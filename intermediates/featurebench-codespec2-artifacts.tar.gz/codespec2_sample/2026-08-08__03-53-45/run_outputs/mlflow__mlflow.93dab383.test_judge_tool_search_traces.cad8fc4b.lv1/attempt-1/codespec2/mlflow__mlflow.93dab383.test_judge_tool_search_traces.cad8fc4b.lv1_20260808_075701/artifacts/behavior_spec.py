print('FAIL: behavior_spec.py has not been generated.')
raise SystemExit(1)
