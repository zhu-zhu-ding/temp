print('FAIL: arch_spec.py has not been generated.')
raise SystemExit(1)
