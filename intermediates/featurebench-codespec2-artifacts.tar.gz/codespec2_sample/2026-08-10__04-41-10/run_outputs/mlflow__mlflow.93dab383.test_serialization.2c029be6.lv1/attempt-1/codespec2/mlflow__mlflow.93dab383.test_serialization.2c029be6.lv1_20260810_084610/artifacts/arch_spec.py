#!/usr/bin/env python3
"""
Executable architecture spec for Assessment Source Management and Custom Scorer Framework.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts:
  - C1: AssessmentSourceType constructs from string (Interface)
  - C4: _standardize returns uppercase string (Dataflow)
  - C5: scorer decorator produces CustomScorer with DECORATOR kind (Interface)
  - C6: scorer with parens accepts name/description/aggregations (Dataflow)
  - C7: scorer serialization round-trips through model_dump/model_validate (Dataflow)
  - C8: scorer model_dump includes call_source and call_signature (Dataflow)
  - C11: scorer run overwrites default feedback name (Dataflow)
  - C12: extract_function_body returns dedented source (Dataflow)
  - C13: recreate_function builds executable callable (Behavior)

Each check_* function provides an executable proof of a contract.
"""

import importlib
import inspect
import sys
import warnings
from typing import Any
from unittest.mock import patch


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _safe_import(module_name: str, attr_name: str) -> Any:
    """Import and return a named attribute from a module, raising on failure."""
    mod = importlib.import_module(module_name)
    if not hasattr(mod, attr_name):
        raise AssertionError(
            f"Module {module_name!r} does not export {attr_name!r}"
        )
    return getattr(mod, attr_name)


def _assert_no_error(callable_fn, *args, **kwargs) -> Any:
    """Call callable_fn and return its result; raise on exception."""
    return callable_fn(*args, **kwargs)


# ──────────────────────────────────────────────────────────────────────────────
# C1: AssessmentSourceType constructs a valid instance from string
# L2 public entry: AssessmentSourceType(...) -> N1, N2, N3, E3
# ──────────────────────────────────────────────────────────────────────────────

def check_assessmentsourcetype_construction_and_str() -> None:
    """
    Verify that AssessmentSourceType(source_type_str) creates an
    instance whose str() returns the uppercase, standardized form.

    Contracts: C1
    Graph: N1, N2, N3, E3
    """
    AssessmentSourceType = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSourceType"
    )

    # Construction with lowercase input
    instance = _assert_no_error(AssessmentSourceType, "human")
    # str() must return uppercase
    assert str(instance) == "HUMAN", (
        f"Expected 'HUMAN', got {str(instance)!r}"
    )

    # Construction with uppercase input
    instance2 = _assert_no_error(AssessmentSourceType, "CODE")
    assert str(instance2) == "CODE", (
        f"Expected 'CODE', got {str(instance2)!r}"
    )

    # Construction with mixed case
    instance3 = _assert_no_error(AssessmentSourceType, "Llm_Judge")
    assert str(instance3) == "LLM_JUDGE", (
        f"Expected 'LLM_JUDGE', got {str(instance3)!r}"
    )

    print("PASS: check_assessmentsourcetype_construction_and_str")


# ──────────────────────────────────────────────────────────────────────────────
# C4: _standardize returns uppercase validated string
# L2 path: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
#          -> AssessmentSourceType.__init__ -> AssessmentSourceType._parse
# Contracts: C4
# Graph: N4, E1, E2
# ──────────────────────────────────────────────────────────────────────────────

def check_standardize_via_assessmentsource_post_init() -> None:
    """
    Prove that AssessmentSource.__post_init__ calls
    AssessmentSourceType._standardize, normalizing the source_type
    to uppercase through the full public chain.

    Contracts: C4
    Graph: N4, N6, N7, E1, E2
    """
    AssessmentSource = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSource"
    )
    AssessmentSourceType = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSourceType"
    )

    # Direct call to _standardize
    result = AssessmentSourceType._standardize("human")
    assert result == "HUMAN", f"Expected 'HUMAN', got {result!r}"

    result2 = AssessmentSourceType._standardize("code")
    assert result2 == "CODE", f"Expected 'CODE', got {result2!r}"

    # Through AssessmentSource.__post_init__ (public entry)
    source = _assert_no_error(AssessmentSource, source_type="human")
    assert source.source_type == "HUMAN", (
        f"Post-init failed to standardize: {source.source_type!r}"
    )

    # AI_JUDGE deprecated path through _standardize
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result3 = AssessmentSourceType._standardize("AI_JUDGE")
        assert result3 == "LLM_JUDGE", (
            f"Expected 'LLM_JUDGE', got {result3!r}"
        )
        assert any("AI_JUDGE is deprecated" in str(warning.message) for warning in w), (
            "No deprecation warning for AI_JUDGE via _standardize"
        )

    print("PASS: check_standardize_via_assessmentsource_post_init")


# ──────────────────────────────────────────────────────────────────────────────
# C5: scorer decorator produces CustomScorer with DECORATOR kind
# L2 public entry: scorer(func) -> N8, N9, N10, E4, E6, E7
# Contracts: C5
# Graph: N8, N9, N10, E4, E6, E7
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_decorator_produces_custom_scorer() -> None:
    """
    Prove that the scorer decorator wraps a function into a Scorer
    subclass with kind == ScorerKind.DECORATOR.

    Contracts: C5
    Graph: N8, N9, N10, E4, E6, E7
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    Scorer = _safe_import("mlflow.genai.scorers.base", "Scorer")
    ScorerKind = _safe_import("mlflow.genai.scorers.base", "ScorerKind")

    def my_test_func(outputs) -> bool:
        return bool(outputs)

    # Without parens: @scorer
    decorated = _assert_no_error(scorer_fn, my_test_func)
    assert isinstance(decorated, Scorer), (
        f"Expected Scorer instance, got {type(decorated).__name__}"
    )
    assert decorated.kind == ScorerKind.DECORATOR, (
        f"Expected DECORATOR kind, got {decorated.kind}"
    )
    assert decorated.name == "my_test_func", (
        f"Expected name 'my_test_func', got {decorated.name!r}"
    )

    # Calling the scorer invokes the original function
    result = _assert_no_error(decorated, outputs="hello")
    assert result is True, f"Expected True, got {result!r}"

    result2 = _assert_no_error(decorated, outputs="")
    assert result2 is False, f"Expected False, got {result2!r}"

    print("PASS: check_scorer_decorator_produces_custom_scorer")


# ──────────────────────────────────────────────────────────────────────────────
# C6: scorer with parens accepts name/description/aggregations
# L2 public entry: scorer(name=..., description=...)(func) -> N8, E4, E5
# Contracts: C6
# Graph: N8, E4, E5
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_parens_accepts_optional_params() -> None:
    """
    Prove that scorer(...)(func) accepts optional name, description,
    and aggregations that are stored on the resulting scorer instance.

    Contracts: C6
    Graph: N8, E4, E5
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")

    def my_func(outputs) -> bool:
        return bool(outputs)

    # With parens: @scorer(name="custom", description="desc")
    decorated = _assert_no_error(
        scorer_fn, name="custom_name", description="my description"
    )
    scorer_instance = _assert_no_error(decorated, my_func)
    assert scorer_instance.name == "custom_name", (
        f"Expected name 'custom_name', got {scorer_instance.name!r}"
    )
    assert scorer_instance.description == "my description", (
        f"Expected description 'my description', got {scorer_instance.description!r}"
    )

    # With custom aggregations
    decorated2 = _assert_no_error(
        scorer_fn, name="agg_scorer", aggregations=["min", "max"]
    )
    scorer_instance2 = _assert_no_error(decorated2, my_func)
    assert scorer_instance2.aggregations == ["min", "max"], (
        f"Expected ['min', 'max'], got {scorer_instance2.aggregations!r}"
    )

    print("PASS: check_scorer_parens_accepts_optional_params")


# ──────────────────────────────────────────────────────────────────────────────
# C8: scorer model_dump includes call_source and call_signature
# L2 path: scorer(func).model_dump() -> N12, N13, E11, E12
# Contracts: C8
# Graph: N12, N13, E11, E12
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_model_dump_contains_source_code_fields() -> None:
    """
    Prove that model_dump() on a decorator scorer includes
    call_source, call_signature, and original_func_name keys
    with non-None values.

    Contracts: C8
    Graph: N12, N13, E11, E12
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")

    def my_test_func(outputs, expectations=None) -> bool:
        if expectations is not None:
            return outputs == expectations.get("expected")
        return len(outputs) > 3

    decorated = _assert_no_error(scorer_fn, my_test_func)
    dump = _assert_no_error(decorated.model_dump)

    assert isinstance(dump, dict), f"Expected dict, got {type(dump).__name__}"
    assert "call_source" in dump, f"Missing 'call_source' key in {list(dump.keys())}"
    assert "call_signature" in dump, (
        f"Missing 'call_signature' key in {list(dump.keys())}"
    )
    assert "original_func_name" in dump, (
        f"Missing 'original_func_name' key in {list(dump.keys())}"
    )
    assert dump["call_source"] is not None, "call_source should not be None"
    assert dump["call_signature"] is not None, "call_signature should not be None"
    assert dump["original_func_name"] == "my_test_func", (
        f"Expected 'my_test_func', got {dump['original_func_name']!r}"
    )

    # call_source should contain the function body content
    assert "len(outputs)" in dump["call_source"] or "outputs" in dump["call_source"], (
        f"call_source should contain function logic, got {dump['call_source']!r}"
    )

    # call_signature should contain parameter names
    assert "outputs" in dump["call_signature"], (
        f"call_signature should mention 'outputs', got {dump['call_signature']!r}"
    )

    print("PASS: check_scorer_model_dump_contains_source_code_fields")


# ──────────────────────────────────────────────────────────────────────────────
# C7: scorer serialization round-trips through model_dump/model_validate
# L2 path: Scorer.model_validate(scorer_func.model_dump())
#          -> N12, N13, N14, N15, N16, N17, E11, E12, E13, E15
# Contracts: C7
# Graph: N12, N13, N14, N15, N16, N17, E11, E12, E13, E15
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_serialization_roundtrip() -> None:
    """
    Prove that a decorator scorer serializes and deserializes correctly
    with behavioral equivalence preserved across control flow, loops,
    and inline imports.

    # Reference: tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri
    #            tests/genai/scorers/test_scorer_utils.py::test_function_with_control_flow
    #            tests/genai/scorers/test_scorer_utils.py::test_function_with_loop

    Contracts: C7
    Graph: N12, N13, N14, N15, N16, N17, E11, E12, E13, E15
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    Scorer = _safe_import("mlflow.genai.scorers.base", "Scorer")

    # Use a scorer with control flow, loops, and an inline import
    def complex_scorer(outputs) -> bool:
        import re
        if not outputs:
            return False
        score = 0
        for word in outputs.split():
            if word.isupper():
                score += 2
            else:
                score += 1
        return score >= 5

    decorator_scorer = _assert_no_error(scorer_fn, complex_scorer)
    original_dump = decorator_scorer.model_dump()

    # Serialized data must contain source code fields
    assert original_dump["original_func_name"] == "complex_scorer"
    assert original_dump["call_source"] is not None
    assert original_dump["call_signature"] is not None

    # Round-trip: model_validate with Databricks runtime mocked so deserialization succeeds
    with patch(
        "mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True
    ):
        deserialized = Scorer.model_validate(original_dump)

    # Same identity fields
    assert deserialized.name == decorator_scorer.name, (
        f"Name mismatch: {deserialized.name!r} vs {decorator_scorer.name!r}"
    )
    assert deserialized.description == decorator_scorer.description, (
        f"Description mismatch: {deserialized.description!r} vs {decorator_scorer.description!r}"
    )

    # Behavioral equivalence — cover all branches of control flow
    # Empty output -> False
    assert deserialized(outputs="") is False, (
        "Roundtripped scorer should return False for empty string"
    )
    # Short output, score=4 < 5 -> False
    assert deserialized(outputs="ab cd") is False, (
        "Roundtripped scorer should return False for 'ab cd' (score=4)"
    )
    # Mixed case, score=1+1+2+1=5 >= 5 -> True
    assert deserialized(outputs="a b C") is True, (
        "Roundtripped scorer should return True for 'a b C' (score=5)"
    )
    # All uppercase, score=2+2+2=6 >= 5 -> True
    assert deserialized(outputs="HI") is True, (
        "Roundtripped scorer should return True for 'HI' (score=4? no: 2+2=4 < 5)"
    )
    # Longer mixed: "Hello WORLD test" -> H=2, e=1, l=1, l=1, o=1, W=2, O=2, R=2, L=2, D=2, t=1, e=1, s=1, t=1 => 2+1+1+1+1 + 2+2+2+2+2 + 1+1+1+1 = 6+10+4 = 20 >= 5 -> True
    assert deserialized(outputs="Hello WORLD test") is True, (
        "Roundtripped scorer should return True for long mixed string"
    )

    print("PASS: check_scorer_serialization_roundtrip")


# ──────────────────────────────────────────────────────────────────────────────
# C11: scorer run overwrites default feedback name
# L2 path: scorer.run() -> N11, N20, N21, E8, E10
# Contracts: C11
# Graph: N11, N20, N21, E8, E10
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_run_overwrites_default_feedback_name() -> None:
    """
    Prove that when a decorator scorer returns a Feedback with the
    default name, run() overwrites it to the scorer's own name.

    Contracts: C11
    Graph: N11, N20, N21, E8, E10
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    Feedback = _safe_import("mlflow.entities", "Feedback")

    @scorer_fn
    def my_scorer(inputs, outputs):
        return Feedback(value=42)

    # Call run() which triggers the name-rewrite logic
    result = _assert_no_error(
        my_scorer.run,
        inputs={"question": "test"},
        outputs="answer",
    )

    assert result.name == "my_scorer", (
        f"Expected feedback name 'my_scorer', got {result.name!r}"
    )
    assert result.value == 42, (
        f"Expected value 42, got {result.value!r}"
    )

    # When user explicitly sets a different name, it should NOT be overwritten
    @scorer_fn
    def another_scorer(inputs, outputs):
        return Feedback(name="explicit_name", value=7)

    result2 = _assert_no_error(
        another_scorer.run,
        inputs={"question": "test"},
        outputs="answer",
    )
    assert result2.name == "explicit_name", (
        f"Expected 'explicit_name', got {result2.name!r}"
    )

    print("PASS: check_scorer_run_overwrites_default_feedback_name")


# ──────────────────────────────────────────────────────────────────────────────
# C12: extract_function_body returns dedented source
# L2 path: extract_function_body(func) -> N16, E12
# Contracts: C12
# Graph: N16, E12
# ──────────────────────────────────────────────────────────────────────────────

def check_extract_function_body_returns_dedented_source() -> None:
    """
    Prove that extract_function_body extracts the dedented body
    of a function, returning a (str, int) tuple.

    Contracts: C12
    Graph: N16, E12
    """
    extract_function_body = _safe_import(
        "mlflow.genai.scorers.scorer_utils", "extract_function_body"
    )

    def sample_func(x):
        # a comment
        y = x + 1
        return y

    body, indent = _assert_no_error(extract_function_body, sample_func)

    assert isinstance(body, str), (
        f"Expected str body, got {type(body).__name__}"
    )
    assert isinstance(indent, int), (
        f"Expected int indent, got {type(indent).__name__}"
    )
    assert len(body) > 0, "Body should be non-empty"
    assert "return y" in body or "return x + 1" in body, (
        f"Body should contain return statement, got {body!r}"
    )

    # Test with lambda
    lam = lambda x: x + 1
    body2, indent2 = _assert_no_error(extract_function_body, lam)
    assert isinstance(body2, str), (
        f"Expected str body from lambda, got {type(body2).__name__}"
    )
    assert len(body2) > 0, "Lambda body should be non-empty"

    print("PASS: check_extract_function_body_returns_dedented_source")


# ──────────────────────────────────────────────────────────────────────────────
# C13: recreate_function builds executable callable
# L2 path: recreate_function(source, signature, func_name) -> N17, E15
# Contracts: C13
# Graph: N17, E15
# ──────────────────────────────────────────────────────────────────────────────

def check_recreate_function_builds_executable_callable() -> None:
    """
    Prove that recreate_function dynamically builds a callable from
    source code string and signature that executes correctly.

    Contracts: C13
    Graph: N17, E15
    """
    recreate_function = _safe_import(
        "mlflow.genai.scorers.scorer_utils", "recreate_function"
    )

    # Simple arithmetic
    func = _assert_no_error(
        recreate_function,
        "return x + 1",
        "(x)",
        "add_one",
    )
    assert callable(func), "Recreated function is not callable"
    assert func.__name__ == "add_one", (
        f"Expected __name__ 'add_one', got {func.__name__!r}"
    )
    assert func(1) == 2, f"add_one(1) should be 2, got {func(1)}"

    # Function with control flow
    func2 = _assert_no_error(
        recreate_function,
        "if x > 0:\n    return 'positive'\nelse:\n    return 'non-positive'",
        "(x)",
        "classify",
    )
    assert func2(5) == "positive", f"classify(5) should be 'positive', got {func2(5)!r}"
    assert func2(-1) == "non-positive", (
        f"classify(-1) should be 'non-positive', got {func2(-1)!r}"
    )

    # Function with default parameter
    func3 = _assert_no_error(
        recreate_function,
        "return base ** exponent",
        "(base, exponent=2)",
        "power",
    )
    assert func3(3) == 9, f"power(3) should be 9, got {func3(3)}"
    assert func3(2, 3) == 8, f"power(2,3) should be 8, got {func3(2,3)}"

    print("PASS: check_recreate_function_builds_executable_callable")


# ──────────────────────────────────────────────────────────────────────────────
# F1: Caller-binding proof for base.py -> scorer_utils
# L2 path: Scorer._extract_source_code_info() -> extract_function_body
# Contracts: C8 (Dataflow), C12 (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_extract_source_code_info_calls_extract_function_body() -> None:
    """
    Prove that Scorer._extract_source_code_info() calls
    extract_function_body from scorer_utils and returns
    recognizable source information.

    # Reference: tests/genai/scorers/test_scorer_description.py::test_scorer_serialization
    # Perspective: P3 — the caller (base.py) resolves extract_function_body
    #   and produces call_source, call_signature, original_func_name

    Contracts: C8
    Graph: N16, E12, N12, N13
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    extract_function_body = _safe_import(
        "mlflow.genai.scorers.scorer_utils", "extract_function_body"
    )

    def my_original_func(inputs, outputs, expectations=None) -> str:
        # Compute some result
        result = outputs.upper()
        return result

    decorated = _assert_no_error(scorer_fn, my_original_func)

    # Call the private _extract_source_code_info to prove the caller chain
    source_info = _assert_no_error(decorated._extract_source_code_info)

    # The returned dict must have expected keys with recognizable content
    assert source_info["original_func_name"] == "my_original_func", (
        f"Expected 'my_original_func', got {source_info['original_func_name']!r}"
    )
    assert source_info["call_source"] is not None, "call_source must not be None"
    assert source_info["call_signature"] is not None, "call_signature must not be None"

    # call_source should contain the body content (the comment and return)
    assert "result" in source_info["call_source"] or "upper" in source_info["call_source"], (
        f"call_source should contain function body, got {source_info['call_source']!r}"
    )

    # call_signature should contain parameter names
    assert "inputs" in source_info["call_signature"], (
        f"call_signature should contain 'inputs', got {source_info['call_signature']!r}"
    )
    assert "outputs" in source_info["call_signature"], (
        f"call_signature should contain 'outputs', got {source_info['call_signature']!r}"
    )

    # Verify extract_function_body works on the same function directly
    body, indent = extract_function_body(my_original_func)
    assert body is not None and len(body) > 0, "extract_function_body should return non-empty body"
    assert isinstance(indent, int), "indent should be an int"

    print("PASS: check_scorer_extract_source_code_info_calls_extract_function_body")


def check_model_validate_triggers_reconstruct_decorator_scorer() -> None:
    """
    Prove the full end-to-end chain:
    Scorer.model_validate(scorer.model_dump())
    -> _reconstruct_decorator_scorer -> recreate_function -> scorer()
    produces a functionally equivalent scorer.

    # Reference: tests/genai/scorers/test_scorer_description.py::test_scorer_deserialization_with_description
    # Perspective: P3 — the caller (base.py model_validate) resolves
    #   _reconstruct_decorator_scorer which calls recreate_function
    #   from scorer_utils; the recreated scorer works identically.

    Contracts: C7
    Graph: N14, N15, N17, E13, E15
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    Scorer = _safe_import("mlflow.genai.scorers.base", "Scorer")
    Feedback = _safe_import("mlflow.entities", "Feedback")

    # Use a scorer that constructs an MLflow Feedback object
    @scorer_fn
    def feedback_scorer(inputs, outputs, expectations=None) -> Feedback:
        import re
        words = re.findall(r'\b\w+\b', outputs)
        return Feedback(value=len(words), rationale=f"Found {len(words)} words")

    original_dump = feedback_scorer.model_dump()

    # Verify the dump contains source code fields (proving extraction happened)
    assert original_dump["call_source"] is not None
    assert original_dump["call_signature"] is not None
    assert original_dump["original_func_name"] == "feedback_scorer"

    # Round-trip with Databricks runtime mocked
    with patch(
        "mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True
    ):
        deserialized = Scorer.model_validate(original_dump)

    # Verify identity fields
    assert deserialized.name == "feedback_scorer"
    assert deserialized.kind == feedback_scorer.kind

    # Verify behavioral equivalence on multiple inputs
    result1 = deserialized(outputs="hello world test")
    assert isinstance(result1, Feedback), (
        f"Expected Feedback, got {type(result1).__name__}"
    )
    assert result1.value == 3, f"Expected 3 words, got {result1.value}"

    result2 = deserialized(outputs="single")
    assert result2.value == 1, f"Expected 1 word, got {result2.value}"

    result3 = deserialized(outputs="")
    assert result3.value == 0, f"Expected 0 words, got {result3.value}"

    # Also test through run() method to ensure the full chain works
    result4 = deserialized.run(
        inputs={"q": "ignored"},
        outputs="four score and seven",
    )
    assert result4.value == 4, f"Expected 4 words via run(), got {result4.value}"
    assert "Found 4 words" in result4.rationale, (
        f"Expected rationale, got {result4.rationale!r}"
    )

    print("PASS: check_model_validate_triggers_reconstruct_decorator_scorer")


# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    check_assessmentsourcetype_construction_and_str()
    check_standardize_via_assessmentsource_post_init()
    check_scorer_decorator_produces_custom_scorer()
    check_scorer_parens_accepts_optional_params()
    check_scorer_model_dump_contains_source_code_fields()
    check_scorer_serialization_roundtrip()
    check_scorer_run_overwrites_default_feedback_name()
    check_extract_function_body_returns_dedented_source()
    check_recreate_function_builds_executable_callable()
    # F1: caller-binding proofs
    check_scorer_extract_source_code_info_calls_extract_function_body()
    check_model_validate_triggers_reconstruct_decorator_scorer()
