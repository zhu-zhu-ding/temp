# Semantic IR

## L1. Requirement Obligations

### R1: AssessmentSourceType instance creation with validation
- Type: Behavior
- Statement: `AssessmentSourceType(source_type_str)` constructs an instance that validates the input string against known source types, standardizes it to uppercase, and stores the result.
- Task Evidence: "Initialize an AssessmentSourceType instance with validation and standardization. ... The input string is converted to uppercase and validated against the list of supported source types."
- Acceptance: `AssessmentSourceType("human")` produces an instance whose `str()` returns `"HUMAN"`; `AssessmentSourceType("ROBOT")` raises `MlflowException`.
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSourceType` (class defined, `__init__` missing); `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`, `test_assessment_source_case_insensitivity`; `libs/skinny/mlflow/entities/assessment_source.py` (complete implementation).
- Uncertainty: None

### R2: Deprecated AI_JUDGE backward compatibility
- Type: Compatibility
- Statement: The deprecated `"AI_JUDGE"` source type is accepted and transparently converted to `"LLM_JUDGE"` with a `FutureWarning`.
- Task Evidence: "The deprecated 'AI_JUDGE' value triggers a FutureWarning and is converted to 'LLM_JUDGE'."
- Acceptance: `AssessmentSource(source_type="AI_JUDGE")` issues `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and `source.source_type == "LLM_JUDGE"`.
- Repository Evidence: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning`, `test_assessment_source_type_validation`; `mlflow/entities/assessment_source.py:AssessmentSourceType.AI_JUDGE = "AI_JUDGE"`.
- Uncertainty: None

### R3: Case-insensitive source type standardization
- Type: Behavior
- Statement: Source type strings are case-insensitive and always normalized to uppercase.
- Task Evidence: "Case-insensitive string inputs (converts to uppercase)"; "Input strings are automatically converted to uppercase for standardization."
- Acceptance: `"human"`, `"Human"`, and `"HUMAN"` all resolve to `"HUMAN"`; `"llm_judge"` resolves to `"LLM_JUDGE"`.
- Repository Evidence: `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity`.
- Uncertainty: None

### R4: Invalid source type rejection
- Type: Failure
- Statement: An unrecognized source type string raises `MlflowException` with error code `INVALID_PARAMETER_VALUE` and a message listing valid types.
- Task Evidence: "If the provided source_type is not one of the valid source types. The exception includes the invalid value and lists all valid source types."
- Acceptance: `AssessmentSource(source_type="ROBOT")` raises `MlflowException` matching `"Invalid assessment source type"`.
- Repository Evidence: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`.
- Uncertainty: None

### R5: _standardize static method
- Type: Interface
- Statement: `AssessmentSourceType._standardize(source_type: str) -> str` creates a temporary instance and returns its string representation, providing a one-shot validation+normalization path.
- Task Evidence: "This static method provides a convenient interface for standardizing assessment source type values by creating a temporary AssessmentSourceType instance and converting it to its string representation."
- Acceptance: `AssessmentSourceType._standardize("human")` returns `"HUMAN"`; used by `AssessmentSource.__post_init__`.
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`; `libs/skinny/mlflow/entities/assessment_source.py:_standardize`.
- Uncertainty: None

### R6: scorer decorator creates CustomScorer subclass
- Type: Behavior
- Statement: The `scorer(func)` decorator wraps a user function in a `CustomScorer(Scorer)` subclass that delegates `__call__` to the original function and reports `kind == ScorerKind.DECORATOR`.
- Task Evidence: "A decorator to define a custom scorer that can be used in mlflow.genai.evaluate(). ... Returns: A CustomScorer instance that can be used in MLflow evaluation functions."
- Acceptance: `@scorer`-decorated function produces an instance of `Scorer` (subclass) with `kind == ScorerKind.DECORATOR` and `name == func.__name__`.
- Repository Evidence: `tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` uses `scorer(always_yes)`; `libs/skinny/mlflow/genai/scorers/base.py:scorer` (complete implementation).
- Uncertainty: None

### R7: scorer decorator optional parameters
- Type: Interface
- Statement: `scorer` accepts optional keyword arguments `name`, `description`, and `aggregations` that override defaults on the resulting Scorer instance, and supports both `@scorer` (no-parens) and `@scorer(name=...)` (with parens) usage.
- Task Evidence: "name: The name of the scorer. If not provided, uses the function's name. description: A description of what the scorer evaluates. aggregations: A list of aggregation functions..."
- Acceptance: `@scorer(name="custom", description="desc")` yields `scorer.name == "custom"` and `scorer.description == "desc"`; `@scorer` with no args also works via `functools.partial`.
- Repository Evidence: `tests/genai/scorers/test_scorer_description.py::test_decorator_scorer_with_description`, `test_decorator_scorer_with_name_and_description`; `tests/genai/scorers/test_scorer.py::test_scorer_name_works`.
- Uncertainty: None

### R8: scorer serialization captures source code
- Type: Dataflow
- Statement: `Scorer.model_dump()` serializes a decorator-based scorer by extracting the original function's source code body and signature, storing them in `SerializedScorer` fields `call_source`, `call_signature`, and `original_func_name`.
- Task Evidence: "Provide secure serialization that handles source code extraction and reconstruction"; "Support various return types (primitives, Feedback objects, lists) from scorer functions."
- Acceptance: `@scorer`-decorated scorer's `model_dump()` produces a dict with `call_source`, `call_signature`, `original_func_name` populated from the original function.
- Repository Evidence: `tests/genai/scorers/test_scorer_description.py::test_scorer_serialization`; `mlflow/genai/scorers/base.py:Scorer.model_dump` and `Scorer._extract_source_code_info`; `libs/skinny/mlflow/genai/scorers/base.py` (has `extract_function_body` import).
- Uncertainty: None

### R9: scorer deserialization reconstructs from source
- Type: Behavior
- Statement: `Scorer.model_validate(serialized_dict)` reconstructs a decorator scorer by executing the stored source code via `recreate_function` and re-wrapping with the `scorer` decorator, restricted to Databricks runtime environments.
- Task Evidence: "Secure code execution during scorer deserialization (restricted to controlled environments)"; "Handle dynamic function reconstruction from serialized source code."
- Acceptance: Round-trip: `scorer.model_validate(scorer.model_dump())` produces a functionally equivalent scorer with same `name`, `description`, and behavior.
- Repository Evidence: `tests/genai/scorers/test_scorer_description.py::test_scorer_deserialization_with_description`; `mlflow/genai/scorers/base.py:Scorer.model_validate` and `Scorer._reconstruct_decorator_scorer`; `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri`.
- Uncertainty: None

### R10: scorer deserialization security gate
- Type: Failure
- Statement: Deserializing a decorator scorer outside Databricks runtime raises `MlflowException` with a message indicating the restriction and displaying the scorer's reconstructed source code for manual copying.
- Task Evidence: "Secure code execution during scorer deserialization (restricted to controlled environments)"; "Custom scorers created with this decorator can be registered for automatic trace evaluation, but registration is only supported in Databricks environments due to security considerations around code execution during deserialization."
- Acceptance: `Scorer._reconstruct_decorator_scorer(serialized)` outside Databricks raises `MlflowException` matching `"not supported outside of Databricks"`.
- Repository Evidence: `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri`, `test_custom_scorer_loading_blocked_for_databricks_remote_access`.
- Uncertainty: None

### R11: scorer run method validates return types
- Type: Failure
- Statement: `Scorer.run()` validates that the scorer's return value is one of `int`, `float`, `bool`, `str`, `Feedback`, `list[Feedback]`, or `None`, raising `MlflowException` for unsupported types.
- Task Evidence: "The scorer function should return one of the following: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects."
- Acceptance: A scorer returning a `dict` raises `MlflowException` matching `"must return one of int, float, bool, str, Feedback, or list[Feedback]"`.
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.run` (lines 374-428); `tests/genai/scorers/test_scorer.py::test_scorer_returns_feedback_with_error`.
- Uncertainty: None

### R12: scorer run rewrites default feedback name
- Type: Dataflow
- Statement: When a scorer returns a single `Feedback` with the default name (`DEFAULT_FEEDBACK_NAME`), `run()` overwrites it to the scorer's own name for consistency.
- Task Evidence: "The metric name will be determined by the scorer function's name or a custom name specified in the `name` parameter for the scorer."
- Acceptance: `@scorer`-decorated function returning `Feedback(value=42)` produces `result.name == scorer.name` when accessed via `run()`.
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.run` (lines 408-427); `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name`.
- Uncertainty: None

### R13: _parse static method in AssessmentSourceType
- Type: Behavior
- Statement: `AssessmentSourceType._parse(source_type: str) -> str` performs case-insensitive validation, converts `AI_JUDGE` to `LLM_JUDGE` with deprecation warning, and raises `MlflowException` for invalid types.
- Task Evidence: "Parse and validate an assessment source type string. ... performs case-insensitive validation and standardization of assessment source type values. It handles deprecated values by converting them to their modern equivalents and issuing appropriate warnings."
- Acceptance: `_parse("human")` → `"HUMAN"`; `_parse("AI_JUDGE")` → `"LLM_JUDGE"` + `FutureWarning`; `_parse("ROBOT")` → `MlflowException`.
- Repository Evidence: `libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`; `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`, `test_ai_judge_deprecation_warning`.
- Uncertainty: None

### R14: __str__ returns stored standardized value
- Type: Interface
- Statement: `str(AssessmentSourceType(source_type))` returns the normalized uppercase source type string.
- Task Evidence: "Return the string representation of the assessment source type. ... The returned string is always in uppercase format."
- Acceptance: `str(AssessmentSourceType("human"))` → `"HUMAN"`.
- Repository Evidence: `libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType.__str__`; `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `_standardize` which internally uses `str(AssessmentSourceType(...))`.
- Uncertainty: None

### R15: scorer_utils function extraction and reconstruction
- Type: Behavior
- Statement: `extract_function_body(func)` extracts the dedented source body of a function; `recreate_function(source, signature, func_name)` dynamically reconstructs a callable from source code string and signature.
- Task Evidence: "Handle dynamic function reconstruction from serialized source code"; "Provide secure serialization that handles source code extraction and reconstruction."
- Acceptance: `extract_function_body` returns `(dedented_body_str, indent_unit)`; `recreate_function` returns a callable matching the original behavior.
- Repository Evidence: `libs/skinny/mlflow/genai/scorers/scorer_utils.py` (complete implementation of `FunctionBodyExtractor`, `extract_function_body`, `recreate_function`); `mlflow/genai/scorers/scorer_utils.py` (stub/empty); `mlflow/genai/scorers/base.py:_extract_source_code_info` and `_reconstruct_decorator_scorer` reference these functions.
- Uncertainty: None

## L2. Functional Design Graph

### N1: AssessmentSourceType (class)
- Kind: Class
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSourceType`

### N2: AssessmentSourceType.__init__
- Kind: Method
- Repository Evidence: `libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType.__init__`

### N3: AssessmentSourceType._parse
- Kind: Method (static)
- Repository Evidence: `libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`

### N4: AssessmentSourceType._standardize
- Kind: Method (static)
- Repository Evidence: `libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`

### N5: AssessmentSourceType.__str__
- Kind: Method
- Repository Evidence: `libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType.__str__`

### N6: AssessmentSource (dataclass)
- Kind: Class
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSource`

### N7: AssessmentSource.__post_init__
- Kind: Method
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`

### N8: scorer (decorator function)
- Kind: PublicEntry
- Repository Evidence: `libs/skinny/mlflow/genai/scorers/base.py:scorer` (complete); `mlflow/genai/scorers/__init__.py` exports `scorer` in `__all__`

### N9: CustomScorer (inner class created by scorer)
- Kind: Class
- Repository Evidence: `libs/skinny/mlflow/genai/scorers/base.py:CustomScorer` (inner class within `scorer`)

### N10: Scorer (base class)
- Kind: Class
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer`

### N11: Scorer.run
- Kind: Method
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.run`

### N12: Scorer.model_dump
- Kind: Method
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.model_dump`

### N13: Scorer._extract_source_code_info
- Kind: Method
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer._extract_source_code_info`

### N14: Scorer.model_validate
- Kind: Method (classmethod)
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.model_validate`

### N15: Scorer._reconstruct_decorator_scorer
- Kind: Method (classmethod)
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer._reconstruct_decorator_scorer`

### N16: extract_function_body
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/genai/scorers/scorer_utils.py:extract_function_body`

### N17: recreate_function
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/genai/scorers/scorer_utils.py:recreate_function`

### N18: SerializedScorer
- Kind: Payload
- Repository Evidence: `mlflow/genai/scorers/base.py:SerializedScorer`

### N19: MlflowException
- Kind: Error
- Repository Evidence: `mlflow/exceptions.py:MlflowException`

### N20: Feedback
- Kind: Payload
- Repository Evidence: `mlflow/entities/assessment.py:Feedback`

### N21: DEFAULT_FEEDBACK_NAME
- Kind: State
- Repository Evidence: `mlflow/entities/assessment.py:DEFAULT_FEEDBACK_NAME`

### E1: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
- Kind: CALL
- Condition: Always (during dataclass post-init)
- Transfer: `(source_type: str) -> str` — raw source_type string to standardized uppercase string
- Evidence: `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`; `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` verifies normalization.
- Obligations: R5, R3

### E2: AssessmentSourceType._standardize -> AssessmentSourceType.__init__ -> AssessmentSourceType._parse
- Kind: CALL
- Condition: Always
- Transfer: `(source_type: str) -> str` — delegates to `_parse` via `__init__`, returns `str()` of instance
- Evidence: `libs/skinny/mlflow/entities/assessment_source.py:_standardize` (returns `str(AssessmentSourceType(source_type))`); `_parse` called inside `__init__`.
- Obligations: R1, R2, R3, R4, R5, R13, R14

### E3: AssessmentSourceType._parse validates and warns
- Kind: CONTROL
- Condition: `source_type.upper() == "AI_JUDGE"` → deprecation branch; `source_type.upper() not in _SOURCE_TYPES` → error branch
- Transfer: `(source_type: str) -> str` — either returns validated uppercase string or raises `MlflowException`
- Evidence: `libs/skinny/mlflow/entities/assessment_source.py:_parse`; `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`, `test_ai_judge_deprecation_warning`.
- Obligations: R1, R2, R3, R4, R13

### E4: scorer decorator -> CustomScorer class creation
- Kind: CALL
- Condition: `func is not None` (decorator used with function)
- Transfer: `(func, name, description, aggregations) -> CustomScorer instance`
- Evidence: `libs/skinny/mlflow/genai/scorers/base.py:scorer`; `tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics`.
- Obligations: R6, R7

### E5: scorer partial-application branch
- Kind: CONTROL
- Condition: `func is None` (decorator used with arguments: `@scorer(name=...)`)
- Transfer: Returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)`
- Evidence: `libs/skinny/mlflow/genai/scorers/base.py:scorer` (lines `if func is None: return functools.partial(...)`); `tests/genai/scorers/test_scorer_description.py::test_decorator_scorer_with_name_and_description`.
- Obligations: R7

### E6: CustomScorer.__init__ -> Scorer.__init__
- Kind: CALL
- Condition: Always (during construction)
- Transfer: `(**data) -> initialized Scorer` with `_original_func` set via `object.__setattr__`
- Evidence: `libs/skinny/mlflow/genai/scorers/base.py:CustomScorer.__init__`.
- Obligations: R6

### E7: CustomScorer.__call__ -> original func
- Kind: CALL
- Condition: Always (when scorer is invoked)
- Transfer: `(*args, **kwargs) -> result` — delegates to the user's decorated function
- Evidence: `libs/skinny/mlflow/genai/scorers/base.py:CustomScorer.__call__` returns `func(*args, **kwargs)`.
- Obligations: R6

### E8: Scorer.run -> CustomScorer.__call__ (via self)
- Kind: CALL
- Condition: Always
- Transfer: `(inputs, outputs, expectations, trace) -> filtered kwargs -> result` — signature introspection filters args
- Evidence: `mlflow/genai/scorers/base.py:Scorer.run` (lines 374-428).
- Obligations: R11, R12

### E9: Scorer.run return-type validation
- Kind: CONTROL
- Condition: Result is not `int|float|bool|str|Assessment|LegacyAssessment|None` and not `list[Assessment]`
- Transfer: Raises `MlflowException` with descriptive type-error message
- Evidence: `mlflow/genai/scorers/base.py:Scorer.run` (lines 387-404).
- Obligations: R11

### E10: Scorer.run default-feedback-name rewrite
- Kind: DATA
- Condition: `isinstance(result, Feedback) and result.name == DEFAULT_FEEDBACK_NAME`
- Transfer: `result.name := self.name` — overwrites default "feedback" name with scorer name
- Evidence: `mlflow/genai/scorers/base.py:Scorer.run` (lines 408-427); `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name`.
- Obligations: R12

### E11: Scorer.model_dump -> Scorer._extract_source_code_info
- Kind: CALL
- Condition: `self._original_func is not None` (decorator scorer)
- Transfer: Extracts `call_source`, `call_signature`, `original_func_name` from original function
- Evidence: `mlflow/genai/scorers/base.py:Scorer.model_dump` (lines 149-184).
- Obligations: R8

### E12: Scorer._extract_source_code_info -> extract_function_body
- Kind: CALL
- Condition: Always
- Transfer: `(func) -> (body_str, indent_unit)` — extracts dedented source body
- Evidence: `mlflow/genai/scorers/base.py:_extract_source_code_info` (line 188 area, import missing); `libs/skinny/mlflow/genai/scorers/base.py` has `from mlflow.genai.scorers.scorer_utils import extract_function_body`.
- Obligations: R8, R15

### E13: Scorer.model_validate -> Scorer._reconstruct_decorator_scorer
- Kind: CALL
- Condition: Serialized data has `call_source` (decorator scorer fields)
- Transfer: `(SerializedScorer) -> reconstructed Scorer`
- Evidence: `mlflow/genai/scorers/base.py:Scorer.model_validate` (lines 203-300); `tests/genai/scorers/test_scorer_description.py::test_scorer_deserialization_with_description`.
- Obligations: R9

### E14: Scorer._reconstruct_decorator_scorer -> security gate
- Kind: CONTROL
- Condition: `not is_in_databricks_runtime()`
- Transfer: Raises `MlflowException` with code snippet; branch for databricks remote vs non-databricks
- Evidence: `mlflow/genai/scorers/base.py:_reconstruct_decorator_scorer` (lines 302-340); `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri`, `test_custom_scorer_loading_blocked_for_databricks_remote_access`.
- Obligations: R10

### E15: Scorer._reconstruct_decorator_scorer -> recreate_function -> scorer
- Kind: CALL
- Condition: `is_in_databricks_runtime()` (security gate passed)
- Transfer: `(call_source, call_signature, original_func_name) -> recreated callable -> CustomScorer via scorer()`
- Evidence: `libs/skinny/mlflow/genai/scorers/base.py:_reconstruct_decorator_scorer` (lines 345-375).
- Obligations: R9, R15

## L3. Verifiable Contracts

### C1: AssessmentSourceType instance creation normalizes case
- Type: Behavior
- Subject: `AssessmentSourceType(source_type_str)._source_type`
- Relation: EQ
- Expected: `"HUMAN"` for inputs `"human"`, `"Human"`, `"HUMAN"`; `"LLM_JUDGE"` for `"llm_judge"`, `"Llm_Judge"`
- Evidence: Task: "Case-insensitive string inputs (converts to uppercase)"; `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity`.
- Observe: FIELD_READ (via `AssessmentSource.source_type` after `AssessmentSource.__post_init__` which calls `_standardize`)
- Target: `AssessmentSource("human").source_type == "HUMAN"`
- Obligations: R1, R3, R14
- Graph: N1, N2, N3, N4, N5, N6, N7, E1, E2

### C2: AI_JUDGE deprecation warning and conversion
- Type: SideEffect
- Subject: `AssessmentSourceType._parse("AI_JUDGE")`
- Relation: EQ
- Expected: Issues `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and returns `"LLM_JUDGE"`
- Evidence: Task: "The deprecated 'AI_JUDGE' value triggers a FutureWarning and is converted to 'LLM_JUDGE'"; `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning`.
- Observe: SIDE_EFFECT (warning) + RETURN_VALUE
- Target: `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated")` context
- Obligations: R2, R13
- Graph: N3, E3

### C3: Invalid source type raises MlflowException
- Type: Failure
- Subject: `AssessmentSourceType._parse("ROBOT")`
- Relation: RAISES
- Expected: `MlflowException` with `error_code=INVALID_PARAMETER_VALUE`, message containing `"Invalid assessment source type: ROBOT"` and valid types list
- Evidence: Task: "If the provided source_type is not one of the valid source types"; `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`.
- Observe: EXCEPTION
- Target: `pytest.raises(MlflowException, match="Invalid assessment source type")`
- Obligations: R4, R13
- Graph: N3, E3

### C4: _standardize returns uppercase string
- Type: Dataflow
- Subject: `AssessmentSourceType._standardize(source_type)`
- Relation: EQ
- Expected: Returns uppercase validated string (e.g., `"human"` → `"HUMAN"`, `"AI_JUDGE"` → `"LLM_JUDGE"`)
- Evidence: Task: "Standardize and validate an assessment source type string"; `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`.
- Observe: RETURN_VALUE
- Target: `AssessmentSourceType._standardize("human") == "HUMAN"`
- Obligations: R5
- Graph: N4, E1, E2

### C5: scorer decorator produces CustomScorer with DECORATOR kind
- Type: Interface
- Subject: `scorer(func)`
- Relation: TYPE_IS
- Expected: Returns instance of `Scorer` subclass with `kind == ScorerKind.DECORATOR`
- Evidence: Task: "Returns: A CustomScorer instance"; `tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` uses `scorer(always_yes)`; `libs/skinny/mlflow/genai/scorers/base.py:CustomScorer.kind`.
- Observe: RETURN_VALUE
- Target: `isinstance(scorer(my_func), Scorer)` and `scorer(my_func).kind == ScorerKind.DECORATOR`
- Obligations: R6
- Graph: N8, N9, N10, E4, E6, E7

### C6: scorer with parens accepts name/description/aggregations
- Type: Dataflow
- Subject: `scorer(name="x", description="y")(func)`
- Relation: EQ
- Expected: Result has `name == "x"`, `description == "y"`, `aggregations` set accordingly
- Evidence: Task: "name, description, aggregations parameters"; `tests/genai/scorers/test_scorer_description.py::test_decorator_scorer_with_name_and_description`.
- Observe: FIELD_READ
- Target: `scorer(name="custom_name", description="desc")(my_func).name == "custom_name"`
- Obligations: R7
- Graph: N8, E4, E5

### C7: scorer serialization round-trips through model_dump/model_validate
- Type: Dataflow
- Subject: `Scorer.model_validate(scorer_func.model_dump())`
- Relation: EQ
- Expected: Reconstructed scorer has same `name`, `description` and equivalent behavior (same return value for same inputs)
- Evidence: Task: "Provide secure serialization that handles source code extraction and reconstruction"; `tests/genai/scorers/test_scorer_description.py::test_scorer_deserialization_with_description`.
- Observe: RETURN_VALUE
- Target: `Scorer.model_validate(serialized).description == original.description`
- Obligations: R8, R9
- Graph: N12, N13, N14, N15, N16, N17, E11, E12, E13, E15

### C8: scorer model_dump includes call_source and call_signature
- Type: Dataflow
- Subject: `scorer(func).model_dump()`
- Relation: CONTAINS
- Expected: Dict contains keys `"call_source"`, `"call_signature"`, `"original_func_name"` with non-None values for decorator scorers
- Evidence: Task: "Secure serialization that handles source code extraction"; `tests/genai/scorers/test_scorer_description.py::test_scorer_serialization` checks dict keys.
- Observe: RETURN_VALUE
- Target: `"call_source" in scorer(func).model_dump()`
- Obligations: R8
- Graph: N12, N13, E11, E12

### C9: scorer deserialization blocked outside Databricks
- Type: Failure
- Subject: `Scorer._reconstruct_decorator_scorer(serialized)` with `is_in_databricks_runtime() == False`
- Relation: RAISES
- Expected: `MlflowException` matching `"not supported outside of Databricks"` or `"via remote access is not supported"`
- Evidence: Task: "registration is only supported in Databricks environments due to security considerations"; `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri`.
- Observe: EXCEPTION
- Target: `pytest.raises(MlflowException, match="not supported")`
- Obligations: R10
- Graph: N15, E14

### C10: scorer run rejects unsupported return types
- Type: Failure
- Subject: `scorer.run()` when decorated function returns unsupported type (e.g., `dict`)
- Relation: RAISES
- Expected: `MlflowException` matching `"must return one of int, float, bool, str, Feedback, or list[Feedback]"`
- Evidence: Task: "Raises: MlflowException: If the scorer function returns an unsupported type"; `mlflow/genai/scorers/base.py:Scorer.run` (lines 387-404).
- Observe: EXCEPTION
- Target: `pytest.raises(MlflowException, match="must return one of")`
- Obligations: R11
- Graph: N11, E8, E9

### C11: scorer run overwrites default feedback name
- Type: Dataflow
- Subject: `scorer.run()` result when decorated func returns `Feedback(value=42)` (default name)
- Relation: EQ
- Expected: `result.name == scorer.name` (not `DEFAULT_FEEDBACK_NAME`)
- Evidence: Task: "The metric name will be determined by the scorer function's name"; `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name`.
- Observe: RETURN_VALUE
- Target: `feedback.name == "my_scorer"` when `@scorer` wraps `def my_scorer`
- Obligations: R12
- Graph: N11, N20, N21, E8, E10

### C12: extract_function_body returns dedented source
- Type: Dataflow
- Subject: `extract_function_body(func)`
- Relation: TYPE_IS
- Expected: Returns `tuple[str, int]` where first element is dedented function body without signature/docstring
- Evidence: `libs/skinny/mlflow/genai/scorers/scorer_utils.py:extract_function_body`; `mlflow/genai/scorers/base.py:_extract_source_code_info` calls it.
- Observe: RETURN_VALUE
- Target: `extract_function_body(lambda x: x + 1)` returns `("return x + 1", indent)`-like tuple
- Obligations: R15
- Graph: N16, E12

### C13: recreate_function builds executable callable
- Type: Behavior
- Subject: `recreate_function("return x + 1", "(x)", "add_one")`
- Relation: EQ
- Expected: Returns a callable `add_one` such that `add_one(1) == 2`
- Evidence: `libs/skinny/mlflow/genai/scorers/scorer_utils.py:recreate_function`; `mlflow/genai/scorers/base.py:_reconstruct_decorator_scorer` uses it.
- Observe: RETURN_VALUE
- Target: `recreate_function("return x + 1", "(x)", "f")(1) == 2`
- Obligations: R15
- Graph: N17, E15
