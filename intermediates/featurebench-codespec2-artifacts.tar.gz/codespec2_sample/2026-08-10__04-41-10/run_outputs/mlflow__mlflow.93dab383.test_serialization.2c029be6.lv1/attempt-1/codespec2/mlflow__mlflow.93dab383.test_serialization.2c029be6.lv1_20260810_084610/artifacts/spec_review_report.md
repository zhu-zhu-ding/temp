# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — requires L2 caller-binding checks with real import/binding observation, not isolated helper tests
- Native tests:
  - `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — validates MlflowException with `match="Invalid assessment source type"` and AI_JUDGE→LLM_JUDGE conversion
  - `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` with exact full message match
  - `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` — verifies case-insensitive normalization through AssessmentSource chain
  - `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` — parametrized test covering default-name overwrite AND custom-name preservation
  - `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` — tests `_reconstruct_decorator_scorer` with SerializedScorer containing `import os; os.system(...)`; checks exact error match
  - `tests/genai/scorers/test_scorer.py::test_custom_scorer_error_message_renders_code_snippet_legibly` — verifies error message contains readable `@scorer`-formatted code snippet
  - `tests/genai/scorers/test_scorer_description.py::test_scorer_serialization` — checks `call_source`/`call_signature` keys in `model_dump()` output
  - `tests/genai/scorers/test_scorer_utils.py::test_mlflow_imports_available` — tests that recreated functions can access MLflow types (Feedback, Trace, etc.) in their namespace
  - `tests/genai/scorers/test_scorer_utils.py::test_function_with_mlflow_trace_type_hint` — tests recreate_function with type-hinted signatures containing `mlflow.entities.Trace`
- Repository source inspected:
  - `/testbed/mlflow/entities/assessment_source.py` — AssessmentSourceType class constants present; `__init__`, `__str__`, `_parse`, `_standardize` MISSING
  - `/testbed/mlflow/genai/scorers/base.py` — Scorer class present; `scorer` decorator function MISSING; calls `extract_function_body` (line 193) and `recreate_function` (line 346) but neither is imported
  - `/testbed/mlflow/genai/scorers/scorer_utils.py` — FunctionBodyExtractor class skeleton with empty body; `extract_function_body` and `recreate_function` both MISSING (empty stubs only)
  - `/testbed/libs/skinny/mlflow/entities/assessment_source.py` — complete reference implementation
  - `/testbed/libs/skinny/mlflow/genai/scorers/base.py` — complete reference implementation with `scorer` decorator at line 847
  - `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` — complete reference implementation

## Rubric
- Requirement coverage: 1 — 13 of 15 IR requirements (R1-R15) have at least one observable assertion, but R13 (`_parse` as distinct static method) and R14 (lifecycle: register/start/stop/update) lack dedicated checks beyond indirect chain coverage
- Caller binding / call chain: 1 — several L2 CALL edges are untested: `base.py`→`extract_function_body` and `base.py`→`recreate_function` are not proven (helpers tested in isolation, not through caller); `AssessmentSource.from_proto`→`AssessmentSourceType.from_proto` is not covered
- Dataflow / state / lifecycle: 1 — serialization round-trip checks only `description` field; no behavioral-equivalence verification for non-trivial scorer logic; lifecycle (register/start/stop/update/sampling-config) entirely absent from both specs
- Failure / compatibility boundaries: 1 — deprecation warning uses substring match instead of exact message from native test; invalid-type rejection doesn't verify `INVALID_PARAMETER_VALUE` error code; code-snippet rendering in error messages not covered

## Derived Practical Test Perspectives
- P1: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — native test uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` with exact full message; current behavior_spec uses substring `"AI_JUDGE is deprecated"` which would pass even if the message omits the migration guidance
- P2: `tests/genai/scorers/test_scorer.py::test_custom_scorer_error_message_renders_code_snippet_legibly` — native test verifies that the blocked-deserialization error message includes a properly formatted `@scorer`-decorated code snippet with correct indentation; this error-message rendering is completely absent from both specs
- P3: `tests/genai/scorers/test_scorer_utils.py::test_mlflow_imports_available` — native test proves that `recreate_function` provides `Feedback`, `AssessmentSourceType`, `Trace`, etc. in the execution namespace so recreated scorers can use these types; the current arch_spec C13 only tests arithmetic callables, not MLflow-type construction
- P4: `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` — native test constructs a `SerializedScorer` with realistic malicious source code (`import os; os.system(...)`) to validate the security gate; current behavior_spec C9 uses trivial `"return True"` which does not stress-test the code-snippet rendering path

## Final Rubric Scores
- Requirement coverage: 1 — R13 (`_parse` static method signature) and R14 (scorer lifecycle: register/start/stop/update) lack dedicated observable checks. While R13 behavior is exercised through the `__init__`→`_parse` chain, the spec never directly observes `_parse` as a standalone static method with its documented signature. The lifecycle methods (`register`, `start`, `stop`, `update`) have no spec coverage despite being core to the "scorer registration, lifecycle management" task requirement.
- Caller binding / call chain: 1 — the most critical L2 CALL edges are unproven: `Scorer._extract_source_code_info` (line 193) calls `extract_function_body` and `Scorer._reconstruct_decorator_scorer` (line 346) calls `recreate_function`, yet neither import is verified. The arch_spec tests these helpers in isolation via direct `_safe_import` from `scorer_utils`, which proves the helpers exist but does NOT prove the caller (`base.py`) resolves and invokes them correctly. The Test Spec skill explicitly requires: "A direct helper test does not prove a caller-binding requirement." Additionally, `AssessmentSource.from_proto`→`AssessmentSourceType.from_proto` has no coverage.
- Dataflow / state / lifecycle: 1 — serialization round-trip (C7) checks only `description` equality; it does not verify that the recreated scorer produces the same output for non-trivial inputs (e.g., a scorer with conditional logic). The entire scorer lifecycle (register/start/stop/update) and `ScorerSamplingConfig` dataflow are absent, despite being listed as "Main Features & Requirements" in the task document. The `model_validate`→`_reconstruct_decorator_scorer`→`scorer` reconstruction chain is not verified end-to-end for behavioral fidelity.
- Failure / compatibility boundaries: 1 — three specific weaknesses: (a) C2 deprecation warning check uses substring `"AI_JUDGE is deprecated"` instead of the exact native-test message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`; (b) C3 invalid-type rejection doesn't verify `error_code=INVALID_PARAMETER_VALUE`; (c) the code-snippet rendering in deserialization error messages (tested by `test_custom_scorer_error_message_renders_code_snippet_legibly`) is completely absent from both specs.
- P1 (exact deprecation message): 0 — behavior_spec C2 uses loose substring match; a wrong implementation emitting `"AI_JUDGE is deprecated"` without the migration hint would pass
- P2 (error code-snippet rendering): 0 — no spec verifies that blocked-deserialization errors contain readable `@scorer`-decorated code snippets
- P3 (MLflow types in recreate_function namespace): 1 — arch_spec C13 tests arithmetic functions; behavior_spec adds `check_recreate_function_with_mlflow_types` which tests Feedback construction, partially covering this angle, but does not test AssessmentSourceType or Trace availability
- P4 (malicious-code security gate): 1 — behavior_spec C9 tests blocking with trivial `"return True"` source; a weak implementation that only blocks certain patterns would pass, whereas the native test uses realistic `import os; os.system(...)` to stress-test

## Findings
- ### F1: missing_requirement — L2 CALL binding `base.py → scorer_utils` unproven
  - Requirement/IR: E11 (`Scorer._extract_source_code_info → extract_function_body`), E15 (`Scorer._reconstruct_decorator_scorer → recreate_function`)
  - Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 193, 346 call `extract_function_body` and `recreate_function` respectively, but neither is imported at the module top. The arch_spec `check_extract_function_body_returns_dedented_source` and `check_recreate_function_builds_executable_callable` import these helpers directly from `scorer_utils`, bypassing the caller.
  - Gap: No spec verifies that `Scorer._extract_source_code_info()` successfully calls `extract_function_body` and receives a valid result, or that `Scorer._reconstruct_decorator_scorer()` calls `recreate_function`. A missing or broken import in `base.py` would go undetected.
  - Repair: Add an arch_spec check that creates a scorer via `scorer(func)`, calls `scorer_instance._extract_source_code_info()`, and asserts the result contains non-None `call_source`/`call_signature`/`original_func_name`. This proves the caller resolves and invokes the helper. Similarly, call `Scorer.model_validate(scorer_instance.model_dump())` and assert the recreated scorer produces identical output — this proves the full `model_validate → _reconstruct_decorator_scorer → recreate_function → scorer` chain.

- ### F2: weak_constraint — C2 deprecation warning uses substring, not exact message
  - Requirement/IR: C2 (`AssessmentSourceType._parse("AI_JUDGE")` → `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`)
  - Evidence: Native test `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` with the exact full message. The behavior_spec `check_ai_judge_deprecation_warning` checks `"AI_JUDGE is deprecated" in str(warning.message)` which is a substring match.
  - Gap: A wrong implementation emitting `"AI_JUDGE is deprecated"` without the migration guidance `"Use LLM_JUDGE instead."` would pass the current spec but fail the native test.
  - Repair: Change the behavior_spec assertion to match the full expected message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`, matching the native test's exact requirement.

- ### F3: weak_constraint — C3 invalid-type rejection doesn't verify error_code
  - Requirement/IR: C3 (`AssessmentSourceType._parse("ROBOT")` → `MlflowException` with `error_code=INVALID_PARAMETER_VALUE`)
  - Evidence: The IR explicitly states `error_code=INVALID_PARAMETER_VALUE`. The behavior_spec `check_invalid_source_type_raises_mlflow_exception` only checks that `"Invalid assessment source type"` appears in the message, not the error code.
  - Gap: An implementation that raises `MlflowException` with a different error code (e.g., `INTERNAL_ERROR`) would pass the current spec.
  - Repair: Add assertion on `exc_info.value.error_code == INVALID_PARAMETER_VALUE` (importing the constant from `mlflow.protos.databricks_pb2`).

- ### F4: missing_requirement — scorer lifecycle (register/start/stop/update) uncovered
  - Requirement/IR: Task document lists "Enable scorer registration, lifecycle management (start/stop/update), and sampling configuration" as a main feature. Native tests `tests/genai/scorers/test_scorer_CRUD.py` extensively test these operations.
  - Evidence: Neither arch_spec nor behavior_spec contains any check for `register()`, `start()`, `stop()`, `update()`, `status`, `sample_rate`, or `filter_string` properties. The `ScorerSamplingConfig` dataclass is not exercised.
  - Gap: The lifecycle management — a task-stated core functionality — has zero spec coverage. Registration gating (blocked for non-Databricks, blocked for CLASS kind) is partially covered by C9 but the happy-path lifecycle is absent.
  - Repair: Add a behavior_spec check that creates a custom scorer, verifies initial `status == ScorerStatus.UNREGISTERED`, then (with Databricks runtime mocked) calls `register()`, verifies `status == ScorerStatus.STOPPED`, calls `start()` with a sampling config, verifies `status == ScorerStatus.STARTED` and `sample_rate` is set, calls `stop()`, verifies `status == ScorerStatus.STOPPED`. Also test `update()` with filter string changes.

- ### F5: missing_requirement — error message code-snippet rendering not verified
  - Requirement/IR: Native test `tests/genai/scorers/test_scorer.py::test_custom_scorer_error_message_renders_code_snippet_legibly` verifies that deserialization-blocked errors contain properly formatted `@scorer`-decorated code.
  - Evidence: The behavior_spec C9 checks check only that `"not supported"` or `"Loading custom scorer"` appears in the error message. They do not verify the presence of `"Registered scorer code:"`, `"from mlflow.genai import scorer"`, `"@scorer"`, or the properly indented function definition.
  - Gap: An implementation that blocks deserialization but omits the code snippet from the error message would pass the current spec.
  - Repair: Add assertions in behavior_spec C9 checks that verify the error message contains `"Registered scorer code:"`, `"from mlflow.genai import scorer"`, `"@scorer"`, and the function definition with proper indentation matching the native test's expectations.

- ### F6: weak_constraint — serialization round-trip doesn't verify behavioral equivalence
  - Requirement/IR: C7 (`Scorer.model_validate(scorer_func.model_dump())` → "equivalent behavior (same return value for same inputs)")
  - Evidence: The arch_spec `check_scorer_serialization_roundtrip` tests a simple `len(outputs) > 4` scorer and verifies the recreated scorer returns the same boolean for two inputs. This is a good start but only uses a trivial function.
  - Gap: A serializer that strips conditional branches, loops, or import statements would still pass. The native test `test_scorer_utils.py::test_function_with_control_flow` tests recreate_function with if/else, and `test_function_with_loop` tests loops — but these are isolated helper tests, not round-trip tests through the scorer.
  - Repair: Enhance the round-trip check to use a scorer with control flow (if/else), loops, and an inline import, then verify behavioral equivalence on multiple diverse inputs after deserialization.

## Rework Instructions
1. **Add caller-binding proof for `base.py`→`scorer_utils` (F1)**: In arch_spec.py, add a `check_scorer_extract_source_code_info_calls_extract_function_body` that creates a decorated scorer, calls `scorer._extract_source_code_info()`, and asserts the returned dict has non-None `call_source`, `call_signature`, `original_func_name` with recognizable content from the original function. Also add `check_model_validate_triggers_reconstruct_decorator_scorer` that calls `Scorer.model_validate(scorer.model_dump())` and asserts the recreated scorer produces identical output for multiple inputs — this proves the full `model_validate → _reconstruct_decorator_scorer → recreate_function → scorer` chain end-to-end.
2. **Strengthen C2 deprecation warning to exact message (F2)**: In behavior_spec `check_ai_judge_deprecation_warning`, change the substring check from `"AI_JUDGE is deprecated"` to the exact full message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`.
3. **Add error_code assertion to C3 (F3)**: In behavior_spec `check_invalid_source_type_raises_mlflow_exception`, import `INVALID_PARAMETER_VALUE` from `mlflow.protos.databricks_pb2` and assert `exc_info.value.error_code == INVALID_PARAMETER_VALUE`.
4. **Add scorer lifecycle coverage (F4)**: In behavior_spec.py, add `check_scorer_lifecycle_register_start_stop` that mocks `is_in_databricks_runtime` and `is_databricks_uri` as True, then walks through UNREGISTERED→STOPPED (after register)→STARTED (after start with sampling config)→STOPPED (after stop). Verify `sample_rate`, `filter_string`, and `status` at each step.
5. **Add error-message code-snippet verification (F5)**: In behavior_spec C9 checks, after catching the MlflowException, assert the error message contains `"Registered scorer code:"`, `"from mlflow.genai import scorer"`, `"@scorer"`, and the function definition line matching `serialized.original_func_name`.
6. **Strengthen round-trip behavioral equivalence (F6)**: In arch_spec `check_scorer_serialization_roundtrip`, use a scorer function with conditional branching (if/elif/else returning different values) and test the deserialized scorer on multiple inputs covering all branches.
