#!/usr/bin/env python3
"""
Executable behavior spec for Assessment Source Management and Custom Scorer Framework.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries, and
compatibility contracts:
  - C1: AssessmentSourceType constructs from string (Behavior - default/boundary)
  - C2: AI_JUDGE deprecated -> FutureWarning + LLM_JUDGE (Compatibility/SideEffect)
  - C3: Invalid source type -> MlflowException (Failure)
  - C5: scorer decorator produces CustomScorer with DECORATOR kind (Behavior - boundary)
  - C9: scorer deserialization blocked outside Databricks (Failure)
  - C10: scorer run rejects unsupported return types (Failure)
  - C13: recreate_function builds executable callable (Behavior - boundary/edge)

Each check_* function provides an executable proof of a contract.
"""

import importlib
import sys
import warnings
from typing import Any
from unittest.mock import patch


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _safe_import(module_name: str, attr_name: str) -> Any:
    """Import and return a named attribute from a module, raising on failure."""
    mod = importlib.import_module(module_name)
    if not hasattr(mod, attr_name):
        raise AssertionError(
            f"Module {module_name!r} does not export {attr_name!r}"
        )
    return getattr(mod, attr_name)


# ──────────────────────────────────────────────────────────────────────────────
# C1: AssessmentSourceType construction and __str__ (Behavior - boundary cases)
# Contracts: C1
# ──────────────────────────────────────────────────────────────────────────────

def check_assessmentsourcetype_all_valid_types() -> None:
    """
    Verify that all valid source type strings are accepted and produce
    correct uppercase string representations.

    Contracts: C1
    """
    AssessmentSourceType = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSourceType"
    )

    valid_cases = [
        ("SOURCE_TYPE_UNSPECIFIED", "SOURCE_TYPE_UNSPECIFIED"),
        ("source_type_unspecified", "SOURCE_TYPE_UNSPECIFIED"),
        ("LLM_JUDGE", "LLM_JUDGE"),
        ("llm_judge", "LLM_JUDGE"),
        ("HUMAN", "HUMAN"),
        ("human", "HUMAN"),
        ("Human", "HUMAN"),
        ("CODE", "CODE"),
        ("code", "CODE"),
        ("Code", "CODE"),
    ]

    for input_val, expected in valid_cases:
        instance = AssessmentSourceType(input_val)
        assert str(instance) == expected, (
            f"AssessmentSourceType({input_val!r}) -> {str(instance)!r}, "
            f"expected {expected!r}"
        )

    print("PASS: check_assessmentsourcetype_all_valid_types")


def check_assessmentsourcetype_class_constants() -> None:
    """
    Verify that AssessmentSourceType class constants are accessible
    and have the expected string values.

    Contracts: C1
    """
    AssessmentSourceType = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSourceType"
    )

    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.CODE == "CODE"

    # _SOURCE_TYPES should not include AI_JUDGE (deprecated, separate path)
    assert "AI_JUDGE" not in AssessmentSourceType._SOURCE_TYPES, (
        "AI_JUDGE should not be in _SOURCE_TYPES"
    )

    print("PASS: check_assessmentsourcetype_class_constants")


# ──────────────────────────────────────────────────────────────────────────────
# C2: AI_JUDGE deprecation -> FutureWarning + LLM_JUDGE conversion
# Contracts: C2
# ──────────────────────────────────────────────────────────────────────────────

def check_ai_judge_deprecation_warning() -> None:
    """
    Prove that using "AI_JUDGE" triggers a FutureWarning with the
    exact full deprecation message and converts to "LLM_JUDGE"
    through multiple public paths.

    # Reference: tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning
    # Perspective: P1 — native test uses exact full message match:
    #   pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")

    Contracts: C2
    """
    AssessmentSourceType = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSourceType"
    )
    AssessmentSource = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSource"
    )

    exact_message = "AI_JUDGE is deprecated. Use LLM_JUDGE instead."

    # Path 1: Direct AssessmentSourceType construction
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        instance = AssessmentSourceType("AI_JUDGE")
        assert str(instance) == "LLM_JUDGE", (
            f"AI_JUDGE should convert to LLM_JUDGE, got {str(instance)!r}"
        )
        assert len(w) >= 1, "Expected at least one warning"
        assert any(
            issubclass(warning.category, FutureWarning) for warning in w
        ), f"Expected FutureWarning, got {[type(x).__name__ for x in w]}"
        # F2 repair: exact full message match
        assert any(
            str(warning.message) == exact_message for warning in w
        ), f"Expected exact message '{exact_message}', got {[str(x.message) for x in w]}"

    # Path 2: Through AssessmentSource.__post_init__
    with warnings.catch_warnings(record=True) as w2:
        warnings.simplefilter("always")
        source = AssessmentSource(source_type="AI_JUDGE", source_id="test")
        assert source.source_type == "LLM_JUDGE", (
            f"AssessmentSource should normalize AI_JUDGE to LLM_JUDGE, "
            f"got {source.source_type!r}"
        )
        assert len(w2) >= 1, "Expected at least one warning via AssessmentSource"
        assert any(
            issubclass(warning.category, FutureWarning) for warning in w2
        ), "Expected FutureWarning via AssessmentSource"
        # F2 repair: exact full message match
        assert any(
            str(warning.message) == exact_message for warning in w2
        ), f"Expected exact message '{exact_message}' via AssessmentSource, got {[str(x.message) for x in w2]}"

    # Path 3: Case-insensitive "ai_judge"
    with warnings.catch_warnings(record=True) as w3:
        warnings.simplefilter("always")
        instance2 = AssessmentSourceType("ai_judge")
        assert str(instance2) == "LLM_JUDGE", (
            f"ai_judge should convert to LLM_JUDGE, got {str(instance2)!r}"
        )
        assert len(w3) >= 1, "Expected warning for lowercase ai_judge"
        # F2 repair: exact full message match for case-insensitive
        assert any(
            str(warning.message) == exact_message for warning in w3
        ), f"Expected exact message '{exact_message}' for lowercase ai_judge, got {[str(x.message) for x in w3]}"

    print("PASS: check_ai_judge_deprecation_warning")


def check_ai_judge_not_in_source_types_list() -> None:
    """
    Verify that AI_JUDGE is NOT listed in _SOURCE_TYPES (the list
    used for validation). It is handled as a separate deprecated path.

    Contracts: C2
    """
    AssessmentSourceType = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSourceType"
    )

    assert "AI_JUDGE" not in AssessmentSourceType._SOURCE_TYPES, (
        "AI_JUDGE should not appear in _SOURCE_TYPES"
    )
    assert "LLM_JUDGE" in AssessmentSourceType._SOURCE_TYPES, (
        "LLM_JUDGE should appear in _SOURCE_TYPES"
    )

    print("PASS: check_ai_judge_not_in_source_types_list")


# ──────────────────────────────────────────────────────────────────────────────
# C3: Invalid source type rejection -> MlflowException
# Contracts: C3
# ──────────────────────────────────────────────────────────────────────────────

def check_invalid_source_type_raises_mlflow_exception() -> None:
    """
    Prove that an unrecognized source type raises MlflowException
    with error code INVALID_PARAMETER_VALUE and a message listing
    valid types.

    # Reference: tests/entities/test_assessment_source.py::test_assessment_source_type_validation
    # Perspective: F3 — native test verifies MlflowException with
    #   match="Invalid assessment source type" and INVALID_PARAMETER_VALUE

    Contracts: C3
    """
    AssessmentSourceType = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSourceType"
    )
    AssessmentSource = _safe_import(
        "mlflow.entities.assessment_source", "AssessmentSource"
    )
    MlflowException = _safe_import("mlflow.exceptions", "MlflowException")
    INVALID_PARAMETER_VALUE = _safe_import(
        "mlflow.protos.databricks_pb2", "INVALID_PARAMETER_VALUE"
    )

    # Path 1: Direct AssessmentSourceType construction
    try:
        AssessmentSourceType("ROBOT")
        raise AssertionError("Should have raised MlflowException for 'ROBOT'")
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e), (
            f"Expected 'Invalid assessment source type' in message, got {str(e)!r}"
        )
        # F3 repair: verify error_code
        assert e.error_code == INVALID_PARAMETER_VALUE, (
            f"Expected error_code INVALID_PARAMETER_VALUE, got {e.error_code}"
        )

    # Path 2: Through AssessmentSource.__post_init__
    try:
        AssessmentSource(source_type="INVALID", source_id="test")
        raise AssertionError("Should have raised MlflowException for 'INVALID'")
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e), (
            f"Expected 'Invalid assessment source type' in message, got {str(e)!r}"
        )
        # F3 repair: verify error_code
        assert e.error_code == INVALID_PARAMETER_VALUE, (
            f"Expected error_code INVALID_PARAMETER_VALUE via AssessmentSource, got {e.error_code}"
        )

    # Verify valid types do NOT raise
    valid_source = AssessmentSource(source_type="HUMAN", source_id="test")
    assert valid_source.source_type == "HUMAN"

    print("PASS: check_invalid_source_type_raises_mlflow_exception")


# ──────────────────────────────────────────────────────────────────────────────
# C5: scorer decorator boundary cases (Behavior - boundary)
# Contracts: C5
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_decorator_boundary_cases() -> None:
    """
    Prove boundary behaviors of the scorer decorator:
    - Multiple scorer instances for same function are independent
    - Scorer can be called with different parameter subsets
    - Scorer with @scorer (no parens) and @scorer(name=...) (with parens) both work

    Contracts: C5
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    ScorerKind = _safe_import("mlflow.genai.scorers.base", "ScorerKind")

    # Case 1: @scorer with no parens
    @scorer_fn
    def basic_check(outputs) -> bool:
        return len(outputs) > 0

    assert basic_check.kind == ScorerKind.DECORATOR
    assert basic_check.name == "basic_check"
    assert basic_check(outputs="hello") is True
    assert basic_check(outputs="") is False

    # Case 2: @scorer with custom name
    decorated = scorer_fn(name="custom_func")
    @decorated
    def other_check(outputs) -> bool:
        return bool(outputs)

    assert other_check.kind == ScorerKind.DECORATOR
    assert other_check.name == "custom_func"
    assert other_check(outputs="x") is True

    # Case 3: Multiple scorers are independent
    @scorer_fn
    def first(outputs) -> int:
        return 1

    @scorer_fn
    def second(outputs) -> int:
        return 2

    assert first(outputs="a") == 1
    assert second(outputs="b") == 2
    assert first.name == "first"
    assert second.name == "second"

    print("PASS: check_scorer_decorator_boundary_cases")


# ──────────────────────────────────────────────────────────────────────────────
# C9: scorer deserialization blocked outside Databricks
# Contracts: C9
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_deserialization_blocked_outside_databricks() -> None:
    """
    Prove that _reconstruct_decorator_scorer raises MlflowException
    outside Databricks runtime and that the error message includes
    the properly formatted scorer code snippet.

    # Reference: tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri
    #            tests/genai/scorers/test_scorer.py::test_custom_scorer_error_message_renders_code_snippet_legibly
    # Perspective: P2, P4, F5 — native tests verify error message contains
    #   "Registered scorer code:", "from mlflow.genai import scorer", "@scorer",
    #   and the function definition with proper indentation.

    Contracts: C9
    """
    Scorer = _safe_import("mlflow.genai.scorers.base", "Scorer")
    SerializedScorer = _safe_import("mlflow.genai.scorers.base", "SerializedScorer")
    MlflowException = _safe_import("mlflow.exceptions", "MlflowException")

    # Use realistic malicious source code to stress-test the security gate
    serialized = SerializedScorer(
        name="malicious_scorer",
        call_source="import os\nos.system('echo hacked')\nreturn True",
        call_signature="(outputs)",
        original_func_name="malicious_scorer",
    )

    try:
        Scorer._reconstruct_decorator_scorer(serialized)
        raise AssertionError("Should have raised MlflowException")
    except MlflowException as e:
        error_msg = str(e)

        # Basic blocking check
        assert "not supported" in error_msg, (
            f"Expected 'not supported' in error, got {error_msg!r}"
        )

        # F5 repair: verify code snippet rendering in error message
        assert "Registered scorer code:" in error_msg, (
            f"Expected 'Registered scorer code:' in error, got {error_msg!r}"
        )
        assert "from mlflow.genai import scorer" in error_msg, (
            f"Expected 'from mlflow.genai import scorer' in error, got {error_msg!r}"
        )
        assert "@scorer" in error_msg, (
            f"Expected '@scorer' in error, got {error_msg!r}"
        )
        assert "def malicious_scorer(outputs):" in error_msg, (
            f"Expected 'def malicious_scorer(outputs):' in error, got {error_msg!r}"
        )
        # Verify the code snippet contains the actual source lines
        assert "import os" in error_msg, (
            f"Expected 'import os' in code snippet, got {error_msg!r}"
        )
        assert "return True" in error_msg, (
            f"Expected 'return True' in code snippet, got {error_msg!r}"
        )

    print("PASS: check_scorer_deserialization_blocked_outside_databricks")


def check_scorer_deserialization_blocked_databricks_remote() -> None:
    """
    Prove that even with Databricks URI, loading is blocked when
    not actually inside Databricks runtime, and the error message
    includes the code snippet.

    # Reference: tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_databricks_remote_access
    # Perspective: F5 — error message includes code snippet with @scorer

    Contracts: C9
    """
    Scorer = _safe_import("mlflow.genai.scorers.base", "Scorer")
    SerializedScorer = _safe_import("mlflow.genai.scorers.base", "SerializedScorer")
    MlflowException = _safe_import("mlflow.exceptions", "MlflowException")

    serialized = SerializedScorer(
        name="complex_scorer",
        call_source=(
            "if not outputs:\n"
            "    return 0\n"
            "score = 0\n"
            "for word in outputs.split():\n"
            "    if word.isupper():\n"
            "        score += 2\n"
            "    else:\n"
            "        score += 1\n"
            "return score"
        ),
        call_signature="(outputs)",
        original_func_name="complex_scorer",
    )

    with (
        patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=False),
        patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True),
    ):
        try:
            Scorer._reconstruct_decorator_scorer(serialized)
            raise AssertionError("Should have raised MlflowException")
        except MlflowException as e:
            error_msg = str(e)

            # Remote access message
            assert "via remote access is not supported" in error_msg, (
                f"Expected 'via remote access is not supported', got {error_msg!r}"
            )

            # F5 repair: verify code snippet rendering
            assert "Registered scorer code:" in error_msg, (
                f"Expected 'Registered scorer code:' in error, got {error_msg!r}"
            )
            assert "from mlflow.genai import scorer" in error_msg, (
                f"Expected 'from mlflow.genai import scorer' in error, got {error_msg!r}"
            )
            assert "@scorer" in error_msg, (
                f"Expected '@scorer' in error, got {error_msg!r}"
            )
            assert "def complex_scorer(outputs):" in error_msg, (
                f"Expected 'def complex_scorer(outputs):' in error, got {error_msg!r}"
            )
            # Verify the indented body lines
            assert "    if not outputs:" in error_msg or "if not outputs:" in error_msg, (
                f"Expected function body in code snippet, got {error_msg!r}"
            )
            assert "return score" in error_msg, (
                f"Expected 'return score' in code snippet, got {error_msg!r}"
            )

    print("PASS: check_scorer_deserialization_blocked_databricks_remote")


# ──────────────────────────────────────────────────────────────────────────────
# C10: scorer run rejects unsupported return types
# Contracts: C10
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_run_rejects_unsupported_return_types() -> None:
    """
    Prove that scorer.run() raises MlflowException when the
    decorated function returns unsupported types (e.g., dict, list
    of non-Assessment items).

    Contracts: C10
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    MlflowException = _safe_import("mlflow.exceptions", "MlflowException")

    # Dict return
    @scorer_fn
    def dict_scorer(outputs):
        return {"score": 42}

    try:
        dict_scorer.run(outputs="test")
        raise AssertionError("Should have raised for dict return type")
    except MlflowException as e:
        assert "must return one of" in str(e), (
            f"Expected 'must return one of', got {str(e)!r}"
        )

    # List of non-Feedback items
    @scorer_fn
    def list_bad_scorer(outputs):
        return [1, 2, 3]

    try:
        list_bad_scorer.run(outputs="test")
        raise AssertionError("Should have raised for list of ints")
    except MlflowException as e:
        assert "must return one of" in str(e), (
            f"Expected 'must return one of', got {str(e)!r}"
        )

    # Custom object
    @scorer_fn
    def obj_scorer(outputs):
        return object()

    try:
        obj_scorer.run(outputs="test")
        raise AssertionError("Should have raised for object return type")
    except MlflowException as e:
        assert "must return one of" in str(e), (
            f"Expected 'must return one of', got {str(e)!r}"
        )

    print("PASS: check_scorer_run_rejects_unsupported_return_types")


def check_scorer_run_accepts_supported_return_types() -> None:
    """
    Prove that scorer.run() accepts all documented return types:
    bool, int, float, str, Feedback, list[Feedback].

    Contracts: C10
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    Feedback = _safe_import("mlflow.entities", "Feedback")

    @scorer_fn
    def bool_scorer(outputs) -> bool:
        return True

    @scorer_fn
    def int_scorer(outputs) -> int:
        return 42

    @scorer_fn
    def float_scorer(outputs) -> float:
        return 3.14

    @scorer_fn
    def str_scorer(outputs) -> str:
        return "good"

    @scorer_fn
    def feedback_scorer(outputs) -> Feedback:
        return Feedback(value=True, rationale="ok")

    @scorer_fn
    def feedback_list_scorer(outputs):
        return [Feedback(value=True), Feedback(value=False)]

    assert bool_scorer.run(outputs="test") is True
    assert int_scorer.run(outputs="test") == 42
    assert float_scorer.run(outputs="test") == 3.14
    assert str_scorer.run(outputs="test") == "good"

    fb = feedback_scorer.run(outputs="test")
    assert isinstance(fb, Feedback)
    assert fb.value is True

    fb_list = feedback_list_scorer.run(outputs="test")
    assert isinstance(fb_list, list)
    assert len(fb_list) == 2
    assert all(isinstance(f, Feedback) for f in fb_list)

    print("PASS: check_scorer_run_accepts_supported_return_types")


def check_scorer_run_none_is_accepted() -> None:
    """
    Prove that scorer.run() accepts None as a valid return value
    (representing an empty assessment).

    Contracts: C10
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")

    @scorer_fn
    def conditional_scorer(outputs):
        if not outputs:
            return None
        return len(outputs) > 0

    # None case
    result = conditional_scorer.run(outputs="")
    assert result is None, f"Expected None for empty outputs, got {result!r}"

    # bool case
    result2 = conditional_scorer.run(outputs="hello")
    assert result2 is True, f"Expected True, got {result2!r}"

    print("PASS: check_scorer_run_none_is_accepted")


# ──────────────────────────────────────────────────────────────────────────────
# C11: scorer run feedback name handling
# Contracts: C11
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_run_no_name_rewrite_for_feedback_list() -> None:
    """
    Prove that when a scorer returns a list of Feedback objects,
    the default-feedback-name rewrite is NOT applied (it only
    applies to single Feedback returns).

    Contracts: C11
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    Feedback = _safe_import("mlflow.entities", "Feedback")
    DEFAULT_FEEDBACK_NAME = _safe_import(
        "mlflow.entities.assessment", "DEFAULT_FEEDBACK_NAME"
    )

    @scorer_fn
    def multi_feedback_scorer(inputs, outputs):
        return [
            Feedback(value=True, rationale="first"),
            Feedback(value=False, rationale="second"),
        ]

    results = multi_feedback_scorer.run(
        inputs={"q": "test"},
        outputs="answer",
    )

    assert isinstance(results, list), f"Expected list, got {type(results).__name__}"
    assert len(results) == 2, f"Expected 2 feedbacks, got {len(results)}"

    # For list returns, name rewrite does NOT happen.
    # Each Feedback keeps its default name "feedback".
    for fb in results:
        assert isinstance(fb, Feedback), (
            f"Expected Feedback, got {type(fb).__name__}"
        )
        assert fb.name == DEFAULT_FEEDBACK_NAME, (
            f"List-returned feedback should keep default name "
            f"'{DEFAULT_FEEDBACK_NAME}', got {fb.name!r}"
        )

    print("PASS: check_scorer_run_no_name_rewrite_for_feedback_list")


# ──────────────────────────────────────────────────────────────────────────────
# C13: recreate_function boundary and edge cases
# Contracts: C13
# ──────────────────────────────────────────────────────────────────────────────

def check_recreate_function_boundary_cases() -> None:
    """
    Prove boundary behaviors of recreate_function:
    - Invalid signature format raises MlflowException
    - Empty source code raises SyntaxError
    - Syntax error in source raises SyntaxError

    Contracts: C13
    """
    recreate_function = _safe_import(
        "mlflow.genai.scorers.scorer_utils", "recreate_function"
    )
    MlflowException = _safe_import("mlflow.exceptions", "MlflowException")

    # Invalid signature format
    try:
        recreate_function("return 1", "not_a_signature", "bad_func")
        raise AssertionError("Should have raised for invalid signature")
    except MlflowException as e:
        assert "Invalid signature format" in str(e), (
            f"Expected 'Invalid signature format', got {str(e)!r}"
        )

    # Syntax error in source (missing colon)
    try:
        recreate_function("if x > 0\n    return True", "(x)", "syntax_err")
        raise AssertionError("Should have raised for syntax error")
    except SyntaxError:
        pass  # Expected

    # Empty function body
    try:
        recreate_function("", "(x)", "empty_func")
        raise AssertionError("Should have raised for empty source")
    except SyntaxError:
        pass  # Expected

    print("PASS: check_recreate_function_boundary_cases")


def check_recreate_function_with_mlflow_types() -> None:
    """
    Prove that recreate_function can produce functions that create
    MLflow Feedback objects and use MLflow namespace imports.

    # Reference: tests/genai/scorers/test_scorer_utils.py::test_mlflow_imports_available
    # Perspective: P3 — recreated functions must have Feedback,
    #   AssessmentSourceType, Trace etc. in their execution namespace

    Contracts: C13
    """
    recreate_function = _safe_import(
        "mlflow.genai.scorers.scorer_utils", "recreate_function"
    )
    Feedback = _safe_import("mlflow.entities", "Feedback")

    source = (
        "import re\n"
        "words = re.findall(r'\\b\\w+\\b', text)\n"
        "return Feedback(value=len(words), "
        "rationale=f'Found {len(words)} words')"
    )
    signature = "(text)"
    func_name = "word_counter"

    func = recreate_function(source, signature, func_name)
    result = func("hello world test")
    assert isinstance(result, Feedback), (
        f"Expected Feedback, got {type(result).__name__}"
    )
    assert result.value == 3, f"Expected 3 words, got {result.value}"
    assert "Found 3 words" in result.rationale, (
        f"Expected 'Found 3 words' in rationale, got {result.rationale!r}"
    )

    print("PASS: check_recreate_function_with_mlflow_types")


# ──────────────────────────────────────────────────────────────────────────────
# F4: scorer lifecycle (register/start/stop/update) coverage
# Contracts: C5 (Interface), C9 (Failure boundary)
# ──────────────────────────────────────────────────────────────────────────────

def check_scorer_lifecycle_register_start_stop() -> None:
    """
    Prove the full scorer lifecycle: UNREGISTERED -> STOPPED (after
    register) -> STARTED (after start with sampling config) ->
    STOPPED (after stop). Verify sample_rate, filter_string, and
    status at each step.

    # Reference: tests/genai/scorers/test_scorer_CRUD.py::test_mlflow_backend_scorer_operations
    # Perspective: F4 — native tests walk through register/start/stop/update
    #   and verify ScorerStatus transitions along with sampling config

    Contracts: C5
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    Scorer = _safe_import("mlflow.genai.scorers.base", "Scorer")
    ScorerStatus = _safe_import("mlflow.genai.scorers.base", "ScorerStatus")
    ScorerSamplingConfig = _safe_import(
        "mlflow.genai.scorers.base", "ScorerSamplingConfig"
    )

    import mlflow

    # Create a custom scorer
    @scorer_fn
    def lifecycle_test_scorer(outputs) -> bool:
        return len(outputs) > 0

    # Step 1: Initial state - UNREGISTERED
    assert lifecycle_test_scorer.status == ScorerStatus.UNREGISTERED, (
        f"Expected UNREGISTERED, got {lifecycle_test_scorer.status}"
    )
    assert lifecycle_test_scorer.sample_rate is None, (
        "sample_rate should be None before registration"
    )
    assert lifecycle_test_scorer.filter_string is None, (
        "filter_string should be None before registration"
    )

    # Step 2: Register (requires Databricks runtime mock for decorator scorers)
    experiment_id = mlflow.create_experiment("test_scorer_lifecycle_exp")

    with (
        patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True),
        patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True),
    ):
        registered = lifecycle_test_scorer.register(
            experiment_id=experiment_id, name="lifecycle_scorer"
        )

        # After registration: STOPPED (sample_rate=0)
        assert registered.status == ScorerStatus.STOPPED, (
            f"Expected STOPPED after register, got {registered.status}"
        )
        assert registered._sampling_config is not None, (
            "sampling_config should be set after registration"
        )

        # Step 3: Start with sampling config
        started = registered.start(
            experiment_id=experiment_id,
            sampling_config=ScorerSamplingConfig(
                sample_rate=0.5, filter_string="status='OK'"
            ),
        )

        # After start: STARTED
        assert started.status == ScorerStatus.STARTED, (
            f"Expected STARTED after start, got {started.status}"
        )
        assert started.sample_rate == 0.5, (
            f"Expected sample_rate 0.5, got {started.sample_rate}"
        )
        assert started.filter_string == "status='OK'", (
            f"Expected filter_string 'status=''OK''', got {started.filter_string!r}"
        )

        # Step 4: Stop
        stopped = started.stop(experiment_id=experiment_id)

        # After stop: STOPPED
        assert stopped.status == ScorerStatus.STOPPED, (
            f"Expected STOPPED after stop, got {stopped.status}"
        )
        # stop() sets sample_rate to 0, but the returned scorer from
        # DatabricksStore.update_registered_scorer may carry the server response;
        # locally verify status reflects STOPPED
        assert isinstance(stopped, Scorer), (
            f"Expected Scorer instance after stop, got {type(stopped).__name__}"
        )

    # Clean up
    mlflow.delete_experiment(experiment_id)

    print("PASS: check_scorer_lifecycle_register_start_stop")


def check_scorer_lifecycle_update_with_filter_changes() -> None:
    """
    Prove that update() can change filter_string while keeping
    the scorer active.

    # Reference: tests/genai/scorers/test_scorer_CRUD.py — update changes
    #   filter_string without changing sample_rate

    Contracts: C5
    """
    scorer_fn = _safe_import("mlflow.genai.scorers.base", "scorer")
    ScorerStatus = _safe_import("mlflow.genai.scorers.base", "ScorerStatus")
    ScorerSamplingConfig = _safe_import(
        "mlflow.genai.scorers.base", "ScorerSamplingConfig"
    )

    import mlflow

    @scorer_fn
    def update_test_scorer(outputs) -> bool:
        return len(outputs) > 0

    experiment_id = mlflow.create_experiment("test_scorer_update_exp")

    with (
        patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True),
        patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True),
    ):
        registered = update_test_scorer.register(
            experiment_id=experiment_id, name="update_scorer"
        )
        assert registered.status == ScorerStatus.STOPPED

        # Start with initial filter
        started = registered.start(
            experiment_id=experiment_id,
            sampling_config=ScorerSamplingConfig(
                sample_rate=0.3, filter_string="env='prod'"
            ),
        )
        assert started.status == ScorerStatus.STARTED
        assert started.sample_rate == 0.3
        assert started.filter_string == "env='prod'"

        # Update the filter_string
        updated = started.update(
            experiment_id=experiment_id,
            sampling_config=ScorerSamplingConfig(filter_string="env='staging'"),
        )
        assert isinstance(updated, type(started)), (
            f"Expected same type after update, got {type(updated).__name__}"
        )

    mlflow.delete_experiment(experiment_id)

    print("PASS: check_scorer_lifecycle_update_with_filter_changes")


# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # C1: AssessmentSourceType construction (behavior/boundary)
    check_assessmentsourcetype_all_valid_types()
    check_assessmentsourcetype_class_constants()

    # C2: AI_JUDGE deprecation
    check_ai_judge_deprecation_warning()
    check_ai_judge_not_in_source_types_list()

    # C3: Invalid source type rejection
    check_invalid_source_type_raises_mlflow_exception()

    # C5: scorer decorator boundary
    check_scorer_decorator_boundary_cases()

    # C9: scorer deserialization blocked
    check_scorer_deserialization_blocked_outside_databricks()
    check_scorer_deserialization_blocked_databricks_remote()

    # C10: scorer run return type validation
    check_scorer_run_rejects_unsupported_return_types()
    check_scorer_run_accepts_supported_return_types()
    check_scorer_run_none_is_accepted()

    # C11: scorer run feedback name handling (list boundary)
    check_scorer_run_no_name_rewrite_for_feedback_list()

    # C13: recreate_function behavior
    check_recreate_function_boundary_cases()
    check_recreate_function_with_mlflow_types()

    # F4: scorer lifecycle (register/start/stop/update)
    check_scorer_lifecycle_register_start_stop()
    check_scorer_lifecycle_update_with_filter_changes()
