# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — durable guidance on arch/behavior spec compilation patterns
- Native tests:
  - `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — verifies AI_JUDGE deprecation, invalid type rejection, and source_type normalization through AssessmentSource creation
  - `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` — verifies case-insensitive processing across all valid types
  - `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — verifies FutureWarning emission with exact message match via `pytest.warns`
  - `tests/tracing/test_assessment.py::test_log_feedback_ai_judge_deprecation_warning` — parametrizes both `"AI_JUDGE"` string and `AssessmentSourceType.AI_JUDGE` constant; asserts `source.source_type == AssessmentSourceType.LLM_JUDGE`
  - `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_no_session_id` — asserts `error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)` pattern
  - `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_invalid_session_id` — same error_code assertion pattern
  - `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_success` — verifies constructed filter_string content and delegation to SearchTracesTool
- Semantic IR: `/agent-logs/.../semantic_ir.md` — 12 requirements (R1–R12), 19 contracts (C1–C19)
- Architecture spec: `/agent-logs/.../arch_spec.py` — 11 check functions covering C2, C3, C7, C9, C10, C12, C13, C17, C18, C19
- Behavior spec: `/agent-logs/.../behavior_spec.py` — 15 check functions covering C1, C4, C5, C6, C8, C11, C14, C15, C16 plus boundary cases
- Repository source (full implementation):
  - `/testbed/libs/tracing/mlflow/genai/judges/tools/search_traces.py` — SearchTracesTool, _get_experiment_id, _convert_assessments_to_tool_types
  - `/testbed/libs/tracing/mlflow/entities/assessment_source.py` — AssessmentSource, AssessmentSourceType with _parse, _standardize, __init__, __str__
- Repository source (stubs to be filled by student):
  - `/testbed/mlflow/genai/judges/tools/search_traces.py` — abstract stub missing all method bodies
  - `/testbed/mlflow/entities/assessment_source.py` — stub missing _parse, __init__, __str__, _standardize

## Rubric
- Requirement coverage: 1 — Most L1 obligations (R1–R12) have at least one spec function, but R6/C8 error_code is unverified and R5/C6-extension omits error_code check; R10 backward-compatibility constant (`AssessmentSourceType.AI_JUDGE`) is untested as a class attribute
- Caller binding / call chain: 1 — C2/C3 test invoke→search_traces dataflow through spy; C18 tests GetTracesInSession→SearchTracesTool delegation with argument forwarding; but C7 tests _get_experiment_id directly rather than through invoke, and C9/C10 test _convert_assessments_to_tool_types as isolated helpers
- Dataflow / state / lifecycle: 2 — C1 verifies full field population through invoke; C9/C10 verify field-by-field mapping; C17 verifies AssessmentSource.__post_init__ standardization; mixed-type ordering preserved in boundary test
- Failure / compatibility boundaries: 1 — C4/C5/C6 test all three _get_experiment_id failure modes with message and error_code, but C6-extension (mlflow_experiment=None) omits error_code, and C8 omits error_code entirely; no test for _get_experiment_id when trace.info itself is malformed

## Derived Practical Test Perspectives
- P1: `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_no_session_id` — the native test ecosystem consistently asserts `error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)` on every MlflowException-raising path. The generated specs must apply this pattern uniformly to all MlflowException assertions (C4, C5, C6, C6-extension, C8, C16).
- P2: `tests/tracing/test_assessment.py::test_log_feedback_ai_judge_deprecation_warning` — parametrizes both `"AI_JUDGE"` string literal and `AssessmentSourceType.AI_JUDGE` class constant. The generated specs must verify the class constant exists as a first-class backward-compatibility artifact, not just test string input paths.
- P3: `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` — tests all case variants across all types. The generated deprecation test (C15) already covers lowercase `"ai_judge"` but the class-constant check in C19 does not include `AI_JUDGE`.

## Final Rubric Scores
- Requirement coverage: 1 — R6 error_code unverified; R5/C6-extension missing error_code; R10 backward-compat constant untested
- Caller binding / call chain: 1 — C7 is direct helper test rather than invoke-through-spy; C9/C10 are isolated; C2/C3/C18 are good caller-binding tests
- Dataflow / state / lifecycle: 2 — strong field-level assertions for conversion, defaults, and ordering
- Failure / compatibility boundaries: 1 — C8 and C6-extension lack error_code assertions; consistent error_code pattern broken across the spec
- P1: 1 — error_code asserted on C4/C5/C6 but missing on C6-extension and C8
- P2: 1 — AI_JUDGE string is tested but class constant `AssessmentSourceType.AI_JUDGE` is not verified in arch_spec C19
- P3: 2 — C15 already covers lowercase `"ai_judge"` deprecation; case normalization is well tested in C14

## Findings
- ### F1: weak_constraint
  - Requirement/IR: R6 / C8
  - Evidence: Task interface description `SearchTracesTool.invoke` says "Raises: MlflowException … The search operation fails due to invalid filter syntax or other errors"; implementation at `libs/tracing/mlflow/genai/judges/tools/search_traces.py:250` sets `error_code="INTERNAL_ERROR"`; native test pattern at `test_judge_tool_get_traces_in_session.py:138` asserts `error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)`
  - Gap: `check_invoke_wraps_search_errors` only asserts message substrings `"Failed to search traces"` and `"Search backend unavailable"`. It does not import `INTERNAL_ERROR` or assert `error_code`. A plausible wrong implementation that sets `error_code=None` or `error_code="BAD_GATEWAY"` would pass.
  - Repair: Add `from mlflow.protos.databricks_pb2 import INTERNAL_ERROR, ErrorCode` and assert `exc_info.value.error_code in (INTERNAL_ERROR, ErrorCode.Name(INTERNAL_ERROR))` or, since the implementation uses a string `"INTERNAL_ERROR"`, assert `str(exc_info.value.error_code) == "INTERNAL_ERROR"` (matching the current codebase convention where search_traces uses a bare string).

- ### F2: weak_constraint
  - Requirement/IR: R5 / C6 (extension)
  - Evidence: IR C6 specifies error_code `INVALID_PARAMETER_VALUE`; native test pattern at `test_judge_tool_get_traces_in_session.py:138,148` asserts `error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)`; the sibling checks C4, C5, and C6 in behavior_spec all assert error_code.
  - Gap: `check_get_experiment_id_raises_on_none_mlflow_experiment` (labeled "C6 extension") only asserts message content `"no experiment_id"` but does not import `INVALID_PARAMETER_VALUE` or `ErrorCode` and does not assert `error_code`. This breaks the consistent pattern set by the other three `_get_experiment_id` failure tests.
  - Repair: Add `from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, ErrorCode` and assert `exc_info.value.error_code in (INVALID_PARAMETER_VALUE, ErrorCode.Name(INVALID_PARAMETER_VALUE))`.

- ### F3: missing_requirement
  - Requirement/IR: R10 / C19
  - Evidence: Task emphasizes "backward compatibility for legacy values" and "Handle case-insensitive input standardization and deprecated value migration with warnings"; native test `test_log_feedback_ai_judge_deprecation_warning` parametrizes with `["AI_JUDGE", AssessmentSourceType.AI_JUDGE]` — the constant is a supported entry point; `arch_spec.py` C19 verifies `AssessmentSourceType.HUMAN`, `LLM_JUDGE`, `CODE`, `SOURCE_TYPE_UNSPECIFIED` as class constants but omits `AI_JUDGE`.
  - Gap: `check_assessment_source_type_instance_and_str` never asserts `AssessmentSourceType.AI_JUDGE == "AI_JUDGE"`. A student implementation that defines `_parse` and `_standardize` but forgets the `AI_JUDGE` class-level constant would still pass all current specs, yet break callers that reference `AssessmentSourceType.AI_JUDGE` directly (as shown in the native test).
  - Repair: Add `assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"` to `check_assessment_source_type_instance_and_str` in `arch_spec.py`, alongside the existing constant assertions for `HUMAN`, `LLM_JUDGE`, `CODE`, and `SOURCE_TYPE_UNSPECIFIED`.

## Rework Instructions
1. **Strengthen C8 (behavior_spec.py):** In `check_invoke_wraps_search_errors`, after catching `MlflowException`, import `INTERNAL_ERROR` and `ErrorCode` from `mlflow.protos.databricks_pb2` and assert `exc_info.value.error_code == "INTERNAL_ERROR"` (matching the implementation's string error_code convention from `search_traces.py:250`). This closes the highest-risk gap: the only search-error path in the entire tool.
2. **Strengthen C6-extension (behavior_spec.py):** In `check_get_experiment_id_raises_on_none_mlflow_experiment`, add the same `error_code` assertion pattern used in the sibling checks C4/C5/C6: `assert exc_info.value.error_code in (INVALID_PARAMETER_VALUE, ErrorCode.Name(INVALID_PARAMETER_VALUE))`.
3. **Add AI_JUDGE constant verification (arch_spec.py):** In `check_assessment_source_type_instance_and_str`, add `assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"` to verify the legacy backward-compatibility constant exists on the class. This ensures the deprecation entry point works both as a string literal and as a class attribute reference, matching native test practice.
