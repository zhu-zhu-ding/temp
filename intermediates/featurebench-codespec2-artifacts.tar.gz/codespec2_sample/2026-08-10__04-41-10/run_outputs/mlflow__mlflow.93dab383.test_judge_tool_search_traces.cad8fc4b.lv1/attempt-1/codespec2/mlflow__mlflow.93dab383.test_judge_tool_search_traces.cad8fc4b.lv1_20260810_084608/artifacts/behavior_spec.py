"""
Executable behavior spec for SearchTracesTool and AssessmentSourceType.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility contracts.
Each check_* function maps to one or more contract IDs from the semantic IR.
"""

import logging
import warnings
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Contracts: C1 — SearchTracesTool.invoke returns list[JudgeToolTraceInfo]
# ---------------------------------------------------------------------------
def check_invoke_returns_list_of_judge_tool_trace_info() -> None:
    """invoke returns a list of JudgeToolTraceInfo with correct field population."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-beh-001"),
    )
    ti = TraceInfo(
        trace_id="trace-beh-001",
        trace_location=tl,
        request_time=5000,
        state=TraceState.OK,
        execution_duration=300,
        assessments=[],
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    # Build a mock search_traces return that looks like real Trace objects
    mock_trace_obj = MagicMock()
    mock_trace_obj.info.trace_id = "found-trace-1"
    mock_trace_obj.info.request_time = 1000
    mock_trace_obj.info.state = TraceState.OK
    mock_trace_obj.info.execution_duration = 150
    mock_trace_obj.info.assessments = []
    mock_trace_obj.data.request = '{"q": "hello"}'
    mock_trace_obj.data.response = '{"a": "hi"}'

    tool = SearchTracesTool()

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = [mock_trace_obj]
        result = tool.invoke(trace)

    assert isinstance(result, list), f"Expected list, got {type(result)}"
    assert len(result) == 1
    info = result[0]
    assert isinstance(info, JudgeToolTraceInfo)
    assert info.trace_id == "found-trace-1"
    assert info.request_time == 1000
    assert info.state == TraceState.OK
    assert info.request == '{"q": "hello"}'
    assert info.response == '{"a": "hi"}'
    assert info.execution_duration == 150
    assert isinstance(info.assessments, list)

    print("PASS: check_invoke_returns_list_of_judge_tool_trace_info")


# ---------------------------------------------------------------------------
# Contracts: C1 extension — invoke with explicit filter, order_by, max_results
# ---------------------------------------------------------------------------
def check_invoke_passes_all_arguments_to_search_traces() -> None:
    """invoke forwards filter_string, order_by, max_results to mlflow.search_traces."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-args"),
    )
    ti = TraceInfo(
        trace_id="trace-args",
        trace_location=tl,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    tool = SearchTracesTool()

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        tool.invoke(
            trace,
            filter_string='status = "OK"',
            order_by=["timestamp DESC"],
            max_results=50,
        )

    call_kwargs = mock_search.call_args.kwargs
    assert call_kwargs["filter_string"] == 'status = "OK"'
    assert call_kwargs["order_by"] == ["timestamp DESC"]
    assert call_kwargs["max_results"] == 50
    assert call_kwargs["return_type"] == "list"
    assert call_kwargs["locations"] == ["exp-args"]

    print("PASS: check_invoke_passes_all_arguments_to_search_traces")


# ---------------------------------------------------------------------------
# Contracts: C4 — _get_experiment_id raises on missing trace_location
# ---------------------------------------------------------------------------
def check_get_experiment_id_raises_on_missing_trace_location() -> None:
    """Raises MlflowException with INVALID_PARAMETER_VALUE when trace_location is None."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_state import TraceState
    from mlflow.exceptions import MlflowException
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    ti = TraceInfo(
        trace_id="bad-trace",
        trace_location=None,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    with pytest.raises(MlflowException) as exc_info:
        _get_experiment_id(trace)

    assert "no trace location" in str(exc_info.value).lower()
    # INVALID_PARAMETER_VALUE error code
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    from mlflow.protos.databricks_pb2 import ErrorCode
    assert exc_info.value.error_code in (
        INVALID_PARAMETER_VALUE,
        ErrorCode.Name(INVALID_PARAMETER_VALUE),
    )

    print("PASS: check_get_experiment_id_raises_on_missing_trace_location")


# ---------------------------------------------------------------------------
# Contracts: C5 — _get_experiment_id raises on non-MLFLOW_EXPERIMENT type
# ---------------------------------------------------------------------------
def check_get_experiment_id_raises_on_non_experiment_type() -> None:
    """Raises MlflowException when trace location type is not MLFLOW_EXPERIMENT."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.exceptions import MlflowException
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    tl = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="catalog.schema.table"),
    )
    ti = TraceInfo(
        trace_id="inference-trace",
        trace_location=tl,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    with pytest.raises(MlflowException) as exc_info:
        _get_experiment_id(trace)

    assert "not from an mlflow experiment" in str(exc_info.value).lower()

    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    from mlflow.protos.databricks_pb2 import ErrorCode
    assert exc_info.value.error_code in (
        INVALID_PARAMETER_VALUE,
        ErrorCode.Name(INVALID_PARAMETER_VALUE),
    )

    print("PASS: check_get_experiment_id_raises_on_non_experiment_type")


# ---------------------------------------------------------------------------
# Contracts: C6 — _get_experiment_id raises on missing experiment_id
# ---------------------------------------------------------------------------
def check_get_experiment_id_raises_on_missing_experiment_id() -> None:
    """Raises MlflowException when mlflow_experiment has no experiment_id."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.exceptions import MlflowException
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    # mlflow_experiment present but experiment_id is empty/falsy
    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id=""),
    )
    ti = TraceInfo(
        trace_id="no-exp-id",
        trace_location=tl,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    with pytest.raises(MlflowException) as exc_info:
        _get_experiment_id(trace)

    assert "no experiment_id" in str(exc_info.value).lower()

    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    from mlflow.protos.databricks_pb2 import ErrorCode
    assert exc_info.value.error_code in (
        INVALID_PARAMETER_VALUE,
        ErrorCode.Name(INVALID_PARAMETER_VALUE),
    )

    print("PASS: check_get_experiment_id_raises_on_missing_experiment_id")


# ---------------------------------------------------------------------------
# Contracts: C6 extension — mlflow_experiment is None with MLFLOW_EXPERIMENT type
# ---------------------------------------------------------------------------
def check_get_experiment_id_raises_on_none_mlflow_experiment() -> None:
    """Raises MlflowException when type is MLFLOW_EXPERIMENT but mlflow_experiment is None."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.exceptions import MlflowException
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=None,
    )
    ti = TraceInfo(
        trace_id="no-mlflow-exp",
        trace_location=tl,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    with pytest.raises(MlflowException) as exc_info:
        _get_experiment_id(trace)

    assert "no experiment_id" in str(exc_info.value).lower()
    # INVALID_PARAMETER_VALUE error code
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE as _IPV_C6E
    from mlflow.protos.databricks_pb2 import ErrorCode as _EC_C6E
    assert exc_info.value.error_code in (
        _IPV_C6E,
        _EC_C6E.Name(_IPV_C6E),
    )

    print("PASS: check_get_experiment_id_raises_on_none_mlflow_experiment")


# ---------------------------------------------------------------------------
# Contracts: C8 — invoke wraps search errors as MlflowException
# ---------------------------------------------------------------------------
def check_invoke_wraps_search_errors() -> None:
    """When mlflow.search_traces raises, invoke wraps it in MlflowException."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.exceptions import MlflowException
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-err"),
    )
    ti = TraceInfo(
        trace_id="trace-err",
        trace_location=tl,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    tool = SearchTracesTool()

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.side_effect = RuntimeError("Search backend unavailable")
        with pytest.raises(MlflowException) as exc_info:
            tool.invoke(trace, filter_string="INVALID SYNTAX !!!")

    assert "Failed to search traces" in str(exc_info.value)
    assert "Search backend unavailable" in str(exc_info.value)
    # INTERNAL_ERROR error code (implementation uses string "INTERNAL_ERROR")
    from mlflow.protos.databricks_pb2 import INTERNAL_ERROR as _IE_C8
    from mlflow.protos.databricks_pb2 import ErrorCode as _EC_C8
    assert exc_info.value.error_code in (
        _IE_C8,
        _EC_C8.Name(_IE_C8),
    )

    print("PASS: check_invoke_wraps_search_errors")


# ---------------------------------------------------------------------------
# Contracts: C11 — invoke logs warning and skips failed trace conversions
# ---------------------------------------------------------------------------
def check_invoke_logs_warning_and_skips_failed_conversions() -> None:
    """When one trace fails conversion, it's logged and skipped, not aborting."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-warn"),
    )
    ti = TraceInfo(
        trace_id="trace-warn",
        trace_location=tl,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    # Create two mock trace objects: one good, one bad
    good_trace = MagicMock()
    good_trace.info.trace_id = "good-trace"
    good_trace.info.request_time = 1000
    good_trace.info.state = TraceState.OK
    good_trace.info.execution_duration = 100
    good_trace.info.assessments = []
    good_trace.data.request = "req1"
    good_trace.data.response = "resp1"

    bad_trace = MagicMock()
    bad_trace.info.trace_id = "bad-trace"
    # Accessing data.request will raise an AttributeError
    bad_trace.data.request = None
    bad_trace.data.response = None
    # Make execution_duration access raise
    type(bad_trace.info).execution_duration = property(lambda self: (_ for _ in ()).throw(
        AttributeError("No such field")
    ))

    tool = SearchTracesTool()

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = [bad_trace, good_trace]

        with patch(
            "mlflow.genai.judges.tools.search_traces._logger"
        ) as mock_logger:
            result = tool.invoke(trace)

    # Should still return the good trace
    assert len(result) == 1, f"Expected 1 result, got {len(result)}"
    assert isinstance(result[0], JudgeToolTraceInfo)
    assert result[0].trace_id == "good-trace"

    # Warning should have been logged for the bad trace
    mock_logger.warning.assert_called_once()
    warning_msg = mock_logger.warning.call_args.args[0]
    assert "Failed to process trace" in warning_msg
    assert "bad-trace" in warning_msg

    print("PASS: check_invoke_logs_warning_and_skips_failed_conversions")


# ---------------------------------------------------------------------------
# Contracts: C14 — AssessmentSourceType._standardize normalizes case
# ---------------------------------------------------------------------------
def check_standardize_normalizes_case() -> None:
    """_standardize converts to uppercase regardless of input casing."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("Human") == "HUMAN"
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("LlM_JuDgE") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("code") == "CODE"
    assert AssessmentSourceType._standardize("CODE") == "CODE"
    assert AssessmentSourceType._standardize("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"

    print("PASS: check_standardize_normalizes_case")


# ---------------------------------------------------------------------------
# Contracts: C15 — AssessmentSourceType._standardize deprecates AI_JUDGE
# ---------------------------------------------------------------------------
def check_standardize_deprecates_ai_judge() -> None:
    """_standardize issues FutureWarning and remaps AI_JUDGE to LLM_JUDGE."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        assert result == "LLM_JUDGE", f"Expected 'LLM_JUDGE', got {result!r}"
        assert len(w) == 1
        assert issubclass(w[0].category, FutureWarning)
        assert "AI_JUDGE is deprecated" in str(w[0].message)
        assert "LLM_JUDGE" in str(w[0].message)

    # Also test lowercase
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("ai_judge")
        assert result == "LLM_JUDGE"
        assert len(w) == 1
        assert issubclass(w[0].category, FutureWarning)

    print("PASS: check_standardize_deprecates_ai_judge")


# ---------------------------------------------------------------------------
# Contracts: C16 — AssessmentSourceType._standardize raises on invalid type
# ---------------------------------------------------------------------------
def check_standardize_raises_on_invalid_type() -> None:
    """_standardize raises MlflowException for unrecognized source types."""
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    with pytest.raises(MlflowException) as exc_info:
        AssessmentSourceType._standardize("INVALID")

    assert "Invalid assessment source type" in str(exc_info.value)
    assert "INVALID" in str(exc_info.value)

    # Also test other invalid values
    with pytest.raises(MlflowException) as exc_info:
        AssessmentSourceType._standardize("ROBOT")

    assert "Invalid assessment source type" in str(exc_info.value)

    with pytest.raises(MlflowException) as exc_info:
        AssessmentSourceType._standardize("")

    assert "Invalid assessment source type" in str(exc_info.value)

    print("PASS: check_standardize_raises_on_invalid_type")


# ---------------------------------------------------------------------------
# Contracts: C11 extension — empty search result returns empty list cleanly
# ---------------------------------------------------------------------------
def check_invoke_empty_result_returns_empty_list() -> None:
    """When search_traces returns [], invoke returns []."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-empty"),
    )
    ti = TraceInfo(
        trace_id="trace-empty",
        trace_location=tl,
        request_time=100,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    tool = SearchTracesTool()

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        result = tool.invoke(trace)

    assert result == []
    assert len(result) == 0

    print("PASS: check_invoke_empty_result_returns_empty_list")


# ---------------------------------------------------------------------------
# Boundary: AssessmentSource defaults source_id to "default"
# ---------------------------------------------------------------------------
def check_assessment_source_default_source_id() -> None:
    """AssessmentSource defaults source_id to 'default' when not provided."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="HUMAN")
    assert source.source_id == "default", (
        f"Expected 'default', got {source.source_id!r}"
    )

    # Custom source_id still works
    source2 = AssessmentSource(source_type="CODE", source_id="my-script")
    assert source2.source_id == "my-script"

    print("PASS: check_assessment_source_default_source_id")


# ---------------------------------------------------------------------------
# Boundary: _convert_assessments_to_tool_types with mixed types
# ---------------------------------------------------------------------------
def check_convert_assessments_mixed_types_maintains_order() -> None:
    """Mixed Expectation and Feedback preserve input order."""
    from mlflow.entities.assessment import Expectation, ExpectationValue, Feedback, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolExpectation, JudgeToolFeedback

    source = AssessmentSource(source_type="HUMAN", source_id="u1")
    exp = Expectation(
        name="e1", source=source, rationale=None, span_id=None,
        assessment_id="a1", value="val1",
    )
    fb = Feedback(
        name="f1", source=source, rationale=None, span_id=None,
        assessment_id="a2", value=0.5, error=None, overrides=None, valid=None,
    )
    exp2 = Expectation(
        name="e2", source=source, rationale=None, span_id=None,
        assessment_id="a3", value="val3",
    )

    result = _convert_assessments_to_tool_types([exp, fb, exp2])
    assert len(result) == 3
    assert isinstance(result[0], JudgeToolExpectation)
    assert result[0].name == "e1"
    assert isinstance(result[1], JudgeToolFeedback)
    assert result[1].name == "f1"
    assert isinstance(result[2], JudgeToolExpectation)
    assert result[2].name == "e2"

    print("PASS: check_convert_assessments_mixed_types_maintains_order")


# ---------------------------------------------------------------------------
# Boundary: _convert_assessments_to_tool_types with empty list
# ---------------------------------------------------------------------------
def check_convert_assessments_empty_list_returns_empty() -> None:
    """Empty assessments list returns empty list."""
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types

    result = _convert_assessments_to_tool_types([])
    assert result == []
    assert isinstance(result, list)

    print("PASS: check_convert_assessments_empty_list_returns_empty")


# ---------------------------------------------------------------------------
# Run all checks
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    check_invoke_returns_list_of_judge_tool_trace_info()
    check_invoke_passes_all_arguments_to_search_traces()
    check_get_experiment_id_raises_on_missing_trace_location()
    check_get_experiment_id_raises_on_non_experiment_type()
    check_get_experiment_id_raises_on_missing_experiment_id()
    check_get_experiment_id_raises_on_none_mlflow_experiment()
    check_invoke_wraps_search_errors()
    check_invoke_logs_warning_and_skips_failed_conversions()
    check_standardize_normalizes_case()
    check_standardize_deprecates_ai_judge()
    check_standardize_raises_on_invalid_type()
    check_invoke_empty_result_returns_empty_list()
    check_assessment_source_default_source_id()
    check_convert_assessments_mixed_types_maintains_order()
    check_convert_assessments_empty_list_returns_empty()
    print("\nAll behavior checks passed.")
