"""
Executable architecture spec for SearchTracesTool and AssessmentSourceType.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check_* function maps to one or more contract IDs from the semantic IR.
"""

import warnings
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Contracts: C12 — SearchTracesTool.name returns "_search_traces"
# ---------------------------------------------------------------------------
def check_tool_name_returns_search_traces() -> None:
    """Verify the name property resolves ToolNames._SEARCH_TRACES."""
    from mlflow.genai.judges.tools.constants import ToolNames
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tool = SearchTracesTool()
    assert tool.name == ToolNames._SEARCH_TRACES, (
        f"Expected {ToolNames._SEARCH_TRACES!r}, got {tool.name!r}"
    )
    assert tool.name == "_search_traces"
    print("PASS: check_tool_name_returns_search_traces")


# ---------------------------------------------------------------------------
# Contracts: C13 — get_definition returns valid ToolDefinition
# ---------------------------------------------------------------------------
def check_get_definition_returns_valid_tool_definition() -> None:
    """Verify get_definition returns a ToolDefinition with correct shape."""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.types.llm import ToolDefinition, FunctionToolDefinition, ToolParamsSchema

    tool = SearchTracesTool()
    definition = tool.get_definition()

    # Type checks
    assert isinstance(definition, ToolDefinition), (
        f"Expected ToolDefinition, got {type(definition)}"
    )
    assert definition.type == "function"
    assert isinstance(definition.function, FunctionToolDefinition)

    func = definition.function
    assert func.name == "_search_traces"
    assert isinstance(func.parameters, ToolParamsSchema)
    assert func.parameters.type == "object"

    # No required parameters
    assert func.parameters.required == [] or func.parameters.required is None, (
        f"Expected empty required list, got {func.parameters.required}"
    )

    # Check properties exist with correct types
    props = func.parameters.properties
    assert "filter_string" in props, "Missing filter_string property"
    assert "order_by" in props, "Missing order_by property"
    assert "max_results" in props, "Missing max_results property"

    # filter_string is string type
    assert props["filter_string"].type == "string", (
        f"Expected 'string', got {props['filter_string'].type!r}"
    )

    # order_by is array of strings
    assert props["order_by"].type == "array", (
        f"Expected 'array', got {props['order_by'].type!r}"
    )
    assert props["order_by"].items.type == "string", (
        f"Expected items type 'string', got {props['order_by'].items.type!r}"
    )
    # Default for order_by
    assert props["order_by"].default == ["timestamp ASC"], (
        f"Expected default ['timestamp ASC'], got {props['order_by'].default!r}"
    )

    # max_results is integer with default 20
    assert props["max_results"].type == "integer", (
        f"Expected 'integer', got {props['max_results'].type!r}"
    )
    assert props["max_results"].default == 20, (
        f"Expected default 20, got {props['max_results'].default!r}"
    )

    print("PASS: check_get_definition_returns_valid_tool_definition")


# ---------------------------------------------------------------------------
# Contracts: C2 — invoke defaults order_by to ["timestamp ASC"]
# ---------------------------------------------------------------------------
def check_invoke_defaults_order_by_to_timestamp_asc() -> None:
    """When order_by=None, mlflow.search_traces receives order_by=['timestamp ASC']."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    # Build a valid trace
    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-001"),
    )
    ti = TraceInfo(
        trace_id="trace-001",
        trace_location=tl,
        request_time=1000,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    tool = SearchTracesTool()

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        tool.invoke(trace, filter_string=None, order_by=None, max_results=20)

    # Verify order_by default was applied
    call_kwargs = mock_search.call_args.kwargs
    assert call_kwargs["order_by"] == ["timestamp ASC"], (
        f"Expected order_by=['timestamp ASC'], got {call_kwargs['order_by']!r}"
    )

    print("PASS: check_invoke_defaults_order_by_to_timestamp_asc")


# ---------------------------------------------------------------------------
# Contracts: C3 — invoke defaults max_results to 20
# ---------------------------------------------------------------------------
def check_invoke_defaults_max_results_to_20() -> None:
    """When max_results not provided, mlflow.search_traces receives max_results=20."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-001"),
    )
    ti = TraceInfo(
        trace_id="trace-001",
        trace_location=tl,
        request_time=1000,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    tool = SearchTracesTool()

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        # Use default max_results (not passed explicitly)
        tool.invoke(trace)

    call_kwargs = mock_search.call_args.kwargs
    assert call_kwargs["max_results"] == 20, (
        f"Expected max_results=20, got {call_kwargs['max_results']!r}"
    )

    print("PASS: check_invoke_defaults_max_results_to_20")


# ---------------------------------------------------------------------------
# Contracts: C7 — _get_experiment_id returns experiment_id on valid trace
# ---------------------------------------------------------------------------
def check_get_experiment_id_returns_valid_experiment_id() -> None:
    """_get_experiment_id extracts and returns the experiment_id string."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="test-exp-abc"),
    )
    ti = TraceInfo(
        trace_id="trace-xyz",
        trace_location=tl,
        request_time=2000,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    exp_id = _get_experiment_id(trace)
    assert exp_id == "test-exp-abc", f"Expected 'test-exp-abc', got {exp_id!r}"
    assert isinstance(exp_id, str)

    print("PASS: check_get_experiment_id_returns_valid_experiment_id")


# ---------------------------------------------------------------------------
# Contracts: C9 — _convert_assessments_to_tool_types maps Expectation fields
# ---------------------------------------------------------------------------
def check_convert_assessments_expectation_fields() -> None:
    """Expectation objects are mapped field-by-field to JudgeToolExpectation."""
    from mlflow.entities.assessment import Expectation, ExpectationValue
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolExpectation

    source = AssessmentSource(source_type="HUMAN", source_id="user1")
    exp = Expectation(
        name="expected-answer",
        source=source,
        rationale="The answer should be X",
        span_id="span-001",
        assessment_id="asmt-001",
        value="correct",
    )

    result = _convert_assessments_to_tool_types([exp])
    assert len(result) == 1
    converted = result[0]
    assert isinstance(converted, JudgeToolExpectation)
    assert converted.name == "expected-answer"
    assert converted.source == "HUMAN"
    assert converted.rationale == "The answer should be X"
    assert converted.span_id == "span-001"
    assert converted.assessment_id == "asmt-001"
    assert converted.value == "correct"

    print("PASS: check_convert_assessments_expectation_fields")


# ---------------------------------------------------------------------------
# Contracts: C10 — _convert_assessments_to_tool_types maps Feedback fields
# ---------------------------------------------------------------------------
def check_convert_assessments_feedback_fields() -> None:
    """Feedback objects are mapped to JudgeToolFeedback with error fields."""
    from mlflow.entities.assessment import Feedback, FeedbackValue
    from mlflow.entities.assessment_error import AssessmentError
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolFeedback

    source = AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4")
    fb = Feedback(
        name="quality-score",
        source=source,
        rationale="Good response",
        span_id="span-002",
        assessment_id="asmt-002",
        value=0.95,
        error=None,
        overrides=None,
        valid=True,
    )

    result = _convert_assessments_to_tool_types([fb])
    assert len(result) == 1
    converted = result[0]
    assert isinstance(converted, JudgeToolFeedback)
    assert converted.name == "quality-score"
    assert converted.source == "LLM_JUDGE"
    assert converted.rationale == "Good response"
    assert converted.span_id == "span-002"
    assert converted.assessment_id == "asmt-002"
    assert converted.value == 0.95
    # Error fields are None when assessment.error is None
    assert converted.error_code is None
    assert converted.error_message is None
    assert converted.stack_trace is None
    assert converted.overrides is None
    assert converted.valid is True

    print("PASS: check_convert_assessments_feedback_fields")


# ---------------------------------------------------------------------------
# Contracts: C10 (extended) — Feedback with error populates error fields
# ---------------------------------------------------------------------------
def check_convert_assessments_feedback_with_error_fields() -> None:
    """Feedback with AssessmentError maps error fields correctly."""
    from mlflow.entities.assessment import Feedback, FeedbackValue
    from mlflow.entities.assessment_error import AssessmentError
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolFeedback

    source = AssessmentSource(source_type="CODE", source_id="heuristic")
    error = AssessmentError(
        error_code="E001",
        error_message="Processing failed",
        stack_trace="Traceback...",
    )
    fb = Feedback(
        name="score",
        source=source,
        rationale=None,
        span_id=None,
        assessment_id="asmt-err",
        value=None,
        error=error,
        overrides=None,
        valid=False,
    )

    result = _convert_assessments_to_tool_types([fb])
    assert len(result) == 1
    converted = result[0]
    assert isinstance(converted, JudgeToolFeedback)
    assert converted.error_code == "E001"
    assert converted.error_message == "Processing failed"
    assert converted.stack_trace == "Traceback..."
    assert converted.valid is False

    print("PASS: check_convert_assessments_feedback_with_error_fields")


# ---------------------------------------------------------------------------
# Contracts: C17 — AssessmentSource.__post_init__ calls _standardize
# ---------------------------------------------------------------------------
def check_assessment_source_post_init_standardizes_type() -> None:
    """Creating AssessmentSource with lowercase type standardizes to uppercase."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="llm_judge", source_id="test")
    assert source.source_type == "LLM_JUDGE", (
        f"Expected 'LLM_JUDGE', got {source.source_type!r}"
    )
    assert source.source_id == "test"

    # Also check HUMAN case
    source2 = AssessmentSource(source_type="human", source_id="u1")
    assert source2.source_type == "HUMAN"

    print("PASS: check_assessment_source_post_init_standardizes_type")


# ---------------------------------------------------------------------------
# Contracts: C18 — GetTracesInSession delegates to SearchTracesTool.invoke
# ---------------------------------------------------------------------------
def check_get_traces_in_session_delegates_to_search_traces_tool() -> None:
    """GetTracesInSession.invoke constructs a SearchTracesTool and calls invoke."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.get_traces_in_session import GetTracesInSession
    from mlflow.tracing.constant import TraceMetadataKey

    session_id = "session-abc-123"
    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-001"),
    )
    ti = TraceInfo(
        trace_id="current-trace",
        trace_location=tl,
        request_time=1234567890,
        state=TraceState.OK,
        trace_metadata={TraceMetadataKey.TRACE_SESSION: session_id},
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    tool = GetTracesInSession()

    with patch(
        "mlflow.genai.judges.tools.get_traces_in_session.SearchTracesTool"
    ) as mock_class:
        mock_instance = MagicMock()
        mock_instance.invoke.return_value = []
        mock_class.return_value = mock_instance

        tool.invoke(trace)

    # Verify SearchTracesTool was constructed and invoke called with proper args
    mock_class.assert_called_once()
    mock_instance.invoke.assert_called_once()
    call_kwargs = mock_instance.invoke.call_args.kwargs
    assert call_kwargs["trace"] is trace
    assert "filter_string" in call_kwargs
    filter_str = call_kwargs["filter_string"]
    assert session_id in filter_str
    assert TraceMetadataKey.TRACE_SESSION in filter_str

    print("PASS: check_get_traces_in_session_delegates_to_search_traces_tool")


# ---------------------------------------------------------------------------
# Contracts: C19 — AssessmentSourceType instance creation and string conversion
# ---------------------------------------------------------------------------
def check_assessment_source_type_instance_and_str() -> None:
    """AssessmentSourceType instance validates and str() returns standardized value."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    # Direct constant access
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"  # Backward-compatibility constant
    assert AssessmentSourceType.CODE == "CODE"
    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"

    # Instance creation
    obj = AssessmentSourceType("HUMAN")
    assert str(obj) == "HUMAN"

    obj2 = AssessmentSourceType("llm_judge")
    assert str(obj2) == "LLM_JUDGE"

    # AI_JUDGE with deprecation
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        obj3 = AssessmentSourceType("AI_JUDGE")
        assert str(obj3) == "LLM_JUDGE"
        assert len(w) == 1
        assert issubclass(w[0].category, FutureWarning)
        assert "AI_JUDGE is deprecated" in str(w[0].message)

    print("PASS: check_assessment_source_type_instance_and_str")


# ---------------------------------------------------------------------------
# Run all checks
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    check_tool_name_returns_search_traces()
    check_get_definition_returns_valid_tool_definition()
    check_invoke_defaults_order_by_to_timestamp_asc()
    check_invoke_defaults_max_results_to_20()
    check_get_experiment_id_returns_valid_experiment_id()
    check_convert_assessments_expectation_fields()
    check_convert_assessments_feedback_fields()
    check_convert_assessments_feedback_with_error_fields()
    check_assessment_source_post_init_standardizes_type()
    check_get_traces_in_session_delegates_to_search_traces_tool()
    check_assessment_source_type_instance_and_str()
    print("\nAll architecture checks passed.")
