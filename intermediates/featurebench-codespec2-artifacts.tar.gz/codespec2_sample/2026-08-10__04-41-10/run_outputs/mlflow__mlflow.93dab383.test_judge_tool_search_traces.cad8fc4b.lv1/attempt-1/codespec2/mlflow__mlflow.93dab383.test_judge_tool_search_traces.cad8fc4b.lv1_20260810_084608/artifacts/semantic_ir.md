# Semantic IR

## L1. Requirement Obligations

### R1: Search traces within experiment context
- Type: Behavior
- Statement: Given a Trace with valid MLflow experiment location, `SearchTracesTool.invoke` must retrieve traces from the same experiment using MLflow's `search_traces` API with the provided filter, order, and max_results, and return them as a list of `JudgeToolTraceInfo` objects.
- Task Evidence: "Provide trace search capabilities within MLflow experiments with filtering, ordering, and result pagination"; "Only traces within the same experiment as the input trace can be searched"
- Acceptance: Calling `invoke(trace, filter_string, order_by, max_results)` returns a `list[JudgeToolTraceInfo]` where each entry has `trace_id`, `request_time`, `state`, `request`, `response`, `execution_duration`, and `assessments`.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke`; `mlflow/tracing/client.py:TracingClient.search_traces`; `mlflow/tracing/fluent.py:search_traces`
- Uncertainty: None

### R2: Default ordering to timestamp ASC
- Type: Dataflow
- Statement: When `order_by` is None, the invoke method must default to `["timestamp ASC"]` for chronological ordering.
- Task Evidence: "order_by: Optional list of order by expressions for sorting results. Defaults to ['timestamp ASC'] for chronological ordering if None."
- Acceptance: Calling `invoke(trace)` with no `order_by` arg results in `mlflow.search_traces` being called with `order_by=["timestamp ASC"]`.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:219-220`
- Uncertainty: None

### R3: Default max_results to 20
- Type: Dataflow
- Statement: When `max_results` is not specified, the invoke method must default to 20.
- Task Evidence: "max_results: Maximum number of traces to return. Must be a positive integer. Defaults to 20 to prevent excessive memory usage."
- Acceptance: Calling `invoke(trace)` with no `max_results` arg results in `mlflow.search_traces` being called with `max_results=20`.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:218`
- Uncertainty: None

### R4: Graceful per-trace conversion error handling
- Type: Failure
- Statement: If an individual trace fails to convert to `JudgeToolTraceInfo` during result processing, it must be logged as a warning and skipped, rather than aborting the entire search.
- Task Evidence: "Traces that fail to process during retrieval are logged as warnings and skipped"
- Acceptance: When one trace in the result set raises during conversion, a warning is logged and remaining traces are still processed and returned.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:256-260`
- Uncertainty: None

### R5: Validate experiment context and raise MlflowException on missing data
- Type: Failure
- Statement: The `_get_experiment_id` function must raise `MlflowException` with `INVALID_PARAMETER_VALUE` when: (a) the trace has no `trace_location`, (b) the location type is not `MLFLOW_EXPERIMENT`, or (c) the trace has no `experiment_id`.
- Task Evidence: "Raises: MlflowException: - The provided trace has no trace location information, - The trace is not from an MLflow experiment context, - The trace has no associated experiment_id"
- Acceptance: Each invalid condition raises `MlflowException` with distinct error messages and `INVALID_PARAMETER_VALUE` error code.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:69-98`; `mlflow/entities/trace_location.py:TraceLocationType.MLFLOW_EXPERIMENT`
- Uncertainty: None

### R6: Wrap search errors as MlflowException
- Type: Failure
- Statement: If `mlflow.search_traces` raises any exception, it must be caught and re-raised as `MlflowException` with error code `INTERNAL_ERROR`.
- Task Evidence: "The search operation fails due to invalid filter syntax or other errors"
- Acceptance: A failing `mlflow.search_traces` call produces an `MlflowException` with the original error message included.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:234-238`
- Uncertainty: None

### R7: Tool name constant returns _SEARCH_TRACES
- Type: Interface
- Statement: The `name` property must return `ToolNames._SEARCH_TRACES`.
- Task Evidence: "name: The tool name from ToolNames._SEARCH_TRACES"
- Acceptance: `SearchTracesTool().name == "_search_traces"`.
- Repository Evidence: `mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:121`
- Uncertainty: None

### R8: Tool definition exposes filter_string, order_by, max_results parameters
- Type: Interface
- Statement: `get_definition` must return a `ToolDefinition` with a `FunctionToolDefinition` containing `name="_search_traces"`, three optional parameters (`filter_string` as string, `order_by` as array of strings with default `["timestamp ASC"]`, `max_results` as integer with default 20), and no required parameters.
- Task Evidence: "parameters: ToolParamsSchema defining three optional parameters: filter_string, order_by, max_results"
- Acceptance: `definition.function.parameters.properties` contains `filter_string`, `order_by`, `max_results` with correct types and defaults; `definition.function.parameters.required` is empty.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:124-207`; `mlflow/types/llm.py:ToolDefinition, FunctionToolDefinition, ToolParamsSchema`
- Uncertainty: None

### R9: Convert Assessment objects to judge tool types
- Type: Behavior
- Statement: `_convert_assessments_to_tool_types` must convert each `Expectation` to `JudgeToolExpectation` (with name, source, rationale, span_id, assessment_id, value) and each `Feedback` to `JudgeToolFeedback` (with additional error_code, error_message, stack_trace, overrides, valid fields).
- Task Evidence: "Convert MLflow Assessment objects to their corresponding judge tool type representations"; "Error fields in JudgeToolFeedback are set to None if the original Feedback object has no associated error"
- Acceptance: Given `[Expectation(...), Feedback(...)]`, returns `[JudgeToolExpectation(...), JudgeToolFeedback(...)]` with all fields mapped correctly and error fields as None when absent.
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:34-65`; `mlflow/entities/assessment.py:Expectation, Feedback`; `mlflow/genai/judges/tools/types.py:JudgeToolExpectation, JudgeToolFeedback`
- Uncertainty: None

### R10: Assessment source type standardization with case-insensitive and deprecation handling
- Type: Behavior
- Statement: `AssessmentSourceType._standardize` must convert input to uppercase, issue `FutureWarning` and remap `AI_JUDGE` to `LLM_JUDGE`, validate against `_SOURCE_TYPES`, and raise `MlflowException` for invalid values.
- Task Evidence: "Case-insensitive string inputs (converts to uppercase)"; "Deprecation warnings for legacy values (AI_JUDGE → LLM_JUDGE)"; "Validation of source type values"
- Acceptance: `_standardize("human")` returns `"HUMAN"`; `_standardize("AI_JUDGE")` emits `FutureWarning` and returns `"LLM_JUDGE"`; `_standardize("INVALID")` raises `MlflowException`.
- Repository Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize, _parse, __init__, __str__`; `mlflow/entities/assessment_source.py:AssessmentSourceType constants`
- Uncertainty: None

### R11: AssessmentSourceType supports instance creation with string validation
- Type: Interface
- Statement: `AssessmentSourceType(source_type_str)` must create an instance that validates and standardizes the source type string via `_parse`.
- Task Evidence: "Supports both direct constant access and instance creation with string validation"; "String input - case insensitive"
- Acceptance: `str(AssessmentSourceType("HUMAN")) == "HUMAN"`; `str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"`.
- Repository Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType.__init__, __str__`
- Uncertainty: None

### R12: GetTracesInSession delegates to SearchTracesTool
- Type: Dataflow
- Statement: `GetTracesInSession.invoke` extracts the session ID from trace metadata, constructs a filter string combining session ID and timestamp condition, and delegates to `SearchTracesTool().invoke()`.
- Task Evidence: Repository evidence shows `GetTracesInSession` imports and calls `SearchTracesTool`.
- Acceptance: `GetTracesInSession().invoke(trace)` internally constructs a `SearchTracesTool` instance and calls `invoke` with a filter string containing session ID and timestamp comparison.
- Repository Evidence: `mlflow/genai/judges/tools/get_traces_in_session.py:89-92`; `tests/genai/judges/test_judge_tool_get_traces_in_session.py:test_get_traces_in_session_tool_invoke_success`
- Uncertainty: None

## L2. Functional Design Graph

### N1: SearchTracesTool
- Kind: Class
- Repository Evidence: `mlflow/genai/judges/tools/search_traces.py:SearchTracesTool`; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool`

### N2: SearchTracesTool.name
- Kind: Method (property)
- Repository Evidence: `mlflow/genai/judges/tools/base.py:JudgeTool.name` (abstract); `libs/tracing/mlflow/genai/judges/tools/search_traces.py:118-120`

### N3: SearchTracesTool.get_definition
- Kind: Method
- Repository Evidence: `mlflow/genai/judges/tools/base.py:JudgeTool.get_definition` (abstract); `libs/tracing/mlflow/genai/judges/tools/search_traces.py:123-207`

### N4: SearchTracesTool.invoke
- Kind: Method
- Repository Evidence: `mlflow/genai/judges/tools/base.py:JudgeTool.invoke` (abstract); `libs/tracing/mlflow/genai/judges/tools/search_traces.py:209-266`

### N5: _convert_assessments_to_tool_types
- Kind: Function
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:34-65`

### N6: _get_experiment_id
- Kind: Function
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:69-98`

### N7: Trace
- Kind: Class (External)
- Repository Evidence: `mlflow/entities/trace.py:Trace`

### N8: Trace.info (TraceInfo)
- Kind: Payload
- Repository Evidence: `mlflow/entities/trace_info.py:TraceInfo`

### N9: TraceLocation
- Kind: Payload
- Repository Evidence: `mlflow/entities/trace_location.py:TraceLocation`

### N10: TraceLocationType
- Kind: State (Enum)
- Repository Evidence: `mlflow/entities/trace_location.py:TraceLocationType`

### N11: MlflowExperimentLocation
- Kind: Payload
- Repository Evidence: `mlflow/entities/trace_location.py:MlflowExperimentLocation`

### N12: mlflow.search_traces
- Kind: Function (External)
- Repository Evidence: `mlflow/tracing/fluent.py:search_traces`; `mlflow/tracking/client.py:MlflowClient.search_traces`

### N13: JudgeToolTraceInfo
- Kind: Payload
- Repository Evidence: `mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`

### N14: JudgeToolExpectation
- Kind: Payload
- Repository Evidence: `mlflow/genai/judges/tools/types.py:JudgeToolExpectation`

### N15: JudgeToolFeedback
- Kind: Payload
- Repository Evidence: `mlflow/genai/judges/tools/types.py:JudgeToolFeedback`

### N16: Expectation
- Kind: Payload
- Repository Evidence: `mlflow/entities/assessment.py:Expectation`

### N17: Feedback
- Kind: Payload
- Repository Evidence: `mlflow/entities/assessment.py:Feedback`

### N18: Assessment
- Kind: Payload
- Repository Evidence: `mlflow/entities/assessment.py:Assessment`

### N19: ToolDefinition / FunctionToolDefinition / ToolParamsSchema
- Kind: Payload
- Repository Evidence: `mlflow/types/llm.py:ToolDefinition, FunctionToolDefinition, ToolParamsSchema`

### N20: ToolNames
- Kind: State (Constants)
- Repository Evidence: `mlflow/genai/judges/tools/constants.py:ToolNames`

### N21: GetTracesInSession
- Kind: Class (Caller)
- Repository Evidence: `mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession`

### N22: AssessmentSourceType
- Kind: Class
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSourceType`; `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType`

### N23: AssessmentSourceType._standardize
- Kind: Method (static)
- Repository Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`

### N24: AssessmentSourceType._parse
- Kind: Method (static)
- Repository Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`

### N25: AssessmentSourceType.__init__
- Kind: Method
- Repository Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType.__init__`

### N26: AssessmentSourceType.__str__
- Kind: Method
- Repository Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType.__str__`

### N27: AssessmentSource
- Kind: Class
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSource`

### N28: AssessmentSource.__post_init__
- Kind: Method
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`

### N29: MlflowException
- Kind: Error
- Repository Evidence: `mlflow/exceptions.py:MlflowException`

### N30: _logger
- Kind: Observer
- Repository Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:_logger`

### E1: GetTracesInSession.invoke -> SearchTracesTool.invoke
- Kind: CALL
- Condition: Always (when GetTracesInSession.invoke is called)
- Transfer: `(trace, filter_string=constructed, order_by, max_results) -> list[JudgeToolTraceInfo]`
- Evidence: `mlflow/genai/judges/tools/get_traces_in_session.py:89-92` imports and calls `SearchTracesTool().invoke(trace=trace, filter_string=filter_string, order_by=order_by, max_results=max_results)`
- Obligations: R12

### E2: SearchTracesTool.invoke -> _get_experiment_id
- Kind: CALL
- Condition: Always (first step of invoke)
- Transfer: `(trace: Trace) -> experiment_id: str`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:219`
- Obligations: R5

### E3: _get_experiment_id -> Trace.info.trace_location
- Kind: DATA
- Condition: Always
- Transfer: Reads `trace.info.trace_location` to access location type and experiment_id
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:83-98`
- Obligations: R5

### E4: _get_experiment_id -> MlflowException (on missing location)
- Kind: CONTROL
- Condition: `trace.info.trace_location` is None/falsy
- Transfer: Raises `MlflowException("Current trace has no trace location...")`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:83-86`
- Obligations: R5

### E5: _get_experiment_id -> MlflowException (on non-MLFLOW_EXPERIMENT)
- Kind: CONTROL
- Condition: `trace.info.trace_location.type != TraceLocationType.MLFLOW_EXPERIMENT`
- Transfer: Raises `MlflowException("Current trace is not from an MLflow experiment...")`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:88-93`
- Obligations: R5

### E6: _get_experiment_id -> MlflowException (on missing experiment_id)
- Kind: CONTROL
- Condition: `trace.info.trace_location.mlflow_experiment` is None or `experiment_id` is falsy
- Transfer: Raises `MlflowException("Current trace has no experiment_id...")`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:95-98`
- Obligations: R5

### E7: SearchTracesTool.invoke -> mlflow.search_traces
- Kind: CALL
- Condition: After successful experiment_id extraction
- Transfer: `(locations=[experiment_id], filter_string, order_by, max_results, return_type="list") -> list[Trace]`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:228-232`
- Obligations: R1, R2, R3

### E8: SearchTracesTool.invoke -> MlflowException (on search failure)
- Kind: CONTROL
- Condition: `mlflow.search_traces` raises any Exception
- Transfer: Catches exception, raises `MlflowException("Failed to search traces: ...")` with `INTERNAL_ERROR`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:234-238`
- Obligations: R6

### E9: SearchTracesTool.invoke -> _convert_assessments_to_tool_types
- Kind: CALL
- Condition: For each trace_obj in search results
- Transfer: `(trace_obj.info.assessments: list[Assessment]) -> list[JudgeToolExpectation | JudgeToolFeedback]`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:264`
- Obligations: R9

### E10: _convert_assessments_to_tool_types -> Expectation/Facebook assessment type check
- Kind: CONTROL
- Condition: `isinstance(assessment, Expectation)` vs `isinstance(assessment, Feedback)`
- Transfer: Branches to create either `JudgeToolExpectation` or `JudgeToolFeedback`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:37-64`
- Obligations: R9

### E11: SearchTracesTool.invoke -> _logger (warning on conversion failure)
- Kind: CONTROL
- Condition: Individual trace conversion raises Exception
- Transfer: Logs warning `"Failed to process trace {trace_id}: {e}"` and continues
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:259-260`
- Obligations: R4

### E12: SearchTracesTool.invoke -> JudgeToolTraceInfo construction
- Kind: DATA
- Condition: Per successful trace
- Transfer: Maps `trace_obj.info.trace_id -> trace_id`, `trace_obj.info.request_time -> request_time`, `trace_obj.info.state -> state`, `trace_obj.data.request -> request`, `trace_obj.data.response -> response`, `trace_obj.info.execution_duration -> execution_duration`, converted assessments -> assessments
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:253-263`
- Obligations: R1

### E13: SearchTracesTool.name -> ToolNames._SEARCH_TRACES
- Kind: DATA
- Condition: Always (property getter)
- Transfer: Returns `ToolNames._SEARCH_TRACES` constant
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:120`
- Obligations: R7

### E14: SearchTracesTool.get_definition -> ToolDefinition construction
- Kind: DATA
- Condition: Always
- Transfer: Constructs `ToolDefinition(function=FunctionToolDefinition(name="_search_traces", description=..., parameters=ToolParamsSchema(properties={...}, required=[])), type="function")`
- Evidence: `libs/tracing/mlflow/genai/judges/tools/search_traces.py:124-207`
- Obligations: R8

### E15: AssessmentSourceType._standardize -> AssessmentSourceType.__init__ -> _parse
- Kind: CALL
- Condition: Always
- Transfer: `(source_type: str) -> standardized: str` via `_parse` then `__str__`
- Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize` delegates to constructor and `str()`
- Obligations: R10, R11

### E16: AssessmentSourceType._parse -> upper casing and deprecation check
- Kind: CONTROL
- Condition: Always converts to uppercase; conditional on `source_type == "AI_JUDGE"`
- Transfer: Normalizes to uppercase; if AI_JUDGE, issues FutureWarning and remaps to LLM_JUDGE; if not in _SOURCE_TYPES, raises MlflowException
- Evidence: `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`
- Obligations: R10

### E17: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
- Kind: CALL
- Condition: Always (during AssessmentSource dataclass initialization)
- Transfer: `self.source_type = AssessmentSourceType._standardize(self.source_type)`
- Evidence: `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`
- Obligations: R10

## L3. Verifiable Contracts

### C1: SearchTracesTool.invoke returns list[JudgeToolTraceInfo] on success
- Type: Behavior
- Subject: N4 (SearchTracesTool.invoke)
- Relation: TYPE_IS
- Expected: Returns `list[JudgeToolTraceInfo]` where each element has non-None `trace_id`, `request_time` (int), `state` (TraceState), and `assessments` (list).
- Evidence: Task evidence R1; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:250-265`; `mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().invoke(trace)` return value type check
- Obligations: R1
- Graph: N4, E7, E9, E12

### C2: SearchTracesTool.invoke defaults order_by to ["timestamp ASC"]
- Type: Dataflow
- Subject: N4 (SearchTracesTool.invoke) -> N12 (mlflow.search_traces)
- Relation: DEFAULTS_TO
- Expected: When `order_by` argument is None, `mlflow.search_traces` is called with `order_by=["timestamp ASC"]`.
- Evidence: Task evidence R2; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:219-220`
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: Argument passed to `mlflow.search_traces` when `order_by=None`
- Obligations: R2
- Graph: N4, N12, E7

### C3: SearchTracesTool.invoke defaults max_results to 20
- Type: Dataflow
- Subject: N4 (SearchTracesTool.invoke) -> N12 (mlflow.search_traces)
- Relation: DEFAULTS_TO
- Expected: When `max_results` argument is not provided (defaults to 20), `mlflow.search_traces` is called with `max_results=20`.
- Evidence: Task evidence R3; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:218`
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: Argument passed to `mlflow.search_traces` when `max_results` uses default
- Obligations: R3
- Graph: N4, N12, E7

### C4: _get_experiment_id raises on missing trace_location
- Type: Failure
- Subject: N6 (_get_experiment_id) -> N29 (MlflowException)
- Relation: RAISES
- Expected: Raises `MlflowException` with message containing "no trace location" and error_code `INVALID_PARAMETER_VALUE`.
- Evidence: Task evidence R5; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:83-86`
- Observe: EXCEPTION
- Target: `_get_experiment_id(trace_without_location)` raises
- Obligations: R5
- Graph: N6, N29, E4

### C5: _get_experiment_id raises on non-MLFLOW_EXPERIMENT type
- Type: Failure
- Subject: N6 (_get_experiment_id) -> N29 (MlflowException)
- Relation: RAISES
- Expected: Raises `MlflowException` with message containing "not from an MLflow experiment" and error_code `INVALID_PARAMETER_VALUE`.
- Evidence: Task evidence R5; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:88-93`
- Observe: EXCEPTION
- Target: `_get_experiment_id(trace_with_inference_table_location)` raises
- Obligations: R5
- Graph: N6, N29, E5

### C6: _get_experiment_id raises on missing experiment_id
- Type: Failure
- Subject: N6 (_get_experiment_id) -> N29 (MlflowException)
- Relation: RAISES
- Expected: Raises `MlflowException` with message containing "no experiment_id" and error_code `INVALID_PARAMETER_VALUE`.
- Evidence: Task evidence R5; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:95-98`
- Observe: EXCEPTION
- Target: `_get_experiment_id(trace_without_experiment_id)` raises
- Obligations: R5
- Graph: N6, N29, E6

### C7: _get_experiment_id returns experiment_id string on valid trace
- Type: Dataflow
- Subject: N6 (_get_experiment_id)
- Relation: EQ
- Expected: Returns `trace.info.trace_location.mlflow_experiment.experiment_id` as a string.
- Evidence: Task evidence R5; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:100`; `mlflow/entities/trace_location.py:MlflowExperimentLocation.experiment_id`
- Observe: RETURN_VALUE
- Target: `_get_experiment_id(trace_with_experiment)` return value
- Obligations: R5
- Graph: N6, N7, N8, N9, N11, E3

### C8: SearchTracesTool.invoke wraps search errors
- Type: Failure
- Subject: N4 (invoke) -> N29 (MlflowException)
- Relation: RAISES
- Expected: When `mlflow.search_traces` raises any exception, an `MlflowException` is raised with message containing "Failed to search traces" and the original error string.
- Evidence: Task evidence R6; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:234-238`
- Observe: EXCEPTION
- Target: `SearchTracesTool().invoke(trace, filter_string="INVALID")` raises when search fails
- Obligations: R6
- Graph: N4, N12, N29, E8

### C9: _convert_assessments_to_tool_types maps Expectation fields
- Type: Dataflow
- Subject: N5 (_convert_assessments_to_tool_types) -> N14 (JudgeToolExpectation)
- Relation: EQ
- Expected: For each Expectation, creates `JudgeToolExpectation(name=assessment.name, source=assessment.source.source_type, rationale=assessment.rationale, span_id=assessment.span_id, assessment_id=assessment.assessment_id, value=assessment.value)`.
- Evidence: Task evidence R9; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:38-47`; `mlflow/genai/judges/tools/types.py:JudgeToolExpectation`
- Observe: RETURN_VALUE
- Target: `_convert_assessments_to_tool_types([Expectation(...)])` returns list containing JudgeToolExpectation with matching fields
- Obligations: R9
- Graph: N5, N14, N16, E10

### C10: _convert_assessments_to_tool_types maps Feedback fields with error handling
- Type: Dataflow
- Subject: N5 (_convert_assessments_to_tool_types) -> N15 (JudgeToolFeedback)
- Relation: EQ
- Expected: For each Feedback, creates `JudgeToolFeedback(name, source, rationale, span_id, assessment_id, value, error_code=None|str, error_message=None|str, stack_trace=None|str, overrides, valid)` where error fields are None if `assessment.error` is None.
- Evidence: Task evidence R9; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:49-64`; `mlflow/genai/judges/tools/types.py:JudgeToolFeedback`
- Observe: RETURN_VALUE
- Target: `_convert_assessments_to_tool_types([Feedback(...)])` returns list with JudgeToolFeedback
- Obligations: R9
- Graph: N5, N15, N17, E10

### C11: SearchTracesTool.invoke logs warning and skips failed trace conversions
- Type: SideEffect
- Subject: N4 (invoke) -> N30 (_logger)
- Relation: CALLS
- Expected: When one trace fails during `JudgeToolTraceInfo` construction, `_logger.warning` is called with message containing "Failed to process trace" and the trace_id, and processing continues to subsequent traces.
- Evidence: Task evidence R4; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:259-260`
- Observe: SIDE_EFFECT
- Target: Log output when trace conversion fails mid-batch
- Obligations: R4
- Graph: N4, N30, E11

### C12: SearchTracesTool.name returns "_search_traces"
- Type: Interface
- Subject: N2 (SearchTracesTool.name)
- Relation: EQ
- Expected: `SearchTracesTool().name == "_search_traces"`.
- Evidence: Task evidence R7; `mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:120`
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().name`
- Obligations: R7
- Graph: N2, N20, E13

### C13: SearchTracesTool.get_definition returns valid ToolDefinition
- Type: Interface
- Subject: N3 (get_definition) -> N19 (ToolDefinition)
- Relation: TYPE_IS
- Expected: Returns `ToolDefinition` with `type="function"`, `function.name="_search_traces"`, `function.parameters.type="object"`, `function.parameters.required=[]`, and properties containing `filter_string` (string), `order_by` (array of strings, default `["timestamp ASC"]`), `max_results` (integer, default 20).
- Evidence: Task evidence R8; `libs/tracing/mlflow/genai/judges/tools/search_traces.py:124-207`
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().get_definition()` return value inspection
- Obligations: R8
- Graph: N3, N19, E14

### C14: AssessmentSourceType._standardize normalizes case
- Type: Behavior
- Subject: N23 (_standardize)
- Relation: EQ
- Expected: `AssessmentSourceType._standardize("human") == "HUMAN"`; `AssessmentSourceType._standardize("LlM_JuDgE") == "LLM_JUDGE"`.
- Evidence: Task evidence R10; `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`
- Observe: RETURN_VALUE
- Target: `AssessmentSourceType._standardize("human")` returns `"HUMAN"`
- Obligations: R10
- Graph: N22, N23, N24, E15, E16

### C15: AssessmentSourceType._standardize deprecates AI_JUDGE
- Type: SideEffect
- Subject: N23 (_standardize)
- Relation: EQ
- Expected: `AssessmentSourceType._standardize("AI_JUDGE")` issues `FutureWarning` with message containing "AI_JUDGE is deprecated. Use LLM_JUDGE instead." and returns `"LLM_JUDGE"`.
- Evidence: Task evidence R10; `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`; `tests/tracing/test_assessment.py:619` tests AI_JUDGE deprecation
- Observe: RETURN_VALUE + SIDE_EFFECT (warning)
- Target: `AssessmentSourceType._standardize("AI_JUDGE")` emits FutureWarning and returns "LLM_JUDGE"
- Obligations: R10
- Graph: N22, N23, N24, E16

### C16: AssessmentSourceType._standardize raises on invalid type
- Type: Failure
- Subject: N23 (_standardize) -> N29 (MlflowException)
- Relation: RAISES
- Expected: `AssessmentSourceType._standardize("INVALID")` raises `MlflowException` with message containing "Invalid assessment source type" and listing valid types.
- Evidence: Task evidence R10; `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`
- Observe: EXCEPTION
- Target: `AssessmentSourceType._standardize("INVALID")` raises MlflowException
- Obligations: R10
- Graph: N22, N23, N24, N29, E16

### C17: AssessmentSource.__post_init__ calls _standardize
- Type: Dataflow
- Subject: N28 (AssessmentSource.__post_init__) -> N23 (_standardize)
- Relation: CALLS
- Expected: Creating `AssessmentSource(source_type="llm_judge", source_id="test")` results in `self.source_type == "LLM_JUDGE"`.
- Evidence: `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`; `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`
- Observe: FIELD_READ
- Target: `AssessmentSource(source_type="llm_judge", source_id="test").source_type == "LLM_JUDGE"`
- Obligations: R10
- Graph: N27, N28, N23, E17

### C18: GetTracesInSession delegates to SearchTracesTool.invoke
- Type: Dataflow
- Subject: N21 (GetTracesInSession.invoke) -> N4 (SearchTracesTool.invoke)
- Relation: CALLS
- Expected: `GetTracesInSession().invoke(trace)` creates `SearchTracesTool()` instance and calls `.invoke(trace=trace, filter_string=constructed, order_by=order_by, max_results=max_results)`.
- Evidence: `mlflow/genai/judges/tools/get_traces_in_session.py:89-92`; `tests/genai/judges/test_judge_tool_get_traces_in_session.py:55-66` mocks SearchTracesTool
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `SearchTracesTool.invoke` called with constructed filter string from GetTracesInSession
- Obligations: R12
- Graph: N21, N4, E1

### C19: AssessmentSourceType instance creation and string conversion
- Type: Interface
- Subject: N25 (__init__) + N26 (__str__)
- Relation: EQ
- Expected: `str(AssessmentSourceType("HUMAN")) == "HUMAN"`; `str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"`; `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"` (with warning).
- Evidence: Task evidence R11; `libs/tracing/mlflow/entities/assessment_source.py:AssessmentSourceType.__init__, __str__`
- Observe: RETURN_VALUE
- Target: `str(AssessmentSourceType("HUMAN"))` equals "HUMAN"
- Obligations: R10, R11
- Graph: N22, N25, N26, E15, E16
