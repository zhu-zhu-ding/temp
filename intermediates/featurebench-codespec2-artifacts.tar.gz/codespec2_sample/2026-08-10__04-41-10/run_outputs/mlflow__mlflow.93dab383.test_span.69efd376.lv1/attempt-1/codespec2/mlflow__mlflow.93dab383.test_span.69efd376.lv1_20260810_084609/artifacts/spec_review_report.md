# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — L1–L6 lessons, architecture coverage matrix, arch/behavior separation guidance
- Native tests:
  - `tests/tracing/test_trace_manager.py::test_add_spans` — exercises real `InMemoryTraceManager` lifecycle: `register_trace` → `register_span` → `pop_trace`, then checks `isinstance(span, Span)` and `not isinstance(span, LiveSpan)`, plus removal from `_traces`. This is the authoritative state/lifecycle pattern for C1/E1.
  - `tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety` — verifies concurrent span registration and pop with correct cardinality, a thread-safety perspective currently absent from both specs.
  - `tests/entities/test_trace.py::test_json_deserialization` — verifies exact dict structure of `to_dict()` including `mock.ANY` for trace_id/span_id, status codes as `"STATUS_CODE_OK"`/`"STATUS_CODE_ERROR"`, events with `time_unix_nano` and attributes, and full round-trip `TraceData.from_dict(trace_data_dict)`. This is the authoritative pattern for C15 token-precise encoding checks.
  - `tests/entities/test_trace.py::test_to_from_dict_and_json` — round-trips all span fields (`name`, `request_id`, `span_id`, `start_time_ns`, `end_time_ns`, `parent_id`, `status`, `inputs`, `outputs`, `_trace_id`, `attributes`, `events`), establishing the C28 `PRESERVE` obligation's required scope.
  - `tests/entities/test_span_status.py::test_otel_status_conversion` — parametrized bidirectional conversion with all three status codes, verifies description-preservation for ERROR only (OTel clears description for non-ERROR). C26/C27 must match this exact behavior.
  - `tests/entities/test_span_status.py::test_otel_proto_status_to_mlflow_status_conversion` — tests `SpanStatus.from_otel_proto_status` which the current specs omit entirely despite being needed for `Span.from_otel_proto`.
  - `tests/entities/test_trace_data.py::test_json_deserialization` — verifies `TraceData.to_dict()` structure with events, confirms `"request"`/`"response"` are absent in v3 schema, and performs round-trip `TraceData.from_dict(to_dict())`.
  - `tests/tracing/test_fluent.py::test_span_record_exception_no_op_span` — verifies `NoOpSpan().record_exception("string")` is safe and creates no traces.
  - `tests/tracing/test_assessment.py::test_log_assessment_on_in_progress_with_span_id` — verifies `span.trace_id != "MLFLOW_NO_OP_SPAN_TRACE_ID"` guard, establishing the exact constant string expected in production code.
  - `tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto` — verifies `span.to_immutable_span()` → `span.to_otel_proto()` → `Span.from_otel_proto(proto, location_id)` round-trip through protobuf conversion, with field-level equality (`name`, `span_id`, `trace_id`, `inputs`, `outputs`, custom attributes). This is the authoritative dataflow for E13, C16, and the `location_id` parameter path.
  - `tests/tracing/utils/test_otlp.py::test_should_use_otlp_exporter` — parametrized environment variable behavior for OTLP export detection.

## Rubric

### Requirement coverage
All 17 L1 requirements (R1–R17) have at least one corresponding executable check in either `arch_spec.py` or `behavior_spec.py`. However, several checks are too weak to distinguish correct from plausible wrong implementations (see Findings). Notably, R6 (Span.attributes), R7 (Span.events), R8 (Span.from_otel_proto), R9 (Span.request_id), R12 (Span.to_otel_proto), R15 (decode anyvalue), and R17 (from_dict v2/v3) all have weak constraints.

**Score: 1** — Present but partial; several material checks lack discriminating power.

### Caller binding / call chain
The arch_spec has 24 checks. The `check_trace_to_mlflow_trace_chain` exercises the real `_Trace.to_mlflow_trace()` method which is good — it proves the public `pop_trace` → `to_mlflow_trace` chain. However, `check_processor_imports_create_mlflow_span` only checks `hasattr(otel_processor, "create_mlflow_span")` — this is a symbol existence check, not a real call chain. The Skill explicitly states: "A successful import module, a source text match, or `hasattr(module, "helper")` proves none of Dependency, Call Chain, or Dataflow." The `BaseMlflowSpanProcessor.on_start` caller path is not exercised.

**Score: 1** — The trace manager chain is exercised; the processor→create_mlflow_span chain is only symbol-checked.

### Dataflow / state / lifecycle
The specs test `to_immutable_span()` downcast, `Span.to_dict()` structure, base64 encoding, and `from_dict` round-trip. However, there is no test for the `Span.to_otel_proto() → Span.from_otel_proto()` protobuf round-trip (E13 dataflow). No test verifies `LiveSpan.end()` triggers span processors and transitions state. No test verifies `_CachedSpanAttributesRegistry` actually caches (the `get` is `@lru_cache` decorated but the behavior spec only tests that `set` raises). No test verifies that `Span.to_dict()` parent_span_id is None for root spans and a base64 string for child spans.

**Score: 1** — Key dataflow paths (protobuf round-trip, end lifecycle, parent_span_id encoding, caching) are missing or weak.

### Failure / compatibility boundaries
`LiveSpan.from_dict` raises `NotImplementedError` (tested). `_CachedSpanAttributesRegistry.set` raises `MlflowException` (tested). `create_mlflow_span` raises for invalid input (tested). However, no test verifies the exact error code (`INVALID_PARAMETER_VALUE`) for `_CachedSpanAttributesRegistry.set` or `create_mlflow_span` invalid input. The v2 backward compatibility test is a best-effort check that only verifies no crash — it does not verify any field correctness.

**Score: 1** — Core failure paths are covered but error codes are not asserted, and backward compat is weak.

## Derived Practical Test Perspectives

### P1: `tests/tracing/test_trace_manager.py::test_add_spans` — State/Lifecycle: pop removal + type assertion
The native test verifies that after `pop_trace`, the trace is removed from `_traces` AND the returned spans are immutable `Span` (not `LiveSpan`). The generated behavior spec `check_to_mlflow_trace_returns_immutable_spans` only asserts the span types but does NOT assert the trace is removed from the manager. This is a state/lifecycle gap — the check should use the real `InMemoryTraceManager.pop_trace` path and verify both conditions.

### P2: `tests/entities/test_trace.py::test_json_deserialization` — Exact dict token compatibility
The native test asserts exact dict structure including `"code": "STATUS_CODE_OK"` (not `"OK"`), `"message": ""` for OK status, events with `time_unix_nano`, and attributes with JSON-encoded values. The generated `check_span_to_dict_keys_and_types` only checks `isinstance(d, dict)` and key membership — it cannot catch the wrong status code string format that would break downstream consumers.

### P3: `tests/entities/test_span_status.py::test_otel_status_conversion` — Description preservation only for ERROR
The native test verifies that OTel clears description for non-ERROR statuses during conversion. The generated `check_span_status_to_otel_status_all_codes` and `check_span_status_from_otel_status_all_codes` iterate all codes but must explicitly check that `to_otel_status()` clears description for OK/UNSET and `from_otel_status()` returns `""` for those cases.

### P4: `tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto` — Protobuf round-trip with location_id
The native test exercises the full `to_immutable_span() → to_otel_proto() → Span.from_otel_proto(proto, location_id)` chain and verifies field-level equality. Neither spec tests `Span.from_otel_proto` with the `location_id` parameter (which triggers v4 trace ID generation). This is a dataflow gap in the E13/C16 contract coverage.

### P5: `tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety` — Concurrent access cardinality
The native test spawns 10 threads adding spans to 5 traces and verifies exact span count per trace. The generated specs have no concurrency/thread-safety check despite the task mentioning "Thread-safe in-memory trace management" as a key challenge.

## Final Rubric Scores
- **Requirement coverage: 1** — All R1–R17 are addressed but 6+ checks are weak (see Findings F2, F3, F4, F8, F10, F11).
- **Caller binding / call chain: 1** — The trace manager chain is real; the processor chain is symbol-only (F1).
- **Dataflow / state / lifecycle: 1** — Key paths missing: protobuf round-trip, end lifecycle, parent_span_id, cache behavior (F5, F7).
- **Failure / compatibility boundaries: 1** — Error codes not asserted; v2 compat is weak (F6, F12).
- **P1: 1** — `pop_trace` removal from manager not asserted in behavior spec; only span type checked.
- **P2: 1** — `to_dict` check is structural only, not token-precise; would pass with wrong status code format.
- **P3: 1** — Iterates all codes but must explicitly verify description clearing for non-ERROR.
- **P4: 0** — `Span.from_otel_proto` with `location_id` parameter is completely untested.
- **P5: 0** — No concurrency/thread-safety check exists in either spec.

## Findings

### F1: missing_requirement — Processor → create_mlflow_span call chain not exercised
- Requirement/IR: E15, C18–C21
- Evidence: Task calls for "create_mlflow_span" being imported by `mlflow/tracing/processor/otel.py:4` and `mlflow/tracing/processor/base_mlflow.py:87`; the Skill states "For every material L2 cross-module CALL, check that arch_spec.py executes the real caller and observes its helper/caller binding plus downstream result."
- Gap: `check_processor_imports_create_mlflow_span` only performs `hasattr(otel_processor, "create_mlflow_span")` which proves nothing about the actual caller binding or data routing. The real `BaseMlflowSpanProcessor.on_start` method calls `create_mlflow_span(span, trace_id)` — this must be exercised with a real processor instance and a spy to prove the import resolves at the caller.
- Repair: Replace the `hasattr` check with a real call chain: construct a minimal `BaseMlflowSpanProcessor` subclass, mock `InMemoryTraceManager`, call `on_start` with a mock `OTelSpan`, and assert `create_mlflow_span` was called with the span and trace_id. Use `patch("mlflow.tracing.processor.base_mlflow.create_mlflow_span", wraps=create_mlflow_span)` to spy at the actual import site.

### F2: weak_constraint — Span.to_dict checks are structural, not token-precise
- Requirement/IR: C15, R11
- Evidence: `tests/entities/test_trace.py::test_json_deserialization` asserts exact status code format `"STATUS_CODE_OK"` (not `"OK"`), exact event structure with `time_unix_nano`, and attribute values as JSON strings. The generated `check_span_to_dict_keys_and_types` only checks `isinstance(d, dict)` and key membership.
- Gap: A wrong implementation that uses `"OK"` instead of `"STATUS_CODE_OK"` for `status["code"]`, or uses `"timestamp"` instead of `"time_unix_nano"` for events, would pass the current check. This breaks downstream consumers (`TraceData.from_dict`, `Span.from_dict`, backend deserialization).
- Repair: Strengthen `check_span_to_dict_keys_and_types` to assert `d["status"]["code"] in ("STATUS_CODE_OK", "STATUS_CODE_ERROR", "STATUS_CODE_UNSET")`, that each event has keys `{"name", "time_unix_nano", "attributes"}`, and that `d["parent_span_id"]` is either `None` or a non-empty base64 string. Add a separate `check_span_to_dict_parent_span_id` that explicitly verifies root span produces `None` and child span produces a valid base64-encoded parent id.

### F3: weak_constraint — Span.to_otel_proto check only verifies field existence
- Requirement/IR: C16, R12
- Evidence: `tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto` verifies round-trip through protobuf with field-level equality. The generated `check_span_to_otel_proto_fields` in behavior_spec checks `hasattr(proto_span, field)` for each field but does not verify any field values or the structure of nested messages (attributes, events, status).
- Gap: A `.to_otel_proto()` that returns a protobuf with all fields set to defaults/empty would pass the current check. The protobuf must have correct trace_id bytes, span_id bytes, timestamps, status code mapping, and attribute serialization via `_set_otel_proto_anyvalue`.
- Repair: Strengthen to assert `len(proto_span.trace_id) == 16` (16 bytes), `len(proto_span.span_id) == 8` (8 bytes), `proto_span.start_time_unix_nano > 0`, `proto_span.status.code` is valid, and at least one attribute is populated. Then add a round-trip check: `Span.from_otel_proto(span.to_otel_proto()).name == span.name`.

### F4: weak_constraint — Span.events check only verifies list type
- Requirement/IR: C11, R7
- Evidence: `tests/entities/test_trace_data.py::test_json_deserialization` verifies event content (name, attributes, timestamp). The generated `check_span_events_returns_span_event_list` only checks `isinstance(events, list)` and `isinstance(events[0], SpanEvent)`.
- Gap: A wrong implementation that returns empty SpanEvent objects (no name, no timestamp) would pass. The events must preserve their name, timestamp, and attributes.
- Repair: Strengthen to assert `events[0].name is not None`, `events[0].timestamp > 0`, and `isinstance(events[0].attributes, dict)`.

### F5: missing_requirement — No Span.to_otel_proto → Span.from_otel_proto round-trip
- Requirement/IR: E13, C16, R8, R12
- Evidence: `tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto` verifies the full chain through protobuf. Neither spec tests `Span.from_otel_proto(span.to_otel_proto())`.
- Gap: The `to_otel_proto` and `from_otel_proto` methods are tested independently but never together. A mismatch in trace_id/span_id encoding between the two methods would not be caught.
- Repair: Add a behavior check: `Span.from_otel_proto(span.to_otel_proto()).name == span.name` and `Span.from_otel_proto(span.to_otel_proto()).span_id == span.span_id`.

### F6: weak_constraint — V2 backward compatibility check is best-effort only
- Requirement/IR: C28 (via `_is_span_v2_schema` / `from_dict_v2`), R17
- Evidence: `tests/entities/test_trace.py::test_from_v2_dict` verifies request_id, spans count, and metadata preservation. The generated `check_span_from_dict_v2_backward_compat` only checks `isinstance(result, Span)` and `name == "v2_span"` — it does not verify any other fields.
- Gap: A v2→v3 conversion that loses span_type, function_name, inputs/outputs, timing, or status would pass the current check. The check wraps in try/except and records failure but the assertion set is too narrow.
- Repair: Strengthen to assert `result.span_type == "CHAIN"`, `result.start_time_ns > 0`, `result.status.status_code == SpanStatusCode.OK`, `result.get_attribute("mlflow.spanInputs")` is not None, and at minimum 4 fields round-trip correctly.

### F7: missing_requirement — LiveSpan.end() lifecycle not tested
- Requirement/IR: IR N6 (LiveSpan.end), task mentions "termination"
- Evidence: `LiveSpan.end()` is defined in the existing code at `/testbed/mlflow/entities/span.py:615-658` and calls `apply_span_processors`, `self._span.end()`. Neither spec tests this method.
- Gap: The end-of-lifecycle behavior (setting OK status, calling span processors, ending the OTel span) is completely untested. A broken `end()` that doesn't set status or doesn't call processors would not be detected.
- Repair: Add a behavior check: create a LiveSpan, call `end()`, then verify `self._span._end_time is not None` and `self.status.status_code == SpanStatusCode.OK`. For the processor invocation, use a spy to verify `apply_span_processors` was called.

### F8: weak_constraint — _decode_otel_proto_anyvalue primitives check is incomplete
- Requirement/IR: C22–C25, R15
- Evidence: `tests/tracing/utils/test_otlp.py` tests the OTLP exporter but not the anyvalue decode function directly. `tests/entities/test_span_event.py::test_span_event_to_otel_proto_conversion` indirectly tests via event conversion. The generated `check_decode_anyvalue_primitives` tests `string_value` and `int_value` but not `bool_value`, `double_value`, `bytes_value`, or `None` (unset).
- Gap: The encode function `_set_otel_proto_anyvalue` handles `bool`, `float`, `bytes`, `None`, and `list/tuple`/`dict`. The decode function must handle all these types to be a true inverse. Missing types create silent data loss.
- Repair: Expand `check_decode_anyvalue_primitives` to include parametrized cases for `bool_value=True`, `double_value=3.14`, `bytes_value=b"hello"`, and unset AnyValue→None.

### F9: weak_constraint — NoOpSpan property getters check uses loop with generic assertions
- Requirement/IR: C7, R5
- Evidence: `tests/tracing/test_fluent.py::test_span_record_exception_no_op_span` tests `NoOpSpan` creation and `record_exception`. The generated `check_noop_span_property_getters_return_none` iterates property names and checks `getattr(noop, prop) is None`.
- Gap: The loop-based check is structurally reasonable but must exclude `trace_id` which returns `"MLFLOW_NO_OP_SPAN_TRACE_ID"` not `None`. The current behavior spec does handle this via separate `check_noop_span_trace_id_constant`. However, the loop does not verify `_trace_id` specifically returns `None` (which is the internal OTel trace ID). If the loop incorrectly includes `trace_id` and asserts `is None`, it would fail. The check should be more explicit.
- Repair: Replace the generic loop with explicit assertions for each property: `span_id`, `start_time_ns`, `end_time_ns`, `name`, `status`, `_trace_id` all return `None`. Keep `trace_id` as a separate explicit check for `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.

### F10: weak_constraint — Span.attributes check is non-specific
- Requirement/IR: C9, R6
- Evidence: `tests/utils/test_databricks_tracing_utils.py` verifies custom attribute retrieval through the full chain. The generated `check_span_attributes_complete_dict` sets `{"in": "input", "out": "result"}` and checks `isinstance(attrs, dict)` and `attrs["in"] == "input"`.
- Gap: This check is actually reasonable for the basic case. However, the check does not verify that attribute values are deserialized from their JSON-string storage format. A wrong implementation that stores raw strings instead of JSON-encoded values might still pass if values happen to be strings.
- Repair: Add a check with non-string attribute types: `set_attribute("int_val", 42)` → `get_attribute("int_val") == 42` (int, not string). Also verify cache hit: get same attribute twice from a cached registry and verify second call is fast or returns same object (optional but valuable).

### F11: missing_requirement — Span.from_otel_proto with location_id parameter
- Requirement/IR: R8, C16
- Evidence: `tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto` calls `Span.from_otel_proto(span, location_id)` with explicit location_id. The generated `check_span_from_otel_proto_creates_valid_span` and `check_span_from_otel_proto_interface` do not test the `location_id` parameter.
- Gap: When `location_id` is provided, `from_otel_proto` should generate a v4 trace ID (`trace:/location/trace_id`). Without testing this path, the v4 trace ID generation is unverified.
- Repair: Add a behavior check: `Span.from_otel_proto(proto_span, location_id="cat.schema")` and verify `span.trace_id.startswith("trace:/cat.schema/")`.

### F12: weak_constraint — _CachedSpanAttributesRegistry.set error code not asserted
- Requirement/IR: C17, R13
- Evidence: Interface Description 2 specifies `MlflowException`. The generated `check_cached_registry_set_raises` only checks `pytest.raises(MlflowException)` without verifying the error code.
- Gap: The error code `INVALID_PARAMETER_VALUE` is used throughout the codebase for parameter errors. If a wrong error code is raised, downstream error handlers may misroute the exception.
- Repair: Strengthen to `pytest.raises(MlflowException, match="...")` and check `exc.value.error_code == INVALID_PARAMETER_VALUE`.

### F13: missing_requirement — No concurrency/thread-safety check
- Requirement/IR: Task mentions "Thread-safe in-memory trace management with timeout-based cleanup" as a key challenge
- Evidence: `tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety` verifies concurrent span registration with 10 threads across 5 traces.
- Gap: Neither spec includes a thread-safety check for `InMemoryTraceManager.register_span` or `pop_trace`.
- Repair: Add an arch_spec check that spawns multiple threads registering spans concurrently, then verifies the total span count matches expected. This validates that the locking in `InMemoryTraceManager` works correctly.

## Rework Instructions

1. **Strengthen processor call chain (F1)**: Replace `check_processor_imports_create_mlflow_span` with a real call chain check. Create a concrete `BaseMlflowSpanProcessor` subclass, mock `InMemoryTraceManager`, and spy on `create_mlflow_span` at its import site in `base_mlflow.py`. Verify `create_mlflow_span` is called with the correct span and trace_id when `on_start` fires.

2. **Strengthen Span.to_dict token precision (F2)**: In `check_span_to_dict_keys_and_types`, add exact assertions for `d["status"]["code"]` matching `"STATUS_CODE_OK"`/`"STATUS_CODE_ERROR"` format, each event having `{"name", "time_unix_nano", "attributes"}` keys, and `d["parent_span_id"]` being `None` for root spans.

3. **Strengthen Span.to_otel_proto (F3)**: Add assertions for byte lengths of trace_id (16) and span_id (8), and add a round-trip check `Span.from_otel_proto(span.to_otel_proto()).name == span.name`.

4. **Add protobuf round-trip check (F5)**: Create `check_span_to_otel_proto_roundtrip` that verifies `from_otel_proto(to_otel_proto())` preserves name, span_id, trace_id, attributes, events, and status.

5. **Add from_otel_proto with location_id (F11)**: Create `check_span_from_otel_proto_with_location_id` that verifies v4 trace ID generation when location_id is provided.

6. **Strengthen v2 backward compat (F6)**: Add field-level assertions beyond name — verify span_type, start_time_ns, status, inputs, and at least 2 more attributes survive v2→v3 conversion.

7. **Add LiveSpan.end() lifecycle check (F7)**: Create `check_livespan_end_transitions_state` that verifies OTel span end_time is set and status defaults to OK.

8. **Expand anyvalue decode primitives (F8)**: Add bool_value, double_value, bytes_value, and None cases to the decode checks.

9. **Strengthen error code assertions (F12)**: Add `error_code == INVALID_PARAMETER_VALUE` to both `_CachedSpanAttributesRegistry.set` and `create_mlflow_span` invalid-input checks.

10. **Add thread-safety check (F13)**: Create `check_trace_manager_thread_safety` that spawns concurrent span registrations and verifies exact cardinality.
