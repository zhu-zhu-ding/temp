#!/usr/bin/env python3
"""
Executable behavior spec for MLflow Distributed Tracing System.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility contracts. Each check validates outcomes, error paths,
and observable state transitions.
"""

import sys
import traceback as _tb

PASSED = 0
FAILED = 0


def _record(name: str, ok: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if ok:
        PASSED += 1
        print(f"PASS: {name}")
    else:
        FAILED += 1
        print(f"FAIL: {name}  -- {detail}")


# ===========================================================================
# R1: _Trace.to_mlflow_trace conversion behavior
# ===========================================================================

def check_to_mlflow_trace_returns_immutable_spans() -> None:
    """C1: _Trace.to_mlflow_trace returns Trace where every data.spans element
    is Span (immutable), not LiveSpan."""
    # Contracts: C1
    # Reference: tests/tracing/test_trace_manager.py::test_add_spans
    from mlflow.entities import LiveSpan, Span, Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import _Trace

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    trace_info = TraceInfo(
        trace_id="tr-beh-c1",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        state=TraceState.OK,
    )
    otel_span = _mk_span(trace_id=1, span_id=1, name="root")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c1")
    internal = _Trace(info=trace_info, span_dict={"s1": live_span})

    result = internal.to_mlflow_trace()

    assert isinstance(result, Trace)
    assert isinstance(result.data, TraceData)
    assert len(result.data.spans) > 0
    for s in result.data.spans:
        assert isinstance(s, Span), f"Expected immutable Span, got {type(s)}"
        assert not isinstance(s, LiveSpan), f"Must not be LiveSpan: {s}"
    _record("check_to_mlflow_trace_returns_immutable_spans", True)


def check_to_mlflow_trace_sets_previews() -> None:
    """C2: _Trace.to_mlflow_trace sets request_preview and response_preview
    on the TraceInfo from root span inputs/outputs."""
    # Contracts: C2
    from mlflow.entities import LiveSpan
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import _Trace

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    trace_info = TraceInfo(
        trace_id="tr-beh-c2",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        state=TraceState.OK,
    )
    otel_span = _mk_span(trace_id=2, span_id=1, name="root")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c2")
    live_span.set_inputs({"query": "hello"})
    live_span.set_outputs({"answer": "world"})
    internal = _Trace(info=trace_info, span_dict={"s1": live_span})

    result = internal.to_mlflow_trace()

    req = result.info.request_preview
    resp = result.info.response_preview
    assert req is not None or resp is not None, \
        "Either request_preview or response_preview must be set"
    _record("check_to_mlflow_trace_sets_previews", True)


# ===========================================================================
# R2: LiveSpan.from_dict rejection
# ===========================================================================

def check_livespan_from_dict_raises_notimplemented() -> None:
    """C3: LiveSpan.from_dict(data) must always raise NotImplementedError."""
    # Contracts: C3
    from mlflow.entities.span import LiveSpan

    assert hasattr(LiveSpan, "from_dict"), "LiveSpan must have from_dict classmethod"
    try:
        LiveSpan.from_dict({"name": "test", "trace_id": "abc"})
        assert False, "LiveSpan.from_dict must raise NotImplementedError"
    except NotImplementedError:
        pass
    except Exception as e:
        assert isinstance(e, NotImplementedError) or "not supported" in str(e).lower(), \
            f"Unexpected exception: {e}"
    _record("check_livespan_from_dict_raises_notimplemented", True)


# ===========================================================================
# R3: LiveSpan.set_span_type behavior
# ===========================================================================

def check_livespan_set_span_type_persists() -> None:
    """C4: After set_span_type('LLM'), get_attribute(SPAN_TYPE) returns 'LLM'."""
    # Contracts: C4
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=3, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c4")
    live_span.set_span_type("LLM")

    val = live_span.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert val == "LLM", f"Expected 'LLM', got {val!r}"

    live_span.set_span_type("TOOL")
    val2 = live_span.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert val2 == "TOOL", f"Expected 'TOOL' after overwrite, got {val2!r}"
    _record("check_livespan_set_span_type_persists", True)


# ===========================================================================
# R4: LiveSpan.to_immutable_span behavior
# ===========================================================================

def check_livespan_to_immutable_span_downcast() -> None:
    """C5: to_immutable_span returns Span with _CachedSpanAttributesRegistry
    and same underlying OTel span."""
    # Contracts: C5
    from mlflow.entities import LiveSpan, Span
    from mlflow.entities.span import _CachedSpanAttributesRegistry

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=4, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c5")
    immutable = live_span.to_immutable_span()

    assert isinstance(immutable, Span), f"Expected Span, got {type(immutable)}"
    assert not isinstance(immutable, LiveSpan), "Result must not be LiveSpan"
    assert immutable._span is live_span._span, "Must reference same OTel span"
    assert isinstance(immutable._attributes, _CachedSpanAttributesRegistry), \
        "Must use _CachedSpanAttributesRegistry"
    _record("check_livespan_to_immutable_span_downcast", True)


# ===========================================================================
# R5: NoOpSpan no-op behavior
# ===========================================================================

def check_noop_span_trace_id_constant() -> None:
    """C6: NoOpSpan().trace_id returns 'MLFLOW_NO_OP_SPAN_TRACE_ID'."""
    # Contracts: C6
    # Reference: tests/tracing/test_assessment.py::test_log_assessment_on_in_progress_with_span_id
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    assert hasattr(noop, "trace_id"), "NoOpSpan must have trace_id property"
    tid = noop.trace_id
    assert tid == "MLFLOW_NO_OP_SPAN_TRACE_ID", \
        f"Expected 'MLFLOW_NO_OP_SPAN_TRACE_ID', got {tid!r}"
    _record("check_noop_span_trace_id_constant", True)


def check_noop_span_property_getters_return_none() -> None:
    """C7: NoOpSpan property getters (span_id, start_time_ns, end_time_ns,
    name, status, _trace_id) all return None.

    F9 repair: Explicit assertions per property instead of generic loop,
    with trace_id deliberately excluded from the None check (it returns
    the constant 'MLFLOW_NO_OP_SPAN_TRACE_ID').
    """
    # Contracts: C7
    # Reference: tests/tracing/test_fluent.py::test_span_record_exception_no_op_span
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()

    # Each property explicitly asserted:
    assert noop.span_id is None, "span_id must be None"
    assert noop.start_time_ns is None, "start_time_ns must be None"
    assert noop.end_time_ns is None, "end_time_ns must be None"
    assert noop.name is None, "name must be None"
    assert noop.status is None, "status must be None"
    # _trace_id is the internal OTel trace ID – must be None
    assert noop._trace_id is None, "_trace_id must be None"

    # trace_id is NOT None — it returns the constant (already tested in C6)
    _record("check_noop_span_property_getters_return_none", True)


def check_noop_span_setters_no_raise() -> None:
    """C8: All NoOpSpan setters complete without raising exceptions."""
    # Contracts: C8
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities import SpanEvent, SpanStatus, SpanStatusCode

    noop = NoOpSpan()

    setters = [
        ("set_attribute", lambda: noop.set_attribute("k", "v")),
        ("set_attributes", lambda: noop.set_attributes({"k": "v"})),
        ("set_inputs", lambda: noop.set_inputs({"x": 1})),
        ("set_outputs", lambda: noop.set_outputs(42)),
        ("set_status", lambda: noop.set_status(SpanStatus(SpanStatusCode.OK))),
        ("add_event", lambda: noop.add_event(SpanEvent(name="e"))),
        ("end", lambda: noop.end()),
        ("record_exception", lambda: noop.record_exception("error")),
    ]

    for name, fn in setters:
        try:
            fn()
        except Exception as e:
            _record("check_noop_span_setters_no_raise", False,
                    f"Setter {name} raised {type(e).__name__}: {e}")
            return
    _record("check_noop_span_setters_no_raise", True)


def check_noop_span_end_accepts_all_params() -> None:
    """C29: NoOpSpan().end(outputs, attributes, status, end_time_ns) silently succeeds."""
    # Contracts: C29
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    try:
        noop.end(
            outputs={"x": 1},
            attributes={"k": "v"},
            status="OK",
            end_time_ns=123456789,
        )
    except Exception as e:
        _record("check_noop_span_end_accepts_all_params", False,
                f"end() raised {type(e).__name__}: {e}")
        return
    _record("check_noop_span_end_accepts_all_params", True)


# ===========================================================================
# R6: Span.attributes behavior
# ===========================================================================

def check_span_attributes_complete_dict() -> None:
    """C9: Span.attributes returns dict with all OTel span attribute keys,
    values deserialized from JSON.

    F10 repair: Add non-string attribute types (int, bool, float) to
    verify proper deserialization from JSON storage format.
    """
    # Contracts: C9
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=6, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c9")
    live_span.set_attribute("string_key", "value")
    live_span.set_attribute("int_key", 123)
    live_span.set_attribute("bool_key", True)
    live_span.set_attribute("float_key", 3.14)
    # F10: non-string types should survive serialization round-trip
    live_span.set_attribute("dict_key", {"nested": "val"})
    live_span.set_attribute("list_key", [1, 2, 3])
    immutable = live_span.to_immutable_span()

    attrs = immutable.attributes
    assert isinstance(attrs, dict), "attributes must be dict"
    assert SpanAttributeKey.REQUEST_ID in attrs
    assert SpanAttributeKey.SPAN_TYPE in attrs
    assert attrs["string_key"] == "value"
    assert attrs["int_key"] == 123
    assert attrs["bool_key"] is True
    assert attrs["float_key"] == 3.14
    # F10: Non-string types verify proper JSON deserialization
    assert attrs["dict_key"] == {"nested": "val"}, \
        f"dict attribute not preserved: {attrs['dict_key']!r}"
    assert attrs["list_key"] == [1, 2, 3], \
        f"list attribute not preserved: {attrs['list_key']!r}"
    # F10: Verify cached registry: get same attribute twice returns same value
    val1 = immutable.get_attribute("int_key")
    val2 = immutable.get_attribute("int_key")
    assert val1 == val2 == 123, "Cached registry should return consistent values"

    _record("check_span_attributes_complete_dict", True)


def check_span_attributes_empty_for_no_attributes() -> None:
    """Verify Span.attributes works for span with no custom attributes."""
    from mlflow.entities import LiveSpan

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=7, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c9b")
    immutable = live_span.to_immutable_span()

    attrs = immutable.attributes
    assert isinstance(attrs, dict)
    from mlflow.tracing.constant import SpanAttributeKey
    assert SpanAttributeKey.REQUEST_ID in attrs
    _record("check_span_attributes_empty_for_no_attributes", True)


# ===========================================================================
# R7: Span.events behavior
# ===========================================================================

def check_span_events_returns_span_event_list() -> None:
    """C10: Span.events returns list[SpanEvent] with plain dict attributes."""
    # Contracts: C10
    from mlflow.entities import LiveSpan, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=8, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c10")
    live_span.add_event(SpanEvent(name="start", attributes={"phase": "begin"}))
    live_span.add_event(SpanEvent(name="end", attributes={"phase": "done"}))
    immutable = live_span.to_immutable_span()

    events = immutable.events
    assert isinstance(events, list), "events must be list"
    assert len(events) == 2, f"Expected 2 events, got {len(events)}"
    for evt in events:
        assert isinstance(evt, SpanEvent), f"Expected SpanEvent, got {type(evt)}"
        assert hasattr(evt, "name")
        assert hasattr(evt, "timestamp")
        assert isinstance(evt.attributes, dict), \
            f"Event attributes must be dict, got {type(evt.attributes)}"
    assert events[0].name == "start"
    assert events[1].name == "end"
    _record("check_span_events_returns_span_event_list", True)


def check_span_events_empty_list() -> None:
    """Verify Span.events returns empty list for span with no events."""
    from mlflow.entities import LiveSpan

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=9, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c10b")
    immutable = live_span.to_immutable_span()

    events = immutable.events
    assert isinstance(events, list)
    assert len(events) == 0, f"Expected empty list, got {events}"
    _record("check_span_events_empty_list", True)


# ===========================================================================
# R8: Span.from_otel_proto behavior
# ===========================================================================

def check_span_from_otel_proto_creates_valid_span() -> None:
    """C11: Span.from_otel_proto creates a Span with correct trace_id,
    span_id, name, times, status, attributes, events.

    F5 repair: Add protobuf round-trip assertions.
    """
    # Contracts: C11
    from mlflow.entities.span import Span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus

    proto_span = OTelProtoSpan()
    proto_span.trace_id = b"\x00" * 15 + b"\x01"
    proto_span.span_id = b"\x00" * 7 + b"\x01"
    proto_span.name = "proto_test"
    proto_span.start_time_unix_nano = 1000000
    proto_span.end_time_unix_nano = 2000000
    proto_span.kind = OTelProtoSpan.SPAN_KIND_INTERNAL

    proto_span.status.code = OTelProtoStatus.STATUS_CODE_OK
    proto_span.status.message = "ok"

    attr = proto_span.attributes.add()
    attr.key = "test.key"
    attr.value.string_value = "test_val"

    result = Span.from_otel_proto(proto_span)
    assert isinstance(result, Span), f"Expected Span, got {type(result)}"
    assert result.name == "proto_test"
    assert result.start_time_ns == 1000000
    assert result.end_time_ns == 2000000
    assert result.trace_id is not None
    assert len(result.trace_id) > 0

    # F5: Protobuf round-trip: from_otel_proto(to_otel_proto()) preserves key fields
    proto = result.to_otel_proto()
    rt = Span.from_otel_proto(proto)
    assert rt.name == result.name, \
        f"Round-trip name: {rt.name!r} vs {result.name!r}"
    assert rt.start_time_ns == result.start_time_ns, \
        f"Round-trip start_time: {rt.start_time_ns} vs {result.start_time_ns}"
    assert rt.end_time_ns == result.end_time_ns, \
        f"Round-trip end_time: {rt.end_time_ns} vs {result.end_time_ns}"

    _record("check_span_from_otel_proto_creates_valid_span", True)


# ===========================================================================
# R9: Span.request_id backward compatibility
# ===========================================================================

def check_span_request_id_equals_trace_id() -> None:
    """C12: span.request_id == span.trace_id always."""
    # Contracts: C12
    from mlflow.entities import LiveSpan

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=12, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c12")
    immutable = live_span.to_immutable_span()

    assert immutable.request_id == immutable.trace_id, \
        f"request_id ({immutable.request_id!r}) must equal trace_id ({immutable.trace_id!r})"
    _record("check_span_request_id_equals_trace_id", True)


# ===========================================================================
# R10: Span.span_type behavior
# ===========================================================================

def check_span_span_type_from_attribute() -> None:
    """C13: span.span_type returns get_attribute(SpanAttributeKey.SPAN_TYPE)."""
    # Contracts: C13
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=13, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c13")
    live_span.set_span_type("RETRIEVER")
    immutable = live_span.to_immutable_span()

    assert immutable.span_type == immutable.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert immutable.span_type == "RETRIEVER"
    _record("check_span_span_type_from_attribute", True)


def check_span_span_type_default_unknown() -> None:
    """Verify span_type defaults to UNKNOWN when not explicitly set."""
    from mlflow.entities import LiveSpan, SpanType

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=14, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c13b")
    immutable = live_span.to_immutable_span()

    assert immutable.span_type == SpanType.UNKNOWN, \
        f"Default span_type should be UNKNOWN, got {immutable.span_type!r}"
    _record("check_span_span_type_default_unknown", True)


# ===========================================================================
# R11: Span.to_dict serialization
# ===========================================================================

def check_span_to_dict_keys_and_types() -> None:
    """C14: Span.to_dict returns dict with all required keys of correct types.

    F2 repair: Token-precise assertions for status code format, event keys,
    and parent_span_id for root spans.
    """
    # Contracts: C14
    # Reference: tests/entities/test_trace.py::test_json_deserialization
    from mlflow.entities import LiveSpan, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=15, span_id=1, name="dict_test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c14")
    live_span.set_status("OK")
    live_span.add_event(SpanEvent(name="e1", attributes={"a": 1}))
    immutable = live_span.to_immutable_span()

    d = immutable.to_dict()
    assert isinstance(d, dict)
    assert "trace_id" in d and isinstance(d["trace_id"], str)
    assert "span_id" in d and isinstance(d["span_id"], str)
    assert "parent_span_id" in d
    assert "name" in d and d["name"] == "dict_test"
    assert "start_time_unix_nano" in d and isinstance(d["start_time_unix_nano"], int)
    assert "end_time_unix_nano" in d
    assert "events" in d and isinstance(d["events"], list)
    assert "status" in d and isinstance(d["status"], dict)
    assert "code" in d["status"]
    assert "attributes" in d and isinstance(d["attributes"], dict)

    # F2: Token-precise status code format
    assert d["status"]["code"] in ("STATUS_CODE_OK", "STATUS_CODE_UNSET", "STATUS_CODE_ERROR"), \
        f"status code must be STATUS_CODE_* format, got {d['status']['code']!r}"
    assert "message" in d["status"], "status must include 'message' key"

    # F2: Each event must have name, time_unix_nano, attributes
    for evt in d["events"]:
        assert "name" in evt, "event missing 'name'"
        assert "time_unix_nano" in evt, "event missing 'time_unix_nano'"
        assert "attributes" in evt, "event missing 'attributes'"

    # F2: parent_span_id is None for root spans
    assert d["parent_span_id"] is None, \
        f"parent_span_id should be None for root spans, got {d['parent_span_id']!r}"

    _record("check_span_to_dict_keys_and_types", True)


def check_span_to_dict_base64_encoding() -> None:
    """C15: to_dict IDs are base64-encoded int.to_bytes output."""
    # Contracts: C15
    import base64
    from mlflow.entities import LiveSpan

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=16, span_id=1, name="b64_test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c15")
    immutable = live_span.to_immutable_span()

    d = immutable.to_dict()
    trace_id_b64 = d["trace_id"]
    span_id_b64 = d["span_id"]

    trace_bytes = base64.b64decode(trace_id_b64)
    span_bytes = base64.b64decode(span_id_b64)

    assert len(trace_bytes) == 16, \
        f"trace_id decodes to {len(trace_bytes)} bytes, expected 16"
    assert len(span_bytes) == 8, \
        f"span_id decodes to {len(span_bytes)} bytes, expected 8"

    trace_int = int.from_bytes(trace_bytes, byteorder="big", signed=False)
    span_int = int.from_bytes(span_bytes, byteorder="big", signed=False)
    assert isinstance(trace_int, int)
    assert isinstance(span_int, int)

    re_encoded_trace = base64.b64encode(trace_int.to_bytes(16, "big")).decode("utf-8")
    re_encoded_span = base64.b64encode(span_int.to_bytes(8, "big")).decode("utf-8")
    assert re_encoded_trace == trace_id_b64
    assert re_encoded_span == span_id_b64
    _record("check_span_to_dict_base64_encoding", True)


# ===========================================================================
# R12: Span.to_otel_proto behavior (strengthened F3/F5)
# ===========================================================================

def check_span_to_otel_proto_fields() -> None:
    """C16: Span.to_otel_proto returns OTelProtoSpan with correct fields
    including byte-level encoding and round-trip preservation.

    F3 repair: Assert byte lengths of trace_id (16) and span_id (8).
    F5 repair: Round-trip from_otel_proto(to_otel_proto()) preserves name.
    """
    # Contracts: C16
    # Reference: tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto
    from mlflow.entities import LiveSpan, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    otel_span = _mk_span(trace_id=17, span_id=1, name="proto_test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c16")
    live_span.set_attribute("export_key", "export_val")
    live_span.add_event(SpanEvent(name="evt", attributes={"k": "v"}))
    live_span.set_status("OK")
    immutable = live_span.to_immutable_span()

    proto = immutable.to_otel_proto()
    assert isinstance(proto, OTelProtoSpan)
    assert proto.name == "proto_test"

    # F3: Byte-length assertions
    assert len(proto.trace_id) == 16, \
        f"trace_id must be 16 bytes, got {len(proto.trace_id)}"
    assert len(proto.span_id) == 8, \
        f"span_id must be 8 bytes, got {len(proto.span_id)}"

    # F5: Round-trip through protobuf
    round_tripped = immutable.from_otel_proto(proto)
    assert round_tripped.name == immutable.name, \
        f"Round-trip name mismatch: {round_tripped.name!r} vs {immutable.name!r}"

    _record("check_span_to_otel_proto_fields", True)


# ===========================================================================
# F5 explicit: Span.to_otel_proto → from_otel_proto protobuf round-trip
# ===========================================================================

def check_span_to_otel_proto_roundtrip() -> None:
    """Verify that from_otel_proto(to_otel_proto()) preserves span_id, trace_id,
    attributes, events, and status in a full protobuf round-trip.

    F5 repair: Dedicated round-trip check.
    """
    # Reference: tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto
    from mlflow.entities import LiveSpan, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=1701, span_id=42, name="roundtrip_proto")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-roundtrip")
    live_span.set_attribute("custom.attr", "custom_val")
    live_span.set_inputs({"in": "data"})
    live_span.set_outputs({"out": "result"})
    live_span.set_status("OK")
    live_span.add_event(SpanEvent(name="checkpoint", attributes={"step": 1}))
    immutable = live_span.to_immutable_span()

    proto = immutable.to_otel_proto()
    rt = immutable.from_otel_proto(proto)

    # Core identity fields
    assert rt.name == immutable.name, \
        f"name: {rt.name!r} vs {immutable.name!r}"
    assert rt.span_id == immutable.span_id, \
        f"span_id: {rt.span_id!r} vs {immutable.span_id!r}"
    assert rt.trace_id == immutable.trace_id, \
        f"trace_id: {rt.trace_id!r} vs {immutable.trace_id!r}"

    # Status
    assert rt.status.status_code == immutable.status.status_code, \
        f"status: {rt.status.status_code} vs {immutable.status.status_code}"

    # Attributes
    assert rt.get_attribute("custom.attr") == "custom_val", \
        "custom attribute lost in round-trip"

    # Events
    assert len(rt.events) == len(immutable.events), \
        f"events count: {len(rt.events)} vs {len(immutable.events)}"
    assert rt.events[0].name == "checkpoint"

    _record("check_span_to_otel_proto_roundtrip", True)


# ===========================================================================
# R13: _CachedSpanAttributesRegistry.set rejection (strengthened F12)
# ===========================================================================

def check_cached_registry_set_raises() -> None:
    """C17: _CachedSpanAttributesRegistry(...).set(key, value) raises MlflowException.

    F12 repair: Assert error_code == INVALID_PARAMETER_VALUE.
    """
    # Contracts: C17
    from mlflow.entities.span import _CachedSpanAttributesRegistry
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=18, span_id=1, name="test")
    registry = _CachedSpanAttributesRegistry(otel_span)

    try:
        registry.set("key", "value")
        assert False, "Expected MlflowException"
    except MlflowException as e:
        # F12: Assert exact error code
        assert e.error_code == INVALID_PARAMETER_VALUE, \
            f"Expected error_code INVALID_PARAMETER_VALUE, got {e.error_code}"
    except Exception as e:
        _record("check_cached_registry_set_raises", False,
                f"Unexpected exception type: {type(e).__name__}: {e}")
        return
    _record("check_cached_registry_set_raises", True)


# ===========================================================================
# R14: create_mlflow_span factory dispatch
# ===========================================================================

def check_create_mlflow_span_livespan_for_otel_span() -> None:
    """C18: create_mlflow_span(OTelSpan, trace_id) returns LiveSpan."""
    # Contracts: C18
    from mlflow.entities.span import LiveSpan, create_mlflow_span

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=19, span_id=1, name="test")
    result = create_mlflow_span(otel_span, "tr-beh-c18")
    assert isinstance(result, LiveSpan), \
        f"Expected LiveSpan, got {type(result)}"
    assert result.trace_id == "tr-beh-c18"
    _record("check_create_mlflow_span_livespan_for_otel_span", True)


def check_create_mlflow_span_span_for_readable() -> None:
    """C19: create_mlflow_span(OTelReadableSpan, trace_id) returns Span."""
    # Contracts: C19
    from mlflow.entities import Span
    from mlflow.entities.span import create_mlflow_span

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=20, span_id=1, name="test", end_time=100)
    result = create_mlflow_span(otel_span, "tr-beh-c19")
    assert isinstance(result, Span), \
        f"Expected Span for finished span, got {type(result)}"
    _record("check_create_mlflow_span_span_for_readable", True)


def check_create_mlflow_span_noop_for_nonrecording() -> None:
    """C20: create_mlflow_span(NonRecordingSpan, trace_id) returns NoOpSpan."""
    # Contracts: C20
    from mlflow.entities.span import NoOpSpan, create_mlflow_span
    from opentelemetry.trace import NonRecordingSpan

    nr = NonRecordingSpan(context=None)
    result = create_mlflow_span(nr, "tr-beh-c20")
    assert isinstance(result, NoOpSpan), \
        f"Expected NoOpSpan, got {type(result)}"
    _record("check_create_mlflow_span_noop_for_nonrecording", True)


def check_create_mlflow_span_noop_for_none() -> None:
    """C20: create_mlflow_span(None, trace_id) returns NoOpSpan."""
    # Contracts: C20
    from mlflow.entities.span import NoOpSpan, create_mlflow_span

    result = create_mlflow_span(None, "tr-beh-c20b")
    assert isinstance(result, NoOpSpan), \
        f"Expected NoOpSpan for None, got {type(result)}"
    assert result.trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"
    _record("check_create_mlflow_span_noop_for_none", True)


def check_create_mlflow_span_raises_for_invalid() -> None:
    """C21: create_mlflow_span('invalid', trace_id) raises MlflowException.

    F12 repair: Assert error_code == INVALID_PARAMETER_VALUE.
    """
    # Contracts: C21
    from mlflow.entities.span import create_mlflow_span
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    try:
        create_mlflow_span("invalid_string", "tr-beh-c21")
        assert False, "Must raise MlflowException"
    except MlflowException as e:
        # F12: Assert exact error code
        assert e.error_code == INVALID_PARAMETER_VALUE, \
            f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}"
    _record("check_create_mlflow_span_raises_for_invalid", True)


# ===========================================================================
# R15: _decode_otel_proto_anyvalue decoding (F8: already expanded)
# ===========================================================================

def check_decode_anyvalue_primitives() -> None:
    """C22-C23: _decode_otel_proto_anyvalue correctly decodes all primitives
    including bool, float, bytes, and None."""
    # Contracts: C22, C23
    # Perspective: F8 repair – all primitives from _set_otel_proto_anyvalue's isinstance chain
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    av_s = AnyValue(); av_s.string_value = "hello"
    assert _decode_otel_proto_anyvalue(av_s) == "hello"

    av_i = AnyValue(); av_i.int_value = 42
    assert _decode_otel_proto_anyvalue(av_i) == 42

    av_b = AnyValue(); av_b.bool_value = True
    assert _decode_otel_proto_anyvalue(av_b) is True

    av_f = AnyValue(); av_f.double_value = 3.14
    assert _decode_otel_proto_anyvalue(av_f) == 3.14

    av_bytes = AnyValue(); av_bytes.bytes_value = b"data"
    assert _decode_otel_proto_anyvalue(av_bytes) == b"data"

    av_none = AnyValue()
    assert _decode_otel_proto_anyvalue(av_none) is None

    _record("check_decode_anyvalue_primitives", True)


def check_decode_anyvalue_array_recursive() -> None:
    """C24: _decode_otel_proto_anyvalue decodes array recursively."""
    # Contracts: C24
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue, _set_otel_proto_anyvalue

    av = AnyValue()
    _set_otel_proto_anyvalue(av, [1, "a", [2, 3]])
    result = _decode_otel_proto_anyvalue(av)
    assert result == [1, "a", [2, 3]], f"Got {result!r}"
    _record("check_decode_anyvalue_array_recursive", True)


def check_decode_anyvalue_kvlist_dict() -> None:
    """C25: _decode_otel_proto_anyvalue decodes kvlist to dict."""
    # Contracts: C25
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue, _set_otel_proto_anyvalue

    av = AnyValue()
    _set_otel_proto_anyvalue(av, {"x": 1, "y": "b"})
    result = _decode_otel_proto_anyvalue(av)
    assert result == {"x": 1, "y": "b"}, f"Got {result!r}"
    _record("check_decode_anyvalue_kvlist_dict", True)


# ===========================================================================
# R16: SpanStatus OTel conversion
# ===========================================================================

def check_span_status_to_otel_status_all_codes() -> None:
    """C26: SpanStatus.to_otel_status for all status codes.

    Perspective: Description-preservation for ERROR only (OTel clears
    description for non-ERROR).
    """
    # Contracts: C26
    # Reference: tests/entities/test_span_status.py::test_otel_status_conversion
    from mlflow.entities import SpanStatus, SpanStatusCode
    from opentelemetry.trace import StatusCode as OTelStatusCode

    test_cases = [
        (SpanStatusCode.UNSET, OTelStatusCode.UNSET),
        (SpanStatusCode.OK, OTelStatusCode.OK),
        (SpanStatusCode.ERROR, OTelStatusCode.ERROR),
    ]

    for ml_code, otel_code in test_cases:
        ss = SpanStatus(ml_code)
        otel_status = ss.to_otel_status()
        assert otel_status.status_code == otel_code, \
            f"Expected {otel_code}, got {otel_status.status_code}"

    # Description preservation for ERROR
    ss_err = SpanStatus(SpanStatusCode.ERROR, "failed")
    otel_err = ss_err.to_otel_status()
    assert otel_err.description == "failed"

    _record("check_span_status_to_otel_status_all_codes", True)


def check_span_status_from_otel_status_all_codes() -> None:
    """C27: SpanStatus.from_otel_status for all status codes."""
    # Contracts: C27
    # Reference: tests/entities/test_span_status.py::test_otel_status_conversion
    from mlflow.entities import SpanStatus, SpanStatusCode
    from opentelemetry.trace import Status as OTelStatus
    from opentelemetry.trace import StatusCode as OTelStatusCode

    test_cases = [
        (OTelStatusCode.UNSET, SpanStatusCode.UNSET),
        (OTelStatusCode.OK, SpanStatusCode.OK),
        (OTelStatusCode.ERROR, SpanStatusCode.ERROR),
    ]

    for otel_code, ml_code in test_cases:
        otel_status = OTelStatus(otel_code, "desc")
        ml_status = SpanStatus.from_otel_status(otel_status)
        assert ml_status.status_code == ml_code, \
            f"Expected {ml_code}, got {ml_status.status_code}"

    otel_err = OTelStatus(OTelStatusCode.ERROR, "error desc")
    ml_err = SpanStatus.from_otel_status(otel_err)
    assert ml_err.description == "error desc"

    _record("check_span_status_from_otel_status_all_codes", True)


# ===========================================================================
# R17: Span serialization backward compatibility
# ===========================================================================

def check_span_from_dict_v3_roundtrip() -> None:
    """C28: Span.from_dict(span.to_dict()) preserves all fields."""
    # Contracts: C28
    # Reference: tests/entities/test_trace.py::test_to_from_dict_and_json
    from mlflow.entities import LiveSpan, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=21, span_id=1, name="roundtrip_test")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-c28")
    live_span.set_span_type("TOOL")
    live_span.set_inputs({"in": "data"})
    live_span.set_outputs({"out": "result"})
    live_span.set_status("OK")
    live_span.add_event(SpanEvent(name="checkpoint", attributes={"step": 1}))
    immutable = live_span.to_immutable_span()

    d = immutable.to_dict()
    rt = immutable.from_dict(d)

    assert rt.name == immutable.name
    assert rt.trace_id == immutable.trace_id
    assert rt.span_id == immutable.span_id
    assert rt.parent_id == immutable.parent_id
    assert rt.start_time_ns == immutable.start_time_ns
    assert rt.status.status_code == immutable.status.status_code
    assert len(rt.events) == len(immutable.events)
    assert rt.span_type == immutable.span_type
    _record("check_span_from_dict_v3_roundtrip", True)


def check_span_from_dict_v2_backward_compat() -> None:
    """Verify Span.from_dict handles v2 schema format.

    F6 repair: Add field-level assertions beyond name – verify span_type,
    start_time_ns, status, inputs, and additional attributes survive
    v2→v3 conversion.
    """
    from mlflow.entities.span import Span

    v2_dict = {
        "name": "v2_span",
        "context": {
            "span_id": "0d48a6670588966b",
            "trace_id": "63076d0c1b90f1df0970f897dc428bd6",
        },
        "parent_id": None,
        "start_time": 100,
        "end_time": 200,
        "status_code": "OK",
        "status_message": "",
        "attributes": {
            "mlflow.traceRequestId": '"tr-v2-test"',
            "mlflow.spanType": '"CHAIN"',
            "mlflow.spanFunctionName": '"v2_func"',
            "mlflow.spanInputs": '{"x": 1}',
            "mlflow.spanOutputs": '"result"',
        },
        "events": [],
    }

    try:
        result = Span.from_dict(v2_dict)
        assert isinstance(result, Span), f"Expected Span, got {type(result)}"
        # F6: Field-level assertions beyond just name
        assert result.name == "v2_span", \
            f"Expected name 'v2_span', got {result.name!r}"
        assert result.start_time_ns == 100, \
            f"Expected start_time_ns 100, got {result.start_time_ns}"
        assert result.end_time_ns == 200, \
            f"Expected end_time_ns 200, got {result.end_time_ns}"
        # v2 span should have a valid trace_id
        assert result.trace_id is not None and len(result.trace_id) > 0, \
            f"trace_id should be non-empty: {result.trace_id!r}"
        assert result.span_id is not None and len(result.span_id) > 0, \
            f"span_id should be non-empty: {result.span_id!r}"
        # Status should be OK
        assert result.status.status_code.value == "OK", \
            f"Expected status OK, got {result.status.status_code}"
        # span_type should survive
        assert result.span_type == "CHAIN", \
            f"Expected span_type CHAIN, got {result.span_type!r}"
    except Exception as e:
        _record("check_span_from_dict_v2_backward_compat", False,
                f"V2 deserialization failed: {type(e).__name__}: {e}")
        return
    _record("check_span_from_dict_v2_backward_compat", True)


# ===========================================================================
# F7: LiveSpan.end() lifecycle state transitions
# ===========================================================================

def check_livespan_end_transitions_state() -> None:
    """Verify LiveSpan.end() sets end_time on OTel span and defaults status to OK.

    F7 repair: Verify OTel span end_time is set and status defaults to OK.
    """
    from mlflow.entities import LiveSpan
    from mlflow.entities.span_status import SpanStatusCode

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=99995, span_id=1, name="end_lifecycle")
    live_span = LiveSpan(otel_span, trace_id="tr-beh-end")

    # Before end: no end_time, status defaults
    assert live_span.end_time_ns is None, "Span should have no end_time before end()"

    live_span.end()

    # After end: end_time must be set
    assert live_span.end_time_ns is not None, "Span must have end_time after end()"
    # Default status should be OK (not UNSET)
    assert live_span.status.status_code == SpanStatusCode.OK, \
        f"Default status after end() should be OK, got {live_span.status.status_code}"

    _record("check_livespan_end_transitions_state", True)


# ===========================================================================
# Boundary / default checks
# ===========================================================================

def check_livespan_default_span_type_is_unknown() -> None:
    """Verify LiveSpan defaults to SpanType.UNKNOWN."""
    from mlflow.entities import LiveSpan, SpanType

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=100, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-boundary")
    assert live_span.get_attribute("mlflow.spanType") == SpanType.UNKNOWN
    _record("check_livespan_default_span_type_is_unknown", True)


def check_span_trace_id_uses_request_id_attribute() -> None:
    """Verify Span.trace_id reads from SpanAttributeKey.REQUEST_ID."""
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=101, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-boundary-tid")
    immutable = live_span.to_immutable_span()

    assert immutable.trace_id == immutable.get_attribute(SpanAttributeKey.REQUEST_ID)
    _record("check_span_trace_id_uses_request_id_attribute", True)


def check_noop_span_instantiation_safe() -> None:
    """Verify NoOpSpan() can be created without arguments."""
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    assert noop is not None
    _ = noop.trace_id
    _ = noop.span_id
    _ = noop.name
    _record("check_noop_span_instantiation_safe", True)


# ===========================================================================
# Main
# ===========================================================================
if __name__ == "__main__":
    checks = [
        check_to_mlflow_trace_returns_immutable_spans,
        check_to_mlflow_trace_sets_previews,
        check_livespan_from_dict_raises_notimplemented,
        check_livespan_set_span_type_persists,
        check_livespan_to_immutable_span_downcast,
        check_noop_span_trace_id_constant,
        check_noop_span_property_getters_return_none,
        check_noop_span_setters_no_raise,
        check_noop_span_end_accepts_all_params,
        check_span_attributes_complete_dict,
        check_span_attributes_empty_for_no_attributes,
        check_span_events_returns_span_event_list,
        check_span_events_empty_list,
        check_span_from_otel_proto_creates_valid_span,
        check_span_request_id_equals_trace_id,
        check_span_span_type_from_attribute,
        check_span_span_type_default_unknown,
        check_span_to_dict_keys_and_types,
        check_span_to_dict_base64_encoding,
        check_span_to_otel_proto_fields,
        check_span_to_otel_proto_roundtrip,
        check_cached_registry_set_raises,
        check_create_mlflow_span_livespan_for_otel_span,
        check_create_mlflow_span_span_for_readable,
        check_create_mlflow_span_noop_for_nonrecording,
        check_create_mlflow_span_noop_for_none,
        check_create_mlflow_span_raises_for_invalid,
        check_decode_anyvalue_primitives,
        check_decode_anyvalue_array_recursive,
        check_decode_anyvalue_kvlist_dict,
        check_span_status_to_otel_status_all_codes,
        check_span_status_from_otel_status_all_codes,
        check_span_from_dict_v3_roundtrip,
        check_span_from_dict_v2_backward_compat,
        check_livespan_end_transitions_state,
        check_livespan_default_span_type_is_unknown,
        check_span_trace_id_uses_request_id_attribute,
        check_noop_span_instantiation_safe,
    ]
    for c in checks:
        try:
            c()
        except Exception:
            _record(c.__name__, False, _tb.format_exc().strip().split("\n")[-1])

    print(f"\n{'='*50}")
    print(f"RESULTS: {PASSED} passed, {FAILED} failed, {len(checks)} total")
    if FAILED > 0:
        sys.exit(1)
    sys.exit(0)
