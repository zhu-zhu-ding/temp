# Semantic IR

## L1. Requirement Obligations

### R1: Convert internal _Trace to immutable MLflow Trace
- Type: Behavior
- Statement: The `_Trace.to_mlflow_trace()` method must convert all contained `LiveSpan` objects to immutable `Span` objects, create a `TraceData` container, set request/response previews on the `TraceInfo`, and return an immutable `Trace` suitable for persistence and external use.
- Task Evidence: "Convert the internal _Trace representation to an MLflow Trace object... transforms the mutable internal trace representation into an immutable MLflow Trace object suitable for persistence and external use. It converts all LiveSpan objects in the span dictionary to immutable Span objects, creates a TraceData container, and sets request/response previews."
- Acceptance: Calling `_Trace.to_mlflow_trace()` returns a `Trace` whose `data.spans` list contains only immutable `Span` instances (not `LiveSpan`), with `request_preview` and `response_preview` populated on `TraceInfo`.
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:186` calls `internal_trace.to_mlflow_trace()` inside `pop_trace`; `/testbed/mlflow/entities/trace.py` defines `Trace` with `info: TraceInfo` and `data: TraceData`; `/testbed/mlflow/entities/trace_data.py` defines `TraceData(spans: list[Span])`.
- Uncertainty: The exact mechanism for `set_request_response_preview` is not yet implemented; the method is referenced in the task but not found in the repository. Whether it uses root span inputs/outputs or requires a helper function is uncertain.

### R2: LiveSpan.from_dict must reject deserialization
- Type: Failure
- Statement: `LiveSpan.from_dict(data)` must always raise `NotImplementedError` because `LiveSpan` objects represent active, mutable spans and cannot be reconstructed from serialized dictionary data.
- Task Evidence: "This method is not supported for the LiveSpan class as LiveSpan objects represent active, mutable spans that are being created and updated during runtime."
- Acceptance: Calling `LiveSpan.from_dict({...})` raises `NotImplementedError`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:484-491` defines `LiveSpan(Span)`; `/testbed/mlflow/entities/span.py:258-329` defines `Span.from_dict(cls, data)` which returns an immutable `Span`; tests in `/testbed/tests/entities/test_trace_data.py:171` exercise span deserialization.
- Uncertainty: None.

### R3: LiveSpan.set_span_type must persist span type attribute
- Type: Behavior
- Statement: `LiveSpan.set_span_type(span_type)` must store the given span type string as a span attribute using the `SpanAttributeKey.SPAN_TYPE` key, allowing categorization of the span's purpose.
- Task Evidence: "Set the type of the span to categorize its purpose or functionality... The span type is stored as a span attribute and will be visible in trace visualizations."
- Acceptance: After calling `live_span.set_span_type("LLM")`, reading `live_span.get_attribute(SpanAttributeKey.SPAN_TYPE)` returns `"LLM"`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:552-554` defines `LiveSpan.set_attribute(key, value)` which delegates to `self._attributes.set(key, value)`; `/testbed/mlflow/tracing/constant.py:57` defines `SpanAttributeKey.SPAN_TYPE = "mlflow.spanType"`; `/testbed/mlflow/entities/span.py:516-517` shows `self._attributes.set(SpanAttributeKey.SPAN_TYPE, span_type)` in `LiveSpan.__init__`.
- Uncertainty: None.

### R4: LiveSpan.to_immutable_span must downcast to immutable Span
- Type: Behavior
- Statement: `LiveSpan.to_immutable_span()` must return an immutable `Span` object wrapping the same underlying OpenTelemetry span data, with no data copying required since all state is persisted in the OTel span.
- Task Evidence: "Convert this LiveSpan instance to an immutable Span object... wraps the underlying OpenTelemetry span object. All state of the live span is already persisted in the OpenTelemetry span object, so no data copying is required."
- Acceptance: `live_span.to_immutable_span()` returns a `Span` instance (not `LiveSpan`) whose `_span` attribute references the same underlying OTel span, and whose `_attributes` is a `_CachedSpanAttributesRegistry`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:101-112` shows `Span.__init__(self, otel_span: OTelReadableSpan)` creates `_CachedSpanAttributesRegistry`; `/testbed/mlflow/entities/span.py:484-517` shows `LiveSpan.__init__` accepts `OTelSpan` (a subclass of `OTelReadableSpan`).
- Uncertainty: None.

### R5: NoOpSpan must provide safe no-op implementations for all Span interface methods
- Type: Interface
- Statement: `NoOpSpan` must implement every property and method of the `Span` interface as a no-op (returning `None` or doing nothing) so that user code calling setters on a `NoOpSpan` instance never raises runtime errors. The `trace_id` property must return `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Task Evidence: "This instance should be returned from the mlflow.start_span context manager when span creation fails. This class should have exactly the same interface as the Span so that user's setter calls do not raise runtime errors."
- Acceptance: Calling any setter (`set_inputs`, `set_outputs`, `set_status`, `set_attribute`, `set_attributes`, `add_event`, `end`, `record_exception`) on a `NoOpSpan` instance completes without error. All property getters (`_trace_id`, `end_time_ns`, `name`, `span_id`, `start_time_ns`, `status`) return `None`. `trace_id` returns `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:761-842` defines `NoOpSpan(Span)` with partial implementation (only `context`, `parent_id`, `record_exception` defined); `/testbed/tests/tracing/test_fluent.py:1832-1836` tests `NoOpSpan()` creation and `record_exception`; `/testbed/tests/tracing/test_assessment.py:507` checks `span.trace_id != "MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Uncertainty: None.

### R6: Span.attributes must return all span attributes as deserialized dict
- Type: Behavior
- Statement: `Span.attributes` property must return a dictionary of all attributes on the span, with values deserialized from their JSON string representation to original Python types. For immutable spans, the attributes are cached via `_CachedSpanAttributesRegistry`.
- Task Evidence: "Get all attributes of the span... The attributes are automatically deserialized from their internal JSON string representation to their original Python objects... For immutable spans, the attributes are cached to improve performance since the span data cannot change after creation."
- Acceptance: `span.attributes` returns a `dict[str, Any]` where each value has been deserialized from JSON. Repeated access to the property on an immutable span returns the same cached result.
- Repository Evidence: `/testbed/mlflow/entities/span.py:112` shows `self._attributes = _CachedSpanAttributesRegistry(otel_span)`; `/testbed/mlflow/entities/span.py:871-879` shows `_SpanAttributesRegistry.get()` deserializes via `json.loads`; `/testbed/mlflow/entities/span.py:892-903` shows `_CachedSpanAttributesRegistry.get()` with `@lru_cache`.
- Uncertainty: The exact iteration mechanism to collect all OTel span attribute keys is uncertain. OTel spans store attributes as a `BoundedAttributes` mapping; `dict(self._span.attributes)` or iterating over `self._span.attributes.items()` would be needed.

### R7: Span.events must return all span events as SpanEvent list
- Type: Behavior
- Statement: `Span.events` property must return a list of `SpanEvent` objects representing all point-in-time occurrences during the span's execution. The events are converted from OTel's internal format and attributes are converted from `BoundedAttributes` to plain dicts for safe serialization.
- Task Evidence: "Get all events of the span... The returned events are converted from OpenTelemetry's internal BoundedAttributes format to simple dictionaries to ensure proper serialization."
- Acceptance: `span.events` returns `list[SpanEvent]` where each `SpanEvent` has `name`, `timestamp`, and `attributes` (as a plain `dict`). Returns empty list if no events.
- Repository Evidence: `/testbed/mlflow/entities/span_event.py:12-36` defines `SpanEvent` dataclass with `name`, `timestamp`, `attributes`; `/testbed/mlflow/entities/span.py:580-588` shows `LiveSpan.add_event` calls `self._span.add_event(event.name, event.attributes, event.timestamp)`; tests in `/testbed/tests/litellm/test_litellm_autolog.py:89-90` check `len(spans[0].events) == 1` and `spans[0].events[0].name == "exception"`.
- Uncertainty: The exact OTel internal event structure. OTel stores events with `name`, `timestamp`, and `attributes` (as `BoundedAttributes`). Converting `BoundedAttributes` to plain `dict` is needed.

### R8: Span.from_otel_proto must create Span from OTel protobuf
- Type: Behavior
- Statement: `Span.from_otel_proto(otel_proto_span, location_id=None)` class method must convert an OpenTelemetry protobuf `Span` message into an MLflow `Span` object by extracting trace/span IDs, timing, attributes, events, and status. With `location_id`, generates v4 trace ID format; otherwise generates standard MLflow trace ID.
- Task Evidence: "Create a Span from an OpenTelemetry protobuf span... It converts an OpenTelemetry protobuf span message into an MLflow Span object by extracting all relevant span data including trace/span IDs, timing information, attributes, events, and status."
- Acceptance: `Span.from_otel_proto(otel_proto_span)` returns a valid `Span` with correct `trace_id`, `span_id`, `name`, `start_time_ns`, `end_time_ns`, `status`, `attributes`, and `events`.
- Repository Evidence: `/testbed/mlflow/entities/trace.py:240-243` calls `Span.from_otel_proto(span)` in `Trace.from_proto`; `/testbed/mlflow/entities/span.py:7-8` imports `OTelProtoSpan` and `OTelProtoStatus`; `/testbed/mlflow/tracing/utils/__init__.py:295-296` defines `generate_mlflow_trace_id_from_otel_trace_id`; `/testbed/mlflow/tracing/utils/otlp.py:122-153` defines `_set_otel_proto_anyvalue`.
- Uncertainty: The exact protobuf field layout; but the OTel proto spec is well-defined.

### R9: Span.request_id must alias trace_id
- Type: Compatibility
- Statement: `Span.request_id` property must return the same value as `trace_id`, providing backward compatibility for code using the deprecated `request_id` attribute.
- Task Evidence: "The request ID of the span, which is an alias for the trace ID... This property is deprecated. Use `trace_id` instead for new code."
- Acceptance: `span.request_id == span.trace_id` always.
- Repository Evidence: `/testbed/mlflow/entities/span.py:114-118` defines `trace_id` property returning `self.get_attribute(SpanAttributeKey.REQUEST_ID)`; `/testbed/mlflow/entities/trace_info.py:162-164` shows `request_id` aliasing `trace_id` in `TraceInfo`.
- Uncertainty: None.

### R10: Span.span_type must return span type from attributes
- Type: Behavior
- Statement: `Span.span_type` property must return the span type string stored in the `SpanAttributeKey.SPAN_TYPE` attribute, used for filtering, categorization, and visualization.
- Task Evidence: "The type of the span... The span type is stored as an attribute with the key defined in SpanAttributeKey.SPAN_TYPE."
- Acceptance: `span.span_type` returns the string value set via `set_span_type` or `SpanType.UNKNOWN` by default.
- Repository Evidence: `/testbed/mlflow/entities/span.py:516-517` sets `SpanAttributeKey.SPAN_TYPE` in `LiveSpan.__init__`; `/testbed/mlflow/tracing/constant.py:57` defines `SpanAttributeKey.SPAN_TYPE = "mlflow.spanType"`; tests in `/testbed/tests/anthropic/test_anthropic_autolog.py:187` check `span.span_type == SpanType.CHAT_MODEL`.
- Uncertainty: None.

### R11: Span.to_dict must serialize span to dictionary
- Type: Dataflow
- Statement: `Span.to_dict()` must serialize the span into a dictionary with trace_id (base64-encoded 16 bytes), span_id (base64-encoded 8 bytes), parent_span_id, name, start_time_unix_nano, end_time_unix_nano, events, status (code/message), and attributes using the specific encoding scheme: int→bytes(big-endian)→base64 for IDs.
- Task Evidence: "Convert the span to a dictionary representation... The trace_id and span_id (and parent_span_id) must be converted from OpenTelemetry integer format to base64-encoded strings through a two-step process: first convert the integer to bytes, then base64-encode those bytes."
- Acceptance: `span.to_dict()` returns a dict with exact keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`. The ID fields use `int.to_bytes(length=N, byteorder="big") → base64.b64encode() → .decode("utf-8")` where N=16 for trace_id and N=8 for span_id.
- Repository Evidence: `/testbed/mlflow/entities/trace_data.py:33` calls `span.to_dict()` in `TraceData.to_dict()`; `/testbed/mlflow/entities/span.py:258-329` defines `Span.from_dict` which decodes base64 IDs; `/testbed/mlflow/entities/span.py:1` imports `base64`; `/testbed/mlflow/entities/trace.py:127` calls `span.to_dict()` in `to_pandas_dataframe_row`.
- Uncertainty: None.

### R12: Span.to_otel_proto must convert span to OTel protobuf
- Type: Dataflow
- Statement: `Span.to_otel_proto()` must convert the MLflow `Span` into an OpenTelemetry protobuf `Span` message for OTLP export, mapping trace/span IDs from hex to bytes, timing, status, attributes (via `AnyValue`), events, and parent span.
- Task Evidence: "Convert to OpenTelemetry protobuf span format for OTLP export... This method transforms the MLflow Span object into an OpenTelemetry protobuf Span message... converting trace ID and span ID from hex string format to bytes."
- Acceptance: `span.to_otel_proto()` returns an `OTelProtoSpan` protobuf message with all fields populated correctly.
- Repository Evidence: `/testbed/mlflow/entities/trace.py:236-238` calls `span.to_otel_proto()` in `Trace.to_proto()`; `/testbed/mlflow/entities/span_event.py:74-88` defines `SpanEvent.to_otel_proto()` using `_set_otel_proto_anyvalue`; `/testbed/mlflow/tracing/utils/otlp.py:122-153` defines `_set_otel_proto_anyvalue`.
- Uncertainty: None.

### R13: _CachedSpanAttributesRegistry.set must reject mutations
- Type: Failure
- Statement: `_CachedSpanAttributesRegistry.set(key, value)` must raise `MlflowException` because cached attributes are for immutable spans and cannot be modified.
- Task Evidence: "Set an attribute value for the cached span attributes registry... Always raised since this method is not supported for immutable spans. The cached registry is designed for read-only access to persisted span attributes and does not allow modifications."
- Acceptance: Calling `_CachedSpanAttributesRegistry(...).set("key", "val")` raises `MlflowException`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:892-903` defines `_CachedSpanAttributesRegistry(_SpanAttributesRegistry)` with only `get` overridden; `/testbed/mlflow/entities/span.py:881-889` shows parent `set` method.
- Uncertainty: None.

### R14: create_mlflow_span factory must dispatch to correct span type
- Type: Behavior
- Statement: `create_mlflow_span(otel_span, trace_id, span_type=None)` factory function must return `LiveSpan` for active `OTelSpan`, `Span` for finished `OTelReadableSpan`, or `NoOpSpan` for `NonRecordingSpan` or `None`, raising `MlflowException` for invalid span types.
- Task Evidence: "Create an MLflow span object from an OpenTelemetry span... This factory function creates the appropriate MLflow span object based on the type of the input OpenTelemetry span."
- Acceptance: `create_mlflow_span(OTelSpan(...), "trace-123")` returns `LiveSpan`; `create_mlflow_span(OTelReadableSpan(...), "trace-123")` returns `Span`; `create_mlflow_span(NonRecordingSpan(...), "trace-123")` returns `NoOpSpan`; `create_mlflow_span(None, "trace-123")` returns `NoOpSpan`; `create_mlflow_span("invalid", "trace-123")` raises `MlflowException(INVALID_PARAMETER_VALUE)`.
- Repository Evidence: `/testbed/mlflow/tracing/processor/otel.py:4,53` imports and calls `create_mlflow_span(span, trace_id)` in `on_end`; `/testbed/mlflow/semantic_kernel/autolog.py:15,91` imports and calls `create_mlflow_span(span, trace_id)`; `/testbed/mlflow/haystack/autolog.py:20,105` imports and calls `create_mlflow_span(span, trace_id)`; `/testbed/mlflow/strands/autolog.py:24,48` imports and calls `create_mlflow_span(span, trace_id)`.
- Uncertainty: None.

### R15: _decode_otel_proto_anyvalue must decode OTel AnyValue to Python
- Type: Dataflow
- Statement: `_decode_otel_proto_anyvalue(pb_any_value)` must recursively convert an OpenTelemetry protobuf `AnyValue` message into its corresponding Python representation, handling all supported types: None (unset), bool, str, int, float, bytes, list (array), and dict (kvlist).
- Task Evidence: "Decode an OpenTelemetry protobuf AnyValue message into a Python object... This function recursively converts an OpenTelemetry AnyValue protobuf message into its corresponding Python representation."
- Acceptance: Feeding an `AnyValue` protobuf message with `string_value="hello"` returns `"hello"`; with `int_value=42` returns `42`; with `array_value` containing `[1, 2]` returns `[1, 2]`; with `kvlist_value` containing `{"a": 1}` returns `{"a": 1}`.
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py:122-153` defines the inverse function `_set_otel_proto_anyvalue`; `/testbed/mlflow/tracing/utils/otlp.py:7` imports `AnyValue` from opentelemetry proto.
- Uncertainty: None.

### R16: SpanStatus must support to_otel_status and from_otel_status
- Type: Compatibility
- Statement: `SpanStatus` must provide `to_otel_status()` to convert to an OpenTelemetry `Status` object and `from_otel_status(otel_status)` classmethod to create from one, enabling interoperability between MLflow and OTel span status representations.
- Task Evidence: Not directly in task document but referenced by existing code: `Span.status` property (line 155) calls `SpanStatus.from_otel_status(self._span.status)` and `LiveSpan.set_status` (line 578) calls `status.to_otel_status()`.
- Acceptance: `SpanStatus(SpanStatusCode.OK).to_otel_status()` returns an OTel `Status` with `StatusCode.OK`; `SpanStatus.from_otel_status(otel_status)` returns a `SpanStatus` with matching code and description.
- Repository Evidence: `/testbed/mlflow/entities/span.py:155` calls `SpanStatus.from_otel_status(self._span.status)`; `/testbed/mlflow/entities/span.py:578` calls `status.to_otel_status()`; `/testbed/mlflow/entities/trace_status.py:50` and `/testbed/mlflow/entities/trace_state.py:33` each define their own `from_otel_status`.
- Uncertainty: `SpanStatus.to_otel_status()` and `SpanStatus.from_otel_status()` are called in production code but not yet defined in `span_status.py`. They must be added.

### R17: Span serialization helpers must exist (_decode_id_from_byte, _is_base64_encoded, _is_span_v2_schema, from_dict_v2)
- Type: Dataflow
- Statement: The `Span.from_dict` method references helper functions `_decode_id_from_byte`, `_is_base64_encoded`, `_is_span_v2_schema`, and `Span.from_dict_v2` that must exist for v2/v3 schema backward compatibility deserialization.
- Task Evidence: "Handle multiple serialization schemas (v2, v3) for backward compatibility."
- Acceptance: `Span.from_dict(data)` succeeds for both v2 and v3 dict formats, using these helpers internally.
- Repository Evidence: `/testbed/mlflow/entities/span.py:269-277` calls `Span._is_span_v2_schema(data)`, `Span.from_dict_v2(data)`, `_is_base64_encoded(data["trace_id"])`, and `_decode_id_from_byte(data["trace_id"])`; none are defined elsewhere in the codebase.
- Uncertainty: The exact implementation of v2 schema detection and conversion. The v2 format likely uses `request_id` key differently from v3's `trace_id` key.

## L2. Functional Design Graph

### N1: _Trace (dataclass)
- Kind: State
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:17-22`

### N2: _Trace.to_mlflow_trace
- Kind: Method
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:186` calls this method on `internal_trace`

### N3: LiveSpan (class)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:484-755`

### N4: LiveSpan.from_dict
- Kind: Method
- Repository Evidence: Interface Description 2 specifies this method

### N5: LiveSpan.set_span_type
- Kind: Method
- Repository Evidence: Interface Description 2 specifies this method

### N6: LiveSpan.to_immutable_span
- Kind: Method
- Repository Evidence: Interface Description 2 specifies this method

### N7: LiveSpan.set_attribute
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/span.py:552-554`

### N8: Span (immutable)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:91-483`

### N9: Span.attributes
- Kind: Method (property)
- Repository Evidence: Interface Description 2 specifies this property

### N10: Span.events
- Kind: Method (property)
- Repository Evidence: Interface Description 2 specifies this property

### N11: Span.from_otel_proto
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/entities/trace.py:240-243` calls this; Interface Description 2 specifies

### N12: Span.request_id
- Kind: Method (property)
- Repository Evidence: Interface Description 2 specifies this property

### N13: Span.span_type
- Kind: Method (property)
- Repository Evidence: `/testbed/mlflow/entities/trace.py:220` calls `span.span_type`; Interface Description 2 specifies

### N14: Span.to_dict
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/trace_data.py:33` calls `span.to_dict()`; Interface Description 2 specifies

### N15: Span.to_otel_proto
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/trace.py:237` calls `span.to_otel_proto()`; Interface Description 2 specifies

### N16: Span.from_dict
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/entities/span.py:258-329`

### N17: Span.trace_id
- Kind: Method (property)
- Repository Evidence: `/testbed/mlflow/entities/span.py:114-118`

### N18: NoOpSpan
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:761-842`

### N19: NoOpSpan properties (span_id, start_time_ns, end_time_ns, name, status, trace_id, _trace_id)
- Kind: Method (property)
- Repository Evidence: Interface Description 2 specifies all these properties

### N20: NoOpSpan setters (set_attribute, set_attributes, set_inputs, set_outputs, set_status, add_event, end)
- Kind: Method
- Repository Evidence: Interface Description 2 specifies all these methods

### N21: _CachedSpanAttributesRegistry
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:892-903`

### N22: _CachedSpanAttributesRegistry.set
- Kind: Method
- Repository Evidence: Interface Description 2 specifies this method

### N23: _SpanAttributesRegistry
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:854-889`

### N24: _SpanAttributesRegistry.get
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/span.py:871-879`

### N25: create_mlflow_span
- Kind: Function
- Repository Evidence: Interface Description 2 specifies; `/testbed/mlflow/tracing/processor/otel.py:4,53` imports and calls

### N26: _decode_otel_proto_anyvalue
- Kind: Function
- Repository Evidence: Interface Description 3 specifies

### N27: _set_otel_proto_anyvalue
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py:122-153`

### N28: SpanStatus
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span_status.py:51-121`

### N29: SpanStatus.to_otel_status
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/span.py:578` calls `status.to_otel_status()`; `/testbed/mlflow/entities/span.py:310` calls `status.to_otel_status()`

### N30: SpanStatus.from_otel_status
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/entities/span.py:155` calls `SpanStatus.from_otel_status(self._span.status)`

### N31: SpanEvent
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/span_event.py:12-36`

### N32: Trace
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace.py:26-31`

### N33: TraceData
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_data.py:11-25`

### N34: TraceInfo
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_info.py:20-60`

### N35: InMemoryTraceManager.pop_trace
- Kind: Method
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:175-186`

### N36: OTelReadableSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:11`

### N37: OTelSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:13`

### N38: NonRecordingSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:12`

### N39: OTelProtoSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:7`

### N40: SpanAttributeKey
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/tracing/constant.py:48-72`

### N41: encode_span_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py` (encode_span_id)

### N42: encode_trace_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py` (encode_trace_id)

### N43: decode_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py` (decode_id)

### N44: dump_span_attribute_value
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py` (dump_span_attribute_value)

### N45: generate_mlflow_trace_id_from_otel_trace_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py:295`

### N46: generate_trace_id_v4_from_otel_trace_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py:308`

### N47: build_otel_context
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py` (build_otel_context)

### N48: _OTelResource
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:9`

### N49: OTelEvent
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:10`

### N50: OTelStatus / OTelStatusCode
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:14-15`

### N51: _decode_id_from_byte (helper)
- Kind: Function
- Repository Evidence: `/testbed/mlflow/entities/span.py:273-277` calls this; must be implemented in span.py

### N52: _is_base64_encoded (helper)
- Kind: Function
- Repository Evidence: `/testbed/mlflow/entities/span.py:272` calls this; must be implemented in span.py

### N53: Span._is_span_v2_schema (helper)
- Kind: Method (staticmethod)
- Repository Evidence: `/testbed/mlflow/entities/span.py:269` calls this; must be implemented

### N54: Span.from_dict_v2 (helper)
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/entities/span.py:270` calls this; must be implemented

### E1: InMemoryTraceManager.pop_trace -> _Trace.to_mlflow_trace
- Kind: CALL
- Condition: When a trace is finalized and popped from memory
- Transfer: `internal_trace` → `Trace` with immutable spans and request/response previews
- Evidence: `/testbed/mlflow/tracing/trace_manager.py:186` `trace=internal_trace.to_mlflow_trace()`
- Obligations: R1

### E2: _Trace.to_mlflow_trace -> LiveSpan.to_immutable_span
- Kind: CALL
- Condition: For each span in span_dict
- Transfer: `LiveSpan` → `Span` (immutable)
- Evidence: Task document: "It converts all LiveSpan objects in the span dictionary to immutable Span objects"
- Obligations: R1, R4

### E3: _Trace.to_mlflow_trace -> TraceInfo (request/response preview)
- Kind: DATA
- Condition: Root span has inputs/outputs
- Transfer: Root span inputs → `trace_info.request_preview`; root span outputs → `trace_info.response_preview`
- Evidence: Task document: "sets request/response previews on the trace info"
- Obligations: R1

### E4: LiveSpan.set_span_type -> LiveSpan.set_attribute
- Kind: CALL
- Condition: Always when called
- Transfer: `span_type: str` → `SpanAttributeKey.SPAN_TYPE` attribute
- Evidence: Task document: "The span type is stored as a span attribute"
- Obligations: R3

### E5: LiveSpan.set_attribute -> _SpanAttributesRegistry.set
- Kind: CALL
- Condition: Always when called
- Transfer: `(key: str, value: Any)` → OTel span attribute (JSON serialized)
- Evidence: `/testbed/mlflow/entities/span.py:554` `self._attributes.set(key, value)`
- Obligations: R3

### E6: LiveSpan.to_immutable_span -> Span.__init__
- Kind: CALL
- Condition: Always when called
- Transfer: `self._span` → `Span(otel_span)`
- Evidence: Task document: "wraps the underlying OpenTelemetry span object"
- Obligations: R4

### E7: Span.attributes -> _CachedSpanAttributesRegistry.get
- Kind: CALL
- Condition: For each key in OTel span attributes
- Transfer: `key` → deserialized value; all collected into dict
- Evidence: `/testbed/mlflow/entities/span.py:112` `self._attributes = _CachedSpanAttributesRegistry(otel_span)`; `/testbed/mlflow/entities/span.py:225` `self._attributes.get(key)`
- Obligations: R6

### E8: Span.events -> OTelReadableSpan.events
- Kind: DATA
- Condition: Always when accessed
- Transfer: OTel internal events → list of `SpanEvent` with plain dict attributes
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:588` `self._span.add_event(event.name, event.attributes, event.timestamp)`
- Obligations: R7

### E9: Span.from_otel_proto -> Span.__init__
- Kind: CALL
- Condition: Always when called
- Transfer: Constructed `OTelReadableSpan` → new `Span`
- Evidence: `/testbed/mlflow/entities/trace.py:240-243` `Span.from_otel_proto(span)`; `/testbed/mlflow/entities/span.py:303-323` shows how `OTelReadableSpan` is constructed in `from_dict`
- Obligations: R8

### E10: Span.request_id -> Span.trace_id
- Kind: DATA
- Condition: Always when accessed
- Transfer: Same value as `trace_id`
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:114-118`
- Obligations: R9

### E11: Span.span_type -> Span.get_attribute
- Kind: CALL
- Condition: Always when accessed
- Transfer: `SpanAttributeKey.SPAN_TYPE` → attribute value
- Evidence: `/testbed/mlflow/entities/span.py:516-517`; `/testbed/mlflow/tracing/constant.py:57`
- Obligations: R10

### E12: Span.to_dict -> encode_span_id, encode_trace_id, base64
- Kind: CALL
- Condition: Always when serializing
- Transfer: Integer IDs → base64 strings; all span fields → dict
- Evidence: Interface Description 2 encoding spec; `/testbed/mlflow/entities/trace_data.py:33`
- Obligations: R11

### E13: Span.to_otel_proto -> _set_otel_proto_anyvalue, SpanEvent.to_otel_proto
- Kind: CALL
- Condition: Always when converting
- Transfer: MLflow Span fields → OTel protobuf Span message
- Evidence: `/testbed/mlflow/entities/trace.py:237`; `/testbed/mlflow/entities/span_event.py:74-88`
- Obligations: R12

### E14: _CachedSpanAttributesRegistry.set -> MlflowException
- Kind: CONTROL
- Condition: Always when called on cached registry
- Transfer: Raises `MlflowException` (unsupported)
- Evidence: Interface Description 2
- Obligations: R13

### E15: create_mlflow_span -> LiveSpan | Span | NoOpSpan
- Kind: CONTROL
- Condition: Based on `otel_span` type: `OTelSpan` → LiveSpan; `OTelReadableSpan` (non-OTelSpan) → Span; `NonRecordingSpan`/None → NoOpSpan; invalid → MlflowException
- Transfer: `(otel_span, trace_id, span_type)` → appropriate span object
- Evidence: `/testbed/mlflow/tracing/processor/otel.py:4,53`; `/testbed/mlflow/semantic_kernel/autolog.py:15,91`
- Obligations: R14

### E16: _decode_otel_proto_anyvalue -> Python types
- Kind: DATA
- Condition: Based on `WhichOneof` result on AnyValue
- Transfer: Protobuf AnyValue → Python bool/str/int/float/bytes/list/dict
- Evidence: Interface Description 3; inverse function `_set_otel_proto_anyvalue` at `/testbed/mlflow/tracing/utils/otlp.py:122-153`
- Obligations: R15

### E17: SpanStatus.to_otel_status -> OTelStatus
- Kind: CALL
- Condition: When setting span status via OTel API
- Transfer: MLflow `SpanStatusCode` → OTel `StatusCode` + description → `OTelStatus`
- Evidence: `/testbed/mlflow/entities/span.py:578` `status.to_otel_status()`
- Obligations: R16

### E18: SpanStatus.from_otel_status -> SpanStatus
- Kind: CALL
- Condition: When reading span status from OTel span
- Transfer: OTel `Status` → `SpanStatus(status_code, description)`
- Evidence: `/testbed/mlflow/entities/span.py:155` `SpanStatus.from_otel_status(self._span.status)`
- Obligations: R16

### E19: Span.from_dict -> _decode_id_from_byte, _is_base64_encoded
- Kind: CALL
- Condition: When deserializing span dict
- Transfer: base64-encoded ID strings → integer IDs
- Evidence: `/testbed/mlflow/entities/span.py:272-277`
- Obligations: R17

### E20: Span.from_dict -> Span._is_span_v2_schema, Span.from_dict_v2
- Kind: CALL
- Condition: When data matches v2 schema format
- Transfer: v2 dict → v3-compatible Span
- Evidence: `/testbed/mlflow/entities/span.py:269-270`
- Obligations: R17

### E21: NoOpSpan (all properties) -> None / "MLFLOW_NO_OP_SPAN_TRACE_ID"
- Kind: DATA
- Condition: Always when accessed
- Transfer: All property getters return None except trace_id returns `"MLFLOW_NO_OP_SPAN_TRACE_ID"`
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:758` `NO_OP_SPAN_TRACE_ID = "MLFLOW_NO_OP_SPAN_TRACE_ID"`
- Obligations: R5

### E22: NoOpSpan (all setters) -> void
- Kind: CONTROL
- Condition: Always when called
- Transfer: No operation performed; no error raised
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:761-842`
- Obligations: R5

## L3. Verifiable Contracts

### C1: _Trace.to_mlflow_trace returns Trace with immutable spans
- Type: Behavior
- Subject: `_Trace.to_mlflow_trace()` return value
- Relation: TYPE_IS
- Expected: `Trace` object where every element of `data.spans` is `Span` (not `LiveSpan`)
- Evidence: Task document R1; `/testbed/mlflow/tracing/trace_manager.py:186` calls `internal_trace.to_mlflow_trace()`; `/testbed/mlflow/entities/trace.py:26-31` defines `Trace` dataclass
- Observe: RETURN_VALUE
- Target: `InMemoryTraceManager.pop_trace(otel_trace_id).trace.data.spans`
- Obligations: R1
- Graph: N1, N2, E1, E2

### C2: _Trace.to_mlflow_trace sets request/response previews
- Type: Dataflow
- Subject: `_Trace.to_mlflow_trace()` result's `info.request_preview` and `info.response_preview`
- Relation: PRESERVE
- Expected: Root span inputs populate `info.request_preview`; root span outputs populate `info.response_preview` (as JSON strings or truncated strings)
- Evidence: Task document R1; `/testbed/mlflow/entities/trace_info.py:20-60` defines `TraceInfo` with `request_preview` and `response_preview` fields
- Observe: FIELD_READ
- Target: `Trace.info.request_preview`, `Trace.info.response_preview`
- Obligations: R1
- Graph: N1, N2, N34, E3

### C3: LiveSpan.from_dict raises NotImplementedError
- Type: Failure
- Subject: `LiveSpan.from_dict(data)`
- Relation: RAISES
- Expected: `NotImplementedError` (always)
- Evidence: Interface Description 2 for `LiveSpan.from_dict`
- Observe: EXCEPTION
- Target: `LiveSpan.from_dict({})`
- Obligations: R2
- Graph: N3, N4

### C4: LiveSpan.set_span_type persists to attributes
- Type: Dataflow
- Subject: `LiveSpan.set_span_type("LLM")`
- Relation: EQ
- Expected: After call, `live_span.get_attribute(SpanAttributeKey.SPAN_TYPE)` returns `"LLM"`
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:552-554` `set_attribute`; `/testbed/mlflow/tracing/constant.py:57` `SpanAttributeKey.SPAN_TYPE`
- Observe: RETURN_VALUE
- Target: `live_span.get_attribute(SpanAttributeKey.SPAN_TYPE)`
- Obligations: R3
- Graph: N3, N5, N7, N40, E4, E5

### C5: LiveSpan.to_immutable_span returns Span
- Type: Behavior
- Subject: `LiveSpan.to_immutable_span()` return value
- Relation: TYPE_IS
- Expected: `Span` (not `LiveSpan`), with `_attributes` being `_CachedSpanAttributesRegistry`
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:101-112` `Span.__init__`
- Observe: RETURN_VALUE
- Target: `type(live_span.to_immutable_span())`
- Obligations: R4
- Graph: N3, N6, N8, N21, E6

### C6: NoOpSpan.trace_id returns constant
- Type: Behavior
- Subject: `NoOpSpan().trace_id`
- Relation: EQ
- Expected: `"MLFLOW_NO_OP_SPAN_TRACE_ID"`
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:758`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().trace_id`
- Obligations: R5
- Graph: N18, N19, E21

### C7: NoOpSpan property getters return None
- Type: Behavior
- Subject: `NoOpSpan().span_id`, `NoOpSpan().start_time_ns`, `NoOpSpan().end_time_ns`, `NoOpSpan().name`, `NoOpSpan().status`, `NoOpSpan()._trace_id`
- Relation: EQ
- Expected: `None` for each
- Evidence: Interface Description 2
- Observe: RETURN_VALUE
- Target: Each property on a `NoOpSpan()` instance
- Obligations: R5
- Graph: N18, N19, E21

### C8: NoOpSpan setters do not raise
- Type: Behavior
- Subject: `NoOpSpan().set_attribute("k", "v")`, `NoOpSpan().set_attributes({"k": "v"})`, `NoOpSpan().set_inputs({"x": 1})`, `NoOpSpan().set_outputs(42)`, `NoOpSpan().set_status(SpanStatus("OK"))`, `NoOpSpan().add_event(SpanEvent("e"))`, `NoOpSpan().end()`
- Relation: UNCHANGED
- Expected: Each call completes without exception
- Evidence: Interface Description 2; `/testbed/tests/tracing/test_fluent.py:1832-1836` tests NoOpSpan
- Observe: EXCEPTION
- Target: Each setter call on `NoOpSpan()` (no exception raised)
- Obligations: R5
- Graph: N18, N20, E22

### C9: Span.attributes returns complete attributes dict
- Type: Dataflow
- Subject: `Span.attributes`
- Relation: CONTAINS
- Expected: Dict with all OTel span attribute keys, values deserialized from JSON
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:871-879` `_SpanAttributesRegistry.get`
- Observe: RETURN_VALUE
- Target: `span.attributes`
- Obligations: R6
- Graph: N8, N9, N21, N24, E7

### C10: Span.events returns list of SpanEvent
- Type: Dataflow
- Subject: `Span.events`
- Relation: TYPE_IS
- Expected: `list[SpanEvent]` where each event has `name`, `timestamp`, and `attributes` as plain dict
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span_event.py:12-36`; tests at `/testbed/tests/litellm/test_litellm_autolog.py:89-90`
- Observe: RETURN_VALUE
- Target: `span.events`
- Obligations: R7
- Graph: N8, N10, N31, N49, E8

### C11: Span.from_otel_proto creates valid Span
- Type: Behavior
- Subject: `Span.from_otel_proto(otel_proto_span)`
- Relation: TYPE_IS
- Expected: Returns `Span` instance with correct trace_id, span_id, name, times, status, attributes, events
- Evidence: Interface Description 2; `/testbed/mlflow/entities/trace.py:240-243`
- Observe: RETURN_VALUE
- Target: `Span.from_otel_proto(proto_span)`
- Obligations: R8
- Graph: N8, N11, N39, N45, N46, E9

### C12: Span.request_id equals trace_id
- Type: Behavior
- Subject: `span.request_id`
- Relation: EQ
- Expected: `span.request_id == span.trace_id`
- Evidence: Interface Description 2; `/testbed/mlflow/entities/span.py:114-118`
- Observe: RETURN_VALUE
- Target: `span.request_id`
- Obligations: R9
- Graph: N8, N12, N17, E10

### C13: Span.span_type returns attribute value
- Type: Behavior
- Subject: `span.span_type`
- Relation: EQ
- Expected: `span.get_attribute(SpanAttributeKey.SPAN_TYPE)`
- Evidence: Interface Description 2; `/testbed/mlflow/tracing/constant.py:57`; tests at `/testbed/tests/anthropic/test_anthropic_autolog.py:187`
- Observe: RETURN_VALUE
- Target: `span.span_type`
- Obligations: R10
- Graph: N8, N13, N40, E11

### C14: Span.to_dict returns correctly structured dict
- Type: Dataflow
- Subject: `span.to_dict()` return dict keys
- Relation: CONTAINS
- Expected: Keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes` with correct types
- Evidence: Interface Description 2; `/testbed/mlflow/entities/trace_data.py:33`; `/testbed/mlflow/entities/span.py:258-329` `from_dict` is inverse
- Observe: RETURN_VALUE
- Target: `span.to_dict()`
- Obligations: R11
- Graph: N8, N14, N41, N42, E12

### C15: Span.to_dict IDs use correct base64 encoding
- Type: Dataflow
- Subject: `span.to_dict()` trace_id encoding
- Relation: EQ
- Expected: `trace_id` = `base64.b64encode(trace_id_int.to_bytes(16, "big")).decode("utf-8")`; `span_id` = `base64.b64encode(span_id_int.to_bytes(8, "big")).decode("utf-8")`
- Evidence: Interface Description 2 encoding specification
- Observe: RETURN_VALUE
- Target: `span.to_dict()["trace_id"]`
- Obligations: R11
- Graph: N8, N14, E12

### C16: Span.to_otel_proto returns OTelProtoSpan
- Type: Dataflow
- Subject: `span.to_otel_proto()` return type
- Relation: TYPE_IS
- Expected: `OTelProtoSpan` protobuf message
- Evidence: Interface Description 2; `/testbed/mlflow/entities/trace.py:237`
- Observe: RETURN_VALUE
- Target: `span.to_otel_proto()`
- Obligations: R12
- Graph: N8, N15, N27, N31, N39, E13

### C17: _CachedSpanAttributesRegistry.set raises MlflowException
- Type: Failure
- Subject: `_CachedSpanAttributesRegistry(otel_span).set("key", "value")`
- Relation: RAISES
- Expected: `MlflowException` (immutable span)
- Evidence: Interface Description 2
- Observe: EXCEPTION
- Target: `_CachedSpanAttributesRegistry(...).set("key", "value")`
- Obligations: R13
- Graph: N21, N22, E14

### C18: create_mlflow_span dispatches LiveSpan for OTelSpan
- Type: Behavior
- Subject: `create_mlflow_span(OTelSpan(...), "trace-123")`
- Relation: TYPE_IS
- Expected: Returns `LiveSpan` instance
- Evidence: Interface Description 2; `/testbed/mlflow/tracing/processor/otel.py:4,53`
- Observe: RETURN_VALUE
- Target: `type(create_mlflow_span(otel_span, trace_id))`
- Obligations: R14
- Graph: N25, N3, N8, N18, N37, E15

### C19: create_mlflow_span dispatches Span for OTelReadableSpan
- Type: Behavior
- Subject: `create_mlflow_span(OTelReadableSpan(...), "trace-123")`
- Relation: TYPE_IS
- Expected: Returns `Span` instance
- Evidence: Interface Description 2
- Observe: RETURN_VALUE
- Target: `type(create_mlflow_span(readable_span, trace_id))`
- Obligations: R14
- Graph: N25, N8, N36, E15

### C20: create_mlflow_span dispatches NoOpSpan for NonRecordingSpan/None
- Type: Behavior
- Subject: `create_mlflow_span(NonRecordingSpan(...), "trace-123")` or `create_mlflow_span(None, "trace-123")`
- Relation: TYPE_IS
- Expected: Returns `NoOpSpan` instance
- Evidence: Interface Description 2
- Observe: RETURN_VALUE
- Target: `type(create_mlflow_span(non_recording_span, trace_id))`
- Obligations: R14
- Graph: N25, N18, N38, E15

### C21: create_mlflow_span raises for invalid span type
- Type: Failure
- Subject: `create_mlflow_span("invalid", "trace-123")`
- Relation: RAISES
- Expected: `MlflowException` with `INVALID_PARAMETER_VALUE`
- Evidence: Interface Description 2
- Observe: EXCEPTION
- Target: `create_mlflow_span("invalid", trace_id)`
- Obligations: R14
- Graph: N25, E15

### C22: _decode_otel_proto_anyvalue decodes string_value
- Type: Dataflow
- Subject: `_decode_otel_proto_anyvalue(AnyValue(string_value="hello"))`
- Relation: EQ
- Expected: `"hello"`
- Evidence: Interface Description 3; `/testbed/mlflow/tracing/utils/otlp.py:122-153` inverse `_set_otel_proto_anyvalue`
- Observe: RETURN_VALUE
- Target: `_decode_otel_proto_anyvalue(pb_any_value)`
- Obligations: R15
- Graph: N26, E16

### C23: _decode_otel_proto_anyvalue decodes int_value
- Type: Dataflow
- Subject: `_decode_otel_proto_anyvalue(AnyValue(int_value=42))`
- Relation: EQ
- Expected: `42`
- Evidence: Interface Description 3
- Observe: RETURN_VALUE
- Target: `_decode_otel_proto_anyvalue(pb_any_value)`
- Obligations: R15
- Graph: N26, E16

### C24: _decode_otel_proto_anyvalue decodes array recursively
- Type: Dataflow
- Subject: `_decode_otel_proto_anyvalue(AnyValue(array_value=...))` with values `[1, "a"]`
- Relation: EQ
- Expected: `[1, "a"]`
- Evidence: Interface Description 3
- Observe: RETURN_VALUE
- Target: `_decode_otel_proto_anyvalue(pb_any_value)`
- Obligations: R15
- Graph: N26, E16

### C25: _decode_otel_proto_anyvalue decodes kvlist to dict
- Type: Dataflow
- Subject: `_decode_otel_proto_anyvalue(AnyValue(kvlist_value=...))` with `{"x": 1}`
- Relation: EQ
- Expected: `{"x": 1}`
- Evidence: Interface Description 3
- Observe: RETURN_VALUE
- Target: `_decode_otel_proto_anyvalue(pb_any_value)`
- Obligations: R15
- Graph: N26, E16

### C26: SpanStatus.to_otel_status converts to OTel Status
- Type: Dataflow
- Subject: `SpanStatus(SpanStatusCode.OK, "desc").to_otel_status()`
- Relation: EQ
- Expected: OTel `Status` with `StatusCode.OK` and description `"desc"`
- Evidence: `/testbed/mlflow/entities/span.py:578` calls `status.to_otel_status()`; `/testbed/mlflow/entities/span.py:310` calls `status.to_otel_status()`
- Observe: RETURN_VALUE
- Target: `SpanStatus(SpanStatusCode.OK).to_otel_status()`
- Obligations: R16
- Graph: N28, N29, N50, E17

### C27: SpanStatus.from_otel_status converts from OTel Status
- Type: Dataflow
- Subject: `SpanStatus.from_otel_status(otel_status)`
- Relation: EQ
- Expected: Returns `SpanStatus` with matching code and description
- Evidence: `/testbed/mlflow/entities/span.py:155` calls `SpanStatus.from_otel_status(self._span.status)`
- Observe: RETURN_VALUE
- Target: `SpanStatus.from_otel_status(otel_status)`
- Obligations: R16
- Graph: N28, N30, N50, E18

### C28: Span.from_dict round-trips with to_dict
- Type: Dataflow
- Subject: `Span.from_dict(span.to_dict())`
- Relation: PRESERVE
- Expected: All span fields (name, trace_id, span_id, start_time_ns, end_time_ns, status, attributes, events) are preserved
- Evidence: `/testbed/mlflow/entities/span.py:258-329` `from_dict`; `/testbed/mlflow/entities/trace_data.py:33` `to_dict`
- Observe: RETURN_VALUE
- Target: `Span.from_dict(span.to_dict()).to_dict()`
- Obligations: R11, R17
- Graph: N8, N14, N16, N51, N52, N53, N54, E12, E19, E20

### C29: NoOpSpan.end accepts all parameters silently
- Type: Behavior
- Subject: `NoOpSpan().end(outputs={"x": 1}, attributes={"k": "v"}, status="OK", end_time_ns=123)`
- Relation: UNCHANGED
- Expected: No error raised, no state change
- Evidence: Interface Description 2
- Observe: EXCEPTION
- Target: `NoOpSpan().end(outputs=..., attributes=..., status=..., end_time_ns=...)`
- Obligations: R5
- Graph: N18, N20, E22
