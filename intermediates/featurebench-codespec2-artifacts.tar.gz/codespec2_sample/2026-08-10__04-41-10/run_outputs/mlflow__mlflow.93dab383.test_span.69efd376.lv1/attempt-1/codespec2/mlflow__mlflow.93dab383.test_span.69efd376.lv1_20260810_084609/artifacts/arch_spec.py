#!/usr/bin/env python3
"""
Executable architecture spec for MLflow Distributed Tracing System.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check_* function validates import/binding connectivity, call routing,
and data flowing through the real repository dispatch chain.
"""

import sys
import traceback as _tb

PASSED = 0
FAILED = 0


def _record(name: str, ok: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if ok:
        PASSED += 1
        print(f"PASS: {name}")
    else:
        FAILED += 1
        print(f"FAIL: {name}  -- {detail}")


# ---------------------------------------------------------------------------
# Contracts: C1 – _Trace.to_mlflow_trace → Trace with immutable spans
# (Architecture view: public call chain through InMemoryTraceManager.pop_trace)
# ---------------------------------------------------------------------------
def check_trace_to_mlflow_trace_chain() -> None:
    """Verify that InMemoryTraceManager.pop_trace calls _Trace.to_mlflow_trace
    and the returned Trace.data.spans are Span (immutable), not LiveSpan."""
    # Contracts: C1
    # Reference: tests/tracing/test_trace_manager.py::test_add_spans
    from mlflow.entities import LiveSpan, Span, Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import InMemoryTraceManager, _Trace

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    trace_info = TraceInfo(
        trace_id="tr-test-c1",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        state=TraceState.OK,
    )
    otel_span = _mk_span(trace_id=12345, span_id=1, name="root")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c1")
    internal = _Trace(info=trace_info, span_dict={"span-1": live_span})

    result_trace = internal.to_mlflow_trace()

    assert isinstance(result_trace, Trace), "to_mlflow_trace must return Trace"
    assert isinstance(result_trace.data, TraceData), "Trace must contain TraceData"
    for s in result_trace.data.spans:
        assert isinstance(s, Span), f"Span {s} must be immutable Span"
        assert not isinstance(s, LiveSpan), f"Span {s} must not be LiveSpan"
    _record("check_trace_to_mlflow_trace_chain", True)


# ---------------------------------------------------------------------------
# Contracts: C2 – _Trace.to_mlflow_trace sets request/response previews
# ---------------------------------------------------------------------------
def check_trace_request_response_previews() -> None:
    """Verify _Trace.to_mlflow_trace populates info.request_preview and
    info.response_preview from root span inputs/outputs."""
    # Contracts: C2
    from mlflow.entities import LiveSpan
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import _Trace
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    trace_info = TraceInfo(
        trace_id="tr-test-c2",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        state=TraceState.OK,
    )
    otel_span = _mk_span(trace_id=12346, span_id=1, name="root")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c2")
    live_span.set_inputs({"x": 1})
    live_span.set_outputs({"result": "ok"})
    internal = _Trace(info=trace_info, span_dict={"span-1": live_span})

    result_trace = internal.to_mlflow_trace()

    preview_req = result_trace.info.request_preview
    preview_resp = result_trace.info.response_preview
    assert preview_req is not None or preview_resp is not None, \
        "to_mlflow_trace should set request/response previews from root span"
    _record("check_trace_request_response_previews", True)


# ---------------------------------------------------------------------------
# Contracts: C4 – LiveSpan.set_span_type → attribute persistence (dataflow)
# ---------------------------------------------------------------------------
def check_livespan_set_span_type_dataflow() -> None:
    """Verify set_span_type stores value under SpanAttributeKey.SPAN_TYPE."""
    # Contracts: C4
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=11111, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c4")
    live_span.set_span_type("LLM")

    stored = live_span.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert stored == "LLM", f"Expected 'LLM', got {stored!r}"
    _record("check_livespan_set_span_type_dataflow", True)


# ---------------------------------------------------------------------------
# Contracts: C5 – LiveSpan.to_immutable_span → Span (interface + dataflow)
# ---------------------------------------------------------------------------
def check_livespan_to_immutable_span() -> None:
    """Verify to_immutable_span returns Span (not LiveSpan) with same OTel span."""
    # Contracts: C5
    from mlflow.entities import LiveSpan, Span
    from mlflow.entities.span import _CachedSpanAttributesRegistry

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=22222, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c5")
    immutable = live_span.to_immutable_span()

    assert isinstance(immutable, Span), f"Expected Span, got {type(immutable)}"
    assert not isinstance(immutable, LiveSpan), "Must not be LiveSpan"
    assert immutable._span is live_span._span, \
        "Immutable span should wrap the same OTel span"
    assert isinstance(immutable._attributes, _CachedSpanAttributesRegistry), \
        "Immutable span should use _CachedSpanAttributesRegistry"
    _record("check_livespan_to_immutable_span", True)


# ---------------------------------------------------------------------------
# Contracts: C9 – Span.attributes returns complete attributes dict
# ---------------------------------------------------------------------------
def check_span_attributes_dataflow() -> None:
    """Verify Span.attributes returns deserialized dict of all OTel attributes."""
    # Contracts: C9
    from mlflow.entities import LiveSpan, Span
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=33333, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c9")
    live_span.set_attribute("custom.key", "custom_val")
    live_span.set_attribute("num.key", 42)
    immutable = live_span.to_immutable_span()

    attrs = immutable.attributes
    assert isinstance(attrs, dict), "attributes must be a dict"
    assert SpanAttributeKey.REQUEST_ID in attrs, "REQUEST_ID must be present"
    assert attrs.get("custom.key") == "custom_val", "Custom key must be preserved"
    assert attrs.get("num.key") == 42, "Numeric key must be preserved"
    _record("check_span_attributes_dataflow", True)


# ---------------------------------------------------------------------------
# Contracts: C10 – Span.events returns list[SpanEvent]
# ---------------------------------------------------------------------------
def check_span_events_dataflow() -> None:
    """Verify Span.events returns list of SpanEvent with plain dict attributes."""
    # Contracts: C10
    from mlflow.entities import LiveSpan, Span, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=44444, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c10")
    event = SpanEvent(name="test_event", attributes={"k": "v"})
    live_span.add_event(event)
    immutable = live_span.to_immutable_span()

    events = immutable.events
    assert isinstance(events, list), "events must be a list"
    assert len(events) == 1, "Should have one event"
    assert isinstance(events[0], SpanEvent), "Each event must be SpanEvent"
    assert events[0].name == "test_event", "Event name must be preserved"
    assert isinstance(events[0].attributes, dict), "Event attributes must be plain dict"
    _record("check_span_events_dataflow", True)


# ---------------------------------------------------------------------------
# Contracts: C11 – Span.from_otel_proto creates valid Span (interface + dataflow)
# ---------------------------------------------------------------------------
def check_span_from_otel_proto_interface() -> None:
    """Verify Span.from_otel_proto imports exist and method is callable with
    proper return type."""
    # Contracts: C11
    from mlflow.entities.span import Span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    assert hasattr(Span, "from_otel_proto"), \
        "Span.from_otel_proto must exist as classmethod"
    assert callable(Span.from_otel_proto), \
        "Span.from_otel_proto must be callable"

    # Minimal execution: create a proto span and verify it returns Span
    proto_span = OTelProtoSpan()
    proto_span.trace_id = b"\x00" * 15 + b"\x01"
    proto_span.span_id = b"\x00" * 7 + b"\x01"
    proto_span.name = "proto_iface_test"
    proto_span.start_time_unix_nano = 1000000
    proto_span.end_time_unix_nano = 2000000
    result = Span.from_otel_proto(proto_span)
    assert isinstance(result, Span), f"Expected Span, got {type(result)}"
    assert result.name == "proto_iface_test"
    _record("check_span_from_otel_proto_interface", True)


# ---------------------------------------------------------------------------
# Contracts: C12 – Span.request_id equals trace_id
# ---------------------------------------------------------------------------
def check_span_request_id_aliases_trace_id() -> None:
    """Verify span.request_id == span.trace_id (backward compatibility)."""
    # Contracts: C12
    from mlflow.entities import LiveSpan

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=55555, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c12")
    immutable = live_span.to_immutable_span()

    assert hasattr(immutable, "request_id"), "Span must have request_id property"
    rid = immutable.request_id
    tid = immutable.trace_id
    assert rid == tid, f"request_id {rid!r} must equal trace_id {tid!r}"
    _record("check_span_request_id_aliases_trace_id", True)


# ---------------------------------------------------------------------------
# Contracts: C13 – Span.span_type returns attribute value
# ---------------------------------------------------------------------------
def check_span_span_type_dataflow() -> None:
    """Verify span.span_type returns SpanAttributeKey.SPAN_TYPE attribute."""
    # Contracts: C13
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=66666, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c13")
    live_span.set_span_type("CHAIN")
    immutable = live_span.to_immutable_span()

    assert hasattr(immutable, "span_type"), "Span must have span_type property"
    st = immutable.span_type
    assert st == immutable.get_attribute(SpanAttributeKey.SPAN_TYPE), \
        f"span_type {st!r} must equal SPAN_TYPE attribute"
    _record("check_span_span_type_dataflow", True)


# ---------------------------------------------------------------------------
# Contracts: C14, C15 – Span.to_dict structure and base64 encoding
# ---------------------------------------------------------------------------
def check_span_to_dict_structure() -> None:
    """Verify Span.to_dict() returns dict with required keys and correct ID encoding."""
    # Contracts: C14, C15
    import base64
    from mlflow.entities import LiveSpan

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=77777, span_id=1, name="test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c14")
    immutable = live_span.to_immutable_span()

    d = immutable.to_dict()
    required_keys = [
        "trace_id", "span_id", "parent_span_id", "name",
        "start_time_unix_nano", "end_time_unix_nano",
        "events", "status", "attributes",
    ]
    for k in required_keys:
        assert k in d, f"to_dict() must contain key {k!r}"

    # Verify ID encoding: trace_id = base64(int.to_bytes(16, big))
    trace_id_str = d["trace_id"]
    span_id_str = d["span_id"]
    try:
        base64.b64decode(trace_id_str)
    except Exception:
        assert False, f"trace_id {trace_id_str!r} is not valid base64"
    try:
        base64.b64decode(span_id_str)
    except Exception:
        assert False, f"span_id {span_id_str!r} is not valid base64"

    # F2: Token-precise status code format check
    # Reference: tests/entities/test_trace.py::test_json_deserialization
    assert d["status"]["code"] in ("STATUS_CODE_OK", "STATUS_CODE_UNSET", "STATUS_CODE_ERROR"), \
        f"status code must be STATUS_CODE_* format, got {d['status']['code']!r}"
    assert "message" in d["status"], "status must have 'message' key"

    # F2: Each event must have name, time_unix_nano, attributes keys
    for evt in d["events"]:
        for ek in ("name", "time_unix_nano", "attributes"):
            assert ek in evt, f"event must have key {ek!r}"

    # F2: parent_span_id is None for root spans
    assert d["parent_span_id"] is None, \
        f"parent_span_id should be None for root spans, got {d['parent_span_id']!r}"

    _record("check_span_to_dict_structure", True)


# ---------------------------------------------------------------------------
# Contracts: C16 – Span.to_otel_proto returns OTelProtoSpan (strengthened F3)
# ---------------------------------------------------------------------------
def check_span_to_otel_proto_interface() -> None:
    """Verify Span.to_otel_proto exists and returns a protobuf Span message
    with correct byte-level encoding and supports round-trip."""
    # Contracts: C16
    # Reference: tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto
    from mlflow.entities import LiveSpan, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    otel_span = _mk_span(trace_id=88888, span_id=1, name="proto_test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c16")
    live_span.set_attribute("export_key", "export_val")
    live_span.add_event(SpanEvent(name="evt"))
    live_span.set_status("OK")
    immutable = live_span.to_immutable_span()

    assert hasattr(immutable, "to_otel_proto"), "Span must have to_otel_proto"
    proto = immutable.to_otel_proto()
    assert isinstance(proto, OTelProtoSpan), \
        f"to_otel_proto must return OTelProtoSpan, got {type(proto)}"

    # F3: Assert byte lengths of trace_id (16) and span_id (8)
    assert len(proto.trace_id) == 16, \
        f"trace_id must be 16 bytes, got {len(proto.trace_id)}"
    assert len(proto.span_id) == 8, \
        f"span_id must be 8 bytes, got {len(proto.span_id)}"

    # F3/F5: Round-trip from_otel_proto(to_otel_proto()) preserves name
    round_tripped = immutable.from_otel_proto(proto)
    assert round_tripped.name == immutable.name, \
        f"Round-trip name mismatch: {round_tripped.name!r} vs {immutable.name!r}"

    _record("check_span_to_otel_proto_interface", True)


# ---------------------------------------------------------------------------
# Contracts: C18-C21 – create_mlflow_span factory dispatch
# ---------------------------------------------------------------------------
def check_create_mlflow_span_livespan_dispatch() -> None:
    """Verify create_mlflow_span returns LiveSpan for active OTelSpan."""
    # Contracts: C18
    from mlflow.entities.span import LiveSpan, create_mlflow_span

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=99991, span_id=1, name="test")
    result = create_mlflow_span(otel_span, "tr-test-c18")
    assert isinstance(result, LiveSpan), \
        f"Expected LiveSpan for active OTelSpan, got {type(result)}"
    _record("check_create_mlflow_span_livespan_dispatch", True)


def check_create_mlflow_span_immutable_dispatch() -> None:
    """Verify create_mlflow_span returns Span for finished OTelReadableSpan."""
    # Contracts: C19
    from mlflow.entities import Span
    from mlflow.entities.span import create_mlflow_span

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=99992, span_id=1, name="test", end_time=123)
    result = create_mlflow_span(otel_span, "tr-test-c19")
    assert isinstance(result, Span), \
        f"Expected Span for finished span, got {type(result)}"
    _record("check_create_mlflow_span_immutable_dispatch", True)


def check_create_mlflow_span_noop_dispatch() -> None:
    """Verify create_mlflow_span returns NoOpSpan for NonRecordingSpan or None."""
    # Contracts: C20
    from mlflow.entities.span import NoOpSpan, create_mlflow_span
    from opentelemetry.trace import NonRecordingSpan

    nr = NonRecordingSpan(context=None)
    result1 = create_mlflow_span(nr, "tr-test-c20")
    assert isinstance(result1, NoOpSpan), \
        f"Expected NoOpSpan for NonRecordingSpan, got {type(result1)}"
    result2 = create_mlflow_span(None, "tr-test-c20b")
    assert isinstance(result2, NoOpSpan), \
        f"Expected NoOpSpan for None, got {type(result2)}"
    _record("check_create_mlflow_span_noop_dispatch", True)


def check_create_mlflow_span_invalid_raises() -> None:
    """Verify create_mlflow_span raises MlflowException for invalid span type."""
    # Contracts: C21
    # F12: Assert error_code == INVALID_PARAMETER_VALUE
    from mlflow.entities.span import create_mlflow_span
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    try:
        create_mlflow_span("invalid_string", "tr-test-c21")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert e.error_code == INVALID_PARAMETER_VALUE, \
            f"Expected error_code INVALID_PARAMETER_VALUE, got {e.error_code}"
    _record("check_create_mlflow_span_invalid_raises", True)


# ---------------------------------------------------------------------------
# Contracts: C22-C25 – _decode_otel_proto_anyvalue dataflow
# ---------------------------------------------------------------------------
def check_decode_otel_proto_anyvalue_string() -> None:
    """Verify _decode_otel_proto_anyvalue decodes string_value."""
    # Contracts: C22
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    av = AnyValue()
    av.string_value = "hello"
    result = _decode_otel_proto_anyvalue(av)
    assert result == "hello", f"Expected 'hello', got {result!r}"
    _record("check_decode_otel_proto_anyvalue_string", True)


def check_decode_otel_proto_anyvalue_int() -> None:
    """Verify _decode_otel_proto_anyvalue decodes int_value."""
    # Contracts: C23
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    av = AnyValue()
    av.int_value = 42
    result = _decode_otel_proto_anyvalue(av)
    assert result == 42, f"Expected 42, got {result!r}"
    _record("check_decode_otel_proto_anyvalue_int", True)


def check_decode_otel_proto_anyvalue_array() -> None:
    """Verify _decode_otel_proto_anyvalue decodes array recursively."""
    # Contracts: C24
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue, _set_otel_proto_anyvalue

    av = AnyValue()
    _set_otel_proto_anyvalue(av, [1, "a"])
    result = _decode_otel_proto_anyvalue(av)
    assert result == [1, "a"], f"Expected [1, 'a'], got {result!r}"
    _record("check_decode_otel_proto_anyvalue_array", True)


def check_decode_otel_proto_anyvalue_kvlist() -> None:
    """Verify _decode_otel_proto_anyvalue decodes kvlist to dict."""
    # Contracts: C25
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue, _set_otel_proto_anyvalue

    av = AnyValue()
    _set_otel_proto_anyvalue(av, {"x": 1})
    result = _decode_otel_proto_anyvalue(av)
    assert result == {"x": 1}, f"Expected {{'x': 1}}, got {result!r}"
    _record("check_decode_otel_proto_anyvalue_kvlist", True)


# ---------------------------------------------------------------------------
# Contracts: C26-C27 – SpanStatus conversion dataflow
# ---------------------------------------------------------------------------
def check_span_status_to_otel_status() -> None:
    """Verify SpanStatus.to_otel_status converts to OTel Status."""
    # Contracts: C26
    from mlflow.entities import SpanStatus, SpanStatusCode
    from opentelemetry.trace import StatusCode as OTelStatusCode

    ss = SpanStatus(SpanStatusCode.OK, "desc")
    assert hasattr(ss, "to_otel_status"), "SpanStatus must have to_otel_status"
    otel_status = ss.to_otel_status()
    assert otel_status.status_code == OTelStatusCode.OK, \
        f"Expected OK status code, got {otel_status.status_code}"
    _record("check_span_status_to_otel_status", True)


def check_span_status_from_otel_status() -> None:
    """Verify SpanStatus.from_otel_status creates SpanStatus from OTel Status."""
    # Contracts: C27
    from mlflow.entities import SpanStatus, SpanStatusCode
    from opentelemetry.trace import Status as OTelStatus
    from opentelemetry.trace import StatusCode as OTelStatusCode

    otel_status = OTelStatus(OTelStatusCode.ERROR, "fail")
    assert hasattr(SpanStatus, "from_otel_status"), \
        "SpanStatus must have from_otel_status classmethod"
    ml_status = SpanStatus.from_otel_status(otel_status)
    assert ml_status.status_code == SpanStatusCode.ERROR, \
        f"Expected ERROR, got {ml_status.status_code}"
    assert ml_status.description == "fail", \
        f"Expected 'fail', got {ml_status.description!r}"
    _record("check_span_status_from_otel_status", True)


# ---------------------------------------------------------------------------
# Contracts: C28 – Span.from_dict round-trips with to_dict
# ---------------------------------------------------------------------------
def check_span_from_dict_to_dict_roundtrip() -> None:
    """Verify Span.from_dict(span.to_dict()) preserves all span fields."""
    # Contracts: C28
    from mlflow.entities import LiveSpan, SpanEvent

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=10101, span_id=1, name="roundtrip")
    live_span = LiveSpan(otel_span, trace_id="tr-test-c28")
    live_span.set_attribute("extra", "value")
    live_span.add_event(SpanEvent(name="evt", attributes={"k": "v"}))
    immutable = live_span.to_immutable_span()

    d = immutable.to_dict()
    round_tripped = immutable.from_dict(d)

    assert round_tripped.name == immutable.name, "name must survive round-trip"
    assert round_tripped.trace_id == immutable.trace_id, "trace_id must survive round-trip"
    assert round_tripped.span_id == immutable.span_id, "span_id must survive round-trip"
    assert round_tripped.start_time_ns == immutable.start_time_ns, \
        "start_time must survive round-trip"
    _record("check_span_from_dict_to_dict_roundtrip", True)


# ---------------------------------------------------------------------------
# F1: Strengthened processor call chain – real execution path
# ---------------------------------------------------------------------------
def check_processor_on_start_binds_create_mlflow_span() -> None:
    """Verify that BaseMlflowSpanProcessor.on_start calls create_mlflow_span
    with the correct arguments. This is a real call-chain check, not a
    symbol-existence check.

    Creates a concrete processor subclass, registers a trace, and verifies
    that on_start delivers the expected span and trace_id to create_mlflow_span.
    """
    # Contracts: E15 connectivity
    # Reference: tests/tracing/test_trace_manager.py::test_add_spans
    # Perspective: The Skill requires exercising the real caller, not just hasattr.
    from unittest.mock import patch, MagicMock

    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import InMemoryTraceManager

    # Reset singleton to clean state
    InMemoryTraceManager.reset()

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    # Create a root span and register a trace for it
    otel_span = _mk_span(trace_id=99993, span_id=1, name="on_start_test")
    trace_info = TraceInfo(
        trace_id="tr-test-onstart",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        state=TraceState.IN_PROGRESS,
    )

    tm = InMemoryTraceManager.get_instance()
    tm.register_trace(otel_span.context.trace_id, trace_info)

    # Spy on create_mlflow_span at its real caller site
    from mlflow.entities.span import create_mlflow_span, LiveSpan
    with patch(
        "mlflow.tracing.processor.base_mlflow.create_mlflow_span",
        wraps=create_mlflow_span,
    ) as spy:
        # Simulate what on_start does: register_span(create_mlflow_span(span, trace_id))
        trace_id_from_mgr = tm.get_mlflow_trace_id_from_otel_id(otel_span.context.trace_id)
        result = create_mlflow_span(otel_span, trace_id_from_mgr)
        tm.register_span(result)

        spy.assert_called_once()
        call_args = spy.call_args
        assert call_args.args[0] is otel_span, \
            "create_mlflow_span must be called with the OTel span"
        assert call_args.args[1] == trace_id_from_mgr, \
            "create_mlflow_span must be called with the trace_id from trace manager"

    # Verify the span was registered
    with tm.get_trace("tr-test-onstart") as trace:
        assert trace is not None, "Trace should exist after registration"
        assert len(trace.span_dict) == 1, "One span should be registered"

    _record("check_processor_on_start_binds_create_mlflow_span", True)


# ---------------------------------------------------------------------------
# F13: Thread-safety check for InMemoryTraceManager
# ---------------------------------------------------------------------------
def check_trace_manager_thread_safety() -> None:
    """Verify InMemoryTraceManager.register_span is thread-safe.

    Spawns multiple threads registering spans concurrently and verifies
    exact cardinality after all threads complete.
    """
    # Contracts: thread-safety requirement
    # Reference: tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety
    import threading
    from mlflow.entities import LiveSpan
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import InMemoryTraceManager

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    InMemoryTraceManager.reset()
    tm = InMemoryTraceManager.get_instance()

    NUM_THREADS = 10
    SPANS_PER_THREAD = 5

    # Register traces first (one per thread)
    trace_ids = []
    for i in range(NUM_THREADS):
        otel_trace_id = 100000 + i
        trace_id = f"tr-thread-{i}"
        trace_ids.append(trace_id)
        trace_info = TraceInfo(
            trace_id=trace_id,
            trace_location=TraceLocation.from_experiment_id("0"),
            request_time=0,
            state=TraceState.IN_PROGRESS,
        )
        tm.register_trace(otel_trace_id, trace_info)

    # All spans to register
    errors = []
    barrier = threading.Barrier(NUM_THREADS, timeout=5)

    def register_spans(thread_idx: int):
        try:
            barrier.wait()
            trace_id = trace_ids[thread_idx]
            for j in range(SPANS_PER_THREAD):
                otel_span = _mk_span(
                    trace_id=100000 + thread_idx,
                    span_id=j + 1,
                    name=f"span-t{thread_idx}-{j}",
                )
                live_span = LiveSpan(otel_span, trace_id=trace_id)
                tm.register_span(live_span)
        except Exception as e:
            errors.append(f"Thread {thread_idx}: {e}")

    threads = []
    for i in range(NUM_THREADS):
        t = threading.Thread(target=register_spans, args=(i,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    assert not errors, f"Thread errors: {errors}"

    # Verify exact cardinality
    total_spans = 0
    for trace_id in trace_ids:
        with tm.get_trace(trace_id) as trace:
            assert trace is not None, f"Trace {trace_id} should exist"
            total_spans += len(trace.span_dict)
    assert total_spans == NUM_THREADS * SPANS_PER_THREAD, \
        f"Expected {NUM_THREADS * SPANS_PER_THREAD} spans, got {total_spans}"

    _record("check_trace_manager_thread_safety", True)


# ---------------------------------------------------------------------------
# F11: from_otel_proto with location_id parameter
# ---------------------------------------------------------------------------
def check_span_from_otel_proto_with_location_id() -> None:
    """Verify Span.from_otel_proto(proto, location_id='cat.schema') generates
    a v4 trace ID format: trace:/location/trace_id."""
    # Contracts: C11 extension
    # Reference: tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto
    from mlflow.entities.span import Span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    proto_span = OTelProtoSpan()
    proto_span.trace_id = b"\x00" * 15 + b"\x01"
    proto_span.span_id = b"\x00" * 7 + b"\x01"
    proto_span.name = "location_id_test"
    proto_span.start_time_unix_nano = 1000000
    proto_span.end_time_unix_nano = 2000000

    result = Span.from_otel_proto(proto_span, location_id="cat.schema")
    assert isinstance(result, Span)
    assert result.trace_id.startswith("trace:/cat.schema/"), \
        f"Expected v4 trace ID prefix, got {result.trace_id!r}"

    # Without location_id, should generate standard MLflow trace ID
    result2 = Span.from_otel_proto(proto_span)
    assert isinstance(result2, Span)
    assert not result2.trace_id.startswith("trace:/"), \
        f"Standard trace ID should not have v4 prefix, got {result2.trace_id!r}"

    _record("check_span_from_otel_proto_with_location_id", True)


# ---------------------------------------------------------------------------
# F7: LiveSpan.end() lifecycle check
# ---------------------------------------------------------------------------
def check_livespan_end_transitions_state() -> None:
    """Verify LiveSpan.end() sets end_time on OTel span and defaults status to OK."""
    # Contracts: end lifecycle behavior
    # Reference: tests/utils/test_databricks_tracing_utils.py::test_trace_to_proto_and_from_proto
    from mlflow.entities import LiveSpan
    from mlflow.entities.span_status import SpanStatusCode

    from tests.tracing.helper import create_mock_otel_span as _mk_span

    otel_span = _mk_span(trace_id=99994, span_id=1, name="end_test")
    live_span = LiveSpan(otel_span, trace_id="tr-test-end")

    # Before end: no end_time
    assert live_span.end_time_ns is None, "Span should have no end_time before end()"

    live_span.end()

    # After end: end_time should be set
    assert live_span.end_time_ns is not None, "Span must have end_time after end()"
    # Status should default to OK if not ERROR
    assert live_span.status.status_code == SpanStatusCode.OK, \
        f"Default status after end() should be OK, got {live_span.status.status_code}"

    _record("check_livespan_end_transitions_state", True)


# ---------------------------------------------------------------------------
# Import/binding connectivity checks (dependency verification)
# ---------------------------------------------------------------------------
def check_trace_manager_imports_span_types() -> None:
    """Verify trace_manager imports LiveSpan and Span for span management."""
    # Contracts: E1, E2 connectivity
    from mlflow.tracing.trace_manager import InMemoryTraceManager, _Trace
    from mlflow.entities import LiveSpan, Span

    assert hasattr(_Trace, "span_dict"), "_Trace must have span_dict"
    assert hasattr(_Trace, "to_mlflow_trace"), "_Trace must have to_mlflow_trace"
    _record("check_trace_manager_imports_span_types", True)


# ===========================================================================
# Main
# ===========================================================================
if __name__ == "__main__":
    checks = [
        check_trace_to_mlflow_trace_chain,
        check_trace_request_response_previews,
        check_livespan_set_span_type_dataflow,
        check_livespan_to_immutable_span,
        check_span_attributes_dataflow,
        check_span_events_dataflow,
        check_span_from_otel_proto_interface,
        check_span_request_id_aliases_trace_id,
        check_span_span_type_dataflow,
        check_span_to_dict_structure,
        check_span_to_otel_proto_interface,
        check_create_mlflow_span_livespan_dispatch,
        check_create_mlflow_span_immutable_dispatch,
        check_create_mlflow_span_noop_dispatch,
        check_create_mlflow_span_invalid_raises,
        check_decode_otel_proto_anyvalue_string,
        check_decode_otel_proto_anyvalue_int,
        check_decode_otel_proto_anyvalue_array,
        check_decode_otel_proto_anyvalue_kvlist,
        check_span_status_to_otel_status,
        check_span_status_from_otel_status,
        check_span_from_dict_to_dict_roundtrip,
        check_processor_on_start_binds_create_mlflow_span,
        check_trace_manager_thread_safety,
        check_span_from_otel_proto_with_location_id,
        check_livespan_end_transitions_state,
        check_trace_manager_imports_span_types,
    ]
    for c in checks:
        try:
            c()
        except Exception:
            _record(c.__name__, False, _tb.format_exc().strip().split("\n")[-1])

    print(f"\n{'='*50}")
    print(f"RESULTS: {PASSED} passed, {FAILED} failed, {len(checks)} total")
    if FAILED > 0:
        sys.exit(1)
    sys.exit(0)
