"""
Executable behavior spec for MLflow GenAI scorers validation system.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility contracts. Each ``check_*`` function validates a
contract ID and exits with a clear message on failure. Every contract
referenced is annotated with ``# Contracts: C<n>``.
"""

from __future__ import annotations

import io
import logging
import sys
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

import mlflow
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException
from mlflow.utils.uri import is_databricks_uri


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fail(msg: str) -> None:
    print(f"FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# C2: CustomScorer.kind returns DECORATOR
# ---------------------------------------------------------------------------


# Contracts: C2
def check_custom_scorer_kind_is_decorator() -> None:
    """C2: A @scorer-decorated function has kind == ScorerKind.DECORATOR."""
    @scorer
    def simple_scorer(outputs: str) -> str:
        return outputs

    kind = simple_scorer.kind
    if kind != ScorerKind.DECORATOR:
        _fail(f"C2: expected kind=DECORATOR, got {kind}")
    print("PASS: C2 - CustomScorer.kind returns ScorerKind.DECORATOR")


# ---------------------------------------------------------------------------
# C3: CustomScorer.__call__ delegates to original function
# ---------------------------------------------------------------------------


# Contracts: C3
def check_custom_scorer_call_delegates_to_original() -> None:
    """C3: Calling the scorer invokes the original decorated function."""
    call_record = []

    @scorer
    def tracking_scorer(inputs, outputs) -> str:
        call_record.append({"inputs": inputs, "outputs": outputs})
        return "scored"

    result = tracking_scorer(inputs="hello", outputs="world")
    if result != "scored":
        _fail(f"C3: expected 'scored', got {result!r}")
    if len(call_record) != 1:
        _fail(f"C3: original function not called (call_record={call_record})")
    if call_record[0] != {"inputs": "hello", "outputs": "world"}:
        _fail(f"C3: wrong arguments passed to original: {call_record[0]}")
    print("PASS: C3 - CustomScorer.__call__ delegates to original function")


# ---------------------------------------------------------------------------
# C5: validate_scorers rejects non-list input
# ---------------------------------------------------------------------------


# Contracts: C5
# Reference: /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 35-40
def check_validate_scorers_rejects_non_list() -> None:
    """C5: Passing a non-list to validate_scorers raises MlflowException.

    Asserts the exact phrase "must be a list of scorers" from the reference impl.
    """
    from mlflow.genai.scorers.validation import validate_scorers

    try:
        validate_scorers("not_a_list")
    except MlflowException as e:
        msg = str(e)
        if "must be a list of scorers" not in msg:
            _fail(f"C5: exception message missing 'must be a list of scorers': {e}")
    else:
        _fail("C5: validate_scorers did not raise for non-list input")
    print("PASS: C5 - validate_scorers rejects non-list input")


# ---------------------------------------------------------------------------
# C6: validate_scorers accepts empty list
# ---------------------------------------------------------------------------


# Contracts: C6
def check_validate_scorers_accepts_empty_list() -> None:
    """C6: validate_scorers([]) returns []."""
    from mlflow.genai.scorers.validation import validate_scorers

    result = validate_scorers([])
    if result != []:
        _fail(f"C6: expected [], got {result!r}")
    print("PASS: C6 - validate_scorers accepts and returns empty list")


# ---------------------------------------------------------------------------
# C7: validate_scorers accepts Scorer instances
# ---------------------------------------------------------------------------


# Contracts: C7
def check_validate_scorers_accepts_scorer_instances() -> None:
    """C7: validate_scorers returns the same list of Scorer instances."""
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    scorer_inst = Correctness()
    result = validate_scorers([scorer_inst])
    if result != [scorer_inst]:
        _fail(f"C7: expected same list, got {result!r}")
    print("PASS: C7 - validate_scorers accepts Scorer instances unchanged")


# ---------------------------------------------------------------------------
# C8: validate_scorers raises with hint for class-not-instance
# ---------------------------------------------------------------------------


# Contracts: C8
# Reference: /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 83-87
def check_validate_scorers_hints_class_not_instance() -> None:
    """C8: Passing a class (not instance) raises with helpful hint.

    Asserts the exact phrase "class instead of an instance" from the reference impl.
    """
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    try:
        validate_scorers([Correctness])  # class, not instance
    except MlflowException as e:
        msg = str(e)
        if "class instead of an instance" not in msg:
            _fail(f"C8: exception should contain 'class instead of an instance': {e}")
    else:
        _fail("C8: validate_scorers did not raise for class-not-instance")
    print("PASS: C8 - validate_scorers hints when class passed instead of instance")


# ---------------------------------------------------------------------------
# E7: validate_scorers accepts legacy Metric (F3)
# ---------------------------------------------------------------------------


# Contracts: E7 (L2 edge)
# Reference: /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 59-65
def check_validate_scorers_accepts_legacy_metric() -> None:
    """E7: When databricks.agents is installed, legacy Metric objects are accepted.

    Mocks IS_DBX_AGENTS_INSTALLED=True and passes a Metric-compatible mock.
    Asserts no exception is raised.
    """
    from mlflow.genai.scorers.validation import validate_scorers

    legacy_metric = MagicMock()
    legacy_metric.name = "legacy_metric"

    with patch("mlflow.genai.scorers.validation.IS_DBX_AGENTS_INSTALLED", True), \
         patch("databricks.rag_eval.evaluation.metrics.Metric", create=True) as MockMetric:
        # Make isinstance check pass
        MockMetric.__instancecheck__ = lambda self, obj: obj is legacy_metric
        # Re-patch isinstance behavior
        import builtins
        original_isinstance = builtins.isinstance

        def custom_isinstance(obj, classinfo):
            if classinfo is MockMetric and obj is legacy_metric:
                return True
            return original_isinstance(obj, classinfo)

        with patch("builtins.isinstance", side_effect=custom_isinstance):
            result = validate_scorers([legacy_metric])

    if legacy_metric not in result:
        _fail("E7: legacy Metric was not included in returned scorers")

    print("PASS: E7 - validate_scorers accepts legacy Metric when databricks.agents installed")


# ---------------------------------------------------------------------------
# E8: validate_scorers hint for scorers=[get_all_scorers()] (F3)
# ---------------------------------------------------------------------------


# Contracts: E8 (L2 edge)
# Reference: /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 68-79
def check_validate_scorers_hints_nested_get_all_scorers() -> None:
    """E8: Passing scorers=[get_all_scorers()] raises with hint about nesting.

    When the user wraps get_all_scorers() in a list, the validator should detect
    this common mistake and provide a hint like 'scorers=get_all_scorers()'.
    """
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers import get_all_scorers

    try:
        validate_scorers([get_all_scorers()])
    except MlflowException as e:
        msg = str(e)
        if "scorers=get_all_scorers()" not in msg:
            _fail(f"E8: exception should hint 'scorers=get_all_scorers()': {e}")
    else:
        _fail("E8: validate_scorers did not raise for nested get_all_scorers()")

    print("PASS: E8 - validate_scorers hints about scorers=[get_all_scorers()] nesting")


# ---------------------------------------------------------------------------
# C12: valid_data_for_builtin_scorers raises on non-dict expectations
# ---------------------------------------------------------------------------


# Contracts: C12
# Reference: /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 138-143
def check_valid_data_raises_on_non_dict_expectations() -> None:
    """C12: Non-dict values in 'expectations' column raise MlflowException."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    df = pd.DataFrame({
        "inputs": ["q1"],
        "outputs": ["a1"],
        "expectations": ["not_a_dict"],
    })

    class _AnyScorer(BuiltInScorer):
        def validate_columns(self, columns):
            pass  # always ok

    try:
        valid_data_for_builtin_scorers(df, [_AnyScorer(name="x")])
    except MlflowException as e:
        msg = str(e).lower()
        if "dictionary" not in msg and "dict" not in msg:
            _fail(f"C12: exception should mention dictionary expectations: {e}")
    else:
        _fail("C12: valid_data_for_builtin_scorers did not raise on non-dict expectations")
    print("PASS: C12 - valid_data_for_builtin_scorers raises on non-dict expectations")


# ---------------------------------------------------------------------------
# C13: valid_data_for_builtin_scorers logs missing columns
# ---------------------------------------------------------------------------


# Contracts: C13
# Reference: /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 160-174
def check_valid_data_logs_missing_columns() -> None:
    """C13: Missing required columns produce an info-level log message.

    Asserts the log message contains BOTH the scorer name AND the missing
    column name, not just that any log event occurred.
    """
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class _ReqFoo(BuiltInScorer):
        def validate_columns(self, columns):
            if "foo_column" not in columns:
                raise MissingColumnsException(self.name, {"foo_column"})

    scorer_inst = _ReqFoo(name="test_foo")
    df = pd.DataFrame({"inputs": ["x"]})  # missing foo_column

    buf = io.StringIO()
    handler = logging.StreamHandler(buf)
    handler.setLevel(logging.INFO)
    logger = logging.getLogger("mlflow.genai.scorers.validation")
    logger.addHandler(handler)
    try:
        valid_data_for_builtin_scorers(df, [scorer_inst])
        log_output = buf.getvalue()
        # Must mention both the missing column name and the scorer name
        if "foo_column" not in log_output:
            _fail(f"C13: missing column 'foo_column' not mentioned in log: {log_output!r}")
        if "test_foo" not in log_output:
            _fail(f"C13: scorer name 'test_foo' not mentioned in log: {log_output!r}")
    finally:
        logger.removeHandler(handler)

    print("PASS: C13 - valid_data_for_builtin_scorers logs missing columns with scorer name")


# ---------------------------------------------------------------------------
# C14: get_all_scorers returns 6 for non-Databricks URI
# ---------------------------------------------------------------------------


# Contracts: C14
# Perspective: /testbed/tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss
def check_get_all_scorers_count_non_databricks() -> None:
    """C14: get_all_scorers() returns 6 scorers with a file:/http: URI.

    Additionally verifies the set of type names contains each expected
    builtin scorer class name.
    """
    from mlflow.genai.scorers import get_all_scorers

    expected_type_names = {
        "ExpectationsGuidelines",
        "Correctness",
        "RelevanceToQuery",
        "RetrievalSufficiency",
        "RetrievalGroundedness",
        "Equivalence",
    }

    # Save current URI and set a non-databricks URI
    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("file:///tmp/mlflow-test")
        scorers_list = get_all_scorers()
        if len(scorers_list) != 6:
            _fail(f"C14: expected 6 scorers for non-Databricks URI, got {len(scorers_list)}")

        type_names = {type(s).__name__ for s in scorers_list}
        missing_names = expected_type_names - type_names
        if missing_names:
            _fail(f"C14: missing expected builtin scorer types: {missing_names}")
    finally:
        mlflow.set_tracking_uri(old_uri)
    print("PASS: C14 - get_all_scorers returns 6 for non-Databricks URI with expected types")


# ---------------------------------------------------------------------------
# C15: get_all_scorers includes Safety/RetrievalRelevance for Databricks URI
# ---------------------------------------------------------------------------


# Contracts: C15
# Perspective: /testbed/tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss
def check_get_all_scorers_databricks_uri_includes_extra() -> None:
    """C15: get_all_scorers() includes Safety & RetrievalRelevance on databricks URI.

    Additionally verifies the set of type names contains all 8 expected
    scorer class names.
    """
    from mlflow.genai.scorers import get_all_scorers

    expected_type_names = {
        "ExpectationsGuidelines",
        "Correctness",
        "RelevanceToQuery",
        "RetrievalSufficiency",
        "RetrievalGroundedness",
        "Equivalence",
        "Safety",
        "RetrievalRelevance",
    }

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("databricks")
        scorers_list = get_all_scorers()
        if len(scorers_list) != 8:
            _fail(f"C15: expected 8 scorers for Databricks URI, got {len(scorers_list)}")

        type_names = {type(s).__name__ for s in scorers_list}
        if "Safety" not in type_names:
            _fail("C15: Safety scorer missing from Databricks URI result")
        if "RetrievalRelevance" not in type_names:
            _fail("C15: RetrievalRelevance scorer missing from Databricks URI result")

        missing_names = expected_type_names - type_names
        if missing_names:
            _fail(f"C15: missing expected builtin scorer types: {missing_names}")
    finally:
        mlflow.set_tracking_uri(old_uri)
    print("PASS: C15 - get_all_scorers includes Safety/RetrievalRelevance for Databricks URI")


# ---------------------------------------------------------------------------
# C19: validate_aggregations accepts valid aggregation strings
# ---------------------------------------------------------------------------


# Contracts: C19
def check_validate_aggregations_accepts_valid_strings() -> None:
    """C19: validate_aggregations with valid names returns None."""
    from mlflow.genai.scorers.validation import validate_aggregations

    result = validate_aggregations(["min", "mean"])
    if result is not None:
        _fail(f"C19: expected None, got {result!r}")
    print("PASS: C19 - validate_aggregations accepts valid aggregation strings")


# ---------------------------------------------------------------------------
# C20: validate_aggregations rejects invalid aggregation name
# ---------------------------------------------------------------------------


# Contracts: C20
# Reference: /testbed/mlflow/genai/scorers/validation.py lines 194-198
def check_validate_aggregations_rejects_invalid_name() -> None:
    """C20: An invalid aggregation string raises MlflowException.

    Asserts the exact phrase "Invalid aggregation" from the implementation.
    """
    from mlflow.genai.scorers.validation import validate_aggregations

    try:
        validate_aggregations(["bad_aggregation"])
    except MlflowException as e:
        msg = str(e)
        if not msg.startswith("Invalid aggregation"):
            _fail(f"C20: exception should start with 'Invalid aggregation': {e}")
    else:
        _fail("C20: validate_aggregations did not raise for invalid name")
    print("PASS: C20 - validate_aggregations rejects invalid aggregation name")


# ---------------------------------------------------------------------------
# C21: validate_aggregations rejects non-callable non-string
# ---------------------------------------------------------------------------


# Contracts: C21
# Reference: /testbed/mlflow/genai/scorers/validation.py lines 199-203
def check_validate_aggregations_rejects_non_callable() -> None:
    """C21: A non-string non-callable item raises MlflowException.

    Asserts the exact phrase "must be either a string from" from the implementation.
    """
    from mlflow.genai.scorers.validation import validate_aggregations

    try:
        validate_aggregations([42])
    except MlflowException as e:
        msg = str(e)
        if "must be either a string from" not in msg:
            _fail(f"C21: exception should contain 'must be either a string from': {e}")
    else:
        _fail("C21: validate_aggregations did not raise for non-callable non-string")
    print("PASS: C21 - validate_aggregations rejects non-callable non-string")


# ---------------------------------------------------------------------------
# Direct-Scorer-subclass model_dump failure (F7)
# ---------------------------------------------------------------------------


# Perspective: /testbed/tests/genai/scorers/test_serialization.py::test_direct_subclass_scorer_rejected
def check_direct_scorer_subclass_model_dump_fails() -> None:
    """Direct subclassing of Scorer is rejected during serialization.

    Creates a class that subclasses Scorer directly (not via @scorer decorator),
    instantiates it, and asserts model_dump() raises MlflowException with
    'Unsupported scorer type' and 'Direct subclassing'.
    """
    class DirectSubclassScorer(Scorer):
        """An unsupported direct subclass of Scorer."""

        def __init__(self, **data):
            super().__init__(name="direct_subclass", **data)

        def __call__(self, *, outputs):
            return len(outputs) > 5

    direct_scorer = DirectSubclassScorer()

    # Calling it should work
    assert direct_scorer(outputs="hello world") is True
    assert direct_scorer(outputs="hi") is False

    # But serialization should raise an error
    try:
        direct_scorer.model_dump()
    except MlflowException as e:
        error_msg = str(e)
        if "Unsupported scorer type" not in error_msg:
            _fail(f"direct subclass: missing 'Unsupported scorer type' in: {error_msg}")
        if "Direct subclassing" not in error_msg:
            _fail(f"direct subclass: missing 'Direct subclassing' in: {error_msg}")
    else:
        _fail("direct subclass: model_dump() did not raise MlflowException")

    print("PASS: direct subclass - model_dump fails for direct Scorer subclass")


# ---------------------------------------------------------------------------
# Full serialization round-trip (F8, P1)
# ---------------------------------------------------------------------------


# Contracts: R1, R5 (serialization round-trip)
# Perspective: /testbed/tests/genai/scorers/test_serialization.py::test_simple_scorer_round_trip
def check_scorer_serialization_round_trip_execution() -> None:
    """Full serialize->deserialize->execute round-trip for decorator scorer.

    Creates a decorator scorer, calls it with test inputs, serializes via
    model_dump(), deserializes via Scorer.model_validate(), calls the
    deserialized scorer with the same inputs, and asserts identical return values.
    """
    @scorer
    def behavior_roundtrip_scorer(outputs: str) -> bool:
        return outputs != ""

    # Original functionality
    assert behavior_roundtrip_scorer(outputs="hello") is True
    assert behavior_roundtrip_scorer(outputs="") is False

    # Serialize and deserialize
    serialized = behavior_roundtrip_scorer.model_dump()
    deserialized = Scorer.model_validate(serialized)

    # Test deserialized functionality matches original
    if deserialized.name != "behavior_roundtrip_scorer":
        _fail(f"round-trip: name mismatch: {deserialized.name}")
    if deserialized(outputs="hello") is not True:
        _fail("round-trip: deserialized scorer returned unexpected False for non-empty string")
    if deserialized(outputs="") is not False:
        _fail("round-trip: deserialized scorer returned unexpected True for empty string")

    # Verify kind is preserved
    if deserialized.kind != ScorerKind.DECORATOR:
        _fail(f"round-trip: kind mismatch after deserialization: {deserialized.kind}")

    print("PASS: serialization round-trip execution - "
          "scorer survives model_dump->model_validate->__call__ with identical results")


# ---------------------------------------------------------------------------
# Boundary / compatibility: validate_aggregations with callable
# ---------------------------------------------------------------------------


def check_validate_aggregations_accepts_callable() -> None:
    """Boundary: validate_aggregations accepts a callable aggregation function."""
    from mlflow.genai.scorers.validation import validate_aggregations

    def custom_agg(values):
        return sum(values) / len(values) if values else 0

    # Should not raise
    validate_aggregations([custom_agg])
    print("PASS: boundary - validate_aggregations accepts callable aggregation")


# ---------------------------------------------------------------------------
# Boundary: validate_aggregations with None / empty
# ---------------------------------------------------------------------------


def check_validate_aggregations_handles_none_and_empty() -> None:
    """Boundary: validate_aggregations(None) and validate_aggregations([]) return None."""
    from mlflow.genai.scorers.validation import validate_aggregations

    assert validate_aggregations(None) is None
    assert validate_aggregations([]) is None
    print("PASS: boundary - validate_aggregations handles None and empty list")


# ---------------------------------------------------------------------------
# Default: scorer uses function name when name not provided
# ---------------------------------------------------------------------------


def check_scorer_defaults_to_function_name() -> None:
    """Default: @scorer without name uses the function's __name__."""
    @scorer
    def unique_name_xyz(outputs):
        return outputs

    if unique_name_xyz.name != "unique_name_xyz":
        _fail(f"Default: expected name='unique_name_xyz', got {unique_name_xyz.name!r}")
    print("PASS: default - scorer uses function name when name not given")


# ---------------------------------------------------------------------------
# Top-level runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    checks = [
        check_custom_scorer_kind_is_decorator,
        check_custom_scorer_call_delegates_to_original,
        check_validate_scorers_rejects_non_list,
        check_validate_scorers_accepts_empty_list,
        check_validate_scorers_accepts_scorer_instances,
        check_validate_scorers_hints_class_not_instance,
        check_validate_scorers_accepts_legacy_metric,
        check_validate_scorers_hints_nested_get_all_scorers,
        check_valid_data_raises_on_non_dict_expectations,
        check_valid_data_logs_missing_columns,
        check_get_all_scorers_count_non_databricks,
        check_get_all_scorers_databricks_uri_includes_extra,
        check_validate_aggregations_accepts_valid_strings,
        check_validate_aggregations_rejects_invalid_name,
        check_validate_aggregations_rejects_non_callable,
        check_direct_scorer_subclass_model_dump_fails,
        check_scorer_serialization_round_trip_execution,
        check_validate_aggregations_accepts_callable,
        check_validate_aggregations_handles_none_and_empty,
        check_scorer_defaults_to_function_name,
    ]
    for check in checks:
        check()
    print("\nAll behavior checks passed.")
