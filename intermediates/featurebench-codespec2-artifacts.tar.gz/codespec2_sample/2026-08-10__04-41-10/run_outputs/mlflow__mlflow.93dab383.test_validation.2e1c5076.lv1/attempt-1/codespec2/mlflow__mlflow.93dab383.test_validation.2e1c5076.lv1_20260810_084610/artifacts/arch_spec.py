"""
Executable architecture spec for MLflow GenAI scorers validation system.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each ``check_*`` function validates a contract ID and exits with a clear
message on failure.  Every contract referenced is annotated with
``# Contracts: C<n>``.

All checks start from a public entry point and trace through the real
repository call chain; external endpoints may be mocked but repository
dispatchers and data transformations remain live.
"""

from __future__ import annotations

import functools
import inspect
import io
import logging
import sys
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

import mlflow
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fail(msg: str) -> None:
    print(f"FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def _make_minimal_df(columns: dict[str, list] | None = None) -> pd.DataFrame:
    """Return a tiny DataFrame with the requested columns."""
    if columns is None:
        columns = {}
    return pd.DataFrame(columns)

# ---------------------------------------------------------------------------
# C1: scorer decorator returns CustomScorer (Scorer) instance
# ---------------------------------------------------------------------------


# Contracts: C1
def check_scorer_decorator_returns_scorer_instance() -> None:
    """C1: @scorer-decorated function yields a Scorer instance."""
    @scorer
    def my_scorer(outputs: str) -> bool:
        return bool(outputs)

    if not isinstance(my_scorer, Scorer):
        _fail("C1: @scorer-decorated function should be an instance of Scorer")
    print("PASS: C1 - scorer decorator returns a Scorer instance")

# ---------------------------------------------------------------------------
# C4: scorer parameterized use returns partial
# ---------------------------------------------------------------------------


# Contracts: C4
def check_scorer_parameterized_returns_partial() -> None:
    """C4: scorer(name=...) without func returns a functools.partial."""
    partial_obj = scorer(name="custom_name", description="desc")
    if not isinstance(partial_obj, functools.partial):
        _fail("C4: scorer(name=...) should return functools.partial")
    # The partial should be callable and, when given a function, return a Scorer
    @partial_obj
    def my_func(outputs):
        return outputs
    if not isinstance(my_func, Scorer):
        _fail("C4: partial(scorer) applied to a function should return a Scorer")
    print("PASS: C4 - parameterized scorer returns partial that produces Scorer")

# ---------------------------------------------------------------------------
# C16: get_all_scorers returns Scorer instances
# ---------------------------------------------------------------------------


# Contracts: C16
def check_get_all_scorers_returns_scorer_instances() -> None:
    """C16: every element from get_all_scorers() is a Scorer instance."""
    from mlflow.genai.scorers import get_all_scorers

    scorers_list = get_all_scorers()
    if not scorers_list:
        _fail("C16: get_all_scorers() returned empty list")
    for idx, s in enumerate(scorers_list):
        if not isinstance(s, Scorer):
            _fail(f"C16: scorer at index {idx} ({type(s).__name__}) is not a Scorer instance")
        if not isinstance(s, BuiltInScorer):
            _fail(
                f"C16: scorer at index {idx} ({type(s).__name__}) is not a BuiltInScorer instance"
            )
    print("PASS: C16 - get_all_scorers() returns only Scorer (BuiltInScorer) instances")

# ---------------------------------------------------------------------------
# C17: evaluate module imports validate_scorers & valid_data_for_builtin_scorers
# ---------------------------------------------------------------------------


# Contracts: C17
# Reference: /testbed/libs/skinny/mlflow/genai/evaluation/base.py line 21
def check_evaluate_imports_validation_functions() -> None:
    """C17: mlflow.genai.evaluation.base imports the validation helpers.

    Verifies that the validation symbols are resolvable as module-level
    names in the evaluation base module. Uses ``hasattr`` rather than
    source-text substring to avoid false positives from comments/strings.
    """
    import mlflow.genai.evaluation.base as _eval_base
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers

    # Confirm both symbols are callable from their defining module
    if not callable(validate_scorers):
        _fail("C17: validate_scorers is not callable")
    if not callable(valid_data_for_builtin_scorers):
        _fail("C17: valid_data_for_builtin_scorers is not callable")

    # Verify the names are resolvable as module-level attributes in the caller
    if not hasattr(_eval_base, "validate_scorers"):
        _fail("C17: mlflow.genai.evaluation.base missing module-level validate_scorers")
    if not hasattr(_eval_base, "valid_data_for_builtin_scorers"):
        _fail("C17: mlflow.genai.evaluation.base missing module-level valid_data_for_builtin_scorers")

    print("PASS: C17 - evaluate module imports validate_scorers and "
          "valid_data_for_builtin_scorers")

# ---------------------------------------------------------------------------
# C18: optimize util imports valid_data_for_builtin_scorers
# ---------------------------------------------------------------------------


# Contracts: C18
# Reference: /testbed/libs/skinny/mlflow/genai/optimize/util.py line 11
def check_optimize_util_imports_validation() -> None:
    """C18: mlflow.genai.optimize.util imports valid_data_for_builtin_scorers.

    Uses ``hasattr`` on the caller module to verify the symbol is resolvable
    as a module-level name, avoiding false positives from source-text substring.
    """
    import mlflow.genai.optimize.util as _opt_util
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    if not callable(valid_data_for_builtin_scorers):
        _fail("C18: valid_data_for_builtin_scorers is not callable")

    if not hasattr(_opt_util, "valid_data_for_builtin_scorers"):
        _fail("C18: mlflow.genai.optimize.util missing module-level valid_data_for_builtin_scorers")

    print("PASS: C18 - optimize util imports valid_data_for_builtin_scorers")

# ---------------------------------------------------------------------------
# C9: valid_data_for_builtin_scorers reverts legacy column names
# ---------------------------------------------------------------------------


# Contracts: C9
# Perspective: P1 from test_serialization.py::test_simple_scorer_round_trip -
#   data transformations must be observable in the column set forwarded to validate_columns.
def check_valid_data_reverts_legacy_column_names() -> None:
    """C9: request->inputs, response->outputs mapping is applied internally.

    Verifies that a DataFrame with 'request' and 'response' columns has them
    transformed to 'inputs'/'outputs' before validate_columns is called.
    The column set passed to validate_columns must contain 'inputs' and
    'outputs' but NOT 'request' and 'response'.
    """
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    recorded_columns = []

    class _SpyScorer(BuiltInScorer):
        def validate_columns(self, columns):
            recorded_columns.append(set(columns))

    scorer_inst = _SpyScorer(name="test_req")
    df = pd.DataFrame({"request": ["q1"], "response": ["a1"]})

    valid_data_for_builtin_scorers(df, [scorer_inst])

    if len(recorded_columns) != 1:
        _fail(f"C9: expected 1 call to validate_columns, got {len(recorded_columns)}")
    cols = recorded_columns[0]
    if "inputs" not in cols:
        _fail("C9: 'inputs' missing in column set after legacy mapping")
    if "outputs" not in cols:
        _fail("C9: 'outputs' missing in column set after legacy mapping")
    if "request" in cols:
        _fail("C9: 'request' should have been remapped to 'inputs'")
    if "response" in cols:
        _fail("C9: 'response' should have been remapped to 'outputs'")

    print("PASS: C9 - valid_data_for_builtin_scorers maps request->inputs, response->outputs")

# ---------------------------------------------------------------------------
# C10: valid_data_for_builtin_scorers infers outputs from predict_fn
# ---------------------------------------------------------------------------


# Contracts: C10
# Perspective: P1 from test_serialization.py::test_simple_scorer_round_trip -
#   dataflow transformations must be observable in forwarded column set.
def check_valid_data_infers_outputs_from_predict_fn() -> None:
    """C10: When predict_fn is provided, outputs column is treated as present.

    Verifies that 'outputs' appears in the column set passed to validate_columns
    even when the DataFrame lacks an 'outputs' column, because predict_fn can
    generate outputs.
    """
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    recorded_columns = []

    class _SpyScorer(BuiltInScorer):
        def validate_columns(self, columns):
            recorded_columns.append(set(columns))

    scorer_inst = _SpyScorer(name="test_outputs")
    df = pd.DataFrame({"inputs": ["q1"]})  # no 'outputs' column

    def my_predict_fn(x):
        return "predicted"

    valid_data_for_builtin_scorers(df, [scorer_inst], predict_fn=my_predict_fn)

    if len(recorded_columns) != 1:
        _fail(f"C10: expected 1 call to validate_columns, got {len(recorded_columns)}")
    cols = recorded_columns[0]
    if "outputs" not in cols:
        _fail("C10: 'outputs' should be inferred from predict_fn and appear in column set")

    print("PASS: C10 - valid_data_for_builtin_scorers treats outputs as present with predict_fn")

# ---------------------------------------------------------------------------
# C11: valid_data_for_builtin_scorers infers inputs/outputs from trace column
# ---------------------------------------------------------------------------


# Contracts: C11
# Perspective: P1 from test_serialization.py::test_simple_scorer_round_trip -
#   dataflow transformations must be observable in forwarded column set.
def check_valid_data_infers_columns_from_trace() -> None:
    """C11: When 'trace' column exists, inputs/outputs are treated as present.

    Verifies that both 'inputs' and 'outputs' appear in the column set passed
    to validate_columns when the DataFrame has a 'trace' column (from which
    both can be inferred).
    """
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    recorded_columns = []

    class _SpyScorer(BuiltInScorer):
        def validate_columns(self, columns):
            recorded_columns.append(set(columns))

    scorer_inst = _SpyScorer(name="test_trace_infer")
    # DataFrame with trace but without explicit inputs/outputs
    df = pd.DataFrame({"trace": ["trace_obj_placeholder"]})

    valid_data_for_builtin_scorers(df, [scorer_inst])

    if len(recorded_columns) != 1:
        _fail(f"C11: expected 1 call to validate_columns, got {len(recorded_columns)}")
    cols = recorded_columns[0]
    if "inputs" not in cols:
        _fail("C11: 'inputs' should be inferred from trace column")
    if "outputs" not in cols:
        _fail("C11: 'outputs' should be inferred from trace column")

    print("PASS: C11 - valid_data_for_builtin_scorers infers inputs/outputs from trace column")

# ---------------------------------------------------------------------------
# New: expectations-key explosion observation (F4)
# ---------------------------------------------------------------------------

# Contracts: C12 (dataflow aspect) — expectations/{key} explosion
# Reference: /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 146-152
def check_valid_data_explodes_expectations_keys() -> None:
    """Expectations/{key} columns are added from expectations dict.

    When the DataFrame has an 'expectations' column with dictionary values,
    the keys are exploded into 'expectations/{key}' columns and these appear
    in the column set passed to validate_columns.
    """
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    recorded_columns = []

    class _SpyScorer(BuiltInScorer):
        def validate_columns(self, columns):
            recorded_columns.append(set(columns))

    scorer_inst = _SpyScorer(name="test_exp")
    df = pd.DataFrame({
        "inputs": ["q1"],
        "outputs": ["a1"],
        "expectations": [{"expected_response": "x", "ground_truth": "y"}],
    })

    valid_data_for_builtin_scorers(df, [scorer_inst])

    if len(recorded_columns) != 1:
        _fail(f"expectations explosion: expected 1 call, got {len(recorded_columns)}")
    cols = recorded_columns[0]
    if "expectations/expected_response" not in cols:
        _fail("expectations explosion: 'expectations/expected_response' missing from column set")
    if "expectations/ground_truth" not in cols:
        _fail("expectations explosion: 'expectations/ground_truth' missing from column set")

    print("PASS: expectations explosion - expectations keys become expectations/{key} columns")

# ---------------------------------------------------------------------------
# E6: get_all_scorers constructs instances of expected builtin classes
# ---------------------------------------------------------------------------


# Contracts: E6, E10 (L2 edges)
def check_l2_edge_get_all_scorers_to_builtin_classes() -> None:
    """E6: get_all_scorers() constructs instances of the expected builtin classes."""
    from mlflow.genai.scorers import get_all_scorers
    from mlflow.genai.scorers.builtin_scorers import (
        Correctness,
        Equivalence,
        ExpectationsGuidelines,
        RelevanceToQuery,
        RetrievalGroundedness,
        RetrievalSufficiency,
    )

    expected_types = {
        ExpectationsGuidelines,
        Correctness,
        RelevanceToQuery,
        RetrievalSufficiency,
        RetrievalGroundedness,
        Equivalence,
    }

    scorers_list = get_all_scorers()
    actual_types = {type(s) for s in scorers_list}

    missing = expected_types - actual_types
    if missing:
        _fail(f"E6: get_all_scorers() missing builtin types: {[t.__name__ for t in missing]}")

    print("PASS: E6 - get_all_scorers constructs all base builtin scorer types")


# ---------------------------------------------------------------------------
# E10: validate_aggregations reads _AGGREGATE_FUNCTIONS
# ---------------------------------------------------------------------------


# Contracts: E10 (L2 edge)
def check_l2_edge_validate_aggregations_reads_aggregate_functions() -> None:
    """E10: validate_aggregations reads _AGGREGATE_FUNCTIONS for validation."""
    from mlflow.genai.scorers.aggregation import _AGGREGATE_FUNCTIONS
    from mlflow.genai.scorers.validation import validate_aggregations

    # Valid strings must be in _AGGREGATE_FUNCTIONS keys
    valid_names = set(_AGGREGATE_FUNCTIONS.keys())
    # All valid names should pass without exception
    for name in valid_names:
        try:
            validate_aggregations([name])
        except MlflowException:
            _fail(f"E10: validate_aggregations rejected valid aggregation '{name}'")

    # An invalid name should raise
    try:
        validate_aggregations(["__nonexistent_agg__"])
    except MlflowException:
        pass  # expected
    else:
        _fail("E10: validate_aggregations did not raise for invalid aggregation name")

    print("PASS: E10 - validate_aggregations correctly reads _AGGREGATE_FUNCTIONS")

# ---------------------------------------------------------------------------
# E9: valid_data_for_builtin_scorers -> BuiltInScorer.validate_columns
# ---------------------------------------------------------------------------


# Contracts: E9 (L2 edge)
def check_l2_edge_valid_data_calls_validate_columns() -> None:
    """E9: valid_data_for_builtin_scorers calls validate_columns on each scorer.

    Verifies call count AND that the column set contains the actual DataFrame
    columns, proving columns are forwarded correctly through the validation chain.
    """
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    calls = []

    class _SpyScorer(BuiltInScorer):
        def validate_columns(self, columns):
            calls.append(set(columns))
            # Never raise — all columns present

    s1 = _SpyScorer(name="spy1")
    s2 = _SpyScorer(name="spy2")
    df = pd.DataFrame({"inputs": ["x"], "outputs": ["y"]})

    valid_data_for_builtin_scorers(df, [s1, s2])
    if len(calls) != 2:
        _fail(f"E9: expected 2 calls to validate_columns, got {len(calls)}")

    # Assert the column set contains the actual DataFrame columns
    for idx, cols in enumerate(calls):
        if "inputs" not in cols:
            _fail(f"E9: call {idx} missing 'inputs' in column set {cols}")
        if "outputs" not in cols:
            _fail(f"E9: call {idx} missing 'outputs' in column set {cols}")

    print("PASS: E9 - valid_data_for_builtin_scorers calls validate_columns on each scorer "
          "with correct columns")

# ---------------------------------------------------------------------------
# E11: CustomScorer._original_func -> Scorer.model_dump (serialization dataflow)
# ---------------------------------------------------------------------------


# Contracts: E11 (L2 edge, R5)
def check_l2_edge_original_func_to_model_dump() -> None:
    """E11: CustomScorer stores _original_func; model_dump uses it for serialization.

    Verifies that a @scorer-decorated function has its original function
    reference stored in ``_original_func``, and that ``model_dump()`` returns
    a dictionary containing ``call_source``, ``call_signature``, and
    ``original_func_name`` keys from the source extraction path.
    """
    @scorer
    def serializable_scorer(outputs: str) -> bool:
        """Docstring for serializable scorer."""
        return bool(outputs)

    # The private attribute must reference the original function
    if not hasattr(serializable_scorer, "_original_func"):
        _fail("E11: CustomScorer missing _original_func attribute")
    original = serializable_scorer._original_func
    if not callable(original):
        _fail("E11: _original_func is not callable")
    if original.__name__ != "serializable_scorer":
        _fail(f"E11: _original_func.__name__ mismatch: {original.__name__}")

    # model_dump() must include serialization info from _original_func
    dump = serializable_scorer.model_dump()
    for key in ("call_source", "call_signature", "original_func_name"):
        if key not in dump:
            _fail(f"E11: model_dump() missing key '{key}'")
    if dump.get("original_func_name") != "serializable_scorer":
        _fail(f"E11: model_dump original_func_name mismatch: {dump.get('original_func_name')}")

    print("PASS: E11 - _original_func is stored and used by model_dump for serialization")

# ---------------------------------------------------------------------------
# Serialization round-trip check (F8, P1)
# ---------------------------------------------------------------------------

# Contracts: R1, R5 (serialization round-trip)
# Perspective: /testbed/tests/genai/scorers/test_serialization.py::test_simple_scorer_round_trip
def check_scorer_serialization_round_trip() -> None:
    """Full serialize->deserialize->execute round-trip for decorator scorer.

    Creates a decorator scorer, calls it, serializes via model_dump(),
    deserializes via Scorer.model_validate(), re-executes, and asserts
    identical behavior. This closes the gap where structural checks pass
    but a broken _reconstruct_decorator_scorer would go undetected.
    """
    @scorer(name="roundtrip_test")
    def roundtrip_scorer(outputs: str) -> bool:
        return len(outputs) > 5

    # Original functionality
    assert roundtrip_scorer(outputs="hello world") is True
    assert roundtrip_scorer(outputs="hi") is False

    # Serialize and deserialize
    serialized = roundtrip_scorer.model_dump()
    deserialized = Scorer.model_validate(serialized)

    # Test deserialized functionality matches original
    if deserialized.name != "roundtrip_test":
        _fail(f"round-trip: name mismatch: {deserialized.name}")
    if deserialized(outputs="hello world") is not True:
        _fail("round-trip: deserialized scorer returned unexpected False for long string")
    if deserialized(outputs="hi") is not False:
        _fail("round-trip: deserialized scorer returned unexpected True for short string")

    # Verify kind is preserved
    if deserialized.kind != ScorerKind.DECORATOR:
        _fail(f"round-trip: kind mismatch after deserialization: {deserialized.kind}")

    print("PASS: serialization round-trip - scorer survives model_dump->model_validate->__call__")

# ---------------------------------------------------------------------------
# Caller-binding proofs for E3/E4/E5 (F2)
# ---------------------------------------------------------------------------

# Contracts: E3, E4, E5 (L2 edges)
# Perspective: /testbed/tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics
def check_evaluate_caller_resolves_validation_functions() -> None:
    """E3/E4: The evaluate module can resolve validate_scorers and
    valid_data_for_builtin_scorers at the module level.

    Instead of source-text checks, this verifies the actual module-level
    attribute resolution that the evaluate function would use at runtime.
    """
    import mlflow.genai.evaluation.base as _eval_base

    # Verify the module itself is importable
    from mlflow.genai.evaluation.base import evaluate
    if not callable(evaluate):
        _fail("E3/E4: evaluate is not callable")

    # Verify the validation symbols are resolvable from the caller module
    if not hasattr(_eval_base, "validate_scorers"):
        _fail("E3: evaluate module cannot resolve validate_scorers at module level")
    if not hasattr(_eval_base, "valid_data_for_builtin_scorers"):
        _fail("E4: evaluate module cannot resolve valid_data_for_builtin_scorers at module level")

    # Verify the resolved attributes are callable
    if not callable(_eval_base.validate_scorers):
        _fail("E3: validate_scorers resolved but not callable")
    if not callable(_eval_base.valid_data_for_builtin_scorers):
        _fail("E4: valid_data_for_builtin_scorers resolved but not callable")

    print("PASS: E3/E4 - evaluate module resolves validate_scorers and "
          "valid_data_for_builtin_scorers")


# Contracts: E5 (L2 edge)
def check_optimize_caller_resolves_validation_function() -> None:
    """E5: The optimize.util module can resolve valid_data_for_builtin_scorers
    at the module level.
    """
    import mlflow.genai.optimize.util as _opt_util

    if not hasattr(_opt_util, "valid_data_for_builtin_scorers"):
        _fail("E5: optimize.util module cannot resolve valid_data_for_builtin_scorers at module level")
    if not callable(_opt_util.valid_data_for_builtin_scorers):
        _fail("E5: valid_data_for_builtin_scorers resolved but not callable")

    print("PASS: E5 - optimize.util module resolves valid_data_for_builtin_scorers")

# ---------------------------------------------------------------------------
# Top-level runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    checks = [
        check_scorer_decorator_returns_scorer_instance,
        check_scorer_parameterized_returns_partial,
        check_get_all_scorers_returns_scorer_instances,
        check_evaluate_imports_validation_functions,
        check_optimize_util_imports_validation,
        check_valid_data_reverts_legacy_column_names,
        check_valid_data_infers_outputs_from_predict_fn,
        check_valid_data_infers_columns_from_trace,
        check_valid_data_explodes_expectations_keys,
        check_l2_edge_get_all_scorers_to_builtin_classes,
        check_l2_edge_validate_aggregations_reads_aggregate_functions,
        check_l2_edge_valid_data_calls_validate_columns,
        check_l2_edge_original_func_to_model_dump,
        check_scorer_serialization_round_trip,
        check_evaluate_caller_resolves_validation_functions,
        check_optimize_caller_resolves_validation_function,
    ]
    for check in checks:
        check()
    print("\nAll architecture checks passed.")

# ---------------------------------------------------------------------------
