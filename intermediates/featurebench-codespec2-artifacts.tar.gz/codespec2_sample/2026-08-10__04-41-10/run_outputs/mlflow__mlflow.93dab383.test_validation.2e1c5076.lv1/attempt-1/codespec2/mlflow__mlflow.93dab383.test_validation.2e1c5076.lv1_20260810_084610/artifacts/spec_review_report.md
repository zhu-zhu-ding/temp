# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — mandates six-view architecture coverage (Structure, Dependency, Call Chain, Dataflow, Interface, State/Lifecycle) and L3-contract type-to-spec-file mapping.
- Semantic IR: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260810_084610/artifacts/semantic_ir.md` — 21 L3 contracts (C1–C21), 8 L1 obligations (R1–R8), 11 L2 edges (E1–E11), 14 nodes (N1–N14).
- Arch spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260810_084610/artifacts/arch_spec.py` — 12 check functions covering C1, C4, C9–C11, C16–C18, E6, E9–E11.
- Behavior spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260810_084610/artifacts/behavior_spec.py` — 16 check functions covering C2–C3, C5–C8, C12–C15, C19–C21, plus 3 boundary/default checks.
- Native tests: `tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` — perspective: decorator scorer instance is callable in `evaluate()`; `test_scorer_name_works` — custom name propagates; `test_custom_scorer_allow_none_return` — `__call__` delegates with None return; `test_trace_passed_correctly` — trace column inference in live eval pipeline.
- Native tests: `tests/genai/scorers/test_serialization.py::test_decorator_scorer_serialization_format` — complete `model_dump` format verification with key presence, version metadata, type-discriminant fields; `test_simple_scorer_round_trip` — full serialize→deserialize→execute cycle; `test_direct_subclass_serialization_error` — error on direct Scorer subclass model_dump; `test_builtin_scorer_with_aggregations_round_trip` — BuiltInScorer round-trip preserving required_columns and aggregations; `test_deserialized_scorer_runs_without_global_context` — isolated namespace execution after deserialization.
- Native tests: `tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss` — length and type-of-instance assertions for URI-dependent scorer count; `tests/genai/scorers/test_scorer_CRUD.py` — `_original_func.__name__` preservation across register/list/get/delete cycles.
- Native tests: `tests/genai/scorers/test_aggregation.py::test_compute_aggregated_metrics` — validates `_AGGREGATE_FUNCTIONS` keys are actually used by aggregation computation, motivating one end-to-end aggregation chain check.
- Repository source: `/testbed/mlflow/genai/scorers/validation.py` — `validate_scorers` and `valid_data_for_builtin_scorers` have blank bodies; `validate_aggregations` is implemented. `/testbed/mlflow/genai/evaluation/base.py` line 243 — calls `validate_scorers(scorers)` but has no import for it; line 248 — calls `valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)` but has no import for it. `/testbed/mlflow/genai/optimize/util.py` line 91 — calls `valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)` but has no import for it.
- Reference implementation: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` — full implementations of all three functions; `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py` — full `get_all_scorers`; `/testbed/libs/skinny/mlflow/genai/scorers/base.py` — full `CustomScorer` inner class.

## Rubric
- Requirement coverage: 1 — 16 of 21 L3 contracts are directly checked; C9–C11 are checked only for column-name-mapping presence (not dataflow correctness); C13 is checked only for log-event occurrence (not message content); R2's E7/E8 edges are absent; R3's expectations/{key} explosion is unobserved; R7/R8 caller imports are checked via source-text but the actual `from ... import` statement is absent in production code, so the C17/C18 checks would fail at runtime.
- Caller binding / call chain: 1 — E3 (`evaluate`→`validate_scorers`) and E4 (`evaluate`→`valid_data_for_builtin_scorers`) are only checked as import-boundary (C17 source-text), not as executed call chains with the real `evaluate()` caller. E5 (`optimize`→`valid_data_for_builtin_scorers`) is similarly import-only (C18). E8 (`validate_scorers`→`get_all_scorers`) is entirely absent. E9 (validation→`validate_columns`) has a call-count check but does not assert the columns passed match the expected set after all transformations.
- Dataflow / state / lifecycle: 1 — E10 (`validate_aggregations`→`_AGGREGATE_FUNCTIONS`) is well tested with iteration over real keys. E11 (`_original_func`→`model_dump`) checks key presence but not round-trip deserialization and re-execution. C9–C11 data transformations (legacy column revert, predict_fn inference, trace inference) are checked only via spy-call existence, not via column-set content assertions. C12 expectations-explosion is unobserved: no check that `expectations/{key}` columns are added.
- Failure / compatibility boundaries: 1 — C5, C8, C12, C20, C21 all have exception checks but with weak message matching (substring presence rather than exact expected text). C5 matches "must be a list" OR "list of scorers" (too permissive). C8 matches "class" OR "instance" (too permissive). No check for the `scorers=[get_all_scorers()]` nested-list hint (R2, E8). No check for legacy `databricks.rag_eval.evaluation.metrics.Metric` acceptance path (E7). No check for `model_dump` failure on direct `Scorer` subclass (pattern from `test_direct_subclass_serialization_error`).

## Derived Practical Test Perspectives

- P1: `tests/genai/scorers/test_serialization.py::test_simple_scorer_round_trip` — observed risk: serialized scorers that pass structural checks may still fail on deserialization or produce different results on execution. The generated specs check `model_dump` key presence (C1, E11) but never execute the full `model_dump`→`model_validate`→`__call__` round-trip. Expected: at least one arch or behavior check that creates a decorator scorer, calls it, serializes, deserializes, and asserts identical behavior on the same inputs.

- P2: `tests/genai/scorers/test_serialization.py::test_direct_subclass_serialization_error` — observed risk: direct `Scorer` subclass instances silently fail with confusing errors when users attempt serialization. The generated specs have no check for `model_dump()` raising `MlflowException` with "Unsupported scorer type" when called on a non-decorator, non-builtin Scorer. Expected: a failure check in behavior_spec.py that subclasses `Scorer` directly (not via `@scorer`), calls `model_dump()`, and asserts the exact error class and message substring.

- P3: `tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss` — observed risk: `get_all_scorers` might return scorers with different types across environments. The generated specs check length and isinstance but do not check individual scorer identity by name or class name. Expected: the arch_spec check should assert that the set of scorer names or type-names in the returned list matches the expected base-6 set (modulo Databricks URI).

- P4: `tests/genai/scorers/test_scorer.py::test_trace_passed_correctly` — observed risk: the `valid_data_for_builtin_scorers` function must correctly infer `inputs`/`outputs` availability when a `trace` column is present (C11). The current arch_spec check (`check_valid_data_infers_columns_from_trace`) creates a trace-column DataFrame and a spy scorer but only checks the spy was called — it does not verify that the trace column was present in the columns passed to `validate_columns`, which is the actual dataflow assertion.

- P5: `tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` — observed risk: `validate_scorers` and `valid_data_for_builtin_scorers` are called from within the real `evaluate()` pipeline. The generated specs test them in isolation (C5–C8, C12–C13) but never exercise the full E3/E4 call chains from `evaluate()`. Expected: at least one check that calls the real `mlflow.genai.evaluate()` with valid scorers and data, then observes that `validate_scorers` and `valid_data_for_builtin_scorers` execute within the pipeline (via spy or side-effect observation).

## Final Rubric Scores
- Requirement coverage: 1 — C9–C11 lack dataflow-content assertions; C13 lacks message-content assertion; E7/E8 are absent; R2's legacy-metric path is absent; R3's expectations-key explosion is unobserved; C17/C18 import assertions would fail against the current production code that lacks the imports.
- Caller binding / call chain: 1 — E3/E4/E5 are proven only as import-boundary; they need at least one executed-call-chain proof each. E8 is entirely absent. E9 has call count but not column-content assertion.
- Dataflow / state / lifecycle: 1 — E11 lacks round-trip deserialization proof. C9–C11 lack column-set content verification. C12 expectations explosion is unobserved. No lifecycle test for `_cached_dump` behavior (caching prevents re-serialization issues).
- Failure / compatibility boundaries: 1 — Exception message matching is overly permissive. Missing `scorers=[get_all_scorers()]` hint path. Missing direct-Scorer-subclass model_dump failure. Missing legacy Metric acceptance path.
- P1 (round-trip serialization): 0 — absent; no check performs `model_dump`→`model_validate`→`__call__` cycle with behavior comparison.
- P2 (direct subclass model_dump error): 0 — absent.
- P3 (scorer identity in get_all_scorers): 1 — arch_spec checks type via E6 (set of type-names) but behavior_spec only checks length; neither checks per-scorer names.
- P4 (trace column dataflow content): 0 — spy-called check exists but column-set content is unverified.
- P5 (evaluate pipeline call chain): 0 — absent.

## Findings

### F1: missing_requirement — C9/C10/C11 dataflow content unverified
- Requirement/IR: R3 / C9, C10, C11
- Evidence: task Interface Description 2; `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 118–132
- Gap: `check_valid_data_reverts_legacy_column_names`, `check_valid_data_infers_outputs_from_predict_fn`, and `check_valid_data_infers_columns_from_trace` in arch_spec.py verify only that a spy-scorer's `validate_columns` was called, but do not assert the actual column-set passed to `validate_columns` contains/omits the expected columns. A broken implementation that passes the raw DataFrame columns without transformation would still pass these checks.
- Repair: In each of the three checks, capture the column-set argument passed to `validate_columns` and assert specific set memberships: (C9) assert `"inputs"` in columns after `"request"`→`"inputs"` revert; (C10) assert `"outputs"` in columns when predict_fn is provided; (C11) assert both `"inputs"` and `"outputs"` are in columns when trace column exists.

### F2: missing_requirement — E3/E4/E5 call-chain not executed from real callers
- Requirement/IR: R7 / E3, E4; R8 / E5
- Evidence: `/testbed/mlflow/genai/evaluation/base.py` lines 243, 248; `/testbed/mlflow/genai/optimize/util.py` line 91; task Interface Description 2
- Gap: C17 and C18 verify only that the source files contain import statements (via `inspect.getsource()` substring match). But the production code at `/testbed/mlflow/genai/evaluation/base.py` and `/testbed/mlflow/genai/optimize/util.py` does NOT currently have the required import statements. Even if imports were added, a source-text check proves neither that the import resolves at runtime nor that the call site actually passes data correctly. The Test Spec Skill mandates: "A successful `import module`, a source text match, or `hasattr(module, \"helper\")` proves none of `Dependency`, `Call Chain`, or `Dataflow`."
- Repair: For E3/E4, call `mlflow.genai.evaluate()` with a minimal valid DataFrame and a BuiltInScorer that has a spy `validate_columns`, then assert the spy was called. For E5, call the real `validate_train_data` with a DataFrame and spy-scorers. At minimum, for each of E3/E4/E5, import the caller module and verify the validation function is actually resolvable as a bound name in that module (not just in source text).

### F3: missing_requirement — E7 (IS_DBX_AGENTS_INSTALLED) and E8 (get_all_scorers) edges absent
- Requirement/IR: R2 / E7, E8
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` lines 51–56 (E7), line 62 (E8); task Interface Description 2
- Gap: No check exercises the legacy Metric compatibility path (E7) or the `scorers=[get_all_scorers()]` nested-list detection path (E8). The validate_scorers behavior checks test only the basic error paths (C5 non-list, C6 empty, C7 valid, C8 class-not-instance). A bug in either E7 or E8 would go undetected.
- Repair: Add to behavior_spec.py: (1) a check that mocks `IS_DBX_AGENTS_INSTALLED=True` and passes a realistic `Metric`-compatible mock, verifying no exception; (2) a check that passes `scorers=[get_all_scorers()]` (a list containing the get_all_scorers result) and asserts the hint message mentions using `scorers=get_all_scorers()` directly.

### F4: missing_requirement — C12 expectations-key explosion unobserved
- Requirement/IR: R3 / C12 (partially)
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 138–143; Interface Description 2: "The 'expectations' column is treated specially - its dictionary values are exploded into individual expectation fields for validation."
- Gap: C12 in behavior_spec.py only checks that non-dict expectations raise MlflowException. It does not check that valid dict expectations cause `expectations/{key}` columns to be added to the set passed to `validate_columns`. A broken implementation that ignores the explosion step would still pass.
- Repair: Extend `check_valid_data_raises_on_non_dict_expectations` (or add a new check) that provides a DataFrame with `expectations` column containing `{"expected_response": "x", "ground_truth": "y"}`, uses a spy scorer whose `validate_columns` records the column set, and asserts `"expectations/expected_response"` and `"expectations/ground_truth"` are present in the recorded set.

### F5: weak_constraint — C13 log message content unverified
- Requirement/IR: R3 / C13
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 160–174
- Gap: `check_valid_data_logs_missing_columns` in behavior_spec.py captures all log output but only checks that anything was logged at all. It does not verify the message mentions which scorers need which columns. A broken implementation that logs "hello" instead of the structured missing-column message would pass.
- Repair: Assert the captured log message contains the scorer name and the missing column name, e.g., assert specific scorer name and column name substrings in the log output.

### F6: weak_constraint — Exception message checks are overly permissive
- Requirement/IR: R2 / C5, C8; R6 / C20, C21
- Evidence: behavior_spec.py checks: C5 uses `"must be a list" not in msg and "list of scorers" not in msg` (accepts either); C8 uses `"class" not in msg.lower() and "instance" not in msg.lower()` (accepts either); C20 uses `"invalid aggregation" not in msg and "bad_aggregation" not in str(e)` (accepts either).
- Gap: These disjunctions accept messages that contain only half the expected content. Per the reference implementation, C5 should contain "must be a list of scorers"; C8 should contain "scorer class instead of an instance"; C20 should contain "Invalid aggregation"; C21 should contain "must be either a string from". The current checks are too weak to catch regressions where the message content changes subtly but still satisfies one branch.
- Repair: Tighten each to match the exact expected substring from the reference implementation. For C5: assert `"must be a list of scorers"` in message. For C8: assert `"scorer class instead of an instance"` in message. For C20: assert `"Invalid aggregation"` in message. For C21: assert `"must be either a string from"` in message.

### F7: missing_requirement — Direct Scorer subclass model_dump error path
- Requirement/IR: R1 / E2 / Scorer.model_dump error contract
- Evidence: `/testbed/tests/genai/scorers/test_serialization.py::test_direct_subclass_serialization_error` (lines 465–490); `/testbed/mlflow/genai/scorers/base.py:Scorer.model_dump` lines 155–177
- Gap: The generated specs have no check verifying that calling `model_dump()` on a directly-subclassed `Scorer` (not `@scorer`-decorated, not `BuiltInScorer`) raises `MlflowException` with "Unsupported scorer type". This is a critical compatibility boundary — users who subclass `Scorer` without `@scorer` will get confusing errors if this is not properly guarded.
- Repair: Add to behavior_spec.py: create a minimal direct `Scorer` subclass, instantiate it, call `model_dump()`, and assert `MlflowException` raised with "Unsupported scorer type" and "Direct subclassing" in the message.

### F8: missing_requirement — Full serialization round-trip unverified
- Requirement/IR: R1/R5 / C1, C3, E11
- Evidence: `/testbed/tests/genai/scorers/test_serialization.py::test_simple_scorer_round_trip` (lines 83–98)
- Gap: The arch_spec check E11 verifies `_original_func` exists and `model_dump` returns expected keys, but does not perform `model_validate` on the dump and then call the deserialized scorer to verify behavioral equivalence. The behavior_spec checks C2 (kind) and C3 (delegation) only on the original scorer, not the round-tripped one. A broken `_reconstruct_decorator_scorer` that produces a non-functional scorer would pass all current checks.
- Repair: Add to either arch_spec.py or behavior_spec.py: create a decorator scorer, call it with test inputs, serialize via `model_dump()`, deserialize via `Scorer.model_validate()`, call the deserialized scorer with the same inputs, and assert identical return values.

### F9: weak_constraint — C17/C18 import checks cannot pass against current production code
- Requirement/IR: R7 / C17; R8 / C18
- Evidence: `/testbed/mlflow/genai/evaluation/base.py` — no `from mlflow.genai.scorers.validation import ...` statement; `/testbed/mlflow/genai/optimize/util.py` — no `from mlflow.genai.scorers.validation import ...` statement
- Gap: The arch_spec checks `check_evaluate_imports_validation_functions` (C17) and `check_optimize_util_imports_validation` (C18) use `inspect.getsource()` to verify the source contains `validate_scorers` and `valid_data_for_builtin_scorers` substrings. The current production files at those paths do not contain these imports, so both checks would fail at runtime. The Test Spec Skill notes that IMPORT_BOUNDARY contracts legitimately use source-text checks, but the checks must match the expected state — either the production code must have the imports or the check must verify existence differently.
- Repair: The spec should verify the import is resolvable as a module-level name (e.g., `hasattr(module, 'validate_scorers')` after importing the module), not just substring-match. The current approach is acceptable per L3 Lesson in the skill, but the production code must also contain the expected imports.

### F10: weak_constraint — E9 validate_columns argument content unverified
- Requirement/IR: R3 / E9
- Evidence: arch_spec.py `check_l2_edge_valid_data_calls_validate_columns`
- Gap: The spy records `set(columns)` but the check only asserts `len(calls) == 2`. It does not verify what columns were passed. If `valid_data_for_builtin_scorers` always passes an empty set, this check would still pass.
- Repair: Assert that each recorded column set contains `"inputs"` and `"outputs"` (the columns present in the test DataFrame), proving the columns are forwarded correctly through the validation chain.

## Rework Instructions

1. **Strengthen C9/C10/C11 dataflow checks (F1, F10):** In the three arch_spec checks, capture and assert the exact column-set passed to spy `validate_columns`. For C9, provide a DataFrame with `"request"`/`"response"` columns and assert `"inputs"`/`"outputs"` appear in the set. For C10, omit `"outputs"` column and provide `predict_fn`, then assert `"outputs"` is in the set. For C11, provide a `"trace"` column, assert both `"inputs"` and `"outputs"` are added. For E9, assert the column set contains the actual DataFrame columns.

2. **Add caller-binding proofs for E3/E4/E5 (F2):** Replace or supplement the source-text checks with at least one executed call-chain that imports the real `evaluate` module and verifies the validation functions are resolvable as bound names. Also consider a lightweight integration check that calls `mlflow.genai.evaluate()` with valid data and scorers and spies on `validate_scorers`/`valid_data_for_builtin_scorers`.

3. **Add E7 and E8 edge coverage (F3):** In behavior_spec.py, add a check for the legacy Metric compatibility path (mock IS_DBX_AGENTS_INSTALLED=True, pass a Metric-compatible mock, assert no exception). Add a check for the `scorers=[get_all_scorers()]` hint path (catch MlflowException, assert hint references `scorers=get_all_scorers()`).

4. **Add expectations-key explosion observation (F4):** Add a test that provides `{"expected_response": "x"}` in expectations column and asserts `"expectations/expected_response"` appears in the columns passed to validate_columns.

5. **Tighten exception message assertions (F6):** Change C5 to assert `"must be a list of scorers"` directly. Change C8 to assert `"class instead of an instance"` (exact phrase from reference impl). Change C20 to assert `"Invalid aggregation"` as a prefix. Change C21 to assert `"must be either a string from"`.

6. **Add direct-Scorer-subclass model_dump failure check (F7):** Add to behavior_spec.py a check that subclasses `Scorer` directly (not via decorator), instantiates, calls `model_dump()`, asserts `MlflowException` with `"Unsupported scorer type"` and `"Direct subclassing"`.

7. **Add full serialization round-trip check (F8, P1):** Add a check that creates a decorator scorer, calls it, serializes via `model_dump()`, deserializes via `Scorer.model_validate()`, re-executes, and asserts identical results. This closes the P1 perspective from native `test_simple_scorer_round_trip`.

8. **Verify C13 log content (F5):** Tighten `check_valid_data_logs_missing_columns` to assert the log message contains the scorer name and missing column name, not just that any log event occurred.

9. **Add per-scorer identity check to C14/C15 (P3):** In behavior_spec.py C14/C15 checks, also assert that the set of `type(s).__name__` for returned scorers contains each expected builtin scorer class name.

10. **Ensure C17/C18 production-code consistency (F9):** Verify that the production files `/testbed/mlflow/genai/evaluation/base.py` and `/testbed/mlflow/genai/optimize/util.py` contain the expected import statements (they currently do not). The spec's source-text check is valid per the skill's L3 lesson, but the tested code must actually contain those imports.
