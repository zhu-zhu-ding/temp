# Semantic IR

## L1. Requirement Obligations

### R1: scorer decorator creates a callable CustomScorer subclass
- Type: Interface
- Statement: When the `@scorer` decorator is applied to a function (with or without arguments), the decorator MUST dynamically create a `CustomScorer` class that subclasses `Scorer`, stores the original function in a `_original_func` private attribute, delegates `__call__` to the original function, and reports `ScorerKind.DECORATOR` as its kind. The returned instance must have its `__call__` signature patched to include `self` as the first parameter matching the original function's parameters.
- Task Evidence: Interface Description 1 — "A decorator to define a custom scorer that can be used in `mlflow.genai.evaluate()`."
- Acceptance: A `@scorer`-decorated function returns a `Scorer` instance whose `__call__` invokes the original function and whose `kind` property returns `ScorerKind.DECORATOR`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:scorer` (lines 847–1030); `/testbed/libs/skinny/mlflow/genai/scorers/base.py` (complete reference implementation includes `CustomScorer` inner class at lines 999–1016); `/testbed/tests/genai/scorers/test_scorer.py` (lines 60–65, 73–80, 573–584).
- Uncertainty: None.

### R2: validate_scorers validates a list of scorer objects
- Type: Behavior
- Statement: Given a list of potential scorer objects, `validate_scorers` MUST assert the input is a list, filter for `Scorer` instances, optionally accept legacy `databricks.rag_eval.evaluation.metrics.Metric` objects if `databricks.agents` is installed, and raise `MlflowException` with helpful hints for common mistakes (passing classes instead of instances, nesting `get_all_scorers()` result in a list).
- Task Evidence: Interface Description 2 — "Validate a list of specified scorers and ensure they are valid Scorer instances."
- Acceptance: The function returns a list of valid `Scorer` instances; raises on non-list input; raises with hints on class-not-instance, nested list, or invalid type errors.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` (lines 26–107); `/testbed/mlflow/genai/evaluation/base.py:243` (call site).
- Uncertainty: None.

### R3: valid_data_for_builtin_scorers validates DataFrame columns for builtin scorers
- Type: Dataflow
- Statement: Given a pandas DataFrame (already converted to legacy eval schema via `_convert_to_eval_set`), a list of `BuiltInScorer` instances, and an optional `predict_fn`, the function MUST revert the legacy column name mapping (`request`→`inputs`, `response`→`outputs`), infer column availability from `predict_fn` and `trace` presence, explode `expectations` dictionary keys into `expectations/{key}` columns, validate each scorer's required columns via `validate_columns`, and log (not raise) informative messages about missing columns.
- Task Evidence: Interface Description 2 — "Validate that the required columns are present in the data for running the builtin scorers."
- Acceptance: Missing columns produce logged warnings; non-dict `expectations` values raise `MlflowException`; columns inferred from trace/predict_fn are treated as present.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` (lines 109–174); `/testbed/mlflow/genai/evaluation/base.py:248` (call site); `/testbed/mlflow/genai/optimize/util.py:91` (call site).
- Uncertainty: None.

### R4: get_all_scorers returns all built-in scorers
- Type: Interface
- Statement: `get_all_scorers()` MUST return a list of instantiated `BuiltInScorer` objects containing `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, and `Equivalence`. When the tracking URI is a Databricks URI, it MUST additionally include `Safety` and `RetrievalRelevance`.
- Task Evidence: Interface Description 3 — "Get all available built-in scorers for MLflow GenAI evaluation."
- Acceptance: Returns 6 scorers for non-Databricks tracking URIs, 8 for Databricks URIs; all items are `Scorer` instances.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:get_all_scorers` (lines 1567–1597); `/testbed/tests/genai/scorers/test_builtin_scorers.py:test_get_all_scorers_oss` (lines 570–577); `/testbed/mlflow/genai/scorers/__init__.py` (`_LAZY_IMPORTS` includes `get_all_scorers`).
- Uncertainty: None.

### R5: CustomScorer preserves original function for serialization
- Type: Dataflow
- Statement: The `CustomScorer` inner class MUST store a reference to the original decorated function in `_original_func` (a `PrivateAttr`) so that `Scorer.model_dump()` and `Scorer._extract_source_code_info()` can access it for serialization.
- Task Evidence: Interface Description 1 (implied by serialization/registration requirements).
- Acceptance: `model_dump()` on a decorator scorer extracts source code via `_original_func`; `_extract_source_code_info()` returns `call_source`, `call_signature`, and `original_func_name`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:model_dump` (lines 155–177); `/testbed/mlflow/genai/scorers/base.py:_extract_source_code_info` (lines 179–198); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:CustomScorer` (lines 999–1016).
- Uncertainty: None.

### R6: validate_aggregations validates aggregation function specifications
- Type: Behavior
- Statement: `validate_aggregations` MUST accept a list of aggregation specs (strings or callables), validate that string aggregations are in the known set (`min`, `max`, `mean`, `median`, `variance`, `p90`), and that non-string items are callable. Invalid items raise `MlflowException`.
- Task Evidence: Implied by `Scorer` base class `aggregations` parameter documentation in Interface Description 1.
- Acceptance: Valid aggregations pass silently; invalid strings or non-callables raise.
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:validate_aggregations` (lines 177–203); `/testbed/mlflow/genai/scorers/aggregation.py:_AGGREGATE_FUNCTIONS`.
- Uncertainty: None.

### R7: evaluate() imports and calls validate_scorers and valid_data_for_builtin_scorers
- Type: Interface
- Statement: `mlflow.genai.evaluate()` MUST import `validate_scorers` and `valid_data_for_builtin_scorers` from `mlflow.genai.scorers.validation` and call them in the evaluation pipeline before running scorers.
- Task Evidence: Task statement mentions "Validate naming conventions and formats" and "Check batch logging constraints."
- Acceptance: The evaluate function's import section includes the validation imports; `validate_scorers` is called on line 243; `valid_data_for_builtin_scorers` is called on line 248.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/evaluation/base.py` (import at line 21); `/testbed/mlflow/genai/evaluation/base.py` (calls at lines 243, 248, missing import).
- Uncertainty: None.

### R8: optimize validate_train_data imports valid_data_for_builtin_scorers
- Type: Interface
- Statement: `validate_train_data` in `mlflow.genai.optimize.util` MUST import and call `valid_data_for_builtin_scorers` for builtin scorer validation.
- Task Evidence: Task mentions "Validate complex data structures like datasets, input tags, and batch operations."
- Acceptance: The import is present and `valid_data_for_builtin_scorers` is called at line 91.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/optimize/util.py` (import at line 11); `/testbed/mlflow/genai/optimize/util.py` (call at line 91, missing import).
- Uncertainty: None.

## L2. Functional Design Graph

### N1: scorer decorator
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:scorer` (line 847); `/testbed/mlflow/genai/scorers/__init__.py` (`scorer` export).

### N2: CustomScorer (inner class)
- Kind: Class
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:CustomScorer` (line 999, inner class of `scorer`).

### N3: Scorer (base class)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:Scorer` (line 107).

### N4: BuiltInScorer
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:BuiltInScorer` (line 259).

### N5: validate_scorers
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` (line 26).

### N6: valid_data_for_builtin_scorers
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` (line 109).

### N7: get_all_scorers
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:get_all_scorers` (line 1567).

### N8: mlflow.genai.evaluate
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/evaluation/base.py:evaluate` (line 52).

### N9: validate_train_data (optimize util)
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/optimize/util.py:validate_train_data` (line 78).

### N10: ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence, Safety, RetrievalRelevance
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py` (lines 826, 1196, 980, 464, 590, 1380, 1094, 335).

### N11: MissingColumnsException
- Kind: Error
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:MissingColumnsException` (line 1600).

### N12: validate_aggregations
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:validate_aggregations` (line 177).

### N13: _AGGREGATE_FUNCTIONS
- Kind: State
- Repository Evidence: `/testbed/mlflow/genai/scorers/aggregation.py:_AGGREGATE_FUNCTIONS` (line 17).

### N14: IS_DBX_AGENTS_INSTALLED
- Kind: State
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:IS_DBX_AGENTS_INSTALLED` (line 23).

### E1: scorer -> CustomScorer
- Kind: CONTROL
- Condition: `func is not None` (decorator called as `@scorer` without arguments)
- Transfer: Creates `CustomScorer` subclass dynamically, patches `__call__.__signature__`, instantiates and returns `CustomScorer(name=..., description=..., aggregations=...)`.
- Evidence: `/testbed/mlflow/genai/scorers/base.py:scorer` lines 994–1030; `/testbed/libs/skinny/mlflow/genai/scorers/base.py:scorer` lines 999–1031.
- Obligations: R1, R5

### E2: CustomScorer -> Scorer (inheritance)
- Kind: CONTROL
- Condition: Always (class definition)
- Transfer: `CustomScorer` inherits all `Scorer` fields, properties, and methods.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:CustomScorer(Scorer)`.
- Obligations: R1, R5

### E3: N8 (evaluate) -> N5 (validate_scorers)
- Kind: CALL
- Condition: Always (before any scoring)
- Transfer: `(scorers: list[Any]) -> list[Scorer]`
- Evidence: `/testbed/mlflow/genai/evaluation/base.py:243` (call); `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21` (import).
- Obligations: R2, R7

### E4: N8 (evaluate) -> N6 (valid_data_for_builtin_scorers)
- Kind: CALL
- Condition: After scorers are validated, before harness execution
- Transfer: `(df: pd.DataFrame, builtin_scorers: list[BuiltInScorer], predict_fn: Callable | None) -> None`
- Evidence: `/testbed/mlflow/genai/evaluation/base.py:248` (call); `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21` (import).
- Obligations: R3, R7

### E5: N9 (validate_train_data) -> N6 (valid_data_for_builtin_scorers)
- Kind: CALL
- Condition: After per-record input validation
- Transfer: `(train_data: pd.DataFrame, builtin_scorers: list[BuiltInScorer], predict_fn: Callable | None) -> None`
- Evidence: `/testbed/mlflow/genai/optimize/util.py:91` (call); `/testbed/libs/skinny/mlflow/genai/optimize/util.py:11` (import).
- Obligations: R3, R8

### E6: N7 (get_all_scorers) -> N10 (builtin scorer classes)
- Kind: CALL
- Condition: Always (constructs instances)
- Transfer: Returns list of instantiated `BuiltInScorer` subclasses; conditionally includes `Safety()` and `RetrievalRelevance()` for Databricks URIs.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:get_all_scorers` lines 1589–1597.
- Obligations: R4

### E7: N5 (validate_scorers) -> N14 (IS_DBX_AGENTS_INSTALLED)
- Kind: DATA
- Condition: When a scorer is not a `Scorer` instance
- Transfer: Reads `IS_DBX_AGENTS_INSTALLED` to decide whether to check for legacy `Metric` type.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` lines 51–56.
- Obligations: R2

### E8: N5 (validate_scorers) -> N7 (get_all_scorers)
- Kind: CALL
- Condition: When a scorer item is a list (to detect `scorers=[get_all_scorers()]` mistake)
- Transfer: Compares the list item against `get_all_scorers()` result for helpful error hints.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` line 62.
- Obligations: R2

### E9: N6 (valid_data_for_builtin_scorers) -> N4 (BuiltInScorer.validate_columns)
- Kind: CALL
- Condition: For each builtin scorer
- Transfer: Calls `scorer.validate_columns(input_columns)` to check required columns; catches `MissingColumnsException`.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 153–158.
- Obligations: R3

### E10: N12 (validate_aggregations) -> N13 (_AGGREGATE_FUNCTIONS)
- Kind: DATA
- Condition: Always
- Transfer: Reads `_AGGREGATE_FUNCTIONS.keys()` to validate string aggregation names.
- Evidence: `/testbed/mlflow/genai/scorers/validation.py:validate_aggregations` lines 188–198.
- Obligations: R6

### E11: N2 (CustomScorer._original_func) -> Scorer.model_dump
- Kind: DATA
- Condition: When `model_dump()` is called and `_original_func` is set
- Transfer: `_original_func` is used by `_extract_source_code_info()` to extract function body, signature, and name for serialization.
- Evidence: `/testbed/mlflow/genai/scorers/base.py:model_dump` (line 162 check `_original_func`); `_extract_source_code_info` (uses `self._original_func`).
- Obligations: R5

## L3. Verifiable Contracts

### C1: scorer decorator returns CustomScorer instance
- Type: Interface
- Subject: `scorer()` return value
- Relation: TYPE_IS
- Expected: `Scorer` (specifically a `CustomScorer` subclass instance)
- Evidence: Task Interface Description 1; `/testbed/tests/genai/scorers/test_scorer.py:test_scorer_existence_in_metrics` (uses `@scorer`-decorated function as scorer); `/testbed/tests/genai/scorers/test_scorer_description.py` (uses `@scorer` decorator).
- Observe: RETURN_VALUE
- Target: `scorer(func)(...)` — the decorated function is a `Scorer` instance callable in `mlflow.genai.evaluate()`.
- Obligations: R1, R5
- Graph: N1, N2, E1, E2

### C2: CustomScorer.kind returns DECORATOR
- Type: State
- Subject: `CustomScorer.kind` property
- Relation: EQ
- Expected: `ScorerKind.DECORATOR`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:CustomScorer.kind` (line 1014–1016).
- Observe: FIELD_READ
- Target: `scorer_instance.kind`
- Obligations: R1
- Graph: N2, E2

### C3: CustomScorer.__call__ delegates to original function
- Type: Behavior
- Subject: `CustomScorer.__call__`
- Relation: EQ
- Expected: `CustomScorer.__call__(*args, **kwargs)` returns the same result as `original_func(*args, **kwargs)`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:CustomScorer.__call__` (line 1012–1013); `/testbed/tests/genai/scorers/test_scorer.py:test_custom_scorer_allow_none_return` (line 568–572).
- Observe: RETURN_VALUE
- Target: `scorer_instance(inputs=..., outputs=...)`
- Obligations: R1
- Graph: N2, E1

### C4: scorer function early return for parameterized decorator use
- Type: Interface
- Subject: `scorer(func=None, *, name=..., description=..., aggregations=...)`
- Relation: TYPE_IS
- Expected: When `func is None`, returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)` — a callable ready to accept the function.
- Evidence: `/testbed/mlflow/genai/scorers/base.py:scorer` lines 994–997; `/testbed/tests/genai/scorers/test_scorer_description.py:test_decorator_scorer_with_name_and_description` (uses `@scorer(name="custom_name", description=description)`).
- Observe: RETURN_VALUE
- Target: `scorer(name="x")` returns a callable `partial`.
- Obligations: R1
- Graph: N1

### C5: validate_scorers rejects non-list input
- Type: Failure
- Subject: `validate_scorers(scorers)` when `scorers` is not a `list`
- Relation: RAISES
- Expected: `MlflowException` with message containing "must be a list of scorers"
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` lines 36–40; task Interface Description 2.
- Observe: EXCEPTION
- Target: `validate_scorers("not_a_list")` raises `MlflowException`.
- Obligations: R2
- Graph: N5, E3

### C6: validate_scorers accepts empty list
- Type: Behavior
- Subject: `validate_scorers([])`
- Relation: EQ
- Expected: Returns `[]`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` lines 43–44; Interface Description 2 note: "Empty lists are valid and return an empty list."
- Observe: RETURN_VALUE
- Target: `validate_scorers([])`
- Obligations: R2
- Graph: N5

### C7: validate_scorers accepts Scorer instances
- Type: Behavior
- Subject: `validate_scorers([Scorer_instance])`
- Relation: EQ
- Expected: Returns the same list of `Scorer` instances unchanged
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` line 49; `/testbed/mlflow/genai/evaluation/base.py:243`.
- Observe: RETURN_VALUE
- Target: `validate_scorers([Correctness()])`
- Obligations: R2
- Graph: N5, E3

### C8: validate_scorers raises with hint for class-not-instance
- Type: Failure
- Subject: `validate_scorers([BuiltInScorer_subclass])` (class, not instance)
- Relation: RAISES
- Expected: `MlflowException` with hint "It looks like you passed a scorer class instead of an instance"
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:validate_scorers` lines 69–73; Interface Description 2.
- Observe: EXCEPTION
- Target: `validate_scorers([Correctness])` raises `MlflowException`.
- Obligations: R2
- Graph: N5, N4

### C9: valid_data_for_builtin_scorers reverts legacy column names
- Type: Dataflow
- Subject: Column name mapping in `valid_data_for_builtin_scorers`
- Relation: PRESERVE
- Expected: `request` column is treated as `inputs`; `response` column is treated as `outputs`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 118–124; Interface Description 2 notes: "performs automatic column name mapping: 'request' -> 'inputs' and 'response' -> 'outputs'."
- Observe: SIDE_EFFECT
- Target: `valid_data_for_builtin_scorers(df, builtin_scorers)` — scorers see `inputs`/`outputs` even when DataFrame has `request`/`response`.
- Obligations: R3
- Graph: N6, E4, E5

### C10: valid_data_for_builtin_scorers infers outputs from predict_fn
- Type: Dataflow
- Subject: `outputs` column availability when `predict_fn` is provided
- Relation: PRESERVE
- Expected: When `predict_fn is not None`, the function treats `outputs` column as present even if missing from DataFrame.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 126–128; Interface Description 2.
- Observe: SIDE_EFFECT
- Target: `valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn=my_fn)` — `outputs` treated as present.
- Obligations: R3
- Graph: N6, E4

### C11: valid_data_for_builtin_scorers infers inputs/outputs from trace column
- Type: Dataflow
- Subject: Column availability when `trace` column is present
- Relation: PRESERVE
- Expected: When `trace` column exists, `inputs` and `outputs` columns are treated as present.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 130–132; Interface Description 2.
- Observe: SIDE_EFFECT
- Target: `valid_data_for_builtin_scorers(df_with_trace, builtin_scorers)` — `inputs`/`outputs` treated as present.
- Obligations: R3
- Graph: N6, E4

### C12: valid_data_for_builtin_scorers raises on non-dict expectations
- Type: Failure
- Subject: Non-dictionary value in `expectations` column
- Relation: RAISES
- Expected: `MlflowException` with message about expectations being a dictionary
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 138–143; Interface Description 2: "Raises: MlflowException: Raised if the 'expectations' column contains non-dictionary values."
- Observe: EXCEPTION
- Target: `valid_data_for_builtin_scorers(df_with_bad_expectations, builtin_scorers)` raises.
- Obligations: R3
- Graph: N6

### C13: valid_data_for_builtin_scorers logs missing columns
- Type: SideEffect
- Subject: Missing column detection
- Relation: CONTAINS
- Expected: When columns required by scorers are missing, the function logs an info message listing which scorers require which missing columns.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` lines 160–174; Interface Description 2: "When required columns are missing, the function logs an informative message."
- Observe: SIDE_EFFECT
- Target: Log output when `valid_data_for_builtin_scorers` detects missing columns.
- Obligations: R3
- Graph: N6, N11

### C14: get_all_scorers returns correct count for non-Databricks URI
- Type: Behavior
- Subject: `get_all_scorers()` return length with file:/http: tracking URI
- Relation: EQ
- Expected: Returns 6 scorers (ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence)
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:get_all_scorers` lines 1589–1595; `/testbed/tests/genai/scorers/test_builtin_scorers.py:test_get_all_scorers_oss` (line 577: `assert len(scorers) == (8 if tracking_uri == "databricks" else 6)`).
- Observe: RETURN_VALUE
- Target: `len(get_all_scorers())` with `file://test` tracking URI.
- Obligations: R4
- Graph: N7, N10, E6

### C15: get_all_scorers includes Safety and RetrievalRelevance for Databricks URI
- Type: Behavior
- Subject: `get_all_scorers()` return with Databricks tracking URI
- Relation: CONTAINS
- Expected: Returned list includes `Safety()` and `RetrievalRelevance()` instances alongside the base 6.
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:get_all_scorers` lines 1596–1597; `/testbed/tests/genai/scorers/test_builtin_scorers.py:test_get_all_scorers_oss` (line 577).
- Observe: RETURN_VALUE
- Target: `get_all_scorers()` with Databricks tracking URI.
- Obligations: R4
- Graph: N7, N10, E6

### C16: get_all_scorers returns Scorer instances
- Type: Interface
- Subject: Each element of `get_all_scorers()` return
- Relation: TYPE_IS
- Expected: Every element is an instance of `Scorer` (specifically `BuiltInScorer`).
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:get_all_scorers` return type annotation `list[BuiltInScorer]`; `/testbed/tests/genai/scorers/test_builtin_scorers.py:test_get_all_scorers_oss` (line 578: `all(isinstance(scorer, Scorer) for scorer in scorers)`).
- Observe: RETURN_VALUE
- Target: `isinstance(scorer, Scorer)` for each scorer in `get_all_scorers()`.
- Obligations: R4
- Graph: N7, N10

### C17: evaluate imports validate_scorers and valid_data_for_builtin_scorers
- Type: Interface
- Subject: Import statement in `/testbed/mlflow/genai/evaluation/base.py`
- Relation: CONTAINS
- Expected: The file contains `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers`
- Evidence: `/testbed/libs/skinny/mlflow/genai/evaluation/base.py` line 21; calls at lines 243, 248 in main `/testbed/mlflow/genai/evaluation/base.py`.
- Observe: IMPORT_BOUNDARY
- Target: The import section of `/testbed/mlflow/genai/evaluation/base.py`.
- Obligations: R7
- Graph: N8, E3, E4

### C18: optimize util imports valid_data_for_builtin_scorers
- Type: Interface
- Subject: Import statement in `/testbed/mlflow/genai/optimize/util.py`
- Relation: CONTAINS
- Expected: The file contains `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers`
- Evidence: `/testbed/libs/skinny/mlflow/genai/optimize/util.py` line 11; call at line 91 in main `/testbed/mlflow/genai/optimize/util.py`.
- Observe: IMPORT_BOUNDARY
- Target: The import section of `/testbed/mlflow/genai/optimize/util.py`.
- Obligations: R8
- Graph: N9, E5

### C19: validate_aggregations accepts valid aggregation strings
- Type: Behavior
- Subject: `validate_aggregations(["min", "max", "mean"])`
- Relation: EQ
- Expected: Returns `None` (passes silently)
- Evidence: `/testbed/mlflow/genai/scorers/validation.py:validate_aggregations` lines 185–187.
- Observe: RETURN_VALUE
- Target: `validate_aggregations(["min", "mean"])` returns `None`.
- Obligations: R6
- Graph: N12, N13, E10

### C20: validate_aggregations rejects invalid aggregation name
- Type: Failure
- Subject: `validate_aggregations(["invalid_name"])`
- Relation: RAISES
- Expected: `MlflowException` with message "Invalid aggregation 'invalid_name'"
- Evidence: `/testbed/mlflow/genai/scorers/validation.py:validate_aggregations` lines 194–198.
- Observe: EXCEPTION
- Target: `validate_aggregations(["bad"])` raises `MlflowException`.
- Obligations: R6
- Graph: N12, N13, E10

### C21: validate_aggregations rejects non-callable non-string
- Type: Failure
- Subject: `validate_aggregations([42])`
- Relation: RAISES
- Expected: `MlflowException` with message containing "must be either a string from"
- Evidence: `/testbed/mlflow/genai/scorers/validation.py:validate_aggregations` lines 199–203.
- Observe: EXCEPTION
- Target: `validate_aggregations([42])` raises `MlflowException`.
- Obligations: R6
- Graph: N12
