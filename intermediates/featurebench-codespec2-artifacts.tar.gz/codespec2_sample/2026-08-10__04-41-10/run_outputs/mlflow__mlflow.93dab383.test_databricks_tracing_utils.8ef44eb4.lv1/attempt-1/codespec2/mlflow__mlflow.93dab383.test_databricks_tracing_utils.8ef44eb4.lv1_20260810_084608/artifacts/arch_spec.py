"""Architecture spec: public interface, graph connectivity, L3 Interface/Dataflow contracts.

Covers contracts: C1-C14, C16-C21, C24
Each check_* function is a no-arg top-level. Calls all checks and prints PASS: on success.
"""

import sys
import warnings
from unittest.mock import patch

import pytest


# ── helpers ──────────────────────────────────────────────────────────────────

def _make_uc_schema_location(catalog="my_catalog", schema="my_schema"):
    """Create a UCSchemaLocation fixture."""
    from mlflow.entities.trace_location import UCSchemaLocation
    return UCSchemaLocation(catalog_name=catalog, schema_name=schema)


def _make_assessment_with_feedback(trace_id="trace:/my_catalog.my_schema/trace_123"):
    """Create an Assessment with feedback for protobuf conversion tests."""
    import time
    from mlflow.entities.assessment import Assessment, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource

    return Assessment(
        name="test_assessment",
        trace_id=trace_id,
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(0.95),
        rationale="Good answer",
        metadata={"key1": "value1"},
        span_id="span_001",
        assessment_id="a-001",
    )


def _make_assessment_with_expectation(trace_id="trace:/my_catalog.my_schema/trace_123"):
    """Create an Assessment with expectation for protobuf conversion tests."""
    import time
    from mlflow.entities.assessment import Assessment, ExpectationValue
    from mlflow.entities.assessment_source import AssessmentSource

    return Assessment(
        name="expected_answer",
        trace_id=trace_id,
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        expectation=ExpectationValue(value="The expected answer"),
    )


# ── C24: AssessmentSourceType constants are simple string values ──────────────

# Contracts: C24
def check_assessment_source_type_constants_are_strings() -> None:
    """Verify AssessmentSourceType constants are plain strings, not dicts."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert isinstance(AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED, str), (
        "SOURCE_TYPE_UNSPECIFIED must be str"
    )
    assert isinstance(AssessmentSourceType.LLM_JUDGE, str), "LLM_JUDGE must be str"
    assert isinstance(AssessmentSourceType.AI_JUDGE, str), "AI_JUDGE must be str"
    assert isinstance(AssessmentSourceType.HUMAN, str), "HUMAN must be str"
    assert isinstance(AssessmentSourceType.CODE, str), "CODE must be str"

    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.CODE == "CODE"

    # _SOURCE_TYPES excludes deprecated AI_JUDGE
    assert isinstance(AssessmentSourceType._SOURCE_TYPES, list)
    assert AssessmentSourceType.LLM_JUDGE in AssessmentSourceType._SOURCE_TYPES
    assert AssessmentSourceType.HUMAN in AssessmentSourceType._SOURCE_TYPES
    assert AssessmentSourceType.CODE in AssessmentSourceType._SOURCE_TYPES
    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED in AssessmentSourceType._SOURCE_TYPES
    assert AssessmentSourceType.AI_JUDGE not in AssessmentSourceType._SOURCE_TYPES, (
        "AI_JUDGE must not be in _SOURCE_TYPES (deprecated)"
    )


# ── C21: AssessmentSourceType._standardize returns uppercase validated string ──

# Contracts: C21
def check_standardize_normalizes_case() -> None:
    """Verify _standardize normalizes case and delegates to constructor + str()."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("Human") == "HUMAN"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("Llm_Judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("CODE") == "CODE"
    assert AssessmentSourceType._standardize("code") == "CODE"


# Contracts: C21
# Perspective: tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning
# Reference: exact FutureWarning message "AI_JUDGE is deprecated. Use LLM_JUDGE instead."
def check_standardize_deprecates_ai_judge() -> None:
    """Verify _standardize maps AI_JUDGE -> LLM_JUDGE with exact FutureWarning message."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated"):
        result = AssessmentSourceType._standardize("AI_JUDGE")
        assert result == "LLM_JUDGE", f"Expected LLM_JUDGE, got {result}"


# ── C7: inference_table_location_to_proto maps full_table_name ────────────────

# Contracts: C7
def check_inference_table_location_to_proto() -> None:
    """Verify inference_table_location_to_proto returns correct protobuf."""
    from mlflow.entities.trace_location import InferenceTableLocation
    from mlflow.utils.databricks_tracing_utils import inference_table_location_to_proto

    loc = InferenceTableLocation(full_table_name="catalog.schema.table")
    proto = inference_table_location_to_proto(loc)
    assert proto.full_table_name == "catalog.schema.table"


# ── C8: mlflow_experiment_location_to_proto maps experiment_id ────────────────

# Contracts: C8
def check_mlflow_experiment_location_to_proto() -> None:
    """Verify mlflow_experiment_location_to_proto returns correct protobuf."""
    from mlflow.entities.trace_location import MlflowExperimentLocation
    from mlflow.utils.databricks_tracing_utils import mlflow_experiment_location_to_proto

    loc = MlflowExperimentLocation(experiment_id="exp_456")
    proto = mlflow_experiment_location_to_proto(loc)
    assert proto.experiment_id == "exp_456"


# ── C18: uc_schema_location_to_proto maps all fields ─────────────────────────

# Contracts: C18
def check_uc_schema_location_to_proto() -> None:
    """Verify uc_schema_location_to_proto includes private table name fields."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto

    loc = _make_uc_schema_location("cat", "sch")
    loc._otel_spans_table_name = "custom_spans"
    loc._otel_logs_table_name = "custom_logs"

    proto = uc_schema_location_to_proto(loc)
    assert proto.catalog_name == "cat"
    assert proto.schema_name == "sch"
    assert proto.otel_spans_table_name == "custom_spans"
    assert proto.otel_logs_table_name == "custom_logs"


# ── C14, C17: uc_schema_location_from_proto ─────────────────────────────────

# Contracts: C14, C17
# Perspective: tests/entities/trace_location.py — HasField() guards optional fields
def check_uc_schema_location_from_proto_basic() -> None:
    """Verify uc_schema_location_from_proto extracts catalog and schema.
    Also verifies optional otel table names are absent when not in proto."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto

    proto = pb.UCSchemaLocation(catalog_name="cat", schema_name="sch")
    loc = uc_schema_location_from_proto(proto)
    assert loc.catalog_name == "cat"
    assert loc.schema_name == "sch"
    # F9: when proto has no optional fields, the private attrs should be absent
    assert not hasattr(loc, "_otel_spans_table_name"), (
        "_otel_spans_table_name should NOT be set when proto lacks the field"
    )
    assert not hasattr(loc, "_otel_logs_table_name"), (
        "_otel_logs_table_name should NOT be set when proto lacks the field"
    )


# Contracts: C17
def check_uc_schema_location_from_proto_optional_tables() -> None:
    """Verify uc_schema_location_from_proto handles optional otel table names."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto

    proto = pb.UCSchemaLocation(
        catalog_name="cat",
        schema_name="sch",
        otel_spans_table_name="spans_tbl",
        otel_logs_table_name="logs_tbl",
    )
    loc = uc_schema_location_from_proto(proto)
    assert loc._otel_spans_table_name == "spans_tbl"
    assert loc._otel_logs_table_name == "logs_tbl"


# ── C13, C14: trace_location_from_proto dispatching ──────────────────────────

# Contracts: C13
def check_trace_location_from_proto_uc_schema() -> None:
    """Verify trace_location_from_proto dispatches to uc_schema handler."""
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
        uc_schema=pb.UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    loc = trace_location_from_proto(proto)
    assert loc.type == TraceLocationType.UC_SCHEMA
    assert loc.uc_schema is not None
    assert loc.uc_schema.catalog_name == "cat"
    assert loc.uc_schema.schema_name == "sch"


# Contracts: C14
def check_trace_location_from_proto_fallback_unspecified() -> None:
    """Verify trace_location_from_proto returns UNSPECIFIED when no identifier."""
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED,
    )
    loc = trace_location_from_proto(proto)
    assert loc.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED


# ── C12: trace_location_to_proto dispatches correctly ───────────────────────

# Contracts: C12
def check_trace_location_to_proto_uc_schema() -> None:
    """Verify trace_location_to_proto dispatches to uc_schema_location_to_proto."""
    from mlflow.entities.trace_location import TraceLocation, TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import (
        trace_location_to_proto,
        uc_schema_location_to_proto,
    )

    uc_loc = _make_uc_schema_location("cat", "sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)

    with patch(
        "mlflow.utils.databricks_tracing_utils.uc_schema_location_to_proto",
        wraps=uc_schema_location_to_proto,
    ) as spy:
        proto = trace_location_to_proto(trace_loc)
        spy.assert_called_once_with(uc_loc)

    assert proto.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA
    assert proto.uc_schema.catalog_name == "cat"


# Contracts: C12
def check_trace_location_to_proto_mlflow_experiment() -> None:
    """Verify trace_location_to_proto dispatches to mlflow_experiment handler."""
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import (
        mlflow_experiment_location_to_proto,
        trace_location_to_proto,
    )

    exp_loc = MlflowExperimentLocation(experiment_id="exp_1")
    trace_loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT, mlflow_experiment=exp_loc
    )

    with patch(
        "mlflow.utils.databricks_tracing_utils.mlflow_experiment_location_to_proto",
        wraps=mlflow_experiment_location_to_proto,
    ) as spy:
        proto = trace_location_to_proto(trace_loc)
        spy.assert_called_once_with(exp_loc)

    assert proto.type == pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    assert proto.mlflow_experiment.experiment_id == "exp_1"


# Contracts: C12
def check_trace_location_to_proto_inference_table() -> None:
    """Verify trace_location_to_proto dispatches to inference_table handler."""
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import (
        inference_table_location_to_proto,
        trace_location_to_proto,
    )

    inf_loc = InferenceTableLocation(full_table_name="c.s.t")
    trace_loc = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE, inference_table=inf_loc
    )

    with patch(
        "mlflow.utils.databricks_tracing_utils.inference_table_location_to_proto",
        wraps=inference_table_location_to_proto,
    ) as spy:
        proto = trace_location_to_proto(trace_loc)
        spy.assert_called_once_with(inf_loc)

    assert proto.type == pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    assert proto.inference_table.full_table_name == "c.s.t"


# Reusable import for roundtrip helpers above
# (defined after they are used to avoid duplication; actual import is inline)
# The roundtrip helpers use trace_location_to_proto from the databricks_tracing_utils
def trace_location_to_proto_impl(trace_loc):
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    return trace_location_to_proto(trace_loc)


# ── F2: TraceLocation proto roundtrip checks ─────────────────────────────────

# Contracts: C12, C13
# Perspective: tests/entities/test_trace_location.py::test_trace_location
# Reference: from_proto = TraceLocation.from_proto(trace_location.to_proto()); assert from_proto == trace_location
def check_trace_location_proto_roundtrip_uc_schema() -> None:
    """Verify TraceLocation roundtrips through to_proto/from_proto for UC_SCHEMA."""
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    from_proto = TraceLocation.from_proto(trace_location_to_proto_impl(trace_loc))
    assert from_proto == trace_loc


def check_trace_location_proto_roundtrip_mlflow_experiment() -> None:
    """Verify TraceLocation roundtrips through to_proto/from_proto for MLFLOW_EXPERIMENT."""
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )

    exp_loc = MlflowExperimentLocation(experiment_id="exp_42")
    trace_loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT, mlflow_experiment=exp_loc
    )
    from_proto = TraceLocation.from_proto(trace_location_to_proto_impl(trace_loc))
    assert from_proto == trace_loc


def check_trace_location_proto_roundtrip_inference_table() -> None:
    """Verify TraceLocation roundtrips through to_proto/from_proto for INFERENCE_TABLE."""
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        TraceLocation,
        TraceLocationType,
    )

    inf_loc = InferenceTableLocation(full_table_name="cat.sch.tbl")
    trace_loc = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE, inference_table=inf_loc
    )
    from_proto = TraceLocation.from_proto(trace_location_to_proto_impl(trace_loc))
    assert from_proto == trace_loc



# ── C1, C2, C3, C4: assessment_to_proto ─────────────────────────────────────

# Contracts: C1
# Perspective: tests/store/tracking/test_databricks_rest_store.py line 1075
# Reference: assessment_to_proto used for wire serialization; source_type uses protobuf enum
def check_assessment_to_proto_required_fields() -> None:
    """Verify assessment_to_proto populates all required fields."""
    from mlflow.protos.assessments_pb2 import AssessmentSource as ProtoAssessmentSource
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assessment = _make_assessment_with_feedback()
    proto = assessment_to_proto(assessment)

    assert proto.assessment_name == assessment.name
    # For v4 trace_id, the raw trace_id is extracted
    assert proto.trace_id == "trace_123"
    # F6: use proper protobuf enum value instead of magic number
    assert proto.source.source_type == ProtoAssessmentSource.SourceType.Value("HUMAN")
    # timestamps are set
    assert proto.create_time.ToMilliseconds() == assessment.create_time_ms
    assert proto.last_update_time.ToMilliseconds() == assessment.last_update_time_ms


# Contracts: C2
def check_assessment_to_proto_v4_trace_id_uc_schema() -> None:
    """Verify v4 trace_id parsing constructs UC_SCHEMA trace_location."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assessment = _make_assessment_with_feedback(
        trace_id="trace:/my_catalog.my_schema/trace_123"
    )
    proto = assessment_to_proto(assessment)

    assert proto.HasField("trace_location")
    assert proto.trace_location.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA
    assert proto.trace_location.uc_schema.catalog_name == "my_catalog"
    assert proto.trace_location.uc_schema.schema_name == "my_schema"
    assert proto.trace_id == "trace_123"


# Contracts: C3
def check_assessment_to_proto_optional_fields() -> None:
    """Verify optional fields are only set when present."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    # Assessment with minimal fields
    import time
    from mlflow.entities.assessment import Assessment, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource

    minimal = Assessment(
        name="minimal",
        trace_id="trace:/c.s/tid",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(1.0),
    )
    proto = assessment_to_proto(minimal)
    # Optional fields should not be set
    assert not proto.HasField("span_id") or proto.span_id == ""
    assert not proto.HasField("rationale") or proto.rationale == ""
    assert not proto.HasField("assessment_id") or proto.assessment_id == ""

    # Assessment with optional fields
    full = _make_assessment_with_feedback()
    proto_full = assessment_to_proto(full)
    assert proto_full.span_id == "span_001"
    assert proto_full.rationale == "Good answer"
    assert proto_full.assessment_id == "a-001"


# Contracts: C3
def check_assessment_to_proto_metadata_string_conversion() -> None:
    """Verify metadata values are converted to strings."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    # metadata with non-string values (int, bool, float) — F7 enriched
    import time
    from mlflow.entities.assessment import Assessment, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource

    assessment = Assessment(
        name="meta_test",
        trace_id="trace:/c.s/tid",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(0.95),
        metadata={"int_key": 42, "bool_key": True, "float_key": 3.14, "str_key": "hello"},
    )
    proto = assessment_to_proto(assessment)
    assert dict(proto.metadata) == {"int_key": "42", "bool_key": "True", "float_key": "3.14", "str_key": "hello"}


# Contracts: C4
def check_assessment_to_proto_feedback_not_expectation() -> None:
    """Verify exactly one of expectation/feedback is set."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    feedback_assessment = _make_assessment_with_feedback()
    proto_fb = assessment_to_proto(feedback_assessment)
    assert proto_fb.HasField("feedback")
    assert not proto_fb.HasField("expectation")

    expectation_assessment = _make_assessment_with_expectation()
    proto_exp = assessment_to_proto(expectation_assessment)
    assert proto_exp.HasField("expectation")
    assert not proto_exp.HasField("feedback")


# ── C5, C6: get_trace_id_from_assessment_proto ──────────────────────────────

# Contracts: C5
def check_get_trace_id_from_assessment_proto_uc_schema() -> None:
    """Verify get_trace_id_from_assessment_proto constructs v4 ID for UC Schema."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    proto = pb.Assessment()
    proto.trace_id = "trace_123"
    proto.trace_location.CopyFrom(
        pb.TraceLocation(
            type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
            uc_schema=pb.UCSchemaLocation(catalog_name="cat", schema_name="sch"),
        )
    )
    result = get_trace_id_from_assessment_proto(proto)
    assert result == "trace:/cat.sch/trace_123"


# Contracts: C6
def check_get_trace_id_from_assessment_proto_no_location() -> None:
    """Verify get_trace_id_from_assessment_proto returns raw trace_id."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    proto = pb.Assessment()
    proto.trace_id = "raw_trace_456"
    result = get_trace_id_from_assessment_proto(proto)
    assert result == "raw_trace_456"


# ── C9: trace_from_proto ────────────────────────────────────────────────────

# Contracts: C9
def check_trace_from_proto_returns_trace() -> None:
    """Verify trace_from_proto returns Trace with info and data."""
    from mlflow.entities import Trace
    from mlflow.utils.databricks_tracing_utils import trace_from_proto

    from mlflow.protos import databricks_tracing_pb2 as pb

    # Build a minimal proto Trace
    proto_trace = pb.Trace()
    proto_trace.trace_info.trace_id = "test_trace_id"
    proto_trace.trace_info.trace_location.CopyFrom(
        pb.TraceLocation(
            type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
            uc_schema=pb.UCSchemaLocation(catalog_name="cat", schema_name="sch"),
        )
    )
    proto_trace.trace_info.request_time.FromMilliseconds(1000)
    proto_trace.trace_info.state = pb.TraceInfo.State.OK

    # Add a minimal span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    otel_span = OTelProtoSpan()
    otel_span.trace_id = b"\x00" * 16
    otel_span.span_id = b"\x00" * 8
    otel_span.name = "test_span"
    otel_span.start_time_unix_nano = 1000000000
    otel_span.end_time_unix_nano = 2000000000
    proto_trace.spans.append(otel_span)

    result = trace_from_proto(proto_trace, "cat.sch")
    assert isinstance(result, Trace)
    assert result.info is not None
    assert result.data is not None
    assert len(result.data.spans) == 1


# ── F10 - E14: trace_from_proto calls Span.from_otel_proto with location_id ─

# Contracts: C9 (chain verification for E14)
def check_trace_from_proto_calls_span_from_otel_proto() -> None:
    """Verify trace_from_proto calls Span.from_otel_proto with location_id passthrough."""
    from mlflow.entities.span import Span
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import trace_from_proto

    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    # Build proto trace with one span
    proto_trace = pb.Trace()
    proto_trace.trace_info.trace_id = "test_trace_id"
    proto_trace.trace_info.trace_location.CopyFrom(
        pb.TraceLocation(
            type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
            uc_schema=pb.UCSchemaLocation(catalog_name="cat", schema_name="sch"),
        )
    )
    proto_trace.trace_info.request_time.FromMilliseconds(1000)
    proto_trace.trace_info.state = pb.TraceInfo.State.OK

    otel_span = OTelProtoSpan()
    otel_span.trace_id = b"\x00" * 16
    otel_span.span_id = b"\x00" * 8
    otel_span.name = "test_span"
    otel_span.start_time_unix_nano = 1000000000
    otel_span.end_time_unix_nano = 2000000000
    proto_trace.spans.append(otel_span)

    with patch(
        "mlflow.utils.databricks_tracing_utils.Span.from_otel_proto",
        wraps=Span.from_otel_proto,
    ) as spy:
        result = trace_from_proto(proto_trace, "cat.sch")
        spy.assert_called_once()
        # Verify location_id is passed through
        assert spy.call_args[0][1] == "cat.sch"


# ── C10, C11, C12: trace_info_to_v4_proto ──────────────────────────────────

# Contracts: C10, C12
# Perspective: tests/entities/test_trace_info.py lines 164-175
# Reference: proto_trace_info_v4 = trace_info_v4.to_proto() verifies state, previews, tags
def check_trace_info_to_v4_proto_uc_schema_parses_trace_id() -> None:
    """Verify trace_info_to_v4_proto parses v4 trace_id and sets all fields for UC Schema."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/raw_123",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
        request_preview="req_preview_data",
        response_preview="resp_preview_data",
        client_request_id="client_req_42",
        trace_metadata={"meta_k": "meta_v"},
        tags={"tag_k": "tag_v"},
    )
    proto = trace_info_to_v4_proto(trace_info)
    # F5: verify all fields populated
    assert proto.trace_id == "raw_123"
    assert proto.state == pb.TraceInfo.State.Value("OK")
    assert proto.request_preview == "req_preview_data"
    assert proto.response_preview == "resp_preview_data"
    assert proto.client_request_id == "client_req_42"
    assert dict(proto.tags) == {"tag_k": "tag_v"}
    assert dict(proto.trace_metadata) == {"meta_k": "meta_v"}


# Contracts: C12
def check_trace_info_to_v4_proto_timestamp_conversion() -> None:
    """Verify timestamps are converted from ms to protobuf Timestamp/Duration."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/raw_456",
        trace_location=trace_loc,
        request_time=5000,
        execution_duration=3000,
        state=TraceState.OK,
    )
    proto = trace_info_to_v4_proto(trace_info)
    assert proto.request_time.ToMilliseconds() == 5000
    assert proto.execution_duration.ToMilliseconds() == 3000


# Contracts: C11
# F10 - E5: spy-verify assessment_to_proto called per assessment from trace_info_to_v4_proto
def check_trace_info_to_v4_proto_includes_assessments() -> None:
    """Verify assessments are converted via assessment_to_proto with spy verification."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import (
        assessment_to_proto,
        trace_info_to_v4_proto,
    )

    assessment = _make_assessment_with_feedback(
        trace_id="trace:/cat.sch/raw_789"
    )

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/raw_789",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
        assessments=[assessment],
    )

    with patch(
        "mlflow.utils.databricks_tracing_utils.assessment_to_proto",
        wraps=assessment_to_proto,
    ) as spy:
        proto = trace_info_to_v4_proto(trace_info)
        spy.assert_called_once_with(assessment)

    assert len(proto.assessments) == 1
    assert proto.assessments[0].assessment_name == "test_assessment"


# ── F10 - E2: trace_info_to_v4_proto calls trace_location_to_proto ──────────

# Contracts: C10, C12 (chain verification for E2)
def check_trace_info_to_v4_proto_calls_trace_location_to_proto() -> None:
    """Spy-verify trace_info_to_v4_proto calls trace_location_to_proto with trace location."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import (
        trace_info_to_v4_proto,
        trace_location_to_proto,
    )

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/raw_456",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
    )

    with patch(
        "mlflow.utils.databricks_tracing_utils.trace_location_to_proto",
        wraps=trace_location_to_proto,
    ) as spy:
        proto = trace_info_to_v4_proto(trace_info)
        spy.assert_called_once_with(trace_loc)


# ── C16: trace_to_proto ─────────────────────────────────────────────────────

# Contracts: C16
def check_trace_to_proto() -> None:
    """Verify trace_to_proto returns pb.Trace with info and spans."""
    from mlflow.entities import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_to_proto

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/raw_000",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
    )
    trace_data = TraceData(spans=[])
    trace = Trace(info=trace_info, data=trace_data)

    proto = trace_to_proto(trace)
    assert proto.HasField("trace_info")
    assert len(proto.spans) == 0


# ── C19, C20: Span.inputs and Span.outputs properties ────────────────────────

# Contracts: C19
def check_span_inputs_property_exists_and_delegates() -> None:
    """Verify Span.inputs property delegates to get_attribute(INPUTS)."""
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    import opentelemetry.sdk.trace as otel_sdk

    tracer = otel_sdk.TracerProvider().get_tracer("test")
    with tracer.start_as_current_span("test_span") as otel_span:
        otel_span.set_attribute(
            SpanAttributeKey.INPUTS, '{"query": "hello"}'
        )
        span = Span(otel_span)
        assert span.inputs == {"query": "hello"}

    # Verify None when no inputs attribute
    with tracer.start_as_current_span("empty_span") as otel_span2:
        span2 = Span(otel_span2)
        assert span2.inputs is None


# Contracts: C20
def check_span_outputs_property_exists_and_delegates() -> None:
    """Verify Span.outputs property delegates to get_attribute(OUTPUTS)."""
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    import opentelemetry.sdk.trace as otel_sdk

    tracer = otel_sdk.TracerProvider().get_tracer("test")
    with tracer.start_as_current_span("test_span") as otel_span:
        otel_span.set_attribute(
            SpanAttributeKey.OUTPUTS, '"result value"'
        )
        span = Span(otel_span)
        assert span.outputs == "result value"

    # Verify None when no outputs attribute
    with tracer.start_as_current_span("empty_span") as otel_span2:
        span2 = Span(otel_span2)
        assert span2.outputs is None


# ── E1: TraceInfo.to_proto calls trace_info_to_v4_proto for v4 traces ────────

# Contracts: C10 (chain verification)
def check_trace_info_to_proto_dispatches_to_v4() -> None:
    """Verify TraceInfo.to_proto() calls trace_info_to_v4_proto for UC Schema."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/tid",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
    )

    with patch(
        "mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto",
        wraps=trace_info_to_v4_proto,
    ) as spy:
        proto = trace_info.to_proto()
        spy.assert_called_once_with(trace_info)


# ── F11: TraceInfo.to_proto non-v4 path does NOT dispatch to v4 ──────────────

# Contracts: C10 (negative chain verification)
# Reference: TraceInfo.to_proto() branches on self._is_v4()
def check_trace_info_to_proto_non_v4_does_not_dispatch() -> None:
    """Verify TraceInfo.to_proto() does NOT call trace_info_to_v4_proto for non-UC traces."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    exp_loc = MlflowExperimentLocation(experiment_id="exp_99")
    trace_loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT, mlflow_experiment=exp_loc
    )
    trace_info = TraceInfo(
        trace_id="non_uc_trace_id",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
    )

    with patch(
        "mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto",
        wraps=trace_info_to_v4_proto,
    ) as spy:
        proto = trace_info.to_proto()
        spy.assert_not_called()


# ── E6: TraceLocation.from_proto calls trace_location_from_proto ──────────────

# Contracts: C13 (chain verification)
def check_trace_location_from_proto_classmethod() -> None:
    """Verify TraceLocation.from_proto() calls trace_location_from_proto."""
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
        uc_schema=pb.UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )

    with patch(
        "mlflow.utils.databricks_tracing_utils.trace_location_from_proto",
        wraps=trace_location_from_proto,
    ) as spy:
        result = TraceLocation.from_proto(proto)
        spy.assert_called_once_with(proto)

    assert result.uc_schema.catalog_name == "cat"


# ── runner ───────────────────────────────────────────────────────────────────

_ALL_CHECKS = [
    check_assessment_source_type_constants_are_strings,
    check_standardize_normalizes_case,
    check_standardize_deprecates_ai_judge,
    check_inference_table_location_to_proto,
    check_mlflow_experiment_location_to_proto,
    check_uc_schema_location_to_proto,
    check_uc_schema_location_from_proto_basic,
    check_uc_schema_location_from_proto_optional_tables,
    check_trace_location_from_proto_uc_schema,
    check_trace_location_from_proto_fallback_unspecified,
    check_trace_location_to_proto_uc_schema,
    check_trace_location_to_proto_mlflow_experiment,
    check_trace_location_to_proto_inference_table,
    # F2: roundtrip checks
    check_trace_location_proto_roundtrip_uc_schema,
    check_trace_location_proto_roundtrip_mlflow_experiment,
    check_trace_location_proto_roundtrip_inference_table,
    check_assessment_to_proto_required_fields,
    check_assessment_to_proto_v4_trace_id_uc_schema,
    check_assessment_to_proto_optional_fields,
    check_assessment_to_proto_metadata_string_conversion,
    check_assessment_to_proto_feedback_not_expectation,
    check_get_trace_id_from_assessment_proto_uc_schema,
    check_get_trace_id_from_assessment_proto_no_location,
    check_trace_from_proto_returns_trace,
    # F10 - E14: spy on Span.from_otel_proto
    check_trace_from_proto_calls_span_from_otel_proto,
    check_trace_info_to_v4_proto_uc_schema_parses_trace_id,
    check_trace_info_to_v4_proto_timestamp_conversion,
    check_trace_info_to_v4_proto_includes_assessments,
    # F10 - E2: spy on trace_location_to_proto from trace_info_to_v4_proto
    check_trace_info_to_v4_proto_calls_trace_location_to_proto,
    check_trace_to_proto,
    check_span_inputs_property_exists_and_delegates,
    check_span_outputs_property_exists_and_delegates,
    check_trace_info_to_proto_dispatches_to_v4,
    # F11: non-v4 path
    check_trace_info_to_proto_non_v4_does_not_dispatch,
    check_trace_location_from_proto_classmethod,
]

if __name__ == "__main__":
    passed = 0
    failed = 0
    for fn in _ALL_CHECKS:
        try:
            fn()
            print(f"PASS: {fn.__name__}")
            passed += 1
        except Exception as e:
            print(f"FAIL: {fn.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    if failed > 0:
        sys.exit(1)
