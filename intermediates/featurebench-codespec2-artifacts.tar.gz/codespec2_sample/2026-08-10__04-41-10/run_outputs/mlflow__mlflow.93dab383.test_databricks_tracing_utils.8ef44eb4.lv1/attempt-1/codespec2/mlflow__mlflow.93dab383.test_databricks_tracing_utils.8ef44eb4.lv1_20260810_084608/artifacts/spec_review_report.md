# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- **Test Spec skill**: `/installed-agent/codespec2/test_spec_skill.md` — mandates that L2 CALL relationships must be verified via spy-on-caller patterns, not isolated helper tests; requires six architecture views (Structure, Dependency, Call Chain, Dataflow, Interface, State/Lifecycle)
- **Native tests**:
  - `tests/entities/test_span.py::test_create_live_span` — verifies `span.inputs` / `span.outputs` property access on both `LiveSpan` (line 43) and immutable `Span` (line 111), property delegation to `get_attribute`, JSON deserialization, and `None` when unset
  - `tests/entities/test_span.py::test_create_non_live_span` — verifies that immutable `Span` does NOT have `set_inputs`/`set_outputs` (raises AttributeError)
  - `tests/entities/test_span.py::test_span_dict_v4` / `test_load_from_old_span_dict` — verifies roundtrip fidelity of inputs/outputs through serialization (lines 623-624, 713-714)
  - `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — verifies `MlflowException` with `INVALID_PARAMETER_VALUE` error code; verifies `FutureWarning` with exact message match `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`
  - `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` — verifies case-insensitive normalization through `AssessmentSource.__post_init__`
  - `tests/entities/test_trace_location.py::test_trace_location` — verifies `TraceLocation.from_proto` / `to_proto` roundtrip equality; verifies `MlflowException` for mismatched type/location
  - `tests/entities/test_trace_info.py` (line 164-175) — verifies `TraceInfo.to_proto()` v4 path returns protobuf with parsed trace_id, UC schema location, state, previews, tags, and assessments
  - `tests/entities/test_trace.py::test_trace_to_and_from_proto` — verifies `Trace.to_proto()` and `Trace.from_proto()` roundtrip through real traced functions
  - `tests/store/tracking/test_databricks_rest_store.py` (line 1075) — verifies `assessment_to_proto` is called by the store layer and its JSON output is sent over the wire
  - `tests/tracing/test_assessment.py::test_feedback_from_proto_v4` (line 439) — verifies `Feedback.from_proto` calls `get_trace_id_from_assessment_proto` for v4 trace ID reconstruction

## Rubric
- Requirement coverage: 1 — All 14 L1 requirements and 25 L3 contracts are acknowledged in the two spec files, but several have only count/type checks instead of discriminating dataflow assertions
- Caller binding / call chain: 1 — E1 and E6 are verified via `patch(wraps=…)` spy patterns, but E2-E5, E7-E12, E15-E16, E17 are tested only through output inspection of the top-level helper, not by spying on internal call boundaries
- Dataflow / state / lifecycle: 1 — Timestamp conversion and metadata string conversion are checked, but trace_info_to_v4_proto fields (request_preview, response_preview, state enum, tags, metadata) are not systematically verified; metadata conversion only tests strings, not int/bool
- Failure / compatibility boundaries: 1 — ValueError for unsupported trace location type and MlflowException for invalid source type are tested, but the INVALID_PARAMETER_VALUE error code is not asserted; the non-UC-schema path of `get_trace_id_from_assessment_proto` for protos that have trace_location but are not UC schema is untested

## Derived Practical Test Perspectives
- **P1**: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — observed risk: the native test asserts exact `FutureWarning` message match (`"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`) and verifies the exception error code. The generated behavior spec uses a generic `issubclass(x.category, FutureWarning)` check without message match and never asserts `exc.error_code == INVALID_PARAMETER_VALUE`. Generated spec must match: exact deprecation message and error code.
- **P2**: `tests/entities/test_span.py::test_create_non_live_span` — observed risk: the native test proves that immutable `Span` has `inputs`/`outputs` as read-only properties, while `LiveSpan` has them plus `set_inputs`/`set_outputs`. The generated arch_spec tests `Span.inputs` on a Span created from a live OTel span (correct), but does not verify that the immutable Span rejects `set_inputs` (AttributeError). Generated spec must add this negative test.
- **P3**: `tests/entities/test_trace_info.py` (lines 164-175) — observed risk: the native test verifies that `TraceInfo.to_proto()` for v4 traces returns a proto with all fields populated (trace_id parsed, state enum, request/response previews, client_request_id, tags). The generated arch_spec only checks trace_id parsing and assessment count; it never verifies `state`, `request_preview`, `response_preview`, `tags`, or `trace_metadata` fields. Generated spec must verify the full structure.
- **P4**: `tests/store/tracking/test_databricks_rest_store.py` (line 1075) — observed risk: the store layer calls `assessment_to_proto(feedback)` and serializes it via `message_to_json`. The generated spec tests `assessment_to_proto` in isolation but never verifies that the proto is serializable to valid JSON (no non-serializable fields). Generated spec should verify JSON roundtrip or at minimum that all proto fields are valid.
- **P5**: `tests/entities/test_trace_location.py::test_trace_location` — observed risk: the native test verifies that `TraceLocation.from_proto(trace_location.to_proto())` roundtrips to equality. The generated arch_spec tests `trace_location_from_proto` and `trace_location_to_proto` separately but never verifies the roundtrip invariant. Generated spec must add a roundtrip equality check.

## Final Rubric Scores
- Requirement coverage: 1 — C10 checks only trace_id; C11 checks only count; C1 uses magic number for source_type enum; C3 metadata test uses only string values; missing negative case for expectation+feedback both present
- Caller binding / call chain: 1 — E1, E6 are spy-verified; E2-E5, E7-E12, E15-E18 lack spy verification on internal call edges; `trace_info_to_v4_proto` calls `trace_location_to_proto`/`parse_trace_id_v4`/truncation helpers/`assessment_to_proto` but none are spied
- Dataflow / state / lifecycle: 1 — `trace_location_to_proto` roundtrip not tested; `uc_schema_location_from_proto` optional-table absence not tested; `trace_info_to_v4_proto` state/preview/tags fields not verified; metadata conversion only tests string→string
- Failure / compatibility boundaries: 1 — `INVALID_PARAMETER_VALUE` error code not asserted; exact `FutureWarning` message not matched; non-UC-schema `trace_location` path in `get_trace_id_from_assessment_proto` not tested; `Span` immutable-rejects-setter not tested; `assessment_to_proto` with `valid=None` not tested
- P1: 1 — Exception type and message are checked but error code is not asserted; warning category is checked but exact message is not matched
- P2: 0 — No test verifies that immutable Span raises AttributeError on `set_inputs`/`set_outputs`
- P3: 1 — Trace ID parsing is checked but state, previews, tags, and metadata fields are not verified in the v4 proto output
- P4: 1 — Proto is created but never serialized to JSON to verify field validity
- P5: 0 — No roundtrip check for `trace_location_from_proto(trace_location_to_proto(loc)) == loc`

## Findings

### F1: missing_requirement — Span.inputs/outputs C19/C20 negative-mutability test
- Requirement/IR: R12/R13, C19/C20
- Evidence: Native test `tests/entities/test_span.py::test_create_non_live_span` line 117: `with pytest.raises(AttributeError, match="set_inputs"): span.set_inputs(...)`
- Gap: The generated arch_spec tests only positive property access. It never verifies that the immutable `Span` class rejects mutation via `set_inputs`/`set_outputs` (AttributeError), while `LiveSpan` accepts them. This is a critical interface contract: `Span` must be read-only.
- Repair: Add to behavior_spec.py a `check_span_rejects_set_inputs_outputs()` that creates an immutable `Span` (via `OTelReadableSpan`), attempts `span.set_inputs(...)`, and asserts `AttributeError`. Also confirm `LiveSpan` accepts them.

### F2: missing_requirement — trace_location roundtrip invariant (C13/C8)
- Requirement/IR: R7/R8, C13
- Evidence: Native test `tests/entities/test_trace_location.py::test_trace_location` line 29: `from_proto = TraceLocation.from_proto(trace_location.to_proto()); assert from_proto == trace_location`
- Gap: The arch_spec tests `trace_location_from_proto` and `trace_location_to_proto` separately but never verifies the roundtrip identity `trace_location_from_proto(trace_location_to_proto(loc)) == loc` for any of the three location types.
- Repair: Add `check_trace_location_proto_roundtrip_uc_schema()`, `check_trace_location_proto_roundtrip_mlflow_experiment()`, `check_trace_location_proto_roundtrip_inference_table()` to arch_spec.py.

### F3: weak_constraint — C23 error code not asserted
- Requirement/IR: R14, C23
- Evidence: Native test `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` line 49: `pytest.raises(MlflowException, match="Invalid assessment source type")` — the native store layer accesses `exc.error_code`; the IR explicitly states error code must be `INVALID_PARAMETER_VALUE`.
- Gap: The behavior spec `check_parse_raises_on_invalid_type` and `check_init_raises_on_invalid_type` catch `MlflowException` and check the message, but never assert `exc.value.error_code == INVALID_PARAMETER_VALUE`.
- Repair: Add `assert exc.value.error_code == INVALID_PARAMETER_VALUE` (import from `mlflow.protos.databricks_pb2`) in both failure checks. Match the exact error code used by the native tests.

### F4: weak_constraint — P1 exact FutureWarning message match
- Requirement/IR: R14, C21, C23
- Evidence: Native test `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` line 73: `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
- Gap: The behavior spec `check_parse_deprecates_ai_judge` and `check_standardize_deprecates_ai_judge` use a generic `any(issubclass(x.category, FutureWarning) for x in w)` without matching the exact deprecation message. A wrong implementation that emits a FutureWarning with a different message (or no message) would pass.
- Repair: Use `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated")` with the exact message substring from the native test.

### F5: weak_constraint — C10 trace_info_to_v4_proto only checks trace_id, not full structure
- Requirement/IR: R6, C10, C11, C12
- Evidence: Native test `tests/entities/test_trace_info.py` lines 164-175 verifies `state`, `request_preview`, `response_preview`, `client_request_id`, `tags`, and `assessments` in the v4 proto output.
- Gap: The arch_spec `check_trace_info_to_v4_proto_uc_schema_parses_trace_id` only asserts `proto.trace_id == "raw_123"`. It does not check that `proto.state`, `proto.request_preview`, `proto.response_preview`, `proto.client_request_id`, `proto.tags`, or `proto.trace_metadata` are populated correctly. `check_trace_info_to_v4_proto_includes_assessments` checks assessment count but not full content.
- Repair: Enrich `check_trace_info_to_v4_proto_uc_schema_parses_trace_id` to verify all fields: `state` enum mapping, `request_preview`, `response_preview`, `client_request_id`, `tags` dict equality, and `trace_metadata` dict equality. Extend `check_trace_info_to_v4_proto_includes_assessments` to verify the assessment proto's `assessment_name`, `source`, and `trace_id` match.

### F6: weak_constraint — C1 assessment_to_proto uses magic number for source_type
- Requirement/IR: R1, C1
- Evidence: Arch spec line: `assert proto.source.source_type == 1  # ProtoAssessmentSource.SourceType.Value("HUMAN")`
- Gap: The assertion uses a magic number `1` which would silently pass if the enum mapping changes. The IR expects `AssessmentSource.to_proto()` to be called, which uses `ProtoAssessmentSource.SourceType.Value(self.source_type)`.
- Repair: Use the proper protobuf enum: `from mlflow.protos.assessments_pb2 import AssessmentSource as ProtoAssessmentSource; assert proto.source.source_type == ProtoAssessmentSource.SourceType.Value("HUMAN")`.

### F7: weak_constraint — C3 metadata conversion only tests string values
- Requirement/IR: R1, C3
- Evidence: Task says "Metadata values are converted to strings regardless of their original type"
- Gap: `check_assessment_to_proto_metadata_string_conversion` uses `{"key1": "value1"}` which is already a string. It does not test conversion of int, bool, float, or None metadata values.
- Repair: Add an assessment with `metadata={"int_key": 42, "bool_key": True, "float_key": 3.14}` and assert the proto metadata values are strings `"42"`, `"True"`, `"3.14"`.

### F8: weak_constraint — C5/C6 get_trace_id_from_assessment_proto missing non-UC location edge case
- Requirement/IR: R2, C6
- Evidence: The IR says "For other location types, returns the trace ID directly"
- Gap: `check_get_trace_id_from_assessment_proto_no_location` tests a proto without `trace_location` at all. But what about a proto that HAS a `trace_location` with `mlflow_experiment` or `inference_table` (not UC schema)? The spec doesn't test that the function returns `proto.trace_id` for non-UC location types.
- Repair: Add `check_get_trace_id_from_assessment_proto_mlflow_experiment_location()` that creates a proto with `trace_location.mlflow_experiment` set and verifies the raw trace_id is returned.

### F9: weak_constraint — C17 uc_schema_location_from_proto absence of optional fields
- Requirement/IR: R10, C17
- Evidence: The IR says "The function uses HasField() to check for optional fields before setting them"
- Gap: `check_uc_schema_location_from_proto_basic` creates a proto WITHOUT optional table names but only checks catalog_name and schema_name. It does not verify that `_otel_spans_table_name` and `_otel_logs_table_name` are NOT set (i.e., accessing them raises AttributeError or the attribute is absent).
- Repair: After creating a `UCSchemaLocation` from a proto without optional fields, assert that accessing `_otel_spans_table_name` raises AttributeError (or use `hasattr` to verify absence).

### F10: missing_requirement — E2-E5, E7-E12, E15-E18 caller-binding not spy-verified
- Requirement/IR: E2-E5, E7-E12, E15-E18
- Evidence: Test Spec Skill L5: "For E1 and E6, use `patch('actual.import.path.func', wraps=real_func)` to spy on the call while letting it execute." The arch_spec applies this pattern for E1 and E6 but not for the remaining cross-module edges.
- Gap: `trace_info_to_v4_proto` is tested by calling it and checking the output proto fields, but no spy verifies that `trace_location_to_proto`, `parse_trace_id_v4`, `_truncate_request_metadata`, `_truncate_tags`, or `assessment_to_proto` are actually called with the expected arguments. A reimplementation that inlines all logic would pass. Similarly, `trace_from_proto` never spies on `Span.from_otel_proto` to verify the `location_id` passthrough.
- Repair: Add spy-verified checks for at minimum E2 (`trace_location_to_proto` called from `trace_info_to_v4_proto`), E5 (`assessment_to_proto` called per assessment), and E14 (`Span.from_otel_proto` called with `location_id` from `trace_from_proto`).

### F11: weak_constraint — E1 only checks v4 dispatch, not non-v4 path
- Requirement/IR: R6, E1
- Evidence: `TraceInfo.to_proto()` branches on `self._is_v4()` (line 100 of trace_info.py). The v4 path calls `trace_info_to_v4_proto`; the non-v4 path does inline conversion.
- Gap: `check_trace_info_to_proto_dispatches_to_v4` only verifies that a UC-schema TraceInfo calls `trace_info_to_v4_proto`. It never verifies that a non-UC-schema TraceInfo does NOT call it (i.e., the spy should have 0 calls for non-v4 traces).
- Repair: Add `check_trace_info_to_proto_non_v4_does_not_dispatch()` that creates a non-UC-schema TraceInfo, spies on `trace_info_to_v4_proto`, calls `to_proto()`, and asserts the spy was never called.

## Rework Instructions
1. **behavior_spec.py**: Add `check_span_rejects_set_inputs_outputs()` — create immutable Span, attempt `set_inputs`, assert AttributeError (F1).
2. **arch_spec.py**: Add three roundtrip checks `check_trace_location_proto_roundtrip_*` for each location type (F2).
3. **behavior_spec.py**: In `check_parse_raises_on_invalid_type` and `check_init_raises_on_invalid_type`, add `assert exc.value.error_code == INVALID_PARAMETER_VALUE` (F3).
4. **behavior_spec.py** and **arch_spec.py**: Replace generic FutureWarning checks with `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated")` matching the native test message (F4).
5. **arch_spec.py**: Enrich `check_trace_info_to_v4_proto_uc_schema_parses_trace_id` to verify `state`, `request_preview`, `response_preview`, `client_request_id`, `tags`, and `trace_metadata` (F5).
6. **arch_spec.py**: In `check_assessment_to_proto_required_fields`, replace magic number `1` with `ProtoAssessmentSource.SourceType.Value("HUMAN")` (F6).
7. **behavior_spec.py**: Add `check_assessment_to_proto_metadata_non_string_conversion()` with int/bool/float metadata values (F7).
8. **behavior_spec.py**: Add `check_get_trace_id_from_assessment_proto_mlflow_experiment_location()` for non-UC trace_location edge case (F8).
9. **arch_spec.py**: In `check_uc_schema_location_from_proto_basic`, assert `_otel_spans_table_name` absence via `hasattr` or AttributeError (F9).
10. **arch_spec.py**: Add spy-verified checks for at minimum E2 (`trace_location_to_proto` from `trace_info_to_v4_proto`), E5 (`assessment_to_proto` from `trace_info_to_v4_proto`), and E14 (`Span.from_otel_proto` with `location_id` from `trace_from_proto`) (F10).
11. **arch_spec.py**: Add `check_trace_info_to_proto_non_v4_does_not_dispatch()` to verify non-v4 path doesn't call `trace_info_to_v4_proto` (F11).
