"""Behavior spec: L3 State, Behavior, Failure, SideEffect, defaults, boundaries, compatibility.

Covers contracts: C15, C22, C23, C25 (plus C5/C6 behavior aspects, C23 failure aspect)
Each check_* function is a no-arg top-level. Calls all checks and prints PASS: on success.
"""

import sys
import warnings

import pytest


# ── C22: AssessmentSourceType.__init__ delegates to _parse and stores result ──

# Contracts: C22
def check_assessment_source_type_init_delegates_to_parse() -> None:
    """Verify __init__ calls _parse and stores result; str() returns parsed value."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    instance = AssessmentSourceType("human")
    assert str(instance) == "HUMAN"

    instance2 = AssessmentSourceType("LLM_JUDGE")
    assert str(instance2) == "LLM_JUDGE"

    instance3 = AssessmentSourceType("CODE")
    assert str(instance3) == "CODE"

    instance4 = AssessmentSourceType("source_type_unspecified")
    assert str(instance4) == "SOURCE_TYPE_UNSPECIFIED"


# Contracts: C22
def check_assessment_source_type_str_roundtrips() -> None:
    """Verify AssessmentSourceType(str(instance)) produces same result."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    for val in ["HUMAN", "LLM_JUDGE", "CODE", "SOURCE_TYPE_UNSPECIFIED"]:
        instance = AssessmentSourceType(val)
        assert str(instance) == val
        # Round-trip
        instance2 = AssessmentSourceType(str(instance))
        assert str(instance2) == val


# ── C23: AssessmentSourceType._parse (normalization, deprecation, validation) ──

# Contracts: C23
def check_parse_normalizes_case() -> None:
    """Verify _parse converts input to uppercase."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._parse("human") == "HUMAN"
    assert AssessmentSourceType._parse("Human") == "HUMAN"
    assert AssessmentSourceType._parse("HUMAN") == "HUMAN"
    assert AssessmentSourceType._parse("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("code") == "CODE"
    assert AssessmentSourceType._parse("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"


# Contracts: C23
# Perspective: tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning
# Reference: exact FutureWarning message "AI_JUDGE is deprecated. Use LLM_JUDGE instead."
def check_parse_deprecates_ai_judge() -> None:
    """Verify _parse maps AI_JUDGE -> LLM_JUDGE with exact FutureWarning message."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated"):
        result = AssessmentSourceType._parse("AI_JUDGE")
        assert result == "LLM_JUDGE", f"Expected LLM_JUDGE, got {result}"

    # Also lowercase
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated"):
        result = AssessmentSourceType._parse("ai_judge")
        assert result == "LLM_JUDGE"


# Contracts: C23
# Perspective: tests/entities/test_assessment_source.py::test_assessment_source_type_validation
# Reference: pytest.raises(MlflowException, match="Invalid assessment source type")
# F3: also assert error_code == INVALID_PARAMETER_VALUE
def check_parse_raises_on_invalid_type() -> None:
    """Verify _parse raises MlflowException with INVALID_PARAMETER_VALUE error code."""
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException, match="Invalid assessment source type") as exc_info:
        AssessmentSourceType._parse("ROBOT")
    assert exc_info.value.error_code == INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException, match="Invalid assessment source type") as exc_info:
        AssessmentSourceType._parse("INVALID")
    assert exc_info.value.error_code == INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException, match="Invalid assessment source type") as exc_info:
        AssessmentSourceType._parse("")
    assert exc_info.value.error_code == INVALID_PARAMETER_VALUE


# Contracts: C23
# F3: also assert error_code
def check_init_raises_on_invalid_type() -> None:
    """Verify AssessmentSourceType('INVALID') raises MlflowException with error_code."""
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException, match="Invalid assessment source type") as exc_info:
        AssessmentSourceType("ROBOT")
    assert exc_info.value.error_code == INVALID_PARAMETER_VALUE


# ── C25: AssessmentSource.__post_init__ calls _standardize ───────────────────

# Contracts: C25
def check_assessment_source_post_init_standardizes() -> None:
    """Verify AssessmentSource.__post_init__ standardizes source_type."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="human", source_id="user_1")
    assert source.source_type == "HUMAN"

    source2 = AssessmentSource(source_type="llm_judge", source_id="gpt-4")
    assert source2.source_type == "LLM_JUDGE"

    source3 = AssessmentSource(source_type="HUMAN", source_id="user_2")
    assert source3.source_type == "HUMAN"


# Contracts: C25
def check_assessment_source_default_source_id() -> None:
    """Verify AssessmentSource defaults source_id to 'default'."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="HUMAN")
    assert source.source_id == "default"


# Contracts: C25
# Perspective: tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning
# Reference: exact message match
def check_assessment_source_ai_judge_warning() -> None:
    """Verify AssessmentSource with AI_JUDGE triggers exact FutureWarning message and converts."""
    from mlflow.entities.assessment_source import AssessmentSource

    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated"):
        source = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
        assert source.source_type == "LLM_JUDGE"


# ── C15: trace_location_to_proto raises ValueError for unsupported type ─────

# Contracts: C15
def check_trace_location_to_proto_raises_value_error() -> None:
    """Verify trace_location_to_proto raises ValueError for unsupported type."""
    from mlflow.entities.trace_location import TraceLocation, TraceLocationType
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto

    # Create a TraceLocation with only UNSPECIFIED type (no supported location)
    bad_loc = TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    with pytest.raises(ValueError, match="Unsupported trace location type"):
        trace_location_to_proto(bad_loc)


# ── C5, C6: get_trace_id_from_assessment_proto behavior aspects ─────────────

# Contracts: C5
def check_get_trace_id_from_assessment_proto_v4_construction() -> None:
    """Verify v4 trace ID construction from UC Schema location."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    proto = pb.Assessment()
    proto.trace_id = "tid_abc"
    proto.trace_location.CopyFrom(
        pb.TraceLocation(
            type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
            uc_schema=pb.UCSchemaLocation(catalog_name="my_cat", schema_name="my_sch"),
        )
    )
    result = get_trace_id_from_assessment_proto(proto)
    assert result == "trace:/my_cat.my_sch/tid_abc"


# Contracts: C6
def check_get_trace_id_from_assessment_proto_raw_fallback() -> None:
    """Verify raw trace_id returned when no location."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    proto = pb.Assessment()
    proto.trace_id = "raw_trace_id"
    result = get_trace_id_from_assessment_proto(proto)
    assert result == "raw_trace_id"


# Contracts: C5
def check_get_trace_id_from_assessment_proto_assessments_pb2() -> None:
    """Verify function works with assessments_pb2.Assessment type."""
    from mlflow.protos import assessments_pb2
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    proto = assessments_pb2.Assessment()
    proto.trace_id = "assessments_pb2_tid"
    result = get_trace_id_from_assessment_proto(proto)
    assert result == "assessments_pb2_tid"


# ── F8: get_trace_id_from_assessment_proto with non-UC trace_location ───────
# Perspective: tests/tracing/test_assessment.py::test_feedback_from_proto_v4
# Reference: proto that HAS trace_location with mlflow_experiment (not UC schema) should return raw trace_id

def check_get_trace_id_from_assessment_proto_mlflow_experiment_location() -> None:
    """Verify raw trace_id returned when trace_location exists but is not UC schema."""
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    proto = pb.Assessment()
    proto.trace_id = "exp_trace_789"
    proto.trace_location.CopyFrom(
        pb.TraceLocation(
            type=pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=pb.TraceLocation.MlflowExperimentLocation(experiment_id="exp_42"),
        )
    )
    result = get_trace_id_from_assessment_proto(proto)
    assert result == "exp_trace_789"


# ── C1: assessment_to_proto behavior boundaries ─────────────────────────────

# Contracts: C1
def check_assessment_to_proto_non_v4_trace_id() -> None:
    """Verify assessment_to_proto handles non-v4 (non-UC) trace IDs."""
    import time
    from mlflow.entities.assessment import Assessment, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assessment = Assessment(
        name="non_v4",
        trace_id="simple_trace_id",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(1.0),
    )
    proto = assessment_to_proto(assessment)
    assert proto.trace_id == "simple_trace_id"
    # No trace_location for non-v4
    assert not proto.HasField("trace_location")


# Contracts: C1
def check_assessment_to_proto_none_span_id() -> None:
    """Verify span_id None results in proto without span_id field."""
    import time
    from mlflow.entities.assessment import Assessment, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assessment = Assessment(
        name="no_span",
        trace_id="trace:/c.s/tid",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(0.5),
        span_id=None,
    )
    proto = assessment_to_proto(assessment)
    assert not proto.HasField("span_id") or proto.span_id == ""


# ── C12: trace_info_to_v4_proto behavior aspects ────────────────────────────

# Contracts: C12
def check_trace_info_to_v4_proto_non_uc_schema() -> None:
    """Verify trace_info_to_v4_proto preserves trace_id for non-UC-schema locations."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    exp_loc = MlflowExperimentLocation(experiment_id="exp_1")
    trace_loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT, mlflow_experiment=exp_loc
    )
    trace_info = TraceInfo(
        trace_id="raw_trace_id_no_parse",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
    )
    proto = trace_info_to_v4_proto(trace_info)
    assert proto.trace_id == "raw_trace_id_no_parse"


# Contracts: C12
def check_trace_info_to_v4_proto_none_duration() -> None:
    """Verify execution_duration not set when None."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/raw_000",
        trace_location=trace_loc,
        request_time=1000,
        state=TraceState.OK,
        execution_duration=None,
    )
    proto = trace_info_to_v4_proto(trace_info)
    assert not proto.HasField("execution_duration")


# ── C19, C20: Span.inputs/outputs behavior boundaries ────────────────────────

# Contracts: C19
def check_span_inputs_with_complex_value() -> None:
    """Verify Span.inputs handles complex nested structures."""
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    import opentelemetry.sdk.trace as otel_sdk

    tracer = otel_sdk.TracerProvider().get_tracer("test")
    with tracer.start_as_current_span("complex_span") as otel_span:
        otel_span.set_attribute(
            SpanAttributeKey.INPUTS, '{"nested": {"inner": [1, 2, 3]}, "flag": true}'
        )
        span = Span(otel_span)
        assert span.inputs == {"nested": {"inner": [1, 2, 3]}, "flag": True}


# Contracts: C20
def check_span_outputs_with_list_value() -> None:
    """Verify Span.outputs handles list values."""
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    import opentelemetry.sdk.trace as otel_sdk

    tracer = otel_sdk.TracerProvider().get_tracer("test")
    with tracer.start_as_current_span("list_span") as otel_span:
        otel_span.set_attribute(
            SpanAttributeKey.OUTPUTS, '[1, 2, 3]'
        )
        span = Span(otel_span)
        assert span.outputs == [1, 2, 3]


# ── F1: Span rejects set_inputs/set_outputs (AttributeError) ────────────────
# Perspective: tests/entities/test_span.py::test_create_non_live_span
# Reference: with pytest.raises(AttributeError, match="set_inputs"): span.set_inputs({"input": 1})

def check_span_rejects_set_inputs_outputs() -> None:
    """Verify immutable Span raises AttributeError on set_inputs/set_outputs."""
    from mlflow.entities.span import Span
    import opentelemetry.sdk.trace as otel_sdk

    tracer = otel_sdk.TracerProvider().get_tracer("test")
    with tracer.start_as_current_span("span_for_reject") as otel_span:
        span = Span(otel_span)
        # Immutable Span must not have set_inputs
        with pytest.raises(AttributeError, match="set_inputs"):
            span.set_inputs({"input": 1})
        # Immutable Span must not have set_outputs
        with pytest.raises(AttributeError, match="set_outputs"):
            span.set_outputs({"output": 2})


# ── C21/C23: _standardize raises MlflowException on invalid ─────────────────

# Contracts: C21, C23
def check_standardize_raises_on_invalid() -> None:
    """Verify _standardize raises MlflowException for invalid source_type."""
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    with pytest.raises(MlflowException, match="Invalid assessment source type"):
        AssessmentSourceType._standardize("ROBOT")


# Contracts: C21
def check_standardize_handles_source_type_unspecified() -> None:
    """Verify _standardize handles SOURCE_TYPE_UNSPECIFIED."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    result = AssessmentSourceType._standardize("source_type_unspecified")
    assert result == "SOURCE_TYPE_UNSPECIFIED"


# Contracts: C25
def check_assessment_source_with_llm_judge_constant() -> None:
    """Verify AssessmentSource works with class constant as source_type."""
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    source = AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="gpt-4")
    assert source.source_type == "LLM_JUDGE"


# ── C3/C4: assessment_to_proto misc fields ──────────────────────────────────

# Contracts: C3
def check_assessment_to_proto_overrides_field() -> None:
    """Verify assessment_to_proto handles overrides field."""
    import time
    from mlflow.entities.assessment import Assessment, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assessment = Assessment(
        name="override_test",
        trace_id="trace:/c.s/tid",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(0.5),
        overrides={"key": "value"},
    )
    proto = assessment_to_proto(assessment)
    assert proto.overrides == {"key": "value"}


# Contracts: C3
def check_assessment_to_proto_valid_field() -> None:
    """Verify assessment_to_proto handles valid field."""
    import time
    from mlflow.entities.assessment import Assessment, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assessment = Assessment(
        name="validated",
        trace_id="trace:/c.s/tid",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(0.5),
        valid=True,
    )
    proto = assessment_to_proto(assessment)
    assert proto.valid is True

    assessment2 = Assessment(
        name="invalid",
        trace_id="trace:/c.s/tid2",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        create_time_ms=int(time.time() * 1000),
        last_update_time_ms=int(time.time() * 1000),
        feedback=FeedbackValue(0.5),
        valid=False,
    )
    proto2 = assessment_to_proto(assessment2)
    assert proto2.valid is False


# ── C14: trace_location_from_proto with mlflow_experiment ───────────────────

# Contracts: C13
def check_trace_location_from_proto_mlflow_experiment() -> None:
    """Verify trace_location_from_proto handles mlflow_experiment identifier."""
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=pb.TraceLocation.MlflowExperimentLocation(experiment_id="exp_42"),
    )
    loc = trace_location_from_proto(proto)
    assert loc.type == TraceLocationType.MLFLOW_EXPERIMENT
    assert loc.mlflow_experiment is not None
    assert loc.mlflow_experiment.experiment_id == "exp_42"


# Contracts: C13
def check_trace_location_from_proto_inference_table() -> None:
    """Verify trace_location_from_proto handles inference_table identifier."""
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.INFERENCE_TABLE,
        inference_table=pb.TraceLocation.InferenceTableLocation(
            full_table_name="catalog.schema.inf_table"
        ),
    )
    loc = trace_location_from_proto(proto)
    assert loc.type == TraceLocationType.INFERENCE_TABLE
    assert loc.inference_table is not None
    assert loc.inference_table.full_table_name == "catalog.schema.inf_table"


# ── C16: trace_to_proto with spans ──────────────────────────────────────────

# Contracts: C16
def check_trace_to_proto_with_spans() -> None:
    """Verify trace_to_proto includes span data when spans exist."""
    from mlflow.entities import Span, Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    import opentelemetry.sdk.trace as otel_sdk

    tracer = otel_sdk.TracerProvider().get_tracer("test")
    with tracer.start_as_current_span("root_span") as otel_span:
        span = Span(otel_span)
        uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
        trace_loc = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)
        trace_info = TraceInfo(
            trace_id="trace:/cat.sch/tid",
            trace_location=trace_loc,
            request_time=1000,
            state=TraceState.OK,
        )
        trace_data = TraceData(spans=[span])
        trace = Trace(info=trace_info, data=trace_data)

        proto = trace_to_proto(trace)
        assert proto.HasField("trace_info")
        assert len(proto.spans) == 1
        assert proto.spans[0].name == "root_span"


# ── runner ───────────────────────────────────────────────────────────────────

_ALL_CHECKS = [
    check_assessment_source_type_init_delegates_to_parse,
    check_assessment_source_type_str_roundtrips,
    check_parse_normalizes_case,
    check_parse_deprecates_ai_judge,
    check_parse_raises_on_invalid_type,
    check_init_raises_on_invalid_type,
    check_assessment_source_post_init_standardizes,
    check_assessment_source_default_source_id,
    check_assessment_source_ai_judge_warning,
    check_trace_location_to_proto_raises_value_error,
    check_get_trace_id_from_assessment_proto_v4_construction,
    check_get_trace_id_from_assessment_proto_raw_fallback,
    check_get_trace_id_from_assessment_proto_assessments_pb2,
    # F8: mlflow_experiment location edge case
    check_get_trace_id_from_assessment_proto_mlflow_experiment_location,
    check_assessment_to_proto_non_v4_trace_id,
    check_assessment_to_proto_none_span_id,
    check_trace_info_to_v4_proto_non_uc_schema,
    check_trace_info_to_v4_proto_none_duration,
    check_span_inputs_with_complex_value,
    check_span_outputs_with_list_value,
    # F1: immutable Span rejects set_inputs/set_outputs
    check_span_rejects_set_inputs_outputs,
    check_standardize_raises_on_invalid,
    check_standardize_handles_source_type_unspecified,
    check_assessment_source_with_llm_judge_constant,
    check_assessment_to_proto_overrides_field,
    check_assessment_to_proto_valid_field,
    check_trace_location_from_proto_mlflow_experiment,
    check_trace_location_from_proto_inference_table,
    check_trace_to_proto_with_spans,
]

if __name__ == "__main__":
    passed = 0
    failed = 0
    for fn in _ALL_CHECKS:
        try:
            fn()
            print(f"PASS: {fn.__name__}")
            passed += 1
        except Exception as e:
            print(f"FAIL: {fn.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    if failed > 0:
        sys.exit(1)
