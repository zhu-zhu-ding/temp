# Semantic IR

## L1. Requirement Obligations

### R1: Convert Assessment entity to protobuf representation
- **Type:** Dataflow
- **Statement:** An Assessment entity must be convertible to a `pb.Assessment` protobuf message with all fields mapped correctly, including name, trace_id (with v4 parsing and trace_location construction for UC Schema), source, timestamps (ms→protobuf Timestamp), and optional fields (span_id, rationale, assessment_id, expectation/feedback, metadata, overrides, valid).
- **Task Evidence:** "Convert an Assessment entity to its corresponding protobuf representation." / "The function automatically parses the trace_id to extract location information and constructs the appropriate trace_location proto field for UC Schema locations"
- **Acceptance:** Calling `assessment_to_proto(assessment)` returns a valid `pb.Assessment` message with all fields correctly populated. For UC Schema trace IDs (v4 format `trace:/<location>/<id>`), the proto's `trace_location` contains a UC_SCHEMA location with catalog/schema parsed from the trace_id. Metadata values are converted to strings.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`; `/testbed/mlflow/entities/assessment.py:Assessment.to_proto` (delegate pattern); `/testbed/tests/store/tracking/test_databricks_rest_store.py:1075` (caller).
- **Uncertainty:** None.

### R2: Extract trace ID from assessment protobuf (both pb and assessments_pb2 variants)
- **Type:** Behavior
- **Statement:** Given a `pb.Assessment` or `assessments_pb2.Assessment` protobuf, extract the effective trace ID. For UC Schema locations (proto has `trace_location.uc_schema`), construct a v4 trace ID via `construct_trace_id_v4(catalog.schema, trace_id)`. Otherwise, return `proto.trace_id` directly.
- **Task Evidence:** "Extract the trace ID from an assessment protocol buffer object." / "For UC schema locations, returns a v4 trace ID constructed from the catalog name, schema name, and trace ID."
- **Acceptance:** `get_trace_id_from_assessment_proto(proto)` returns the correct trace_id string. For protos with UC Schema location, returns `trace:/<catalog>.<schema>/<trace_id>`. For other locations, returns `proto.trace_id`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`; `/testbed/mlflow/entities/assessment.py:288` (Expectation.from_proto) and `:426` (Feedback.from_proto) — both import and call this function; `/testbed/mlflow/tracing/utils/__init__.py:construct_trace_id_v4`.
- **Uncertainty:** None.

### R3: Convert InferenceTableLocation entity to protobuf
- **Type:** Dataflow
- **Statement:** An `InferenceTableLocation` entity with a `full_table_name` attribute must be converted to a `pb.InferenceTableLocation` protobuf message with the `full_table_name` field populated.
- **Task Evidence:** "Convert an InferenceTableLocation object to its corresponding protobuf representation."
- **Acceptance:** `inference_table_location_to_proto(loc)` returns `pb.InferenceTableLocation(full_table_name=loc.full_table_name)`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:inference_table_location_to_proto`; `/testbed/mlflow/entities/trace_location.py:InferenceTableLocation` (has `full_table_name` field).
- **Uncertainty:** None.

### R4: Convert MlflowExperimentLocation entity to protobuf
- **Type:** Dataflow
- **Statement:** An `MlflowExperimentLocation` entity with an `experiment_id` attribute must be converted to a `pb.MlflowExperimentLocation` protobuf message with the `experiment_id` field populated.
- **Task Evidence:** "Convert an MlflowExperimentLocation object to its corresponding protobuf representation."
- **Acceptance:** `mlflow_experiment_location_to_proto(loc)` returns `pb.MlflowExperimentLocation(experiment_id=loc.experiment_id)`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:mlflow_experiment_location_to_proto`; `/testbed/mlflow/entities/trace_location.py:MlflowExperimentLocation` (has `experiment_id` field).
- **Uncertainty:** None.

### R5: Deserialize protobuf Trace to MLflow Trace entity
- **Type:** Dataflow
- **Statement:** A `pb.Trace` protobuf message must be deserialized into an MLflow `Trace` entity, converting `trace_info` via `TraceInfo.from_proto()` and each span via `Span.from_otel_proto(span, location_id)`.
- **Task Evidence:** "Convert a protobuf Trace message to an MLflow Trace entity."
- **Acceptance:** `trace_from_proto(proto, location_id)` returns a `Trace` object with `info` (TraceInfo) and `data` (TraceData containing Span list).
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`; `/testbed/libs/tracing/mlflow/store/tracking/databricks_rest_store.py` (imports `trace_from_proto`); `/testbed/mlflow/entities/trace.py:Trace.from_proto` (classmethod); `/testbed/mlflow/entities/span.py:366` (Span.from_otel_proto).
- **Uncertainty:** The `location_id` parameter is passed to `Span.from_otel_proto` for v4 trace ID generation. The exact semantics match the existing implementation in libs/tracing.

### R6: Convert TraceInfo to v4 protobuf representation
- **Type:** Dataflow
- **Statement:** A `TraceInfo` entity must be converted to a `pb.TraceInfo` protobuf message for the v4 tracing protocol. For UC Schema locations, the trace_id must be parsed via `parse_trace_id_v4()` to extract the raw trace ID. All timestamps are converted from milliseconds to protobuf Timestamp/Duration format. Trace metadata and tags must be truncated to fit protobuf size limits. Assessments must be converted using `assessment_to_proto()`.
- **Task Evidence:** "Convert a TraceInfo object to its v4 protocol buffer representation." / "For UC schema trace locations, the trace ID is parsed using parse_trace_id_v4()"
- **Acceptance:** `trace_info_to_v4_proto(trace_info)` returns a `pb.TraceInfo` with all fields correctly populated, truncated metadata/tags, and converted assessments.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`; `/testbed/mlflow/entities/trace_info.py:103` (calls `trace_info_to_v4_proto(self)` in `to_proto()`); `/testbed/mlflow/entities/trace_info_v2.py:_truncate_request_metadata`, `_truncate_tags`; `/testbed/mlflow/tracing/utils/__init__.py:parse_trace_id_v4`.
- **Uncertainty:** None.

### R7: Deserialize protobuf TraceLocation to TraceLocation entity
- **Type:** Dataflow
- **Statement:** A `pb.TraceLocation` protobuf must be deserialized into a `TraceLocation` entity by determining which oneof field is set (uc_schema, mlflow_experiment, or inference_table) and delegating to the appropriate from_proto factory. Falls back to `TRACE_LOCATION_TYPE_UNSPECIFIED` when no identifier is found.
- **Task Evidence:** "Convert a protobuf TraceLocation message to a TraceLocation entity object." / "Uses the WhichOneof method to determine which identifier field is set"
- **Acceptance:** `trace_location_from_proto(proto)` returns a `TraceLocation` entity with correct type and location details. For UC_SCHEMA, returns `TraceLocation(type=UC_SCHEMA, uc_schema=UCSchemaLocation(...))`. For MLFLOW_EXPERIMENT, delegates to `MlflowExperimentLocation.from_proto()`. For INFERENCE_TABLE, delegates to `InferenceTableLocation.from_proto()`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`; `/testbed/mlflow/entities/trace_location.py:246` (calls `trace_location_from_proto(proto)` in `TraceLocation.from_proto()`); `/testbed/mlflow/protos/databricks_tracing_pb2.pyi` (shows TraceLocation has oneof identifier with uc_schema, mlflow_experiment, inference_table).
- **Uncertainty:** None.

### R8: Convert TraceLocation entity to protobuf for all three types
- **Type:** Dataflow
- **Statement:** A `TraceLocation` entity must be converted to `pb.TraceLocation` based on its type: UC_SCHEMA delegates to `uc_schema_location_to_proto`, MLFLOW_EXPERIMENT to `mlflow_experiment_location_to_proto`, INFERENCE_TABLE to `inference_table_location_to_proto`. Raises `ValueError` for unsupported types.
- **Task Evidence:** "Convert a TraceLocation object to its corresponding protobuf representation." / "Raises: ValueError: If the trace_location.type is not one of the supported types"
- **Acceptance:** `trace_location_to_proto(trace_location)` returns correct `pb.TraceLocation` for each type. Unsupported types raise ValueError.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`; `/testbed/libs/tracing/mlflow/store/tracking/databricks_rest_store.py` (imports and uses `trace_location_to_proto`).
- **Uncertainty:** None.

### R9: Serialize Trace entity to protobuf
- **Type:** Dataflow
- **Statement:** A `Trace` entity must be serialized to `pb.Trace` by converting `trace.info` via its `to_proto()` method and each span via `span.to_otel_proto()`.
- **Task Evidence:** "Convert a Trace object to its corresponding protobuf representation."
- **Acceptance:** `trace_to_proto(trace)` returns `pb.Trace(trace_info=..., spans=[...])`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_to_proto`; `/testbed/tests/store/tracking/test_databricks_rest_store.py:212,451` (caller uses `trace_to_proto(trace)`); `/testbed/mlflow/entities/trace.py:to_proto` (delegate pattern).
- **Uncertainty:** None.

### R10: Deserialize protobuf UCSchemaLocation to UCSchemaLocation entity
- **Type:** Dataflow
- **Statement:** A `pb.UCSchemaLocation` protobuf must be deserialized into a `UCSchemaLocation` entity. Extract `catalog_name` and `schema_name` directly. Optionally set `_otel_spans_table_name` and `_otel_logs_table_name` private attributes if the proto has those fields.
- **Task Evidence:** "Convert a protobuf UCSchemaLocation message to a UCSchemaLocation entity object." / "The function uses HasField() to check for optional fields before setting them"
- **Acceptance:** `uc_schema_location_from_proto(proto)` returns `UCSchemaLocation(catalog_name=..., schema_name=...)` with optional `_otel_spans_table_name` and `_otel_logs_table_name` set when present.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`; `/testbed/mlflow/entities/trace_location.py:UCSchemaLocation` (has catalog_name, schema_name, _otel_spans_table_name, _otel_logs_table_name).
- **Uncertainty:** None.

### R11: Serialize UCSchemaLocation entity to protobuf
- **Type:** Dataflow
- **Statement:** A `UCSchemaLocation` entity must be serialized to `pb.UCSchemaLocation` by mapping catalog_name, schema_name, and optionally the private `_otel_spans_table_name` and `_otel_logs_table_name` fields.
- **Task Evidence:** "Convert a UCSchemaLocation entity to its corresponding protobuf representation." / "This function accesses private attributes (_otel_spans_table_name and _otel_logs_table_name)"
- **Acceptance:** `uc_schema_location_to_proto(loc)` returns `pb.UCSchemaLocation(catalog_name=..., schema_name=..., otel_spans_table_name=..., otel_logs_table_name=...)`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_to_proto`; `/testbed/mlflow/entities/trace_location.py:UCSchemaLocation` (private attributes).
- **Uncertainty:** None.

### R12: Span.inputs property — retrieve deserialized input values
- **Type:** Interface
- **Statement:** The `Span` class must expose an `inputs` property that retrieves the deserialized input values stored as the `mlflow.spanInputs` span attribute. Returns `None` if no inputs were set.
- **Task Evidence:** "The input values of the span." / "The inputs are automatically serialized to JSON when stored and deserialized when retrieved."
- **Acceptance:** `span.inputs` returns the deserialized Python object stored in `SpanAttributeKey.INPUTS` attribute, or `None` if not set.
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:Span.get_attribute` (deserializes JSON attributes); `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.INPUTS = "mlflow.spanInputs"`; `/testbed/mlflow/entities/span.py:529` (LiveSpan.set_inputs sets this key).
- **Uncertainty:** None.

### R13: Span.outputs property — retrieve deserialized output values
- **Type:** Interface
- **Statement:** The `Span` class must expose an `outputs` property that retrieves the deserialized output values stored as the `mlflow.spanOutputs` span attribute. Returns `None` if no outputs were set.
- **Task Evidence:** "The output values of the span." / "The outputs are stored as span attributes and can contain any serializable data structure"
- **Acceptance:** `span.outputs` returns the deserialized Python object stored in `SpanAttributeKey.OUTPUTS` attribute, or `None` if not set.
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:Span.get_attribute` (deserializes JSON attributes); `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"`; `/testbed/mlflow/entities/span.py:533` (LiveSpan.set_outputs sets this key).
- **Uncertainty:** None.

### R14: AssessmentSourceType source type validation and standardization
- **Type:** Compatibility
- **Statement:** The `AssessmentSourceType` class must support string-based source type validation with case-insensitive normalization, deprecation of `AI_JUDGE` → `LLM_JUDGE` with `FutureWarning`, and rejection of invalid types with `MlflowException`. Must implement `_standardize()`, `__init__`, `__str__`, and `_parse()` methods.
- **Task Evidence:** "Validate and normalize assessment source types with deprecation handling" / "The class automatically handles: Case-insensitive string inputs (converts to uppercase), Deprecation warnings for legacy values (AI_JUDGE → LLM_JUDGE), Validation of source type values"
- **Acceptance:** `AssessmentSourceType("human")` produces an instance whose `str()` is `"HUMAN"`. `AssessmentSourceType("AI_JUDGE")` issues `FutureWarning` and produces `"LLM_JUDGE"`. `AssessmentSourceType("INVALID")` raises `MlflowException` with `INVALID_PARAMETER_VALUE`. `AssessmentSourceType._standardize("llm_judge")` returns `"LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType` (has constants but missing method implementations); `/testbed/mlflow/entities/assessment_source.py:78` (`AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`); `/testbed/tests/entities/test_assessment_source.py` (tests for case insensitivity, deprecation warning, invalid type rejection).
- **Uncertainty:** None.

## L2. Functional Design Graph

### N1: assessment_to_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference implementation).

### N2: get_trace_id_from_assessment_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N3: inference_table_location_to_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N4: mlflow_experiment_location_to_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N5: trace_from_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N6: trace_info_to_v4_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N7: trace_location_from_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N8: trace_location_to_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N9: trace_to_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N10: uc_schema_location_from_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N11: uc_schema_location_to_proto
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` (target); `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference).

### N12: Span.inputs (property)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:Span` (class exists; property currently absent but required by interface); `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.INPUTS`.

### N13: Span.outputs (property)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:Span` (class exists; property currently absent but required by interface); `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.OUTPUTS`.

### N14: AssessmentSourceType._standardize
- **Kind:** Method (staticmethod)
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType` (class exists; method referenced but not implemented); `/testbed/mlflow/entities/assessment_source.py:78` (caller: `AssessmentSource.__post_init__`).

### N15: AssessmentSourceType.__init__
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType` (class exists; constructor not implemented).

### N16: AssessmentSourceType.__str__
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType` (class exists; __str__ not implemented).

### N17: AssessmentSourceType._parse
- **Kind:** Method (staticmethod)
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType` (class exists; _parse not implemented).

### N18: parse_trace_id_v4 (external)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/tracing/utils/__init__.py:parse_trace_id_v4`.

### N19: construct_trace_id_v4 (external)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/tracing/utils/__init__.py:construct_trace_id_v4`.

### N20: _truncate_request_metadata (external)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info_v2.py:_truncate_request_metadata`.

### N21: _truncate_tags (external)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info_v2.py:_truncate_tags`.

### N22: TraceInfo.to_proto (caller)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info.py:to_proto` (calls `trace_info_to_v4_proto(self)` for v4 traces).

### N23: TraceLocation.from_proto (caller)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:from_proto` (calls `trace_location_from_proto(proto)`).

### N24: AssessmentSource.__post_init__ (caller)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:__post_init__` (calls `AssessmentSourceType._standardize(self.source_type)`).

### N25: Expectation.from_proto / Feedback.from_proto (callers)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:288,426` (import and call `get_trace_id_from_assessment_proto`).

### N26: Span.get_attribute (helper)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:get_attribute` (deserializes JSON attributes via `_CachedSpanAttributesRegistry.get`).

### N27: DatabricksTracingRestStore (caller)
- **Kind:** Class
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/store/tracking/databricks_rest_store.py:DatabricksTracingRestStore` (imports `assessment_to_proto`, `trace_from_proto`, `trace_location_to_proto`, `uc_schema_location_from_proto`, `uc_schema_location_to_proto` from `mlflow.utils.databricks_tracing_utils`).

---

### E1: N22 -> N6 (TraceInfo.to_proto calls trace_info_to_v4_proto)
- **Kind:** CALL
- **Condition:** `trace_info._is_v4()` is True (trace_location has uc_schema)
- **Transfer:** `TraceInfo → pb.TraceInfo`
- **Evidence:** `/testbed/mlflow/entities/trace_info.py:103` calls `trace_info_to_v4_proto(self)`; `/testbed/libs/skinny/mlflow/entities/trace_info.py:101` has import from `mlflow.utils.databricks_tracing_utils`.
- **Obligations:** R6

### E2: N6 -> N8 (trace_info_to_v4_proto calls trace_location_to_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `TraceInfo.trace_location → pb.TraceLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto` calls `trace_location_to_proto(trace_info.trace_location)`.
- **Obligations:** R6, R8

### E3: N6 -> N18 (trace_info_to_v4_proto calls parse_trace_id_v4)
- **Kind:** CALL
- **Condition:** trace_info has uc_schema location
- **Transfer:** `TraceInfo.trace_id (v4 format) → raw trace_id`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto` calls `parse_trace_id_v4(trace_info.trace_id)`.
- **Obligations:** R6

### E4: N6 -> N20, N21 (trace_info_to_v4_proto calls truncation helpers)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `trace_metadata, tags → truncated dicts`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto` calls `_truncate_request_metadata` and `_truncate_tags`.
- **Obligations:** R6

### E5: N6 -> N1 (trace_info_to_v4_proto calls assessment_to_proto for each assessment)
- **Kind:** CALL
- **Condition:** trace_info has assessments
- **Transfer:** `Assessment → pb.Assessment` per assessment
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto` calls `[assessment_to_proto(a) for a in trace_info.assessments]`.
- **Obligations:** R1, R6

### E6: N23 -> N7 (TraceLocation.from_proto calls trace_location_from_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `pb.TraceLocation → TraceLocation entity`
- **Evidence:** `/testbed/mlflow/entities/trace_location.py:246` calls `trace_location_from_proto(proto)`; `/testbed/libs/skinny/mlflow/entities/trace_location.py:244` has import.
- **Obligations:** R7

### E7: N7 -> N10 (trace_location_from_proto calls uc_schema_location_from_proto)
- **Kind:** CALL
- **Condition:** `proto.WhichOneof("identifier") == "uc_schema"`
- **Transfer:** `pb.UCSchemaLocation → UCSchemaLocation entity`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto` calls `uc_schema_location_from_proto(proto.uc_schema)`.
- **Obligations:** R7, R10

### E8: N7 -> MlflowExperimentLocation.from_proto
- **Kind:** CALL
- **Condition:** `proto.WhichOneof("identifier") == "mlflow_experiment"`
- **Transfer:** `pb.MlflowExperimentLocation → MlflowExperimentLocation entity`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto` calls `MlflowExperimentLocation.from_proto(proto.mlflow_experiment)`.
- **Obligations:** R7

### E9: N7 -> InferenceTableLocation.from_proto
- **Kind:** CALL
- **Condition:** `proto.WhichOneof("identifier") == "inference_table"`
- **Transfer:** `pb.InferenceTableLocation → InferenceTableLocation entity`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto` calls `InferenceTableLocation.from_proto(proto.inference_table)`.
- **Obligations:** R7

### E10: N8 -> N11 (trace_location_to_proto calls uc_schema_location_to_proto)
- **Kind:** CALL
- **Condition:** `trace_location.type == UC_SCHEMA`
- **Transfer:** `UCSchemaLocation → pb.UCSchemaLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto` calls `uc_schema_location_to_proto(trace_location.uc_schema)`.
- **Obligations:** R8, R11

### E11: N8 -> N4 (trace_location_to_proto calls mlflow_experiment_location_to_proto)
- **Kind:** CALL
- **Condition:** `trace_location.type == MLFLOW_EXPERIMENT`
- **Transfer:** `MlflowExperimentLocation → pb.MlflowExperimentLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto` calls `mlflow_experiment_location_to_proto(trace_location.mlflow_experiment)`.
- **Obligations:** R4, R8

### E12: N8 -> N3 (trace_location_to_proto calls inference_table_location_to_proto)
- **Kind:** CALL
- **Condition:** `trace_location.type == INFERENCE_TABLE`
- **Transfer:** `InferenceTableLocation → pb.InferenceTableLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto` calls `inference_table_location_to_proto(trace_location.inference_table)`.
- **Obligations:** R3, R8

### E13: N9 -> TraceInfo.to_proto, Span.to_otel_proto (trace_to_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `Trace → pb.Trace` via `trace.info.to_proto()` and `span.to_otel_proto()` for each span.
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_to_proto`; `/testbed/tests/store/tracking/test_databricks_rest_store.py:212,451` (caller).
- **Obligations:** R9

### E14: N5 -> TraceInfo.from_proto, Span.from_otel_proto (trace_from_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `pb.Trace → Trace` via `TraceInfo.from_proto(proto.trace_info)` and `Span.from_otel_proto(span, location_id)` for each span.
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`; `/testbed/libs/tracing/mlflow/store/tracking/databricks_rest_store.py` (imports `trace_from_proto`).
- **Obligations:** R5

### E15: N1 -> parse_trace_id_v4, construct_trace_id_v4 (assessment_to_proto parses trace_id)
- **Kind:** CALL
- **Condition:** trace_id is v4 format (has `trace:/` prefix)
- **Transfer:** `assessment.trace_id → (location, raw_trace_id)`, then `pb.TraceLocation` with catalog/schema extracted from location.
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto` calls `parse_trace_id_v4(assessment.trace_id)` and splits location by `.` for catalog/schema.
- **Obligations:** R1

### E16: N1 -> AssessmentSource.to_proto (assessment_to_proto converts source)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `assessment.source.to_proto() → pb.Assessment.source`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto` calls `assessment.source.to_proto()`.
- **Obligations:** R1

### E17: N2 -> N19 (get_trace_id_from_assessment_proto calls construct_trace_id_v4)
- **Kind:** CALL
- **Condition:** proto has `trace_location.uc_schema`
- **Transfer:** `(catalog.schema, trace_id) → v4 trace_id string`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto` calls `construct_trace_id_v4(...)`.
- **Obligations:** R2

### E18: N25 -> N2 (Expectation.from_proto / Feedback.from_proto call get_trace_id_from_assessment_proto)
- **Kind:** CALL
- **Condition:** Always during deserialization
- **Transfer:** `proto → trace_id string`
- **Evidence:** `/testbed/mlflow/entities/assessment.py:288,426` import and call `get_trace_id_from_assessment_proto(proto)`.
- **Obligations:** R2

### E19: N24 -> N14 (AssessmentSource.__post_init__ calls AssessmentSourceType._standardize)
- **Kind:** CALL
- **Condition:** Always during AssessmentSource initialization
- **Transfer:** `self.source_type (raw string) → standardized string`
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:78` calls `AssessmentSourceType._standardize(self.source_type)`.
- **Obligations:** R14

### E20: N14 -> N15, N16 (AssessmentSourceType._standardize creates instance and calls __str__)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `source_type string → AssessmentSourceType instance → str(instance) → standardized string`
- **Evidence:** Task description: "The _standardize method must instantiate an AssessmentSourceType object by calling the constructor AssessmentSourceType(source_type), then convert the instance to a string representation to obtain the standardized value."
- **Obligations:** R14

### E21: N15 -> N17 (AssessmentSourceType.__init__ calls _parse)
- **Kind:** CALL
- **Condition:** Always during construction
- **Transfer:** `source_type string → validated/standardized string stored in instance`
- **Evidence:** Task description: "The constructor must delegate validation and transformation logic to a _parse(source_type: str) static method."
- **Obligations:** R14

### E22: N12 -> N26 (Span.inputs calls get_attribute)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `SpanAttributeKey.INPUTS → deserialized value or None`
- **Evidence:** `/testbed/mlflow/entities/span.py:Span.get_attribute` (deserializes from `_CachedSpanAttributesRegistry`); `/testbed/mlflow/entities/span.py:529` (LiveSpan.set_inputs sets SpanAttributeKey.INPUTS).
- **Obligations:** R12

### E23: N13 -> N26 (Span.outputs calls get_attribute)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `SpanAttributeKey.OUTPUTS → deserialized value or None`
- **Evidence:** `/testbed/mlflow/entities/span.py:Span.get_attribute` (deserializes from `_CachedSpanAttributesRegistry`); `/testbed/mlflow/entities/span.py:533` (LiveSpan.set_outputs sets SpanAttributeKey.OUTPUTS).
- **Obligations:** R13

### E24: N7 -> TraceLocation (fallback for unspecified)
- **Kind:** CONTROL
- **Condition:** No recognized oneof identifier
- **Transfer:** Returns `TraceLocation(TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto` has else branch returning unspecified.
- **Obligations:** R7

### E25: N8 -> ValueError (unsupported type)
- **Kind:** CONTROL
- **Condition:** `trace_location.type` not in {UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE}
- **Transfer:** Raises `ValueError`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto` has else branch raising ValueError.
- **Obligations:** R8

## L3. Verifiable Contracts

### C1: assessment_to_proto populates all required fields
- **Type:** Dataflow
- **Subject:** `assessment_to_proto(assessment)` return value
- **Relation:** EQ
- **Expected:** Returned `pb.Assessment` has: `assessment_name == assessment.name`, `trace_id == parsed_raw_id` (or original if not v4), `source` from `assessment.source.to_proto()`, `create_time` from `assessment.create_time_ms`, `last_update_time` from `assessment.last_update_time_ms`.
- **Evidence:** Task description for assessment_to_proto; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto` (reference).
- **Observe:** RETURN_VALUE
- **Target:** `assessment_to_proto(assessment)` → `pb.Assessment` fields
- **Obligations:** R1
- **Graph:** N1, E15, E16

### C2: assessment_to_proto handles v4 trace_id with UC Schema location
- **Type:** Dataflow
- **Subject:** `assessment_to_proto(assessment)` when `assessment.trace_id` is v4 format
- **Relation:** CONTAINS
- **Expected:** The returned proto has `trace_location.type == UC_SCHEMA`, `trace_location.uc_schema.catalog_name` and `schema_name` extracted from the v4 trace_id location segment.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `assessment_to_proto(assessment).trace_location`
- **Obligations:** R1
- **Graph:** N1, E15

### C3: assessment_to_proto sets optional fields only when present
- **Type:** Dataflow
- **Subject:** `assessment_to_proto(assessment)` for optional fields (span_id, rationale, assessment_id, metadata, overrides, valid)
- **Relation:** PRESERVE
- **Expected:** Proto fields are set only when the corresponding assessment field is not None. Metadata values cast to `str`.
- **Evidence:** Task notes: "The function handles None values gracefully by only setting proto fields when the corresponding assessment fields are not None" / "Metadata values are converted to strings."
- **Observe:** RETURN_VALUE
- **Target:** `assessment_to_proto(assessment)` — check optional fields only present when source has them
- **Obligations:** R1
- **Graph:** N1

### C4: assessment_to_proto sets exactly one of expectation or feedback
- **Type:** Dataflow
- **Subject:** `assessment_to_proto(assessment)` — expectation vs feedback
- **Relation:** EQ
- **Expected:** If `assessment.expectation` is not None, proto has `expectation` field set via `assessment.expectation.to_proto()`. If `assessment.feedback` is not None, proto has `feedback` field set via `assessment.feedback.to_proto()`. Not both.
- **Evidence:** Task notes: "Either expectation or feedback will be set in the proto, but not both"; `/testbed/mlflow/entities/assessment.py:__post_init__` enforces exactly one of expectation/feedback.
- **Observe:** RETURN_VALUE
- **Target:** `assessment_to_proto(assessment)` — check oneof field
- **Obligations:** R1
- **Graph:** N1

### C5: get_trace_id_from_assessment_proto returns v4 trace ID for UC Schema
- **Type:** Dataflow
- **Subject:** `get_trace_id_from_assessment_proto(proto)` with `proto.trace_location.uc_schema` set
- **Relation:** EQ
- **Expected:** Returns `"trace:/<catalog>.<schema>/<trace_id>"` constructed via `construct_trace_id_v4`.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`; `/testbed/mlflow/tracing/utils/__init__.py:construct_trace_id_v4`.
- **Observe:** RETURN_VALUE
- **Target:** `get_trace_id_from_assessment_proto(proto)`
- **Obligations:** R2
- **Graph:** N2, E17, E18

### C6: get_trace_id_from_assessment_proto returns raw trace_id for non-UC locations
- **Type:** Dataflow
- **Subject:** `get_trace_id_from_assessment_proto(proto)` without `trace_location.uc_schema`
- **Relation:** EQ
- **Expected:** Returns `proto.trace_id` directly.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto` (else branch).
- **Observe:** RETURN_VALUE
- **Target:** `get_trace_id_from_assessment_proto(proto)`
- **Obligations:** R2
- **Graph:** N2, E18

### C7: inference_table_location_to_proto maps full_table_name
- **Type:** Dataflow
- **Subject:** `inference_table_location_to_proto(loc)`
- **Relation:** EQ
- **Expected:** `pb.InferenceTableLocation(full_table_name=loc.full_table_name)`
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:inference_table_location_to_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `inference_table_location_to_proto(loc).full_table_name`
- **Obligations:** R3
- **Graph:** N3, E12

### C8: mlflow_experiment_location_to_proto maps experiment_id
- **Type:** Dataflow
- **Subject:** `mlflow_experiment_location_to_proto(loc)`
- **Relation:** EQ
- **Expected:** `pb.MlflowExperimentLocation(experiment_id=loc.experiment_id)`
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:mlflow_experiment_location_to_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `mlflow_experiment_location_to_proto(loc).experiment_id`
- **Obligations:** R4
- **Graph:** N4, E11

### C9: trace_from_proto returns Trace with correct info and data
- **Type:** Dataflow
- **Subject:** `trace_from_proto(proto, location_id)`
- **Relation:** EQ
- **Expected:** Returns `Trace(info=TraceInfo.from_proto(proto.trace_info), data=TraceData(spans=[Span.from_otel_proto(s, location_id) for s in proto.spans]))`.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `trace_from_proto(proto, location_id).info` and `.data.spans`
- **Obligations:** R5
- **Graph:** N5, E14

### C10: trace_info_to_v4_proto parses v4 trace_id for UC Schema
- **Type:** Dataflow
- **Subject:** `trace_info_to_v4_proto(trace_info)` when `trace_info.trace_location.uc_schema` is not None
- **Relation:** EQ
- **Expected:** The returned proto's `trace_id` is the raw trace ID extracted via `parse_trace_id_v4(trace_info.trace_id)`.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `trace_info_to_v4_proto(trace_info).trace_id`
- **Obligations:** R6
- **Graph:** N6, E1, E3

### C11: trace_info_to_v4_proto includes all assessments
- **Type:** Dataflow
- **Subject:** `trace_info_to_v4_proto(trace_info).assessments`
- **Relation:** EQ
- **Expected:** Each assessment in `trace_info.assessments` is converted via `assessment_to_proto()` and included in the proto.
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto` (list comprehension).
- **Observe:** RETURN_VALUE
- **Target:** `trace_info_to_v4_proto(trace_info).assessments` count and content
- **Obligations:** R1, R6
- **Graph:** N6, E5

### C12: trace_info_to_v4_proto converts timestamps from ms to protobuf Timestamp
- **Type:** Dataflow
- **Subject:** `trace_info_to_v4_proto(trace_info).request_time`
- **Relation:** EQ
- **Expected:** Request time is converted from milliseconds to `google.protobuf.Timestamp` via `FromMilliseconds()`. Execution duration (if not None) converted similarly to `google.protobuf.Duration`.
- **Evidence:** Task notes: "Timestamps are converted from milliseconds to protobuf Timestamp format using FromMilliseconds()"; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `trace_info_to_v4_proto(trace_info).request_time.ToMilliseconds() == trace_info.request_time`
- **Obligations:** R6
- **Graph:** N6

### C13: trace_location_from_proto dispatches to correct sub-location handler
- **Type:** Dataflow
- **Subject:** `trace_location_from_proto(proto)` with `proto.WhichOneof("identifier") == "uc_schema"`
- **Relation:** EQ
- **Expected:** Returns `TraceLocation(type=UC_SCHEMA, uc_schema=uc_schema_location_from_proto(proto.uc_schema))`.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `trace_location_from_proto(proto).uc_schema`
- **Obligations:** R7, R10
- **Graph:** N7, E7

### C14: trace_location_from_proto falls back to UNSPECIFIED when no identifier
- **Type:** Dataflow
- **Subject:** `trace_location_from_proto(proto)` when no oneof identifier is set
- **Relation:** EQ
- **Expected:** Returns `TraceLocation(TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)`.
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto` (else branch).
- **Observe:** RETURN_VALUE
- **Target:** `trace_location_from_proto(proto).type`
- **Obligations:** R7
- **Graph:** N7, E24

### C15: trace_location_to_proto raises ValueError for unsupported type
- **Type:** Failure
- **Subject:** `trace_location_to_proto(trace_location)` with unsupported type
- **Relation:** RAISES
- **Expected:** Raises `ValueError` with message about unsupported trace location type.
- **Evidence:** Task description: "Raises: ValueError: If the trace_location.type is not one of the supported types"; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`.
- **Observe:** EXCEPTION
- **Target:** `trace_location_to_proto(TraceLocation(type=unsupported))` raises ValueError
- **Obligations:** R8
- **Graph:** N8, E25

### C16: trace_to_proto returns pb.Trace with trace_info and spans
- **Type:** Dataflow
- **Subject:** `trace_to_proto(trace)` return value
- **Relation:** EQ
- **Expected:** Returns `pb.Trace` with `trace_info` from `trace.info.to_proto()` and `spans` from `[span.to_otel_proto() for span in trace.data.spans]`.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:trace_to_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `trace_to_proto(trace)` → `pb.Trace`
- **Obligations:** R9
- **Graph:** N9, E13

### C17: uc_schema_location_from_proto sets optional table names via HasField
- **Type:** Dataflow
- **Subject:** `uc_schema_location_from_proto(proto)` when proto has `otel_spans_table_name`
- **Relation:** EQ
- **Expected:** The returned `UCSchemaLocation` has `_otel_spans_table_name == proto.otel_spans_table_name` and `_otel_logs_table_name == proto.otel_logs_table_name` when those fields are set.
- **Evidence:** Task description: "The function uses HasField() to check for optional fields"; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`.
- **Observe:** FIELD_READ
- **Target:** `uc_schema_location_from_proto(proto)._otel_spans_table_name`
- **Obligations:** R10
- **Graph:** N10, E7

### C18: uc_schema_location_to_proto maps all fields including private table names
- **Type:** Dataflow
- **Subject:** `uc_schema_location_to_proto(loc)` return value
- **Relation:** EQ
- **Expected:** Returns `pb.UCSchemaLocation(catalog_name=loc.catalog_name, schema_name=loc.schema_name, otel_spans_table_name=loc._otel_spans_table_name, otel_logs_table_name=loc._otel_logs_table_name)`.
- **Evidence:** Task description; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_to_proto`.
- **Observe:** RETURN_VALUE
- **Target:** `uc_schema_location_to_proto(loc)` → `pb.UCSchemaLocation`
- **Obligations:** R11
- **Graph:** N11, E10

### C19: Span.inputs returns deserialized value from SpanAttributeKey.INPUTS
- **Type:** Interface
- **Subject:** `Span.inputs` property
- **Relation:** EQ
- **Expected:** Returns the result of `self.get_attribute(SpanAttributeKey.INPUTS)` which deserializes the JSON-stored value. Returns `None` if attribute not set.
- **Evidence:** Task description for Span.inputs; `/testbed/mlflow/entities/span.py:Span.get_attribute`; `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.INPUTS = "mlflow.spanInputs"`.
- **Observe:** RETURN_VALUE
- **Target:** `span.inputs`
- **Obligations:** R12
- **Graph:** N12, E22, N26

### C20: Span.outputs returns deserialized value from SpanAttributeKey.OUTPUTS
- **Type:** Interface
- **Subject:** `Span.outputs` property
- **Relation:** EQ
- **Expected:** Returns the result of `self.get_attribute(SpanAttributeKey.OUTPUTS)` which deserializes the JSON-stored value. Returns `None` if attribute not set.
- **Evidence:** Task description for Span.outputs; `/testbed/mlflow/entities/span.py:Span.get_attribute`; `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"`.
- **Observe:** RETURN_VALUE
- **Target:** `span.outputs`
- **Obligations:** R13
- **Graph:** N13, E23, N26

### C21: AssessmentSourceType._standardize returns uppercase validated string
- **Type:** Dataflow
- **Subject:** `AssessmentSourceType._standardize(source_type)` with valid input
- **Relation:** EQ
- **Expected:** For `"human"` → `"HUMAN"`; for `"llm_judge"` → `"LLM_JUDGE"`; for `"AI_JUDGE"` → `"LLM_JUDGE"` (with FutureWarning). Constructs instance via `AssessmentSourceType(source_type)` and returns `str(instance)`.
- **Evidence:** Task description; `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_case_insensitivity`, `test_ai_judge_deprecation_warning`, `test_assessment_source_type_validation`.
- **Observe:** RETURN_VALUE
- **Target:** `AssessmentSourceType._standardize("human")` → `"HUMAN"`
- **Obligations:** R14
- **Graph:** N14, E19, E20

### C22: AssessmentSourceType.__init__ delegates to _parse and stores result
- **Type:** State
- **Subject:** `AssessmentSourceType(source_type_str)` instance after construction
- **Relation:** EQ
- **Expected:** `str(instance)` equals the result of `_parse(source_type_str)`. The parsed value is stored as an instance attribute.
- **Evidence:** Task description: "The constructor must delegate validation and transformation logic to a _parse(source_type: str) static method."
- **Observe:** STATE_READ
- **Target:** `str(AssessmentSourceType("human"))` → `"HUMAN"`
- **Obligations:** R14
- **Graph:** N15, E21

### C23: AssessmentSourceType._parse normalizes case and handles AI_JUDGE deprecation
- **Type:** Dataflow
- **Subject:** `AssessmentSourceType._parse(source_type)`
- **Relation:** EQ
- **Expected:** Converts input to uppercase. Maps `"AI_JUDGE"` → `"LLM_JUDGE"` with `FutureWarning`. Validates against `_SOURCE_TYPES` list. Raises `MlflowException` with `INVALID_PARAMETER_VALUE` error code for invalid types.
- **Evidence:** Task description; `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_type_validation` expects `MlflowException` with match `"Invalid assessment source type"`; `/testbed/mlflow/protos/databricks_pb2:INVALID_PARAMETER_VALUE`.
- **Observe:** RETURN_VALUE / EXCEPTION
- **Target:** `AssessmentSourceType._parse("human")` → `"HUMAN"`; `AssessmentSourceType._parse("ROBOT")` → raises MlflowException
- **Obligations:** R14
- **Graph:** N17, E21

### C24: AssessmentSourceType constants are simple string values
- **Type:** Interface
- **Subject:** `AssessmentSourceType.LLM_JUDGE`, `AssessmentSourceType.HUMAN`, etc.
- **Relation:** TYPE_IS
- **Expected:** Each constant is a `str` value (not a dict). `_SOURCE_TYPES` is `[SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]` (excluding deprecated `AI_JUDGE`).
- **Evidence:** Task description: "The class constants (SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, AI_JUDGE, HUMAN, CODE) should be defined as simple string values, not dictionary structures. The _SOURCE_TYPES list should contain [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE] (excluding the deprecated AI_JUDGE)."
- **Observe:** IMPORT_BOUNDARY
- **Target:** `AssessmentSourceType.LLM_JUDGE` is `"LLM_JUDGE"` (str)
- **Obligations:** R14
- **Graph:** N15

### C25: AssessmentSource.__post_init__ calls _standardize
- **Type:** SideEffect
- **Subject:** `AssessmentSource(source_type="human", source_id="x")` initialization
- **Relation:** EQ
- **Expected:** After `__post_init__`, `source.source_type == "HUMAN"` (standardized via `AssessmentSourceType._standardize`).
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:78` (`self.source_type = AssessmentSourceType._standardize(self.source_type)`); `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_case_insensitivity`.
- **Observe:** FIELD_READ
- **Target:** `AssessmentSource(source_type="human", source_id="x").source_type` → `"HUMAN"`
- **Obligations:** R14
- **Graph:** N24, E19, N14
