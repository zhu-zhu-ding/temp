"""Executable architecture spec for structured-unit and function-helper task.

This file compiles the L2/L3 path contracts from semantic_ir.md into runtime
call-chain observations.  It keeps repository dispatchers live: helper dict
entries and module globals are temporarily wrapped with call-recording shims
that delegate to the real implementation.  The public NumPy/ERFA entries are
always invoked first so every material path below starts at its L2 public
entry.

The rework edition additionally records call ordering through the full
`np.concatenate -> _iterable_helper -> _quantities2arrays -> get_err_str`
error path and observes `_iterable_helper` through every acceptance-listed
NumPy caller (`concatenate`, `choose`, `select`, `quantile`, `nanmedian`).
"""

from __future__ import annotations

import contextlib
import re

import numpy as np

import astropy.units as u
import astropy.units.core as core
import astropy.units.structured as structured
import erfa
from astropy.units import Quantity, StructuredUnit
from astropy.units.quantity_helper import erfa as erfa_helpers_module
from astropy.units.quantity_helper import function_helpers


@contextlib.contextmanager
def _spy_name(obj, name, order=None, label=None):
    """Temporarily wrap a module/class attribute, recording calls."""
    original = getattr(obj, name)
    calls = []

    def wrapper(*args, **kwargs):
        calls.append((args, kwargs))
        if order is not None:
            order.append(label or name)
        return original(*args, **kwargs)

    setattr(obj, name, wrapper)
    try:
        yield calls
    finally:
        setattr(obj, name, original)


@contextlib.contextmanager
def _spy_dict_entry(d, key, order=None, label=None):
    """Temporarily wrap a dispatcher dict entry, recording calls."""
    original = d[key]
    calls = []

    def wrapper(*args, **kwargs):
        calls.append((args, kwargs))
        if order is not None:
            order.append(label or str(key))
        return original(*args, **kwargs)

    d[key] = wrapper
    try:
        yield calls
    finally:
        d[key] = original


@contextlib.contextmanager
def _assert_raises(exc_type, match=None):
    """Assert that the guarded block raises ``exc_type``.

    ``match``, when given, is a regular expression searched in the exception
    text with ``re.search``.
    """
    try:
        yield
    except exc_type as exc:
        if match is not None and re.search(match, str(exc), re.DOTALL) is None:
            raise AssertionError(
                f"expected {exc_type.__name__} matching {match!r}; got {str(exc)!r}"
            ) from exc
    else:
        raise AssertionError(f"expected {exc_type.__name__!r}, but no exception was raised")


# Contracts: C25; R2, R3, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_einsum, test_zeros_like, test_ones_like.
# Perspective: public function-helper registration must be observable from the
#   module-level dispatcher after import, and the registered object must be the
#   declared helper symbol (not merely an output-compatible substitute).
# Source path/symbol: astropy/units/quantity_helper/function_helpers.FUNCTION_HELPERS,
#   function_helpers.einsum, function_helpers.like_helper, function_helpers.concatenate.
def check_registered_function_helpers():
    helpers = function_helpers.FUNCTION_HELPERS

    assert np.einsum in helpers, "np.einsum is not registered in FUNCTION_HELPERS"
    assert np.ones_like in helpers, "np.ones_like is not registered in FUNCTION_HELPERS"
    assert np.zeros_like in helpers, "np.zeros_like is not registered in FUNCTION_HELPERS"
    assert np.concatenate in helpers, "np.concatenate is not registered in FUNCTION_HELPERS"

    assert helpers[np.einsum] is function_helpers.einsum
    assert helpers[np.ones_like] is function_helpers.like_helper
    assert helpers[np.zeros_like] is function_helpers.like_helper
    assert helpers[np.concatenate] is function_helpers.concatenate


# Contracts: C11, C13; R4, R5.
# Static issue: structured._normalize_names (on-path) is closed by driving the
#   public StructuredUnit constructor through __new__ to _normalize_names.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitBasics.test_recursive_initialization (lines 71-95).
# Perspective: observe the constructor's real caller-binding to
#   _normalize_names; the behavior outcome is asserted separately in
#   behavior_spec.py C11/C12.
# Source path/symbol: astropy/units/structured.StructuredUnit.__new__ ->
#   astropy/units/structured._normalize_names.
def check_structured_unit_constructor_reaches_normalize_names():
    with _spy_name(structured, "_normalize_names") as normalize_calls:
        su = StructuredUnit((("km", "km/s"), "yr"), names=(("p", "v"), "t"))

    assert len(normalize_calls) >= 1, f"_normalize_names call count {len(normalize_calls)!r}"
    assert any(
        call[0] and call[0][0] == (("p", "v"), "t") for call in normalize_calls
    ), f"no _normalize_names call with nested names; got {normalize_calls!r}"
    assert su.field_names == (["pv", ("p", "v")], "t")


# Contracts: C5, C18; R2, R8, R12.
# Static issue: function_helpers._as_quantities (on-path) is closed by driving
#   np.einsum -> Quantity.__array_function__ -> function_helpers.einsum ->
#   function_helpers._as_quantities.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_einsum (lines 1415-1428).
# Perspective: prove the full dispatch chain reaches both the einsum helper and
#   _as_quantities, and that the registered helper identity is the declared
#   symbol.  The public result carries the product unit.
# Source path/symbol:
#   astropy/units/quantity.py Quantity.__array_function__,
#   astropy/units/quantity_helper/function_helpers.einsum,
#   astropy/units/quantity_helper/function_helpers._as_quantities.
def check_einsum_public_dispatch_chain():
    assert function_helpers.FUNCTION_HELPERS[np.einsum] is function_helpers.einsum

    a = [[1, 2], [3, 4]] * u.m
    b = [[5, 6], [7, 8]] * u.s

    with _spy_dict_entry(function_helpers.FUNCTION_HELPERS, np.einsum) as einsum_calls, _spy_name(
        function_helpers, "_as_quantities"
    ) as as_quantities_calls:
        result = np.einsum("ij,jk->ik", a, b)

    assert len(einsum_calls) == 1, f"einsum helper call count {len(einsum_calls)!r}"
    assert einsum_calls[0][0][0] == "ij,jk->ik"
    assert einsum_calls[0][0][1] is a
    assert einsum_calls[0][0][2] is b

    assert len(as_quantities_calls) == 1, f"_as_quantities call count {len(as_quantities_calls)!r}"
    assert len(as_quantities_calls[0][0]) == 2
    assert as_quantities_calls[0][0][0] is a
    assert as_quantities_calls[0][0][1] is b

    assert isinstance(result, Quantity)
    assert result.unit == u.m * u.s
    np.testing.assert_allclose(
        result.value, np.einsum("ij,jk->ik", a.to_value(u.m), b.to_value(u.s))
    )


# Contracts: C9, C10 (path proof), R3, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_zeros_like/test_ones_like (lines 341-348);
#   astropy/units/tests/test_structured.py TestStructuredQuantityFunctions
#   test_zeros_ones_like (lines 646-651).
# Perspective: prove np.ones_like/np.zeros_like dispatch through Quantity and
#   the registered like_helper; default path preserves unit, subok=False path
#   returns plain ndarray.  The dispatcher identity is asserted before the
#   dict-entry spies are installed.
# Source path/symbol:
#   astropy/units/quantity.py Quantity.__array_function__,
#   astropy/units/quantity_helper/function_helpers.like_helper.
def check_like_public_dispatch_chain():
    assert function_helpers.FUNCTION_HELPERS[np.ones_like] is function_helpers.like_helper
    assert function_helpers.FUNCTION_HELPERS[np.zeros_like] is function_helpers.like_helper

    q = [1.0, 2.0, 3.0] * u.m

    with _spy_dict_entry(function_helpers.FUNCTION_HELPERS, np.ones_like) as ones_calls, _spy_dict_entry(
        function_helpers.FUNCTION_HELPERS, np.zeros_like
    ) as zeros_calls:
        ones = np.ones_like(q)
        zeros = np.zeros_like(q, subok=False)

    assert len(ones_calls) == 1, f"ones_like helper call count {len(ones_calls)!r}"
    assert ones_calls[0][0][0] is q
    assert isinstance(ones, Quantity)
    assert ones.unit == u.m
    np.testing.assert_array_equal(ones.value, np.ones_like(q.value))

    assert len(zeros_calls) == 1, f"zeros_like helper call count {len(zeros_calls)!r}"
    assert zeros_calls[0][0][0] is q
    assert type(zeros) is np.ndarray
    np.testing.assert_array_equal(zeros, np.zeros_like(q.value))


# Contracts: C3; R1, R12.
# Static issue: function_helpers._iterable_helper (on-path) is closed by
#   driving np.concatenate -> Quantity.__array_function__ ->
#   function_helpers.concatenate -> function_helpers._iterable_helper.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_concatenate (lines 711-734).
# Perspective: prove the public concatenate call reaches both the registered
#   helper and _iterable_helper, and that the unit survives to the result.
# Source path/symbol:
#   astropy/units/quantity.py Quantity.__array_function__,
#   astropy/units/quantity_helper/function_helpers.concatenate,
#   astropy/units/quantity_helper/function_helpers._iterable_helper.
def check_concatenate_public_dispatch_chain():
    assert function_helpers.FUNCTION_HELPERS[np.concatenate] is function_helpers.concatenate

    q1 = [1, 2] * u.m
    q2 = [3, 4] * u.m

    with _spy_dict_entry(
        function_helpers.FUNCTION_HELPERS, np.concatenate
    ) as concatenate_calls, _spy_name(function_helpers, "_iterable_helper") as iterable_calls:
        result = np.concatenate([q1, q2])

    assert len(concatenate_calls) == 1, f"concatenate helper call count {len(concatenate_calls)!r}"
    assert len(iterable_calls) == 1, f"_iterable_helper call count {len(iterable_calls)!r}"
    # concatenate passes *arrays to _iterable_helper.
    assert iterable_calls[0][0][0] is q1
    assert iterable_calls[0][0][1] is q2

    assert isinstance(result, Quantity)
    assert result.unit == u.m
    np.testing.assert_array_equal(result.value, np.concatenate([q1.value, q2.value]))


# Contracts: C20; R1, R9.
# Static issues: function_helpers._iterable_helper and core.get_err_str (both
#   on the same path) are closed by driving an incompatible np.concatenate all
#   the way through _quantities2arrays -> Quantity._to_own_unit ->
#   UnitBase.get_converter -> UnitBase._apply_equivalencies -> core.get_err_str.
#   Unlike the previous edition, every intermediate layer is spied in one shared
#   order list so the error-path check cannot bypass _iterable_helper or
#   _quantities2arrays.
# Repository guidance: astropy/units/tests/test_units.py test_convertible_exception2
#   (lines 339-340) and test_quantity_non_ufuncs.py test_concatenate failure angle.
# Perspective: an incompatible public concatenate must raise UnitConversionError,
#   after passing through concatenate, _iterable_helper, _quantities2arrays, and
#   then core.get_err_str.
# Source path/symbol:
#   astropy/units/quantity.py Quantity._to_own_unit,
#   astropy/units/core.py UnitBase.get_converter, UnitBase._apply_equivalencies,
#   astropy/units/core.py get_err_str.
def check_incompatible_concatenate_reaches_get_err_str():
    q1 = [1, 2] * u.m
    q2 = [1, 2] * u.s

    order = []
    with _spy_dict_entry(
        function_helpers.FUNCTION_HELPERS, np.concatenate, order, "concatenate"
    ) as concatenate_calls, _spy_name(
        function_helpers, "_iterable_helper", order, "iterable_helper"
    ) as iterable_calls, _spy_name(
        function_helpers, "_quantities2arrays", order, "quantities2arrays"
    ) as quantities_calls, _spy_name(
        core, "get_err_str", order, "get_err_str"
    ) as get_err_calls:
        with _assert_raises(u.UnitConversionError, match="are not convertible"):
            np.concatenate([q1, q2])

    assert len(concatenate_calls) == 1, f"concatenate helper call count {len(concatenate_calls)!r}"
    assert len(iterable_calls) == 1, f"_iterable_helper call count {len(iterable_calls)!r}"
    assert len(quantities_calls) == 1, f"_quantities2arrays call count {len(quantities_calls)!r}"
    assert len(get_err_calls) >= 1, f"core.get_err_str call count {len(get_err_calls)!r}"

    assert order.index("concatenate") < order.index("iterable_helper")
    assert order.index("iterable_helper") < order.index("quantities2arrays")
    assert order.index("quantities2arrays") < order.index("get_err_str")


# Contracts: C26 (rework addition); R1, R12.
# Static issue: function_helpers._iterable_helper is called by multiple
#   materially different NumPy helpers.  Public outputs are validated in
#   behavior_spec.py; here we prove the real public entries reach the missing
#   helper and forward their distinct kwargs.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   test_choose (991), test_select (1002), test_quantile (1142),
#   test_nanmedian (1260).
# Perspective: choose must pass mode; nanmedian must pass axis.  A helper that
#   is only wired into concatenate would fail this path check.
# Source path/symbol:
#   numpy.choose/numpy.select/numpy.quantile/numpy.nanmedian ->
#   Quantity.__array_function__ -> function_helpers.choose/select/quantile/nanmedian ->
#   function_helpers._iterable_helper.
def check_iterable_helper_reaches_additional_numpy_callers():
    a = np.array([0, 1]).reshape((2, 1, 1))
    q1 = np.array([1, 2, 3]).reshape((1, 3, 1)) * u.cm
    q2 = np.array([-1, -2, -3, -4, -5]).reshape((1, 1, 5)) * u.m
    q = np.array([0.3, 0.7, 1.2]) * u.m
    data = [1.0, 2.0, np.nan, 3.0, 4.0] * u.km

    with _spy_name(function_helpers, "_iterable_helper") as iterable_calls:
        np.choose(a, (q1, q2))
        np.select([q < 0.55 * u.m, q > 1.0 * u.m], [q, q.to(u.cm)], default=-1.0 * u.km)
        np.quantile(q, 50 * u.percent)
        np.nanmedian(data, axis=0)

    assert len(iterable_calls) == 4, f"_iterable_helper call count {len(iterable_calls)!r}"

    # choose is the first call and forwards mode='raise' through the helper.
    assert iterable_calls[0][1].get("mode") == "raise"
    # nanmedian is the fourth call and forwards axis=0 through the helper.
    assert iterable_calls[3][1].get("axis") == 0


# Contracts: C22; R10.
# Static issue: erfa.check_structured_unit (on-path) is closed by driving a valid
#   structured pv Quantity through public erfa.ufunc.pv2p ->
#   Quantity.__array_ufunc__/converters_and_unit -> get_erfa_helpers ->
#   helper_pv2p -> check_structured_unit.
# Repository guidance: static issue + astropy/units/tests/test_structured.py
#   test_parsing (structured unit shape) and test_quantity_erfa_ufuncs angle
#   named in the task. Perspective: prove the ERFA public entry reaches
#   check_structured_unit and accepts a structured dt_pv-compatible unit.
# Source path/symbol:
#   astropy/units/quantity_helper/erfa.helper_pv2p,
#   astropy/units/quantity_helper/erfa.check_structured_unit.
def check_erfa_pv2p_reaches_check_structured_unit():
    pv_unit = StructuredUnit((u.km, u.km / u.s), names=erfa.dt_pv)
    value = np.zeros(1, dtype=erfa.dt_pv)
    value["p"] = [1.0, 0.0, 0.0]
    value["v"] = [0.0, 1.0, 0.0]
    q_pv = Quantity(value, pv_unit)

    with _spy_name(erfa_helpers_module, "check_structured_unit") as check_calls:
        result = erfa.ufunc.pv2p(q_pv)

    assert len(check_calls) == 1, f"check_structured_unit call count {len(check_calls)!r}"
    assert check_calls[0][0][0] is q_pv.unit
    assert check_calls[0][0][1] == "dt_pv"

    assert isinstance(result, Quantity)
    assert result.unit == pv_unit[0]
    assert result.shape == (1, 3)


# Contracts: C27 (rework addition); R10.
# Static issue: erfa.check_structured_unit must validate structured shape for
#   dt_eraASTROM too, not just isinstance.  A wrong-shape structured unit is
#   driven through the public erfa.ufunc.aper path, whose helper_aper calls
#   check_structured_unit before touching the field at index 7.
# Repository guidance: static issue + erfa.py helper_aper (lines 322-333);
#   task artifact name refers to test_quantity_erfa_ufuncs.
# Perspective: a two-field StructuredUnit passed as ``astrom`` must raise
#   UnitTypeError and the real check_structured_unit call site must be reached.
# Source path/symbol:
#   astropy/units/quantity_helper/erfa.helper_aper,
#   astropy/units/quantity_helper/erfa.check_structured_unit.
def check_erfa_aper_reaches_check_structured_unit():
    theta = 0.0 * u.rad
    bad_unit = StructuredUnit((u.rad, u.rad), names=("x", "y"))
    bad_value = np.zeros((), dtype=[("x", "f8"), ("y", "f8")])
    bad_q = Quantity(bad_value, bad_unit)

    with _spy_name(erfa_helpers_module, "check_structured_unit") as check_calls:
        with _assert_raises(u.UnitTypeError):
            erfa.ufunc.aper(theta, bad_q)

    assert len(check_calls) >= 1, f"check_structured_unit call count {len(check_calls)!r}"
    assert check_calls[0][0][0] is bad_q.unit
    assert check_calls[0][0][1] == "dt_eraASTROM"


# Contracts: C24; R11.
# Static issue: erfa.ldbody_unit (on-path) is closed by driving public
#   erfa.ufunc.ldn -> get_erfa_helpers -> helper_ldn -> ldbody_unit.
# Repository guidance: static issue + astropy/units/tests/test_structured.py
#   test_parsing (lines 212-215) gives the equivalent structured unit.
# Perspective: prove the public ldn path reaches ldbody_unit, accepts a
#   compatible structured body Quantity, and returns a dimensionless Quantity.
# Source path/symbol:
#   astropy/units/quantity_helper/erfa.helper_ldn,
#   astropy/units/quantity_helper/erfa.ldbody_unit.
def check_erfa_ldn_reaches_ldbody_unit():
    body_unit = StructuredUnit(
        (u.Msun, u.rad**2 / 2, (u.AU, u.AU / u.day)), names=erfa.dt_eraLDBODY
    )
    value = np.zeros(1, dtype=erfa.dt_eraLDBODY)
    value["bm"] = 1.0
    value["dl"] = 6e-6
    value["pv"]["p"] = [1.0, 0.0, 0.0]
    value["pv"]["v"] = [0.0, 0.0, 0.0]
    q_b = Quantity(value, body_unit)
    q_ob = np.array([0.0, 0.0, 1.0]) * u.AU
    sc = np.array([0.0, 0.0, 1.0])

    with _spy_name(erfa_helpers_module, "ldbody_unit") as ldbody_calls:
        result = erfa.ufunc.ldn(q_b, q_ob, sc)

    assert len(ldbody_calls) == 1, f"ldbody_unit call count {len(ldbody_calls)!r}"
    assert isinstance(result, Quantity)
    assert result.unit == u.dimensionless_unscaled


CHECKS = (
    check_registered_function_helpers,
    check_structured_unit_constructor_reaches_normalize_names,
    check_einsum_public_dispatch_chain,
    check_like_public_dispatch_chain,
    check_concatenate_public_dispatch_chain,
    check_incompatible_concatenate_reaches_get_err_str,
    check_iterable_helper_reaches_additional_numpy_callers,
    check_erfa_pv2p_reaches_check_structured_unit,
    check_erfa_aper_reaches_check_structured_unit,
    check_erfa_ldn_reaches_ldbody_unit,
)


def main():
    for check in CHECKS:
        check()
        print(f"PASS: {check.__name__}")


if __name__ == "__main__":
    main()
