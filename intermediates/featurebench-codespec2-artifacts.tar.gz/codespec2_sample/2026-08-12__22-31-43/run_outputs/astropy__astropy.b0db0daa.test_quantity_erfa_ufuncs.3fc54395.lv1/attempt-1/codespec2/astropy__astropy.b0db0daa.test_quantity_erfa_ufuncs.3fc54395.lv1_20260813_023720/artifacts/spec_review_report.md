# Spec Review Report

## Evidence Reviewed

- Task document and Interface Descriptions 1-2.
- `/agent-logs/codespec2/astropy__astropy.b0db0daa.test_quantity_erfa_ufuncs.3fc54395.lv1_20260813_023720/artifacts/semantic_ir.md` (full).
- `/agent-logs/codespec2/astropy__astropy.b0db0daa.test_quantity_erfa_ufuncs.3fc54395.lv1_20260813_023720/artifacts/arch_spec.py` (full).
- `/agent-logs/codespec2/astropy__astropy.b0db0daa.test_quantity_erfa_ufuncs.3fc54395.lv1_20260813_023720/artifacts/behavior_spec.py` (full).
- `/agent-logs/codespec2/astropy__astropy.b0db0daa.test_quantity_erfa_ufuncs.3fc54395.lv1_20260813_023720/artifacts/static_issues.md` and `static_analysis.md` (full).
- `/installed-agent/codespec2/review_skill.md` (full).
- Repository source: `astropy/units/structured.py`, `astropy/units/core.py`, `astropy/units/quantity.py`, `astropy/units/quantity_helper/function_helpers.py`, `astropy/units/quantity_helper/erfa.py`, `astropy/units/quantity_helper/converters.py`, `astropy/units/quantity_helper/helpers.py`.
- Repository tests: `astropy/units/tests/test_structured.py`, `astropy/units/tests/test_quantity_non_ufuncs.py`, `astropy/units/tests/test_units.py`.

## Rubric Scores

### Requirement coverage
- **Score:** 2/5
- **Seed/derived rubric:** Every atomic task requirement has a traceable R/G/C path and one or more executable observations.
- **Evidence:** R1 acceptance names `np.concatenate`, `np.choose`, `np.select`, `np.quantile`, and `np.nanmedian`, but only `np.concatenate` is observed. R3's direct `like_helper` return contract has no contract at all. R4 misses `StructuredUnit.to`, `.physical_type`, and `.to_string`, which are called by visible `test_structured.py` and are implied by the task's structured-conversion requirement.
- **Affected R/E/C IDs:** R1, R3, R4; E6-E10, E16, E23; C1-C13.

### Requirement fidelity
- **Score:** 3/5
- **Seed/derived rubric:** Tests assert the task-supported relation, not a guessed stronger behavior, a looser proxy, or an implementation detail.
- **Evidence:** Most unit/value assertions are exact. However `like_helper` and `einsum` are validated mainly through public outputs rather than their declared direct helper contracts, and `check_structured_unit` is validated only for `isinstance`-style rejection rather than structured-shape compatibility.
- **Affected R/E/C IDs:** R2, R3, R10, R11; E2-E5, E20-E23; C5-C10, C21-C24.

### Caller binding and architecture
- **Score:** 3/5
- **Seed/derived rubric:** Material CALL edges execute through the actual public/owning entry, caller-resolved dependency, downstream receiver, and observer.
- **Evidence:** Static-issue symbols are generally reached through public entries: `np.einsum` reaches `_as_quantities`, `StructuredUnit` reaches `_normalize_names`, `np.concatenate` reaches `_iterable_helper`, `erfa.ufunc.pv2p` reaches `check_structured_unit`, and `erfa.ufunc.ldn` reaches `ldbody_unit`. But `like_helper` is never observed as the registered helper identity, and the `get_err_str` error check does not observe the `_iterable_helper` layer on the same path.
- **Affected R/E/C IDs:** R1, R3, R9; E2, E7-E15, E23; C3-C4, C20, C25.

### Dataflow and lifecycle
- **Score:** 3/5
- **Seed/derived rubric:** Tests distinguish correct forwarding, ordering, representation, identity/copy, mutation, conversion, and cleanup from plausible wrong implementations.
- **Evidence:** Direct `_iterable_helper` checks verify tuple shape, common unit, original `out` identity, and ndarray-view sharing. Public `concatenate`/`einsum`/`like` checks verify result identity and values. Missing: extra kwargs forwarding (`axis`, `mode`, `overwrite_input`, `keepdims`) and other call-site dataflows (`choose`, `select`, `quantile`, `nanmedian`).
- **Affected R/E/C IDs:** R1, R2; E6-E10; C1-C8.

### Failure and compatibility
- **Score:** 2/5
- **Seed/derived rubric:** Invalid, partial, optional, and fallback paths use expected exception class and diagnostics.
- **Evidence:** Non-Quantity `out`, non-string `einsum`, invalid nested names, incompatible `concatenate`, and regular-quantity ERFA rejection are covered. Missing: structured-unit arithmetic failures (`su * su`, `"s,s" * su`), division behavior, `_as_quantities` propagation of `NotImplementedError`, and incompatible structured ERFA shape rejection for `dt_eraASTROM`.
- **Affected R/E/C IDs:** R7, R8, R10; E18-E22; C12, C16-C18, C21-C24.

### Static-issue closure strength
- **Score:** 3/5
- **Seed/derived rubric:** Every on-path static issue is closed by a runtime observation that executes the real caller path through the public entry.
- **Evidence:** No on-path issue is closed only by an import-boundary assertion. `_normalize_names` has a real constructor-path spy plus a supplemental import-boundary check. However the `get_err_str` error-path check reaches the final observer without spying the `_iterable_helper` middle layer, and ERFA static-issue closure exercises only one of several material helper families.
- **Affected R/E/C IDs:** R1, R5, R9, R10, R11; E9-E15, E20-E22; C11-C13, C20-C24.

### Repository-test alignment
- **Score:** 2/5
- **Seed/derived rubric:** Similar repository tests are examined for fixture shape, input dimensions, observer style, error semantics, lifecycle, and integration boundaries.
- **Evidence:** The generated specs cite many repository tests, but do not adapt several of their concrete angles: `TestStructuredUnitMethods.test_conversion`, `test_physical_type`, `TestStructuredUnitBasics.test_to_string/test_str/test_repr`; `test_choose`, `test_select`, `test_quantile`, `test_nanmedian`; `test_concatenate` with `axis=1` and `dtype="f4"`; and `TestStructuredUnitArithmatic.test_multiplication/test_division` failure cases.
- **Affected R/E/C IDs:** R1, R4, R7, R10, R11; C1-C4, C9-C17, C21-C24.

### Oracle strength
- **Score:** 3/5
- **Seed/derived rubric:** Assertions use exact values, fields, order, identity, cardinality, state, and diagnostics where evidence supports them.
- **Evidence:** Many checks assert exact units, numeric equality, dtype/shape, and object identity. But `ldbody_unit` checks equality while ignoring field names, and no check asserts `FUNCTION_HELPERS[np.ones_like] is function_helpers.like_helper` or `FUNCTION_HELPERS[np.einsum] is function_helpers.einsum`.
- **Affected R/E/C IDs:** R2, R3, R11; E2-E5, E20-E23; C5-C10, C23-C25.

## Findings

### Finding 1
- **Type:** `requirement_misread`
- **Affected IDs:** R4; E16; C11-C13
- **Static issue:** None
- **Repository source/test evidence:** `astropy/units/structured.py` defines no `to`, `physical_type`, or `to_string`; `_repr_latex_` and `__str__` call the missing `to_string` (lines 443-444, 491-492). Visible tests call these methods directly: `astropy/units/tests/test_structured.py::TestStructuredUnitBasics.test_to_string/test_str/test_repr` (lines 217-232), `TestStructuredUnitMethods.test_physical_type` (lines 318-323), and `test_conversion` (lines 350-381).
- **Precise gap:** The IR records these methods as "repository perspective, not hidden-task obligations" and the specs never observe them. A generated implementation passing both specs can still leave `StructuredUnit.to`, `.physical_type`, `.to_string`, `str(su)`, and `repr(su)` broken, failing visible repository tests and the task's structured-conversion requirement.
- **Concrete rework instruction:** Add R/G/C entries and behavior checks for `StructuredUnit.to` (structured dtype and field-name preservation, nested/tuple value conversion), `StructuredUnit.physical_type`, and `StructuredUnit.to_string`/`__str__`/`__repr__` using the exact fixtures from `test_structured.py`.

### Finding 2
- **Type:** `missing_requirement`
- **Affected IDs:** R1; E6-E10; C1-C4
- **Static issue:** `astropy/units/quantity_helper/function_helpers.py`: `_iterable_helper` used but not defined or imported
- **Repository source/test evidence:** `_iterable_helper` call sites are materially different: `concatenate` passes `axis` (function_helpers.py lines 488-500), `choose` passes `mode` and `out` (line 729), `select` passes only choices (line 735), `quantile` passes `out` and extra kwargs with a Quantity `q` (line 853), and `nanmedian` passes `axis`, `out`, `overwrite_input`, `keepdims` (line 867). Visible tests: `test_quantity_non_ufuncs.py::test_choose` (991), `test_select` (1002), `test_quantile` (1142), `test_nanmedian` (1260), and `test_concatenate` with `axis=1`/`dtype="f4"` (711-731).
- **Precise gap:** The specs test `_iterable_helper` only with two Quantity arrays and no extra kwargs, and test `np.concatenate` only with default axis and no dtype. A helper that drops or fails to forward `axis`, `mode`, `overwrite_input`, `keepdims`, or mishandles `quantile`'s Quantity `q`/positional `out` would pass every generated check.
- **Concrete rework instruction:** Add public-path checks for `np.choose`, `np.select`, `np.quantile`, and `np.nanmedian` using the repository fixtures, and add a `np.concatenate` check with `axis=1` and `dtype="f4"`. For `_iterable_helper` directly, assert that arbitrary kwargs are preserved in the returned `kwargs`.

### Finding 3
- **Type:** `weak_constraint`
- **Affected IDs:** R3, R12; E23; C9-C10, C25
- **Static issue:** None
- **Repository source/test evidence:** Interface Description 1 requires `function_helpers.like_helper` with a specific return tuple and `subok` extraction. The arch spec only spies `FUNCTION_HELPERS[np.ones_like]` and `FUNCTION_HELPERS[np.zeros_like]`; the behavior spec only asserts public outputs.
- **Precise gap:** No check imports or calls `function_helpers.like_helper` directly, and no check asserts `FUNCTION_HELPERS[np.ones_like] is function_helpers.like_helper` or `FUNCTION_HELPERS[np.zeros_like] is function_helpers.like_helper`. A different registered function that happens to preserve units would pass, while the declared interface symbol and its direct return contract remain unverified.
- **Concrete rework instruction:** Add a direct `function_helpers.like_helper` check for both `subok=True` and `subok=False`, asserting the exact `(args, kwargs, unit, None)` tuple and that `subok` is removed from kwargs. In the public dispatch chain, also spy or assert the registered helper identity.

### Finding 4
- **Type:** `weak_constraint`
- **Affected IDs:** R2, R8, R12; E2-E5; C5-C8, C25
- **Static issue:** `astropy/units/quantity_helper/function_helpers.py`: `_as_quantities` used but not defined or imported
- **Repository source/test evidence:** Interface Description 1 specifies `function_helpers.einsum` returns `(args, kwargs, unit, out)`. The arch check spies `FUNCTION_HELPERS[np.einsum]` and `_as_quantities` but not `function_helpers.einsum` identity; behavior checks public success and direct non-string failure only.
- **Precise gap:** A registered helper other than `function_helpers.einsum` could call `_as_quantities` and produce the same public result. The named helper's direct success return tuple and its use of `_quantity_out_as_array` for `out` are not observed.
- **Concrete rework instruction:** Add a direct `function_helpers.einsum("ij,jk->ik", a, b)` return-tuple check and a direct Quantity-`out` check, and assert `FUNCTION_HELPERS[np.einsum] is function_helpers.einsum` in the public dispatch chain.

### Finding 5
- **Type:** `weak_constraint`
- **Affected IDs:** R10, R11; E20-E22; C21-C24
- **Static issue:** `astropy/units/quantity_helper/erfa.py`: `check_structured_unit` and `ldbody_unit` used but not defined or imported
- **Repository source/test evidence:** `check_structured_unit` call sites include `dt_pv` helpers and the `dt_eraASTROM` helper `helper_aper` (erfa.py lines 166-264, 322). `ldbody_unit` call sites include `helper_ldn`, `helper_atciqn`, and `helper_aticqn` (lines 311-318, 435, 456). The task artifact name refers to `test_quantity_erfa_ufuncs`, whose missing visible file is imported by `astropy/coordinates/tests/test_geodetic_representations.py`.
- **Precise gap:** The specs validate `check_structured_unit` only through `erfa.ufunc.pv2p` with a non-structured Quantity and a valid two-field `dt_pv` unit. They never test `dt_eraASTROM`, nor an incompatible structured unit with the wrong number of fields, so an implementation that only checks `isinstance(unit, StructuredUnit)` would pass. `ldbody_unit` is checked by equality ignoring names, so incorrect field names/structure are not ruled out.
- **Concrete rework instruction:** Add a public or direct `erfa.ufunc.aper`/`check_structured_unit` check with a wrong-shape structured unit that must raise `UnitTypeError`, and a valid `astrom_unit` case. Add a direct `ldbody_unit().field_names` or structure assertion against `erfa.dt_eraLDBODY`, or exercise `erfa.ufunc.aticqn`/`erfa.ufunc.atciqn`.

### Finding 6
- **Type:** `weak_constraint`
- **Affected IDs:** R7; E18-E19; C16-C17
- **Static issue:** None
- **Repository source/test evidence:** `astropy/units/tests/test_structured.py::TestStructuredUnitArithmatic.test_multiplication` (lines 383-399) checks both successful unit/string multiplication and failures for `self.pv_unit * self.pv_unit` and `"s,s" * self.pv_unit`. `test_division` (lines 401-414) checks `su / u.s` and `su / "s"` plus failure cases. The behavior spec covers only multiplication success and array-like `__rmul__`.
- **Precise gap:** A wrong `__mul__`/`__rmul__` that returns a structured unit for incompatible structured*structured or invalid string-structured cases, or a regression in `__truediv__`, would pass all generated checks.
- **Concrete rework instruction:** Add behavior checks for `with pytest.raises(TypeError): su * su` and `"s,s" * su`, and add success checks for `su / u.s` and `su / "s"` preserving field names and field-wise units.

### Finding 7
- **Type:** `weak_constraint`
- **Affected IDs:** R1, R9; E9-E15; C20
- **Static issue:** `astropy/units/quantity_helper/function_helpers.py`: `_iterable_helper`; `astropy/units/core.py`: `get_err_str`
- **Repository source/test evidence:** The semantic IR path for C20 is `np.concatenate -> Quantity.__array_function__ -> concatenate -> _iterable_helper -> _quantities2arrays -> Quantity._to_own_unit -> UnitBase.get_converter -> _apply_equivalencies -> get_err_str`. The arch check `check_incompatible_concatenate_reaches_get_err_str` wraps only `core.get_err_str`.
- **Precise gap:** The error-path check reaches the final observer while bypassing `_iterable_helper` and `_quantities2arrays`, both on the same path and one of them itself an on-path static issue. The compatible-path check observes `_iterable_helper`, but not in this failure path.
- **Concrete rework instruction:** In the same incompatible `np.concatenate` check, spy `FUNCTION_HELPERS[np.concatenate]`, `function_helpers._iterable_helper`, and `function_helpers._quantities2arrays`, and assert each is called before `core.get_err_str` while the `UnitConversionError` is raised.

## Decision

`Decision: REWORK`

The generated specs close the static-issue symbols at a basic level and contain several strong exact-value checks, but they omit repository-visible `StructuredUnit` conversion/display methods and multiple `_iterable_helper` caller shapes. They also leave named helper identities/direct contracts and ERFA structured-shape validation under-constrained, and the `get_err_str` error-path check bypasses an on-path `_iterable_helper` delegation layer. These gaps would allow plausible incorrect implementations to pass while failing repository and hidden tests.
