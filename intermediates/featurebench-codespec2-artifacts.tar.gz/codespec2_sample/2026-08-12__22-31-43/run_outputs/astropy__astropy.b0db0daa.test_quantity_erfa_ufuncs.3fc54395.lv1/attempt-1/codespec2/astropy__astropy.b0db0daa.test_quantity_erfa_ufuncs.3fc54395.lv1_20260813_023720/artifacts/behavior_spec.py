"""Executable behavior spec for structured-unit and function-helper task.

This file compiles the L3 outcome/state/failure contracts from semantic_ir.md
into concrete assertions.  Each check starts from a public entry (or an
explicitly required owning method for operator contracts) and observes exact
return values, units, identity, memory sharing, and exception semantics.

The rework edition adds direct helper return-tuple contracts, every
acceptance-listed `_iterable_helper` caller shape, structured-unit conversion
and display methods, structured-unit arithmetic failures/division, and
wrong-shape ERFA `dt_eraASTROM` validation.
"""

from __future__ import annotations

import contextlib
import re

import numpy as np

import astropy.units as u
import erfa
from astropy.units import Quantity, StructuredUnit, Unit
from astropy.units.quantity_helper import erfa as erfa_helpers_module
from astropy.units.quantity_helper import function_helpers


@contextlib.contextmanager
def _assert_raises(exc_type, match=None):
    """Assert that the guarded block raises ``exc_type``."""
    try:
        yield
    except exc_type as exc:
        if match is not None and re.search(match, str(exc), re.DOTALL) is None:
            raise AssertionError(
                f"expected {exc_type.__name__} matching {match!r}; got {str(exc)!r}"
            ) from exc
    else:
        raise AssertionError(f"expected {exc_type.__name__!r}, but no exception was raised")


def _make_pv_quantity():
    """Create a structured pv Quantity compatible with erfa.dt_pv."""
    pv_unit = StructuredUnit((u.km, u.km / u.s), names=erfa.dt_pv)
    value = np.zeros(1, dtype=erfa.dt_pv)
    value["p"] = [1.0, 0.0, 0.0]
    value["v"] = [0.0, 1.0, 0.0]
    return Quantity(value, pv_unit)


def _make_ldbody_quantity():
    """Create a structured body Quantity compatible with erfa.dt_eraLDBODY."""
    body_unit = StructuredUnit(
        (u.Msun, u.rad**2 / 2, (u.AU, u.AU / u.day)), names=erfa.dt_eraLDBODY
    )
    value = np.zeros(1, dtype=erfa.dt_eraLDBODY)
    value["bm"] = 1.0
    value["dl"] = 6e-6
    value["pv"]["p"] = [1.0, 0.0, 0.0]
    value["pv"]["v"] = [0.0, 0.0, 0.0]
    return Quantity(value, body_unit)


def _make_astrom_quantity():
    """Create a zeroed structured astrom Quantity compatible with erfa.dt_eraASTROM."""
    astrom_unit = erfa_helpers_module.astrom_unit()
    value = np.zeros((), dtype=erfa.dt_eraASTROM)
    return Quantity(value, astrom_unit)


# Contracts: C1; R1.
# Repository guidance: Interface Description 1; no direct repository test for
#   _iterable_helper itself, but test_quantity_non_ufuncs.py test_concatenate
#   exercises it through np.concatenate.
# Perspective: exact direct-return contract: 4-tuple, converted arrays, common
#   unit, updated kwargs only when out is supplied, and original out object.
# Source path/symbol: astropy/units/quantity_helper/function_helpers._iterable_helper.
def check_iterable_helper_return_contract():
    a = [1, 2] * u.m
    b = [3, 4] * u.m

    result = function_helpers._iterable_helper(a, b)
    assert isinstance(result, tuple) and len(result) == 4
    arrays, kwargs, unit, out = result

    np.testing.assert_array_equal(arrays[0], [1, 2])
    np.testing.assert_array_equal(arrays[1], [3, 4])
    assert unit == u.m
    assert out is None
    assert kwargs == {}

    out_q = np.empty(4) * u.m
    result = function_helpers._iterable_helper(a, b, out=out_q)
    arrays, kwargs, unit, out = result

    np.testing.assert_array_equal(arrays[0], [1, 2])
    np.testing.assert_array_equal(arrays[1], [3, 4])
    assert unit == u.m
    assert out is out_q
    assert "out" in kwargs
    assert isinstance(kwargs["out"], np.ndarray)
    assert np.shares_memory(kwargs["out"], out_q)


# Contracts: C2; R1.
# Repository guidance: Interface Description 1; _quantity_out_as_array in
#   function_helpers.py is the same failure path.
# Perspective: a non-Quantity out must be rejected with NotImplementedError.
# Source path/symbol: astropy/units/quantity_helper/function_helpers._iterable_helper.
def check_iterable_helper_rejects_nonquantity_out():
    a = [1, 2] * u.m
    b = [3, 4] * u.m
    with _assert_raises(NotImplementedError):
        function_helpers._iterable_helper(a, b, out=np.empty(4))


# Contracts: C1, C26 (rework addition); R1.
# Repository guidance: function_helpers.py call sites at lines 488-500, 729,
#   735, 853, 867 show callers pass axis, mode, out, overwrite_input, keepdims,
#   dtype.  Direct _iterable_helper must preserve arbitrary extra kwargs.
# Perspective: a helper that drops kwargs would pass the no-kwargs check but
#   fail public callers such as np.concatenate(..., axis=1, dtype='f4').
# Source path/symbol: astropy/units/quantity_helper/function_helpers._iterable_helper.
def check_iterable_helper_forwards_extra_kwargs():
    a = [1, 2] * u.m
    b = [3, 4] * u.m

    arrays, kwargs, unit, out = function_helpers._iterable_helper(
        a, b, axis=1, dtype=np.dtype("f4")
    )

    assert "out" not in kwargs
    assert kwargs["axis"] == 1
    assert kwargs["dtype"] == np.dtype("f4")
    assert unit == u.m
    assert out is None
    np.testing.assert_array_equal(arrays[0], [1, 2])
    np.testing.assert_array_equal(arrays[1], [3, 4])


# Contracts: C3; R1, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_concatenate (lines 711-721).
# Perspective: public np.concatenate with two compatible Quantity inputs returns
#   a Quantity in the first input's unit with the concatenated values.
# Source path/symbol: numpy.concatenate -> Quantity.__array_function__ ->
#   function_helpers.concatenate -> _iterable_helper.
def check_concatenate_preserves_unit():
    q1 = [1, 2] * u.m
    q2 = [3, 4] * u.m
    result = np.concatenate([q1, q2])

    assert isinstance(result, Quantity)
    assert result.unit == u.m
    np.testing.assert_array_equal(result.value, np.concatenate([q1.value, q2.value]))


# Contracts: C3; R1, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_concatenate (lines 711-721) covers axis=1 and
#   dtype='f4'.  These are the exact kwargs-forwarding shapes missing previously.
# Perspective: np.concatenate must preserve the requested axis and dtype while
#   still returning a Quantity with the common unit.
# Source path/symbol: numpy.concatenate -> function_helpers.concatenate ->
#   _iterable_helper.
def check_concatenate_axis_and_dtype():
    q1 = np.arange(6.0).reshape(2, 3) * u.m
    q2 = np.arange(6.0, 12.0).reshape(2, 3) * u.m

    axis_result = np.concatenate([q1, q2], axis=1)
    assert isinstance(axis_result, Quantity)
    assert axis_result.unit == u.m
    assert axis_result.shape == (2, 6)
    np.testing.assert_array_equal(
        axis_result.value, np.concatenate([q1.value, q2.value], axis=1)
    )

    dtype_result = np.concatenate([q1, q2], dtype="f4")
    assert isinstance(dtype_result, Quantity)
    assert dtype_result.unit == u.m
    assert dtype_result.dtype == np.dtype("f4")
    np.testing.assert_array_equal(
        dtype_result.value, np.concatenate([q1.value, q2.value], dtype="f4")
    )


# Contracts: C4; R1, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_concatenate (lines 723-731).
# Perspective: when a Quantity out is supplied, the same object is returned and
#   its unit is updated to the result unit.
# Source path/symbol: np.concatenate -> _iterable_helper ->
#   Quantity._result_as_quantity.
def check_concatenate_quantity_out_identity_and_unit():
    q1 = [1, 2] * u.m
    q2 = [3, 4] * u.m
    out = np.empty(4) * u.dimensionless_unscaled

    result = np.concatenate([q1, q2], out=out)

    assert result is out
    assert out.unit == u.m
    np.testing.assert_array_equal(out.value, np.concatenate([q1.value, q2.value]))


# Contracts: C5; R2, R8, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_einsum (lines 1422-1424).
# Perspective: two-operand np.einsum multiplies the operand units and matches the
#   numpy numeric result on the underlying values.
# Source path/symbol: np.einsum -> Quantity.__array_function__ ->
#   function_helpers.einsum -> _as_quantities.
def check_einsum_multiplies_units():
    a = [[1, 2], [3, 4]] * u.m
    b = [[5, 6], [7, 8]] * u.s

    result = np.einsum("ij,jk->ik", a, b)

    assert isinstance(result, Quantity)
    assert result.unit == u.m * u.s
    np.testing.assert_allclose(
        result.value, np.einsum("ij,jk->ik", a.to_value(u.m), b.to_value(u.s))
    )


# Contracts: C6; R2, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_einsum (lines 1416-1418).
# Perspective: single-operand np.einsum with an ellipsis preserves the input
#   array and its unit.
# Source path/symbol: np.einsum -> Quantity.__array_function__ ->
#   function_helpers.einsum.
def check_einsum_single_operand_preserves_unit():
    q = np.arange(9.0).reshape(3, 3) * u.m
    result = np.einsum("...i", q)

    assert isinstance(result, Quantity)
    assert result.unit == u.m
    np.testing.assert_array_equal(result.value, q.value)
    assert result.shape == q.shape


# Contracts: C7; R2.
# Repository guidance: Interface Description 1; no local direct test for the
#   non-string mode.
# Perspective: the helper must reject a non-string first operand with ValueError.
# Source path/symbol: astropy/units/quantity_helper/function_helpers.einsum.
def check_einsum_rejects_nonstring_subscripts():
    q = [1, 2] * u.m
    with _assert_raises(ValueError):
        function_helpers.einsum(1, q)


# Contracts: C5, C28 (rework addition); R2, R8.
# Repository guidance: Interface Description 1 specifies `function_helpers.einsum`
#   returns `(args, kwargs, unit, out)`; public checks alone allow a different
#   registered helper to pass.  The direct helper must produce ndarray arguments
#   and the product unit, and must put a Quantity `out` into kwargs as an
#   ndarray view while returning the original Quantity as the fourth item.
# Source path/symbol: astropy/units/quantity_helper/function_helpers.einsum ->
#   _as_quantities -> _quantity_out_as_array.
def check_einsum_helper_direct_return_contract():
    a = [[1, 2], [3, 4]] * u.m
    b = [[5, 6], [7, 8]] * u.s

    args, kwargs, unit, out = function_helpers.einsum("ij,jk->ik", a, b)

    assert isinstance(args, tuple) and len(args) == 3
    assert args[0] == "ij,jk->ik"
    assert all(isinstance(arg, np.ndarray) for arg in args[1:])
    assert kwargs == {}
    assert unit == u.m * u.s
    assert out is None
    np.testing.assert_allclose(
        np.einsum(*args), np.einsum("ij,jk->ik", a.to_value(u.m), b.to_value(u.s))
    )

    out_q = np.empty((2, 2)) * u.dimensionless_unscaled
    args, kwargs, unit, out = function_helpers.einsum("ij,jk->ik", a, b, out=out_q)

    assert out is out_q
    assert unit == u.m * u.s
    assert "out" in kwargs
    assert isinstance(kwargs["out"], np.ndarray)
    assert np.shares_memory(kwargs["out"], out_q)
    np.testing.assert_allclose(
        np.einsum(*args, **kwargs),
        np.einsum("ij,jk->ik", a.to_value(u.m), b.to_value(u.s)),
    )


# Contracts: C8; R2, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_einsum (lines 1425-1428).
# Perspective: np.einsum with a Quantity out returns that same object and fills
#   it with the computed result.
# Source path/symbol: np.einsum -> function_helpers.einsum ->
#   _quantity_out_as_array -> Quantity._result_as_quantity.
def check_einsum_quantity_out_identity_and_unit():
    q1 = np.arange(9.0).reshape(3, 3) * u.m
    q2 = np.eye(3) / u.s
    o2 = np.einsum("ij,jk", q1, q2)
    o3 = 0 * o2

    result = np.einsum("ij,jk", q1, q2, out=o3)

    assert result is o3
    assert o3.unit == o2.unit
    np.testing.assert_allclose(o3.value, o2.value)


# Contracts: C9; R3, R12.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredQuantityFunctions.test_zeros_ones_like (lines 646-651).
# Perspective: zeros_like/ones_like preserve dtype, shape, and structured unit
#   by default.
# Source path/symbol: np.zeros_like/np.ones_like -> Quantity.__array_function__
#   -> function_helpers.like_helper.
def check_like_preserves_structured_unit():
    su = StructuredUnit((u.km, u.km / u.s), names=("p", "v"))
    value = np.array([(1.0, 0.25), (2.0, 0.5)], dtype=[("p", "f8"), ("v", "f8")])
    q = Quantity(value, su)

    for func in (np.zeros_like, np.ones_like):
        result = func(q)
        assert isinstance(result, Quantity)
        assert result.dtype == value.dtype
        assert result.shape == value.shape
        assert result.unit == su
        np.testing.assert_array_equal(result.value, func(value))


# Contracts: C10; R3, R12.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   TestQuantityNonUFuncs.test_empty_like shows the subok=False ndarray pattern.
# Perspective: subok=False must produce a plain ndarray, not a Quantity.
# Source path/symbol: np.zeros_like/np.ones_like -> function_helpers.like_helper.
def check_like_subok_false_returns_ndarray():
    q = [1.0, 2.0, 3.0] * u.m

    for func in (np.zeros_like, np.ones_like):
        result = func(q, subok=False)
        assert type(result) is np.ndarray
        np.testing.assert_array_equal(result, func(q.value))


# Contracts: C29 (rework addition); R3.
# Repository guidance: Interface Description 1 requires `like_helper` to extract
#   `subok`, remove it from kwargs, convert `a` to an ndarray view, and return
#   `(args, kwargs, unit, None)` with unit=a.unit for subok=True and None
#   otherwise.
# Perspective: a helper that only produces correct public outputs via a
#   different registered function would not satisfy this direct contract.
# Source path/symbol: astropy/units/quantity_helper/function_helpers.like_helper.
def check_like_helper_direct_return_contract():
    q = [1.0, 2.0, 3.0] * u.m

    args, kwargs, unit, out = function_helpers.like_helper(q)
    assert isinstance(args, tuple) and len(args) == 1
    assert isinstance(args[0], np.ndarray)
    assert np.shares_memory(args[0], q)
    assert kwargs == {}
    assert unit == u.m
    assert out is None

    args, kwargs, unit, out = function_helpers.like_helper(
        q, dtype=np.dtype("f4"), subok=True
    )
    assert "subok" not in kwargs
    assert kwargs.keys() == {"dtype"}
    assert kwargs["dtype"] == np.dtype("f4")
    assert unit == u.m
    assert out is None

    args, kwargs, unit, out = function_helpers.like_helper(q, subok=False)
    assert "subok" not in kwargs
    assert kwargs == {}
    assert unit is None
    assert out is None


# Contracts: C11; R4, R5.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitBasics.test_recursive_initialization (lines 71-95).
# Perspective: nested bare-name tuples are normalized to the documented
#   [upper, lower_tuple] field-name representation.
# Source path/symbol: astropy/units/structured.StructuredUnit.__new__ ->
#   structured._normalize_names.
def check_structured_unit_nested_name_normalization():
    su = StructuredUnit((("km", "km/s"), "yr"), names=(("p", "v"), "t"))

    assert su.field_names == (["pv", ("p", "v")], "t")
    assert su["pv"]["p"] == u.km
    assert su["pv"]["v"] == u.km / u.s
    assert su["t"] == u.yr


# Contracts: R4 (mapping, iteration, equality, si/cgs recursion); C11 field
#   names already anchor nested normalization.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitAsMapping (lines 252-291) and TestStructuredUnitMethods
#   test_si/test_cgs (lines 335-343).
# Perspective: structured units behave as ordered mappings, equality ignores
#   field names, and si/cgs recursively apply to each regular-unit leaf.
# Source path/symbol: astropy/units/structured.StructuredUnit.__getitem__,
#   keys/values/items/__iter__/__len__/__eq__/si/cgs.
def check_structured_unit_mapping_and_recursive_properties():
    su = StructuredUnit((u.km, u.km / u.s), names=("p", "v"))

    assert len(su) == 2
    assert tuple(su.keys()) == ("p", "v")
    assert list(su) == ["p", "v"]
    assert dict(su) == {"p": su["p"], "v": su["v"]}
    assert su["p"] == u.km
    assert su["v"] == u.km / u.s

    # Equality ignores names.
    renamed = StructuredUnit((u.km, u.km / u.s), names=("position", "velocity"))
    assert su == renamed

    si = su.si
    assert si["p"].scale == 1000
    assert si["v"].scale == 1000

    cgs = su.cgs
    assert cgs["p"].scale == 100000
    assert cgs["v"].scale == 100000


# Contracts: C12; R5.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitBasics.test_initialization_names_invalid_list_errors
#   (lines 127-141).
# Perspective: malformed nested name lists must raise ValueError with the
#   documented ``invalid entry <entry>`` diagnostic.
# Source path/symbol: astropy/units/structured.StructuredUnit.__new__ ->
#   structured._normalize_names.
def check_structured_unit_invalid_names_raise_valueerror():
    cases = (
        (("t", ["p", "v"]), "['p', 'v']"),
        (("t", ["pv", "p", "v"]), "['pv', 'p', 'v']"),
        (("t", ["pv", ["p", "v"]]), "['pv', ['p', 'v']]"),
        (("t", ()), "()"),
        (("t", ("p", None)), "None"),
        (("t", ["pv", ("p", "")]), "''"),
    )
    for names, invalid in cases:
        with _assert_raises(ValueError, match=re.escape(invalid)):
            StructuredUnit("yr,(AU,AU/day)", names)


# Contracts: C13; R5.
# Repository guidance: static issue structured._normalize_names; direct
#   importability is supplemental to C11/C12 path evidence.
# Perspective: the helper exists, is callable, and normalizes a simple nested
#   tuple as expected.
# Source path/symbol: astropy/units/structured._normalize_names.
def check_normalize_names_importable_and_callable():
    from astropy.units.structured import _normalize_names

    assert callable(_normalize_names)
    assert tuple(_normalize_names((("p", "v"), "t"))) == (["pv", ("p", "v")], "t")


# Contracts: C30 (rework addition); R4.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitMethods.test_physical_type (lines 318-323).
# Perspective: physical_type must be a structured object with the field-wise
#   physical types.  This was previously omitted but is directly called by the
#   visible structured-unit method tests.
# Source path/symbol: astropy/units/structured.StructuredUnit.physical_type.
def check_structured_unit_physical_type():
    pv_unit = StructuredUnit((u.km, u.km / u.s), names=("p", "v"))
    pv_pt = pv_unit.physical_type
    assert pv_pt == np.array(("length", "speed"), "O,O")[()]

    pv_t_unit = StructuredUnit((pv_unit, u.s), names=("pv", "t"))
    pv_t_pt = pv_t_unit.physical_type
    assert pv_t_pt == np.array((pv_pt, "time"), "O,O")[()]


# Contracts: C31 (rework addition); R4.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitMethods.test_conversion (lines 350-381).
# Perspective: StructuredUnit.to must convert a structured ndarray field-wise
#   and preserve the value dtype; nested tuple/list values must also work.
# Source path/symbol: astropy/units/structured.StructuredUnit.to.
def check_structured_unit_to_conversion():
    pv_unit = StructuredUnit((u.km, u.km / u.s), names=("p", "v"))
    pv = np.array([(1.0, 0.25), (2.0, 0.5)], dtype=[("p", "f8"), ("v", "f8")])

    result = pv_unit.to(("AU", "AU/day"), pv)
    assert isinstance(result, np.ndarray)
    assert result.dtype == pv.dtype
    np.testing.assert_allclose(result["p"], u.km.to(u.AU, pv["p"]))
    np.testing.assert_allclose(result["v"], (u.km / u.s).to(u.AU / u.day, pv["v"]))

    # Nested tuple value conversion.
    pv_t_unit = StructuredUnit((pv_unit, u.s), names=("pv", "t"))
    tuple_result = pv_t_unit.to((("AU", "AU/day"), "Myr"), ((1.0, 0.25), 10.0))
    assert tuple_result["pv"]["p"] == u.km.to(u.AU, 1.0)
    assert tuple_result["pv"]["v"] == (u.km / u.s).to(u.AU / u.day, 0.25)
    assert tuple_result["t"] == u.s.to(u.Myr, 10.0)


# Contracts: C32 (rework addition); R4.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitBasics.test_to_string/test_str/test_repr (lines 217-232).
# Perspective: to_string/str/repr are public display obligations and must match
#   the exact structured-unit serialization used by the repository tests.
# Source path/symbol: astropy/units/structured.StructuredUnit.to_string,
#   __str__, __repr__.
def check_structured_unit_to_string_str_repr():
    su = StructuredUnit((u.km, u.km / u.s))
    latex_str = r"$(\mathrm{km}, \mathrm{\frac{km}{s}})$"
    assert su.to_string(format="latex") == latex_str
    latex_inline_str = r"$(\mathrm{km}, \mathrm{km\,s^{-1}})$"
    assert su.to_string(format="latex_inline") == latex_inline_str

    su_nested = StructuredUnit(((u.km, u.km / u.s), u.yr))
    assert str(su_nested) == "((km, km / s), yr)"
    assert u.Unit(str(su_nested)) == su_nested
    assert repr(su_nested) == 'Unit("((km, km / s), yr)")'
    assert eval(repr(su_nested)) == su_nested


# Contracts: C14; R6.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredQuantity.test_initialization_by_shifting_to_unit
#   (lines 457-461).
# Perspective: value << StructuredUnit creates a Quantity with the same unit and,
#   for array values, shares memory when possible.
# Source path/symbol: astropy/units/structured.StructuredUnit.__rlshift__ ->
#   astropy.units.Quantity constructor.
def check_structured_unit_rlshift_creates_quantity():
    su = StructuredUnit((u.km, u.km / u.s), names=("p", "v"))
    value = np.array([(1.0, 0.25), (2.0, 0.5)], dtype=[("p", "f8"), ("v", "f8")])

    result = value << su

    assert isinstance(result, Quantity)
    assert result.unit == su
    np.testing.assert_array_equal(result.value, value)
    assert np.may_share_memory(result, value)


# Contracts: C15; R6.
# Repository guidance: Interface Description 2; no direct local test for the
#   failure-return branch.
# Perspective: a value that cannot be turned into a Quantity with the structured
#   unit must produce NotImplemented rather than leaking a constructor exception.
# Source path/symbol: astropy/units/structured.StructuredUnit.__rlshift__.
def check_structured_unit_rlshift_returns_notimplemented_on_failure():
    su = StructuredUnit((u.km, u.km / u.s), names=("p", "v"))
    assert su.__rlshift__(object()) is NotImplemented


# Contracts: C16; R7.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitArithmatic.test_multiplication (lines 383-399).
# Perspective: multiplication of a structured unit by a regular unit, from both
#   sides and via a string, applies the unit field-wise and preserves names.
# Source path/symbol: astropy/units/structured.StructuredUnit.__rmul__ and
#   StructuredUnit.__mul__.
def check_structured_unit_rmul_unit_like():
    su = StructuredUnit((u.m, u.s))
    left = u.kg * su
    right = su * u.kg
    from_string = "kg" * su

    assert isinstance(left, StructuredUnit)
    assert left.field_names == ("f0", "f1")
    assert left["f0"] == u.kg * u.m
    assert left["f1"] == u.kg * u.s
    assert right == left
    assert from_string == left


# Contracts: C17; R7.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredQuantity.test_initialization_by_multiplication_with_unit
#   (lines 447-455).
# Perspective: array-like * StructuredUnit returns a Quantity with the structured
#   unit and the original structured values.
# Source path/symbol: astropy/units/structured.StructuredUnit.__rmul__ ->
#   astropy.units.Quantity constructor.
def check_structured_unit_rmul_array_like():
    su = StructuredUnit((u.km, u.km / u.s), names=("p", "v"))
    values = np.array([(1.0, 0.5), (2.0, 1.0)], dtype=[("p", "f8"), ("v", "f8")])

    result = values * su

    assert isinstance(result, Quantity)
    assert result.unit == su
    np.testing.assert_array_equal(result.value, values)


# Contracts: C33 (rework addition); R7.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitArithmatic.test_multiplication (lines 393-399).
# Perspective: structured*structured and structured-string multiplication must
#   fail with TypeError, not produce a malformed StructuredUnit.
# Source path/symbol: astropy/units/structured.StructuredUnit.__mul__ and
#   StructuredUnit.__rmul__.
def check_structured_unit_multiplication_failures():
    su = StructuredUnit((u.m, u.s))
    with _assert_raises(TypeError):
        su * su
    with _assert_raises(TypeError):
        "s,s" * su


# Contracts: C34 (rework addition); R7.
# Repository guidance: astropy/units/tests/test_structured.py
#   TestStructuredUnitArithmatic.test_division (lines 401-414).
# Perspective: division by a regular unit/string applies field-wise and keeps
#   field names; invalid left-hand operands raise TypeError.
# Source path/symbol: astropy/units/structured.StructuredUnit.__truediv__,
#   __rtruediv__ (or Python operator fallback).
def check_structured_unit_division():
    su = StructuredUnit((u.m, u.s), names=("p", "v"))

    by_unit = su / u.s
    assert isinstance(by_unit, StructuredUnit)
    assert by_unit.field_names == ("p", "v")
    assert by_unit["p"] == u.m / u.s
    assert by_unit["v"] == u.s / u.s

    by_string = su / "s"
    assert by_string == by_unit

    with _assert_raises(TypeError):
        1.0 / su
    with _assert_raises(TypeError):
        u.s / su


# Contracts: C18; R8.
# Repository guidance: static issue function_helpers._as_quantities; supplemental
#   direct-helper check, with the full np.einsum path covered in arch_spec.py.
# Perspective: _as_quantities converts each positional argument to Quantity and
#   preserves existing units.
# Source path/symbol: astropy/units/quantity_helper/function_helpers._as_quantities.
def check_as_quantities_converts_multiple_arguments():
    result = function_helpers._as_quantities([1, 2], [3, 4] * u.m)

    assert isinstance(result, tuple)
    assert len(result) == 2
    assert all(isinstance(q, Quantity) for q in result)
    assert result[1].unit == u.m
    np.testing.assert_array_equal(result[0].value, [1, 2])
    np.testing.assert_array_equal(result[1].value, [3, 4])


# Contracts: C18; R8.
# Repository guidance: Interface Description 1/R8 says `_as_quantities` must
#   propagate NotImplementedError from `_as_quantity` for unconvertible args.
# Perspective: object() cannot be converted to Quantity and must surface as
#   NotImplementedError, not a leak of the underlying constructor exception.
# Source path/symbol: astropy/units/quantity_helper/function_helpers._as_quantities ->
#   function_helpers._as_quantity.
def check_as_quantities_propagates_notimplemented():
    with _assert_raises(NotImplementedError):
        function_helpers._as_quantities(object())


# Contracts: C35 (rework addition); R1.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   test_choose (991-1001).  The fixture is the np.choose docstring shape.
# Perspective: np.choose must convert both Quantity choices to the first choice's
#   unit and return a Quantity with that unit.
# Source path/symbol: np.choose -> Quantity.__array_function__ ->
#   function_helpers.choose -> _iterable_helper.
def check_choose_preserves_unit():
    a = np.array([0, 1]).reshape((2, 1, 1))
    q1 = np.array([1, 2, 3]).reshape((1, 3, 1)) * u.cm
    q2 = np.array([-1, -2, -3, -4, -5]).reshape((1, 1, 5)) * u.m

    result = np.choose(a, (q1, q2))

    assert isinstance(result, Quantity)
    assert result.unit == u.cm
    expected = np.choose(a, (q1.to_value(u.cm), q2.to_value(u.cm))) * u.cm
    np.testing.assert_array_equal(result.value, expected.value)


# Contracts: C36 (rework addition); R1.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   test_select (1002-1016).
# Perspective: np.select must convert choices/default to the selected common unit
#   and return a Quantity, while the condition list drives selection.
# Source path/symbol: np.select -> function_helpers.select -> _iterable_helper.
def check_select_preserves_unit():
    q = np.array([0.3, 0.7, 1.2]) * u.m

    result = np.select(
        [q < 0.55 * u.m, q > 1.0 * u.m], [q, q.to(u.cm)], default=-1.0 * u.km
    )

    assert isinstance(result, Quantity)
    assert result.unit == u.m
    expected = (
        np.select([q.value < 0.55, q.value > 1.0], [q.value, q.to_value(u.m)], default=-1000.0)
        * u.m
    )
    np.testing.assert_array_equal(result.value, expected.value)


# Contracts: C37 (rework addition); R1.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   test_quantile (1142-1150).
# Perspective: np.quantile must accept a Quantity q and preserve the input unit,
#   using q's value in the requested percentile unit.
# Source path/symbol: np.quantile -> function_helpers.quantile ->
#   _iterable_helper.
def check_quantile_preserves_unit():
    q = np.arange(6.0).reshape(2, 3) * u.m

    result = np.quantile(q, 50 * u.percent)

    assert isinstance(result, Quantity)
    assert result.unit == u.m
    expected = np.quantile(q.value, 0.5) * u.m
    np.testing.assert_array_equal(result.value, expected.value)


# Contracts: C38 (rework addition); R1.
# Repository guidance: astropy/units/tests/test_quantity_non_ufuncs.py
#   test_nanmedian_out (1260-1265).
# Perspective: np.nanmedian must preserve the input unit and return the supplied
#   Quantity out object, filling it with the computed median.
# Source path/symbol: np.nanmedian -> function_helpers.nanmedian ->
#   _iterable_helper -> Quantity._result_as_quantity.
def check_nanmedian_preserves_unit_and_out():
    data = [1.0, 2.0, np.nan, 3.0, 4.0] * u.km
    out = np.empty_like(data)

    result = np.nanmedian(data, out=out)

    assert result is out
    assert out.unit == u.km
    np.testing.assert_array_equal(out.value, np.nanmedian(data.value))


# Contracts: C19; R9.
# Repository guidance: astropy/units/tests/test_units.py test_convertible_exception2
#   (lines 339-340).
# Perspective: incompatible direct unit conversion raises UnitConversionError
#   (not NameError) and reports both physical types and the diagnostic phrase.
# Source path/symbol: astropy/units/core.UnitBase.to -> get_converter ->
#   _apply_equivalencies -> core.get_err_str.
def check_get_err_str_unit_conversion_failure():
    with _assert_raises(u.UnitConversionError, match="length.*time.*are not convertible"):
        u.m.to(u.s)


# Contracts: C20; R1, R9.
# Repository guidance: astropy/units/tests/test_units.py test_convertible_exception2
#   combined with test_quantity_non_ufuncs.py test_concatenate failure angle.
# Perspective: incompatible units entering np.concatenate must surface as
#   UnitConversionError with the same diagnostic, proving the helper path uses
#   core.get_err_str rather than a missing name.
# Source path/symbol: np.concatenate -> _iterable_helper -> _quantities2arrays ->
#   Quantity._to_own_unit -> UnitBase.get_converter -> core.get_err_str.
def check_incompatible_concatenate_unit_conversion_error():
    q1 = [1, 2] * u.m
    q2 = [1, 2] * u.s

    with _assert_raises(u.UnitConversionError, match="are not convertible"):
        np.concatenate([q1, q2])


# Contracts: C21; R10.
# Repository guidance: static issue erfa.check_structured_unit; ERFA quantity
#   ufunc angle named in the task (no local test file present).
# Perspective: a regular (non-structured) Quantity sent to erfa.ufunc.pv2p must
#   be rejected with UnitTypeError, not NameError/AttributeError.
# Source path/symbol: erfa.ufunc.pv2p -> converters_and_unit -> get_erfa_helpers
#   -> helper_pv2p -> erfa.check_structured_unit.
def check_erfa_check_structured_unit_rejects_regular_quantity():
    bad = [1.0, 2.0, 3.0] * u.km
    with _assert_raises(u.UnitTypeError):
        erfa.ufunc.pv2p(bad)


# Contracts: C22; R10.
# Repository guidance: static issue erfa.check_structured_unit; valid structured
#   dt_pv quantity path should be accepted.
# Perspective: a pv-compatible StructuredUnit accepted by erfa.ufunc.pv2p returns
#   a Quantity in the position field's unit.
# Source path/symbol: erfa.ufunc.pv2p -> helper_pv2p -> erfa.check_structured_unit.
def check_erfa_pv2p_accepts_structured_pv_unit():
    q_pv = _make_pv_quantity()
    result = erfa.ufunc.pv2p(q_pv)

    assert isinstance(result, Quantity)
    assert result.unit == q_pv.unit[0]
    assert result.shape == (1, 3)


# Contracts: C27 (rework addition); R10.
# Repository guidance: static issue erfa.check_structured_unit; erfa.py helper_aper
#   calls check_structured_unit(unit_astrom, "dt_eraASTROM") before indexing
#   field 7.  A two-field structured unit is the wrong shape for dt_eraASTROM.
# Perspective: check_structured_unit must inspect structured shape/dtype-name,
#   not just isinstance(unit, StructuredUnit).
# Source path/symbol: erfa.ufunc.aper -> helper_aper -> erfa.check_structured_unit.
def check_erfa_aper_rejects_wrong_shape_structured_unit():
    theta = 0.0 * u.rad
    bad_unit = StructuredUnit((u.rad, u.rad), names=("x", "y"))
    bad_value = np.zeros((), dtype=[("x", "f8"), ("y", "f8")])
    bad_q = Quantity(bad_value, bad_unit)

    with _assert_raises(u.UnitTypeError):
        erfa.ufunc.aper(theta, bad_q)


# Contracts: C39 (rework addition); R10.
# Repository guidance: erfa.py helper_aper (lines 322-333) and astrom_unit()
#   (lines 288-307) define the valid dt_eraASTROM structure.
# Perspective: a valid astrom_unit() Quantity passed to erfa.ufunc.aper is
#   accepted and returns a Quantity with the astrom structured unit.
# Source path/symbol: erfa.ufunc.aper -> helper_aper ->
#   erfa.check_structured_unit -> Quantity._result_as_quantity.
def check_erfa_aper_accepts_valid_astrom():
    theta = 0.0 * u.rad
    q_astrom = _make_astrom_quantity()
    astrom_unit = erfa_helpers_module.astrom_unit()

    result = erfa.ufunc.aper(theta, q_astrom)

    assert isinstance(result, Quantity)
    assert result.unit == astrom_unit


# Contracts: C23; R11.
# Repository guidance: astropy/units/tests/test_structured.py test_parsing
#   (lines 212-215).
# Perspective: ldbody_unit returns the documented structured unit (equality
#   ignores field names, matching StructuredUnit semantics).
# Source path/symbol: astropy/units/quantity_helper/erfa.ldbody_unit.
def check_ldbody_unit_returns_expected_structured_unit():
    result = erfa_helpers_module.ldbody_unit()
    expected = StructuredUnit((u.Msun, u.rad**2 / 2, (u.AU, u.AU / u.day)))

    assert isinstance(result, StructuredUnit)
    assert result == expected


# Contracts: C40 (rework addition); R11.
# Repository guidance: erfa.dt_eraLDBODY has fields bm, dl, pv(p,v).  Equality
#   alone cannot distinguish incorrect field names because StructuredUnit.__eq__
#   intentionally ignores them.  ldbody_unit must carry ERFA-compatible names.
# Perspective: assert the exact dtype-derived field_names and top-level keys.
# Source path/symbol: astropy/units/quantity_helper/erfa.ldbody_unit ->
#   astropy/units/structured.StructuredUnit.field_names/keys.
def check_ldbody_unit_field_names_match_erfa_dtype():
    result = erfa_helpers_module.ldbody_unit()

    assert result.field_names == ("bm", "dl", ["pv", ("p", "v")])
    assert result.keys() == ("bm", "dl", "pv")
    assert result["pv"]["p"] == u.AU
    assert result["pv"]["v"] == u.AU / u.day


# Contracts: C24; R11.
# Repository guidance: static issue erfa.ldbody_unit; public ERFA path angle.
# Perspective: public erfa.ufunc.ldn with a body Quantity compatible with
#   ldbody_unit returns a dimensionless Quantity and does not raise NameError.
# Source path/symbol: erfa.ufunc.ldn -> get_erfa_helpers -> helper_ldn ->
#   erfa.ldbody_unit.
def check_erfa_ldn_public_path_dimensionless():
    q_b = _make_ldbody_quantity()
    q_ob = np.array([0.0, 0.0, 1.0]) * u.AU
    sc = np.array([0.0, 0.0, 1.0])

    result = erfa.ufunc.ldn(q_b, q_ob, sc)

    assert isinstance(result, Quantity)
    assert result.unit == u.dimensionless_unscaled


CHECKS = (
    check_iterable_helper_return_contract,
    check_iterable_helper_rejects_nonquantity_out,
    check_iterable_helper_forwards_extra_kwargs,
    check_concatenate_preserves_unit,
    check_concatenate_axis_and_dtype,
    check_concatenate_quantity_out_identity_and_unit,
    check_einsum_multiplies_units,
    check_einsum_single_operand_preserves_unit,
    check_einsum_rejects_nonstring_subscripts,
    check_einsum_helper_direct_return_contract,
    check_einsum_quantity_out_identity_and_unit,
    check_like_preserves_structured_unit,
    check_like_subok_false_returns_ndarray,
    check_like_helper_direct_return_contract,
    check_structured_unit_nested_name_normalization,
    check_structured_unit_mapping_and_recursive_properties,
    check_structured_unit_invalid_names_raise_valueerror,
    check_normalize_names_importable_and_callable,
    check_structured_unit_physical_type,
    check_structured_unit_to_conversion,
    check_structured_unit_to_string_str_repr,
    check_structured_unit_rlshift_creates_quantity,
    check_structured_unit_rlshift_returns_notimplemented_on_failure,
    check_structured_unit_rmul_unit_like,
    check_structured_unit_rmul_array_like,
    check_structured_unit_multiplication_failures,
    check_structured_unit_division,
    check_as_quantities_converts_multiple_arguments,
    check_as_quantities_propagates_notimplemented,
    check_choose_preserves_unit,
    check_select_preserves_unit,
    check_quantile_preserves_unit,
    check_nanmedian_preserves_unit_and_out,
    check_get_err_str_unit_conversion_failure,
    check_incompatible_concatenate_unit_conversion_error,
    check_erfa_check_structured_unit_rejects_regular_quantity,
    check_erfa_pv2p_accepts_structured_pv_unit,
    check_erfa_aper_rejects_wrong_shape_structured_unit,
    check_erfa_aper_accepts_valid_astrom,
    check_ldbody_unit_returns_expected_structured_unit,
    check_ldbody_unit_field_names_match_erfa_dtype,
    check_erfa_ldn_public_path_dimensionless,
)


def main():
    for check in CHECKS:
        check()
        print(f"PASS: {check.__name__}")


if __name__ == "__main__":
    main()
