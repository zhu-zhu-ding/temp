# Semantic IR

IR = <R, G, C> for the task **Implement Structured Unit Operations and Quantity Function Helpers** in `/testbed`.

## L1. Requirement Obligations

### R1: `_iterable_helper` argument conversion and `out` handling
- **Type:** Interface / Dataflow / Failure
- **Statement:** `astropy.units.quantity_helper.function_helpers._iterable_helper(*args, **kwargs)` must pop an optional `out` keyword, require it to be a `Quantity` when provided (otherwise raise `NotImplementedError`), convert it to a plain `ndarray` view, convert all positional arguments to arrays in a common unit through `_quantities2arrays`, and return exactly `(arrays, kwargs, unit, out)` where `kwargs` contains the `out` ndarray view only when `out` was provided and `out` is the original `Quantity`.
- **Task Evidence:** Interface Description 1.
- **Acceptance:** Direct calls return a 4-tuple with converted arrays, updated kwargs, common unit, and original out; `np.concatenate`, `np.choose`, `np.select`, `np.quantile`, `np.nanmedian` continue to work with Quantity inputs and preserve units.
- **Repository Evidence:** `astropy/units/quantity_helper/function_helpers.py` call sites at lines 488-500, 729, 735, 853, 867; `_quantity_out_as_array` lines 262-270; `_quantities2arrays` lines 435-470; `Quantity.__array_function__` lines 1881-1935.
- **Uncertainty:** Whether kwargs always contains an `out` key when the caller passed `out=None`; exact placement of the helper definition in the module.

### R2: `einsum` helper with unit product
- **Type:** Interface / Dataflow / Failure
- **Statement:** `function_helpers.einsum(*operands, **kwargs)` must be decorated with `@function_helper`, accept only string-subscript mode, raise `ValueError` if the first operand is not a string, convert all remaining operands to `Quantity` objects, compute the result unit as the product of all operand units, handle `out` in the same `Quantity`-only way as `_iterable_helper`, and return `(args, kwargs, unit, out)` suitable for `Quantity.__array_function__`.
- **Task Evidence:** Interface Description 1.
- **Acceptance:** `np.einsum('ij,jk->ik', a, b)` returns a Quantity with unit `a.unit * b.unit`; `np.einsum('...i', q)` preserves unit; `np.einsum(..., out=o3)` returns `o3` with the result unit.
- **Repository Evidence:** `function_helpers.py` has no current `einsum` definition; `FunctionAssigner` registration lines 188-217; `Quantity.__array_function__` lines 1881-1935; visible tests `astropy/units/tests/test_quantity_non_ufuncs.py` lines 1415-1428.
- **Uncertainty:** Exact error-message text for non-string subscripts and for non-Quantity `out`.

### R3: `like_helper` for `ones_like` and `zeros_like`
- **Type:** Interface / Dataflow / Compatibility
- **Statement:** `function_helpers.like_helper(a, *args, **kwargs)` must be decorated with `@function_helper(helps={np.ones_like, np.zeros_like})`, extract `subok` (default `True`), set the result unit to `a.unit` when `subok` is true and `None` otherwise, convert `a` to an ndarray view, remove `subok` from kwargs, and return `(args, kwargs, unit, None)`.
- **Task Evidence:** Interface Description 1.
- **Acceptance:** `np.zeros_like(q)` and `np.ones_like(q)` return Quantity with the input unit for regular and structured quantities; with `subok=False` they return plain ndarray.
- **Repository Evidence:** Comments at `function_helpers.py` lines 246-254; visible tests `test_quantity_non_ufuncs.py` lines 341-348 and `test_structured.py` lines 639-651.
- **Uncertainty:** None material.

### R4: `StructuredUnit` construction, nested field names, and field access
- **Type:** Interface / State / Failure
- **Statement:** `StructuredUnit(units, names=None)` must construct structured units from nested unit tuples, strings, dtype-like `names`, other `StructuredUnit` names, and explicit nested name tuples/lists. Field names must be normalized so nested bare tuples become `[upper_name, (lower_names...)]`; lists already in `[upper_name, lower_tuple]` form are preserved. Field access (`su['f1']`), `field_names`, `keys`, `values`, `items`, `len`, iteration, equality ignoring names, and `si`/`cgs` recursion must behave as documented.
- **Task Evidence:** Interface Description 2 class doc; task statement "nested field access".
- **Acceptance:** Examples from the class doc and visible `TestStructuredUnitBasics`, `TestStructuredUnitAsMapping`, `TestStructuredUnitMethods`.
- **Repository Evidence:** `astropy/units/structured.py` `__new__` lines 131-195, field methods 197-228, `_recursively_apply` 230-249, `si`/`cgs` 287-294; tests `astropy/units/tests/test_structured.py` lines 49-232.
- **Uncertainty:** The class doc and visible tests imply additional methods (`physical_type`, `to_string`, `to`) that are currently absent from the repository; they are not separately declared in the Interface Description, so they are recorded as repository perspective, not hidden-task obligations.

### R5: `_normalize_names` helper
- **Type:** Dependency / Interface / Failure
- **Statement:** `astropy.units.structured._normalize_names(names)` must be defined and must normalize nested name tuples/lists. It must reject invalid entries with `ValueError` whose text contains `invalid entry <entry>`, including malformed lists and invalid leaf values.
- **Task Evidence:** Static issue `astropy/units/structured.py`: `_normalize_names` used but not defined or imported.
- **Acceptance:** `StructuredUnit(..., names=(('p','v'),'t')).field_names == (['pv',('p','v')], 't')`; invalid lists from `test_structured.py` lines 127-141 raise the expected `ValueError`.
- **Repository Evidence:** Call site `structured.py` line 145; valid examples in class doc; tests `test_structured.py` lines 71-141.
- **Uncertainty:** Exact recursive algorithm and whether it also normalizes dtype-derived names.

### R6: `StructuredUnit.__rlshift__`
- **Type:** Interface / Side-effect / Dataflow
- **Statement:** `StructuredUnit.__rlshift__(self, m)` must implement `m << self` by creating `Quantity(m, self, copy=False, subok=True)`. If creation fails, return `NotImplemented`.
- **Task Evidence:** Interface Description 2.
- **Acceptance:** `values << su` returns a structured Quantity with unit `su`, correct per-field values, and memory sharing when possible; invalid structures return `NotImplemented` or propagate an appropriate exception.
- **Repository Evidence:** `structured.py` lacks `__rlshift__`; `Quantity.__lshift__` is in `quantity.py` lines 1133-1139; visible tests `test_structured.py` lines 457-461, 527-548, 636-637.
- **Uncertainty:** Whether all exceptions are swallowed into `NotImplemented` or only `Exception`; exact copy semantics for non-array values.

### R7: `StructuredUnit.__rmul__` and required `__mul__`
- **Type:** Interface / Dataflow / Compatibility
- **Statement:** `StructuredUnit.__rmul__(self, other)` must implement `other * self`. For a string `other`, parse it as a unit with `parse_strict='silent'`; for `UnitBase`, return a new `StructuredUnit` whose fields are each multiplied by `other` (delegating to `StructuredUnit.__mul__`); for array-like `other`, return `Quantity(other, self)`; otherwise return `NotImplemented`. `StructuredUnit.__mul__` must exist and perform the commutative field-wise multiplication for `self * unit` and `self * str`.
- **Task Evidence:** Interface Description 2; task statement "multiplication/division operations".
- **Acceptance:** Visible arithmetic tests pass: `su * u.au`, `u.au * su`, `su * "au"`, `"AU" * su`, `values * su`; incompatible structured*structured and str-structured cases raise `TypeError` or return `NotImplemented`.
- **Repository Evidence:** `__truediv__` pattern at `structured.py` lines 471-481; tests `test_structured.py` lines 383-399 and 447-455.
- **Uncertainty:** `__mul__` is not listed as a separate interface but is required by the documented `__rmul__` delegation and visible tests.

### R8: `_as_quantities` helper
- **Type:** Dependency / Interface / Failure
- **Statement:** `astropy.units.quantity_helper.function_helpers._as_quantities(*args)` must be defined and must convert each positional argument to a `Quantity` using `_as_quantity`, returning a tuple of `Quantity` objects. It must propagate `NotImplementedError` from `_as_quantity` for unconvertible arguments.
- **Task Evidence:** Static issue `function_helpers.py`: `_as_quantities` used but not defined or imported; Interface Description 1 `einsum` requires converting all operands to Quantity.
- **Acceptance:** `_as_quantities(a, b)` returns `(Quantity, Quantity)`; `np.einsum` and existing helpers that call `_as_quantities` no longer raise `NameError`.
- **Repository Evidence:** `_as_quantity` at `function_helpers.py` lines 410-418; call sites at lines 326, 910, 928, 935, 942, 1048, 1095, 1154, 1433, 1445, 1515, 1623.
- **Uncertainty:** Behavior for a single argument (return 1-tuple vs scalar) is inferred from call-site unpacking and should be a tuple.

### R9: `get_err_str` helper in `core.py`
- **Type:** Dependency / Failure / Compatibility
- **Statement:** `astropy.units.core.get_err_str(unit)` must be defined and return a display string for a unit (including physical-type information) used by `UnitBase._apply_equivalencies` when constructing `UnitConversionError`. Without it, incompatible conversions raise `NameError` instead of the documented `UnitConversionError`.
- **Task Evidence:** Static issue `astropy/units/core.py`: `get_err_str` used but not defined or imported.
- **Acceptance:** `u.m.to(u.s)` raises `UnitConversionError` matching `length` and `time` and `are not convertible`; `np.concatenate([1*u.m, 1*u.s])` raises `UnitConversionError`, not `NameError`.
- **Repository Evidence:** Call sites `core.py` lines 520-523; `UnitBase.get_converter` lines 570-574; `_iterable_helper` path through `_quantities2arrays`/`Quantity._to_own_unit`; tests `astropy/units/tests/test_units.py` lines 334-341.
- **Uncertainty:** Exact string formatting (whether it includes quoted unit name, physical type, or both) must be inferred from existing test regexes.

### R10: `check_structured_unit` helper in ERFA quantity helpers
- **Type:** Dependency / Failure / Compatibility
- **Statement:** `astropy.units.quantity_helper.erfa.check_structured_unit(unit, dtype_name)` must be defined and must validate that `unit` is a `StructuredUnit` suitable for the named ERFA dtype (`dt_pv` or `dt_eraASTROM`). It should raise `UnitTypeError` for non-structured/incompatible units and otherwise return `None`, enabling ERFA ufunc helpers such as `pv2p`, `pv2s`, `pvm`, `pvu`, `pvup`, `s2xpv`, and `aper`.
- **Task Evidence:** Static issue `astropy/units/quantity_helper/erfa.py`: `check_structured_unit` used but not defined or imported.
- **Acceptance:** ERFA ufunc helpers that call `check_structured_unit` no longer raise `NameError`; valid structured quantities are accepted and invalid regular quantities raise `UnitTypeError`.
- **Repository Evidence:** Call sites `erfa.py` lines 167, 174, 194-195, 204, 254, 259, 264, 322; helper registration `erfa.py` lines 484-533; `UfuncHelpers` import path in `converters.py` lines 20-99.
- **Uncertainty:** The exact compatibility check (only `isinstance` vs field-count/dtype-name comparison) is not visible in the source.

### R11: `ldbody_unit` helper in ERFA quantity helpers
- **Type:** Dependency / Interface / Dataflow
- **Statement:** `astropy.units.quantity_helper.erfa.ldbody_unit()` must be defined and return a `StructuredUnit` equivalent to `Unit("Msun, 0.5rad^2, (au, au/day)")`, i.e. `StructuredUnit((u.Msun, u.rad**2 / 2, (u.AU, u.AU / u.day)))`, with field names from `erfa.dt_eraLDBODY` (or otherwise compatible field structure).
- **Task Evidence:** Static issue `erfa.py`: `ldbody_unit` used but not defined or imported.
- **Acceptance:** `helper_ldn`, `helper_aticqn`, and `helper_aticqn` no longer raise `NameError`; `ldbody_unit()` equals the structured unit asserted in `test_structured.py` lines 212-215.
- **Repository Evidence:** Call sites `erfa.py` lines 315, 435, 456; `erfa.dt_eraLDBODY` available from ERFA; test `test_structured.py` lines 212-215.
- **Uncertainty:** Exact field names are inferred from `erfa.dt_eraLDBODY` and the helper's use in `get_converter`.

### R12: NumPy array-function protocol registration
- **Type:** Compatibility / Interface
- **Statement:** Newly implemented helpers must be registered so that `np.einsum`, `np.ones_like`, and `np.zeros_like` dispatch through `Quantity.__array_function__`; existing `np.concatenate`, `np.choose`, `np.select`, `np.quantile`, `np.nanmedian` must continue to dispatch to helpers that call `_iterable_helper`.
- **Task Evidence:** Task statement "Maintain compatibility with NumPy's array function protocol".
- **Acceptance:** `np.einsum in FUNCTION_HELPERS`, `np.ones_like in FUNCTION_HELPERS`, `np.zeros_like in FUNCTION_HELPERS` after module import; public NumPy calls return Quantities with correct units.
- **Repository Evidence:** `FunctionAssigner` lines 188-217; `Quantity.__array_function__` lines 1881-1935; module import in `quantity_helper/__init__.py` lines 8-16.
- **Uncertainty:** None material beyond placement and import order.

## L2. Functional Design Graph

### N1: `np.einsum`, `np.ones_like`, `np.zeros_like` (public NumPy entries)
- **Kind:** External public entry
- **Repository Evidence:** `astropy/units/tests/test_quantity_non_ufuncs.py` lines 341-348, 1415-1428.

### N2: `Quantity.__array_function__`
- **Kind:** Dispatch boundary
- **Repository Evidence:** `astropy/units/quantity.py` lines 1837-1935.

### N3: `function_helpers.einsum`
- **Kind:** Function helper
- **Repository Evidence:** Required by Interface Description 1; missing in source.

### N4: `function_helpers._as_quantities`
- **Kind:** Helper
- **Repository Evidence:** Missing; call sites listed in R8.

### N5: `function_helpers._as_quantity`
- **Kind:** Helper
- **Repository Evidence:** `function_helpers.py` lines 410-418.

### N6: `function_helpers._iterable_helper`
- **Kind:** Function helper
- **Repository Evidence:** Required by Interface Description 1; call sites lines 488-500, 729, 735, 853, 867.

### N7: `function_helpers._quantities2arrays`
- **Kind:** Helper
- **Repository Evidence:** `function_helpers.py` lines 435-470.

### N8: `function_helpers._quantity_out_as_array`
- **Kind:** Helper
- **Repository Evidence:** `function_helpers.py` lines 262-270.

### N9: `Quantity._to_own_unit`
- **Kind:** State/data conversion
- **Repository Evidence:** `astropy/units/quantity.py` lines 1660-1710.

### N10: `UnitBase.get_converter`
- **Kind:** Conversion boundary
- **Repository Evidence:** `astropy/units/core.py` lines 525-589.

### N11: `UnitBase._apply_equivalencies`
- **Kind:** Error path
- **Repository Evidence:** `astropy/units/core.py` lines 477-523.

### N12: `core.get_err_str`
- **Kind:** Helper
- **Repository Evidence:** Missing; call sites `core.py` lines 520-523.

### N13: `StructuredUnit.__new__`
- **Kind:** Constructor/state
- **Repository Evidence:** `structured.py` lines 131-195.

### N14: `structured._normalize_names`
- **Kind:** Helper
- **Repository Evidence:** Missing; call site `structured.py` line 145.

### N15: `StructuredUnit.__rlshift__`
- **Kind:** Operator method
- **Repository Evidence:** Missing; required by Interface Description 2.

### N16: `StructuredUnit.__rmul__`
- **Kind:** Operator method
- **Repository Evidence:** Missing; required by Interface Description 2.

### N17: `StructuredUnit.__mul__`
- **Kind:** Operator method
- **Repository Evidence:** Missing; required by R7 and visible test `test_structured.py` line 385.

### N18: `Quantity` constructor
- **Kind:** Constructor
- **Repository Evidence:** `astropy/units/quantity.py` `Quantity` class.

### N19: ERFA ufunc public entries (`erfa.ufunc.pv2p`, `erfa.ufunc.pv2s`, `erfa.ufunc.ldn`, etc.)
- **Kind:** External public entry
- **Repository Evidence:** `erfa.py` registration lines 484-533; static issue file.

### N20: `erfa.get_erfa_helpers`
- **Kind:** Lazy module importer
- **Repository Evidence:** `erfa.py` lines 484-533.

### N21: `erfa.check_structured_unit`
- **Kind:** Helper
- **Repository Evidence:** Missing; call sites in R10.

### N22: `erfa.ldbody_unit`
- **Kind:** Helper
- **Repository Evidence:** Missing; call sites in R11.

### N23: `np.concatenate`
- **Kind:** External public entry
- **Repository Evidence:** `function_helpers.py` lines 482-501; tests `test_quantity_non_ufuncs.py` lines 710-734.

### N24: `function_helpers.concatenate`
- **Kind:** Function helper
- **Repository Evidence:** `function_helpers.py` lines 482-501.

### N25: `function_helpers.like_helper`
- **Kind:** Function helper
- **Repository Evidence:** Required by Interface Description 1; missing in source.

### N26: `Quantity._result_as_quantity`
- **Kind:** Result/state observer
- **Repository Evidence:** `quantity.py` lines 675-725.

### E1: N1 -> N2
- **Kind:** CALL
- **Condition:** NumPy function dispatch when any argument is a Quantity.
- **Transfer:** `function` is `np.einsum`, `np.ones_like`, or `np.zeros_like`.
- **Evidence:** `Quantity.__array_function__` lines 1837-1935.
- **Obligations:** R12.

### E2: N2 -> N3
- **Kind:** CALL
- **Condition:** `function is np.einsum` and `np.einsum in FUNCTION_HELPERS`.
- **Transfer:** `args` and `kwargs` forwarded to `einsum`.
- **Evidence:** `quantity.py` lines 1881-1885.
- **Obligations:** R2, R12.

### E3: N3 -> N4
- **Kind:** CALL
- **Condition:** `einsum` has at least one array operand.
- **Transfer:** Remaining operands (`operands[1:]`) passed to `_as_quantities`.
- **Evidence:** Interface Description 1 and R2/R8.
- **Obligations:** R2, R8.

### E4: N4 -> N5
- **Kind:** CALL
- **Condition:** Each argument processed by `_as_quantities`.
- **Transfer:** Each argument passed to `_as_quantity`.
- **Evidence:** R8; `_as_quantity` lines 410-418.
- **Obligations:** R8.

### E5: N3 -> N8
- **Kind:** CALL
- **Condition:** `out` is present in kwargs.
- **Transfer:** `out` converted from Quantity to ndarray view.
- **Evidence:** Interface Description 1 and `_quantity_out_as_array`.
- **Obligations:** R2.

### E6: N23 -> N2
- **Kind:** CALL
- **Condition:** `np.concatenate` called with a Quantity sequence.
- **Transfer:** Dispatches through `Quantity.__array_function__`.
- **Evidence:** tests `test_quantity_non_ufuncs.py` lines 710-734.
- **Obligations:** R1, R12.

### E7: N2 -> N24
- **Kind:** CALL
- **Condition:** `function is np.concatenate`.
- **Transfer:** `arrays` and kwargs forwarded to `concatenate` helper.
- **Evidence:** `quantity.py` lines 1881-1885.
- **Obligations:** R1.

### E8: N24 -> N6
- **Kind:** CALL
- **Condition:** Always in `concatenate` helper.
- **Transfer:** `*arrays`, `out`, `axis`, and kwargs forwarded to `_iterable_helper`.
- **Evidence:** `function_helpers.py` lines 484-501.
- **Obligations:** R1.

### E9: N6 -> N8
- **Kind:** CALL
- **Condition:** `out` provided.
- **Transfer:** `out` converted to ndarray view and inserted into kwargs.
- **Evidence:** `_quantity_out_as_array`; R1.
- **Obligations:** R1.

### E10: N6 -> N7
- **Kind:** CALL
- **Condition:** Always for positional args.
- **Transfer:** All positional args passed to `_quantities2arrays`.
- **Evidence:** R1; `_quantities2arrays` lines 435-470.
- **Obligations:** R1.

### E11: N7 -> N5
- **Kind:** CALL
- **Condition:** First and subsequent arguments converted.
- **Transfer:** `args[0]` and trial args passed to `_as_quantity`.
- **Evidence:** `_quantities2arrays` lines 441-457.
- **Obligations:** R1, R8.

### E12: N7 -> N9
- **Kind:** CALL
- **Condition:** More than one argument and a unit-bearing first argument selected.
- **Transfer:** Each argument converted to `q.unit` with `q._to_own_unit`.
- **Evidence:** `_quantities2arrays` lines 465-467.
- **Obligations:** R1, R9.

### E13: N9 -> N10
- **Kind:** CALL
- **Condition:** Argument has a `unit` attribute and conversion is not a no-op.
- **Transfer:** `value.to_value(unit)` or `Quantity(value).to_value(unit)`.
- **Evidence:** `Quantity._to_own_unit` lines 1682-1710.
- **Obligations:** R9.

### E14: N10 -> N11
- **Kind:** CALL
- **Condition:** Direct `_to` scaling fails and equivalencies are attempted.
- **Transfer:** `self`, `other`, and normalized equivalencies passed to `_apply_equivalencies`.
- **Evidence:** `core.py` lines 570-574.
- **Obligations:** R9.

### E15: N11 -> N12
- **Kind:** CALL
- **Condition:** No equivalency produced a converter.
- **Transfer:** `unit` and `other` passed to `get_err_str`.
- **Evidence:** `core.py` lines 520-523.
- **Obligations:** R9.

### E16: N13 -> N14
- **Kind:** CALL
- **Condition:** `names` is not a `StructuredUnit` or `np.dtype`.
- **Transfer:** `names` passed to `_normalize_names`.
- **Evidence:** `structured.py` lines 135-145.
- **Obligations:** R4, R5.

### E17: N15 -> N18
- **Kind:** CALL
- **Condition:** `value << unit` is attempted.
- **Transfer:** `m` and `self` passed to `Quantity(m, self, copy=False, subok=True)`.
- **Evidence:** Interface Description 2; `Quantity.__lshift__` lines 1133-1139.
- **Obligations:** R6.

### E18: N16 -> N17
- **Kind:** CALL
- **Condition:** `other` is `UnitBase` or a parsed unit string.
- **Transfer:** Delegates to `__mul__` for field-wise multiplication.
- **Evidence:** Interface Description 2; visible tests `test_structured.py` lines 383-399.
- **Obligations:** R7.

### E19: N16 -> N18
- **Kind:** CALL
- **Condition:** `other` is array-like.
- **Transfer:** `other` and `self` passed to `Quantity`.
- **Evidence:** Interface Description 2; visible test `test_structured.py` lines 447-455.
- **Obligations:** R7.

### E20: N19 -> N20
- **Kind:** CALL
- **Condition:** ERFA ufunc is looked up in `UFUNC_HELPERS` and module `erfa.ufunc` is not yet imported.
- **Transfer:** `UfuncHelpers.__missing__` calls `get_erfa_helpers`.
- **Evidence:** `erfa.py` lines 484-533; `converters.py` lines 64-99.
- **Obligations:** R10, R11.

### E21: N20 -> N21
- **Kind:** CALL
- **Condition:** ERFA helper containing `check_structured_unit` is invoked (e.g., `pv2p`, `pv2s`, `pvm`, `pvu`, `pvup`, `s2xpv`, `aper`).
- **Transfer:** `unit` and dtype-name string passed to `check_structured_unit`.
- **Evidence:** `erfa.py` call sites in R10.
- **Obligations:** R10.

### E22: N20 -> N22
- **Kind:** CALL
- **Condition:** `helper_ldn`, `helper_aticqn`, or `helper_aticqn` is invoked.
- **Transfer:** No arguments; return value used as `to_unit` in `get_converter`.
- **Evidence:** `erfa.py` lines 315, 435, 456.
- **Obligations:** R11.

### E23: N1 -> N2 -> N25
- **Kind:** CALL
- **Condition:** `function is np.ones_like` or `np.zeros_like`.
- **Transfer:** `a` and kwargs forwarded to `like_helper`.
- **Evidence:** Interface Description 1; `quantity.py` lines 1881-1885.
- **Obligations:** R3, R12.

### E24: N2 -> N26
- **Kind:** CALL
- **Condition:** Helper returned `unit` and result from NumPy is not `NotImplemented`.
- **Transfer:** `result`, `unit`, and `out` passed to `_result_as_quantity`.
- **Evidence:** `quantity.py` lines 1927-1935.
- **Obligations:** R1, R2, R3.

## L3. Verifiable Contracts

### C1: `_iterable_helper` returns converted arrays, kwargs, unit, and original out
- **Type:** Dataflow
- **Subject:** `function_helpers._iterable_helper`
- **Relation:** `RETURN_VALUE`
- **Expected:** For `a = [1,2]*u.m` and `b = [3,4]*u.m`, `_iterable_helper(a,b)` returns `((array([1,2]), array([3,4])), {}, u.m, None)`; with `out = np.empty(4)*u.m`, kwargs contains an ndarray-view `out` and the fourth return item is the original `out`.
- **Evidence:** Interface Description 1; `_quantity_out_as_array`; `_quantities2arrays`.
- **Observe:** `RETURN_VALUE`
- **Target:** `astropy.units.quantity_helper.function_helpers._iterable_helper`
- **Obligations:** R1.
- **Graph:** N6, N7, N8; E9, E10.

### C2: `_iterable_helper` rejects non-Quantity `out`
- **Type:** Failure
- **Subject:** `function_helpers._iterable_helper`
- **Relation:** `EXCEPTION`
- **Expected:** `_iterable_helper(a, out=np.empty(4))` raises `NotImplementedError`.
- **Evidence:** Interface Description 1; `_quantity_out_as_array` lines 262-270.
- **Observe:** `EXCEPTION`
- **Target:** `function_helpers._iterable_helper`
- **Obligations:** R1.
- **Graph:** N6, N8; E9.

### C3: `np.concatenate` dispatches through `_iterable_helper` and preserves units
- **Type:** Compatibility/Dataflow
- **Subject:** `np.concatenate`
- **Relation:** `RETURN_VALUE`
- **Expected:** `np.concatenate([q1, q2])` returns a Quantity with unit `q1.unit` and values equal to `np.concatenate([q1.value, q2.to_value(q1.unit)])`.
- **Evidence:** Visible tests `test_quantity_non_ufuncs.py` lines 710-731.
- **Observe:** `RETURN_VALUE`
- **Target:** `numpy.concatenate` with Quantity inputs
- **Obligations:** R1, R12.
- **Graph:** N23, N2, N24, N6; E6, E7, E8.

### C4: `np.concatenate` with Quantity `out` returns the same object and sets unit
- **Type:** Side-effect/State
- **Subject:** `np.concatenate`
- **Relation:** `RETURN_VALUE` / `SIDE_EFFECT`
- **Expected:** With `out = np.empty((4,3)) * u.dimensionless_unscaled`, `result = np.concatenate([q1,q2], out=out)` returns `out` (`result is out`) and `out.unit == q1.unit`.
- **Evidence:** Visible test `test_quantity_non_ufuncs.py` lines 723-731; `Quantity._result_as_quantity` lines 717-725.
- **Observe:** `RETURN_VALUE` and `SIDE_EFFECT`
- **Target:** `numpy.concatenate` with Quantity inputs
- **Obligations:** R1, R12.
- **Graph:** N6, N8, N26; E9, E24.

### C5: `np.einsum` multiplies operand units
- **Type:** Dataflow
- **Subject:** `np.einsum`
- **Relation:** `RETURN_VALUE`
- **Expected:** For `a = [[1,2],[3,4]] * u.m` and `b = [[5,6],[7,8]] * u.s`, `np.einsum('ij,jk->ik', a, b)` returns a Quantity with unit `u.m * u.s` and numeric result equal to `np.einsum('ij,jk->ik', a.value, b.value)`.
- **Evidence:** Interface Description 1; visible test `test_quantity_non_ufuncs.py` lines 1422-1424.
- **Observe:** `RETURN_VALUE`
- **Target:** `numpy.einsum` with Quantity inputs
- **Obligations:** R2, R8, R12.
- **Graph:** N1, N2, N3, N4; E1, E2, E3.

### C6: `np.einsum` single-operand unit preservation
- **Type:** Dataflow
- **Subject:** `np.einsum`
- **Relation:** `RETURN_VALUE`
- **Expected:** `np.einsum('...i', q1)` returns a Quantity equal to `q1` with the same unit.
- **Evidence:** Visible test `test_quantity_non_ufuncs.py` lines 1416-1418.
- **Observe:** `RETURN_VALUE`
- **Target:** `numpy.einsum`
- **Obligations:** R2, R12.
- **Graph:** N1, N2, N3; E1, E2.

### C7: `np.einsum` rejects non-string subscripts
- **Type:** Failure
- **Subject:** `function_helpers.einsum`
- **Relation:** `EXCEPTION`
- **Expected:** `einsum(1, q)` or `np.einsum` in an unsupported mode raises `ValueError` (not a TypeError/AttributeError).
- **Evidence:** Interface Description 1.
- **Observe:** `EXCEPTION`
- **Target:** `function_helpers.einsum` direct call or `numpy.einsum` dispatch
- **Obligations:** R2.
- **Graph:** N3.

### C8: `np.einsum` with Quantity `out`
- **Type:** Side-effect/State
- **Subject:** `np.einsum`
- **Relation:** `RETURN_VALUE`
- **Expected:** With `o3 = 0 * o2`, `result = np.einsum('ij,jk', q1, q2, out=o3)` returns `o3` and sets `o3` to the computed result unit.
- **Evidence:** Visible test `test_quantity_non_ufuncs.py` lines 1425-1428.
- **Observe:** `RETURN_VALUE` and `SIDE_EFFECT`
- **Target:** `numpy.einsum`
- **Obligations:** R2, R12.
- **Graph:** N1, N2, N3, N8, N26; E2, E5, E24.

### C9: `np.zeros_like`/`np.ones_like` preserve structured units by default
- **Type:** Dataflow/Compatibility
- **Subject:** `np.zeros_like` and `np.ones_like`
- **Relation:** `RETURN_VALUE`
- **Expected:** `func(q_pv)` returns a Quantity with dtype `q_pv.dtype`, unit `q_pv.unit`, shape `q_pv.shape`, and values equal to `func(q_pv.value) << q_pv.unit`.
- **Evidence:** Visible test `test_structured.py` lines 645-651; Interface Description 1.
- **Observe:** `RETURN_VALUE`
- **Target:** `numpy.zeros_like` / `numpy.ones_like`
- **Obligations:** R3, R12.
- **Graph:** N1, N2, N25; E23.

### C10: `like_helper` with `subok=False` returns dimensionless ndarray
- **Type:** Dataflow
- **Subject:** `function_helpers.like_helper`
- **Relation:** `RETURN_VALUE`
- **Expected:** `np.zeros_like(q, subok=False)` and `np.ones_like(q, subok=False)` return plain `np.ndarray`, not Quantity.
- **Evidence:** Interface Description 1; visible pattern in `test_quantity_non_ufuncs.py` line 338.
- **Observe:** `RETURN_VALUE`
- **Target:** `numpy.zeros_like` / `numpy.ones_like`
- **Obligations:** R3, R12.
- **Graph:** N1, N2, N25; E23.

### C11: `StructuredUnit` nested name normalization
- **Type:** State/Dataflow
- **Subject:** `StructuredUnit.__new__`
- **Relation:** `FIELD_READ`
- **Expected:** `StructuredUnit((("km","km/s"),"yr"), names=(("p","v"),"t")).field_names == (["pv",("p","v")],"t")`.
- **Evidence:** Interface Description 2; visible test `test_structured.py` lines 71-95.
- **Observe:** `FIELD_READ`
- **Target:** `astropy.units.StructuredUnit`
- **Obligations:** R4, R5.
- **Graph:** N13, N14; E16.

### C12: `StructuredUnit` invalid nested names raise `ValueError`
- **Type:** Failure
- **Subject:** `StructuredUnit.__new__` / `_normalize_names`
- **Relation:** `EXCEPTION`
- **Expected:** Invalid name lists (`("t", ["p","v"])`, `("t", ["pv","p","v"])`, `("t", ())`, `("t", ("p", None))`, etc.) raise `ValueError` whose message contains `invalid entry <entry>`.
- **Evidence:** Visible tests `test_structured.py` lines 127-141; R5.
- **Observe:** `EXCEPTION`
- **Target:** `astropy.units.StructuredUnit`
- **Obligations:** R5.
- **Graph:** N13, N14; E16.

### C13: `_normalize_names` is importable and callable
- **Type:** Interface
- **Subject:** `astropy.units.structured._normalize_names`
- **Relation:** `IMPORT_BOUNDARY`
- **Expected:** `from astropy.units.structured import _normalize_names` succeeds and the symbol is callable.
- **Evidence:** Static issue `structured.py`; R5.
- **Observe:** `IMPORT_BOUNDARY`
- **Target:** `astropy.units.structured`
- **Obligations:** R5.
- **Graph:** N14.

### C14: `StructuredUnit.__rlshift__` creates a Quantity
- **Type:** Dataflow/Side-effect
- **Subject:** `StructuredUnit.__rlshift__`
- **Relation:** `RETURN_VALUE`
- **Expected:** For `su = StructuredUnit((u.km, u.km/u.s), names=('p','v'))` and a compatible structured value, `value << su` returns a Quantity with unit `su`, and for arrays shares memory when possible (`np.may_share_memory(result, value)`).
- **Evidence:** Interface Description 2; visible tests `test_structured.py` lines 457-461.
- **Observe:** `RETURN_VALUE` and `SIDE_EFFECT`
- **Target:** `astropy.units.StructuredUnit.__rlshift__`
- **Obligations:** R6.
- **Graph:** N15, N18; E17.

### C15: `StructuredUnit.__rlshift__` returns `NotImplemented` on failure
- **Type:** Failure
- **Subject:** `StructuredUnit.__rlshift__`
- **Relation:** `RETURN_VALUE`
- **Expected:** For a value that cannot be converted to a Quantity with this unit, `su.__rlshift__(value)` returns `NotImplemented`.
- **Evidence:** Interface Description 2.
- **Observe:** `RETURN_VALUE`
- **Target:** `StructuredUnit.__rlshift__`
- **Obligations:** R6.
- **Graph:** N15, N18; E17.

### C16: `StructuredUnit.__rmul__` with unit-like `other`
- **Type:** Dataflow
- **Subject:** `StructuredUnit.__rmul__`
- **Relation:** `RETURN_VALUE`
- **Expected:** `u.kg * StructuredUnit((u.m,u.s))` returns a `StructuredUnit` with field units `(u.kg*u.m, u.kg*u.s)` and preserved field names.
- **Evidence:** Interface Description 2; visible tests `test_structured.py` lines 383-399.
- **Observe:** `RETURN_VALUE`
- **Target:** `StructuredUnit.__rmul__`
- **Obligations:** R7.
- **Graph:** N16, N17; E18.

### C17: `StructuredUnit.__rmul__` with array-like `other`
- **Type:** Dataflow
- **Subject:** `StructuredUnit.__rmul__`
- **Relation:** `RETURN_VALUE`
- **Expected:** `values * su` returns a `Quantity` whose unit is `su` and whose values are the structured input values.
- **Evidence:** Interface Description 2; visible tests `test_structured.py` lines 447-455.
- **Observe:** `RETURN_VALUE`
- **Target:** `StructuredUnit.__rmul__`
- **Obligations:** R7.
- **Graph:** N16, N18; E19.

### C18: `_as_quantities` converts multiple arguments
- **Type:** Interface/Dataflow
- **Subject:** `function_helpers._as_quantities`
- **Relation:** `RETURN_VALUE`
- **Expected:** `_as_quantities([1,2], [3,4]*u.m)` returns a tuple of two `Quantity` objects, with the second preserving `u.m`.
- **Evidence:** R8; `_as_quantity` lines 410-418.
- **Observe:** `RETURN_VALUE`
- **Target:** `function_helpers._as_quantities`
- **Obligations:** R8.
- **Graph:** N4, N5; E4.

### C19: `get_err_str` is defined and used in conversion failures
- **Type:** Failure/Compatibility
- **Subject:** `astropy.units.core.get_err_str`
- **Relation:** `EXCEPTION`
- **Expected:** `u.m.to(u.s)` raises `UnitConversionError` (not `NameError`) with a message matching `length`, `time`, and `are not convertible`.
- **Evidence:** Static issue `core.py`; visible tests `test_units.py` lines 334-341.
- **Observe:** `EXCEPTION`
- **Target:** `astropy.units.UnitBase.to` / `core._apply_equivalencies`
- **Obligations:** R9.
- **Graph:** N10, N11, N12; E14, E15.

### C20: incompatible `np.concatenate` exercises `get_err_str`
- **Type:** Failure/Compatibility
- **Subject:** `np.concatenate`
- **Relation:** `EXCEPTION`
- **Expected:** `np.concatenate([[1]*u.m, [1]*u.s])` raises `UnitConversionError` (not `NameError`) with `are not convertible`.
- **Evidence:** R9; path N6 -> N7 -> N9 -> N10 -> N11 -> N12.
- **Observe:** `EXCEPTION`
- **Target:** `numpy.concatenate`
- **Obligations:** R1, R9.
- **Graph:** N23, N2, N24, N6, N7, N9, N10, N11, N12; E6-E15.

### C21: `check_structured_unit` is defined and rejects non-structured ERFA input
- **Type:** Failure/Compatibility
- **Subject:** `astropy.units.quantity_helper.erfa.check_structured_unit`
- **Relation:** `EXCEPTION`
- **Expected:** Through a public ERFA ufunc path such as `erfa.ufunc.pv2p` with a non-structured Quantity, the call raises `UnitTypeError`, not `NameError` or `AttributeError`.
- **Evidence:** Static issue `erfa.py`; R10.
- **Observe:** `EXCEPTION`
- **Target:** `erfa.ufunc.pv2p` (or another R10-listed ufunc)
- **Obligations:** R10.
- **Graph:** N19, N20, N21; E20, E21.

### C22: `check_structured_unit` accepts a structured pv unit
- **Type:** Dataflow/Compatibility
- **Subject:** `astropy.units.quantity_helper.erfa.check_structured_unit`
- **Relation:** `RETURN_VALUE`
- **Expected:** A structured Quantity with a pv-compatible `StructuredUnit` passed to `erfa.ufunc.pv2p` returns a Quantity with unit `unit[0]` and does not raise `NameError`/`AttributeError`.
- **Evidence:** `erfa.py` `helper_pv2p` lines 166-168; R10.
- **Observe:** `RETURN_VALUE`
- **Target:** `erfa.ufunc.pv2p`
- **Obligations:** R10.
- **Graph:** N19, N20, N21; E20, E21.

### C23: `ldbody_unit` is defined and returns the expected structured unit
- **Type:** Interface/Dataflow
- **Subject:** `astropy.units.quantity_helper.erfa.ldbody_unit`
- **Relation:** `RETURN_VALUE`
- **Expected:** `ldbody_unit() == StructuredUnit((u.Msun, Unit(u.rad**2/2), (u.AU, u.AU/u.day)))`.
- **Evidence:** Static issue `erfa.py`; visible test `test_structured.py` lines 212-215.
- **Observe:** `RETURN_VALUE`
- **Target:** `erfa.ldbody_unit`
- **Obligations:** R11.
- **Graph:** N22.

### C24: `ldbody_unit` is reached through the public `erfa.ufunc.ldn` path
- **Type:** Compatibility/Dataflow
- **Subject:** `erfa.ufunc.ldn`
- **Relation:** `RETURN_VALUE`
- **Expected:** Calling `erfa.ufunc.ldn` with a Quantity whose unit is compatible with `ldbody_unit()` returns a dimensionless Quantity and does not raise `NameError`.
- **Evidence:** `erfa.py` lines 311-318; R11.
- **Observe:** `RETURN_VALUE`
- **Target:** `erfa.ufunc.ldn`
- **Obligations:** R11.
- **Graph:** N19, N20, N22; E20, E22.

### C25: array-function protocol registration
- **Type:** Compatibility/Interface
- **Subject:** `FUNCTION_HELPERS`
- **Relation:** `STATE_READ`
- **Expected:** After importing `astropy.units.quantity_helper.function_helpers`, `np.einsum`, `np.ones_like`, and `np.zeros_like` are keys in `FUNCTION_HELPERS`.
- **Evidence:** R12; `FunctionAssigner` lines 188-217.
- **Observe:** `STATE_READ`
- **Target:** `astropy.units.quantity_helper.function_helpers.FUNCTION_HELPERS`
- **Obligations:** R2, R3, R12.
- **Graph:** N3, N25; E2, E23.

## Traceability Notes

- Static issue `_normalize_names`: closed by chain `StructuredUnit.__new__ (N13) -> _normalize_names (N14)`; contracts C11-C13.
- Static issue `_iterable_helper`: closed as the declared interface `N6`; contracts C1-C4 and C20.
- Static issue `_as_quantities`: closed by chain `np.einsum (N1) -> Quantity.__array_function__ (N2) -> einsum (N3) -> _as_quantities (N4) -> _as_quantity (N5)`; contract C18 and C5.
- Static issue `get_err_str`: closed by chain `np.concatenate (N23) -> Quantity.__array_function__ (N2) -> concatenate (N24) -> _iterable_helper (N6) -> _quantities2arrays (N7) -> Quantity._to_own_unit (N9) -> UnitBase.get_converter (N10) -> _apply_equivalencies (N11) -> get_err_str (N12)`; contracts C19-C20.
- Static issue `check_structured_unit`: closed by chain `erfa.ufunc.* (N19) -> get_erfa_helpers (N20) -> ERFA helper -> check_structured_unit (N21)`; contracts C21-C22.
- Static issue `ldbody_unit`: closed by chain `erfa.ufunc.ldn (N19) -> get_erfa_helpers (N20) -> helper_ldn -> ldbody_unit (N22)`; contracts C23-C24.
