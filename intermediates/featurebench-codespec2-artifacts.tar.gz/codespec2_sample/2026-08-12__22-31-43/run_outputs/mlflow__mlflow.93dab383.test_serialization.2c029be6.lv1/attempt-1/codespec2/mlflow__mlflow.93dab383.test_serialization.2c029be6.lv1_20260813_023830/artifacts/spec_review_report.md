# Spec Review Report

## Evidence Reviewed

- Primary oracle: task document and Interface Description 1 (`scorer`) and Interface Description 2 (`AssessmentSourceType`).
- Semantic IR: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260813_023830/artifacts/semantic_ir.md` (all 870 lines).
- Architecture spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260813_023830/artifacts/arch_spec.py` (all 322 lines).
- Behavior spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260813_023830/artifacts/behavior_spec.py` (all 902 lines).
- Static issue and static analysis artifacts.
- Persistent review skill: `/installed-agent/codespec2/review_skill.md`.
- Repository source inspected: `mlflow/entities/assessment_source.py`, `mlflow/genai/scorers/base.py`, `mlflow/genai/scorers/scorer_utils.py`, `mlflow/genai/scorers/registry.py`, `mlflow/genai/scorers/aggregation.py`, `mlflow/genai/scorers/validation.py`, package `__init__` modules.
- Repository tests inspected: `tests/entities/test_assessment_source.py`, `tests/genai/scorers/test_scorer.py`, `tests/genai/scorers/test_scorer_description.py`, `tests/genai/scorers/test_scorer_utils.py`, `tests/genai/scorers/test_registered_scorers_scheduling.py`, `tests/genai/scorers/test_scorer_CRUD.py`, `tests/genai/scorers/test_validation.py`, and `tests/genai/evaluate/test_utils.py`.

## Rubric Scores

| Rubric | Score | Evidence | Affected R/E/C IDs |
|---|---:|---|---|
| Requirement coverage (seed) | PARTIAL | Every IR C number has at least one generated check, but R17 reconstruction sub-behaviors (control flow, loops, defaults, stdlib, indentation) and R13 class-based evaluation have no executable observation. | R13, R17, C24, C25, C26 |
| Requirement fidelity (seed) | FAIL | `check_C31_invalid_aggregation_string_rejected` asserts eager decorator-time `MlflowException`, but the IR marks C31 uncertain, `validate_aggregations` is not wired into `scorer`, and repository aggregation code raises `ValueError` later. This overstates the supported requirement. | R19, C31, E26, N17 |
| Caller binding and architecture (seed) | PARTIAL | Static-issue closure checks C22, C22b, and C23 execute the real caller path through `model_validate`/`scorer`/`model_dump`, which is strong. However lifecycle C27/C28 never observe the backend store call, so server-boundary binding is not proven. | R18, C22, C22b, C23, C27, C28, E20 |
| Dataflow and lifecycle (seed) | FAIL | C27/C28 verify local status and immutability but do not assert `register`/`start`/`update`/`stop` call the store with the required name, experiment_id, sample_rate, and filter_string. C18/C23 also do not observe that `model_dump` populates `_cached_dump` and subsequent dumps use it. | R14, R18, C18, C23, C27, C28 |
| Failure and compatibility (seed) | PARTIAL | Assessment-source invalid/deprecated cases are exact. Deserialization blocked-path checks assert the right exception and snippet markers, but no spy proves `recreate_function`/`exec` was not invoked on the malicious source. | R4, R15, C5, C20, C21 |
| Static-issue closure strength (seed) | PASS | SI-1 (`extract_function_body`), SI-2 (`recreate_function`), and SI-3 (`scorer`) are all closed by runtime observer checks that enter through the real public path rather than import-boundary assertions. | SI-1, SI-2, SI-3, C22, C22b, C23 |
| Chain integrity (seed) | PASS | The multi-layer deserialization path is split across C22 (lower `recreate_function`) and C22b (module `scorer`); neither check bypasses a lower layer to reach its observer. | C22, C22b, E14, E15, E17 |
| Repository-test alignment (derived) | FAIL | `test_scorer_utils.py` tests bare `Feedback` availability and full `Trace` construction, but generated C25 imports `Feedback`/`Trace` before use. `test_registered_scorers_scheduling.py` asserts exact store call kwargs, but generated lifecycle checks never assert the mocks were called. Class-scorer evaluation from `test_scorer.py` is absent. | R13, R17, R18, C25, C27, C28 |
| Oracle strength (derived) | PARTIAL | Many value and type assertions are exact, but security no-exec, backend call kwargs, serialization cache state, and reconstruction control-flow/default cases remain unobserved. | R14, R15, R17, R18 |

## Findings

### F1: Blocked deserialization checks do not prove the malicious source is never executed

- **Type**: `weak_constraint`
- **Affected IDs**: R15, C20, C21, E19; Static Issue 2 (`recreate_function` is on-path in the allowed branch)
- **Evidence**:
  - Behavior spec `check_C20_decorator_deserialization_blocked_outside_databricks` (lines 441-472) and `check_C21_decorator_deserialization_blocked_remote_databricks` (lines 475-506) patch only `is_in_databricks_runtime` and `is_databricks_uri`, then assert `MlflowException` message text and snippet markers.
  - Neither check patches `recreate_function`, `builtins.exec`, or any other execution primitive, and neither asserts that the execution primitive was not called.
  - The IR R15 acceptance explicitly states "neither path calls `exec`/`recreate_function`."
- **Gap**: A plausible incorrect implementation could execute the serialized call source first and then raise the same `MlflowException` with the same message. The current observations would still pass.
- **Rework**: In both blocked-path checks, patch `mlflow.genai.scorers.base.recreate_function` (or `builtins.exec`) with a spy/mock, invoke `Scorer.model_validate(serialized)` under the blocked runtime conditions, and assert the spy was not called and no exception other than the expected `MlflowException` was raised.

### F2: Lifecycle checks observe local state but not the backend store call

- **Type**: `weak_constraint`
- **Affected IDs**: R18, C27, C28, E20
- **Evidence**:
  - Behavior spec `check_C27_status_follows_registration_and_sampling` (lines 616-664) and `check_C28_lifecycle_methods_are_immutable` (lines 667-751) patch `DatabricksStore.add_registered_scorer` and `DatabricksStore.update_registered_scorer` as `mock_add`/`mock_update`, but contain no `assert_called_once_with` or call-kwargs assertions.
  - Repository test `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` does assert these calls: `test_scorer_register` lines 57-61, `test_scorer_start` lines 108-112, `test_scorer_update` lines 160-164, `test_scorer_stop` lines 184-185, and `test_scorer_register_with_experiment_id` lines 194-197.
  - IR R18 states lifecycle methods must "update server sampling configuration through the scorer store."
- **Gap**: An implementation that creates a new local scorer with the correct `_sampling_config` but never calls the store would pass the generated lifecycle checks.
- **Rework**: Add `mock_add.assert_called_once_with(name=..., scorer=ANY, sample_rate=0.0, filter_string=None, experiment_id=...)` for `register`, and `mock_update.assert_called_once_with(name=..., scorer=ANY, sample_rate=..., filter_string=..., experiment_id=...)` for `start`/`update`/`stop`, matching the repository test oracle.

### F3: Dynamic function reconstruction coverage is materially incomplete

- **Type**: `missing_requirement`
- **Affected IDs**: R17, C24, C25, C26
- **Evidence**:
  - IR R17 acceptance states "functions with loops/control flow/defaults also execute correctly" and cites the full `/testbed/tests/genai/scorers/test_scorer_utils.py` suite.
  - Repository tests `test_function_with_control_flow` (line 27), `test_function_with_loop` (line 44), `test_function_with_multiple_parameters` (line 61), `test_function_with_defaults` (`test_signature_with_defaults`, line 173), `test_complex_signature` (line 186), `test_indentation_handling` (line 337), `test_function_using_builtin_modules` (line 263), and `test_function_with_import_error_at_runtime` (line 363) have no generated-spec counterpart.
  - Behavior spec only has `check_C24_recreate_function_basic` (simple arithmetic), two MLflow-namespace checks, and three failure cases.
- **Gap**: A reconstruction implementation that handles only a flat one-line body and simple signatures would pass the generated specs while failing the repository-backed R17 acceptance.
- **Rework**: Add parameterized reconstruction checks for at least: control flow (`if`/`else`), loops, defaults, whitespace in signatures, complex signatures, standard-library imports, runtime import errors, and indentation handling. Use the exact source/signature/call assertions from the cited repository tests.

### F4: MLflow namespace check weakens the repository's bare-name injection requirement

- **Type**: `weak_constraint`
- **Affected IDs**: R17, C25
- **Evidence**:
  - Behavior spec `check_C25_mlflow_namespace_available` (lines 529-548) starts the reconstructed source with `from mlflow.entities import Feedback, Trace` before using `Feedback`, and only asserts the pre-built trace's `trace_id` in the type-hint check.
  - Repository test `/testbed/tests/genai/scorers/test_scorer_utils.py::test_mlflow_imports_available` (lines 281-323) deliberately starts with bare `feedback = Feedback(value=True, rationale="test")` before any import, then constructs `TraceInfo`, `TraceData`, `TraceLocation`, `MlflowExperimentLocation`, and `Trace` inside the recreated function.
- **Gap**: A reconstruction implementation that does not inject `Feedback` into the execution globals but permits explicit imports would pass the generated C25 check while failing the repository-backed namespace requirement.
- **Rework**: Change `check_C25_mlflow_namespace_available` to use bare `Feedback` at the top of the source (before imports) and to construct the full `Trace` object graph inside the recreated function, exactly as `test_mlflow_imports_available` does.

### F5: Eager invalid-aggregation validation is promoted to a mandatory spec without repository or IR support

- **Type**: `requirement_misread`
- **Affected IDs**: R19, C31, E26, N17
- **Evidence**:
  - Behavior spec `check_C31_invalid_aggregation_string_rejected` (lines 825-843) asserts `scorer(aggregations=["bogus"])(bad)` raises `MlflowException` with "Invalid aggregation" at decorator creation.
  - IR C31 is marked uncertain: "No repository test currently exercises invalid aggregation at `scorer` creation, and `validate_aggregations` is not currently wired into `scorer`."
  - Repository code `mlflow/genai/scorers/validation.py::validate_aggregations` exists but is not called by `scorer`; `mlflow/genai/scorers/aggregation.py::_compute_aggregations` raises `ValueError` later for unknown string aggregations.
- **Gap**: The generated spec mandates an eager creation-time `MlflowException` that is not established by the task, the IR, or the repository. A valid implementation that accepts the scorer and fails later during aggregation would be incorrectly rejected.
- **Rework**: Either remove C31 or re-anchor it to the real aggregation path (`compute_aggregated_metrics`/`_compute_aggregations`) with the repository-supported exception semantics. If eager creation-time validation is intended, add task evidence and wire `validate_aggregations` into `scorer`; do not leave it as an unsupported mandatory check.

### F6: Class-based scorer usability for evaluation is not observed

- **Type**: `missing_requirement`
- **Affected IDs**: R13
- **Evidence**:
  - IR R13 acceptance states "Class-based scorers can run in evaluation but `register`/`start`/`update`/`stop` raise."
  - Repository test `/testbed/tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` (line 62) parameterizes both `AlwaysYesScorer(name="always_yes")` and `scorer(always_yes)`, proving the class-based path is part of the supported surface.
  - Generated behavior C19 defines a `DirectScorer` only to test serialization rejection, and C29 defines `CustomScorer` only to test registration rejection. No check runs a class-based scorer through `Scorer.run` or evaluation.
- **Gap**: A framework change that breaks `Scorer.run` for class-based scorers while leaving decorator scorers working would pass both generated specs.
- **Rework**: Add a check that defines a direct `Scorer` subclass with `__call__`, invokes `.run(...)` (or a minimal evaluation path), and asserts the returned value matches the class implementation.

### F7: `model_dump` cache population and reuse are not observed

- **Type**: `weak_constraint`
- **Affected IDs**: R14, C18, C23
- **Evidence**:
  - IR R14 states `model_dump` "must be cached in `_cached_dump`."
  - Behavior `check_C18_model_dump_serialized_fields` checks only returned keys/values; arch `check_C23_serialization_reaches_extract_function_body` checks one extraction call on the first dump.
  - No generated check asserts `scorer._cached_dump is dump` after `model_dump`, or that a second `model_dump` does not call `extract_function_body` again.
  - Repository `test_register_with_custom_name_updates_serialization` depends on cache behavior when it updates `_cached_dump["name"]`.
- **Gap**: An implementation that recomputes `model_dump` every call and never populates `_cached_dump` would pass the current generated checks, but would violate R14 and could break cache-sensitive caller behavior.
- **Rework**: In C18 or C23, assert the returned dict is assigned to `_cached_dump`, then call `model_dump` a second time under a spy on `extract_function_body` and assert the spy is not called again and the cached object is returned.

## Decision

`Decision: REWORK`

The generated specs are strong on import boundaries, assessment-source validation, decorator metadata, static-issue caller traces, and basic return-type handling. They are not yet sufficient because several security, lifecycle-boundary, reconstruction, namespace, and compatibility contracts are either unobserved or asserted too strongly.
