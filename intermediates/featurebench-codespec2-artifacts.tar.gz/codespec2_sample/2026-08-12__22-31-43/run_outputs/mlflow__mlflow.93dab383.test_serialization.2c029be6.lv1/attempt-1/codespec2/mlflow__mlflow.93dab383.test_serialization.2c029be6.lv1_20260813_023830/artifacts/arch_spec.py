"""Architecture specification for Assessment Source Management and Custom Scorer Framework.

This file compiles the path, import-boundary, and caller-binding contracts from
the typed semantic IR.  It is intentionally executable with plain ``python``.

Contract coverage in this file:
    C3, C6, C9, C10, C12, C22, C22b, C23
Static-issue closure:
    SI-1 ``extract_function_body`` -> check_C23
    SI-2 ``recreate_function``       -> check_C22
    SI-3 module-level ``scorer``     -> check_C22b
"""

from __future__ import annotations

import sys
import traceback
from unittest.mock import patch

import mlflow.genai.scorers.base as scorer_base
import mlflow.genai.scorers.scorer_utils as scorer_utils
from mlflow.entities import AssessmentSource
from mlflow.entities.assessment_source import AssessmentSourceType
from mlflow.genai.scorers.base import Scorer, ScorerKind, SerializedScorer


def _pass(name: str) -> None:
    print(f"PASS: {name}")


class _SymbolCallSpy:
    """Patch a scorer_utils symbol at both its defining module and any base-module alias.

    The production module may import ``extract_function_body``/``recreate_function`` either at
    module import time (creating a ``mlflow.genai.scorers.base`` alias) or locally inside the
    method body (as the repository's skinny implementation does).  Patching both candidate
    bindings keeps the check focused on the real caller-to-helper path without depending on
    which import style the implementation chooses.
    """

    def __init__(self, symbol_name: str):
        self.symbol_name = symbol_name
        self.calls: list[tuple[tuple, dict]] = []
        self._patches = []

    def _make_spy(self, original):
        calls = self.calls

        def spy(*args, **kwargs):
            calls.append((args, kwargs))
            return original(*args, **kwargs)

        return spy

    def __enter__(self) -> "_SymbolCallSpy":
        utils_original = getattr(scorer_utils, self.symbol_name)
        self._patches.append(
            patch.object(scorer_utils, self.symbol_name, new=self._make_spy(utils_original))
        )
        if hasattr(scorer_base, self.symbol_name):
            base_original = getattr(scorer_base, self.symbol_name)
            self._patches.append(
                patch.object(scorer_base, self.symbol_name, new=self._make_spy(base_original))
            )
        for item in self._patches:
            item.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        for item in reversed(self._patches):
            item.stop()
        return False


# ---------------------------------------------------------------------------
# Public import boundaries
# ---------------------------------------------------------------------------

def check_C09_assessment_source_import_boundary() -> None:
    """C9/R7. Both implementation-module and public entity imports bind one class.

    Guidance: /testbed/tests/entities/test_assessment_source.py
    (test_assessment_source_properties) imports the implementation module while
    public consumers import through ``mlflow.entities``.  Perspective: export
    surface identity.  Path/symbol: ``mlflow.entities.assessment_source.AssessmentSourceType``
    and ``mlflow.entities.AssessmentSourceType``.
    """
    from mlflow.entities.assessment_source import AssessmentSourceType as ImplAST
    from mlflow.entities import AssessmentSourceType as PublicAST

    assert ImplAST is PublicAST, "assessment source type import paths resolve to different objects"
    _pass("check_C09_assessment_source_import_boundary")


def check_C10_scorer_import_boundaries() -> None:
    """C10/R8. ``scorer`` must bind identically from base, package, and top-level GenAI.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py line 6 imports
    ``from mlflow.genai import Scorer, scorer``; test_scorer_CRUD.py line 4 imports
    ``from mlflow.genai.scorers import Scorer, scorer``; test_validation.py line 9 imports
    ``from mlflow.genai.scorers.base import Scorer, scorer``.  Perspective: public
    surface identity across three namespaces.  Path/symbol:
    ``mlflow.genai.scorers.base.scorer``.
    """
    from mlflow.genai.scorers.base import scorer as base_scorer
    from mlflow.genai.scorers import scorer as package_scorer
    from mlflow.genai import scorer as top_scorer

    assert base_scorer is package_scorer, "base and package scorer bindings differ"
    assert package_scorer is top_scorer, "package and top-level scorer bindings differ"
    _pass("check_C10_scorer_import_boundaries")


# ---------------------------------------------------------------------------
# Real caller-to-helper delegation chains
# ---------------------------------------------------------------------------

def check_C03_standardize_delegates_to_constructor_and_str() -> None:
    """C3/R2/R6. ``_standardize`` is documented to create a temporary instance and
    obtain its string representation.  Observe the real path through ``__str__``.

    Guidance: Interface Description 2 ``_standardize`` docstring; no dedicated
    repository test drives this delegation directly, but
    /testbed/tests/entities/test_assessment_source.py
    (test_assessment_source_case_insensitivity) exercises the observable result.
    Perspective: representation-layer delegation.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSourceType._standardize``.
    """
    original_str = AssessmentSourceType.__str__
    calls = []

    def spy_str(instance):
        calls.append(instance)
        return original_str(instance)

    with patch.object(AssessmentSourceType, "__str__", new=spy_str):
        result = AssessmentSourceType._standardize("human")

    assert result == "HUMAN", f"standardize result was {result!r}"
    assert len(calls) == 1, f"__str__ was not reached exactly once through _standardize: {calls}"
    assert str(calls[0]) == "HUMAN", f"temporary instance string was {str(calls[0])!r}"
    _pass("check_C03_standardize_delegates_to_constructor_and_str")


def check_C06_assessment_source_delegation() -> None:
    """C6/R2/R3/R5. Constructing ``AssessmentSource`` must reach
    ``AssessmentSourceType._standardize`` through ``__post_init__`` and normalize the field.

    Guidance: /testbed/tests/entities/test_assessment_source.py
    (test_assessment_source_case_insensitivity, test_assessment_source_properties).
    Perspective: dataclass normalization dataflow.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSource.__post_init__`` ->
    ``AssessmentSourceType._standardize``.
    """
    original_standardize = AssessmentSourceType._standardize
    calls = []

    def spy_standardize(source_type):
        calls.append(source_type)
        return original_standardize(source_type)

    with patch.object(AssessmentSourceType, "_standardize", new=spy_standardize):
        source = AssessmentSource(source_type="llm_judge", source_id="gpt-4")

    assert calls == ["llm_judge"], f"_standardize did not receive original source_type: {calls}"
    assert source.source_type == "LLM_JUDGE", f"normalized source_type was {source.source_type!r}"
    assert source.source_id == "gpt-4", f"source_id was {source.source_id!r}"
    _pass("check_C06_assessment_source_delegation")


def check_C12_scorer_run_filters_keyword_arguments() -> None:
    """C12/R10. ``Scorer.run`` builds the four-key input map and passes only the keys
    accepted by the wrapped scorer signature.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_custom_scorer_allow_none_return, test_scorer_on_genai_evaluate) exercise
    ``Scorer.run`` through decorated scorers.  Perspective: runtime argument trace.
    Path/symbol: ``mlflow.genai.scorers.base.Scorer.run`` -> ``Scorer.__call__``.
    """
    from mlflow.genai.scorers import scorer

    seen_keys = []

    @scorer
    def outputs_only(outputs):
        # ``locals()`` at function entry contains only the parameters that run() passed.
        seen_keys.append(set(locals().keys()))
        return bool(outputs)

    outputs_only.run(
        inputs={"question": "q"},
        outputs="answer",
        expectations={"expected_response": "answer"},
        trace=None,
    )

    assert seen_keys == [{"outputs"}], f"run passed unexpected keyword set: {seen_keys}"
    _pass("check_C12_scorer_run_filters_keyword_arguments")


# ---------------------------------------------------------------------------
# Static-issue closure checks: real caller path through the public entry
# ---------------------------------------------------------------------------

def check_C23_serialization_reaches_extract_function_body() -> None:
    """C23/R14/R16 and Static Issue 1 (``extract_function_body`` used but not defined/imported).

    Chain: public entry ``scorer`` -> ``Scorer.model_dump`` ->
    ``Scorer._extract_source_code_info`` -> caller-resolved ``extract_function_body``.

    Guidance: /testbed/tests/genai/scorers/test_scorer_description.py
    (test_scorer_serialization) covers the serialized dict shape.  Perspective:
    caller-binding and source-extraction dataflow.  Path/symbol:
    ``mlflow.genai.scorers.base.scorer`` -> ``Scorer.model_dump`` ->
    ``mlflow.genai.scorers.scorer_utils.extract_function_body``.
    """
    from mlflow.genai.scorers import scorer

    @scorer
    def f(outputs):
        return bool(outputs)

    with _SymbolCallSpy("extract_function_body") as spy:
        dump = f.model_dump()

    assert len(spy.calls) == 1, f"extract_function_body call count was {len(spy.calls)}"
    assert spy.calls[0][0][0] is f._original_func, (
        "extract_function_body did not receive the original function"
    )
    assert isinstance(dump, dict)
    assert "bool(outputs)" in dump["call_source"], f"call_source did not contain function body: {dump!r}"
    assert dump["original_func_name"] == "f"
    assert dump["call_signature"] == "(outputs)"
    _pass("check_C23_serialization_reaches_extract_function_body")


def check_C22_deserialization_reaches_recreate_function() -> None:
    """C22/R15/R17 and Static Issue 2 (``recreate_function`` used but not defined/imported).

    Chain: public deserialization entry ``Scorer.model_validate`` ->
    ``Scorer._reconstruct_decorator_scorer`` -> caller-resolved ``recreate_function``.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_custom_scorer_loading_blocked_for_non_databricks_uri and
    test_custom_scorer_loading_blocked_for_databricks_remote_access) establish the
    security gate; the Databricks-runtime branch is the path that must reach the helper.
    Perspective: caller-binding under a controlled runtime.  Path/symbol:
    ``mlflow.genai.scorers.base.Scorer.model_validate`` ->
    ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    serialized = {
        "name": "rebound_scorer",
        "description": "deserialization path check",
        "aggregations": ["mean"],
        "call_source": "return bool(outputs)",
        "call_signature": "(outputs)",
        "original_func_name": "rebound_scorer",
    }

    with (
        _SymbolCallSpy("recreate_function") as spy,
        patch.object(scorer_base, "is_in_databricks_runtime", return_value=True),
    ):
        rebuilt = Scorer.model_validate(serialized)

    assert len(spy.calls) == 1, f"recreate_function call count was {len(spy.calls)}"
    assert spy.calls[0][0][0] == serialized["call_source"]
    assert spy.calls[0][0][1] == serialized["call_signature"]
    assert spy.calls[0][0][2] == serialized["original_func_name"]
    assert rebuilt.name == serialized["name"]
    assert rebuilt.kind == ScorerKind.DECORATOR
    _pass("check_C22_deserialization_reaches_recreate_function")


def check_C22b_deserialization_reaches_module_scorer() -> None:
    """C22b/R8/R9/R15 and Static Issue 3 (module-level ``scorer`` used but not defined/imported).

    Chain: ``Scorer.model_validate`` -> ``_reconstruct_decorator_scorer`` ->
    module-level ``scorer`` in ``mlflow.genai.scorers.base``.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_custom_scorer_loading_blocked_for_non_databricks_uri) and
    /testbed/tests/genai/scorers/test_scorer_description.py
    (test_scorer_deserialization_with_description).  Perspective: self-defining
    decorator re-entry after function reconstruction.  Path/symbol:
    ``mlflow.genai.scorers.base.Scorer._reconstruct_decorator_scorer`` ->
    ``mlflow.genai.scorers.base.scorer``.
    """
    original_scorer = scorer_base.scorer
    calls = []

    def spy_scorer(func, **kwargs):
        calls.append((func, kwargs))
        return original_scorer(func, **kwargs)

    serialized = {
        "name": "module_scorer_probe",
        "description": "module scorer re-entry",
        "aggregations": ["mean", "max"],
        "call_source": "return bool(outputs)",
        "call_signature": "(outputs)",
        "original_func_name": "module_scorer_probe",
    }

    with (
        patch.object(scorer_base, "scorer", new=spy_scorer),
        patch.object(scorer_base, "is_in_databricks_runtime", return_value=True),
    ):
        rebuilt = Scorer.model_validate(serialized)

    assert len(calls) == 1, f"module-level scorer call count was {len(calls)}"
    assert calls[0][1]["name"] == serialized["name"]
    assert calls[0][1]["description"] == serialized["description"]
    assert calls[0][1]["aggregations"] == serialized["aggregations"]
    assert rebuilt.name == serialized["name"]
    _pass("check_C22b_deserialization_reaches_module_scorer")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

_CHECKS = [
    check_C09_assessment_source_import_boundary,
    check_C10_scorer_import_boundaries,
    check_C03_standardize_delegates_to_constructor_and_str,
    check_C06_assessment_source_delegation,
    check_C12_scorer_run_filters_keyword_arguments,
    check_C23_serialization_reaches_extract_function_body,
    check_C22_deserialization_reaches_recreate_function,
    check_C22b_deserialization_reaches_module_scorer,
]


def _main() -> None:
    failures = []
    for check in _CHECKS:
        name = check.__name__
        try:
            check()
        except Exception as exc:  # noqa: BLE001 - executable spec should report all failures
            print(f"FAIL: {name}: {exc}")
            traceback.print_exc()
            failures.append(name)
        else:
            print(f"PASS: {name}")

    if failures:
        print(f"FAILED_CHECKS: {failures}")
        sys.exit(1)


if __name__ == "__main__":
    _main()
