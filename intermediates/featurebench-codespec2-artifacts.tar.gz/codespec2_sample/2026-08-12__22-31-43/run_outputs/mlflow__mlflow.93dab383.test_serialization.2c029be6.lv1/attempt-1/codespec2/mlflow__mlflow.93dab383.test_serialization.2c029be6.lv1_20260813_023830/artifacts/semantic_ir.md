# Semantic IR

IR = <R, G, C>

This document compiles the task document and repository evidence for the
Assessment Source Management and Custom Scorer Framework changes. The declared
interface paths are:

- `/testbed/mlflow/genai/scorers/base.py` -> `scorer(func=None, *, name=None, description=None, aggregations=None)`
- `/testbed/mlflow/entities/assessment_source.py` -> `AssessmentSourceType.__init__`, `__str__`, `_parse`, `_standardize`

Static-analysis findings in `mlflow/genai/scorers/base.py` are treated as
mandatory on-path risks and are closed in L2.

---

## L1. Requirement Obligations

### R1: Assessment source type constants and supported set
- **Type**: Interface / Data
- **Statement**: `AssessmentSourceType` must expose `SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `AI_JUDGE`, `HUMAN`, and `CODE`. The modern valid set used for validation is `[SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]`; `AI_JUDGE` remains a deprecated compatibility constant but is not a valid final value.
- **Task Evidence**: Interface Description 2 lists the available source types and states `AI_JUDGE` is legacy and converted to `LLM_JUDGE`.
- **Acceptance**: Reading `AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `AI_JUDGE`, `HUMAN`, `CODE` returns the corresponding uppercase strings; `AssessmentSourceType._SOURCE_TYPES` equals the four non-deprecated values.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 153-158 define the constants as strings. Repository tests compare values as strings, e.g. `/testbed/tests/genai/scorers/test_scorer_utils.py` line 286-287 asserts `AssessmentSourceType.CODE == "CODE"`.
- **Uncertainty**: The Interface Description 2 code block renders constants as `{'_type': 'literal', '_value': ...}` dictionaries. This conflicts with the checked-in source and repository tests, which use plain strings. Runtime contracts below follow the checked-in string representation.
- **Contracts**: C1, C9.

### R2: Case-insensitive source type parsing and standardization
- **Type**: Interface / Compatibility
- **Statement**: `_parse` and `_standardize` must accept any case variation of a valid source type (`"human"`, `"Human"`, `"HUMAN"`, `"llm_judge"`, etc.) and return the uppercase standardized string.
- **Task Evidence**: Interface Description 2 states "Case-insensitive string inputs (converts to uppercase)".
- **Acceptance**: `AssessmentSourceType._parse("human")` and `_standardize("Llm_Judge")` return `"HUMAN"` and `"LLM_JUDGE"` respectively without warnings.
- **Repository Evidence**: `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_case_insensitivity` exercises `AssessmentSource(source_type=...)` for `human`, `Human`, `HUMAN`, `llm_judge`, `Llm_Judge`, `LLM_JUDGE` and asserts normalized fields. `AssessmentSource.__post_init__` delegates to `AssessmentSourceType._standardize` at `/testbed/mlflow/entities/assessment_source.py` lines 76-78.
- **Uncertainty**: None.
- **Contracts**: C2, C3, C6.

### R3: Deprecated `AI_JUDGE` backward compatibility
- **Type**: Compatibility / Side-effect
- **Statement**: The deprecated `AI_JUDGE` value must be accepted, converted to `LLM_JUDGE`, and emit a `FutureWarning` with the message `AI_JUDGE is deprecated. Use LLM_JUDGE instead.`
- **Task Evidence**: Interface Description 2 and AssessmentSource docstring note `AI_JUDGE -> LLM_JUDGE` with a deprecation warning.
- **Acceptance**: Standardizing `"AI_JUDGE"` returns `"LLM_JUDGE"` and emits exactly one `FutureWarning` matching the message.
- **Repository Evidence**: `/testbed/tests/entities/test_assessment_source.py` `test_ai_judge_deprecation_warning` uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and asserts `source.source_type == "LLM_JUDGE"`.
- **Uncertainty**: None.
- **Contracts**: C4, C6.

### R4: Invalid source type rejection
- **Type**: Failure / Interface
- **Statement**: An unrecognized source type must raise `MlflowException` with an error message containing `Invalid assessment source type` and the valid source types.
- **Task Evidence**: Interface Description 2 says `MlflowException` is raised and "includes the invalid value and lists all valid source types."
- **Acceptance**: `AssessmentSourceType._parse("ROBOT")` and `AssessmentSource(source_type="ROBOT")` raise `MlflowException` whose message matches `Invalid assessment source type`.
- **Repository Evidence**: `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_type_validation` expects `MlflowException` with `match="Invalid assessment source type"` for `"ROBOT"`. `/testbed/mlflow/entities/assessment_source.py` imports `MlflowException` and `INVALID_PARAMETER_VALUE`.
- **Uncertainty**: Exact full message wording beyond the required prefix is not pinned by repository tests; hidden tests may inspect valid-list content.
- **Contracts**: C5.

### R5: `AssessmentSource` dataclass normalization and field preservation
- **Type**: Dataflow / State
- **Statement**: Constructing `AssessmentSource` must normalize `source_type` through `AssessmentSourceType._standardize` while preserving the supplied `source_id`.
- **Task Evidence**: Assessment Source Management requires validation and standardization for tracking evaluation origins.
- **Acceptance**: `AssessmentSource(source_type="llm_judge", source_id="gpt-4")` yields `source_type == "LLM_JUDGE"` and `source_id == "gpt-4"`.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 73-78; `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_properties`, `test_assessment_source_equality`, `test_assessment_source_case_insensitivity`.
- **Uncertainty**: None.
- **Contracts**: C6.

### R6: `AssessmentSourceType` instance constructor and string conversion
- **Type**: Interface
- **Statement**: `AssessmentSourceType(source_type)` must validate/normalize the input and store the standardized value; `str(instance)` must return that uppercase value.
- **Task Evidence**: Interface Description 2 documents `__init__` and `__str__` as instance-creation with string validation and string representation.
- **Acceptance**: `str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"`; `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"` with a warning.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 102-158 contain the class and constants; the `__init__`, `__str__`, `_parse`, and `_standardize` bodies are currently blank placeholders.
- **Uncertainty**: Attribute name for the stored normalized value is not shown in the current source; likely `self.source_type`, but hidden tests should observe only `str(instance)`.
- **Contracts**: C7.

### R7: `AssessmentSourceType` public import boundaries
- **Type**: Interface / Dependency
- **Statement**: `AssessmentSourceType` must be importable from its implementation module and from the public `mlflow.entities` namespace.
- **Task Evidence**: Interface Description 2 path is `/testbed/mlflow/entities/assessment_source.py`; repository callers use both import paths.
- **Acceptance**: `from mlflow.entities.assessment_source import AssessmentSourceType` succeeds, and `from mlflow.entities import AssessmentSourceType` resolves to the same class.
- **Repository Evidence**: `/testbed/mlflow/entities/__init__.py` lines 6-10 imports and re-exports it; `/testbed/mlflow/entities/assessment.py` imports from `assessment_source` and re-exports to package consumers.
- **Uncertainty**: None.
- **Contracts**: C9.

### R8: `scorer` public entry and package import boundaries
- **Type**: Interface / Dependency
- **Statement**: `scorer` must be defined in `/testbed/mlflow/genai/scorers/base.py` and be importable from `mlflow.genai.scorers.base`, `mlflow.genai.scorers`, and `mlflow.genai`.
- **Task Evidence**: Interface Description 1 gives path `/testbed/mlflow/genai/scorers/base.py`; examples import `from mlflow.genai.scorers import scorer`.
- **Acceptance**: All three import forms bind the same callable.
- **Repository Evidence**: `/testbed/tests/genai/scorers/test_scorer.py` line 6 imports `from mlflow.genai import Scorer, scorer`; `/testbed/tests/genai/scorers/test_scorer_CRUD.py` line 4 imports `from mlflow.genai.scorers import Scorer, scorer`; `/testbed/tests/genai/scorers/test_validation.py` line 9 imports `from mlflow.genai.scorers.base import Scorer, scorer`. `/testbed/mlflow/genai/scorers/__init__.py` currently imports only `Scorer, ScorerSamplingConfig` and lists `scorer` only in `__all__`; `/testbed/mlflow/genai/__init__.py` currently imports only `Scorer` and lists `scorer` only in `__all__`.
- **Uncertainty**: The checked-in package `__init__` modules do not currently bind `scorer`, so export wiring must be added.
- **Contracts**: C10.

### R9: `scorer` decorator signature and metadata handling
- **Type**: Interface / Data
- **Statement**: `scorer(func=None, *, name=None, description=None, aggregations=None)` must support both `@scorer` and `@scorer(name=..., description=..., aggregations=...)`; it returns an MLflow `Scorer` instance whose `name` defaults to `func.__name__` and whose `description` and `aggregations` are stored as supplied.
- **Task Evidence**: Interface Description 1 documents `func`, `name`, `description`, and `aggregations`, default aggregation `"mean"`, and returns a `CustomScorer`/`Scorer` instance.
- **Acceptance**: Bare decoration yields `instance.name == func.__name__` and `instance.description is None`; parameterized decoration stores the provided `name`, `description`, and `aggregations`.
- **Repository Evidence**: `/testbed/tests/genai/scorers/test_scorer_description.py` tests bare and parameterized decorators and asserts `description` and `name`. `/testbed/tests/genai/evaluate/test_utils.py` lines 493-528 tests `aggregations` pass-through. `Scorer` model fields are in `/testbed/mlflow/genai/scorers/base.py` lines 111-114.
- **Uncertainty**: Whether `aggregations` defaults to `None` or `["mean"]` on the instance is not directly asserted; aggregation defaults are currently applied later in `/testbed/mlflow/genai/scorers/aggregation.py` when `Scorer.aggregations is None`.
- **Contracts**: C11, C30.

### R10: Scorer call dispatch filters supported keyword parameters
- **Type**: Dataflow / Interface
- **Statement**: `Scorer.run` must build `{inputs, outputs, expectations, trace}` and pass only the keys accepted by the scorer function signature, preserving keyword semantics.
- **Task Evidence**: Interface Description 1 says the scorer function should take a subset of `inputs`, `outputs`, `expectations`, `trace`.
- **Acceptance**: A scorer defined as `def f(outputs): ...` receives only `outputs` when `run` is called with all four arguments; a scorer defined with `trace` receives the trace.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 374-386 implement filtering via `inspect.signature(self.__call__)`. `/testbed/tests/genai/scorers/test_scorer.py` `test_scorer_on_genai_evaluate`, `test_trace_passed_correctly`, and `test_custom_scorer_allow_none_return` exercise this path.
- **Uncertainty**: None.
- **Contracts**: C12.

### R11: Scorer return type validation
- **Type**: Failure / Interface
- **Statement**: `Scorer.run` must accept `int`, `float`, `bool`, `str`, `Feedback`, legacy `Assessment`, a list of `Feedback`/legacy `Assessment`, and `None`. Any other return value must raise `MlflowException` with a message naming `int, float, bool, str, Feedback, or list[Feedback]`.
- **Task Evidence**: Interface Description 1 lists supported return types and says `MlflowException` is raised for unsupported types.
- **Acceptance**: Supported returns pass through; unsupported `dict` or `list[int]` raises `MlflowException` containing `must return one of int, float, bool, str, Feedback, or list[Feedback]`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 387-404. Repository tests in `/testbed/tests/genai/scorers/test_scorer.py` cover primitive, `Feedback`, and list returns and `None`; unsupported-type behavior is directly implied by the code and task statement.
- **Uncertainty**: Hidden tests may use `list[int]` and inspect `Got list[int]` in the message.
- **Contracts**: C13, C14.

### R12: Feedback name normalization on single-feedback returns
- **Type**: State / Compatibility
- **Statement**: When a scorer returns a single `Feedback` whose name is the default feedback name, `run` must overwrite that name with the scorer name. Custom feedback names and lists of `Feedback` must be preserved.
- **Task Evidence**: Interface Description 1 notes metric name is determined by scorer function name or custom `name`; repository behavior is explicit in source comments.
- **Acceptance**: `@scorer def my_scorer(...): return Feedback(value=42)` yields `feedback.name == "my_scorer"`; `Feedback(name="custom")` remains `"custom"`; a list keeps each item name.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 406-423. `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_overwrites_default_feedback_name` and `test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list`.
- **Uncertainty**: None.
- **Contracts**: C15, C16.

### R13: Scorer kind and class-based scorer compatibility
- **Type**: Interface / Compatibility
- **Statement**: The framework must distinguish `ScorerKind.CLASS`, `ScorerKind.BUILTIN`, and `ScorerKind.DECORATOR`. Class-based scorers subclassing `Scorer` and implementing `__call__` remain usable for evaluation, while registration/lifecycle methods reject `CLASS` scorers.
- **Task Evidence**: Task statement requires "Support multiple scorer types (builtin, decorator-based, class-based) with consistent interfaces."
- **Acceptance**: `@scorer` instances report `ScorerKind.DECORATOR`; `Judge` subclasses report `BUILTIN`; `Scorer` subclasses report `CLASS`. Class-based scorers can run in evaluation but `register/start/update/stop` raise `MlflowException` with `Scorer must be a builtin or decorator scorer`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 29-35 (`ScorerKind`, `_ALLOWED_SCORERS_FOR_REGISTRATION`), 523-525 (`Scorer.kind -> CLASS`), 806-815 (`_check_can_be_registered`). `/testbed/mlflow/genai/judges/base.py` lines 55-58 (`Judge.kind -> BUILTIN`). `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_class_scorer_cannot_be_registered`.
- **Uncertainty**: Decorator-created scorers must set their `kind` to `DECORATOR`; this is inferred from `_ALLOWED_SCORERS_FOR_REGISTRATION` and registration tests, but the actual decorator implementation is missing.
- **Contracts**: C17, C29.

### R14: Decorator scorer serialization via `Scorer.model_dump`
- **Type**: Dataflow / Compatibility
- **Statement**: `Scorer.model_dump` on a decorator scorer must return a dictionary containing `name`, `description`, `aggregations`, `mlflow_version`, `serialization_version`, and decorator fields `call_source`, `call_signature`, and `original_func_name`; the result must be cached in `_cached_dump`.
- **Task Evidence**: Task statement requires "serialization that handles source code extraction and reconstruction" and "secure serialization."
- **Acceptance**: `model_dump()` succeeds for `@scorer`-created scorers, includes the above keys, and `call_source` is the extracted body of the original function.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 61-86 (`SerializedScorer` schema) and 149-184 (`model_dump`). `/testbed/tests/genai/scorers/test_scorer_description.py` `test_scorer_serialization` and `test_scorer_deserialization_with_description`; `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_register_with_custom_name_updates_serialization`.
- **Uncertainty**: The exact indentation/format of `call_source` is not pinned beyond its ability to be reconstructed.
- **Contracts**: C18, C23.

### R15: Secure decorator scorer deserialization gating
- **Type**: Security / Failure
- **Statement**: Deserializing a decorator scorer must not execute arbitrary code outside controlled Databricks environments. `Scorer.model_validate`/`Scorer._reconstruct_decorator_scorer` must raise `MlflowException` when not in a Databricks runtime; when connected to a Databricks workspace remotely from outside, it must raise a distinct `via remote access is not supported` error; both errors must render a copyable code snippet.
- **Task Evidence**: Task statement key challenge: "Secure code execution during scorer deserialization (restricted to controlled environments)"; Interface Description 1 note: registration/loading only supported in Databricks.
- **Acceptance**: With `is_in_databricks_runtime() == False` and non-Databricks tracking URI, deserialization raises `Loading custom scorer.*not supported`; with remote Databricks URI, raises `via remote access is not supported`; neither path calls `exec`/`recreate_function`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 301-343. `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_loading_blocked_for_non_databricks_uri`, `test_custom_scorer_loading_blocked_for_databricks_remote_access`, and `test_custom_scorer_error_message_renders_code_snippet_legibly`.
- **Uncertainty**: None.
- **Contracts**: C20, C21.

### R16: Source code extraction helper `extract_function_body`
- **Type**: Dependency / Dataflow
- **Statement**: `extract_function_body` must be available to `Scorer._extract_source_code_info` and must return the body source of a function so it can be stored in `SerializedScorer.call_source`.
- **Task Evidence**: Task statement requires source code extraction for serialization. Static analysis reports `extract_function_body` is used but undefined in `mlflow/genai/scorers/base.py`.
- **Acceptance**: The path `scorer(...).model_dump()` reaches and successfully calls `extract_function_body`, producing a non-empty `call_source` string that contains the original function body.
- **Repository Evidence**: Static issues list `extract_function_body` at `/testbed/mlflow/genai/scorers/base.py` line 193. The placeholder module `/testbed/mlflow/genai/scorers/scorer_utils.py` lines 15-60 reserves `FunctionBodyExtractor` and `extract_function_body` but currently has no implementation. `/testbed/tests/genai/scorers/test_scorer.py` indirectly exercises this through model dump/register flows.
- **Uncertainty**: The second tuple element returned by `extract_function_body` is discarded by `_extract_source_code_info` (`call_body, _ = ...`); its exact type/semantics are not pinned by current tests.
- **Contracts**: C23.

### R17: Function reconstruction helper `recreate_function`
- **Type**: Dependency / Dataflow
- **Statement**: `recreate_function(source, signature, func_name)` must compile a Python function from its body source, signature string, and name; it must handle indentation, defaults, type hints, standard-library imports, and available MLflow entities (`Feedback`, `AssessmentSourceType`, `Trace`, etc.).
- **Task Evidence**: Task statement requires "dynamic function reconstruction from serialized source code." Static analysis reports `recreate_function` is used but undefined in `mlflow/genai/scorers/base.py`.
- **Acceptance**: `recreate_function("return x + y", "(x, y)", "add_func")` returns a callable named `add_func` and `add_func(3,4) == 7`; functions with loops/control flow/defaults also execute correctly.
- **Repository Evidence**: `/testbed/tests/genai/scorers/test_scorer_utils.py` is a full test suite for `recreate_function` covering simple, control flow, loops, defaults, `Feedback` construction, `AssessmentSourceType`, `Trace`, import errors, syntax errors, empty signatures, and MLflow namespace imports.
- **Uncertainty**: None for the tested behaviors.
- **Contracts**: C22, C24, C25, C26.

### R18: Scorer lifecycle management and sampling state
- **Type**: State / Interface
- **Statement**: `Scorer` must expose `sample_rate`, `filter_string`, and `status`; `register`, `start`, `update`, and `stop` must operate on copies and update server sampling configuration through the scorer store. Status is `UNREGISTERED` when no backend is set, `STOPPED` when `sample_rate <= 0`, and `STARTED` when `sample_rate > 0`.
- **Task Evidence**: Task statement requires "scorer registration, lifecycle management (start/stop/update), and sampling configuration."
- **Acceptance**: A freshly decorated scorer has `status == ScorerStatus.UNREGISTERED`; a registered scorer has `status == ScorerStatus.STOPPED`; a started scorer with positive sample rate has `status == ScorerStatus.STARTED`; methods return new instances and leave the original instance unchanged.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 120-137, 527-590, 592-790. `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` covers register/start/update/stop, immutability, and status.
- **Uncertainty**: Scheduling is Databricks-only; non-Databricks tracking URIs raise `MlflowException` in `start/update/stop`.
- **Contracts**: C27, C28.

### R19: Aggregation configuration on scorer creation
- **Type**: Interface / Compatibility
- **Statement**: The `scorer` decorator must accept `aggregations` as a list of allowed strings (`min`, `max`, `mean`, `median`, `variance`, `p90`) or callables, and preserve the supplied value on the returned scorer.
- **Task Evidence**: Interface Description 1 documents `aggregations` and allowed values.
- **Acceptance**: `@scorer(name="s", aggregations=["mean", "max"])` produces `instance.aggregations == ["mean", "max"]`; callable aggregations are preserved.
- **Repository Evidence**: `/testbed/tests/genai/evaluate/test_utils.py` lines 493-528 tests both string and callable aggregation pass-through. `validate_aggregations` in `/testbed/mlflow/genai/scorers/validation.py` lines 177-199 already implements string/callable validation but is not currently called by `scorer` (scorer body is missing).
- **Uncertainty**: Interface Description 1 also says invalid string aggregations raise `MlflowException`. No repository test currently exercises invalid aggregation at decorator creation; hidden tests may.
- **Contracts**: C30, C31.

---

## L2. Functional Design Graph

### Nodes

### N1: `mlflow.genai.scorers.base.scorer`
- **Kind**: Public entry / function (currently undefined)
- **Repository Evidence**: Required by Interface Description 1 and imported by `/testbed/tests/genai/scorers/test_scorer.py` line 6; call site at `/testbed/mlflow/genai/scorers/base.py` line 363.

### N2: `mlflow.genai.scorers.base.Scorer`
- **Kind**: Class / model
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 111-425; pydantic `BaseModel` with `name`, `aggregations`, `description`, private state fields.

### N3: `Scorer.run`
- **Kind**: Method / public evaluation entry
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 374-425.

### N4: `Scorer.__call__`
- **Kind**: Method / dispatch slot
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 427-521; class-based scorers override it; decorator scorers must bind it to the wrapped function.

### N5: `Scorer.model_dump`
- **Kind**: Method / serialization entry
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 149-184.

### N6: `Scorer._extract_source_code_info`
- **Kind**: Method / helper
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 186-200.

### N7: `mlflow.genai.scorers.scorer_utils.extract_function_body`
- **Kind**: Helper / currently undefined
- **Repository Evidence**: Static issue; reserved in `/testbed/mlflow/genai/scorers/scorer_utils.py` lines 60-66; call site at `/testbed/mlflow/genai/scorers/base.py` line 193.

### N8: `Scorer.model_validate`
- **Kind**: Classmethod / deserialization entry
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 202-299.

### N9: `Scorer._reconstruct_decorator_scorer`
- **Kind**: Classmethod / helper
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 301-372.

### N10: `mlflow.genai.scorers.scorer_utils.recreate_function`
- **Kind**: Helper / currently undefined
- **Repository Evidence**: Static issue; reserved in `/testbed/mlflow/genai/scorers/scorer_utils.py`; call site at `/testbed/mlflow/genai/scorers/base.py` line 346; tested directly by `/testbed/tests/genai/scorers/test_scorer_utils.py`.

### N11: `Scorer` lifecycle methods (`register`, `start`, `update`, `stop`, `_create_copy`, `_check_can_be_registered`)
- **Kind**: Method group / lifecycle
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 527-844.

### N12: `Scorer` status/sampling properties (`status`, `sample_rate`, `filter_string`)
- **Kind**: Properties / state observer
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 120-137.

### N13: Scorer store callers (`MlflowTrackingStore`, `DatabricksStore`)
- **Kind**: Caller boundary
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/registry.py` lines 182-249 (`MlflowTrackingStore`) and 252-399 (`DatabricksStore`); `MlflowTrackingStore` serializes with `model_dump` and deserializes with `Scorer.model_validate`.

### N14: `mlflow.genai.scorers.__init__`
- **Kind**: Package export boundary
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/__init__.py`; currently imports `Scorer, ScorerSamplingConfig` and lists `scorer` in `__all__`.

### N15: `mlflow.genai.__init__`
- **Kind**: Package export boundary
- **Repository Evidence**: `/testbed/mlflow/genai/__init__.py`; currently imports `Scorer` from scorers and lists `scorer` in `__all__`.

### N16: `mlflow.genai.evaluation.harness._compute_eval_scores`
- **Kind**: Caller / evaluation boundary
- **Repository Evidence**: `/testbed/mlflow/genai/evaluation/harness.py` lines 197-226; calls `scorer.run(...)` for every scorer.

### N17: `mlflow.genai.scorers.validation.validate_aggregations`
- **Kind**: Helper / validation
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/validation.py` lines 177-199.

### N18: `mlflow.entities.assessment_source.AssessmentSourceType`
- **Kind**: Class / validator
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 102-194.

### N19: `AssessmentSourceType.__init__`
- **Kind**: Constructor
- **Repository Evidence**: Required by Interface Description 2; body currently blank in `/testbed/mlflow/entities/assessment_source.py`.

### N20: `AssessmentSourceType.__str__`
- **Kind**: Method / string conversion
- **Repository Evidence**: Required by Interface Description 2; body currently blank.

### N21: `AssessmentSourceType._parse`
- **Kind**: Static method / validator
- **Repository Evidence**: Required by Interface Description 2; body currently blank.

### N22: `AssessmentSourceType._standardize`
- **Kind**: Static method / public normalization entry
- **Repository Evidence**: Required by Interface Description 2; body currently blank; called by `AssessmentSource.__post_init__` at `/testbed/mlflow/entities/assessment_source.py` line 78.

### N23: `mlflow.entities.assessment_source.AssessmentSource`
- **Kind**: Dataclass
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 11-99.

### N24: `AssessmentSource.__post_init__`
- **Kind**: Method / normalization hook
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 76-78.

### Edges

### E1: N14 -> N1
- **Kind**: DATA
- **Condition**: `from mlflow.genai.scorers import scorer`
- **Transfer**: Package namespace binds the module-level `scorer` callable.
- **Evidence**: `/testbed/mlflow/genai/scorers/__init__.py` must expose `scorer`; repository tests import it.
- **Obligations**: R8.

### E2: N15 -> N14
- **Kind**: DATA
- **Condition**: `from mlflow.genai import scorer`
- **Transfer**: Top-level `mlflow.genai` re-exports `scorer` from `mlflow.genai.scorers`.
- **Evidence**: `/testbed/mlflow/genai/__init__.py` lists `scorer` in `__all__`; `/testbed/tests/genai/scorers/test_scorer.py` imports it.
- **Obligations**: R8.

### E3: N1 -> N2
- **Kind**: STATE
- **Condition**: Decorator invocation
- **Transfer**: Creates/returns a `Scorer` instance carrying `name`, `description`, `aggregations`, `kind=DECORATOR`, and the original function reference/`__call__`.
- **Evidence**: Interface Description 1; `/testbed/mlflow/genai/scorers/base.py` model fields and `_check_can_be_registered` rely on `kind`.
- **Obligations**: R9, R13, R19.

### E4: N1 -> N4
- **Kind**: DATA
- **Condition**: Decorator invocation
- **Transfer**: Binds the wrapped original function as the scorer callable.
- **Evidence**: `Scorer.run` calls `self(**filtered)` at `/testbed/mlflow/genai/scorers/base.py` line 386; `@scorer` test functions execute.
- **Obligations**: R10, R13.

### E5: N16 -> N3
- **Kind**: CALL
- **Condition**: GenAI evaluation harness runs scorers.
- **Transfer**: Passes `inputs`, `outputs`, `expectations`, `trace` to `Scorer.run`.
- **Evidence**: `/testbed/mlflow/genai/evaluation/harness.py` lines 201-212.
- **Obligations**: R10, R11, R12.

### E6: N3 -> N4
- **Kind**: CALL
- **Condition**: `run` filters signature-compatible keys.
- **Transfer**: Invokes `self(**filtered)` and captures the returned assessment.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 377-386.
- **Obligations**: R10, R11.

### E7: N3 -> MlflowException
- **Kind**: CONTROL
- **Condition**: Return value is not an allowed primitive, `Feedback`/`Assessment`, list thereof, or `None`.
- **Transfer**: Raises `MlflowException.invalid_parameter_value`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 387-404.
- **Obligations**: R11.

### E8: N3 -> N2
- **Kind**: STATE
- **Condition**: Return value is a single `Feedback` with default name.
- **Transfer**: Mutates `result.name` to `self.name`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 406-423.
- **Obligations**: R12.

### E9: N5 -> N6
- **Kind**: CALL
- **Condition**: Decorator scorer has `_original_func`.
- **Transfer**: Calls `_extract_source_code_info` to obtain body source and signature.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 157-181.
- **Obligations**: R14, R16.

### E10: N6 -> N7
- **Kind**: CALL
- **Condition**: Serialization of decorator scorer.
- **Transfer**: Calls `extract_function_body(self._original_func)` and stores the first returned value as `call_source`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` line 193; static issue `extract_function_body` undefined.
- **Obligations**: R14, R16.

### E11: N7 -> N5
- **Kind**: DATA
- **Condition**: Source extraction succeeds.
- **Transfer**: Returns extracted body to populate `SerializedScorer.call_source`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 179-184.
- **Obligations**: R14, R16.

### E12: N5 -> N2
- **Kind**: STATE
- **Condition**: First successful decorator `model_dump`.
- **Transfer**: Sets `_cached_dump` to the serialized dict.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 183-184.
- **Obligations**: R14.

### E13: N13 -> N5
- **Kind**: CALL
- **Condition**: Tracking-store scorer registration.
- **Transfer**: `json.dumps(scorer.model_dump())`.
- **Evidence**: `/testbed/mlflow/genai/scorers/registry.py` line 192.
- **Obligations**: R14, R16.

### E14: N8 -> N9
- **Kind**: CALL
- **Condition**: Serialized data has decorator fields `call_source`, `call_signature`, `original_func_name`.
- **Transfer**: Dispatches to `_reconstruct_decorator_scorer`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 238-240.
- **Obligations**: R15, R17.

### E15: N9 -> N10
- **Kind**: CALL
- **Condition**: Databricks runtime security gate passes.
- **Transfer**: Calls `recreate_function(serialized.call_source, serialized.call_signature, serialized.original_func_name)`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 345-348; static issue `recreate_function` undefined.
- **Obligations**: R15, R17.

### E16: N10 -> N9
- **Kind**: DATA
- **Condition**: Reconstruction succeeds.
- **Transfer**: Returns a callable with the original name/signature.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 345-359.
- **Obligations**: R17.

### E17: N9 -> N1
- **Kind**: CALL
- **Condition**: Recreated function exists.
- **Transfer**: Calls module-level `scorer(recreated_func, name=..., description=..., aggregations=...)` to rebuild the scorer.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 363-368; static issue `scorer` undefined in the same module.
- **Obligations**: R8, R9, R15.

### E18: N13 -> N8
- **Kind**: CALL
- **Condition**: Tracking-store scorer retrieval/listing.
- **Transfer**: `Scorer.model_validate(serialized_scorer)`.
- **Evidence**: `/testbed/mlflow/genai/scorers/registry.py` lines 207, 221, 234.
- **Obligations**: R15, R17.

### E19: N9 -> MlflowException
- **Kind**: CONTROL
- **Condition**: `is_in_databricks_runtime()` is false, or tracking URI is a remote Databricks URI.
- **Transfer**: Raises `MlflowException.invalid_parameter_value` with rendered code snippet; `exec`/`recreate_function` not reached.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 305-343.
- **Obligations**: R15.

### E20: N11 -> N13
- **Kind**: CALL
- **Condition**: `register`, `start`, `update`, or `stop` invoked.
- **Transfer**: Delegates server mutation to `_get_scorer_store()`/`DatabricksStore`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 584, 656, 729, 786.
- **Obligations**: R18.

### E21: N11 -> N12
- **Kind**: STATE
- **Condition**: Registration/scheduling methods create copies with sampling config.
- **Transfer**: Updates `_sampling_config`, `_registered_backend`; `status` derives `UNREGISTERED`/`STOPPED`/`STARTED`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 120-137, 584-590; `/testbed/mlflow/genai/scorers/registry.py` lines 261-268, 362-363.
- **Obligations**: R18.

### E22: N24 -> N22
- **Kind**: CALL
- **Condition**: `AssessmentSource` dataclass initialized.
- **Transfer**: Calls `AssessmentSourceType._standardize(self.source_type)` and assigns the result back.
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 76-78.
- **Obligations**: R2, R3, R5.

### E23: N22 -> N19
- **Kind**: CALL
- **Condition**: `_standardize` follows its documented temp-instance approach.
- **Transfer**: Creates `AssessmentSourceType(source_type)` and obtains its string representation.
- **Evidence**: Interface Description 2 `_standardize` docstring says it creates a temporary instance and converts to string.
- **Obligations**: R2, R6.

### E24: N19 -> N21
- **Kind**: CALL
- **Condition**: Constructor normalizes input.
- **Transfer**: Calls `_parse(source_type)` and stores the result.
- **Evidence**: Interface Description 2 `__init__`/`_parse` docstrings.
- **Obligations**: R2, R3, R4, R6.

### E25: N19 -> N20
- **Kind**: DATA
- **Condition**: `str(instance)` requested.
- **Transfer**: `__str__` returns the stored standardized value.
- **Evidence**: Interface Description 2 `__str__` docstring.
- **Obligations**: R6.

### E26: N1 -> N17 (candidate)
- **Kind**: CALL
- **Condition**: If `scorer` validates aggregation names eagerly at creation time.
- **Transfer**: Calls `validate_aggregations(aggregations)` before constructing the scorer.
- **Evidence**: Interface Description 1 requires allowed string aggregations; `validate_aggregations` already implements this rule.
- **Obligations**: R19.
- **Uncertainty**: No repository caller currently wires this helper; this edge is conditional and must not be treated as observed runtime behavior.

---

## Static Issue Closure

### Static issue 1: `extract_function_body` used but not defined/imported in `mlflow/genai/scorers/base.py`
1. **Call site**: `/testbed/mlflow/genai/scorers/base.py` line 193 inside `Scorer._extract_source_code_info` (`U`).
2. **Upward caller trace**:
   - `Scorer._extract_source_code_info` is called by `Scorer.model_dump` at `/testbed/mlflow/genai/scorers/base.py` line 170.
   - `Scorer.model_dump` is called by `MlflowTrackingStore.register_scorer` at `/testbed/mlflow/genai/scorers/registry.py` line 192.
   - `MlflowTrackingStore.register_scorer` is called by `Scorer.register` at `/testbed/mlflow/genai/scorers/base.py` line 584.
   - `Scorer.register` is invoked on scorers created by the task-required public entry `scorer`; direct `scorer(...).model_dump()` tests also reach `model_dump` without registration.
3. **Chain**: `scorer` (public entry `P`) -> `Scorer.register` -> `MlflowTrackingStore.register_scorer` -> `Scorer.model_dump` -> `Scorer._extract_source_code_info` -> `extract_function_body`.
4. **Disposition**: ON-PATH. Contract C23 observes the real caller path through `scorer(...).model_dump()`.

Edges recorded: E9 (`model_dump` -> `_extract_source_code_info`), E10 (`_extract_source_code_info` -> `extract_function_body`), E13 (tracking store -> `model_dump`), E20 (lifecycle -> store).

### Static issue 2: `recreate_function` used but not defined/imported in `mlflow/genai/scorers/base.py`
1. **Call site**: `/testbed/mlflow/genai/scorers/base.py` line 346 inside `Scorer._reconstruct_decorator_scorer` (`U`).
2. **Upward caller trace**:
   - `Scorer._reconstruct_decorator_scorer` is called by `Scorer.model_validate` at `/testbed/mlflow/genai/scorers/base.py` line 240.
   - `Scorer.model_validate` is called by `MlflowTrackingStore.get_scorer` at `/testbed/mlflow/genai/scorers/registry.py` line 221, `list_scorers` at line 207, and `list_scorer_versions` at line 234.
   - Registry `get_scorer`/`list_scorers` are public APIs under `mlflow.genai.scorers.registry`; repository tests also call `Scorer.model_validate` directly.
3. **Chain**: `Scorer.model_validate` (deserialization entry `P`) -> `Scorer._reconstruct_decorator_scorer` -> `recreate_function`.
4. **Disposition**: ON-PATH. Contract C22 observes `Scorer.model_validate` in a Databricks-runtime test double reaching `recreate_function`.

Edges recorded: E14 (`model_validate` -> `_reconstruct_decorator_scorer`), E15 (`_reconstruct_decorator_scorer` -> `recreate_function`), E18 (tracking store -> `model_validate`).

### Static issue 3: `scorer` used but not defined/imported in `mlflow/genai/scorers/base.py`
1. **Call site**: `/testbed/mlflow/genai/scorers/base.py` line 363 inside `Scorer._reconstruct_decorator_scorer` (`U`).
2. **Upward caller trace**:
   - `Scorer._reconstruct_decorator_scorer` is called by `Scorer.model_validate` at line 240.
   - `Scorer.model_validate` is reached from registry public deserialization callers and direct tests as above.
3. **Chain**: `Scorer.model_validate` -> `Scorer._reconstruct_decorator_scorer` -> module-level `scorer`.
4. **Disposition**: ON-PATH and self-defining: `scorer` is itself task-required public entry `P` in Interface Description 1. Contract C22b observes the reconstruction path invoking the module-level `scorer`.

Edges recorded: E17 (`_reconstruct_decorator_scorer` -> `scorer`), E1/E2 (package exports -> `scorer`).

---

## L3. Verifiable Contracts

### C1: Assessment source type constant values
- **Type**: Field value
- **Subject**: `AssessmentSourceType`
- **Relation**: `FIELD_READ`
- **Expected**: `SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"`, `LLM_JUDGE == "LLM_JUDGE"`, `AI_JUDGE == "AI_JUDGE"`, `HUMAN == "HUMAN"`, `CODE == "CODE"`, and `_SOURCE_TYPES == ["SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "HUMAN", "CODE"]`.
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 153-158; repository tests compare string values.
- **Observe**: FIELD_READ
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType`
- **Obligations**: R1
- **Graph**: N18.

### C2: `_parse` case-insensitive normalization
- **Type**: Return value
- **Subject**: `AssessmentSourceType._parse`
- **Relation**: accepts mixed-case valid source type
- **Expected**: `_parse("human") == "HUMAN"`, `_parse("Llm_Judge") == "LLM_JUDGE"`, no warning.
- **Evidence**: Interface Description 2; repository test `test_assessment_source_case_insensitivity`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- **Obligations**: R2
- **Graph**: N21.

### C3: `_standardize` case-insensitive normalization
- **Type**: Return value
- **Subject**: `AssessmentSourceType._standardize`
- **Relation**: accepts mixed-case valid source type
- **Expected**: `_standardize("human") == "HUMAN"`; `_standardize("llm_judge") == "LLM_JUDGE"`.
- **Evidence**: Interface Description 2; `AssessmentSource.__post_init__` depends on this.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType._standardize`
- **Obligations**: R2, R5
- **Graph**: N22.

### C4: `_parse` deprecates `AI_JUDGE`
- **Type**: Return value + warning
- **Subject**: `AssessmentSourceType._parse`
- **Relation**: accepts deprecated `AI_JUDGE`
- **Expected**: `_parse("AI_JUDGE") == "LLM_JUDGE"` and `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`.
- **Evidence**: `/testbed/tests/entities/test_assessment_source.py` `test_ai_judge_deprecation_warning`.
- **Observe**: RETURN_VALUE and SIDE_EFFECT
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- **Obligations**: R3
- **Graph**: N21.

### C5: `_parse` invalid source type raises
- **Type**: Exception
- **Subject**: `AssessmentSourceType._parse`
- **Relation**: rejects unsupported source type
- **Expected**: `_parse("ROBOT")` raises `MlflowException` with message matching `Invalid assessment source type`.
- **Evidence**: `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_type_validation`.
- **Observe**: EXCEPTION
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- **Obligations**: R4
- **Graph**: N21.

### C6: `AssessmentSource` normalizes `source_type` and preserves `source_id`
- **Type**: State/field read
- **Subject**: `AssessmentSource.__post_init__`
- **Relation**: normalizes `source_type` via `_standardize`
- **Expected**: `AssessmentSource(source_type="llm_judge", source_id="gpt-4").source_type == "LLM_JUDGE"`; `.source_id == "gpt-4"`.
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 76-78; repository tests `test_assessment_source_properties` and `test_assessment_source_case_insensitivity`.
- **Observe**: FIELD_READ
- **Target**: `mlflow.entities.assessment_source.AssessmentSource`
- **Obligations**: R2, R3, R5
- **Graph**: N24 -> N22, N23.

### C7: `AssessmentSourceType` constructor and `__str__`
- **Type**: Return value / field read
- **Subject**: `AssessmentSourceType.__init__` and `__str__`
- **Relation**: instance normalizes input
- **Expected**: `str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"`; `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"` with deprecation warning.
- **Evidence**: Interface Description 2 `__init__`/`__str__`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType`
- **Obligations**: R2, R3, R6
- **Graph**: N19, N20, N21.

### C8: `AssessmentSourceType.from_proto` returns enum name
- **Type**: Return value
- **Subject**: `AssessmentSourceType.from_proto`
- **Relation**: converts protobuf source type to name string
- **Expected**: `AssessmentSourceType.from_proto(proto_source_type) == ProtoAssessmentSource.SourceType.Name(proto_source_type)`.
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 192-194.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType.from_proto`
- **Obligations**: R1, R7
- **Graph**: N18.

### C9: `AssessmentSourceType` import boundary
- **Type**: Import boundary
- **Subject**: `AssessmentSourceType`
- **Relation**: binds from implementation and public package namespaces
- **Expected**: `from mlflow.entities.assessment_source import AssessmentSourceType` and `from mlflow.entities import AssessmentSourceType` both succeed and resolve to the same object.
- **Evidence**: `/testbed/mlflow/entities/__init__.py` lines 6-10; `/testbed/mlflow/entities/assessment.py` imports the symbol.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `mlflow.entities.assessment_source.AssessmentSourceType`
- **Obligations**: R7
- **Graph**: N18.

### C10: `scorer` import boundaries
- **Type**: Import boundary
- **Subject**: `scorer`
- **Relation**: binds from all three public namespaces
- **Expected**: `from mlflow.genai.scorers.base import scorer`, `from mlflow.genai.scorers import scorer`, and `from mlflow.genai import scorer` all succeed and resolve to the same callable.
- **Evidence**: Repository test imports in `/testbed/tests/genai/scorers/test_scorer.py` line 6, `/testbed/tests/genai/scorers/test_scorer_CRUD.py` line 4, `/testbed/tests/genai/scorers/test_validation.py` line 9; `__all__` entries in `scorers/__init__.py` and `genai/__init__.py`.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `mlflow.genai.scorers.base.scorer`
- **Obligations**: R8
- **Graph**: N1, N14, N15, E1, E2.

### C11: `scorer` decorator metadata
- **Type**: Field read
- **Subject**: `scorer`
- **Relation**: stores name/description/aggregations
- **Expected**: For `@scorer(name="custom", description="desc", aggregations=["mean","max"]) def f(...): ...`, `f.name == "custom"`, `f.description == "desc"`, `f.aggregations == ["mean","max"]`, and `f` is an instance of `mlflow.genai.scorers.base.Scorer`.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer_description.py`; `/testbed/tests/genai/evaluate/test_utils.py` lines 493-528.
- **Observe**: FIELD_READ
- **Target**: returned scorer instance
- **Obligations**: R9, R19
- **Graph**: N1 -> N2.

### C12: `Scorer.run` filters keyword arguments
- **Type**: Runtime argument trace
- **Subject**: `Scorer.run`
- **Relation**: passes only signature-compatible keys
- **Expected**: A scorer function `def f(outputs):` called through `f.run(inputs=..., outputs=..., expectations=..., trace=...)` invokes `f.__call__` with exactly `{"outputs": ...}`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 374-386.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `Scorer.run`
- **Obligations**: R10
- **Graph**: N3 -> N4, E6.

### C13: `Scorer.run` passes supported return values
- **Type**: Return value
- **Subject**: `Scorer.run`
- **Relation**: returns supported scorer output unchanged
- **Expected**: For decorated scorers returning `"yes"`, `42`, `42.0`, `True`, `Feedback(...)`, or a list of `Feedback`, `run` returns the same value/type.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer.py` `test_scorer_on_genai_evaluate` and `test_custom_scorer_allow_none_return`.
- **Observe**: RETURN_VALUE
- **Target**: `Scorer.run`
- **Obligations**: R11
- **Graph**: N3, N4.

### C14: `Scorer.run` rejects unsupported return values
- **Type**: Exception
- **Subject**: `Scorer.run`
- **Relation**: raises for unsupported type
- **Expected**: A scorer returning `{"score": 1}` or `[1, 2]` raises `MlflowException` with message matching `must return one of int, float, bool, str, Feedback, or list[Feedback]`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 387-404.
- **Observe**: EXCEPTION
- **Target**: `Scorer.run`
- **Obligations**: R11
- **Graph**: N3, E7.

### C15: Single default-named `Feedback` renamed to scorer name
- **Type**: Field read
- **Subject**: `Scorer.run`
- **Relation**: overwrites default feedback name
- **Expected**: `@scorer def my_scorer(...): return Feedback(value=42)` -> returned feedback has `name == "my_scorer"`.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_overwrites_default_feedback_name`.
- **Observe**: FIELD_READ
- **Target**: returned `Feedback`
- **Obligations**: R12
- **Graph**: N3 -> N2, E8.

### C16: List feedback names preserved
- **Type**: Field read
- **Subject**: `Scorer.run`
- **Relation**: does not rewrite list item names
- **Expected**: A scorer returning `[Feedback(name="big", ...), Feedback(name="small", ...)]` yields names `"big"` and `"small"` unchanged.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list`.
- **Observe**: FIELD_READ
- **Target**: returned list
- **Obligations**: R12
- **Graph**: N3.

### C17: Decorator scorer kind is `DECORATOR`
- **Type**: Field read
- **Subject**: scorer-created instance
- **Relation**: reports `ScorerKind.DECORATOR`
- **Expected**: `@scorer def f(outputs): ...` -> `f.kind == ScorerKind.DECORATOR`.
- **Evidence**: `_ALLOWED_SCORERS_FOR_REGISTRATION` includes `DECORATOR` and registration tests for custom scorers pass the `_check_can_be_registered` path in `/testbed/mlflow/genai/scorers/base.py`.
- **Observe**: FIELD_READ
- **Target**: returned scorer instance
- **Obligations**: R13
- **Graph**: N1 -> N2.

### C18: `Scorer.model_dump` serializes decorator scorer fields
- **Type**: Return value
- **Subject**: `Scorer.model_dump`
- **Relation**: returns serialized scorer dictionary
- **Expected**: Dictionary has `name`, `description`, `aggregations`, `mlflow_version`, `serialization_version`, `call_source`, `call_signature`, `original_func_name`; `name` equals scorer name and `description` equals supplied value.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 172-184; `/testbed/tests/genai/scorers/test_scorer_description.py` `test_scorer_serialization`.
- **Observe**: RETURN_VALUE
- **Target**: `Scorer.model_dump`
- **Obligations**: R14
- **Graph**: N5 -> N6 -> N7, E9-E12.

### C19: Unsupported direct `Scorer` subclass serialization raises
- **Type**: Exception
- **Subject**: `Scorer.model_dump`
- **Relation**: rejects unsupported scorer kind
- **Expected**: A direct `Scorer` subclass instance without `_original_func` raises `MlflowException` containing `Unsupported scorer type`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 156-167.
- **Observe**: EXCEPTION
- **Target**: `Scorer.model_dump`
- **Obligations**: R13, R14
- **Graph**: N5.

### C20: Decorator deserialization blocked outside Databricks runtime
- **Type**: Exception
- **Subject**: `Scorer._reconstruct_decorator_scorer`
- **Relation**: refuses execution when not in Databricks runtime
- **Expected**: With `is_in_databricks_runtime()` false and non-Databricks tracking URI, `Scorer._reconstruct_decorator_scorer(serialized)` raises `MlflowException` matching `Loading custom scorer.*not supported`; `recreate_function` is not called.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_loading_blocked_for_non_databricks_uri`; `/testbed/mlflow/genai/scorers/base.py` lines 308-343.
- **Observe**: EXCEPTION
- **Target**: `Scorer._reconstruct_decorator_scorer`
- **Obligations**: R15
- **Graph**: N9, E19.

### C21: Decorator deserialization blocked for remote Databricks access
- **Type**: Exception
- **Subject**: `Scorer._reconstruct_decorator_scorer`
- **Relation**: distinguishes remote Databricks URI
- **Expected**: With `is_in_databricks_runtime()` false and `is_databricks_uri(tracking_uri)` true, raises `MlflowException` matching `via remote access is not supported`.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_loading_blocked_for_databricks_remote_access`.
- **Observe**: EXCEPTION
- **Target**: `Scorer._reconstruct_decorator_scorer`
- **Obligations**: R15
- **Graph**: N9, E19.

### C22: Deserialization path reaches `recreate_function`
- **Type**: Runtime argument trace
- **Subject**: `Scorer.model_validate` -> `Scorer._reconstruct_decorator_scorer`
- **Relation**: calls `recreate_function` with serialized fields when Databricks runtime is true
- **Expected**: Under a patch of `is_in_databricks_runtime` to `True`, `Scorer.model_validate(serialized_decorator_dict)` reaches `recreate_function(serialized.call_source, serialized.call_signature, serialized.original_func_name)` exactly once.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 345-348; static issue `recreate_function` is ON-PATH through `model_validate`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `mlflow.genai.scorers.scorer_utils.recreate_function`
- **Obligations**: R15, R17
- **Graph**: N8 -> N9 -> N10, E14, E15.

### C22b: Deserialization path reaches module-level `scorer`
- **Type**: Runtime argument trace / return value
- **Subject**: `Scorer._reconstruct_decorator_scorer`
- **Relation**: re-decorates reconstructed function via module-level `scorer`
- **Expected**: After `recreate_function`, `_reconstruct_decorator_scorer` calls `mlflow.genai.scorers.base.scorer(recreated_func, name=serialized.name, description=serialized.description, aggregations=serialized.aggregations)` and returns a `Scorer` with `name == serialized.name`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 363-372; static issue `scorer` is self-defining and ON-PATH.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `mlflow.genai.scorers.base.scorer`
- **Obligations**: R8, R9, R15
- **Graph**: N9 -> N1, E17.

### C23: Serialization path reaches `extract_function_body`
- **Type**: Runtime argument trace / return value
- **Subject**: `scorer(...).model_dump()` -> `Scorer._extract_source_code_info`
- **Relation**: calls `extract_function_body` with the original function
- **Expected**: For `@scorer def f(outputs): return bool(outputs)`, `f.model_dump()` reaches `extract_function_body(f._original_func)` and returns a dict with non-empty `call_source` containing the function body and `original_func_name == "f"`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 186-198; static issue `extract_function_body` is ON-PATH through `model_dump`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `mlflow.genai.scorers.scorer_utils.extract_function_body`
- **Obligations**: R14, R16
- **Graph**: N5 -> N6 -> N7, E9, E10.

### C24: `recreate_function` basic reconstruction
- **Type**: Return value
- **Subject**: `recreate_function`
- **Relation**: compiles simple source into a callable
- **Expected**: `recreate_function("return x + y", "(x, y)", "add_func")` returns a function with `__name__ == "add_func"` and `add_func(3,4) == 7`.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_simple_function_recreation`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.scorer_utils.recreate_function`
- **Obligations**: R17
- **Graph**: N10.

### C25: `recreate_function` MLflow namespace and type-hint compatibility
- **Type**: Return value
- **Subject**: `recreate_function`
- **Relation**: makes MLflow entities importable in reconstructed functions
- **Expected**: Reconstructed functions can construct `Feedback`, `AssessmentSourceType`, and `Trace`, and a signature with `mlflow.entities.Trace`/`mlflow.entities.Feedback` type hints is accepted.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_mlflow_imports_available` and `test_function_with_mlflow_trace_type_hint`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.scorer_utils.recreate_function`
- **Obligations**: R17
- **Graph**: N10.

### C26: `recreate_function` failure semantics
- **Type**: Exception
- **Subject**: `recreate_function`
- **Relation**: validates signature and source syntax
- **Expected**: Empty signature raises `MlflowException` matching `Invalid signature format`; syntax-error source raises `SyntaxError`; empty body source raises `SyntaxError` matching `expected an indented block`.
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_empty_signature_string`, `test_function_with_syntax_error`, `test_empty_source_code`.
- **Observe**: EXCEPTION
- **Target**: `mlflow.genai.scorers.scorer_utils.recreate_function`
- **Obligations**: R17
- **Graph**: N10.

### C27: Scorer status follows registration/sampling state
- **Type**: State read
- **Subject**: `Scorer.status`
- **Relation**: derives from `_registered_backend` and `sample_rate`
- **Expected**: Fresh decorator scorer has `status == ScorerStatus.UNREGISTERED`; after `register` under Databricks backend it has `status == ScorerStatus.STOPPED`; after `start` with `sample_rate > 0` it has `status == ScorerStatus.STARTED`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 130-137; `/testbed/tests/genai/scorers/test_scorer_CRUD.py` and `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py`.
- **Observe**: STATE_READ
- **Target**: `Scorer.status`
- **Obligations**: R18
- **Graph**: N11 -> N12, E21.

### C28: Lifecycle methods are immutable with respect to the original scorer
- **Type**: State read
- **Subject**: `Scorer.register/start/update/stop`
- **Relation**: return new instances and leave original state unchanged
- **Expected**: Each method returns `new_scorer is not original`; original `name`, `_sampling_config`, and serialization cache remain unchanged after the call.
- **Evidence**: `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_all_methods_are_immutable` and `test_scorer_register`.
- **Observe**: STATE_READ
- **Target**: returned scorer and original scorer
- **Obligations**: R18
- **Graph**: N11.

### C29: Class-based scorer registration is rejected
- **Type**: Exception
- **Subject**: `Scorer._check_can_be_registered`
- **Relation**: rejects `ScorerKind.CLASS`
- **Expected**: A direct `Scorer` subclass with `__call__` raises `MlflowException` matching `Scorer must be a builtin or decorator scorer` for `register`, `start`, `update`, and `stop`.
- **Evidence**: `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_class_scorer_cannot_be_registered`; `/testbed/mlflow/genai/scorers/base.py` lines 806-815.
- **Observe**: EXCEPTION
- **Target**: `Scorer.register/start/update/stop`
- **Obligations**: R13, R18
- **Graph**: N11.

### C30: `scorer` preserves aggregation configuration
- **Type**: Field read
- **Subject**: scorer-created instance
- **Relation**: stores string and callable aggregations
- **Expected**: `@scorer(aggregations=["mean","max"])` and `@scorer(aggregations=[sum, max])` produce instances with `.aggregations ==` the supplied list.
- **Evidence**: `/testbed/tests/genai/evaluate/test_utils.py` `test_scorer_pass_through_aggregations`.
- **Observe**: FIELD_READ
- **Target**: returned scorer instance
- **Obligations**: R19
- **Graph**: N1 -> N2.

### C31: Invalid aggregation string rejection at scorer creation
- **Type**: Exception
- **Subject**: `scorer` aggregation validation
- **Relation**: rejects invalid string aggregation names
- **Expected**: `@scorer(aggregations=["bogus"])` raises `MlflowException` matching `Invalid aggregation`.
- **Evidence**: Interface Description 1 restricts string aggregations to the six supported names; `/testbed/mlflow/genai/scorers/validation.py` `validate_aggregations` implements the same rule.
- **Observe**: EXCEPTION
- **Target**: `scorer` creation path
- **Obligations**: R19
- **Graph**: N1 -> N17.
- **Uncertainty**: No repository test currently exercises invalid aggregation at `scorer` creation, and `validate_aggregations` is not currently wired into `scorer`. If hidden tests do not require eager validation, this contract may be relaxed to "invalid names fail later in aggregation computation"; otherwise `scorer` must call or duplicate `validate_aggregations`.

