"""Behavioral specification for Assessment Source Management and Custom Scorer Framework.

This file compiles the value, state, outcome, failure, side-effect, boundary, and
compatibility contracts from the typed semantic IR.  It is executable with plain
``python`` and does not require pytest.

Contract coverage in this file:
    C1, C2, C3, C4, C5, C6, C7, C8, C11, C13, C14, C15, C16, C17, C18,
    C19, C20, C21, C24, C25, C26, C27, C28, C29, C30, C31, C32 (new)
"""

from __future__ import annotations

import sys
import traceback
import warnings
from contextlib import ExitStack
from unittest.mock import ANY, patch

import mlflow
import mlflow.genai.scorers.base as scorer_base
import mlflow.genai.scorers.scorer_utils as scorer_utils
from mlflow.entities import Assessment, Feedback, Trace, TraceData, TraceInfo, TraceState
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.entities.trace_location import (
    MlflowExperimentLocation,
    TraceLocation,
    TraceLocationType,
)
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import (
    Scorer,
    ScorerKind,
    ScorerSamplingConfig,
    ScorerStatus,
    SerializedScorer,
)
from mlflow.genai.scorers.registry import DatabricksStore


def _pass(name: str) -> None:
    print(f"PASS: {name}")


def _make_trace() -> Trace:
    """Create a minimal Trace for reconstruction type-hint tests."""
    mlflow_exp_location = MlflowExperimentLocation(experiment_id="0")
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=mlflow_exp_location,
    )
    trace_info = TraceInfo(
        trace_id="test_trace_id",
        trace_location=trace_location,
        request_time=1000,
        state=TraceState.OK,
    )
    return Trace(info=trace_info, data=TraceData())


def _copy_with_sampling(
    scorer: Scorer,
    sample_rate: float | None,
    filter_string: str | None = None,
) -> Scorer:
    """Return a Databricks-registered copy with the given sampling configuration."""
    copy = scorer.model_copy(deep=True)
    object.__setattr__(
        copy, "_sampling_config", ScorerSamplingConfig(sample_rate=sample_rate, filter_string=filter_string)
    )
    object.__setattr__(copy, "_registered_backend", "databricks")
    return copy


def _enter_databricks_common(stack: ExitStack):
    """Patch all Databricks URI/store gates needed by the real lifecycle methods."""
    stack.enter_context(patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True))
    stack.enter_context(patch("mlflow.genai.scorers.base.get_tracking_uri", return_value="databricks"))
    stack.enter_context(
        patch("mlflow.tracking._tracking_service.utils.get_tracking_uri", return_value="databricks")
    )
    stack.enter_context(patch("mlflow.utils.uri.is_databricks_uri", return_value=True))
    mock_store = stack.enter_context(patch("mlflow.genai.scorers.registry._get_scorer_store"))
    mock_store.return_value = DatabricksStore()
    return mock_store


class _SymbolSpy:
    """Patch a scorer_utils symbol at its defining module and any base-module alias.

    ``fail_if_called`` is used by blocked deserialization checks to prove the
    execution primitive is not reached; normal mode is used by cache-reuse checks.
    """

    def __init__(self, symbol_name: str, fail_if_called: bool = False):
        self.symbol_name = symbol_name
        self.fail_if_called = fail_if_called
        self.calls: list[tuple[tuple, dict]] = []
        self._patches = []

    def _make_spy(self, original):
        calls = self.calls
        symbol_name = self.symbol_name
        fail_if_called = self.fail_if_called

        def spy(*args, **kwargs):
            calls.append((args, kwargs))
            if fail_if_called:
                raise AssertionError(f"{symbol_name} was called in a blocked execution path")
            return original(*args, **kwargs)

        return spy

    def __enter__(self) -> "_SymbolSpy":
        utils_original = getattr(scorer_utils, self.symbol_name)
        self._patches.append(
            patch.object(scorer_utils, self.symbol_name, new=self._make_spy(utils_original))
        )
        if hasattr(scorer_base, self.symbol_name):
            base_original = getattr(scorer_base, self.symbol_name)
            self._patches.append(
                patch.object(scorer_base, self.symbol_name, new=self._make_spy(base_original))
            )
        for item in self._patches:
            item.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        for item in reversed(self._patches):
            item.stop()
        return False


# ---------------------------------------------------------------------------
# Assessment source values and validation
# ---------------------------------------------------------------------------

def check_C01_assessment_source_constants() -> None:
    """C1/R1. Constants and modern supported set must match the public string values.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py lines 286-287
    compares ``AssessmentSourceType.CODE == "CODE"``.  Perspective: field-value
    compatibility.  Path/symbol: ``mlflow.entities.assessment_source.AssessmentSourceType``.
    """
    t = AssessmentSourceType
    assert t.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert t.LLM_JUDGE == "LLM_JUDGE"
    assert t.AI_JUDGE == "AI_JUDGE"
    assert t.HUMAN == "HUMAN"
    assert t.CODE == "CODE"
    assert t._SOURCE_TYPES == ["SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "HUMAN", "CODE"]
    _pass("check_C01_assessment_source_constants")


def check_C02_parse_case_insensitive() -> None:
    """C2/R2. ``_parse`` normalizes mixed-case modern values without warning.

    Guidance: /testbed/tests/entities/test_assessment_source.py
    (test_assessment_source_case_insensitivity).  Perspective: case-insensitive
    standardization.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSourceType._parse``.
    """
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        assert AssessmentSourceType._parse("human") == "HUMAN"
        assert AssessmentSourceType._parse("Human") == "HUMAN"
        assert AssessmentSourceType._parse("HUMAN") == "HUMAN"
        assert AssessmentSourceType._parse("llm_judge") == "LLM_JUDGE"
        assert AssessmentSourceType._parse("Llm_Judge") == "LLM_JUDGE"
        assert AssessmentSourceType._parse("LLM_JUDGE") == "LLM_JUDGE"

    future_warnings = [w for w in caught if issubclass(w.category, FutureWarning)]
    assert future_warnings == [], f"unexpected FutureWarning for modern source types: {future_warnings}"
    _pass("check_C02_parse_case_insensitive")


def check_C03_standardize_case_insensitive() -> None:
    """C3/R2/R5. ``_standardize`` is the public normalization entry.

    Guidance: /testbed/tests/entities/test_assessment_source.py
    (test_assessment_source_case_insensitivity) exercises this through
    ``AssessmentSource``.  Perspective: normalization entry result.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSourceType._standardize``.
    """
    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("CODE") == "CODE"
    assert AssessmentSourceType._standardize("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"
    _pass("check_C03_standardize_case_insensitive")


def check_C04_parse_ai_judge_deprecation() -> None:
    """C4/R3. Deprecated ``AI_JUDGE`` converts to ``LLM_JUDGE`` with a FutureWarning.

    Guidance: /testbed/tests/entities/test_assessment_source.py
    (test_ai_judge_deprecation_warning).  Perspective: deprecation side effect.
    Path/symbol: ``mlflow.entities.assessment_source.AssessmentSourceType._parse``.
    """
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        assert AssessmentSourceType._parse("AI_JUDGE") == "LLM_JUDGE"

    future_warnings = [w for w in caught if issubclass(w.category, FutureWarning)]
    assert len(future_warnings) == 1, f"expected exactly one FutureWarning, got {future_warnings}"
    assert str(future_warnings[0].message) == "AI_JUDGE is deprecated. Use LLM_JUDGE instead."
    _pass("check_C04_parse_ai_judge_deprecation")


def check_C05_parse_invalid_source_type_raises() -> None:
    """C5/R4. Unsupported source types raise ``MlflowException`` with diagnostic text.

    Guidance: /testbed/tests/entities/test_assessment_source.py
    (test_assessment_source_type_validation) matches ``Invalid assessment source type``.
    Perspective: failure semantics.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSourceType._parse``.
    """
    try:
        AssessmentSourceType._parse("ROBOT")
    except MlflowException as exc:
        message = str(exc)
        assert "Invalid assessment source type" in message
        assert "ROBOT" in message
        assert "LLM_JUDGE" in message, f"valid source types not listed in error: {message}"
    else:
        raise AssertionError("_parse('ROBOT') did not raise MlflowException")
    _pass("check_C05_parse_invalid_source_type_raises")


def check_C06_assessment_source_fields() -> None:
    """C6/R2/R3/R5. Dataclass construction preserves ``source_id`` and normalizes
    ``source_type``.

    Guidance: /testbed/tests/entities/test_assessment_source.py
    (test_assessment_source_properties, test_assessment_source_case_insensitivity).
    Perspective: state/field preservation.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSource``.
    """
    source = AssessmentSource(source_type="llm_judge", source_id="gpt-4")
    assert source.source_type == "LLM_JUDGE"
    assert source.source_id == "gpt-4"

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        deprecated_source = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
    assert deprecated_source.source_type == "LLM_JUDGE"
    assert deprecated_source.source_id == "ai_1"
    assert any(issubclass(w.category, FutureWarning) for w in caught)
    _pass("check_C06_assessment_source_fields")


def check_C07_assessment_source_type_instance_str() -> None:
    """C7/R2/R3/R6. Instance constructor normalizes and ``str()`` returns the stored value.

    Guidance: Interface Description 2 ``__init__``/``__str__``; no dedicated
    repository test calls these methods directly.  Perspective: instance
    representation.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSourceType``.
    """
    assert str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        assert str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"
    assert any(issubclass(w.category, FutureWarning) for w in caught)
    _pass("check_C07_assessment_source_type_instance_str")


def check_C08_from_proto_returns_enum_name() -> None:
    """C8/R1/R7. ``from_proto`` delegates to protobuf enum name lookup.

    Guidance: /testbed/mlflow/entities/assessment_source.py lines 192-194 define
    this method.  Perspective: protobuf compatibility.  Path/symbol:
    ``mlflow.entities.assessment_source.AssessmentSourceType.from_proto``.
    """
    from mlflow.protos.assessments_pb2 import AssessmentSource as ProtoAssessmentSource

    proto_value = ProtoAssessmentSource.SourceType.Value("HUMAN")
    assert AssessmentSourceType.from_proto(proto_value) == ProtoAssessmentSource.SourceType.Name(
        proto_value
    )
    _pass("check_C08_from_proto_returns_enum_name")


# ---------------------------------------------------------------------------
# Scorer creation metadata
# ---------------------------------------------------------------------------

def check_C11_scorer_decorator_metadata() -> None:
    """C11/R9/R19. Bare and parameterized decorators store name, description, and
    aggregations on a real ``Scorer`` instance.

    Guidance: /testbed/tests/genai/scorers/test_scorer_description.py
    (test_decorator_scorer_without_description,
    test_decorator_scorer_with_name_and_description); /testbed/tests/genai/evaluate/test_utils.py
    (test_scorer_pass_through_aggregations).  Perspective: public decorator
    metadata.  Path/symbol: ``mlflow.genai.scorers.base.scorer`` -> ``Scorer``.
    """
    from mlflow.genai.scorers import scorer

    @scorer
    def bare_scorer(outputs):
        return True

    assert isinstance(bare_scorer, Scorer)
    assert bare_scorer.name == "bare_scorer"
    assert bare_scorer.description is None

    @scorer(name="custom", description="desc", aggregations=["mean", "max"])
    def parameterized_scorer(outputs):
        return True

    assert parameterized_scorer.name == "custom"
    assert parameterized_scorer.description == "desc"
    assert parameterized_scorer.aggregations == ["mean", "max"]
    _pass("check_C11_scorer_decorator_metadata")


# ---------------------------------------------------------------------------
# Scorer run outcomes and failures
# ---------------------------------------------------------------------------

def check_C13_run_passes_supported_return_values() -> None:
    """C13/R11. Supported primitive, Feedback, and list[Feedback] returns pass through.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_scorer_on_genai_evaluate).  Perspective: return-type compatibility.
    Path/symbol: ``mlflow.genai.scorers.base.Scorer.run``.
    """
    from mlflow.genai.scorers import scorer

    cases = [
        "yes",
        42,
        42.0,
        True,
        Feedback(name="custom_feedback", value=42, rationale="rationale"),
        [
            Feedback(name="big_question", value=42),
            Feedback(name="small_question", value=1),
        ],
    ]

    def make_scorer(expected):
        @scorer
        def dummy(inputs, outputs):
            return expected

        return dummy

    for expected in cases:
        actual = make_scorer(expected).run(inputs={"question": "q"}, outputs="answer")
        if isinstance(expected, bool):
            assert isinstance(actual, bool)
            assert actual == expected
        elif isinstance(expected, int) and not isinstance(expected, bool):
            assert type(actual) is int
            assert actual == expected
        elif isinstance(expected, float):
            assert type(actual) is float
            assert actual == expected
        elif isinstance(expected, str):
            assert type(actual) is str
            assert actual == expected
        else:
            assert actual is expected, f"expected run to return the original object: {actual!r}"

    _pass("check_C13_run_passes_supported_return_values")


def check_C14_run_rejects_unsupported_return_values() -> None:
    """C14/R11. Dict and list[int] returns raise the required ``MlflowException``.

    Guidance: /testbed/mlflow/genai/scorers/base.py lines 387-404 implement this
    validation.  Perspective: failure branch semantics.  Path/symbol:
    ``mlflow.genai.scorers.base.Scorer.run``.
    """
    from mlflow.genai.scorers import scorer

    def make_scorer(bad_return):
        @scorer
        def bad(inputs, outputs):
            return bad_return

        return bad

    for bad_return in ({"score": 1}, [1, 2]):
        try:
            make_scorer(bad_return).run(inputs="q", outputs="answer")
        except MlflowException as exc:
            message = str(exc)
            assert "must return one of int, float, bool, str, Feedback, or list[Feedback]" in message
        else:
            raise AssertionError(f"unsupported return {bad_return!r} did not raise MlflowException")

    _pass("check_C14_run_rejects_unsupported_return_values")


def check_C15_single_default_feedback_renamed() -> None:
    """C15/R12. A single default-named ``Feedback`` is renamed to the scorer name.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_custom_scorer_overwrites_default_feedback_name).  Perspective: feedback
    name normalization.  Path/symbol: ``mlflow.genai.scorers.base.Scorer.run``.
    """
    from mlflow.genai.scorers import scorer

    @scorer
    def my_scorer(inputs, outputs):
        return Feedback(value=42)

    feedback = my_scorer.run(inputs="q", outputs="answer")
    assert feedback.name == "my_scorer"
    assert feedback.value == 42
    _pass("check_C15_single_default_feedback_renamed")


def check_C16_list_feedback_names_preserved() -> None:
    """C16/R12. Names on a returned list of Feedback objects are not rewritten.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list).
    Perspective: list-item identity/naming.  Path/symbol:
    ``mlflow.genai.scorers.base.Scorer.run``.
    """
    from mlflow.genai.scorers import scorer

    @scorer
    def my_scorer(inputs, outputs):
        return [
            Feedback(name="big_question", value=42),
            Feedback(name="small_question", value=1),
        ]

    feedbacks = my_scorer.run(inputs="q", outputs="answer")
    assert [f.name for f in feedbacks] == ["big_question", "small_question"]
    _pass("check_C16_list_feedback_names_preserved")


def check_C17_decorator_scorer_kind() -> None:
    """C17/R13. A scorer created by ``@scorer`` reports ``ScorerKind.DECORATOR``.

    Guidance: /testbed/tests/genai/scorers/test_registered_scorers_scheduling.py
    uses decorator scorers and exercises ``_check_can_be_registered``, which
    requires the allowed decorator kind.  Perspective: type classification.
    Path/symbol: ``mlflow.genai.scorers.base.scorer`` -> ``Scorer.kind``.
    """
    from mlflow.genai.scorers import scorer

    @scorer
    def f(outputs):
        return True

    assert f.kind == ScorerKind.DECORATOR
    _pass("check_C17_decorator_scorer_kind")


def check_C32_class_based_scorer_run_supported() -> None:
    """C32/R13 (new contract for previously uncovered R13 acceptance).  Class-based
    scorers can run through ``Scorer.run`` even though registration is rejected.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_scorer_existence_in_metrics) parameterizes both ``AlwaysYesScorer(name="always_yes")``
    and ``scorer(always_yes)``.  Perspective: class-based evaluation surface.
    Path/symbol: ``mlflow.genai.scorers.base.Scorer.run`` -> subclass ``__call__``.
    """

    class AlwaysYesScorer(Scorer):
        def __call__(self, inputs, outputs, expectations, trace):
            return "yes"

    scorer_instance = AlwaysYesScorer(name="always_yes")
    assert scorer_instance.kind == ScorerKind.CLASS
    assert scorer_instance.run(inputs={}, outputs="answer", expectations={}, trace=None) == "yes"
    _pass("check_C32_class_based_scorer_run_supported")


# ---------------------------------------------------------------------------
# Scorer serialization / deserialization
# ---------------------------------------------------------------------------

def check_C18_model_dump_serialized_fields_and_cache() -> None:
    """C18/R14. ``model_dump`` returns the documented serialization schema and caches
    the resulting dict for subsequent calls.

    Guidance: /testbed/tests/genai/scorers/test_scorer_description.py
    (test_scorer_serialization) and /testbed/tests/genai/scorers/test_registered_scorers_scheduling.py
    (test_register_with_custom_name_updates_serialization).  Perspective:
    serialization representation and cache reuse.  Path/symbol:
    ``mlflow.genai.scorers.base.Scorer.model_dump``.
    """
    from mlflow.genai.scorers import scorer

    @scorer(description="serialization check")
    def test_scorer(outputs):
        return bool(outputs)

    serialized = test_scorer.model_dump()
    expected_keys = {
        "name",
        "description",
        "aggregations",
        "mlflow_version",
        "serialization_version",
        "call_source",
        "call_signature",
        "original_func_name",
    }
    assert expected_keys <= set(serialized.keys()), f"missing serialized keys: {serialized!r}"
    assert serialized["name"] == "test_scorer"
    assert serialized["description"] == "serialization check"
    assert serialized["call_signature"] == "(outputs)"
    assert serialized["original_func_name"] == "test_scorer"
    assert "bool(outputs)" in serialized["call_source"]
    assert serialized["mlflow_version"] == mlflow.__version__
    assert serialized["serialization_version"] == 1
    assert test_scorer._cached_dump is serialized, "model_dump did not populate _cached_dump"

    with _SymbolSpy("extract_function_body") as spy:
        second = test_scorer.model_dump()
    assert second is serialized, "second model_dump did not return the cached dict"
    assert spy.calls == [], f"second model_dump re-extracted function source: {spy.calls}"
    _pass("check_C18_model_dump_serialized_fields_and_cache")


def check_C19_direct_scorer_subclass_serialization_raises() -> None:
    """C19/R13/R14. Direct ``Scorer`` subclasses cannot be serialized.

    Guidance: /testbed/mlflow/genai/scorers/base.py lines 156-167.  Perspective:
    unsupported-kind failure.  Path/symbol: ``mlflow.genai.scorers.base.Scorer.model_dump``.
    """

    class DirectScorer(Scorer):
        def __call__(self, *, outputs=None):
            return True

    direct = DirectScorer(name="direct")
    try:
        direct.model_dump()
    except MlflowException as exc:
        assert "Unsupported scorer type" in str(exc)
    else:
        raise AssertionError("DirectScorer.model_dump() did not raise MlflowException")
    _pass("check_C19_direct_scorer_subclass_serialization_raises")


def check_C20_decorator_deserialization_blocked_outside_databricks() -> None:
    """C20/R15. Non-Databricks deserialization is rejected before code execution.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_custom_scorer_loading_blocked_for_non_databricks_uri).  Perspective:
    security gate.  Path/symbol: ``mlflow.genai.scorers.base.Scorer.model_validate`` ->
    ``Scorer._reconstruct_decorator_scorer``.
    """
    serialized = SerializedScorer(
        name="malicious_scorer",
        call_source="import os\nos.system('echo hacked')\nreturn True",
        call_signature="(outputs)",
        original_func_name="malicious_scorer",
    )

    with ExitStack() as stack:
        stack.enter_context(patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=False))
        stack.enter_context(patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=False))
        with _SymbolSpy("recreate_function", fail_if_called=True) as spy:
            try:
                Scorer.model_validate(serialized)
            except MlflowException as exc:
                message = str(exc)
                assert "Loading custom scorer" in message
                assert "not supported" in message
                # R15 requires a copyable code snippet in the security error.
                assert "Registered scorer code:" in message
                assert "from mlflow.genai import scorer" in message
                assert "@scorer" in message
            else:
                raise AssertionError("model_validate did not block non-Databricks custom scorer")
        assert spy.calls == [], f"recreate_function called in blocked path: {spy.calls}"
    _pass("check_C20_decorator_deserialization_blocked_outside_databricks")


def check_C21_decorator_deserialization_blocked_remote_databricks() -> None:
    """C21/R15. Remote Databricks access is rejected with a distinct message.

    Guidance: /testbed/tests/genai/scorers/test_scorer.py
    (test_custom_scorer_loading_blocked_for_databricks_remote_access).  Perspective:
    remote-access security distinction.  Path/symbol:
    ``mlflow.genai.scorers.base.Scorer.model_validate`` ->
    ``Scorer._reconstruct_decorator_scorer``.
    """
    serialized = SerializedScorer(
        name="malicious_scorer",
        call_source="import os\nos.system('echo hacked')\nreturn True",
        call_signature="(outputs)",
        original_func_name="malicious_scorer",
    )

    with ExitStack() as stack:
        stack.enter_context(patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=False))
        stack.enter_context(patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True))
        with _SymbolSpy("recreate_function", fail_if_called=True) as spy:
            try:
                Scorer.model_validate(serialized)
            except MlflowException as exc:
                message = str(exc)
                assert "via remote access is not supported" in message
                # R15 requires a copyable code snippet in the remote-access error too.
                assert "Registered scorer code:" in message
                assert "from mlflow.genai import scorer" in message
                assert "@scorer" in message
            else:
                raise AssertionError("model_validate did not block remote Databricks custom scorer")
        assert spy.calls == [], f"recreate_function called in blocked path: {spy.calls}"
    _pass("check_C21_decorator_deserialization_blocked_remote_databricks")


# ---------------------------------------------------------------------------
# Function reconstruction helper
# ---------------------------------------------------------------------------

def check_C24_recreate_function_basic() -> None:
    """C24/R17. Simple source is compiled into a named callable with expected result.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py
    (test_simple_function_recreation).  Perspective: reconstruction return value.
    Path/symbol: ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    recreated = recreate_function("return x + y", "(x, y)", "add_func")
    assert recreated.__name__ == "add_func"
    assert recreated(3, 4) == 7
    assert recreated(10, -5) == 5
    _pass("check_C24_recreate_function_basic")


def check_C24_recreate_function_control_flow_and_loops() -> None:
    """C24/R17. Reconstruction handles if/else control flow and loop bodies.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py
    (test_function_with_control_flow, test_function_with_loop).  Perspective:
    body-shape coverage.  Path/symbol:
    ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    classify_source = """if x > 0:
    return "positive"
else:
    return "non-positive" """
    classify = recreate_function(classify_source, "(x)", "classify_number")
    assert classify(5) == "positive"
    assert classify(-3) == "non-positive"
    assert classify(0) == "non-positive"

    loop_source = """total = 0
for i in range(n):
    total += i
return total"""
    sum_range = recreate_function(loop_source, "(n)", "sum_range")
    assert sum_range(5) == 10
    assert sum_range(3) == 3
    assert sum_range(0) == 0
    _pass("check_C24_recreate_function_control_flow_and_loops")


def check_C24_recreate_function_signatures() -> None:
    """C24/R17. Reconstruction parses defaults, whitespace, and complex signatures.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py
    (test_function_with_multiple_parameters, test_signature_with_whitespace,
    test_signature_with_defaults, test_complex_signature).  Perspective: signature
    parser coverage.  Path/symbol:
    ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    length_check = recreate_function(
        """if threshold is None:
    threshold = 5
return len(text) > threshold""",
        "(text, threshold=None)",
        "length_check",
    )
    assert length_check("hello") is False
    assert length_check("hello world") is True
    assert length_check("hi", 1) is True

    add_with_spaces = recreate_function("return a + b", "( a , b )", "add_with_spaces")
    assert add_with_spaces(3, 7) == 10

    power = recreate_function("return base ** exponent", "(base, exponent=2)", "power")
    assert power(3) == 9
    assert power(2, 3) == 8

    format_result = recreate_function(
        """if data is None:
    data = []
return f"{prefix}: {len(data)} items" + (suffix or "")""",
        "(data=None, prefix='Result', suffix=None)",
        "format_result",
    )
    assert format_result() == "Result: 0 items"
    assert format_result([1, 2, 3]) == "Result: 3 items"
    assert format_result([1, 2], "Count", "!") == "Count: 2 items!"
    _pass("check_C24_recreate_function_signatures")


def check_C24_recreate_function_builtin_modules_indentation_import_error() -> None:
    """C24/R17. Reconstruction handles stdlib imports, flat indentation, and runtime
    import failures without executing unavailable symbols at definition time.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py
    (test_function_using_builtin_modules, test_indentation_handling,
    test_function_with_import_error_at_runtime).  Perspective: namespace/indentation
    edge cases.  Path/symbol:
    ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    import json

    from mlflow.genai.scorers.scorer_utils import recreate_function

    json_word_count = recreate_function(
        """import json
import re
data = {"count": len(re.findall(r'\\w+', text))}
return json.dumps(data)""",
        "(text)",
        "json_word_count",
    )
    result = json_word_count("hello world test")
    assert json.loads(result)["count"] == 3

    indentation_test = recreate_function(
        """x = 1
y = 2
return x + y""",
        "()",
        "indentation_test",
    )
    assert indentation_test() == 3

    runtime_import_error = recreate_function(
        """try:
    return NonExistentClass()
except NameError:
    return "import_failed" """,
        "()",
        "runtime_import_error",
    )
    assert runtime_import_error() == "import_failed"
    _pass("check_C24_recreate_function_builtin_modules_indentation_import_error")


def check_C25_mlflow_namespace_available() -> None:
    """C25/R17. Recreated functions can use bare MLflow names and construct a full Trace.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py
    (test_mlflow_imports_available).  Perspective: namespace injection, not merely
    explicit imports.  Path/symbol:
    ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    source = """# Test all available MLflow imports
feedback = Feedback(value=True, rationale="test")
# AssessmentSource should be available too
from mlflow.entities.assessment_source import AssessmentSourceType
source_obj = AssessmentSourceType.CODE  # Use the default source type
# Test that Trace is available
from mlflow.entities import TraceInfo, TraceState, TraceData
from mlflow.entities.trace_location import (
    TraceLocation,
    TraceLocationType,
    MlflowExperimentLocation,
)
from mlflow.entities.trace import Trace
mlflow_exp_location = MlflowExperimentLocation(experiment_id="0")
trace_location = TraceLocation(
    type=TraceLocationType.MLFLOW_EXPERIMENT,
    mlflow_experiment=mlflow_exp_location
)
trace_info = TraceInfo(
    trace_id="test_trace_id",
    trace_location=trace_location,
    request_time=1000,
    state=TraceState.OK
)
trace = Trace(info=trace_info, data=TraceData())
return {"feedback": feedback, "source": source_obj, "trace": trace}"""
    recreated = recreate_function(source, "()", "test_mlflow_imports")
    result = recreated()
    assert isinstance(result["feedback"], Feedback)
    assert result["feedback"].value is True
    assert result["source"] == "CODE"
    assert isinstance(result["trace"], Trace)
    _pass("check_C25_mlflow_namespace_available")


def check_C25_trace_type_hint_reconstruction() -> None:
    """C25/R17. Signatures with ``mlflow.entities.Trace``/``Feedback`` hints compile and run.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py
    (test_function_with_mlflow_trace_type_hint).  Perspective: type-hint
    reconstruction.  Path/symbol:
    ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    source = """return Feedback(
    value=trace.info.trace_id is not None,
    rationale=f"Trace ID: {trace.info.trace_id}"
)"""
    signature = "(trace: mlflow.entities.Trace) -> mlflow.entities.Feedback"
    recreated = recreate_function(source, signature, "scorer_with_trace_type_hint")
    result = recreated(_make_trace())
    assert isinstance(result, Feedback)
    assert result.value is True
    assert "test_trace_id" in result.rationale
    _pass("check_C25_trace_type_hint_reconstruction")


def check_C26_recreate_function_failures() -> None:
    """C26/R17. Empty signature, syntax error, and empty body fail with the
    task-supported exception semantics.

    Guidance: /testbed/tests/genai/scorers/test_scorer_utils.py
    (test_empty_signature_string, test_function_with_syntax_error,
    test_empty_source_code).  Perspective: failure boundaries.  Path/symbol:
    ``mlflow.genai.scorers.scorer_utils.recreate_function``.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    try:
        recreate_function("return 1", "", "empty_sig")
    except MlflowException as exc:
        assert "Invalid signature format" in str(exc)
    else:
        raise AssertionError("empty signature did not raise MlflowException")

    try:
        recreate_function("if x > 0\n    return True", "(x)", "syntax_error_func")
    except SyntaxError as exc:
        assert "expected ':'" in str(exc)
    else:
        raise AssertionError("syntax error did not raise SyntaxError")

    try:
        recreate_function("", "()", "empty_func")
    except SyntaxError as exc:
        assert "expected an indented block" in str(exc)
    else:
        raise AssertionError("empty body did not raise SyntaxError")
    _pass("check_C26_recreate_function_failures")


# ---------------------------------------------------------------------------
# Lifecycle, sampling state, and immutability
# ---------------------------------------------------------------------------

def check_C27_status_follows_registration_and_sampling() -> None:
    """C27/R18. Status transitions UNREGISTERED -> STOPPED -> STARTED, and lifecycle
    methods call the Databricks store with exact sampling kwargs.

    Guidance: /testbed/tests/genai/scorers/test_scorer_CRUD.py
    (test_databricks_backend_scorer_operations) and
    /testbed/tests/genai/scorers/test_registered_scorers_scheduling.py
    (test_scorer_register, test_scorer_start, test_scorer_update, test_scorer_stop,
    test_scorer_register_with_experiment_id).  Perspective: lifecycle state read and
    server-boundary call args.  Path/symbol: ``mlflow.genai.scorers.base.Scorer.status``
    through ``register``/``start``/``update``/``stop``.
    """
    from mlflow.genai.scorers import scorer

    @scorer
    def f(outputs):
        return bool(outputs)

    assert f.status == ScorerStatus.UNREGISTERED

    # Register: store.add_registered_scorer must receive name, experiment_id, and
    # sample_rate=0.0 / filter_string=None.
    with ExitStack() as stack:
        _enter_databricks_common(stack)
        mock_add = stack.enter_context(
            patch("mlflow.genai.scorers.registry.DatabricksStore.add_registered_scorer")
        )
        registered = f.register(name="reg_f", experiment_id="exp123")
        assert registered is not f
        assert registered.status == ScorerStatus.STOPPED
        assert registered.sample_rate == 0.0
        assert registered.filter_string is None
        mock_add.assert_called_once_with(
            name="reg_f", scorer=ANY, sample_rate=0.0, filter_string=None, experiment_id="exp123"
        )

    # Start: positive sample rate transitions to STARTED and is sent to the store.
    with ExitStack() as stack:
        _enter_databricks_common(stack)
        mock_update = stack.enter_context(
            patch("mlflow.genai.scorers.registry.DatabricksStore.update_registered_scorer")
        )
        mock_update.return_value = _copy_with_sampling(
            registered, 0.5, filter_string="trace.status = 'OK'"
        )
        started = registered.start(
            name="reg_f",
            experiment_id="exp123",
            sampling_config=ScorerSamplingConfig(
                sample_rate=0.5, filter_string="trace.status = 'OK'"
            ),
        )
        assert started.status == ScorerStatus.STARTED
        assert started.sample_rate == 0.5
        mock_update.assert_called_once_with(
            name="reg_f",
            scorer=ANY,
            sample_rate=0.5,
            filter_string="trace.status = 'OK'",
            experiment_id="exp123",
        )

    # Update: changed sample_rate/filter_string are sent to the store.
    with ExitStack() as stack:
        _enter_databricks_common(stack)
        mock_update = stack.enter_context(
            patch("mlflow.genai.scorers.registry.DatabricksStore.update_registered_scorer")
        )
        mock_update.return_value = _copy_with_sampling(registered, 0.4, filter_string="new filter")
        updated = registered.update(
            name="reg_f",
            experiment_id="exp123",
            sampling_config=ScorerSamplingConfig(sample_rate=0.4, filter_string="new filter"),
        )
        assert updated.status == ScorerStatus.STARTED
        assert updated.sample_rate == 0.4
        mock_update.assert_called_once_with(
            name="reg_f",
            scorer=ANY,
            sample_rate=0.4,
            filter_string="new filter",
            experiment_id="exp123",
        )

    # Stop: delegates to update with sample_rate=0.0.
    with ExitStack() as stack:
        _enter_databricks_common(stack)
        mock_update = stack.enter_context(
            patch("mlflow.genai.scorers.registry.DatabricksStore.update_registered_scorer")
        )
        mock_update.return_value = _copy_with_sampling(registered, 0.0)
        stopped = registered.stop(name="reg_f", experiment_id="exp123")
        assert stopped.status == ScorerStatus.STOPPED
        assert stopped.sample_rate == 0.0
        mock_update.assert_called_once_with(
            name="reg_f", scorer=ANY, sample_rate=0.0, filter_string=None, experiment_id="exp123"
        )

    _pass("check_C27_status_follows_registration_and_sampling")


def check_C28_lifecycle_methods_are_immutable() -> None:
    """C28/R18. Lifecycle methods return new instances and leave original state/cache unchanged.

    Guidance: /testbed/tests/genai/scorers/test_registered_scorers_scheduling.py
    (test_all_methods_are_immutable, test_scorer_register).  Perspective:
    copy-on-write lifecycle state.  Path/symbol:
    ``mlflow.genai.scorers.base.Scorer.register/start/update/stop``.
    """
    from mlflow.genai.scorers import scorer

    @scorer
    def original_scorer(outputs):
        return bool(outputs)

    original = original_scorer
    original_dump = original.model_dump()
    cached_before = original._cached_dump
    name_before = original.name
    sampling_before = original._sampling_config

    with ExitStack() as stack:
        _enter_databricks_common(stack)
        mock_add = stack.enter_context(
            patch("mlflow.genai.scorers.registry.DatabricksStore.add_registered_scorer")
        )
        mock_update = stack.enter_context(
            patch("mlflow.genai.scorers.registry.DatabricksStore.update_registered_scorer")
        )

        registered = original.register(name="new_name")
        assert registered is not original
        assert original.name == name_before
        assert original._sampling_config is sampling_before
        assert original._cached_dump is cached_before
        mock_add.assert_called_once()

        mock_update.return_value = _copy_with_sampling(original, 0.9)
        started = original.start(sampling_config=ScorerSamplingConfig(sample_rate=0.9))
        assert started is not original
        assert original.name == name_before
        assert original._sampling_config is sampling_before
        assert original._cached_dump is cached_before

        mock_update.return_value = _copy_with_sampling(original, 0.1, filter_string="new filter")
        updated = original.update(
            sampling_config=ScorerSamplingConfig(sample_rate=0.1, filter_string="new filter")
        )
        assert updated is not original
        assert original.name == name_before
        assert original._sampling_config is sampling_before
        assert original._cached_dump is cached_before

        mock_update.return_value = _copy_with_sampling(original, 0.0)
        stopped = original.stop()
        assert stopped is not original
        assert original.name == name_before
        assert original._sampling_config is sampling_before
        assert original._cached_dump is cached_before

        assert mock_update.call_count == 3
        # The original dump is still the value observed before lifecycle mutations.
        assert original.model_dump() == original_dump

    _pass("check_C28_lifecycle_methods_are_immutable")


def check_C29_class_based_scorer_registration_rejected() -> None:
    """C29/R13/R18. Class-based scorers are rejected by all registration/lifecycle methods.

    Guidance: /testbed/tests/genai/scorers/test_registered_scorers_scheduling.py
    (test_class_scorer_cannot_be_registered).  Perspective: kind-based lifecycle
    failure.  Path/symbol: ``mlflow.genai.scorers.base.Scorer._check_can_be_registered``
    reached through ``register``/``start``/``update``/``stop``.
    """

    class CustomScorer(Scorer):
        def __call__(self, *, outputs=None):
            return True

    custom = CustomScorer(name="custom")

    with ExitStack() as stack:
        _enter_databricks_common(stack)
        operations = [
            ("register", lambda: custom.register()),
            (
                "start",
                lambda: custom.start(sampling_config=ScorerSamplingConfig(sample_rate=0.5)),
            ),
            (
                "update",
                lambda: custom.update(sampling_config=ScorerSamplingConfig(sample_rate=0.5)),
            ),
            ("stop", lambda: custom.stop()),
        ]
        for name, operation in operations:
            try:
                operation()
            except MlflowException as exc:
                assert "Scorer must be a builtin or decorator scorer" in str(exc), (
                    f"{name} raised wrong message: {exc}"
                )
            else:
                raise AssertionError(f"{name} did not reject class-based scorer")

    _pass("check_C29_class_based_scorer_registration_rejected")


# ---------------------------------------------------------------------------
# Aggregation configuration
# ---------------------------------------------------------------------------

def check_C30_scorer_preserves_aggregations() -> None:
    """C30/R19. String and callable aggregation lists are preserved on the scorer.

    Guidance: /testbed/tests/genai/evaluate/test_utils.py
    (test_scorer_pass_through_aggregations).  Perspective: aggregation field
    pass-through.  Path/symbol: ``mlflow.genai.scorers.base.scorer`` -> ``Scorer``.
    """
    from mlflow.genai.scorers import scorer

    @scorer(aggregations=["mean", "max"])
    def string_aggregations(outputs):
        return 1.0

    assert string_aggregations.aggregations == ["mean", "max"]

    @scorer(aggregations=[sum, max])
    def callable_aggregations(outputs):
        return 1.0

    assert callable_aggregations.aggregations == [sum, max]
    _pass("check_C30_scorer_preserves_aggregations")


def check_C31_invalid_aggregation_string_rejected_at_compute() -> None:
    """C31/R19. Invalid string aggregation names fail in the real aggregation path.

    Review finding F5: scorer creation does not have repository/IR support for eager
    ``MlflowException``.  The repository-supported behavior is a ``ValueError`` from
    ``_compute_aggregations`` when an unknown string aggregation is actually computed.

    Guidance: no repository test exercises this exact branch; /testbed/mlflow/genai/scorers/aggregation.py
    implements ``_compute_aggregations`` with ``raise ValueError("Invalid aggregation: ...")``.
    Perspective: late aggregation validation.  Path/symbol:
    ``mlflow.genai.scorers.aggregation._compute_aggregations``.
    """
    from mlflow.genai.scorers.aggregation import _compute_aggregations

    try:
        _compute_aggregations([1.0, 2.0], ["bogus"])
    except ValueError as exc:
        message = str(exc)
        assert "Invalid aggregation" in message
        assert "bogus" in message
    else:
        raise AssertionError("_compute_aggregations([1.0, 2.0], ['bogus']) did not raise ValueError")
    _pass("check_C31_invalid_aggregation_string_rejected_at_compute")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

_CHECKS = [
    check_C01_assessment_source_constants,
    check_C02_parse_case_insensitive,
    check_C03_standardize_case_insensitive,
    check_C04_parse_ai_judge_deprecation,
    check_C05_parse_invalid_source_type_raises,
    check_C06_assessment_source_fields,
    check_C07_assessment_source_type_instance_str,
    check_C08_from_proto_returns_enum_name,
    check_C11_scorer_decorator_metadata,
    check_C13_run_passes_supported_return_values,
    check_C14_run_rejects_unsupported_return_values,
    check_C15_single_default_feedback_renamed,
    check_C16_list_feedback_names_preserved,
    check_C17_decorator_scorer_kind,
    check_C32_class_based_scorer_run_supported,
    check_C18_model_dump_serialized_fields_and_cache,
    check_C19_direct_scorer_subclass_serialization_raises,
    check_C20_decorator_deserialization_blocked_outside_databricks,
    check_C21_decorator_deserialization_blocked_remote_databricks,
    check_C24_recreate_function_basic,
    check_C24_recreate_function_control_flow_and_loops,
    check_C24_recreate_function_signatures,
    check_C24_recreate_function_builtin_modules_indentation_import_error,
    check_C25_mlflow_namespace_available,
    check_C25_trace_type_hint_reconstruction,
    check_C26_recreate_function_failures,
    check_C27_status_follows_registration_and_sampling,
    check_C28_lifecycle_methods_are_immutable,
    check_C29_class_based_scorer_registration_rejected,
    check_C30_scorer_preserves_aggregations,
    check_C31_invalid_aggregation_string_rejected_at_compute,
]


def _main() -> None:
    failures = []
    for check in _CHECKS:
        name = check.__name__
        try:
            check()
        except Exception as exc:  # noqa: BLE001 - executable spec should report all failures
            print(f"FAIL: {name}: {exc}")
            traceback.print_exc()
            failures.append(name)
        else:
            print(f"PASS: {name}")

    if failures:
        print(f"FAILED_CHECKS: {failures}")
        sys.exit(1)


if __name__ == "__main__":
    _main()
