# Spec Review Report

## Evidence Reviewed

Read in full before source/tests inspection:

- `/agent-logs/codespec2/pandas-dev__pandas.82fa2715.test_concat.ebe5de39.lv1_20260813_023744/artifacts/semantic_ir.md`
- `/agent-logs/codespec2/pandas-dev__pandas.82fa2715.test_concat.ebe5de39.lv1_20260813_023744/artifacts/arch_spec.py`
- `/agent-logs/codespec2/pandas-dev__pandas.82fa2715.test_concat.ebe5de39.lv1_20260813_023744/artifacts/behavior_spec.py`
- `/agent-logs/codespec2/pandas-dev__pandas.82fa2715.test_concat.ebe5de39.lv1_20260813_023744/artifacts/static_issues.md`
- `/agent-logs/codespec2/pandas-dev__pandas.82fa2715.test_concat.ebe5de39.lv1_20260813_023744/artifacts/static_analysis.md`
- `/installed-agent/codespec2/review_skill.md`

Repository source inspected:

- `pandas/core/reshape/concat.py` (overloads only; helpers `_sanitize_mixed_ndim`, `new_axes`, `_get_concat_axis_dataframe`, `_make_concat_multiindex`)
- `pandas/core/internals/concat.py` (uses `concat_compat` at lines 136, 139, 396, 400; no import)
- `pandas/core/dtypes/concat.py` (blank region after `_is_nonempty`; no `concat_compat`)
- `pandas/core/indexes/base.py` and `pandas/core/indexes/api.py` (other-axis union/join helpers)
- `pandas/core/reshape/api.py` and `pandas/__init__.py` (top-level import route)

Repository tests inspected:

- `pandas/tests/reshape/concat/test_concat.py`
- `pandas/tests/reshape/concat/test_index.py`
- `pandas/tests/reshape/concat/test_dataframe.py`
- `pandas/tests/reshape/concat/test_invalid.py`
- `pandas/tests/reshape/concat/test_sort.py`
- `pandas/tests/reshape/concat/test_series.py`
- `pandas/tests/reshape/concat/test_categorical.py`
- `pandas/tests/dtypes/test_concat.py`

No generated spec was executed; no production code or test code was modified.

## Rubric Scores

| Rubric | Score | Evidence | Affected R/E/C IDs |
|---|---|---|---|
| Requirement coverage | FAIL | Missing checks for invalid `join`; successful `keys`/`levels`/`names` on axis=1 and unequal input indexes; other-axis unanimous index-name preservation. | R4, R5, R6, C11, C17 |
| Requirement fidelity | FAIL | C30 asserts object blocks share memory on axis=1, but repository test and `internals/concat.py` show object/numpy blocks are freshly allocated by `np.concatenate`. | R11, C30 |
| Caller binding and architecture | PASS | C1/C2 bind top-level and module entry; C15/C16 execute public `pd.concat` through `_get_concat_axis_dataframe` -> `_concat_indexes`; C25/C26 exercise `concat_compat` directly and through `pd.concat`. | C1, C2, C15, C16, C25, C26 |
| Dataflow and lifecycle | WEAK | Dtype, categorical, sparse, empty/all-NA, subclass, attrs, and index-identity checks are mostly exact, but C30's object-memory expectation is stronger than repository-supported behavior. | R8, R10, R11, C20-C28, C30 |
| Failure and compatibility | FAIL | `_raises` uses substring containment for several diagnostics where repository tests use full `re.search` patterns; invalid `join` is absent. | R3, R4, R5, C6, C10, C12, C14 |
| Static-issue closure strength | WEAK | On-path `_concat_indexes` is closed at line 721 via C15/C16 and `concat_compat` is closed via C25/C26, but `_concat_indexes` line 885 (inside `_make_concat_multiindex`'s `not all_indexes_same` branch) is never reached by a successful keys check. | R12, C11, C15, C16 |
| Chain integrity | WEAK | C11 uses equal row indexes, so it bypasses `_make_concat_multiindex`'s unequal-index branch that calls `_concat_indexes` at line 885; no successful axis=1 keys/levels path is present. | R5, R12, N7, N8, E8, E9 |
| Repository-test alignment | WEAK | Generated specs adapt many repo tests, but miss `test_concat_with_group_keys`, `test_concat_keys_specific_levels`, `test_concat_series_axis1_names_applied`, `test_concat_same_index_names`, and do not match the dtype-branch precision of `test_concat_copy`. | C11, C17, C30 |
| Oracle strength | WEAK | Several failure needles are loose substrings; C25 computes its categorical expectation via `pd.concat`, which is partially circular for the same helper under test. | C6, C10, C12, C14, C25 |

## Findings

### Finding 1

- Type: `requirement_misread`
- Affected IDs: C30, R11, E10, N10
- Static issue: none
- Evidence:
  - `pandas/tests/reshape/concat/test_concat.py::test_concat_copy` (lines 48-66) branches by dtype. For object blocks it asserts only `arr.base is not None`; it does **not** assert `np.shares_memory` with the source object block.
  - `pandas/core/internals/concat.py` lines 132-134 route non-extension uniform join units through `np.concatenate`, which allocates a new array; a read-only NumPy check confirms `np.concatenate` returns `base is None` and `np.shares_memory` is false for object inputs.
  - `behavior_spec.py::check_C30_axis1_copy_memory_sharing` asserts for every object result block: `any(np.shares_memory(arr, src) for src in object_blocks)`, which a correct pandas implementation would fail.
- Gap: The spec overstates copy=False memory sharing for object/numpy blocks. It turns a dtype-specific repository expectation into a uniform and stronger memory-sharing assertion.
- Rework: Replicate the repository test's dtype branches. For object blocks assert `arr.base is not None`; keep memory-sharing assertions only for dtype branches where the repository test demonstrates sharing (e.g., float/int/string blocks).

### Finding 2

- Type: `missing_requirement`
- Affected IDs: R5, R12, C11, C15, C16, N7, N8, E8, E9
- Static issue: `_concat_indexes` (`pandas/core/reshape/concat.py` lines 721 and 885)
- Evidence:
  - `pandas/tests/reshape/concat/test_concat.py::test_concat_with_group_keys` (lines 85-112) constructs successful MultiIndex keys on both axis=0 with unequal row indexes and axis=1 with unequal columns.
  - `pandas/tests/reshape/concat/test_concat.py::test_concat_keys_specific_levels` (lines 114-131) constructs a successful axis=1 `keys`/`levels`/`names` result.
  - `pandas/tests/reshape/concat/test_series.py::test_concat_series_axis1_names_applied` (line 106) verifies Series axis=1 keys/names.
  - Generated `check_C11` only uses axis=0 with row indexes that are both `RangeIndex(0, 1)`, so it enters `_make_concat_multiindex`'s `all_indexes_same` branch and never executes line 885. `check_C13` only covers axis=1 key-length failure.
- Gap: Successful construction of a concat-axis MultiIndex via `keys`/`levels`/`names` on axis=1, and the unequal-index branch of `_make_concat_multiindex` that calls `_concat_indexes` at line 885, are unobserved. An implementation can pass all current checks while mis-handling these paths.
- Rework: Add checks that:
  - `pd.concat([df_3rows, df2_4rows], keys=[0,1])` and `pd.concat([df_3cols, df2_4cols], keys=[0,1], axis=1)` match `test_concat_with_group_keys`.
  - `pd.concat([df, df2, df, df2], axis=1, keys=..., levels=..., names=...)` matches `test_concat_keys_specific_levels`.
  - `pd.concat([s, s2], axis=1, keys=["a","b"], names=["A"])` matches `test_concat_series_axis1_names_applied`.

### Finding 3

- Type: `missing_requirement`
- Affected IDs: R4
- Static issue: none
- Evidence:
  - Interface Description 1 Raises: `ValueError ... If join parameter is not 'inner' or 'outer'.`
  - Neither `arch_spec.py` nor `behavior_spec.py` contains a check for `join="invalid"` or any invalid `join` value.
- Gap: A required public failure mode is completely unobserved. A candidate implementation that accepts arbitrary `join` strings would pass every generated check.
- Rework: Add a failure check such as `_raises(ValueError, "Only can inner (intersect) or outer (union) join the other axis", pd.concat, [df, df], join="invalid")` using the repository-supported message, or the exact message from the intended pandas implementation.

### Finding 4

- Type: `weak_constraint`
- Affected IDs: C6, C10, C12, C14; R3, R4, R5
- Static issue: none
- Evidence:
  - `pandas/tests/reshape/concat/test_invalid.py::test_concat_invalid` and `::test_concat_invalid_first_argument` use full `pytest.raises(match=...)` patterns including object type and `you passed an object of type "DataFrame"`.
  - `pandas/tests/reshape/concat/test_concat.py::test_concat_with_moot_ignore_index_and_keys` uses the full `"Cannot set ignore_index=True and specify keys. Either should be used."` pattern.
  - `pandas/tests/reshape/concat/test_index.py::test_concat_with_duplicated_levels` uses `r"Level values not unique: \['x', 'y', 'y'\]"`.
  - Generated `_raises` only checks `needle in str(err)`, so the shorter needles in C6, C10, C12, and C14 accept messages that would fail repository tests.
- Gap: The checks cannot distinguish correct diagnostics from plausible wrong implementations that include only the common phrase.
- Rework: Change `_raises` to use `re.search` with the full repository regex (or assert full exact strings) for each failure path, including object type for invalid elements, the full first-argument message, the full ignore_index message, and the full level-duplication message.

### Finding 5

- Type: `weak_constraint`
- Affected IDs: C2, R1
- Static issue: none
- Evidence:
  - Interface Description 1 declares `def concat(objs, *, axis=0, join="outer", ignore_index=False, keys=None, levels=None, names=None, verify_integrity=False, sort=False, copy=lib.no_default)` and `@set_module('pandas')`.
  - `arch_spec.py::check_C2` verifies parameter names and asserts only `axis` and `copy` are keyword-only. It does not verify the other parameters are keyword-only, does not verify default values, and does not verify the `@set_module("pandas")` effect (`concat.__module__ == "pandas"`).
- Gap: A candidate with positional-or-keyword `join`, `ignore_index`, `keys`, etc., or wrong defaults, would pass the generated signature check even though the public interface is keyword-only.
- Rework: Assert every parameter after `objs` has `kind is inspect.Parameter.KEYWORD_ONLY`, assert the exact defaults from the interface, and assert `concat.__module__ == "pandas"` (or otherwise observe `@set_module`).

### Finding 6

- Type: `missing_requirement`
- Affected IDs: R6, C17
- Static issue: none
- Evidence:
  - `pandas/tests/reshape/concat/test_index.py::test_concat_same_index_names` (lines 55-100) verifies that when non-concatenation axis indexes have unanimous names, the joined result retains that name.
  - Generated `check_C17` covers outer/inner order and sort, and `check_C18` covers the DatetimeIndex forced-sort exception, but neither observes non-concatenation axis index-name preservation.
- Gap: R6 explicitly includes "Index names are preserved when unanimous," but this clause has no executable observation.
- Rework: Add a check analogous to `test_concat_same_index_names` with three DataFrames concatenated along axis=1, all index names `"idx"`, asserting `result.index.name == "idx"` and full frame equality for a representative unanimous/name-dropping case.

## Decision

Decision: REWORK
