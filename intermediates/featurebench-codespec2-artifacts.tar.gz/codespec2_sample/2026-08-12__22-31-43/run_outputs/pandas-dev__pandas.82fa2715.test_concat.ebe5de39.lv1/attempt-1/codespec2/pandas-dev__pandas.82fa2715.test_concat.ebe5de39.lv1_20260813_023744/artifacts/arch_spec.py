"""
Executable architecture spec for the ``pandas.concat`` typed semantic IR.

This file compiles the dependency/import-boundary and real delegation-path
contracts from semantic_ir.md into runtime checks.  It intentionally does not
prove every behavioral outcome; behavior_spec.py owns the state/outcome matrix.
"""

from __future__ import annotations

import inspect
import re
import sys
from decimal import Decimal

import numpy as np
import pandas as pd
import pandas._testing as tm
from pandas import Series
from pandas._libs import lib
from pandas.tests.extension.decimal import to_decimal


def _raises(exc_type, pattern, func, *args, **kwargs):
    try:
        func(*args, **kwargs)
    except exc_type as err:
        assert re.search(pattern, str(err)), f"expected pattern {pattern!r} in {err!r}"
        return
    except Exception as err:  # pragma: no cover - diagnostic aid
        raise AssertionError(
            f"expected {exc_type.__name__} matching {pattern!r}, "
            f"got {type(err).__name__}: {err}"
        ) from err
    raise AssertionError(
        f"expected {exc_type.__name__} matching {pattern!r}, got no exception"
    )


# Off-path static issue dispositions (from static_issues.md / static_analysis.md):
# - pandas/core/frame.py ``concat_compat`` inside DataFrame._reduce -> reduction
#   public APIs, dead-end before the required concat entry.
# - pandas/core/generic.py ``concat`` inside astype/compare -> astype/compare.
# - pandas/core/methods/describe.py ``concat`` -> describe public API.
# - pandas/core/resample.py ``concat`` -> Resampler.interpolate.
# - pandas/core/reshape/melt.py ``concat``/``concat_compat`` -> melt/lreshape/wide_to_long.
# - pandas/core/reshape/pivot.py ``concat`` -> pivot_table.
# - pandas/core/window/rolling.py ``concat`` -> Rolling._apply_pairwise.
# - pandas/io/json/_json.py and pandas/io/pytables.py ``concat`` -> IO readers.
# These dead-ends do not reach the required ``pandas.concat`` entry, so they are
# dispositioned inapplicable for the on-path runtime checks below.  The on-path
# ``_concat_indexes`` issues are closed by check_C15/C16 (line 721 path) and
# check_C15b/C16b (line 885 path).  ``concat_compat`` is closed by check_C25
# (direct lower-layer) and check_C26 (real internals delegation through pd.concat).


def check_C1_top_level_pandas_concat_import_boundary():
    # Contracts: C1 (R1, R13). Repo guidance: pandas/tests/reshape/concat/test_concat.py
    # imports ``concat`` from pandas. Perspective: public export binding and callability.
    # Source path/symbol: pandas/__init__.py -> pandas.core.reshape.concat.concat.
    from pandas import concat as top_concat
    from pandas.core.reshape.concat import concat as impl_concat

    assert callable(top_concat)
    assert top_concat is impl_concat
    result = top_concat([Series([1, 2])])
    assert isinstance(result, Series)
    assert result.tolist() == [1, 2]


def check_C2_module_concat_import_boundary_and_signature():
    # Contracts: C2 (R1, R13). Repo guidance: Interface Description 1 path and
    # pandas/tests/reshape/concat/test_concat.py::test_concat_no_items_raises.
    # Perspective: module-level callable must be the real implementation, with the
    # exact keyword-only signature/defaults and @set_module("pandas") effect.
    # Source path/symbol: pandas/core/reshape/concat.py::concat.
    from pandas.core.reshape.concat import concat

    result = concat([Series([1, 2])])
    assert isinstance(result, Series)
    assert result.tolist() == [1, 2]

    sig = inspect.signature(concat)
    assert list(sig.parameters) == [
        "objs",
        "axis",
        "join",
        "ignore_index",
        "keys",
        "levels",
        "names",
        "verify_integrity",
        "sort",
        "copy",
    ]

    for name in list(sig.parameters)[1:]:
        assert sig.parameters[name].kind is inspect.Parameter.KEYWORD_ONLY, (
            f"{name} must be keyword-only, got {sig.parameters[name].kind}"
        )

    assert sig.parameters["axis"].default == 0
    assert sig.parameters["join"].default == "outer"
    assert sig.parameters["ignore_index"].default is False
    assert sig.parameters["keys"].default is None
    assert sig.parameters["levels"].default is None
    assert sig.parameters["names"].default is None
    assert sig.parameters["verify_integrity"].default is False
    assert sig.parameters["sort"].default is False
    assert sig.parameters["copy"].default is lib.no_default

    # @set_module("pandas") is part of the public interface declaration.
    assert concat.__module__ == "pandas", concat.__module__

    _raises(ValueError, "No objects to concatenate", concat, [])


def check_C15_concat_indexes_on_path_via_public_concat():
    # Contracts: C15 (R12, R5). Repo guidance:
    # pandas/tests/reshape/concat/test_index.py::test_concat_same_index_names and
    # test_concat_copy_index_frame. Perspective: the public entry must execute
    # _get_concat_axis_dataframe -> _concat_indexes without NameError and preserve
    # the concat-axis dtype/name. Source path/symbol:
    # pandas/core/reshape/concat.py::_get_concat_axis_dataframe -> _concat_indexes.
    idx = pd.Index(["x", "y"], name="idx")
    df1 = pd.DataFrame({"a": [1, 2]}, index=idx)
    df2 = pd.DataFrame({"a": [3]}, index=pd.Index(["z"], name="idx"))

    result = pd.concat([df1, df2])

    expected_index = pd.Index(["x", "y", "z"], name="idx")
    assert result.index.equals(expected_index)
    assert result.index.name == "idx"
    expected = pd.DataFrame({"a": [1, 2, 3]}, index=expected_index)
    tm.assert_frame_equal(result, expected)


def check_C15b_concat_indexes_unequal_axis0_keys_on_path():
    # Contracts: C15b (R12, R5). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_with_group_keys (axis=0).
    # Perspective: when keys are provided and input indexes differ in length, the
    # public path reaches _make_concat_multiindex's ``not all_indexes_same`` branch
    # and calls _concat_indexes at line 885. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> _make_concat_multiindex -> _concat_indexes.
    df = pd.DataFrame(np.random.default_rng(2).standard_normal((3, 4)))
    df2 = pd.DataFrame(np.random.default_rng(2).standard_normal((4, 4)))

    result = pd.concat([df, df2], keys=[0, 1])

    exp_index = pd.MultiIndex.from_arrays(
        [[0, 0, 0, 1, 1, 1, 1], [0, 1, 2, 0, 1, 2, 3]]
    )
    expected = pd.DataFrame(np.r_[df.values, df2.values], index=exp_index)
    tm.assert_frame_equal(result, expected)


def check_C16_concat_indexes_multiindex_and_categorical_on_path():
    # Contracts: C16 (R12, R5, R8). Repo guidance:
    # pandas/tests/reshape/concat/test_index.py::test_concat_multiindex_rangeindex
    # and pandas/tests/reshape/concat/test_concat.py::test_concat_multiindex_with_category.
    # Perspective: the same _concat_indexes observer must preserve MultiIndex and
    # CategoricalIndex concat-axis structures. Source path/symbol:
    # pandas/core/reshape/concat.py::_concat_indexes.

    # MultiIndex concat axis (axis=1 columns are the concat axis).
    left_mi = pd.MultiIndex.from_product([["A"], ["a", "b"]])
    right_mi = pd.MultiIndex.from_product([["A"], ["c"]])
    df1 = pd.DataFrame([[1, 2]], index=[0], columns=left_mi)
    df2 = pd.DataFrame([[3]], index=[0], columns=right_mi)
    result = pd.concat([df1, df2], axis=1)
    expected_mi = pd.MultiIndex.from_tuples([("A", "a"), ("A", "b"), ("A", "c")])
    assert result.columns.equals(expected_mi)

    # CategoricalIndex concat axis (axis=1 columns are the concat axis).
    cat1 = pd.CategoricalIndex(["a", "b"], categories=["a", "b", "c"])
    cat2 = pd.CategoricalIndex(["c"], categories=["a", "b", "c"])
    df3 = pd.DataFrame([[1, 2]], index=[0], columns=cat1)
    df4 = pd.DataFrame([[3]], index=[0], columns=cat2)
    result = pd.concat([df3, df4], axis=1)
    expected_cat = pd.CategoricalIndex(["a", "b", "c"], categories=["a", "b", "c"])
    assert result.columns.equals(expected_cat)


def check_C16b_concat_indexes_unequal_axis1_keys_on_path():
    # Contracts: C16b (R12, R5). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_with_group_keys (axis=1).
    # Perspective: same line-885 _concat_indexes path, but with the concat axis=1
    # and unequal column counts, so the columns become the keyed MultiIndex.
    # Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> _make_concat_multiindex -> _concat_indexes.
    df = pd.DataFrame(np.random.default_rng(2).standard_normal((4, 3)))
    df2 = pd.DataFrame(np.random.default_rng(2).standard_normal((4, 4)))

    result = pd.concat([df, df2], keys=[0, 1], axis=1)

    exp_columns = pd.MultiIndex.from_arrays(
        [[0, 0, 0, 1, 1, 1, 1], [0, 1, 2, 0, 1, 2, 3]]
    )
    expected = pd.DataFrame(np.c_[df.values, df2.values], columns=exp_columns)
    tm.assert_frame_equal(result, expected)


def check_C25_concat_compat_module_import_and_array_behavior():
    # Contracts: C25 (R9, R13). Repo guidance:
    # pandas/tests/dtypes/test_concat.py::test_concat_mismatched_categoricals_with_empty
    # and test_concat_periodarray_2d. Perspective: the lower representation-layer
    # helper must be directly importable and concatenate categorical/PeriodArray data.
    # Expected Categorical is constructed independently here to avoid a circular
    # pd.concat oracle for the same helper. Source path/symbol:
    # pandas/core/dtypes/concat.py::concat_compat.
    import pandas.core.dtypes.concat as _concat

    ser1 = pd.Series(["a", "b", "c"], dtype="category")
    ser2 = pd.Series([], dtype="category")
    result = _concat.concat_compat([ser1._values, ser2._values])
    expected = pd.Categorical(["a", "b", "c"], categories=["a", "b", "c"])
    tm.assert_categorical_equal(result, expected)

    pi = pd.period_range("2016-01-01", periods=36, freq="D")
    arr = pi._data.reshape(6, 6)
    result = _concat.concat_compat([arr[:2], arr[2:]], axis=0)
    tm.assert_period_array_equal(result, arr)
    result = _concat.concat_compat([arr[:, :2], arr[:, 2:]], axis=1)
    tm.assert_period_array_equal(result, arr)


def check_C26_concat_compat_on_path_through_public_concat():
    # Contracts: C26 (R9, R13). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_ea_upcast and
    # test_concat_different_extension_dtypes_upcasts. Perspective: public
    # pd.concat must survive the internals.concatenate_managers ->
    # _concatenate_join_units -> concat_compat delegation chain without NameError.
    # Source path/symbol: pandas/core/internals/concat.py::concatenate_managers
    # and _concatenate_join_units.
    df1 = pd.DataFrame(["a"], dtype="string")
    df2 = pd.DataFrame([1], dtype="Int64")
    result = pd.concat([df1, df2])
    expected = pd.DataFrame(["a", 1], index=[0, 0])
    tm.assert_frame_equal(result, expected)
    assert result.iloc[0, 0] == "a"
    assert result.iloc[1, 0] == 1

    left = pd.Series(pd.array([1, 2], dtype="Int64"))
    right = pd.Series(to_decimal([1, 2]))
    result = pd.concat([left, right], ignore_index=True)
    expected = pd.Series([1, 2, Decimal(1), Decimal(2)], dtype=object)
    tm.assert_series_equal(result, expected)


def _main():
    checks = [
        check_C1_top_level_pandas_concat_import_boundary,
        check_C2_module_concat_import_boundary_and_signature,
        check_C15_concat_indexes_on_path_via_public_concat,
        check_C15b_concat_indexes_unequal_axis0_keys_on_path,
        check_C16_concat_indexes_multiindex_and_categorical_on_path,
        check_C16b_concat_indexes_unequal_axis1_keys_on_path,
        check_C25_concat_compat_module_import_and_array_behavior,
        check_C26_concat_compat_on_path_through_public_concat,
    ]
    for check in checks:
        check()
        print(f"PASS: {check.__name__}")


if __name__ == "__main__":
    try:
        _main()
    except Exception:
        import traceback

        traceback.print_exc()
        sys.exit(1)
