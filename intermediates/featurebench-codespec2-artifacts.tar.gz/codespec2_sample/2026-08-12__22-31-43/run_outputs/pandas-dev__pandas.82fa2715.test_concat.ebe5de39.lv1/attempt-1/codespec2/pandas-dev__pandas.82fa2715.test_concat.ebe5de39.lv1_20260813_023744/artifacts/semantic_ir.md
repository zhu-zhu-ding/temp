# Semantic IR

IR = <R, G, C> for the task-declared public entry
`/testbed/pandas/core/reshape/concat.py::concat`.

Static findings were read in full and are closed below. The declared
interface is `concat`; repository tests provide implementation perspective, not
hidden requirements.

---

## L1. Requirement Obligations

### R1: Public callable and import surface
- Type: Interface / Compatibility
- Statement: `concat` MUST be importable both as `pandas.concat` and as
  `pandas.core.reshape.concat.concat`; the bound object MUST be a callable
  implementation, not the current `typing.overload` dummy.
- Task Evidence: Interface Description 1 path is
  `/testbed/pandas/core/reshape/concat.py` and examples call `pd.concat`.
- Acceptance: `from pandas import concat` succeeds; calling
  `concat([Series(...)])` returns a pandas object; the implementation has the
  keyword signature `(objs, *, axis=0, join="outer", ignore_index=False,
  keys=None, levels=None, names=None, verify_integrity=False, sort=False,
  copy=lib.no_default)` and is decorated with `@set_module("pandas")`.
- Repository Evidence:
  - `/testbed/pandas/core/reshape/concat.py` lines 74-151 contain only
    `@overload` declarations; calling the imported object raises
    `NotImplementedError` (runtime introspection).
  - `/testbed/pandas/__init__.py` line 286 lists `"concat"` in `__all__`, but
    no import of `concat` exists in the file (`grep -n concat pandas/__init__.py`
    finds only line 286).
  - `/testbed/pandas/core/reshape/api.py` line 27 lists `"concat"` in
    `__all__`, but the module imports `concat` nowhere.
  - `pandas/tests/reshape/concat/test_concat.py` line 19 imports
    `concat` from `pandas`.
- Uncertainty: The exact top-level import route (direct in `pandas/__init__.py`
  versus via `pandas.core.reshape.api`) is not present in source; either route
  must satisfy the public binding.

### R2: Collection normalization, None filtering, and empty handling
- Type: Behavior / Failure
- Statement: `objs` may be any iterable or a mapping. Mapping keys become the
  `keys` argument when `keys is None`. `None` entries are dropped. An empty
  collection raises `ValueError("No objects to concatenate")`; a collection of
  only `None` raises `ValueError("All objects passed were None")`. Generators,
  `deque`, and custom iterable/`__getitem__` objects are accepted.
- Task Evidence: Interface docstring "objs : an iterable or mapping",
  "Any None objects will be dropped silently unless they are all None in which
  case a ValueError will be raised"; Raises list.
- Acceptance: The exceptions above and mapping-to-keys equivalence are observed.
- Repository Evidence:
  - `pandas/tests/reshape/concat/test_concat.py`:
    `test_concat_mapping`, `test_concat_iterables`, `test_concat_exclude_none`,
    `test_concat_keys_with_none`, `test_concat_no_items_raises`.
  - `pandas/tests/reshape/concat/test_invalid.py`:
    `test_concat_generator_obj`, `test_concat_textreader_obj`.
- Uncertainty: Exact diagnostic wording for empty/all-None is from repository
  tests and may be asserted with `pytest.raises(..., match=...)`.

### R3: Object validation and mixed Series/DataFrame normalization
- Type: Behavior / Failure
- Statement: Every non-None element must be a `Series` or `DataFrame`.
  A non-iterable first argument raises a specific `TypeError`. An invalid
  object in the collection raises `TypeError`. Mixed `Series` and `DataFrame`
  inputs are normalized to the highest ndim by `_sanitize_mixed_ndim`; a
  mix that is not exactly ndim `max` and `max-1` raises
  `ValueError("cannot concatenate unaligned mixed dimensional NDFrame objects")`.
- Task Evidence: Interface docstring Raises
  `TypeError: If first argument is not an iterable of pandas objects`,
  `TypeError: If objects contain types other than Series or DataFrame`,
  `TypeError: If trying to concatenate unaligned mixed dimensional NDFrame objects`.
- Acceptance: Invalid first argument and invalid object produce TypeError;
  mixed Series/DataFrame produce expected column naming for axis 0 and 1.
- Repository Evidence:
  - `/testbed/pandas/core/reshape/concat.py` `_sanitize_mixed_ndim`
    lines 456-510 raises the mixed-dim `ValueError`.
  - `pandas/tests/reshape/concat/test_invalid.py`
    `test_concat_invalid`, `test_concat_invalid_first_argument`.
  - `pandas/tests/reshape/concat/test_concat.py`
    `test_concat_mixed_objs_columns`, `test_concat_mixed_objs_index`,
    `test_concat_mixed_objs_index_names`, `test_concat_of_series_and_frame`.
- Uncertainty: The exact TypeError message is sourced from repository tests;
  the task docstring does not quote it.

### R4: Axis and parameter validation
- Type: Behavior / Failure / Compatibility
- Statement: `axis` accepts `0`/`"index"`/`"rows"` and `1`/`"columns"`.
  An unknown axis raises `ValueError("No axis named ...")`. `join` must be
  `"inner"` or `"outer"`. `sort` must be a boolean; `sort=None` raises
  `ValueError`. `ignore_index=True` together with `keys` is invalid and raises
  `ValueError`. `copy` accepts a bool or `lib.no_default`.
- Task Evidence: Interface docstring documents `axis`, `join`, `sort`,
  `ignore_index`, `copy`, and the corresponding Raises.
- Acceptance: Valid aliases produce results; invalid values raise without
  calling data manipulation.
- Repository Evidence:
  - `pandas/tests/reshape/concat/test_dataframe.py`
    `test_concat_axis_parameter` includes `"rows"` and invalid axis.
  - `pandas/tests/reshape/concat/test_sort.py`
    `test_concat_sort_none_raises`.
  - `pandas/tests/reshape/concat/test_concat.py`
    `test_concat_with_moot_ignore_index_and_keys`.
  - `/testbed/pandas/core/reshape/concat.py` imports `is_bool`, `is_scalar`,
    `warnings`, `Pandas4Warning`, and `find_stack_level`, which are unused in
    the surviving source and indicate validation in the removed `concat` body.
- Uncertainty: The interface docstring says `sort` invalid raises `ValueError`;
  repository test confirms `sort=None` raises `ValueError`. Invalid `join`
  message is not quoted in repository tests.

### R5: Concat-axis index construction
- Type: Dataflow / Behavior / Failure
- Statement: For the concatenation axis, `ignore_index=True` returns a
  `RangeIndex` of total length. Otherwise, with `keys is None`, the result
  axis is the concatenation of the input indexes via `_concat_indexes`.
  With `keys`, the result axis is a `MultiIndex` built by
  `_make_concat_multiindex`, honoring `levels` and `names`. `levels` without
  `keys` raises `ValueError`. Duplicate `levels` raise `ValueError`. Keys not
  present in supplied levels raise `ValueError`. Key length must equal object
  length after None filtering. `verify_integrity=True` raises
  `ValueError("Indexes have overlapping values: ...")` when the resulting axis
  has duplicates.
- Task Evidence: Interface docstring keys/levels/names/verify_integrity and
  Raises.
- Acceptance: Index/columns are exactly the expected `Index` or `MultiIndex`;
  each invalid condition raises the specified `ValueError`.
- Repository Evidence:
  - `/testbed/pandas/core/reshape/concat.py`:
    `new_axes` lines 619-646; `_get_concat_axis_dataframe` lines 701-730;
    `_make_concat_multiindex` lines 839-949; `validate_unique_levels`
    lines 833-836.
  - `pandas/tests/reshape/concat/test_concat.py`:
    `test_concat_with_group_keys`, `test_concat_keys_specific_levels`,
    `test_concat_keys_and_levels`, `test_concat_keys_levels_no_overlap`,
    `test_concat_preserves_rangeindex`, `test_concat_repeated_keys`,
    `test_concat_mismatched_keys_length`.
  - `pandas/tests/reshape/concat/test_index.py`:
    `test_concat_with_duplicated_levels`,
    `test_concat_with_levels_with_none_keys`,
    `test_concat_multiindex_with_keys`.
- Uncertainty: `_concat_indexes` is currently undefined in the file; its exact
  implementation is inferred to be index append, but the observable contract
  is the resulting index.

### R6: Other-axis join, sort, and index-name semantics
- Type: Behavior / Compatibility
- Statement: For the non-concatenation axis, `join="outer"` computes the union
  of indexes and `join="inner"` computes the intersection. `sort=True` sorts
  the result; `sort=False` preserves first-appearance order. If the
  non-concatenation axis is a `DatetimeIndex` and `join="outer"` and it is not
  already aligned, it is always sorted lexicographically. Index names are
  preserved when unanimous.
- Task Evidence: Interface docstring `join`, `sort`, and the DatetimeIndex
  exception note.
- Acceptance: Column/index order and names match pandas expected values in
  repository tests.
- Repository Evidence:
  - `/testbed/pandas/core/indexes/api.py` `get_objs_combined_axis` and
    `_get_combined_index` lines 63-158 implement union/intersection/sort.
  - `pandas/tests/reshape/concat/test_sort.py` all tests.
  - `pandas/tests/reshape/concat/test_dataframe.py`
    `test_outer_sort_columns`, `test_inner_sort_columns`,
    `test_sort_columns_one_df`.
  - `pandas/tests/reshape/concat/test_index.py`
    `test_concat_same_index_names`.
- Uncertainty: DatetimeIndex forced sort is documented in the interface but no
  focused repository test is identified; it should be compiled from the
  docstring.

### R7: Result type, subclass, attrs, and index/columns identity
- Type: State / Compatibility
- Statement: Concatenating only `Series` along `axis=0` returns a `Series`;
  any `DataFrame` along `axis=0`, or any `axis=1`, returns a `DataFrame`.
  A single input with subclass type preserves the subclass. `attrs` are
  retained when identical and dropped when they differ. Axis object identity
  follows pandas copy rules: for axis 0 the resulting concat axis is new, the
  other axis is shared; for axis 1 the opposite holds.
- Task Evidence: Interface docstring Returns and copy/memory note; repository
  subclass/attrs tests.
- Acceptance: `isinstance(result, type(expected))` and identity/attrs checks
  pass.
- Repository Evidence:
  - `pandas/tests/reshape/concat/test_concat.py`
    `test_concat_preserves_subclass`, `test_concat_drop_attrs`,
    `test_concat_retain_attrs`.
  - `pandas/tests/reshape/concat/test_index.py`
    `test_concat_copy_index_series`, `test_concat_copy_index_frame`.
- Uncertainty: Exact `copy` keyword behavior is version-dependent (pandas 3.0
  deprecation noted in docstring); the repository currently expects lazy/no
  eager copy for `copy=False`.

### R8: Dtype inference and conversion across blocks
- Type: Dataflow / Compatibility
- Statement: `concat` must infer a common dtype across blocks without
  unnecessary upcasting, preserving extension dtypes when possible. Integer
  plus missing data upcasts to float. Bool plus nullable boolean yields
  nullable boolean; bool plus numeric yields object. Datetime-like and
  categorical dtypes are preserved where possible; incompatible categorical
  categories are cast to object. Sparse dtypes are preserved for compatible
  sparse inputs.
- Task Evidence: Task Statement "Data Type Inference and Conversion System",
  "Type Detection", "Data Conversion", "Maintain type safety".
- Acceptance: Result `.dtypes`/`.values.dtype` match repository expected dtypes.
- Repository Evidence:
  - `pandas/tests/reshape/concat/test_concat.py`:
    `test_concat_no_unnecessary_upcast`, `test_concat_will_upcast`,
    `test_concat_frame_axis0_extension_dtypes`,
    `test_concat_preserves_extension_int64_dtype`, `test_concat_bool_types`,
    `test_concat_different_extension_dtypes_upcasts`, `test_concat_ea_upcast`,
    `test_concat_sparse`, `test_concat_dense_sparse`.
  - `pandas/tests/reshape/concat/test_series.py`
    `test_concat_bool_and_numeric`.
  - `pandas/tests/reshape/concat/test_categorical.py`
    `test_categorical_concat_preserve`, `test_categorical_index_preserver`.
- Uncertainty: Hidden tests may cover additional dtype pairs; the IR binds only
  the evidenced dtype transitions.

### R9: Array-level concat_compat helper
- Type: Dependency / Dataflow
- Statement: `pandas.core.dtypes.concat.concat_compat` must exist and
  concatenate arrays/ExtensionArrays, including 1D and 2D PeriodArray, along
  `axis=0` or `axis=1`. It must filter empty arrays and raise `ValueError`
  when non-concatenation dimensions mismatch. It must be imported by
  `pandas.core.internals.concat` so `concatenate_managers` can execute.
- Task Evidence: Task Statement "Data Conversion", "Sparse arrays", "pandas
  extension arrays"; static issue for `concat_compat` in `frame.py` and the
  discovered on-path use in `pandas/core/internals/concat.py`.
- Acceptance: `pandas.core.dtypes.concat.concat_compat` is importable; period
  array tests pass; `pd.concat` paths that call `concatenate_managers` do not
  raise `NameError`.
- Repository Evidence:
  - `/testbed/pandas/core/dtypes/concat.py` has imports `astype_array`,
    `find_common_type`, `np_find_common_type`, `cast` but no `concat_compat`
    definition; lines 51-120 are a blank region.
  - `/testbed/pandas/core/internals/concat.py` uses `concat_compat` at lines
    136, 139, 396, 400 and has no import for it.
  - `pandas/tests/dtypes/test_concat.py`
    `test_concat_mismatched_categoricals_with_empty`,
    `test_concat_periodarray_2d`.
- Uncertainty: The exact internal implementation of `concat_compat` is not
  specified by the interface; only its importability and observed array
  behavior are testable.

### R10: Missing value and empty/all-NA block handling
- Type: Behavior / Compatibility
- Statement: Empty frames/series and all-NA blocks participate in dtype
  inference without spuriously coercing non-empty data except where pandas
  documented behavior requires object or float upcast. Object-null index with
  DatetimeIndex aligns to object index. Empty plus non-empty categorical and
  tz-aware cases preserve the expected dtype/index.
- Task Evidence: Task Statement "Missing Value Handling"; interface examples
  show NaN fill for outer concat.
- Acceptance: Expected dtype/index from repository regression tests.
- Repository Evidence:
  - `pandas/tests/reshape/concat/test_concat.py`:
    `test_concat_empty_and_non_empty_frame_regression`,
    `test_concat_ignore_empty_object_float`,
    `test_concat_ignore_all_na_object_float`,
    `test_concat_ignore_empty_from_reindex`,
    `test_concat_null_object_with_dti`,
    `test_concat_none_with_timezone_timestamp`.
  - `pandas/tests/reshape/concat/test_series.py`
    `test_concat_empty_and_non_empty_series_regression`.
- Uncertainty: Some empty dtype expectations are explicitly marked TODO in
  repository comments; hidden tests should follow current repository expected
  values, not TODO speculation.

### R11: Copy and memory optimization
- Type: Side-effect / Performance
- Statement: `copy=False` must avoid unnecessary deep copies; single-object
  concat returns an equal object/copy; axis=1 concat shares memory with input
  blocks where dtype/consolidation permits. `copy=True` (or legacy semantics)
  must force a copy when required.
- Task Evidence: Interface docstring `copy` note and "Memory Optimization" in
  task statement.
- Acceptance: Memory-sharing assertions in repository tests pass.
- Repository Evidence:
  - `pandas/tests/reshape/concat/test_concat.py` `test_concat_copy`.
  - `pandas/tests/dtypes/test_concat.py`
    `test_concat_single_dataframe_tz_aware`.
  - `pandas/tests/reshape/concat/test_index.py`
    `test_concat_copy_index_series`, `test_concat_copy_index_frame`.
- Uncertainty: CoW/lazy-copy future behavior is deprecated; compile against
  current repository behavior.

### R12: On-path dependency `_concat_indexes`
- Type: Dependency / Interface
- Statement: `_concat_indexes` MUST be defined in
  `/testbed/pandas/core/reshape/concat.py` before use, and it must concatenate
  a non-empty list of indexes into a single index preserving dtype/names and
  supporting `Index`, `RangeIndex`, `MultiIndex`, and `CategoricalIndex`.
- Task Evidence: Static issue in `pandas/core/reshape/concat.py`;
  `_concat_indexes` is referenced by `_get_concat_axis_dataframe` and
  `_make_concat_multiindex`, both on the `concat` call path.
- Acceptance: `pd.concat([...])` without `keys` and with `ignore_index=False`
  executes without `NameError` and returns the correct concat axis.
- Repository Evidence:
  - `pandas/core/reshape/concat.py` lines 721 and 885 call `_concat_indexes`;
    no definition exists anywhere in `pandas/`.
  - `new_axes` line 633 calls `_get_concat_axis_dataframe`, and `new_axes` is
    a concat helper with no current caller other than the missing `concat`
    body.
- Uncertainty: The private helper is not independently imported by tests; it
  is observed only through public `concat`.

### R13: On-path import/binding closure for `concat_compat` and top-level `concat`
- Type: Dependency / Import Boundary
- Statement: The public `concat` path must close two bindings:
  (1) `pandas` top-level and/or `pandas.core.reshape.api` must import the
  implemented `concat`; (2) `pandas.core.internals.concat` must bind
  `concat_compat` from `pandas.core.dtypes.concat`.
- Task Evidence: Static issues plus repository import evidence; interface path.
- Acceptance: `import pandas as pd; pd.concat` works; `pd.concat` on a path
  requiring `concatenate_managers`/`concat_compat` works.
- Repository Evidence:
  - `pandas/__init__.py` line 286 and `pandas/core/reshape/api.py` line 27
    include `"concat"` in `__all__` but no import.
  - `pandas/core/reshape/concat.py` line 49 imports `concatenate_managers`,
    with no other current caller.
  - `pandas/core/internals/concat.py` uses `concat_compat` with no import.
  - `pandas/core/dtypes/concat.py` is the module imported as
    `pandas.core.dtypes.concat` by `pandas/tests/dtypes/test_concat.py`.
- Uncertainty: There may be additional internal imports needed by off-path
  callers, but they are not required for the declared `concat` entry.

---

## L2. Functional Design Graph

### Entities

### N1: `concat`
- Kind: PublicEntry
- Repository Evidence: `/testbed/pandas/core/reshape/concat.py` lines 74-151
  overloads; missing implementation body; Interface Description 1.

### N2: `pandas` top-level namespace
- Kind: ImportBoundary
- Repository Evidence: `/testbed/pandas/__init__.py` line 286 `__all__` entry.

### N3: `pandas.core.reshape.api`
- Kind: ImportBoundary
- Repository Evidence: `/testbed/pandas/core/reshape/api.py` line 27 `__all__`
  entry; module currently imports other reshape functions only.

### N4: `_sanitize_mixed_ndim`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/reshape/concat.py` lines 456-510.

### N5: `new_axes`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/reshape/concat.py` lines 619-646;
  docstring says "Return the new [index, column] result for concat."

### N6: `_get_concat_axis_dataframe`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/reshape/concat.py` lines 701-730.

### N7: `_make_concat_multiindex`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/reshape/concat.py` lines 839-949.

### N8: `_concat_indexes`
- Kind: UnresolvedSymbol
- Repository Evidence: referenced at `/testbed/pandas/core/reshape/concat.py`
  lines 721 and 885; no definition or import in `pandas/`.

### N9: `get_objs_combined_axis`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/indexes/api.py` lines 63-75.

### N10: `concatenate_managers`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/internals/concat.py` lines 61-145;
  imported by concat.py line 49.

### N11: `concat_compat`
- Kind: UnresolvedSymbol
- Repository Evidence: referenced at
  `/testbed/pandas/core/internals/concat.py` lines 136, 139, 396, 400; no
  import in that file; no definition in
  `/testbed/pandas/core/dtypes/concat.py`.

### N12: `pandas.core.dtypes.concat` module
- Kind: Module
- Repository Evidence: `/testbed/pandas/core/dtypes/concat.py`; blank region
  lines 51-120; imported by `pandas/tests/dtypes/test_concat.py` line 3.

### N13: `_concatenate_join_units`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/internals/concat.py` lines 385-401.

### N14: `_get_combined_index`
- Kind: Function
- Repository Evidence: `/testbed/pandas/core/indexes/api.py` lines 106-158.

### Edges

### E1: N2 -> N1
- Kind: DATA
- Condition: `pandas/__init__.py` must bind the `concat` symbol from
  `pandas.core.reshape.concat` (directly or via `pandas.core.reshape.api`).
- Transfer: public `pandas.concat` binding.
- Evidence: `pandas/__init__.py` line 286 `__all__`; runtime introspection
  showed `hasattr(pandas, "concat") is False`.
- Obligations: R1, R13.

### E2: N3 -> N1
- Kind: DATA
- Condition: `pandas.core.reshape.api` must import `concat` from
  `pandas.core.reshape.concat` if top-level import routes through it.
- Transfer: `pandas.core.reshape.api.concat` binding.
- Evidence: `pandas/core/reshape/api.py` line 27 `__all__`; file currently has
  no `concat` import.
- Obligations: R1, R13.

### E3: N1 -> N4
- Kind: CALL
- Condition: mixed Series/DataFrame inputs require ndim normalization.
- Transfer: input objects -> normalized list of Series/DataFrame.
- Evidence: `_sanitize_mixed_ndim` helper is defined in the same file and has
  no current caller other than the missing `concat` body; its comment says
  "if we have mixed ndims, then convert to highest ndim".
- Obligations: R3, R7.

### E4: N1 -> N5
- Kind: CALL
- Condition: result axes must be constructed for the target block-manager axis.
- Transfer: object list, axis/join/sort/keys/levels/names/verify_integrity ->
  `[index, columns]` axes.
- Evidence: `new_axes` docstring and signature in concat.py; no current caller
  other than missing `concat` body.
- Obligations: R5, R6, R7.

### E5: N5 -> N6
- Kind: CALL
- Condition: `i == bm_axis` (the concatenation axis).
- Transfer: concat-axis inputs -> result axis.
- Evidence: concat.py lines 632-642.
- Obligations: R5, R12.

### E6: N5 -> N9
- Kind: CALL
- Condition: `i != bm_axis` (the other axis).
- Transfer: other-axis inputs -> union/intersection/sorted index.
- Evidence: concat.py lines 643-647.
- Obligations: R6.

### E7: N6 -> N8
- Kind: CALL
- Condition: `keys is None` and `ignore_index=False`.
- Transfer: list of input indexes -> concatenated index.
- Evidence: concat.py line 721.
- Obligations: R5, R12.

### E8: N6 -> N7
- Kind: CALL
- Condition: `keys is not None`.
- Transfer: indexes, keys, levels, names -> MultiIndex.
- Evidence: concat.py line 723.
- Obligations: R5.

### E9: N7 -> N8
- Kind: CALL
- Condition: input indexes are not all equal.
- Transfer: concat of original indexes -> appended levels/codes.
- Evidence: concat.py line 885.
- Obligations: R5, R12.

### E10: N1 -> N10
- Kind: CALL
- Condition: after axes are computed, block managers are concatenated.
- Transfer: manager/indexer tuples, axes, concat_axis, copy -> BlockManager.
- Evidence: concat.py line 49 imports `concatenate_managers`; no current caller
  other than missing `concat` body.
- Obligations: R7, R8, R10, R11.

### E11: N10 -> N11
- Kind: CALL
- Condition: uniform non-extension join path or non-uniform join path requires
  array concatenation.
- Transfer: list of arrays -> concatenated array.
- Evidence: `pandas/core/internals/concat.py` lines 136, 139.
- Obligations: R8, R9, R13.

### E12: N10 -> N13
- Kind: CALL
- Condition: non-uniform join units require `_concatenate_join_units`.
- Transfer: join units -> reindexed arrays -> concatenated array.
- Evidence: `pandas/core/internals/concat.py` `_get_combined_plan` and
  `_concatenate_join_units` usage in `concatenate_managers`.
- Obligations: R8, R10.

### E13: N13 -> N11
- Kind: CALL
- Condition: `_concatenate_join_units` must concatenate reindexed values.
- Transfer: to_concat values -> `concat_compat` result.
- Evidence: `pandas/core/internals/concat.py` lines 396 and 400.
- Obligations: R9, R13.

### E14: N11 -> N12
- Kind: DATA
- Condition: `pandas.core.dtypes.concat` must define `concat_compat`, and
  `pandas.core.internals.concat` must import it from there.
- Transfer: `concat_compat` symbol binding.
- Evidence: `pandas/tests/dtypes/test_concat.py` imports the module; internals
  file has no import; dtypes file has blank definition region.
- Obligations: R9, R13.

### E15: N9 -> N14
- Kind: CALL
- Condition: `get_objs_combined_axis` delegates to `_get_combined_index`.
- Transfer: other-axis indexes -> union/intersection/sort result.
- Evidence: `pandas/core/indexes/api.py` lines 63-75 and 106-158.
- Obligations: R6.

### Off-path static issue dispositions

The following static-issue symbols are **out-of-scope** for the declared
`concat` entry because an upward caller trace dead-ends at public APIs that are
not task-required and do not reach `concat`:

- `pandas/core/frame.py:12129,12163` `concat_compat` inside
  `DataFrame._reduce` -> callers are DataFrame reductions (`sum`, `mean`,
  etc.), not `concat`. Dead-end: no `_reduce` caller is `concat`.
- `pandas/core/generic.py:6528,9510` `concat` inside `NDFrame.astype` and
  `NDFrame.compare` -> callers are public `astype`/`compare`, not `concat`.
  Dead-end: no caller chain reaches `concat`.
- `pandas/core/methods/describe.py:175` `concat` inside
  `DataFrame.describe`/describe classes. Dead-end: no caller chain reaches
  `concat`.
- `pandas/core/resample.py:1028` `concat` inside `Resampler.interpolate`.
  Dead-end: no caller chain reaches `concat`.
- `pandas/core/reshape/melt.py:252,264,669` `concat` and `melt.py:350`
  `concat_compat` inside `melt`, `lreshape`, `wide_to_long`. Dead-end: public
  reshape APIs, not `concat`.
- `pandas/core/reshape/pivot.py:266,509,611,1188,1202` `concat` inside
  `pivot_table` and helpers. Dead-end: public `pivot_table`, not `concat`.
- `pandas/core/window/rolling.py:773` `concat` inside
  `Rolling._apply_pairwise`. Dead-end: rolling APIs, not `concat`.
- `pandas/io/json/_json.py:993` `concat` inside JSON `_read_ujson`.
  Dead-end: JSON reader, not `concat`.
- `pandas/io/pytables.py:1112,3457,4863` `concat` inside HDF5 readers.
  Dead-end: HDF5 reader, not `concat`.

These call sites still lack imports/definitions, but they are not on the
task-required `concat` path. No L3 contract is generated for them.

---

## L3. Verifiable Contracts

### C1: Top-level `pandas.concat` import boundary
- Type: Interface
- Subject: N2 / N1
- Relation: `hasattr(pandas, "concat")` and `pandas.concat` callable.
- Expected: `import pandas as pd; from pandas import concat` succeeds;
  `concat` is the implementation in `pandas.core.reshape.concat`.
- Evidence: `pandas/__init__.py` line 286; runtime introspection showed
  `hasattr(pd, "concat") is False` before implementation.
- Observe: IMPORT_BOUNDARY
- Target: `/testbed/pandas/__init__.py`
- Obligations: R1, R13
- Graph: N1, N2, E1

### C2: Module-level `concat` import boundary
- Type: Interface
- Subject: N1
- Relation: `from pandas.core.reshape.concat import concat` returns a callable.
- Expected: Calling the imported object with a list of `Series` returns a
  `Series`; calling with an empty list raises `ValueError`.
- Evidence: Interface Description 1 path; current file has only overloads and
  calling the imported object raises `NotImplementedError`.
- Observe: IMPORT_BOUNDARY
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R1, R13
- Graph: N1, E2

### C3: Basic Series concatenation and ignore_index
- Type: Behavior
- Subject: N1
- Relation: `concat([Series([1,2]), Series([3])])` values/return type;
  `ignore_index=True` resets to RangeIndex.
- Expected: First returns `Series([1,2,3], index=[0,1,0])`; second returns
  `Series([1,2,3], index=RangeIndex(0,3))`.
- Evidence: Interface examples; `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_mixed_objs_index`; `pandas/tests/reshape/concat/test_index.py`
  `test_default_index`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R2, R5, R7
- Graph: N1, N5, N6, N8, E4, E5, E7

### C4: Empty and all-None failures
- Type: Failure
- Subject: N1
- Relation: `concat([])` and `concat([None, None])`.
- Expected: `ValueError` messages "No objects to concatenate" and
  "All objects passed were None", respectively.
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_no_items_raises`, `test_concat_exclude_none`.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R2
- Graph: N1

### C5: None filtering with keys
- Type: Behavior
- Subject: N1
- Relation: `concat([None, df0, df0[:2]], keys=["a","b","c"])` drops None and
  drops key `"a"`.
- Expected: Equals `concat([df0, df0[:2]], keys=["b","c"])`.
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_keys_with_none`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R2, R5
- Graph: N1, N5, N6, N7, E4, E5, E8

### C6: Invalid object and first-argument failures
- Type: Failure
- Subject: N1
- Relation: `concat([DataFrame(...), obj])` for `obj in [1, {}, [1,2], (1,2)]`
  and `concat(DataFrame(...))`.
- Expected: `TypeError` with "only Series and DataFrame objs are valid" for
  invalid elements and "first argument must be an iterable of pandas objects"
  for a DataFrame first argument.
- Evidence: `pandas/tests/reshape/concat/test_invalid.py`
  `test_concat_invalid`, `test_concat_invalid_first_argument`.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R3
- Graph: N1

### C7: Mixed Series/DataFrame normalization
- Type: Behavior
- Subject: N1, N4
- Relation: Row-wise and column-wise concat of named/unnamed Series with
  DataFrames.
- Expected: Matches
  `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_mixed_objs_columns`, `test_concat_mixed_objs_index`,
  `test_concat_mixed_objs_index_names`, `test_concat_of_series_and_frame`.
- Evidence: Same tests; `_sanitize_mixed_ndim` source.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R3, R7
- Graph: N1, N4, E3

### C8: Invalid axis failure
- Type: Failure
- Subject: N1
- Relation: `concat([series1, series2], axis="something")`.
- Expected: Raises `ValueError("No axis named something")`.
- Evidence: `pandas/tests/reshape/concat/test_dataframe.py`
  `test_concat_axis_parameter`.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R4
- Graph: N1

### C9: Sort validation
- Type: Failure
- Subject: N1
- Relation: `sort=None`.
- Expected: `ValueError` with "The 'sort' keyword only accepts boolean values;
  None was passed."
- Evidence: `pandas/tests/reshape/concat/test_sort.py`
  `test_concat_sort_none_raises`.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R4, R6
- Graph: N1

### C10: ignore_index plus keys failure
- Type: Failure
- Subject: N1
- Relation: `ignore_index=True` and `keys` provided.
- Expected: `ValueError` with "Cannot set ignore_index=True and specify keys.
  Either should be used."
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_with_moot_ignore_index_and_keys`.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R4, R5
- Graph: N1

### C11: MultiIndex keys/levels/names construction
- Type: Behavior
- Subject: N1, N7
- Relation: `concat([df, df2, df, df2], keys=[("foo","one"), ...],
  levels=..., names=...)`.
- Expected: Result index is a MultiIndex with levels, codes, and names equal
  to repository expected values.
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_keys_and_levels`, `test_concat_keys_specific_levels`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R5
- Graph: N1, N5, N6, N7, E4, E5, E8

### C12: Key/level error paths
- Type: Failure
- Subject: N1, N7
- Relation: `levels` without keys; duplicate levels; keys absent from supplied
  levels.
- Expected: `ValueError` messages:
  "levels supported only when keys is not None";
  "Level values not unique: [...]";
  "Values not found in passed level: [...]" or "Key ... not in level ...".
- Evidence: `pandas/tests/reshape/concat/test_index.py`
  `test_concat_with_duplicated_levels`, `test_concat_with_levels_with_none_keys`;
  `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_keys_levels_no_overlap`.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R5
- Graph: N6, N7, E7, E8

### C13: Keys length mismatch
- Type: Failure
- Subject: N1
- Relation: Four Series and three keys, both axis 0 and axis 1, including
  generator keys.
- Expected: `ValueError` matching "The length of the keys".
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_mismatched_keys_length`.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R5
- Graph: N1, N5, N6, E4, E5

### C14: verify_integrity overlap
- Type: Failure
- Subject: N1, N6
- Relation: `concat([df5, df6], verify_integrity=True)` with overlapping index.
- Expected: `ValueError("Indexes have overlapping values: ['a']")`.
- Evidence: Interface docstring example;
  `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_repeated_keys` also exercises integrity paths.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R5
- Graph: N1, N5, N6, E4, E5

### C15: On-path execution of `_concat_indexes`
- Type: Dependency / Behavior
- Subject: N8
- Relation: `pd.concat([df1, df2])` with `keys=None` and
  `ignore_index=False` executes `_get_concat_axis_dataframe` -> `_concat_indexes`.
- Expected: No `NameError`; result index equals the append/concatenation of
  input indexes, preserving dtype and names.
- Evidence: Static issue `_concat_indexes`; concat.py lines 721 and 885;
  `pandas/tests/reshape/concat/test_index.py` `test_concat_same_index_names`,
  `test_concat_copy_index_frame`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R12, R5
- Graph: N1 -> N5 -> N6 -> N8 (E4, E5, E7)

### C16: `_concat_indexes` with MultiIndex and categorical index
- Type: Dependency / Behavior
- Subject: N8
- Relation: `pd.concat` of MultiIndex/CategoricalIndex-backed frames without
  keys.
- Expected: Result index preserves MultiIndex levels/names and CategoricalIndex
  categories/dtype as in repository tests.
- Evidence: `pandas/tests/reshape/concat/test_index.py`
  `test_concat_multiindex_rangeindex`,
  `test_concat_multiindex_with_none_in_index_names`;
  `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_multiindex_with_category`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R12, R5, R8
- Graph: N1 -> N5 -> N6 -> N8 (E4, E5, E7)

### C17: Other-axis outer/inner join and sort
- Type: Behavior
- Subject: N1, N9, N14
- Relation: `join="outer"` vs `join="inner"` with `sort=True` on DataFrames
  with overlapping and mixed-type columns.
- Expected: Outer includes all columns with NaN fill; inner includes only
  common columns; sort=True orders columns lexicographically.
- Evidence: `pandas/tests/reshape/concat/test_dataframe.py`
  `test_outer_sort_columns`, `test_inner_sort_columns`,
  `test_sort_columns_one_df`; `pandas/tests/reshape/concat/test_sort.py`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R6, R8
- Graph: N1, N5, N9, N14, E4, E6, E15

### C18: DatetimeIndex outer sort exception
- Type: Behavior
- Subject: N1, N9
- Relation: `join="outer"` on non-aligned DatetimeIndex non-concatenation axis.
- Expected: Result axis is sorted lexicographically regardless of `sort=False`.
- Evidence: Interface docstring note.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R6
- Graph: N1, N5, N9, E4, E6

### C19: Single-object concat preserves dtype and equality
- Type: Behavior
- Subject: N1, N10
- Relation: `pd.concat([df])` for a tz-aware DataFrame.
- Expected: Result equals `df.copy()` and preserves tz-aware datetime dtype.
- Evidence: `pandas/tests/dtypes/test_concat.py`
  `test_concat_single_dataframe_tz_aware`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R8, R11
- Graph: N1, N10, E10

### C20: Extension dtype preservation
- Type: Behavior
- Subject: N1, N10
- Relation: `concat([DataFrame({"a": pd.array([...], dtype="Int64")}),
  DataFrame({"a": np.array([...])})], ignore_index=True)`.
- Expected: Result dtype is `Int64` in both input orders.
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_frame_axis0_extension_dtypes`,
  `test_concat_preserves_extension_int64_dtype`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R8
- Graph: N1, N10, E10

### C21: Bool and boolean common dtype
- Type: Behavior
- Subject: N1
- Relation: `concat` of Series with `"bool"`/`"boolean"` pairs.
- Expected: Common dtype is `"boolean"` for bool+boolean and boolean+boolean;
  `"bool"` for bool+bool.
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_bool_types`; `pandas/tests/reshape/concat/test_series.py`
  `test_concat_bool_and_numeric`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R8
- Graph: N1, N10, E10

### C22: Categorical dtype preservation and incompatible-category cast
- Type: Behavior
- Subject: N1, N10
- Relation: `concat` of same-category Series preserves category; different
  categories produce object; wrong-category categorical indexes cast to object.
- Expected: Matches `pandas/tests/reshape/concat/test_categorical.py`
  `test_categorical_concat_preserve`, `test_categorical_index_preserver`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R8, R10
- Graph: N1, N10, E10

### C23: Sparse and dense-sparse concat
- Type: Behavior
- Subject: N1, N10
- Relation: `concat([a, a], axis=1)` for SparseArray Series; dense+sparse axis 0.
- Expected: Returns SparseDtype DataFrame/Series as specified in
  `pandas/tests/reshape/concat/test_concat.py` `test_concat_sparse`,
  `test_concat_dense_sparse`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R8, R9
- Graph: N1, N10, N11, E10, E11

### C24: Float/int upcast and no-unnecessary-upcast
- Type: Behavior
- Subject: N1, N10
- Relation: Float arrays with NaN preserve float dtype; int arrays with NaN
  upcast to float64; empty + non-empty int/object regression.
- Expected: Matches `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_no_unnecessary_upcast`, `test_concat_will_upcast`,
  `test_concat_empty_and_non_empty_frame_regression`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R8, R10
- Graph: N1, N10, E10

### C25: `concat_compat` module import and successful array behavior
- Type: Dependency / Behavior
- Subject: N11, N12
- Relation: `import pandas.core.dtypes.concat as _concat`; call
  `_concat.concat_compat` on categorical values and 2D PeriodArray with
  matching dimensions.
- Expected: Categorical result equals `pd.concat([ser1, ser2])._values`;
  PeriodArray axis 0 and axis 1 results reassemble the original array.
- Evidence: `pandas/tests/dtypes/test_concat.py`
  `test_concat_mismatched_categoricals_with_empty`,
  `test_concat_periodarray_2d` successful cases.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/dtypes/concat.py`
- Obligations: R9, R13
- Graph: N11, N12, E14

### C25b: `concat_compat` dimension mismatch failure
- Type: Failure
- Subject: N11
- Relation: `_concat.concat_compat` with 2D PeriodArray slices whose
  non-concatenation dimensions differ.
- Expected: `ValueError` matching
  "all the input array dimensions.* for the concatenation axis must match exactly".
- Evidence: `pandas/tests/dtypes/test_concat.py`
  `test_concat_periodarray_2d` mismatch cases.
- Observe: EXCEPTION
- Target: `/testbed/pandas/core/dtypes/concat.py`
- Obligations: R9
- Graph: N11

### C26: `concat_compat` on-path through `pd.concat`
- Type: Dependency / Behavior
- Subject: N10, N11
- Relation: `pd.concat([DataFrame(["a"], dtype="string"),
  DataFrame([1], dtype="Int64")])` and
  `pd.concat([Series(Int64), Series(decimal)])`.
- Expected: Results equal repository expected object DataFrames/Series; no
  `NameError` from missing `concat_compat`.
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_ea_upcast`, `test_concat_different_extension_dtypes_upcasts`;
  on-path chain E10 -> E11/E13.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/internals/concat.py`
- Obligations: R9, R13
- Graph: N1, N10, N11, N13, E10, E11, E12, E13

### C27: Empty/all-NA block dtype handling
- Type: Behavior
- Subject: N1, N10
- Relation: Empty or all-NA DataFrames/Series concatenated with non-empty data.
- Expected: Matches regression expectations in
  `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_ignore_empty_object_float`,
  `test_concat_ignore_all_na_object_float`,
  `test_concat_ignore_empty_from_reindex`.
- Observe: RETURN_VALUE
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R10
- Graph: N1, N10, N13, E10, E12

### C28: Subclass and attrs preservation
- Type: State / Behavior
- Subject: N1
- Relation: `concat([obj, obj])` for subclassed DataFrame/Series; concat of
  equal-attr and differing-attr objects.
- Expected: Subclass instance returned; attrs retained when identical and
  emptied when different.
- Evidence: `pandas/tests/reshape/concat/test_concat.py`
  `test_concat_preserves_subclass`, `test_concat_drop_attrs`,
  `test_concat_retain_attrs`.
- Observe: FIELD_READ
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R7
- Graph: N1

### C29: Axis-dependent index/column identity
- Type: State / Behavior
- Subject: N1
- Relation: `concat([obj, obj], axis=axis)` for Series and DataFrame.
- Expected: For axis 0, resulting concat axis is not the original index and
  columns are shared; for axis 1, index is shared and columns are new.
- Evidence: `pandas/tests/reshape/concat/test_index.py`
  `test_concat_copy_index_series`, `test_concat_copy_index_frame`.
- Observe: STATE_READ
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R7, R11
- Graph: N1, N5, N6, N8, E4, E5, E7

### C30: Copy/memory sharing on axis=1
- Type: Side-effect / Performance
- Subject: N1, N10
- Relation: `concat([df, df2, df3], axis=1)` with copy defaults.
- Expected: Blocks share memory with source blocks where dtype permits, as
  asserted by `np.shares_memory`/block `.base` checks in repository test.
- Evidence: `pandas/tests/reshape/concat/test_concat.py` `test_concat_copy`.
- Observe: FIELD_READ
- Target: `/testbed/pandas/core/reshape/concat.py`
- Obligations: R11
- Graph: N1, N10, E10
