"""
Executable behavior spec for the ``pandas.concat`` typed semantic IR.

This file compiles the state/outcome/default/failure/boundary contracts from
semantic_ir.md into runtime assertions.  arch_spec.py owns import-boundary and
real delegation-chain proofs.
"""

from __future__ import annotations

import re
import sys
from collections import abc, deque

import numpy as np
import pandas as pd
import pandas._testing as tm
from pandas import (
    DataFrame,
    Index,
    MultiIndex,
    RangeIndex,
    Series,
)


def _raises(exc_type, pattern, func, *args, **kwargs):
    try:
        func(*args, **kwargs)
    except exc_type as err:
        assert re.search(pattern, str(err)), f"expected pattern {pattern!r} in {err!r}"
        return
    except Exception as err:  # pragma: no cover - diagnostic aid
        raise AssertionError(
            f"expected {exc_type.__name__} matching {pattern!r}, "
            f"got {type(err).__name__}: {err}"
        ) from err
    raise AssertionError(
        f"expected {exc_type.__name__} matching {pattern!r}, got no exception"
    )


def check_C3_basic_series_concat_and_ignore_index():
    # Contracts: C3 (R2, R5, R7). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_mixed_objs_index and
    # pandas/tests/reshape/concat/test_index.py::test_default_index.
    # Perspective: default Series concat returns a Series with concatenated index;
    # ignore_index resets to RangeIndex. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> new_axes -> _get_concat_axis_dataframe.
    s1 = Series([1, 2])
    s2 = Series([3])
    result = pd.concat([s1, s2])
    expected = Series([1, 2, 3], index=[0, 1, 0])
    tm.assert_series_equal(result, expected)

    result = pd.concat([s1, s2], ignore_index=True)
    expected = Series([1, 2, 3], index=RangeIndex(0, 3))
    tm.assert_series_equal(result, expected)


def check_C4_empty_and_all_none_failures():
    # Contracts: C4 (R2). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_no_items_raises and
    # test_concat_exclude_none. Perspective: exact empty/all-None failure semantics.
    # Source path/symbol: pandas/core/reshape/concat.py::concat normalization.
    _raises(ValueError, "No objects to concatenate", pd.concat, [])
    _raises(ValueError, "All objects passed were None", pd.concat, [None, None])


def check_C5_collection_normalization_none_filtering_and_iterables():
    # Contracts: C5 and R2 iterable/mapping normalization. Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_keys_with_none,
    # test_concat_mapping, and test_concat_iterables. Perspective: None entries are
    # dropped with their keys; mappings use keys when keys is not supplied;
    # generators/deque/custom __getitem__/abc.Iterable objects are accepted.
    # Source path/symbol: pandas/core/reshape/concat.py::concat collection normalization.
    df0 = DataFrame([[10, 20, 30], [10, 20, 30], [10, 20, 30]])
    result = pd.concat(
        [None, df0, df0[:2], df0[:1], df0], keys=["a", "b", "c", "d", "e"]
    )
    expected = pd.concat([df0, df0[:2], df0[:1], df0], keys=["b", "c", "d", "e"])
    tm.assert_frame_equal(result, expected)

    mapping = {"a": None, "b": df0, "c": df0[:2]}
    expected = pd.concat({"b": df0, "c": df0[:2]})
    tm.assert_frame_equal(pd.concat(mapping), expected)
    expected_with_keys = pd.concat([df0, df0[:2]], keys=["b", "c"])
    tm.assert_frame_equal(pd.concat(mapping, keys=["b", "c"]), expected_with_keys)

    df1 = DataFrame([1, 2, 3])
    df2 = DataFrame([4, 5, 6])
    expected_all = DataFrame([1, 2, 3, 4, 5, 6])
    tm.assert_frame_equal(pd.concat((df1, df2), ignore_index=True), expected_all)
    tm.assert_frame_equal(
        pd.concat((df for df in (df1, df2)), ignore_index=True), expected_all
    )
    tm.assert_frame_equal(pd.concat(deque((df1, df2)), ignore_index=True), expected_all)

    class CustomIterator1:
        def __len__(self) -> int:
            return 2

        def __getitem__(self, index):
            try:
                return {0: df1, 1: df2}[index]
            except KeyError as err:
                raise IndexError from err

    tm.assert_frame_equal(pd.concat(CustomIterator1(), ignore_index=True), expected_all)

    class CustomIterator2(abc.Iterable):
        def __iter__(self):
            yield df1
            yield df2

    tm.assert_frame_equal(pd.concat(CustomIterator2(), ignore_index=True), expected_all)


def check_C6_invalid_object_and_first_argument_failures():
    # Contracts: C6 (R3). Repo guidance:
    # pandas/tests/reshape/concat/test_invalid.py::test_concat_invalid and
    # test_concat_invalid_first_argument. Perspective: invalid elements and a
    # non-iterable first argument raise precise TypeErrors. Source path/symbol:
    # pandas/core/reshape/concat.py::concat validation.
    df1 = DataFrame(range(2))
    for obj in [1, {}, [1, 2], (1, 2)]:
        pattern = re.escape(
            f"cannot concatenate object of type '{type(obj)}'; "
            "only Series and DataFrame objs are valid"
        )
        _raises(TypeError, pattern, pd.concat, [df1, obj])
    _raises(
        TypeError,
        re.escape(
            'first argument must be an iterable of pandas objects, '
            'you passed an object of type "DataFrame"'
        ),
        pd.concat,
        df1,
    )


def check_C7_mixed_series_dataframe_normalization():
    # Contracts: C7 (R3, R7). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_of_series_and_frame and
    # test_concat_mixed_objs_columns. Perspective: _sanitize_mixed_ndim normalizes
    # Series to DataFrames and names columns for axis 0 and 1. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> _sanitize_mixed_ndim.
    result = pd.concat(
        [DataFrame({"a": [0, 1], "b": [2, 3]}), Series([4, 5], name="c")]
    )
    expected = DataFrame(
        {
            "a": [0, 1, None, None],
            "b": [2, 3, None, None],
            "c": [None, None, 4, 5],
        },
        index=[0, 1, 0, 1],
    )
    tm.assert_frame_equal(result, expected)

    result = pd.concat(
        [
            DataFrame({"a": [0, 1], "b": [2, 3]}),
            Series([4, 5]),
            Series([4, 5]),
        ],
        axis=1,
    )
    expected = DataFrame(
        {"a": [0, 1], "b": [2, 3], 0: [4, 5], 1: [4, 5]},
        index=[0, 1],
    )
    tm.assert_frame_equal(result, expected)


def check_C8_axis_parameter_aliases_and_invalid_axis():
    # Contracts: C8 (R4). Repo guidance:
    # pandas/tests/reshape/concat/test_dataframe.py::test_concat_axis_parameter.
    # Perspective: 0/'index'/'rows' and 1/'columns' are aliases; unknown axis fails
    # with 'No axis named'. Source path/symbol: pandas/core/reshape/concat.py::concat.
    df1 = DataFrame({"A": [0.1, 0.2]}, index=range(2))
    df2 = DataFrame({"A": [0.3, 0.4]}, index=range(2))

    expected_index = DataFrame({"A": [0.1, 0.2, 0.3, 0.4]}, index=[0, 1, 0, 1])
    for axis in [0, "index", "rows"]:
        tm.assert_frame_equal(pd.concat([df1, df2], axis=axis), expected_index)

    expected_columns = DataFrame(
        [[0.1, 0.3], [0.2, 0.4]], index=[0, 1], columns=["A", "A"]
    )
    for axis in [1, "columns"]:
        tm.assert_frame_equal(pd.concat([df1, df2], axis=axis), expected_columns)

    _raises(ValueError, re.escape("No axis named something"), pd.concat, [df1, df2], axis="something")


def check_C8b_invalid_join_failure():
    # Contracts: C8b (R4). Repo guidance: Interface Description 1 Raises section;
    # no focused repository test identified in the IR. Perspective: join accepts
    # only 'inner'/'outer', and an invalid value must fail before data manipulation.
    # Source path/symbol: pandas/core/reshape/concat.py::concat validation.
    df = DataFrame({"a": [1]})
    _raises(
        ValueError,
        re.escape("Only can inner (intersect) or outer (union) join the other axis"),
        pd.concat,
        [df, df],
        join="invalid",
    )


def check_C9_sort_validation():
    # Contracts: C9 (R4, R6). Repo guidance:
    # pandas/tests/reshape/concat/test_sort.py::test_concat_sort_none_raises.
    # Perspective: sort=None is rejected before data manipulation. Source path/symbol:
    # pandas/core/reshape/concat.py::concat sort validation.
    df = DataFrame({1: [1, 2], "a": [3, 4]})
    _raises(
        ValueError,
        re.escape("The 'sort' keyword only accepts boolean values; None was passed."),
        pd.concat,
        [df, df],
        sort=None,
    )


def check_C10_ignore_index_and_keys_failure():
    # Contracts: C10 (R4, R5). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_with_moot_ignore_index_and_keys.
    # Perspective: ignore_index=True and keys are mutually exclusive. Source path/symbol:
    # pandas/core/reshape/concat.py::concat validation.
    df1 = DataFrame([[0]])
    df2 = DataFrame([[42]])
    _raises(
        ValueError,
        re.escape("Cannot set ignore_index=True and specify keys. Either should be used."),
        pd.concat,
        [df1, df2],
        keys=["df1", "df2"],
        ignore_index=True,
    )


def check_C11_multiindex_keys_levels_names_construction():
    # Contracts: C11 (R5). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_keys_and_levels and
    # test_concat_keys_specific_levels. Perspective: keys/levels/names construct the
    # expected MultiIndex levels, codes, and names. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> _make_concat_multiindex.
    df = DataFrame(np.random.default_rng(2).standard_normal((1, 3)))
    df2 = DataFrame(np.random.default_rng(2).standard_normal((1, 4)))
    levels = [["foo", "baz"], ["one", "two"]]
    names = ["first", "second"]
    keys = [("foo", "one"), ("foo", "two"), ("baz", "one"), ("baz", "two")]

    result = pd.concat([df, df2, df, df2], keys=keys, levels=levels, names=names)
    expected = pd.concat([df, df2, df, df2])
    expected.index = MultiIndex(
        levels=levels + [[0]],
        codes=[[0, 0, 1, 1], [0, 1, 0, 1], [0, 0, 0, 0]],
        names=names + [None],
    )
    tm.assert_frame_equal(result, expected)

    result = pd.concat([df, df2, df, df2], keys=keys, names=["first", "second"])
    assert result.index.names == ("first", "second", None)
    tm.assert_index_equal(
        result.index.levels[0], Index(["baz", "foo"], name="first")
    )


def check_C11b_axis1_keys_levels_names_and_series_names():
    # Contracts: C11b (R5, R12). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_keys_specific_levels,
    # test_concat_with_group_keys (axis=1), and
    # pandas/tests/reshape/concat/test_series.py::test_concat_series_axis1_names_applied.
    # Perspective: successful axis=1 keys/levels/names paths must construct the
    # expected columns MultiIndex (including _make_concat_multiindex's unequal-index
    # branch) and Series axis=1 keys/names must not be ignored. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> _make_concat_multiindex -> _concat_indexes.
    df = DataFrame(np.random.default_rng(2).standard_normal((10, 4)))
    pieces = [df.iloc[:, [0, 1]], df.iloc[:, [2]], df.iloc[:, [3]]]
    level = ["three", "two", "one", "zero"]
    result = pd.concat(
        pieces,
        axis=1,
        keys=["one", "two", "three"],
        levels=[level],
        names=["group_key"],
    )
    tm.assert_index_equal(result.columns.levels[0], Index(level, name="group_key"))
    tm.assert_index_equal(result.columns.levels[1], Index([0, 1, 2, 3]))
    assert result.columns.names == ["group_key", None]

    s = Series([1, 2, 3])
    s2 = Series([4, 5, 6])
    result = pd.concat([s, s2], axis=1, keys=["a", "b"], names=["A"])
    expected = DataFrame(
        [[1, 4], [2, 5], [3, 6]], columns=Index(["a", "b"], name="A")
    )
    tm.assert_frame_equal(result, expected)

    dfa = DataFrame(np.random.default_rng(2).standard_normal((4, 3)))
    dfb = DataFrame(np.random.default_rng(2).standard_normal((4, 4)))
    result = pd.concat([dfa, dfb], keys=[0, 1], axis=1)
    exp_columns = MultiIndex.from_arrays(
        [[0, 0, 0, 1, 1, 1, 1], [0, 1, 2, 0, 1, 2, 3]]
    )
    expected = DataFrame(np.c_[dfa.values, dfb.values], columns=exp_columns)
    tm.assert_frame_equal(result, expected)


def check_C12_key_level_error_paths():
    # Contracts: C12 (R5). Repo guidance:
    # pandas/tests/reshape/concat/test_index.py::test_concat_with_duplicated_levels,
    # test_concat_with_levels_with_none_keys, and
    # pandas/tests/reshape/concat/test_concat.py::test_concat_keys_levels_no_overlap.
    # Perspective: levels without keys, duplicate levels, and keys absent from supplied
    # levels have distinct ValueError messages. Source path/symbol:
    # pandas/core/reshape/concat.py::_get_concat_axis_dataframe -> _make_concat_multiindex.
    df1 = DataFrame({"A": [1]}, index=["x"])
    df2 = DataFrame({"A": [1]}, index=["y"])

    _raises(
        ValueError,
        re.escape("levels supported only when keys is not None"),
        pd.concat,
        [df1, df2],
        levels=[["x", "y"]],
    )
    _raises(
        ValueError,
        r"Level values not unique: \['x', 'y', 'y'\]",
        pd.concat,
        [df1, df2],
        keys=["x", "y"],
        levels=[["x", "y", "y"]],
    )

    df_same = DataFrame({"A": [1]}, index=["a"])
    _raises(
        ValueError,
        "Values not found in passed level",
        pd.concat,
        [df_same, df_same],
        keys=["one", "two"],
        levels=[["foo", "bar", "baz"]],
    )
    _raises(
        ValueError,
        "Key one not in level",
        pd.concat,
        [df1, df2],
        keys=["one", "two"],
        levels=[["foo", "bar", "baz"]],
    )


def check_C13_keys_length_mismatch():
    # Contracts: C13 (R5). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_mismatched_keys_length.
    # Perspective: key length is checked after None filtering for both axes and for
    # generator inputs. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> _get_concat_axis_dataframe.
    ser = Series(range(5))
    sers = [ser + n for n in range(4)]
    keys = ["A", "B", "C"]

    for axis in [0, 1]:
        _raises(
            ValueError,
            r"The length of the keys",
            pd.concat,
            sers,
            keys=keys,
            axis=axis,
        )
        _raises(
            ValueError,
            r"The length of the keys",
            pd.concat,
            (x for x in sers),
            keys=(y for y in keys),
            axis=axis,
        )


def check_C14_verify_integrity_overlap():
    # Contracts: C14 (R5). Repo guidance: Interface docstring example,
    # pandas/tests/reshape/concat/test_append.py::test_append_overlap_raises, and
    # pandas/tests/reshape/concat/test_concat.py::test_concat_repeated_keys.
    # Perspective: verify_integrity=True rejects duplicate concat-axis labels with
    # the documented diagnostic prefix. Source path/symbol:
    # pandas/core/reshape/concat.py::_get_concat_axis_dataframe.
    df5 = DataFrame([1], index=["a"])
    df6 = DataFrame([2], index=["a"])
    _raises(
        ValueError,
        r"Indexes have overlapping values: ",
        pd.concat,
        [df5, df6],
        verify_integrity=True,
    )


def check_C17_other_axis_outer_inner_join_and_sort():
    # Contracts: C17 (R6, R8). Repo guidance:
    # pandas/tests/reshape/concat/test_dataframe.py::test_outer_sort_columns,
    # test_inner_sort_columns, and test_sort_columns_one_df. Perspective: outer
    # union fills NaN; inner intersection keeps common columns; sort controls
    # lexicographic order and sort=False preserves first-appearance order.
    # Source path/symbol: pandas/core/reshape/concat.py::concat -> new_axes ->
    # pandas/core/indexes/api.py::get_objs_combined_axis -> _get_combined_index.
    df1 = DataFrame({"A": [0], "B": [1], 0: 1})
    df2 = DataFrame({"A": [100]})

    result = pd.concat([df1, df2], ignore_index=True, join="outer", sort=True)
    expected = DataFrame({0: [1.0, np.nan], "A": [0, 100], "B": [1.0, np.nan]})
    tm.assert_frame_equal(result, expected)

    df3 = DataFrame({"A": [0], "B": [1], 0: 1})
    df4 = DataFrame({"A": [100], 0: 2})
    result = pd.concat([df3, df4], ignore_index=True, join="inner", sort=True)
    expected = DataFrame({0: [1, 2], "A": [0, 100]})
    tm.assert_frame_equal(result, expected)

    left = DataFrame({"B": [1]}, index=[0])
    right = DataFrame({"A": [2]}, index=[0])
    result = pd.concat([left, right], ignore_index=True, join="outer", sort=False)
    assert list(result.columns) == ["B", "A"]


def check_C17b_other_axis_unanimous_index_name_preservation():
    # Contracts: C17b (R6). Repo guidance:
    # pandas/tests/reshape/concat/test_index.py::test_concat_same_index_names.
    # Perspective: when the non-concat axis has unanimous index names the result
    # retains that name; when the names are mixed, the result name is dropped.
    # Source path/symbol: pandas/core/reshape/concat.py::concat -> new_axes ->
    # pandas/core/indexes/api.py::get_objs_combined_axis -> _get_combined_index.
    idx1 = Index(["a", "b", "c"], name="idx")
    idx2 = Index(["b", "c", "d"], name="idx")
    idx3 = Index(["c", "d", "e"], name="idx")
    frames = [
        DataFrame({"x": [0, 1, 2]}, index=idx1),
        DataFrame({"y": [0, 1, 2]}, index=idx2),
        DataFrame({"z": [0, 1, 2]}, index=idx3),
    ]
    result = pd.concat(frames, axis=1)
    expected_index = Index(["a", "b", "c", "d", "e"], name="idx")
    expected = DataFrame(
        {
            "x": [0, 1, 2, np.nan, np.nan],
            "y": [np.nan, 0, 1, 2, np.nan],
            "z": [np.nan, np.nan, 0, 1, 2],
        },
        index=expected_index,
    )
    tm.assert_frame_equal(result, expected)
    assert result.index.name == "idx"

    idx3_unnamed = Index(["c", "d", "e"], name=None)
    frames = [
        DataFrame({"x": [0, 1, 2]}, index=idx1),
        DataFrame({"y": [0, 1, 2]}, index=idx2),
        DataFrame({"z": [0, 1, 2]}, index=idx3_unnamed),
    ]
    result = pd.concat(frames, axis=1)
    expected_index = Index(["a", "b", "c", "d", "e"], name=None)
    assert result.index.name is None
    assert result.index.equals(expected_index)


def check_C18_datetime_outer_sort_exception():
    # Contracts: C18 (R6). Repo guidance: Interface docstring DatetimeIndex note;
    # no focused repository test identified in the IR. Perspective: for outer joins
    # on unaligned DatetimeIndex axes, the result is sorted even with sort=False.
    # Source path/symbol: pandas/core/reshape/concat.py::concat -> new_axes ->
    # pandas/core/indexes/api.py::get_objs_combined_axis -> union_indexes.
    idx1 = pd.DatetimeIndex(["2020-01-03", "2020-01-01"])
    idx2 = pd.DatetimeIndex(["2020-01-02", "2020-01-01"])
    df1 = DataFrame({"a": [1, 2]}, index=idx1)
    df2 = DataFrame({"b": [3, 4]}, index=idx2)

    result = pd.concat([df1, df2], axis=1, join="outer", sort=False)
    expected_index = pd.DatetimeIndex(["2020-01-01", "2020-01-02", "2020-01-03"])
    assert result.index.equals(expected_index)


def check_C19_single_object_concat_preserves_dtype_and_equality():
    # Contracts: C19 (R8, R11). Repo guidance:
    # pandas/tests/dtypes/test_concat.py::test_concat_single_dataframe_tz_aware.
    # Perspective: single-object concat does not disturb tz-aware dtype or values.
    # Source path/symbol: pandas/core/reshape/concat.py::concat -> concatenate_managers.
    df = pd.DataFrame(
        {"timestamp": [pd.Timestamp("2020-04-08 09:00:00+0000", tz="UTC")]}
    )
    result = pd.concat([df])
    tm.assert_frame_equal(result, df)
    assert result["timestamp"].dtype == df["timestamp"].dtype


def check_C20_extension_dtype_preservation():
    # Contracts: C20 (R8). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_frame_axis0_extension_dtypes
    # and test_concat_preserves_extension_int64_dtype. Perspective: nullable integer
    # extension dtype is preserved in both input orders and across outer columns.
    # Source path/symbol: pandas/core/reshape/concat.py::concat -> concatenate_managers.
    df1 = DataFrame({"a": pd.array([1, 2, 3], dtype="Int64")})
    df2 = DataFrame({"a": np.array([4, 5, 6])})
    result = pd.concat([df1, df2], ignore_index=True)
    expected = DataFrame({"a": [1, 2, 3, 4, 5, 6]}, dtype="Int64")
    tm.assert_frame_equal(result, expected)
    assert str(result["a"].dtype) == "Int64"

    result = pd.concat([df2, df1], ignore_index=True)
    expected = DataFrame({"a": [4, 5, 6, 1, 2, 3]}, dtype="Int64")
    tm.assert_frame_equal(result, expected)
    assert str(result["a"].dtype) == "Int64"

    df_a = DataFrame({"a": [-1]}, dtype="Int64")
    df_b = DataFrame({"b": [1]}, dtype="Int64")
    result = pd.concat([df_a, df_b], ignore_index=True)
    expected = DataFrame({"a": [-1, None], "b": [None, 1]}, dtype="Int64")
    tm.assert_frame_equal(result, expected)


def check_C21_bool_boolean_common_dtype():
    # Contracts: C21 (R8). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_bool_types and
    # pandas/tests/reshape/concat/test_series.py::test_concat_bool_and_numeric.
    # Perspective: bool/boolean common dtype follows pandas rules; bool plus numeric
    # produces object. Source path/symbol: pandas/core/reshape/concat.py::concat.
    pairs = [
        ("bool", "bool", "bool"),
        ("boolean", "bool", "boolean"),
        ("bool", "boolean", "boolean"),
        ("boolean", "boolean", "boolean"),
    ]
    for dtype1, dtype2, expected_dtype in pairs:
        ser1 = Series([True, False], dtype=dtype1)
        ser2 = Series([False, True], dtype=dtype2)
        result = pd.concat([ser1, ser2], ignore_index=True)
        expected = Series([True, False, False, True], dtype=expected_dtype)
        tm.assert_series_equal(result, expected)

    left = Series([True, False], dtype="bool")
    right = Series([1, 2], dtype=np.int64)
    result = pd.concat([left, right], ignore_index=True)
    expected = Series([True, False, 1, 2], dtype=object)
    tm.assert_series_equal(result, expected)
    assert result.iloc[0] is True
    assert type(result.iloc[2]) is int


def check_C22_categorical_dtype_preservation_and_incompatible_cast():
    # Contracts: C22 (R8, R10). Repo guidance:
    # pandas/tests/reshape/concat/test_categorical.py::test_categorical_concat_preserve
    # and test_categorical_index_preserver. Perspective: same-category Series keep
    # category dtype; different categories cast to object; incompatible categorical
    # indexes cast to object. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> concatenate_managers.
    s = Series(list("abc"), dtype="category")
    result = pd.concat([s, s], ignore_index=True)
    expected = Series(list("abcabc"), dtype="category")
    tm.assert_series_equal(result, expected)

    s2 = Series(list("abd"), dtype="category")
    result = pd.concat([s, s2], ignore_index=True)
    expected = Series(list("abcabd"))
    tm.assert_series_equal(result, expected)
    assert result.dtype == object

    a = Series([1, 2], index=pd.CategoricalIndex(["foo", "bar"]))
    b = Series([4, 3], index=pd.CategoricalIndex(["baz", "bar"]))
    result = pd.concat([a, b])
    expected = Series([1, 2, 4, 3], index=["foo", "bar", "baz", "bar"])
    tm.assert_series_equal(result, expected)


def check_C23_sparse_and_dense_sparse_concat():
    # Contracts: C23 (R8, R9). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_sparse and
    # test_concat_dense_sparse. Perspective: sparse dtypes are preserved for
    # compatible sparse and dense-sparse concatenation. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> concatenate_managers -> concat_compat.
    a = Series(pd.arrays.SparseArray([0, 1, 2]))
    expected = DataFrame(data=[[0, 0], [1, 1], [2, 2]]).astype(
        pd.SparseDtype(np.int64, 0)
    )
    result = pd.concat([a, a], axis=1)
    tm.assert_frame_equal(result, expected)

    dtype = pd.SparseDtype(np.float64, None)
    a = Series(pd.arrays.SparseArray([1, None]), dtype=dtype)
    b = Series([1], dtype=float)
    expected = Series(data=[1, None, 1], index=[0, 1, 0]).astype(dtype)
    result = pd.concat([a, b], axis=0)
    tm.assert_series_equal(result, expected)


def check_C24_float_int_upcast_and_no_unnecessary_upcast():
    # Contracts: C24 (R8, R10). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_no_unnecessary_upcast,
    # test_concat_will_upcast, and test_concat_empty_and_non_empty_frame_regression.
    # Perspective: float with NaN stays float; int with NaN upcasts to float64;
    # empty + non-empty int upcasts to float. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> concatenate_managers.
    dfs = [
        Series([1.0], dtype="float64"),
        Series([np.nan], dtype="float64"),
        Series([5.0], dtype="float64"),
    ]
    result = pd.concat(dfs)
    assert result.dtype == np.float64

    dfs = [Series([1], dtype="int64"), Series([np.nan]), Series([5], dtype="int64")]
    result = pd.concat(dfs)
    assert result.dtype == np.float64

    df1 = DataFrame({"foo": [1]})
    df2 = DataFrame({"foo": []})
    result = pd.concat([df1, df2])
    expected = DataFrame({"foo": [1.0]})
    tm.assert_frame_equal(result, expected)


def check_C25b_concat_compat_dimension_mismatch_failure():
    # Contracts: C25b (R9). Repo guidance:
    # pandas/tests/dtypes/test_concat.py::test_concat_periodarray_2d mismatch cases.
    # Perspective: concat_compat validates non-concatenation dimensions and raises
    # ValueError with the repository-supported full pattern. Source path/symbol:
    # pandas/core/dtypes/concat.py::concat_compat.
    import pandas.core.dtypes.concat as _concat

    pi = pd.period_range("2016-01-01", periods=36, freq="D")
    arr = pi._data.reshape(6, 6)
    pattern = r"all the input array dimensions.* for the concatenation axis must match exactly"
    _raises(
        ValueError,
        pattern,
        _concat.concat_compat,
        [arr[:, :2], arr[:, 2:]],
        axis=0,
    )
    _raises(
        ValueError,
        pattern,
        _concat.concat_compat,
        [arr[:2], arr[2:]],
        axis=1,
    )


def check_C27_empty_all_na_block_dtype_handling():
    # Contracts: C27 (R10). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_ignore_empty_object_float,
    # test_concat_ignore_all_na_object_float, and test_concat_ignore_empty_from_reindex.
    # Perspective: empty/all-NA blocks participate in dtype inference without
    # spuriously coercing non-empty data. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> concatenate_managers ->
    # pandas/core/internals/concat.py::_concatenate_join_units.
    df = DataFrame({"foo": [1, 2]}, dtype="int64")
    empty = DataFrame(columns=["foo"], dtype=object)
    result = pd.concat([empty, df])
    expected = df.astype(object)
    tm.assert_frame_equal(result, expected)

    df = DataFrame({"foo": [1, 2]}, dtype="int64")
    empty = DataFrame({"foo": [np.nan]}, dtype=object)
    result = pd.concat([empty, df], ignore_index=True)
    expected = DataFrame({"foo": [np.nan, 1, 2]}, dtype=object)
    tm.assert_frame_equal(result, expected)

    df1 = DataFrame({"a": [1], "b": [pd.Timestamp("2012-01-01")]})
    df2 = DataFrame({"a": [2]})
    aligned = df2.reindex(columns=df1.columns)
    result = pd.concat([df1, aligned], ignore_index=True)
    expected = DataFrame(
        {
            "a": [1, 2],
            "b": pd.array([pd.Timestamp("2012-01-01"), np.nan], dtype=object),
        },
        dtype=object,
    )
    expected["a"] = expected["a"].astype("int64")
    tm.assert_frame_equal(result, expected)


def check_C28_subclass_and_attrs_preservation():
    # Contracts: C28 (R7). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_preserves_subclass,
    # test_concat_drop_attrs, and test_concat_retain_attrs. Perspective: subclass
    # type is preserved; attrs are retained only when identical. Source path/symbol:
    # pandas/core/reshape/concat.py::concat result construction.
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        obj = tm.SubclassedDataFrame({"A": np.arange(0, 10)})
        result = pd.concat([obj, obj])
        assert isinstance(result, type(obj))

        obj = tm.SubclassedSeries(np.arange(0, 10), name="A")
        result = pd.concat([obj, obj])
        assert isinstance(result, type(obj))

    s1 = Series(data=[1, 2])
    s1.attrs = {1: 1}
    s2 = Series(data=[1, 2])
    s2.attrs = {1: 2}
    assert len(pd.concat([s1, s2]).attrs) == 0

    s1 = Series(data=[1, 2])
    s1.attrs = {1: 1}
    s2 = Series(data=[1, 2])
    s2.attrs = {1: 1}
    assert pd.concat([s1, s2]).attrs[1] == 1


def check_C29_axis_dependent_index_identity():
    # Contracts: C29 (R7, R11). Repo guidance:
    # pandas/tests/reshape/concat/test_index.py::test_concat_copy_index_series and
    # test_concat_copy_index_frame. Perspective: the concat axis is new; the other
    # axis is shared. Series use ``is`` and DataFrame Index uses ``Index.is_`` to
    # work correctly through views. Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> new_axes.
    ser = Series([1, 2])
    comb = pd.concat([ser, ser], axis=0)
    assert comb.index is not ser.index
    assert comb.index.equals(Index([0, 1, 0, 1]))

    comb = pd.concat([ser, ser], axis=1)
    assert comb.index is ser.index

    df = DataFrame([[1, 2], [3, 4]], columns=["a", "b"])
    comb = pd.concat([df, df], axis=0)
    assert not comb.index.is_(df.index)
    assert comb.columns.is_(df.columns)

    comb = pd.concat([df, df], axis=1)
    assert comb.index.is_(df.index)
    assert not comb.columns.is_(df.columns)


def check_C30_axis1_copy_memory_sharing():
    # Contracts: C30 (R11). Repo guidance:
    # pandas/tests/reshape/concat/test_concat.py::test_concat_copy.
    # Perspective: copy=False axis=1 concat branches by dtype: float/int blocks share
    # their source block base, while object blocks are freshly allocated and need
    # only have a non-None base. This preserves the repository test's dtype dispatch
    # instead of overstating memory sharing for object/numpy blocks.
    # Source path/symbol:
    # pandas/core/reshape/concat.py::concat -> concatenate_managers.
    df = DataFrame(np.random.default_rng(2).standard_normal((4, 3)))
    df2 = DataFrame(np.random.default_rng(2).integers(0, 10, size=4).reshape(4, 1))
    df3 = DataFrame(
        {5: ["foo", "bar", "baz", "qux"]}, index=range(4), dtype=object
    )

    result = pd.concat([df, df2, df3], axis=1)
    assert result.shape == (4, 5)

    float_blocks = [block.values for block in df._mgr.blocks]
    int_blocks = [block.values for block in df2._mgr.blocks]
    object_blocks = [block.values for block in df3._mgr.blocks]

    seen = set()
    for block in result._mgr.blocks:
        arr = block.values
        if arr.dtype.kind == "f":
            seen.add("float")
            assert arr.base is df._mgr.blocks[0].values.base
        elif arr.dtype.kind in ("i", "u"):
            seen.add("int")
            assert arr.base is df2._mgr.blocks[0].values.base
        elif arr.dtype == object:
            seen.add("object")
            assert arr.base is not None
        elif arr.dtype == "string":
            seen.add("string")
            tm.shares_memory(arr, df3._mgr.blocks[0].values)
        else:  # pragma: no cover - diagnostic aid
            raise AssertionError(f"unexpected block dtype in copy check: {arr.dtype}")

    assert {"float", "int", "object"}.issubset(seen)


def _main():
    checks = [
        check_C3_basic_series_concat_and_ignore_index,
        check_C4_empty_and_all_none_failures,
        check_C5_collection_normalization_none_filtering_and_iterables,
        check_C6_invalid_object_and_first_argument_failures,
        check_C7_mixed_series_dataframe_normalization,
        check_C8_axis_parameter_aliases_and_invalid_axis,
        check_C8b_invalid_join_failure,
        check_C9_sort_validation,
        check_C10_ignore_index_and_keys_failure,
        check_C11_multiindex_keys_levels_names_construction,
        check_C11b_axis1_keys_levels_names_and_series_names,
        check_C12_key_level_error_paths,
        check_C13_keys_length_mismatch,
        check_C14_verify_integrity_overlap,
        check_C17_other_axis_outer_inner_join_and_sort,
        check_C17b_other_axis_unanimous_index_name_preservation,
        check_C18_datetime_outer_sort_exception,
        check_C19_single_object_concat_preserves_dtype_and_equality,
        check_C20_extension_dtype_preservation,
        check_C21_bool_boolean_common_dtype,
        check_C22_categorical_dtype_preservation_and_incompatible_cast,
        check_C23_sparse_and_dense_sparse_concat,
        check_C24_float_int_upcast_and_no_unnecessary_upcast,
        check_C25b_concat_compat_dimension_mismatch_failure,
        check_C27_empty_all_na_block_dtype_handling,
        check_C28_subclass_and_attrs_preservation,
        check_C29_axis_dependent_index_identity,
        check_C30_axis1_copy_memory_sharing,
    ]
    for check in checks:
        check()
        print(f"PASS: {check.__name__}")


if __name__ == "__main__":
    try:
        _main()
    except Exception:
        import traceback

        traceback.print_exc()
        sys.exit(1)
