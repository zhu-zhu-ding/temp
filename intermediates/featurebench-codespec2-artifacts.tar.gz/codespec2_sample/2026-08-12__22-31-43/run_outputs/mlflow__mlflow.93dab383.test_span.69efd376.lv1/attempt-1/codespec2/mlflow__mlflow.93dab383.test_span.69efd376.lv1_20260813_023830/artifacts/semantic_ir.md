# Semantic IR

IR = <R, G, C>

This document compiles the task document, the three interface descriptions,
repository source, repository tests, and the supplied static-analysis artifacts
into a typed requirement representation. Repository paths are relative to
`/testbed`. The reference implementation copies under
`/testbed/libs/tracing/mlflow` and `/testbed/libs/skinny/mlflow` are treated as
repository evidence for the intended behavior; they are not runtime proof and
every material claim is paired with a verifiable contract below.

---

## L1. Requirement Obligations

### R1: `_Trace.to_mlflow_trace` finalization
- **Type**: state / dataflow / interface
- **Statement**: `_Trace.to_mlflow_trace()` must create a `TraceData`, append
  `span.to_immutable_span()` for every `LiveSpan` in `span_dict`, call
  `set_request_response_preview(self.info, trace_data)`, and return
  `Trace(self.info, trace_data)`.
- **Task Evidence**: Interface Description 1; task statement "Support both live
  (mutable) and immutable span states during execution lifecycle" and
  "thread-safe in-memory trace management".
- **Acceptance**: The returned object is `mlflow.entities.Trace`; its
  `data.spans` contains the same number of spans as the internal `span_dict`;
  every returned span is an immutable `Span` and not a `LiveSpan`; the original
  `_Trace` object still contains `LiveSpan` values.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/trace_manager.py`
  `_Trace.to_mlflow_trace`; `tests/tracing/test_trace_manager.py`
  `test_add_spans` asserts `trace.data.spans` are `Span`, not `LiveSpan`.
- **Uncertainty**: None.

### R2: `set_request_response_preview` dependency
- **Type**: dependency / dataflow
- **Statement**: `mlflow.tracing.utils.truncation.set_request_response_preview`
  must exist, be importable, and update `TraceInfo.request_preview` and
  `TraceInfo.response_preview` only when the current values are `None`.
- **Task Evidence**: Interface Description 1 says `to_mlflow_trace` "calls
  set_request_response_preview to populate preview data".
- **Acceptance**: Import succeeds; calling with `TraceInfo` previews `None`
  populates both previews from root span inputs/outputs; existing previews are
  preserved.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`;
  `tests/tracing/utils/test_truncation.py`.
- **Uncertainty**: The current `/testbed/mlflow/tracing/utils/truncation.py`
  lacks `set_request_response_preview`; the function must be added or imported.

### R3: `TraceData.request` and `TraceData.response` dependencies
- **Type**: dependency / dataflow
- **Statement**: `TraceData` must expose `request` and `response` properties
  returning the root span's raw serialized `mlflow.spanInputs` and
  `mlflow.spanOutputs` attribute values, or `None` when no root span exists.
- **Task Evidence**: Interface Description 1 requires request/response preview
  population; `set_request_response_preview` consumes `trace_data.request` and
  `trace_data.response`.
- **Acceptance**: For a `TraceData` with a root span carrying serialized inputs
  and outputs, the properties return those raw strings; empty trace returns
  `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/trace_data.py`.
- **Uncertainty**: The current `/testbed/mlflow/entities/trace_data.py` does not
  define these two properties.

### R4: `Span.attributes` returns deserialized attribute dictionary
- **Type**: interface / dataflow
- **Statement**: `Span.attributes` must return a `dict[str, Any]` containing all
  OTel span attributes, deserialized from their JSON-string storage format to
  their original Python values.
- **Task Evidence**: Interface Description 2, `Span.attributes`.
- **Acceptance**: For a span with attributes set through `set_attribute` or
  constructed with dumped values, `span.attributes` equals the original
  key-value objects.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.attributes` and `_SpanAttributesRegistry.get_all`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks both
  `Span.attributes` and `_SpanAttributesRegistry.get_all`.

### R5: `Span.events` returns `SpanEvent` list with plain dictionaries
- **Type**: interface / dataflow
- **Statement**: `Span.events` must return `list[SpanEvent]`, converting OTel
  `BoundedAttributes` event attributes to plain `dict` values; an eventless span
  returns `[]`.
- **Task Evidence**: Interface Description 2, `Span.events`.
- **Acceptance**: Event names, nanosecond timestamps, and attributes are
  preserved; `dict(event.attributes)` does not raise during serialization.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.events`; `tests/tracing/opentelemetry/test_integration.py`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks
  `Span.events`.

### R6: `Span.request_id` is an alias for `trace_id`
- **Type**: interface / compatibility
- **Statement**: `Span.request_id` must return the same value as `trace_id`.
- **Task Evidence**: Interface Description 2, `Span.request_id`.
- **Acceptance**: `span.request_id == span.trace_id`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.request_id`.
- **Uncertainty**: None.

### R7: `Span.span_type` reads the span-type attribute
- **Type**: interface / compatibility
- **Statement**: `Span.span_type` must return
  `get_attribute(SpanAttributeKey.SPAN_TYPE)`.
- **Task Evidence**: Interface Description 2, `Span.span_type`.
- **Acceptance**: A span whose `mlflow.spanType` attribute is `"LLM"` returns
  `"LLM"`; a span without the attribute returns `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.span_type`.
- **Uncertainty**: None.

### R8: `Span.to_dict` v3 base64 serialization
- **Type**: interface / compatibility / dataflow
- **Statement**: `Span.to_dict()` must return the OTLP-compatible v3 dictionary
  with `trace_id`, `span_id`, and `parent_span_id` encoded as base64 strings:
  trace ID integer -> exactly 16 big-endian bytes -> standard base64 UTF-8;
  span/parent ID integer -> exactly 8 big-endian bytes -> standard base64 UTF-8.
  It must also include `name`, `start_time_unix_nano`, `end_time_unix_nano`,
  `events`, `status`, and `attributes` with dumped attribute values.
- **Task Evidence**: Interface Description 2, `Span.to_dict`; task statement
  "Enable trace data serialization/deserialization across different formats
  (dict, protobuf)".
- **Acceptance**: The returned dictionary has the documented keys and base64
  values produced by `int.to_bytes(...)` + `base64.b64encode(...).decode("utf-8")`;
  status code is the OTel proto code name; attributes are the raw serialized
  OTel attribute values.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.to_dict` and `_encode_span_id_to_byte`, `_encode_trace_id_to_byte`,
  `_encode_bytes_to_base64`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks `to_dict`
  and the three encoding helpers.

### R9: `Span.from_dict` deserialization across v3 base64, v3 legacy, and v2 schemas
- **Type**: interface / compatibility / failure
- **Statement**: `Span.from_dict` must reconstruct an immutable `Span` from the
  v3 base64 schema, the legacy 3.5.0 non-base64 schema, and the v2 `context`
  schema.
- **Task Evidence**: Task statement "Handle multiple serialization schemas
  (v2, v3) for backward compatibility"; Interface Description 2 `Span.to_dict`
  describes round-trip compatibility.
- **Acceptance**: `Span.from_dict(Span.to_dict(span))` round-trips; a v2 dict
  with `context` and `parent_id` fields reconstructs; a legacy dict with
  `"tr-..."` trace ID reconstructs.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.from_dict`, `Span._is_span_v2_schema`, `Span.from_dict_v2`;
  `tests/tracing/test_fluent.py` uses `Trace.from_dict` remote traces.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` references
  `Span._is_span_v2_schema` and `cls.from_dict_v2` but does not define them.

### R10: `Span.from_dict` missing request-ID failure
- **Type**: failure
- **Statement**: `Span.from_dict` must raise `MlflowException` with
  `INVALID_PARAMETER_VALUE` when `mlflow.traceRequestId` is empty or missing
  from `data["attributes"]`.
- **Task Evidence**: Existing source logic and `libs/tracing` behavior.
- **Acceptance**: Calling `Span.from_dict({"attributes": {}})` raises
  `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` lines 262-267;
  `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R11: `Span.from_otel_proto` protobuf conversion
- **Type**: interface / compatibility / dataflow
- **Statement**: `Span.from_otel_proto` must convert an OpenTelemetry protobuf
  span into an immutable MLflow `Span`. It decodes trace/span/parent IDs from
  protobuf bytes, maps OTel proto status codes to OTel SDK status codes,
  generates `tr-<hex>` MLflow trace ID when `location_id` is `None`, generates
  `trace:/<location>/<hex>` when `location_id` is provided, JSON-dumps decoded
  attributes and adds the MLflow `REQUEST_ID` attribute, and preserves events
  with decoded attributes.
- **Task Evidence**: Interface Description 2, `Span.from_otel_proto`; task
  statement "Provide OpenTelemetry protocol compatibility for trace data
  exchange".
- **Acceptance**: Given an `OTelProtoSpan` with known bytes and attributes,
  the returned `Span` has expected `trace_id`, `span_id`, `parent_id`,
  `span_type`, `events`, and decoded attributes.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.from_otel_proto`; `libs/tracing/mlflow/tracing/utils/otlp.py`
  `_otel_proto_bytes_to_id`; `tests/tracing/test_otel_logging.py`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` and
  `/testbed/mlflow/tracing/utils/otlp.py` lack `from_otel_proto` and
  `_otel_proto_bytes_to_id`.

### R12: `Span.to_otel_proto` OTLP export conversion
- **Type**: interface / compatibility / dataflow
- **Statement**: `Span.to_otel_proto()` must return an `OTelProtoSpan` with
  `trace_id` and `span_id` as `bytes.fromhex` of MLflow hex IDs, optional
  `parent_span_id`, name, nanosecond start/end times, protobuf status, all
  attributes encoded as OTel `AnyValue`, and all events encoded via
  `SpanEvent.to_otel_proto()`.
- **Task Evidence**: Interface Description 2, `Span.to_otel_proto`.
- **Acceptance**: Fields on the returned protobuf span match the source MLflow
  span; attributes survive a `_decode_otel_proto_anyvalue` round-trip; root
  span omits `parent_span_id`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `Span.to_otel_proto`; `mlflow/entities/span_event.py`
  `SpanEvent.to_otel_proto`; `tests/entities/test_span_event.py`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks
  `to_otel_proto`.

### R13: `LiveSpan.from_dict` unsupported
- **Type**: failure / interface
- **Statement**: `LiveSpan.from_dict` must always raise `NotImplementedError`.
- **Task Evidence**: Interface Description 2, `LiveSpan.from_dict`.
- **Acceptance**: Calling `LiveSpan.from_dict({})` raises `NotImplementedError`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `LiveSpan.from_dict`.
- **Uncertainty**: None.

### R14: `LiveSpan.set_span_type` updates span-type attribute
- **Type**: side-effect / interface
- **Statement**: `LiveSpan.set_span_type(span_type)` must set the
  `mlflow.spanType` attribute through `set_attribute`.
- **Task Evidence**: Interface Description 2, `LiveSpan.set_span_type`.
- **Acceptance**: After `span.set_span_type("TOOL")`,
  `span.get_attribute(SpanAttributeKey.SPAN_TYPE) == "TOOL"` and
  `span.span_type == "TOOL"`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `LiveSpan.set_span_type`; callers in `mlflow/bedrock/_autolog.py`,
  `mlflow/haystack/autolog.py`, `mlflow/strands/autolog.py`.
- **Uncertainty**: None.

### R15: `LiveSpan.to_immutable_span` downcast
- **Type**: state / interface
- **Statement**: `LiveSpan.to_immutable_span()` must return `Span(self._span)`,
  reusing the underlying OTel span without copying span state.
- **Task Evidence**: Interface Description 2, `LiveSpan.to_immutable_span`;
  Interface Description 1 depends on this conversion.
- **Acceptance**: The returned object is `Span` and not `LiveSpan`; its
  `_span` is the same object as the live span's `_span`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `LiveSpan.to_immutable_span`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks this method.

### R16: `LiveSpan.end` span-processor application and termination
- **Type**: side-effect / lifecycle
- **Statement**: `LiveSpan.end` must set final attributes/outputs/status, set
  status to `OK` when not `ERROR`, call `apply_span_processors(self)`, and end
  the underlying OTel span. Exceptions are caught and logged, not raised.
- **Task Evidence**: Task statement "Span lifecycle management (creation,
  attribute setting, status updates, termination)"; static issue
  `apply_span_processors` in `mlflow/entities/span.py`.
- **Acceptance**: A configured span processor mutates the live span during
  `end()`; the underlying OTel span receives `end(end_time=...)`; processor
  exceptions do not propagate.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `LiveSpan.end`; `tests/tracing/utils/test_processor.py`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` uses
  `apply_span_processors` without importing it, and
  `/testbed/mlflow/tracing/utils/processor.py` does not define it.

### R17: `NoOpSpan._trace_id` returns `None`
- **Type**: interface
- **Statement**: `NoOpSpan._trace_id` must return `None`.
- **Task Evidence**: Interface Description 2, `NoOpSpan._trace_id`.
- **Acceptance**: `NoOpSpan()._trace_id is None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R18: `NoOpSpan.add_event` is a no-op
- **Type**: interface / side-effect
- **Statement**: `NoOpSpan.add_event(event)` must accept a `SpanEvent`, return
  `None`, and perform no work.
- **Task Evidence**: Interface Description 2, `NoOpSpan.add_event`.
- **Acceptance**: Calling with a real `SpanEvent` does not raise and returns
  `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R19: `NoOpSpan.end` is a no-op
- **Type**: interface / side-effect
- **Statement**: `NoOpSpan.end(outputs, attributes, status, end_time_ns)` must
  accept the full end signature, return `None`, and perform no work.
- **Task Evidence**: Interface Description 2, `NoOpSpan.end`.
- **Acceptance**: Calling with any arguments does not raise and returns `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R20: `NoOpSpan.end_time_ns` returns `None`
- **Type**: interface
- **Statement**: `NoOpSpan.end_time_ns` must return `None`.
- **Task Evidence**: Interface Description 2, `NoOpSpan.end_time_ns`.
- **Acceptance**: `NoOpSpan().end_time_ns is None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R21: `NoOpSpan.name` returns `None`
- **Type**: interface
- **Statement**: `NoOpSpan.name` must return `None`.
- **Task Evidence**: Interface Description 2, `NoOpSpan.name`.
- **Acceptance**: `NoOpSpan().name is None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R22: `NoOpSpan.set_attribute` is a no-op
- **Type**: interface / side-effect
- **Statement**: `NoOpSpan.set_attribute(key, value)` must return `None` and
  perform no work.
- **Task Evidence**: Interface Description 2, `NoOpSpan.set_attribute`.
- **Acceptance**: Calling does not raise and returns `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R23: `NoOpSpan.set_attributes` is a no-op
- **Type**: interface / side-effect
- **Statement**: `NoOpSpan.set_attributes(attributes)` must return `None` and
  perform no work.
- **Task Evidence**: Interface Description 2, `NoOpSpan.set_attributes`.
- **Acceptance**: Calling with a dict does not raise and returns `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R24: `NoOpSpan.set_inputs` is a no-op
- **Type**: interface / side-effect
- **Statement**: `NoOpSpan.set_inputs(inputs)` must return `None` and perform no
  work.
- **Task Evidence**: Interface Description 2, `NoOpSpan.set_inputs`.
- **Acceptance**: Calling with `{"x": 1}` does not raise and returns `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R25: `NoOpSpan.set_outputs` is a no-op
- **Type**: interface / side-effect
- **Statement**: `NoOpSpan.set_outputs(outputs)` must return `None` and perform
  no work.
- **Task Evidence**: Interface Description 2, `NoOpSpan.set_outputs`.
- **Acceptance**: Calling with any value does not raise and returns `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R26: `NoOpSpan.set_status` is a no-op
- **Type**: interface / side-effect
- **Statement**: `NoOpSpan.set_status(status)` must return `None` and perform no
  work.
- **Task Evidence**: Interface Description 2, `NoOpSpan.set_status`.
- **Acceptance**: Calling with a `SpanStatus` or string does not raise and
  returns `None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R27: `NoOpSpan.span_id` returns `None`
- **Type**: interface
- **Statement**: `NoOpSpan.span_id` must return `None`.
- **Task Evidence**: Interface Description 2, `NoOpSpan.span_id`.
- **Acceptance**: `NoOpSpan().span_id is None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R28: `NoOpSpan.start_time_ns` returns `None`
- **Type**: interface
- **Statement**: `NoOpSpan.start_time_ns` must return `None`.
- **Task Evidence**: Interface Description 2, `NoOpSpan.start_time_ns`.
- **Acceptance**: `NoOpSpan().start_time_ns is None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R29: `NoOpSpan.status` returns `None`
- **Type**: interface
- **Statement**: `NoOpSpan.status` must return `None`.
- **Task Evidence**: Interface Description 2, `NoOpSpan.status`.
- **Acceptance**: `NoOpSpan().status is None`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R30: `NoOpSpan.trace_id` returns the no-op constant
- **Type**: interface / compatibility
- **Statement**: `NoOpSpan.trace_id` must return `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- **Task Evidence**: Interface Description 2, `NoOpSpan.trace_id`.
- **Acceptance**: `NoOpSpan().trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` defines
  `NO_OP_SPAN_TRACE_ID`; `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R31: `_CachedSpanAttributesRegistry.set` is forbidden
- **Type**: failure / state
- **Statement**: `_CachedSpanAttributesRegistry.set(key, value)` must always
  raise `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Task Evidence**: Interface Description 2,
  `_CachedSpanAttributesRegistry.set`; task statement "Implement efficient
  caching for immutable span attributes while preventing updates".
- **Acceptance**: Calling `set` on the cached registry raises
  `MlflowException`; its `error_code` is `INVALID_PARAMETER_VALUE`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `_CachedSpanAttributesRegistry.set`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks this
  override.

### R32: `create_mlflow_span` factory dispatch
- **Type**: interface / control
- **Statement**: `create_mlflow_span(otel_span, trace_id, span_type=None)` must
  return:
  - `NoOpSpan()` for `None` or `NonRecordingSpan`;
  - `LiveSpan(otel_span, trace_id, span_type)` for `OTelSpan`;
  - `Span(otel_span)` for `OTelReadableSpan`.
- **Task Evidence**: Interface Description 2, `create_mlflow_span`.
- **Acceptance**: The concrete return type matches the input OTel span type;
  live spans receive the passed trace ID and span type.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`
  `create_mlflow_span`; many callers in `mlflow/tracing/processor/*` and
  autologging integrations.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks this
  function.

### R33: `create_mlflow_span` invalid input failure
- **Type**: failure
- **Statement**: `create_mlflow_span` must raise `MlflowException` with
  `INVALID_PARAMETER_VALUE` for an input that is neither `None`,
  `NonRecordingSpan`, `OTelSpan`, nor `OTelReadableSpan`.
- **Task Evidence**: Interface Description 2, `create_mlflow_span` Raises.
- **Acceptance**: Passing e.g. `object()` raises `MlflowException` with
  `INVALID_PARAMETER_VALUE`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R34: `BaseMlflowSpanProcessor.on_start` binds `create_mlflow_span`
- **Type**: dependency / caller binding
- **Statement**: `mlflow/tracing/processor/base_mlflow.py` must import
  `create_mlflow_span` from `mlflow.entities.span`, and
  `BaseMlflowSpanProcessor.on_start` must call it with `(span, trace_id)` and
  pass the result to `InMemoryTraceManager.get_instance().register_span`.
- **Task Evidence**: Static issue `create_mlflow_span` used but not defined or
  imported in `mlflow/tracing/processor/base_mlflow.py`; Interface Description
  2 defines `create_mlflow_span`.
- **Acceptance**: Importing the module succeeds and `on_start` invokes the real
  `create_mlflow_span` callable at its call site.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/processor/base_mlflow.py`
  imports `create_mlflow_span`.
- **Uncertainty**: None.

### R35: `_decode_otel_proto_anyvalue` primitive decoding
- **Type**: interface / dataflow
- **Statement**: `_decode_otel_proto_anyvalue(pb_any_value)` must use
  `WhichOneof("value")` and return `None` for an unset value, or the
  corresponding `bool`, `str`, `int`, `float`, or `bytes` value for primitive
  fields.
- **Task Evidence**: Interface Description 3.
- **Acceptance**: For each primitive `AnyValue`, the returned Python object has
  the exact type and value.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/otlp.py`
  `_decode_otel_proto_anyvalue`; `tests/entities/test_span_event.py`.
- **Uncertainty**: None.

### R36: `_decode_otel_proto_anyvalue` recursive array and key-value decoding
- **Type**: interface / dataflow
- **Statement**: The function must recursively decode `array_value` to a Python
  `list` and `kvlist_value` to a Python `dict` with string keys, preserving
  nested values.
- **Task Evidence**: Interface Description 3.
- **Acceptance**: Nested arrays and key-value lists round-trip from
  `_set_otel_proto_anyvalue` to `_decode_otel_proto_anyvalue`.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/otlp.py`;
  `tests/entities/test_span_event.py` (decodes lists and dicts).
- **Uncertainty**: None.

### R37: `_otel_proto_bytes_to_id` helper
- **Type**: dependency / dataflow
- **Statement**: `mlflow/tracing/utils/otlp.py` must define
  `_otel_proto_bytes_to_id(id_bytes)` as `int.from_bytes(id_bytes, byteorder="big",
  signed=False)`.
- **Task Evidence**: Required by `Span.from_otel_proto` (Interface Description
  2); repository reference.
- **Acceptance**: The helper converts protobuf ID bytes to the same integer used
  by OTel SDK contexts.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/otlp.py`.
- **Uncertainty**: Current `/testbed/mlflow/tracing/utils/otlp.py` lacks this
  helper.

### R38: `_SpanAttributesRegistry.get_all` helper
- **Type**: dependency / dataflow
- **Statement**: `_SpanAttributesRegistry` must define
  `get_all()` returning `{key: self.get(key) for key in self._span.attributes.keys()}`.
- **Task Evidence**: Required by `Span.attributes` (Interface Description 2).
- **Acceptance**: `get_all()` returns every OTel span attribute deserialized.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks `get_all`.

### R39: ID and base64 encoding helpers
- **Type**: dependency / dataflow
- **Statement**: `mlflow/entities/span.py` must define
  `_encode_span_id_to_byte`, `_encode_trace_id_to_byte`, and
  `_encode_bytes_to_base64` with the byte lengths and base64 scheme documented
  in `Span.to_dict`.
- **Task Evidence**: Interface Description 2, `Span.to_dict` encoding notes.
- **Acceptance**: Trace IDs use 16-byte big-endian; span/parent IDs use 8-byte
  big-endian; base64 uses `base64.b64encode` decoded as UTF-8.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` lacks these
  helpers.

### R40: Base64 detection and decoding helpers
- **Type**: dependency / dataflow
- **Statement**: `mlflow/entities/span.py` must define
  `_is_base64_encoded(trace_or_span_id)` and
  `_decode_id_from_byte(trace_or_span_id_b64)`; detection uses
  `base64.b64decode(..., validate=True)` and decoding returns
  `int.from_bytes(base64.b64decode(value), byteorder="big", signed=False)`.
- **Task Evidence**: Static issues `_is_base64_encoded` and
  `_decode_id_from_byte`; Interface Description 2 `Span.to_dict` round-trip.
- **Acceptance**: Valid base64 IDs are detected and decoded; invalid strings
  return `False` from `_is_base64_encoded`.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: None.

### R41: v2 schema detection and conversion helpers
- **Type**: dependency / compatibility
- **Statement**: `Span` must define `_is_span_v2_schema(data)` returning
  `"context" in data`, and `from_dict_v2(data)` reconstructing a `Span` from the
  v2 `context`, `parent_id`, `start_time`, `end_time`, `status_code`,
  `status_message`, and event fields.
- **Task Evidence**: Task statement "Handle multiple serialization schemas
  (v2, v3)"; current `Span.from_dict` references these methods.
- **Acceptance**: v2 dictionaries produce a `Span` with decoded IDs and status.
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Uncertainty**: Current `/testbed/mlflow/entities/span.py` references these
  methods but does not define them.

### R42: `apply_span_processors` helper
- **Type**: dependency / side-effect
- **Statement**: `mlflow/tracing/utils/processor.py` must define
  `apply_span_processors(span)` to read `mlflow.tracing.config.get_config()`
  and invoke each configured processor sequentially, ignoring non-`None`
  returns with a warning and catching per-processor exceptions with a warning.
- **Task Evidence**: Static issue `apply_span_processors`;
  `tests/tracing/utils/test_processor.py`.
- **Acceptance**: Multiple processors are applied in order; a failing processor
  does not prevent later processors; non-`None` returns are ignored with a
  warning.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/processor.py`.
- **Uncertainty**: Current `/testbed/mlflow/tracing/utils/processor.py` only
  defines `validate_span_processors`.

### R43: Truncation helpers
- **Type**: dependency / dataflow
- **Statement**: `mlflow/tracing/utils/truncation.py` must define
  `_get_truncated_preview`, `_try_extract_messages`, `_get_max_length`, and
  `set_request_response_preview`, matching the truncation behavior tested in
  `tests/tracing/utils/test_truncation.py`.
- **Task Evidence**: Interface Description 1 preview population; static issue
  `_get_truncated_preview`; existing tests import `_get_truncated_preview`.
- **Acceptance**: `_get_truncated_preview(None, role) == ""`; long content is
  truncated to max length; chat message content is extracted by role; existing
  trace-info previews are not overwritten by `set_request_response_preview`.
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`;
  `tests/tracing/utils/test_truncation.py`.
- **Uncertainty**: Current `/testbed/mlflow/tracing/utils/truncation.py` lacks
  `_get_truncated_preview`, `_try_extract_messages`, `_get_max_length`, and
  `set_request_response_preview`.

### R44: `_get_truncated_preview` caller binding in SQLAlchemy store
- **Type**: dependency / caller binding
- **Statement**: `mlflow/store/tracking/sqlalchemy_store.py` must import
  `_get_truncated_preview` from `mlflow.tracing.utils.truncation`, and
  `SqlAlchemyStore._update_trace_info_attributes` must call it for root-span
  inputs/outputs when SQL previews are `None`.
- **Task Evidence**: Static issue `_get_truncated_preview` used but not defined
  or imported in `mlflow/store/tracking/sqlalchemy_store.py`; OTLP ingestion
  path reaches this store method.
- **Acceptance**: The SQLAlchemy store module imports successfully; calling
  `_update_trace_info_attributes` with a root span dictionary populates
  `request_preview`/`response_preview` in the update dict.
- **Repository Evidence**: `libs/tracing/mlflow/store/tracking/sqlalchemy_store.py`
  imports `_get_truncated_preview`; `libs/tracing/mlflow/tracing/utils/truncation.py`.
- **Uncertainty**: None.

---

## L2. Functional Design Graph

### Nodes

### N1: `_Trace.to_mlflow_trace`
- **Kind**: public method / entry
- **Repository Evidence**: `/testbed/mlflow/tracing/trace_manager.py`; Interface Description 1.

### N2: `TraceData`
- **Kind**: data container
- **Repository Evidence**: `/testbed/mlflow/entities/trace_data.py`.

### N3: `LiveSpan.to_immutable_span`
- **Kind**: method / state transition
- **Repository Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.

### N4: `Span` immutable constructor/class
- **Kind**: class / state
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` `Span.__init__`.

### N5: `set_request_response_preview`
- **Kind**: helper function
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`.

### N6: `TraceData.request`
- **Kind**: property
- **Repository Evidence**: `libs/tracing/mlflow/entities/trace_data.py`.

### N7: `TraceData.response`
- **Kind**: property
- **Repository Evidence**: `libs/tracing/mlflow/entities/trace_data.py`.

### N8: `Span.attributes`
- **Kind**: property / public interface
- **Repository Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.

### N9: `_SpanAttributesRegistry.get_all`
- **Kind**: helper method
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.

### N10: `_SpanAttributesRegistry.get`
- **Kind**: helper method
- **Repository Evidence**: `/testbed/mlflow/entities/span.py`.

### N11: `Span.events`
- **Kind**: property / public interface
- **Repository Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.

### N12: `SpanEvent`
- **Kind**: entity / constructor
- **Repository Evidence**: `/testbed/mlflow/entities/span_event.py`.

### N13: `Span.request_id`
- **Kind**: property
- **Repository Evidence**: Interface Description 2.

### N14: `Span.trace_id`
- **Kind**: property
- **Repository Evidence**: `/testbed/mlflow/entities/span.py`.

### N15: `Span.span_type`
- **Kind**: property
- **Repository Evidence**: Interface Description 2.

### N16: `Span.to_dict`
- **Kind**: public method
- **Repository Evidence**: Interface Description 2.

### N17: `_encode_trace_id_to_byte`
- **Kind**: helper function
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.

### N18: `_encode_span_id_to_byte`
- **Kind**: helper function
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.

### N19: `_encode_bytes_to_base64`
- **Kind**: helper function
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.

### N20: `Span.from_dict`
- **Kind**: public method
- **Repository Evidence**: `/testbed/mlflow/entities/span.py`; task dict deserialization.

### N21: `_is_base64_encoded`
- **Kind**: helper function
- **Repository Evidence**: static issue; `libs/tracing/mlflow/entities/span.py`.

### N22: `_decode_id_from_byte`
- **Kind**: helper function
- **Repository Evidence**: static issue; `libs/tracing/mlflow/entities/span.py`.

### N23: `Span._is_span_v2_schema`
- **Kind**: helper method
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.

### N24: `Span.from_dict_v2`
- **Kind**: helper method
- **Repository Evidence**: `libs/tracing/mlflow/entities/span.py`.

### N25: `Span.from_otel_proto`
- **Kind**: public classmethod
- **Repository Evidence**: Interface Description 2.

### N26: `_otel_proto_bytes_to_id`
- **Kind**: helper function
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/otlp.py`.

### N27: `_decode_otel_proto_anyvalue`
- **Kind**: public helper function
- **Repository Evidence**: Interface Description 3.

### N28: MLflow trace-ID generation functions
- **Kind**: helper group
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/__init__.py`
  `generate_mlflow_trace_id_from_otel_trace_id`,
  `generate_trace_id_v4_from_otel_trace_id`.

### N29: `Span.to_otel_proto`
- **Kind**: public method
- **Repository Evidence**: Interface Description 2.

### N30: `_set_otel_proto_anyvalue`
- **Kind**: helper function
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/otlp.py`.

### N31: `LiveSpan.from_dict`
- **Kind**: public classmethod
- **Repository Evidence**: Interface Description 2.

### N32: `LiveSpan.set_span_type`
- **Kind**: public method
- **Repository Evidence**: Interface Description 2.

### N33: `LiveSpan.end`
- **Kind**: lifecycle method
- **Repository Evidence**: `/testbed/mlflow/entities/span.py`; task lifecycle requirement.

### N34: `apply_span_processors`
- **Kind**: helper function
- **Repository Evidence**: static issue; `libs/tracing/mlflow/tracing/utils/processor.py`.

### N35: `NoOpSpan`
- **Kind**: class / no-op implementation
- **Repository Evidence**: Interface Description 2; `/testbed/mlflow/entities/span.py`.

### N36: `_CachedSpanAttributesRegistry.set`
- **Kind**: method / failure boundary
- **Repository Evidence**: Interface Description 2.

### N37: `create_mlflow_span`
- **Kind**: public factory function
- **Repository Evidence**: Interface Description 2.

### N38: `BaseMlflowSpanProcessor.on_start`
- **Kind**: caller method
- **Repository Evidence**: `/testbed/mlflow/tracing/processor/base_mlflow.py`.

### N39: `InMemoryTraceManager.register_span`
- **Kind**: method / state change
- **Repository Evidence**: `/testbed/mlflow/tracing/trace_manager.py`.

### N40: `mlflow.tracing.utils.processor` module
- **Kind**: module boundary
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/processor.py`.

### N41: `mlflow.tracing.utils.truncation` module
- **Kind**: module boundary
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/truncation.py`.

### N42: `SqlAlchemyStore._update_trace_info_attributes`
- **Kind**: method / caller
- **Repository Evidence**: `/testbed/mlflow/store/tracking/sqlalchemy_store.py`.

### N43: `_get_truncated_preview`
- **Kind**: helper function
- **Repository Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`; static issue.

### N44: `SqlAlchemyStore.log_spans`
- **Kind**: public store method
- **Repository Evidence**: `/testbed/mlflow/store/tracking/sqlalchemy_store.py`.

### N45: `server.otel_api.export_traces`
- **Kind**: OTLP ingestion entry
- **Repository Evidence**: `/testbed/mlflow/server/otel_api.py`.

### N46: `LiveSpan`
- **Kind**: class / live state
- **Repository Evidence**: `/testbed/mlflow/entities/span.py`.

### Edges

### E1: N1 -> N2
- **Kind**: DATA
- **Condition**: Always during finalization.
- **Transfer**: Creates an empty `TraceData()`.
- **Evidence**: `libs/tracing/mlflow/tracing/trace_manager.py`.
- **Obligations**: R1.

### E2: N1 -> N3
- **Kind**: CALL
- **Condition**: For each `LiveSpan` in `self.span_dict.values()`.
- **Transfer**: Calls `span.to_immutable_span()` and appends result to
  `TraceData.spans`.
- **Evidence**: `libs/tracing/mlflow/tracing/trace_manager.py`.
- **Obligations**: R1, R15.

### E3: N3 -> N4
- **Kind**: STATE / CALL
- **Condition**: Always in `to_immutable_span`.
- **Transfer**: `Span(self._span)` wraps the existing OTel span.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R15.

### E4: N1 -> N5
- **Kind**: CALL
- **Condition**: After spans are appended.
- **Transfer**: Calls `set_request_response_preview(self.info, trace_data)`.
- **Evidence**: `libs/tracing/mlflow/tracing/trace_manager.py`.
- **Obligations**: R1, R2.

### E5: N5 -> N6
- **Kind**: DATA
- **Condition**: Request preview is `None`.
- **Transfer**: Reads root-span serialized inputs via `trace_data.request`.
- **Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`.
- **Obligations**: R2, R3, R43.

### E6: N5 -> N7
- **Kind**: DATA
- **Condition**: Response preview is `None`.
- **Transfer**: Reads root-span serialized outputs via `trace_data.response`.
- **Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`.
- **Obligations**: R2, R3, R43.

### E7: N8 -> N9
- **Kind**: CALL
- **Condition**: Always when `Span.attributes` is read.
- **Transfer**: Returns `self._attributes.get_all()`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R4, R38.

### E8: N9 -> N10
- **Kind**: CALL
- **Condition**: For each OTel attribute key.
- **Transfer**: Deserializes each attribute through `_SpanAttributesRegistry.get`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R4, R38.

### E9: N11 -> N12
- **Kind**: DATA
- **Condition**: For each OTel event.
- **Transfer**: Constructs `SpanEvent(name, timestamp, dict(event.attributes))`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R5.

### E10: N13 -> N14
- **Kind**: CALL / DATA
- **Condition**: Always.
- **Transfer**: Returns `self.trace_id`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R6.

### E11: N15 -> N10
- **Kind**: CALL
- **Condition**: Always.
- **Transfer**: Returns `self.get_attribute(SpanAttributeKey.SPAN_TYPE)`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R7.

### E12: N16 -> N17
- **Kind**: CALL
- **Condition**: Always for trace ID encoding.
- **Transfer**: Encodes OTel trace ID integer to 16 bytes.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R8, R39.

### E13: N16 -> N18
- **Kind**: CALL
- **Condition**: Always for span ID and optional parent ID.
- **Transfer**: Encodes span/parent ID integer to 8 bytes.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R8, R39.

### E14: N16 -> N19
- **Kind**: CALL
- **Condition**: For each encoded ID byte string.
- **Transfer**: Base64-encodes and UTF-8 decodes.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R8, R39.

### E15: N20 -> N23
- **Kind**: CONTROL
- **Condition**: If `data` has a `"context"` key.
- **Transfer**: Selects v2 deserialization path.
- **Evidence**: `/testbed/mlflow/entities/span.py`; `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R9, R41.

### E16: N23 -> N24
- **Kind**: CALL
- **Condition**: When v2 schema is detected.
- **Transfer**: Calls `cls.from_dict_v2(data)`.
- **Evidence**: `/testbed/mlflow/entities/span.py`.
- **Obligations**: R9, R41.

### E17: N20 -> N21
- **Kind**: CALL
- **Condition**: For non-v2 schemas, when evaluating `data["trace_id"]`.
- **Transfer**: Detects whether the trace ID is base64 encoded.
- **Evidence**: `/testbed/mlflow/entities/span.py`; static issue.
- **Obligations**: R9, R40.

### E18: N20 -> N22
- **Kind**: CALL
- **Condition**: When `_is_base64_encoded(data["trace_id"])` is true.
- **Transfer**: Decodes base64 trace/span/parent IDs to integers.
- **Evidence**: `/testbed/mlflow/entities/span.py`; static issue.
- **Obligations**: R9, R40.

### E19: N25 -> N26
- **Kind**: CALL
- **Condition**: Always for trace, span, and optional parent IDs.
- **Transfer**: Converts OTel protobuf ID bytes to integers.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R11, R37.

### E20: N25 -> N28
- **Kind**: CALL
- **Condition**: Always to produce the MLflow trace ID.
- **Transfer**: Generates `tr-<hex>` or `trace:/<location>/<hex>` based on
  `location_id`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R11.

### E21: N25 -> N27
- **Kind**: CALL
- **Condition**: For each protobuf span attribute and event attribute.
- **Transfer**: Decodes `AnyValue` to Python objects.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R11, R35, R36.

### E22: N25 -> N4
- **Kind**: STATE / CALL
- **Condition**: After constructing an `OTelReadableSpan`.
- **Transfer**: Returns `cls(otel_span)`, producing an immutable `Span`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R11.

### E23: N29 -> N30
- **Kind**: CALL
- **Condition**: For each span attribute.
- **Transfer**: Encodes Python values as OTel protobuf `AnyValue`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R12.

### E24: N29 -> N11
- **Kind**: CALL
- **Condition**: For each event.
- **Transfer**: Reads `Span.events` and calls `SpanEvent.to_otel_proto()`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R5, R12.

### E25: N31 -> NotImplementedError
- **Kind**: CONTROL / EXCEPTION
- **Condition**: Always.
- **Transfer**: Raises `NotImplementedError`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R13.

### E26: N32 -> N10
- **Kind**: CALL
- **Condition**: Always.
- **Transfer**: Calls `self.set_attribute(SpanAttributeKey.SPAN_TYPE, span_type)`,
  which delegates to the live attribute registry.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R14.

### E27: N33 -> N34
- **Kind**: CALL
- **Condition**: Always before ending the OTel span.
- **Transfer**: Calls `apply_span_processors(self)`.
- **Evidence**: `/testbed/mlflow/entities/span.py`; static issue.
- **Obligations**: R16, R42.

### E28: N34 -> N40
- **Kind**: DATA / IMPORT
- **Condition**: At runtime, reads `mlflow.tracing.config.get_config()`.
- **Transfer**: Loads configured span processors from the tracing config module.
- **Evidence**: `libs/tracing/mlflow/tracing/utils/processor.py`.
- **Obligations**: R42.

### E29: N35 -> NO_OP_SPAN_TRACE_ID / None
- **Kind**: DATA / CONTROL
- **Condition**: Property or setter access on `NoOpSpan`.
- **Transfer**: Returns the no-op constant for `trace_id`, `None` for the
  documented read-only properties, and performs no state change for setters.
- **Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R17-R30.

### E30: N36 -> MlflowException
- **Kind**: EXCEPTION
- **Condition**: Always.
- **Transfer**: Raises `MlflowException(..., INVALID_PARAMETER_VALUE)`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R31.

### E31: N37 -> N35
- **Kind**: CONTROL
- **Condition**: `otel_span` is `None` or `NonRecordingSpan`.
- **Transfer**: Returns `NoOpSpan()`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R32.

### E32: N37 -> N46
- **Kind**: CONTROL
- **Condition**: `otel_span` is an `OTelSpan`.
- **Transfer**: Returns `LiveSpan(otel_span, trace_id, span_type)`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R32.

### E33: N37 -> N4
- **Kind**: CONTROL
- **Condition**: `otel_span` is an `OTelReadableSpan`.
- **Transfer**: Returns `Span(otel_span)`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R32.

### E34: N37 -> MlflowException
- **Kind**: EXCEPTION
- **Condition**: Input is not one of the supported OTel span types.
- **Transfer**: Raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Obligations**: R33.

### E35: N38 -> N37
- **Kind**: CALL / IMPORT_BOUNDARY
- **Condition**: Always in `BaseMlflowSpanProcessor.on_start`.
- **Transfer**: Calls module-level imported `create_mlflow_span(span, trace_id)`.
- **Evidence**: `/testbed/mlflow/tracing/processor/base_mlflow.py`; static issue.
- **Obligations**: R34.

### E36: N38 -> N39
- **Kind**: CALL / DATA
- **Condition**: After creating the MLflow span.
- **Transfer**: Passes the factory result to
  `InMemoryTraceManager.get_instance().register_span`.
- **Evidence**: `/testbed/mlflow/tracing/processor/base_mlflow.py`.
- **Obligations**: R34.

### E37: N25 -> N45
- **Kind**: CALL
- **Condition**: During OTLP ingestion in `server/otel_api.export_traces`.
- **Transfer**: The handler calls `Span.from_otel_proto(otel_proto_span)`.
- **Evidence**: `/testbed/mlflow/server/otel_api.py`.
- **Obligations**: R11, R44.

### E38: N45 -> N44
- **Kind**: CALL
- **Condition**: After grouping converted spans by trace ID.
- **Transfer**: Calls `store.log_spans(x_mlflow_experiment_id, trace_spans)`.
- **Evidence**: `/testbed/mlflow/server/otel_api.py`.
- **Obligations**: R44.

### E39: N44 -> N42
- **Kind**: CALL
- **Condition**: For each root span during span logging.
- **Transfer**: Calls
  `self._update_trace_info_attributes(sql_trace_info, span_dict)`.
- **Evidence**: `/testbed/mlflow/store/tracking/sqlalchemy_store.py`.
- **Obligations**: R44.

### E40: N42 -> N43
- **Kind**: CALL / IMPORT_BOUNDARY
- **Condition**: When SQL request/response previews are `None` and root span
  inputs/outputs exist.
- **Transfer**: Calls `_get_truncated_preview(trace_inputs, role=...)` or
  `_get_truncated_preview(trace_outputs, role=...)`.
- **Evidence**: `/testbed/mlflow/store/tracking/sqlalchemy_store.py`; static issue.
- **Obligations**: R43, R44.

### E41: N43 -> N41
- **Kind**: DATA / IMPORT
- **Condition**: Always when SQLAlchemy store imports/calls the helper.
- **Transfer**: Binds `_get_truncated_preview` from
  `mlflow.tracing.utils.truncation`.
- **Evidence**: `libs/tracing/mlflow/store/tracking/sqlalchemy_store.py`.
- **Obligations**: R43, R44.

### E42: N27 -> N27
- **Kind**: CALL
- **Condition**: When `AnyValue` contains `array_value` or `kvlist_value`.
- **Transfer**: Recursively decodes nested values.
- **Evidence**: Interface Description 3; `libs/tracing/mlflow/tracing/utils/otlp.py`.
- **Obligations**: R36.

---

### Static Issue Closure

### Issue 1: `_decode_id_from_byte` used but not defined or imported in `mlflow/entities/span.py`
- **Call site**: `Span.from_dict` lines 273-277.
- **Enclosing unit U**: `Span.from_dict`.
- **Upward caller trace**: `Span.from_dict` is the direct deserialization entry
  required by the task's dict-serialization functionality and is called by
  `TraceData.from_dict`, `Trace.from_dict`, `mlflow/tracing/utils/copy.py`, and
  `mlflow/store/tracking/sqlalchemy_store.py` (line 3606). This trace reaches
  task-required serialization/deserialization entries.
- **Closed chain**: `Span.from_dict` -> `_decode_id_from_byte`.
- **Disposition**: ON-PATH. Contracts C8 and C30 execute the real `from_dict`
  path.

### Issue 2: `_is_base64_encoded` used but not defined or imported in `mlflow/entities/span.py`
- **Call site**: `Span.from_dict` line 272.
- **Enclosing unit U**: `Span.from_dict`.
- **Upward caller trace**: Same as Issue 1.
- **Closed chain**: `Span.from_dict` -> `_is_base64_encoded`.
- **Disposition**: ON-PATH. Contracts C8 and C30 execute the real `from_dict`
  path.

### Issue 3: `apply_span_processors` used but not defined or imported in `mlflow/entities/span.py`
- **Call site**: `LiveSpan.end` line 654.
- **Enclosing unit U**: `LiveSpan.end`.
- **Upward caller trace**: `LiveSpan.end` is called by public tracing lifecycle
  entry points in `mlflow/tracing/fluent.py` (`start_span` context exits),
  `mlflow/tracking/client.py` (`start_trace`/`start_span` clients), timeout
  cleanup in `mlflow/tracing/utils/timeout.py`, and trace copy utilities. This
  reaches the task-required span lifecycle termination requirement.
- **Closed chain**: `mlflow.start_span`/`mlflow.trace` lifecycle ->
  `LiveSpan.end` -> `apply_span_processors`.
- **Disposition**: ON-PATH. Contracts C17 and C18 execute the real `LiveSpan.end`
  path.

### Issue 4: `create_mlflow_span` used but not defined or imported in `mlflow/tracing/processor/base_mlflow.py`
- **Call site**: `BaseMlflowSpanProcessor.on_start` line 87.
- **Enclosing unit U**: `BaseMlflowSpanProcessor.on_start`.
- **Upward caller trace**: `on_start` is invoked by the OpenTelemetry SDK when a
  span starts through `mlflow.tracing.provider` (`start_span_in_context`,
  `start_detached_span`), which backs public `mlflow.start_span` and
  `mlflow.trace` entry points.
- **Closed chain**: public `mlflow.start_span`/`mlflow.trace` -> OTel SDK ->
  `BaseMlflowSpanProcessor.on_start` -> `create_mlflow_span`.
- **Disposition**: ON-PATH. Contract C25 executes the real `on_start` call path.

### Issue 5: `_get_truncated_preview` used but not defined or imported in `mlflow/store/tracking/sqlalchemy_store.py`
- **Call site**: `SqlAlchemyStore._update_trace_info_attributes` lines 3488 and
  3496.
- **Enclosing unit U**: `SqlAlchemyStore._update_trace_info_attributes`.
- **Upward caller trace**: `SqlAlchemyStore._update_trace_info_attributes` is
  called by `SqlAlchemyStore.log_spans` (line 3438). `log_spans` is called by
  `mlflow/server/otel_api.py` `export_traces` (line 123), the same handler that
  calls task-required `Span.from_otel_proto` (line 106). `log_spans` is also
  called through `mlflow/tracing/client.py` and `mlflow/tracing/export/*`.
- **Closed chain**: `Span.from_otel_proto` -> `server.otel_api.export_traces` ->
  `SqlAlchemyStore.log_spans` -> `SqlAlchemyStore._update_trace_info_attributes`
  -> `_get_truncated_preview`.
- **Disposition**: ON-PATH. Contract C34 executes the SQLAlchemy caller path with
  a span produced by `Span.from_otel_proto`.

---

## L3. Verifiable Contracts

### C1: `_Trace.to_mlflow_trace` returns immutable MLflow trace
- **Type**: RETURN_VALUE / FIELD_READ
- **Subject**: `_Trace.to_mlflow_trace`
- **Relation**: result type and span immutability
- **Expected**: Result is `Trace`; `len(result.data.spans)` equals
  `len(trace.span_dict)`; every span is `Span` and `not isinstance(span, LiveSpan)`;
  original `span_dict` values remain `LiveSpan`.
- **Evidence**: `libs/tracing/mlflow/tracing/trace_manager.py`;
  `tests/tracing/test_trace_manager.py::test_add_spans`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/trace_manager.py`
- **Obligations**: R1, R15.
- **Graph**: N1, N2, N3, N4; E1, E2, E3.

### C2: `_Trace.to_mlflow_trace` populates request/response previews
- **Type**: SIDE_EFFECT / STATE_READ
- **Subject**: `_Trace.to_mlflow_trace`
- **Relation**: trace-info preview side effects
- **Expected**: With a root `LiveSpan` whose inputs/outputs are set and
  `info.request_preview`/`info.response_preview` initially `None`, after the
  call both fields are non-empty strings derived from the root span. If previews
  are pre-set, they are unchanged.
- **Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`;
  `libs/tracing/mlflow/tracing/trace_manager.py`.
- **Observe**: SIDE_EFFECT
- **Target**: `/testbed/mlflow/tracing/trace_manager.py`
- **Obligations**: R1, R2, R3, R43.
- **Graph**: N1, N5, N6, N7, N43; E4, E5, E6.

### C3: `Span.attributes` deserializes all attributes
- **Type**: RETURN_VALUE
- **Subject**: `Span.attributes`
- **Relation**: attribute dictionary correctness
- **Expected**: For an immutable span built from an `OTelReadableSpan` with
  JSON-dumped values, `span.attributes == original_dict`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`;
  `tests/tracing/opentelemetry/test_integration.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R4, R38.
- **Graph**: N8, N9, N10; E7, E8.

### C4: `Span.events` returns plain-dict `SpanEvent` list
- **Type**: RETURN_VALUE
- **Subject**: `Span.events`
- **Relation**: event conversion
- **Expected**: Event count, names, timestamps, and attributes match the
  underlying OTel events; each event is a `SpanEvent`; attributes are plain
  `dict`; no events yields `[]`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`;
  `tests/tracing/opentelemetry/test_integration.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R5.
- **Graph**: N11, N12; E9.

### C5: `Span.request_id` aliases `trace_id`
- **Type**: RETURN_VALUE
- **Subject**: `Span.request_id`
- **Relation**: equality with `trace_id`
- **Expected**: `span.request_id == span.trace_id`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R6.
- **Graph**: N13, N14; E10.

### C6: `Span.span_type` reads the span type attribute
- **Type**: RETURN_VALUE
- **Subject**: `Span.span_type`
- **Relation**: attribute lookup
- **Expected**: Equals the deserialized `mlflow.spanType` attribute, or `None`
  when absent.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R7.
- **Graph**: N15, N10; E11.

### C7: `Span.to_dict` base64 v3 encoding
- **Type**: RETURN_VALUE
- **Subject**: `Span.to_dict`
- **Relation**: dictionary schema and ID encoding
- **Expected**: The result contains keys `trace_id`, `span_id`,
  `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`,
  `events`, `status`, `attributes`. Trace ID equals
  `base64.b64encode(trace_id_int.to_bytes(16, "big", signed=False)).decode("utf-8")`;
  span and parent IDs use 8 bytes. Status `code` is the OTel proto status code
  name; `attributes` values are raw OTel dumped strings.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`; Interface Description 2
  encoding notes.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R8, R39.
- **Graph**: N16, N17, N18, N19; E12, E13, E14.

### C8: `Span.from_dict` round-trips v3 base64 output
- **Type**: RETURN_VALUE
- **Subject**: `Span.from_dict`
- **Relation**: v3 base64 deserialization
- **Expected**: `Span.from_dict(span.to_dict())` returns a `Span` with equal
  `trace_id`, `span_id`, `parent_id`, `name`, `start_time_ns`, `end_time_ns`,
  `status`, `events`, and attributes.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`;
  `tests/tracing/test_fluent.py` remote trace paths.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R9, R40.
- **Graph**: N20, N21, N22; E17, E18.

### C9: `Span.from_dict` reconstructs v2 schema
- **Type**: RETURN_VALUE
- **Subject**: `Span.from_dict`
- **Relation**: v2 compatibility
- **Expected**: A v2 span dict with `context`, `parent_id`, `start_time`,
  `end_time`, `status_code`, `status_message`, and `events` produces a `Span`
  with decoded IDs and status.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R9, R41.
- **Graph**: N20, N23, N24; E15, E16.

### C10: `Span.from_dict` legacy 3.5.0 schema
- **Type**: RETURN_VALUE
- **Subject**: `Span.from_dict`
- **Relation**: legacy non-base64 compatibility
- **Expected**: A dict with `trace_id="tr-<hex>"`, hex `span_id`, and optional
  hex `parent_span_id` reconstructs a `Span`.
- **Evidence**: `/testbed/mlflow/entities/span.py` lines 279-286;
  `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R9.
- **Graph**: N20.

### C11: `Span.from_dict` missing request ID raises
- **Type**: EXCEPTION
- **Subject**: `Span.from_dict`
- **Relation**: invalid-input failure
- **Expected**: `Span.from_dict({"attributes": {}})` raises `MlflowException`
  with `error_code == INVALID_PARAMETER_VALUE`.
- **Evidence**: `/testbed/mlflow/entities/span.py` lines 262-267.
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R10.
- **Graph**: N20.

### C12: `Span.from_otel_proto` basic OTLP conversion
- **Type**: RETURN_VALUE
- **Subject**: `Span.from_otel_proto`
- **Relation**: OTLP protobuf-to-Span correctness
- **Expected**: With `location_id=None`, trace ID is `tr-<hex>`; span and parent
  IDs are decoded from bytes; attributes are JSON-dumped decoded values and
  include `mlflow.traceRequestId`; events are preserved; status code maps OK,
  ERROR, UNSET.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`;
  `tests/tracing/test_otel_logging.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R11, R35, R36, R37.
- **Graph**: N25, N26, N27, N28, N4; E19, E20, E21, E22.

### C13: `Span.from_otel_proto` v4 location trace ID
- **Type**: RETURN_VALUE
- **Subject**: `Span.from_otel_proto`
- **Relation**: location-specific ID generation
- **Expected**: With `location_id="loc"`, `span.trace_id == "trace:/loc/<hex>"`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R11.
- **Graph**: N25, N28; E20.

### C14: `Span.to_otel_proto` OTLP export conversion
- **Type**: RETURN_VALUE
- **Subject**: `Span.to_otel_proto`
- **Relation**: Span-to-protobuf correctness
- **Expected**: Returned `OTelProtoSpan` has `trace_id == bytes.fromhex(span._trace_id)`,
  `span_id == bytes.fromhex(span.span_id)`, optional parent bytes, matching
  name/times/status, attributes that decode back through
  `_decode_otel_proto_anyvalue`, and matching events.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`;
  `tests/entities/test_span_event.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R12.
- **Graph**: N29, N30, N11; E23, E24.

### C15: `LiveSpan.from_dict` raises `NotImplementedError`
- **Type**: EXCEPTION
- **Subject**: `LiveSpan.from_dict`
- **Relation**: unsupported operation
- **Expected**: `LiveSpan.from_dict({})` raises `NotImplementedError`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R13.
- **Graph**: N31; E25.

### C16: `LiveSpan.set_span_type` writes the span-type attribute
- **Type**: SIDE_EFFECT / FIELD_READ
- **Subject**: `LiveSpan.set_span_type`
- **Relation**: attribute mutation
- **Expected**: After `span.set_span_type("TOOL")`, the OTel span attribute
  `mlflow.spanType` is the JSON dump of `"TOOL"` and `span.span_type == "TOOL"`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`; autologging callers.
- **Observe**: SIDE_EFFECT
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R14.
- **Graph**: N32, N10; E26.

### C17: `LiveSpan.to_immutable_span` returns immutable wrapper
- **Type**: RETURN_VALUE / STATE_READ
- **Subject**: `LiveSpan.to_immutable_span`
- **Relation**: live-to-immutable downcast
- **Expected**: Result is `Span`, not `LiveSpan`, and `result._span is span._span`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R15.
- **Graph**: N3, N4; E3.

### C18: `LiveSpan.end` applies processors and ends the OTel span
- **Type**: RUNTIME_ARGUMENT_TRACE / SIDE_EFFECT
- **Subject**: `LiveSpan.end`
- **Relation**: lifecycle termination and processor invocation
- **Expected**: Configure a span processor with side effect. Calling
  `live_span.end()` invokes the processor once with the same live span, then
  invokes `_span.end`. Processor exceptions do not propagate. Non-ERROR status
  is set to OK.
- **Evidence**: `/testbed/mlflow/entities/span.py`; `libs/tracing/mlflow/entities/span.py`;
  `tests/tracing/utils/test_processor.py`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R16, R42.
- **Graph**: N33, N34; E27.

### C19: `apply_span_processors` import boundary and behavior
- **Type**: IMPORT_BOUNDARY / RUNTIME_ARGUMENT_TRACE
- **Subject**: `mlflow.tracing.utils.processor.apply_span_processors`
- **Relation**: module import and sequential processing
- **Expected**: `from mlflow.tracing.utils.processor import apply_span_processors`
  succeeds. With two configured processors, both are called in order; a failing
  processor is logged and later processors still run; non-`None` returns are
  ignored with a warning.
- **Evidence**: `tests/tracing/utils/test_processor.py`;
  `libs/tracing/mlflow/tracing/utils/processor.py`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `/testbed/mlflow/tracing/utils/processor.py`
- **Obligations**: R42.
- **Graph**: N34, N40; E28.

### C20: `NoOpSpan.trace_id` constant
- **Type**: RETURN_VALUE
- **Subject**: `NoOpSpan.trace_id`
- **Relation**: special constant
- **Expected**: Returns `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- **Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R30.
- **Graph**: N35; E29.

### C21: `NoOpSpan` read-only properties return `None`
- **Type**: RETURN_VALUE / FIELD_READ
- **Subject**: `NoOpSpan` `_trace_id`, `span_id`, `name`, `start_time_ns`,
  `end_time_ns`, `status`
- **Relation**: no-op property values
- **Expected**: Each property returns `None`.
- **Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R17, R20, R21, R27, R28, R29.
- **Graph**: N35; E29.

### C22: `NoOpSpan` mutators are safe no-ops
- **Type**: SIDE_EFFECT / RETURN_VALUE
- **Subject**: `NoOpSpan.add_event`, `end`, `set_attribute`, `set_attributes`,
  `set_inputs`, `set_outputs`, `set_status`
- **Relation**: no-op interface compatibility
- **Expected**: Each method accepts its documented arguments and returns `None`
  without raising or storing data.
- **Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.
- **Observe**: SIDE_EFFECT
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R18, R19, R22, R23, R24, R25, R26.
- **Graph**: N35; E29.

### C23: `_CachedSpanAttributesRegistry.set` raises immutable error
- **Type**: EXCEPTION
- **Subject**: `_CachedSpanAttributesRegistry.set`
- **Relation**: forbidden mutation
- **Expected**: Raises `MlflowException` with
  `error_code == INVALID_PARAMETER_VALUE`.
- **Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R31.
- **Graph**: N36; E30.

### C24: `create_mlflow_span` dispatch by OTel span type
- **Type**: RETURN_VALUE
- **Subject**: `create_mlflow_span`
- **Relation**: factory dispatch
- **Expected**: For `OTelSpan`, returns `LiveSpan` with supplied trace ID and
  span type; for `OTelReadableSpan` (non-live), returns `Span`; for `None` and
  `NonRecordingSpan`, returns `NoOpSpan`.
- **Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`;
  `tests/tracing/test_tracing_client.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R32.
- **Graph**: N37, N35, N46, N4; E31, E32, E33.

### C25: `create_mlflow_span` invalid type raises
- **Type**: EXCEPTION
- **Subject**: `create_mlflow_span`
- **Relation**: invalid-input failure
- **Expected**: Passing `object()` raises `MlflowException` with
  `INVALID_PARAMETER_VALUE`.
- **Evidence**: Interface Description 2; `libs/tracing/mlflow/entities/span.py`.
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R33.
- **Graph**: N37; E34.

### C26: `BaseMlflowSpanProcessor.on_start` binds and calls `create_mlflow_span`
- **Type**: RUNTIME_ARGUMENT_TRACE
- **Subject**: `BaseMlflowSpanProcessor.on_start`
- **Relation**: caller binding
- **Expected**: With `create_mlflow_span` and `register_span` patched/mocked,
  calling `on_start(mock_otel_span, parent_context)` invokes
  `create_mlflow_span` once with `(mock_otel_span, trace_id)` and passes the
  returned span to `register_span`. Importing
  `mlflow.tracing.processor.base_mlflow` succeeds and its module global
  `create_mlflow_span` resolves to `mlflow.entities.span.create_mlflow_span`.
- **Evidence**: Static issue 4; `libs/tracing/mlflow/tracing/processor/base_mlflow.py`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `/testbed/mlflow/tracing/processor/base_mlflow.py`
- **Obligations**: R34.
- **Graph**: N38, N37, N39; E35, E36.

### C27: `_decode_otel_proto_anyvalue` primitives
- **Type**: RETURN_VALUE
- **Subject**: `_decode_otel_proto_anyvalue`
- **Relation**: primitive AnyValue decoding
- **Expected**: Unset yields `None`; bool, string, int, double, and bytes fields
  yield the exact corresponding Python object.
- **Evidence**: Interface Description 3; `tests/entities/test_span_event.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/utils/otlp.py`
- **Obligations**: R35.
- **Graph**: N27.

### C28: `_decode_otel_proto_anyvalue` recursive structures
- **Type**: RETURN_VALUE
- **Subject**: `_decode_otel_proto_anyvalue`
- **Relation**: array/kvlist decoding
- **Expected**: Array `AnyValue` decodes to list with recursively decoded items;
  kvlist decodes to dict with string keys and recursively decoded values.
- **Evidence**: Interface Description 3; `tests/entities/test_span_event.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/utils/otlp.py`
- **Obligations**: R36.
- **Graph**: N27; E42.

### C29: `_otel_proto_bytes_to_id` conversion
- **Type**: RETURN_VALUE
- **Subject**: `_otel_proto_bytes_to_id`
- **Relation**: protobuf ID bytes-to-integer
- **Expected**: Returns `int.from_bytes(id_bytes, byteorder="big", signed=False)`.
- **Evidence**: `libs/tracing/mlflow/tracing/utils/otlp.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/utils/otlp.py`
- **Obligations**: R37.
- **Graph**: N26; E19.

### C30: `_SpanAttributesRegistry.get_all` deserializes all attributes
- **Type**: RETURN_VALUE
- **Subject**: `_SpanAttributesRegistry.get_all`
- **Relation**: attribute registry aggregation
- **Expected**: Returns `{key: deserialized_value for key in underlying OTel
  attributes}`; non-JSON raw strings are returned as-is by `get`.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R38.
- **Graph**: N9, N10; E8.

### C31: `_is_base64_encoded` and `_decode_id_from_byte`
- **Type**: RETURN_VALUE
- **Subject**: `_is_base64_encoded`, `_decode_id_from_byte`
- **Relation**: base64 detection and decoding
- **Expected**: Valid base64 returns `True` and decodes to the original integer;
  malformed base64 returns `False`.
- **Evidence**: static issues 1 and 2; `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R40.
- **Graph**: N21, N22; E17, E18.

### C32: `_is_span_v2_schema` and `from_dict_v2`
- **Type**: RETURN_VALUE
- **Subject**: `Span._is_span_v2_schema`, `Span.from_dict_v2`
- **Relation**: v2 schema handling
- **Expected**: A dict containing `"context"` is detected as v2 and converted to
  a `Span` with decoded IDs, status, attributes, and events.
- **Evidence**: `libs/tracing/mlflow/entities/span.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py`
- **Obligations**: R41.
- **Graph**: N23, N24; E15, E16.

### C33: `TraceData.request` and `TraceData.response`
- **Type**: RETURN_VALUE
- **Subject**: `TraceData.request`, `TraceData.response`
- **Relation**: root-span preview sources
- **Expected**: With a root span, returns the raw serialized
  `mlflow.spanInputs`/`mlflow.spanOutputs` OTel attributes; without a root span,
  returns `None`.
- **Evidence**: `libs/tracing/mlflow/entities/trace_data.py`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/trace_data.py`
- **Obligations**: R3.
- **Graph**: N6, N7; E5, E6.

### C34: `set_request_response_preview` and `_get_truncated_preview`
- **Type**: SIDE_EFFECT / RETURN_VALUE
- **Subject**: `set_request_response_preview`, `_get_truncated_preview`
- **Relation**: preview truncation and non-overwrite semantics
- **Expected**: `_get_truncated_preview(None, role) == ""`; long content is
  truncated to `_get_max_length()`; chat message content is extracted by role.
  `set_request_response_preview` only sets preview fields when they are `None`.
- **Evidence**: `libs/tracing/mlflow/tracing/utils/truncation.py`;
  `tests/tracing/utils/test_truncation.py`.
- **Observe**: SIDE_EFFECT
- **Target**: `/testbed/mlflow/tracing/utils/truncation.py`
- **Obligations**: R2, R43.
- **Graph**: N5, N43, N41; E4, E5, E6.

### C35: `_get_truncated_preview` SQLAlchemy caller path
- **Type**: RUNTIME_ARGUMENT_TRACE / SIDE_EFFECT
- **Subject**: `SqlAlchemyStore._update_trace_info_attributes`
- **Relation**: caller binding and preview update dictionary
- **Expected**: Build a `Span` through `Span.from_otel_proto` (proving the OTLP
  entry) and pass the corresponding translated root-span dict to
  `_update_trace_info_attributes`. When `SqlTraceInfo.request_preview` and
  `response_preview` are `None` and inputs/outputs exist, the returned update
  dict contains `SqlTraceInfo.request_preview` and
  `SqlTraceInfo.response_preview` with the same values returned by
  `_get_truncated_preview`. Importing
  `mlflow.store.tracking.sqlalchemy_store` succeeds and its module global
  `_get_truncated_preview` resolves.
- **Evidence**: Static issue 5; `libs/tracing/mlflow/store/tracking/sqlalchemy_store.py`;
  `libs/tracing/mlflow/tracing/utils/truncation.py`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `/testbed/mlflow/store/tracking/sqlalchemy_store.py`
- **Obligations**: R43, R44.
- **Graph**: N25, N45, N44, N42, N43; E37, E38, E39, E40, E41.

