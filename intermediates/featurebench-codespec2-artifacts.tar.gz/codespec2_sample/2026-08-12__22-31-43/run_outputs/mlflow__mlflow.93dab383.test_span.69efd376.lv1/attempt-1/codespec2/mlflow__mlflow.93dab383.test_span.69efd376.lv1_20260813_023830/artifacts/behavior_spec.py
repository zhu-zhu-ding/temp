"""
Behavior spec for the MLflow distributed tracing span IR.

This file checks states, outcomes, defaults, failures, side effects, boundaries,
and compatibility. It does not modify production code and does not execute
repository tests. Each check is a no-argument callable and prints PASS on
success. The process exits nonzero when any check fails.
"""

import base64
import json
import os
import sys
import time
from contextlib import contextmanager
from unittest.mock import Mock, patch

REPO = "/testbed"
if REPO not in sys.path:
    sys.path.insert(0, REPO)

from opentelemetry.proto.common.v1.common_pb2 import AnyValue
from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import Event as OTelEvent
from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
from opentelemetry.trace import Status as OTelStatus
from opentelemetry.trace import StatusCode as OTelStatusCode

from mlflow.entities import LiveSpan, Span, SpanEvent, Trace, TraceData, TraceInfo
from mlflow.entities.span_status import SpanStatus, SpanStatusCode
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.tracing.utils import (
    build_otel_context,
    decode_id,
    dump_span_attribute_value,
    encode_span_id,
    encode_trace_id,
    generate_mlflow_trace_id_from_otel_trace_id,
    generate_trace_id_v4_from_otel_trace_id,
)

from tests.tracing.helper import create_mock_otel_span


def make_trace_info(trace_id: str = "tr-1") -> TraceInfo:
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState

    return TraceInfo(
        trace_id=trace_id,
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        state=TraceState.OK,
    )


def make_otel_readable_span(
    name="root",
    trace_id=1,
    span_id=2,
    parent_id=None,
    start_time=100,
    end_time=200,
    attributes=None,
    events=None,
    status=None,
):
    return OTelReadableSpan(
        name=name,
        context=build_otel_context(trace_id, span_id),
        parent=build_otel_context(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        end_time=end_time,
        attributes=attributes or {},
        status=status or OTelStatus(OTelStatusCode.OK),
        resource=Resource.get_empty(),
        events=events or [],
    )


def make_live_span(trace_id="tr-1", span_id=1, parent_id=None, span_type=None):
    otel_span = create_mock_otel_span(
        trace_id=12345,
        span_id=span_id,
        parent_id=parent_id,
        name=f"span-{span_id}",
    )
    live_span = LiveSpan(
        otel_span,
        trace_id=trace_id,
        span_type=span_type if span_type is not None else "UNKNOWN",
    )
    return live_span, otel_span


@contextmanager
def raises(exc_type, error_code=None):
    try:
        yield
    except exc_type as exc:
        if error_code is not None:
            assert getattr(exc, "error_code", None) == error_code, (
                f"Expected error_code {error_code}, got {getattr(exc, 'error_code', None)}"
            )
    else:
        raise AssertionError(f"Expected {exc_type.__name__} to be raised")


# ---------------------------------------------------------------------------
# C2/R1/R2/R3/R43: _Trace.to_mlflow_trace must populate TraceInfo request and
# response previews only when they are None.
# Repository test used as guidance:
# tests/tracing/utils/test_truncation.py (preview truncation semantics).
# Perspective: lifecycle side effect and non-overwrite state.
# Source path: mlflow/tracing/trace_manager.py::_Trace.to_mlflow_trace
# -> mlflow/tracing/utils/truncation.py::set_request_response_preview
# -> mlflow/entities/trace_data.py::TraceData.request/response.
# ---------------------------------------------------------------------------
def check_trace_to_mlflow_trace_previews():
    from mlflow.tracing.trace_manager import _Trace

    # Population when previews are None.
    trace = _Trace(info=make_trace_info("tr-populate"))
    root, _ = make_live_span("tr-populate", span_id=1, parent_id=None)
    root.set_inputs({"question": "hello"})
    root.set_outputs({"answer": "world"})
    trace.span_dict[root.span_id] = root

    result = trace.to_mlflow_trace()
    assert isinstance(result, Trace)
    assert result.info.request_preview is not None
    assert result.info.response_preview is not None
    assert len(result.info.request_preview) > 0
    assert len(result.info.response_preview) > 0

    # Non-overwrite when previews are already set.
    info = make_trace_info("tr-preserve")
    info.request_preview = "existing-request"
    info.response_preview = "existing-response"
    trace = _Trace(info=info)
    root, _ = make_live_span("tr-preserve", span_id=1, parent_id=None)
    root.set_inputs({"question": "new"})
    root.set_outputs({"answer": "new"})
    trace.span_dict[root.span_id] = root

    trace.to_mlflow_trace()
    assert info.request_preview == "existing-request"
    assert info.response_preview == "existing-response"


# ---------------------------------------------------------------------------
# C3/R4/R38: Span.attributes returns every OTel attribute deserialized from its
# JSON-string storage form.
# Repository test used as guidance:
# tests/tracing/opentelemetry/test_integration.py (span attribute round-trips).
# Perspective: representation preservation.
# Source path: mlflow/entities/span.py::Span.attributes
# -> _CachedSpanAttributesRegistry.get_all -> get.
# ---------------------------------------------------------------------------
def check_span_attributes_deserialized():
    original = {
        "number": 42,
        "text": "hello",
        "nested": {"a": [1, 2, 3]},
    }
    otel_span = make_otel_readable_span(
        attributes={
            key: dump_span_attribute_value(value) for key, value in original.items()
        },
    )
    span = Span(otel_span)
    assert span.attributes == original


# ---------------------------------------------------------------------------
# C4/R5: Span.events returns SpanEvent objects with plain dict attributes.
# Repository test used as guidance:
# tests/tracing/opentelemetry/test_integration.py and
# tests/entities/test_span_event.py (event conversion).
# Perspective: event conversion and serializability.
# Source path: mlflow/entities/span.py::Span.events -> SpanEvent.
# ---------------------------------------------------------------------------
def check_span_events_plain_dicts():
    otel_span = make_otel_readable_span(
        events=[
            OTelEvent(name="first", timestamp=123, attributes={"k": "v"}),
            OTelEvent(name="second", timestamp=456, attributes={"n": 1}),
        ],
    )
    span = Span(otel_span)
    events = span.events
    assert len(events) == 2
    assert all(isinstance(event, SpanEvent) for event in events)
    assert events[0].name == "first"
    assert events[0].timestamp == 123
    assert events[1].attributes == {"n": 1}
    assert isinstance(events[0].attributes, dict)
    # Plain dicts must serialize without lock-object errors.
    json.dumps(events[0].attributes)

    assert Span(make_otel_readable_span(events=[])).events == []


# ---------------------------------------------------------------------------
# C5/R6: Span.request_id is a deprecated alias for trace_id.
# Repository test used as guidance: none direct; interface compatibility.
# Perspective: public alias preservation.
# Source path: mlflow/entities/span.py::Span.request_id -> trace_id.
# ---------------------------------------------------------------------------
def check_span_request_id_alias():
    otel_span = make_otel_readable_span(
        attributes={SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-42")},
    )
    span = Span(otel_span)
    assert span.request_id == span.trace_id == "tr-42"


# ---------------------------------------------------------------------------
# C6/R7: Span.span_type reads mlflow.spanType and returns None when absent.
# Repository test used as guidance:
# tests/genai/utils/test_trace_utils.py (span type attribute lookup).
# Perspective: optional attribute default.
# Source path: mlflow/entities/span.py::Span.span_type -> get_attribute.
# ---------------------------------------------------------------------------
def check_span_span_type():
    typed_span = Span(
        make_otel_readable_span(
            attributes={SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM")},
        )
    )
    assert typed_span.span_type == "LLM"

    untyped_span = Span(make_otel_readable_span(attributes={}))
    assert untyped_span.span_type is None


# ---------------------------------------------------------------------------
# C7/R8/R39: Span.to_dict must encode trace/span/parent IDs using the v3
# big-endian byte + base64 scheme and include all documented fields.
# Repository test used as guidance: none direct; Interface Description 2
# encoding notes are the oracle.
# Perspective: exact schema and encoding units.
# Source path: mlflow/entities/span.py::Span.to_dict
# -> _encode_trace_id_to_byte/_encode_span_id_to_byte/_encode_bytes_to_base64.
# ---------------------------------------------------------------------------
def check_span_to_dict_v3_base64():
    trace_id_int = 0x0102030405060708090A0B0C0D0E0F10
    span_id_int = 0x1112131415161718
    parent_id_int = 0x2122232425262728
    attributes = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-1"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("CHAIN"),
        "payload": dump_span_attribute_value({"x": 1}),
    }
    otel_span = make_otel_readable_span(
        name="encoded",
        trace_id=trace_id_int,
        span_id=span_id_int,
        parent_id=parent_id_int,
        start_time=100,
        end_time=200,
        attributes=attributes,
        events=[OTelEvent(name="evt", timestamp=123, attributes={"k": "v"})],
        status=OTelStatus(OTelStatusCode.OK),
    )
    span = Span(otel_span)
    data = span.to_dict()

    assert data["trace_id"] == base64.b64encode(
        trace_id_int.to_bytes(16, "big", signed=False)
    ).decode("utf-8")
    assert data["span_id"] == base64.b64encode(
        span_id_int.to_bytes(8, "big", signed=False)
    ).decode("utf-8")
    assert data["parent_span_id"] == base64.b64encode(
        parent_id_int.to_bytes(8, "big", signed=False)
    ).decode("utf-8")
    assert data["name"] == "encoded"
    assert data["start_time_unix_nano"] == 100
    assert data["end_time_unix_nano"] == 200
    assert data["status"]["code"] == "STATUS_CODE_OK"
    assert data["status"]["message"] == ""
    assert data["attributes"] == attributes
    assert len(data["events"]) == 1
    assert data["events"][0]["name"] == "evt"
    assert data["events"][0]["attributes"] == {"k": "v"}


# ---------------------------------------------------------------------------
# C8/R9/R40: Span.from_dict round-trips v3 base64 output. This executes the
# real from_dict call path that uses _is_base64_encoded and _decode_id_from_byte
# (static issues 1 and 2 are closed here).
# Repository test used as guidance: tests/tracing/test_fluent.py remote trace
# deserialization paths.
# Perspective: serialization/deserialization compatibility.
# Source path: mlflow/entities/span.py::Span.from_dict.
# ---------------------------------------------------------------------------
def check_span_from_dict_roundtrip_v3_base64():
    original = Span(
        make_otel_readable_span(
            name="roundtrip",
            trace_id=0x0102030405060708090A0B0C0D0E0F10,
            span_id=0x1112131415161718,
            parent_id=0x2122232425262728,
            start_time=100,
            end_time=200,
            attributes={
                SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-roundtrip"),
                SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("AGENT"),
                "payload": dump_span_attribute_value({"a": [1, 2]}),
            },
            events=[OTelEvent(name="evt", timestamp=123, attributes={"k": "v"})],
            status=OTelStatus(OTelStatusCode.OK),
        )
    )
    restored = Span.from_dict(original.to_dict())

    assert restored.trace_id == original.trace_id == "tr-roundtrip"
    assert restored.span_id == original.span_id
    assert restored.parent_id == original.parent_id
    assert restored.name == original.name
    assert restored.start_time_ns == original.start_time_ns
    assert restored.end_time_ns == original.end_time_ns
    assert restored.status == original.status
    assert restored.span_type == original.span_type
    assert restored.attributes == original.attributes
    assert restored.events == original.events


# ---------------------------------------------------------------------------
# C9/R9/R41: Span.from_dict reconstructs the v2 context schema.
# Repository test used as guidance: tests/tracing/test_fluent.py remote trace
# v2 compatibility.
# Perspective: backward-compatible schema dispatch.
# Source path: mlflow/entities/span.py::Span.from_dict -> from_dict_v2.
# ---------------------------------------------------------------------------
def check_span_from_dict_v2():
    span_id_int = 0xABCDEF
    parent_id_int = 0x123456
    data = {
        "context": {"trace_id": "abc123", "span_id": "abcdef"},
        "parent_id": "123456",
        "name": "v2-span",
        "start_time": 100,
        "end_time": 200,
        "attributes": {
            SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-v2"),
            SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("CHAIN"),
        },
        "status_code": "OK",
        "status_message": "",
        "events": [],
    }
    span = Span.from_dict(data)

    assert span.trace_id == "tr-v2"
    assert span.span_id == encode_span_id(span_id_int)
    assert span.parent_id == encode_span_id(parent_id_int)
    assert span.span_type == "CHAIN"
    assert span.status.status_code == SpanStatusCode.OK


# ---------------------------------------------------------------------------
# C10/R9: Span.from_dict reconstructs the legacy 3.5.0 non-base64 schema.
# Repository test used as guidance: none direct; current from_dict source
# contains the legacy branch.
# Perspective: legacy representation compatibility.
# Source path: mlflow/entities/span.py::Span.from_dict.
# ---------------------------------------------------------------------------
def check_span_from_dict_legacy_35():
    span_id_int = decode_id("def456")
    parent_id_int = decode_id("abc123")
    data = {
        "trace_id": "tr-abc123",
        "span_id": "def456",
        "parent_span_id": "abc123",
        "name": "legacy-span",
        "start_time_unix_nano": 100,
        "end_time_unix_nano": 200,
        "attributes": {
            SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-legacy"),
        },
        "status": {"code": "OK", "message": ""},
        "events": [],
    }
    span = Span.from_dict(data)

    assert span.trace_id == "tr-legacy"
    assert span.span_id == encode_span_id(span_id_int)
    assert span.parent_id == encode_span_id(parent_id_int)
    assert span.status.status_code == SpanStatusCode.OK


# ---------------------------------------------------------------------------
# C11/R10: Span.from_dict must reject a missing mlflow.traceRequestId with
# INVALID_PARAMETER_VALUE.
# Repository test used as guidance: current source line 262-267; no direct
# repository test found.
# Perspective: exact failure semantics.
# Source path: mlflow/entities/span.py::Span.from_dict.
# ---------------------------------------------------------------------------
def check_span_from_dict_missing_request_id():
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with raises(MlflowException, error_code=INVALID_PARAMETER_VALUE):
        Span.from_dict({"attributes": {}})


# ---------------------------------------------------------------------------
# C12/R11/R35/R36/R37: Span.from_otel_proto converts protobuf IDs, attributes,
# events, and status into an immutable MLflow Span.
# Repository test used as guidance: tests/tracing/test_otel_logging.py OTLP
# endpoint tests; no direct unit test for the converter.
# Perspective: OTLP compatibility and representation preservation.
# Source path: mlflow/entities/span.py::Span.from_otel_proto
# -> mlflow/tracing/utils/otlp.py::_otel_proto_bytes_to_id/_decode_otel_proto_anyvalue.
# ---------------------------------------------------------------------------
def check_span_from_otel_proto_basic():
    from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue

    trace_id_int = 0x0102030405060708090A0B0C0D0E0F10
    span_id_int = 0x1112131415161718
    parent_id_int = 0x2122232425262728

    proto_span = OTelProtoSpan()
    proto_span.trace_id = trace_id_int.to_bytes(16, "big")
    proto_span.span_id = span_id_int.to_bytes(8, "big")
    proto_span.parent_span_id = parent_id_int.to_bytes(8, "big")
    proto_span.name = "otel-span"
    proto_span.start_time_unix_nano = 100
    proto_span.end_time_unix_nano = 200
    proto_span.status.code = OTelProtoStatus.STATUS_CODE_ERROR
    proto_span.status.message = "boom"

    attr = proto_span.attributes.add()
    attr.key = SpanAttributeKey.SPAN_TYPE
    _set_otel_proto_anyvalue(attr.value, "LLM")
    attr = proto_span.attributes.add()
    attr.key = "payload"
    _set_otel_proto_anyvalue(attr.value, {"a": [1, 2]})

    event = proto_span.events.add()
    event.name = "evt"
    event.time_unix_nano = 123
    event_attr = event.attributes.add()
    event_attr.key = "k"
    _set_otel_proto_anyvalue(event_attr.value, [1, 2, 3])

    span = Span.from_otel_proto(proto_span)

    assert span.trace_id == generate_mlflow_trace_id_from_otel_trace_id(trace_id_int)
    assert span.span_id == encode_span_id(span_id_int)
    assert span.parent_id == encode_span_id(parent_id_int)
    assert span.span_type == "LLM"
    assert span.status.status_code == SpanStatusCode.ERROR
    assert span.status.description == "boom"
    assert span.attributes["payload"] == {"a": [1, 2]}
    assert span.attributes[SpanAttributeKey.REQUEST_ID] == span.trace_id
    assert span.events[0].name == "evt"
    assert span.events[0].timestamp == 123
    assert span.events[0].attributes == {"k": [1, 2, 3]}


# ---------------------------------------------------------------------------
# C12/R11 (status-mapping branch strengthening): Span.from_otel_proto must map
# OTel proto OK and UNSET statuses to MLflow OK and UNSET, not just ERROR.
# Repository test used as guidance:
# tests/tracing/test_otel_loading.py::test_get_trace_for_otel_sent_span and
# ::test_get_trace_with_otel_span_status.
# Perspective: full protobuf status-code mapping.
# Source path: mlflow/entities/span.py::Span.from_otel_proto.
# ---------------------------------------------------------------------------
def check_span_from_otel_proto_status_mapping():
    trace_id_int = 0x0102030405060708090A0B0C0D0E0F10
    span_id_int = 0x1112131415161718

    for proto_code, expected_code, message in [
        (OTelProtoStatus.STATUS_CODE_OK, SpanStatusCode.OK, "ok-message"),
        (OTelProtoStatus.STATUS_CODE_UNSET, SpanStatusCode.UNSET, ""),
    ]:
        proto_span = OTelProtoSpan()
        proto_span.trace_id = trace_id_int.to_bytes(16, "big")
        proto_span.span_id = span_id_int.to_bytes(8, "big")
        proto_span.name = "status-span"
        proto_span.start_time_unix_nano = 100
        proto_span.end_time_unix_nano = 200
        proto_span.status.code = proto_code
        proto_span.status.message = message

        span = Span.from_otel_proto(proto_span)
        assert span.status.status_code == expected_code
        assert span.status.description == message


# ---------------------------------------------------------------------------
# C13/R11: Span.from_otel_proto generates a v4 location trace ID when
# location_id is provided.
# Repository test used as guidance: none direct; task OTLP compatibility.
# Perspective: location-specific trace ID generation.
# Source path: mlflow/entities/span.py::Span.from_otel_proto
# -> mlflow/tracing/utils.generate_trace_id_v4_from_otel_trace_id.
# ---------------------------------------------------------------------------
def check_span_from_otel_proto_location_id():
    trace_id_int = 0x0102030405060708090A0B0C0D0E0F10
    span_id_int = 0x1112131415161718
    proto_span = OTelProtoSpan()
    proto_span.trace_id = trace_id_int.to_bytes(16, "big")
    proto_span.span_id = span_id_int.to_bytes(8, "big")
    proto_span.name = "v4-span"
    proto_span.start_time_unix_nano = 100
    proto_span.end_time_unix_nano = 200

    span = Span.from_otel_proto(proto_span, location_id="loc")

    assert span.trace_id == generate_trace_id_v4_from_otel_trace_id(trace_id_int, "loc")
    assert span.span_id == encode_span_id(span_id_int)


# ---------------------------------------------------------------------------
# C14/R12: Span.to_otel_proto converts an MLflow span to OTelProtoSpan with
# bytes IDs, AnyValue attributes, and SpanEvent protobuf events. The root-span
# case is included to prove parent_span_id is left unset when no parent exists.
# Repository test used as guidance: tests/entities/test_span_event.py
# (event protobuf conversion round-trip).
# Perspective: OTLP export representation preservation and parent boundary.
# Source path: mlflow/entities/span.py::Span.to_otel_proto
# -> mlflow/tracing/utils/otlp.py::_set_otel_proto_anyvalue.
# ---------------------------------------------------------------------------
def check_span_to_otel_proto_export():
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    trace_id_int = 0x0102030405060708090A0B0C0D0E0F10
    span_id_int = 0x1112131415161718
    parent_id_int = 0x2122232425262728
    span = Span(
        make_otel_readable_span(
            name="export",
            trace_id=trace_id_int,
            span_id=span_id_int,
            parent_id=parent_id_int,
            start_time=100,
            end_time=200,
            attributes={
                SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-export"),
                "payload": dump_span_attribute_value({"x": 1}),
            },
            events=[OTelEvent(name="evt", timestamp=123, attributes={"k": "v"})],
            status=OTelStatus(OTelStatusCode.OK),
        )
    )

    proto_span = span.to_otel_proto()

    assert proto_span.trace_id == bytes.fromhex(span._trace_id)
    assert proto_span.span_id == bytes.fromhex(span.span_id)
    assert proto_span.parent_span_id == bytes.fromhex(span.parent_id)
    assert proto_span.name == "export"
    assert proto_span.start_time_unix_nano == 100
    assert proto_span.end_time_unix_nano == 200
    assert proto_span.status.code == OTelProtoStatus.STATUS_CODE_OK

    decoded_attrs = {
        attr.key: _decode_otel_proto_anyvalue(attr.value)
        for attr in proto_span.attributes
    }
    assert decoded_attrs == {"mlflow.traceRequestId": "tr-export", "payload": {"x": 1}}

    assert len(proto_span.events) == 1
    decoded_event_attrs = {
        attr.key: _decode_otel_proto_anyvalue(attr.value)
        for attr in proto_span.events[0].attributes
    }
    assert proto_span.events[0].name == "evt"
    assert proto_span.events[0].time_unix_nano == 123
    assert decoded_event_attrs == {"k": "v"}

    # Root span must omit parent_span_id (protobuf bytes field stays empty).
    root_span = Span(
        make_otel_readable_span(
            name="root-export",
            trace_id=trace_id_int,
            span_id=span_id_int,
            parent_id=None,
            start_time=100,
            end_time=200,
            attributes={
                SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-root-export"),
            },
            status=OTelStatus(OTelStatusCode.OK),
        )
    )
    root_proto = root_span.to_otel_proto()
    assert root_proto.parent_span_id == b""


# ---------------------------------------------------------------------------
# C15/R13: LiveSpan.from_dict is unsupported and always raises
# NotImplementedError.
# Repository test used as guidance: none direct; Interface Description 2.
# Perspective: exact failure semantics.
# Source path: mlflow/entities/span.py::LiveSpan.from_dict.
# ---------------------------------------------------------------------------
def check_live_span_from_dict_raises():
    with raises(NotImplementedError):
        LiveSpan.from_dict({})


# ---------------------------------------------------------------------------
# C16/R14: LiveSpan.set_span_type writes mlflow.spanType through set_attribute.
# Repository test used as guidance: autologging tests assert span_type values
# (e.g., tests/anthropic/test_anthropic_autolog.py).
# Perspective: live-span mutation and attribute round-trip.
# Source path: mlflow/entities/span.py::LiveSpan.set_span_type -> set_attribute.
# ---------------------------------------------------------------------------
def check_live_span_set_span_type():
    live, _ = make_live_span("tr-1", span_id=1, parent_id=None)
    live.set_span_type("TOOL")

    assert live.get_attribute(SpanAttributeKey.SPAN_TYPE) == "TOOL"
    assert live.span_type == "TOOL"


# ---------------------------------------------------------------------------
# C17/R15: LiveSpan.to_immutable_span reuses the underlying OTel span without
# copying state.
# Repository test used as guidance:
# tests/tracing/test_trace_manager.py::test_add_spans.
# Perspective: identity-preserving downcast.
# Source path: mlflow/entities/span.py::LiveSpan.to_immutable_span.
# ---------------------------------------------------------------------------
def check_live_span_to_immutable_span():
    live, otel_span = make_live_span("tr-1", span_id=1, parent_id=None)
    immutable = live.to_immutable_span()

    assert isinstance(immutable, Span)
    assert not isinstance(immutable, LiveSpan)
    assert immutable._span is otel_span


# ---------------------------------------------------------------------------
# C18/R16/R42: LiveSpan.end must apply configured span processors through the
# real end call path and then end the underlying OTel span. Static issue 3 is
# closed here because the real LiveSpan.end caller executes apply_span_processors.
# Repository test used as guidance:
# tests/tracing/utils/test_processor.py::test_apply_span_processors_*.
# Perspective: lifecycle termination and processor application ordering/failure.
# Source path: mlflow/entities/span.py::LiveSpan.end
# -> mlflow/tracing/utils/processor.py::apply_span_processors.
# ---------------------------------------------------------------------------
def check_live_span_end_applies_processors():
    import mlflow

    live, otel_span = make_live_span("tr-end", span_id=1, parent_id=None)
    otel_span.end = Mock()

    def failing_processor(span):
        raise ValueError("boom")

    def good_processor(span):
        span.set_outputs("overridden")
        span.set_attribute("attr_1", "value_1")

    with mlflow.tracing.configure(span_processors=[failing_processor, good_processor]):
        live.end(end_time_ns=999)

    assert otel_span.end.called
    assert otel_span.end.call_args.kwargs == {"end_time": 999}
    assert live.outputs == "overridden"
    assert live.get_attribute("attr_1") == "value_1"
    assert live.status.status_code == SpanStatusCode.OK


# ---------------------------------------------------------------------------
# NEW C36/R45: LiveSpan.record_exception records an exception event and sets
# span status to ERROR for both string and Exception inputs, rejects invalid
# input, and NoOpSpan.record_exception stays a no-op.
# Repository test used as guidance:
# tests/tracing/test_fluent.py::test_span_record_exception_with_string,
# ::test_span_record_exception_with_exception,
# ::test_span_record_exception_invalid_type,
# ::test_span_record_exception_no_op_span.
# Perspective: exception recording lifecycle and no-op compatibility.
# Source path: mlflow/entities/span.py::LiveSpan.record_exception and
# NoOpSpan.record_exception.
# ---------------------------------------------------------------------------
def check_span_record_exception():
    from mlflow.entities.span import NoOpSpan
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    live, _ = make_live_span("tr-record-string", span_id=1, parent_id=None)
    live.record_exception("Something went wrong")
    assert live.status.status_code == SpanStatusCode.ERROR
    assert len(live.events) == 1
    assert live.events[0].name == "exception"
    assert live.events[0].attributes["exception.message"] == "Something went wrong"

    live, _ = make_live_span("tr-record-exception", span_id=2, parent_id=None)
    live.record_exception(ValueError("Custom error message"))
    assert live.status.status_code == SpanStatusCode.ERROR
    assert len(live.events) == 1
    assert live.events[0].name == "exception"
    assert live.events[0].attributes["exception.type"] == "ValueError"
    assert live.events[0].attributes["exception.message"] == "Custom error message"

    live, _ = make_live_span("tr-record-invalid", span_id=3, parent_id=None)
    with raises(MlflowException, error_code=INVALID_PARAMETER_VALUE):
        live.record_exception(123)

    noop = NoOpSpan()
    assert noop.record_exception("ignored") is None
    assert noop.record_exception(ValueError("ignored")) is None


# ---------------------------------------------------------------------------
# C20/R30: NoOpSpan.trace_id returns the no-op constant.
# Repository test used as guidance: none direct; Interface Description 2.
# Perspective: no-op compatibility constant.
# Source path: mlflow/entities/span.py::NoOpSpan.trace_id.
# ---------------------------------------------------------------------------
def check_noop_trace_id_constant():
    from mlflow.entities.span import NO_OP_SPAN_TRACE_ID, NoOpSpan

    assert NoOpSpan().trace_id == NO_OP_SPAN_TRACE_ID == "MLFLOW_NO_OP_SPAN_TRACE_ID"


# ---------------------------------------------------------------------------
# C21/R17/R20/R21/R27/R28/R29: NoOpSpan read-only properties return None.
# Repository test used as guidance: none direct; Interface Description 2.
# Perspective: no-op read boundary values.
# Source path: mlflow/entities/span.py::NoOpSpan.*.
# ---------------------------------------------------------------------------
def check_noop_readonly_properties_none():
    noop = NoOpSpan()
    assert noop._trace_id is None
    assert noop.span_id is None
    assert noop.name is None
    assert noop.start_time_ns is None
    assert noop.end_time_ns is None
    assert noop.status is None


# ---------------------------------------------------------------------------
# C22/R18/R19/R22/R23/R24/R25/R26: NoOpSpan mutators are safe no-ops that
# accept the documented signatures and return None.
# Repository test used as guidance: none direct; Interface Description 2.
# Perspective: no-op setter compatibility.
# Source path: mlflow/entities/span.py::NoOpSpan.set_* / add_event / end.
# ---------------------------------------------------------------------------
def check_noop_mutators_noop():
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    assert noop.add_event(SpanEvent(name="e")) is None
    assert noop.set_attribute("k", "v") is None
    assert noop.set_attributes({"k": "v"}) is None
    assert noop.set_inputs({"x": 1}) is None
    assert noop.set_outputs({"y": 2}) is None
    assert noop.set_status(SpanStatus(SpanStatusCode.OK)) is None
    assert noop.set_status("OK") is None
    assert noop.end(outputs={"y": 2}, attributes={"k": "v"}, status="OK", end_time_ns=123) is None


# ---------------------------------------------------------------------------
# C23/R31: _CachedSpanAttributesRegistry.set must reject mutation with
# INVALID_PARAMETER_VALUE.
# Repository test used as guidance: none direct; Interface Description 2.
# Perspective: immutable attribute boundary failure.
# Source path: mlflow/entities/span.py::_CachedSpanAttributesRegistry.set.
# ---------------------------------------------------------------------------
def check_cached_span_attributes_set_raises():
    from mlflow.entities.span import _CachedSpanAttributesRegistry
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    otel_span = create_mock_otel_span(trace_id=1, span_id=2)
    registry = _CachedSpanAttributesRegistry(otel_span)
    with raises(MlflowException, error_code=INVALID_PARAMETER_VALUE):
        registry.set("k", "v")


# ---------------------------------------------------------------------------
# C25/R33: create_mlflow_span raises INVALID_PARAMETER_VALUE for an invalid
# input type.
# Repository test used as guidance: none direct; Interface Description 2.
# Perspective: invalid-input factory failure.
# Source path: mlflow/entities/span.py::create_mlflow_span.
# ---------------------------------------------------------------------------
def check_create_mlflow_span_invalid_type():
    from mlflow.entities.span import create_mlflow_span
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with raises(MlflowException, error_code=INVALID_PARAMETER_VALUE):
        create_mlflow_span(object(), "tr-invalid")


# ---------------------------------------------------------------------------
# C27/R35: _decode_otel_proto_anyvalue decodes primitive AnyValue fields.
# Repository test used as guidance:
# tests/entities/test_span_event.py::test_span_event_to_otel_proto_conversion.
# Perspective: protobuf primitive decoding.
# Source path: mlflow/tracing/utils/otlp.py::_decode_otel_proto_anyvalue.
# ---------------------------------------------------------------------------
def check_decode_otel_proto_anyvalue_primitives():
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    assert _decode_otel_proto_anyvalue(AnyValue()) is None

    bool_value = AnyValue(); bool_value.bool_value = True
    assert _decode_otel_proto_anyvalue(bool_value) is True

    string_value = AnyValue(); string_value.string_value = "s"
    assert _decode_otel_proto_anyvalue(string_value) == "s"

    int_value = AnyValue(); int_value.int_value = 42
    assert _decode_otel_proto_anyvalue(int_value) == 42

    double_value = AnyValue(); double_value.double_value = 3.14
    assert _decode_otel_proto_anyvalue(double_value) == 3.14

    bytes_value = AnyValue(); bytes_value.bytes_value = b"abc"
    assert _decode_otel_proto_anyvalue(bytes_value) == b"abc"


# ---------------------------------------------------------------------------
# C28/R36: _decode_otel_proto_anyvalue recursively decodes array and kvlist
# values.
# Repository test used as guidance:
# tests/entities/test_span_event.py::test_span_event_to_otel_proto_conversion
# (nested list/dict round-trip).
# Perspective: recursive protobuf decoding.
# Source path: mlflow/tracing/utils/otlp.py::_decode_otel_proto_anyvalue.
# ---------------------------------------------------------------------------
def check_decode_otel_proto_anyvalue_recursive():
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue, _set_otel_proto_anyvalue

    source = {"a": [1, {"b": "c"}], "d": [True, None]}
    pb = AnyValue()
    _set_otel_proto_anyvalue(pb, source)
    assert _decode_otel_proto_anyvalue(pb) == source


# ---------------------------------------------------------------------------
# C30/R4/R38: _SpanAttributesRegistry.get_all deserializes all attributes and
# get falls back to raw non-JSON strings.
# Repository test used as guidance:
# tests/tracing/opentelemetry/test_integration.py (attribute registry behavior).
# Perspective: registry aggregation and fallback.
# Source path: mlflow/entities/span.py::_SpanAttributesRegistry.get_all/get.
# ---------------------------------------------------------------------------
def check_span_attributes_registry_get_all():
    from mlflow.entities.span import _SpanAttributesRegistry

    otel_span = create_mock_otel_span(trace_id=1, span_id=2)
    registry = _SpanAttributesRegistry(otel_span)
    registry.set("json_attr", {"x": 1})
    otel_span.set_attribute("raw_attr", "not-json")

    assert registry.get_all() == {"json_attr": {"x": 1}, "raw_attr": "not-json"}
    assert registry.get("raw_attr") == "not-json"


# ---------------------------------------------------------------------------
# C31/R40: base64 detection and decoding helpers.
# Repository test used as guidance: none direct; Interface Description 2
# encoding notes.
# Perspective: exact helper semantics.
# Source path: mlflow/entities/span.py::_is_base64_encoded/_decode_id_from_byte.
# ---------------------------------------------------------------------------
def check_base64_helpers():
    from mlflow.entities.span import _decode_id_from_byte, _is_base64_encoded

    encoded = base64.b64encode((0x0102030405060708).to_bytes(8, "big")).decode("utf-8")
    assert _is_base64_encoded(encoded) is True
    assert _decode_id_from_byte(encoded) == 0x0102030405060708
    assert _is_base64_encoded("not base64 !!!") is False


# ---------------------------------------------------------------------------
# C32/R41: v2 schema detection and conversion helpers.
# Repository test used as guidance: tests/tracing/test_fluent.py remote trace
# v2 compatibility.
# Perspective: schema dispatch and v2 representation preservation.
# Source path: mlflow/entities/span.py::Span._is_span_v2_schema/from_dict_v2.
# ---------------------------------------------------------------------------
def check_v2_schema_helpers():
    from mlflow.entities.span import Span

    assert Span._is_span_v2_schema({"context": {}}) is True
    assert Span._is_span_v2_schema({"trace_id": "x"}) is False

    span = Span.from_dict_v2(
        {
            "context": {"trace_id": "abc", "span_id": "def"},
            "parent_id": "123",
            "name": "v2-span",
            "start_time": 100,
            "end_time": 200,
            "attributes": {
                SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-v2"),
                SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("CHAIN"),
            },
            "status_code": "OK",
            "status_message": "",
            "events": [],
        }
    )
    assert span.trace_id == "tr-v2"
    assert span.span_type == "CHAIN"
    assert span.status.status_code == SpanStatusCode.OK


# ---------------------------------------------------------------------------
# C33/R3: TraceData.request and TraceData.response return root-span raw
# serialized inputs/outputs, or None for an empty trace.
# Repository test used as guidance: libs/tracing/mlflow/entities/trace_data.py;
# no direct repository test found.
# Perspective: root-span dataflow and empty boundary.
# Source path: mlflow/entities/trace_data.py::TraceData.request/response.
# ---------------------------------------------------------------------------
def check_trace_data_request_response():
    inputs = dump_span_attribute_value({"question": "hello"})
    outputs = dump_span_attribute_value({"answer": "world"})
    root_span = Span(
        make_otel_readable_span(
            attributes={
                SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-td"),
                SpanAttributeKey.INPUTS: inputs,
                SpanAttributeKey.OUTPUTS: outputs,
            },
        )
    )

    trace_data = TraceData([root_span])
    assert trace_data.request == inputs
    assert trace_data.response == outputs

    empty = TraceData()
    assert empty.request is None
    assert empty.response is None


# ---------------------------------------------------------------------------
# C35/R43/R44: SqlAlchemyStore._update_trace_info_attributes must return a
# preview update dict only for unset SQL previews. This complements the caller
# path check in arch_spec.py with the direct side-effect oracle.
# Repository test used as guidance: tests/tracing/test_otel_logging.py OTLP
# ingestion path; no direct unit test found.
# Perspective: side-effect boundary and non-overwrite behavior.
# Source path: mlflow/store/tracking/sqlalchemy_store.py::_update_trace_info_attributes.
# ---------------------------------------------------------------------------
def check_sqlalchemy_update_trace_info_preview_side_effects():
    import mlflow.store.tracking.sqlalchemy_store as sql_store
    from mlflow.store.tracking.dbmodels.models import SqlTraceInfo
    from mlflow.tracing.utils.truncation import _get_truncated_preview

    span_dict = {
        "attributes": {
            SpanAttributeKey.INPUTS: json.dumps({"question": "hello"}),
            SpanAttributeKey.OUTPUTS: json.dumps({"answer": "world"}),
        }
    }
    store = object.__new__(sql_store.SqlAlchemyStore)

    unset_info = SqlTraceInfo()
    unset_info.request_preview = None
    unset_info.response_preview = None
    update = store._update_trace_info_attributes(unset_info, span_dict)
    assert update[SqlTraceInfo.request_preview] == _get_truncated_preview(
        span_dict["attributes"][SpanAttributeKey.INPUTS], role="user"
    )
    assert update[SqlTraceInfo.response_preview] == _get_truncated_preview(
        span_dict["attributes"][SpanAttributeKey.OUTPUTS], role="assistant"
    )

    set_info = SqlTraceInfo()
    set_info.request_preview = "keep-request"
    set_info.response_preview = "keep-response"
    assert store._update_trace_info_attributes(set_info, span_dict) == {}


# ---------------------------------------------------------------------------
# C34/R2/R43: _get_truncated_preview truncates and extracts chat content;
# set_request_response_preview only sets previews when they are None.
# Repository test used as guidance:
# tests/tracing/utils/test_truncation.py (all parametrized truncation cases).
# Perspective: truncation boundaries and non-overwrite side effects.
# Source path: mlflow/tracing/utils/truncation.py::_get_truncated_preview,
# set_request_response_preview.
# ---------------------------------------------------------------------------
def check_truncation_and_preview_setters():
    from mlflow.tracing.utils.truncation import (
        _get_truncated_preview,
        set_request_response_preview,
    )

    with patch("mlflow.tracing.utils.truncation._get_max_length", return_value=50):
        assert _get_truncated_preview(None, role="user") == ""
        assert _get_truncated_preview("short", role="user") == "short"
        long_value = "start" + "a" * 50
        assert _get_truncated_preview(long_value, role="user") == "start" + "a" * 42 + "..."

        chat = json.dumps(
            {"messages": [{"role": "user", "content": "First" + "a" * 50}]}
        )
        assert _get_truncated_preview(chat, role="user") == "First" + "a" * 42 + "..."

    inputs = dump_span_attribute_value({"question": "hello"})
    outputs = dump_span_attribute_value({"answer": "world"})
    root_span = Span(
        make_otel_readable_span(
            attributes={
                SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-preview"),
                SpanAttributeKey.INPUTS: inputs,
                SpanAttributeKey.OUTPUTS: outputs,
            },
        )
    )
    trace_data = TraceData([root_span])

    info = make_trace_info("tr-preview")
    set_request_response_preview(info, trace_data)
    assert info.request_preview is not None
    assert info.response_preview is not None

    preserved = make_trace_info("tr-preserved")
    preserved.request_preview = "keep-request"
    preserved.response_preview = "keep-response"
    set_request_response_preview(preserved, trace_data)
    assert preserved.request_preview == "keep-request"
    assert preserved.response_preview == "keep-response"


# ---------------------------------------------------------------------------
# NEW C38/R47: InMemoryTraceManager timeout-based cleanup must honor the buffer
# TTL and max-size environment variables.
# Repository test used as guidance:
# tests/tracing/test_trace_manager.py::test_traces_buffer_expires_after_ttl,
# ::test_traces_buffer_expires_and_log_when_timeout_is_set,
# ::test_traces_buffer_max_size_limit.
# Perspective: timeout/max-size cleanup boundaries.
# Source path: mlflow/tracing/trace_manager.py::InMemoryTraceManager and
# mlflow/tracing/utils/timeout.py::get_trace_cache_with_timeout.
# ---------------------------------------------------------------------------
def check_trace_manager_ttl_and_max_size_cleanup():
    from mlflow.tracing.trace_manager import InMemoryTraceManager

    with patch.dict(
        os.environ,
        {"MLFLOW_TRACE_BUFFER_TTL_SECONDS": "1", "MLFLOW_TRACE_BUFFER_MAX_SIZE": "1000", "MLFLOW_TRACE_TIMEOUT_SECONDS": "0"},
    ), patch(
        "mlflow.tracing.trace_manager.MLFLOW_TRACE_TIMEOUT_SECONDS.get",
        return_value=None,
    ):
        ttl_manager = InMemoryTraceManager()
        ttl_manager.register_trace(12345, make_trace_info("tr-ttl"))
        ttl_span, _ = make_live_span("tr-ttl", span_id=1, parent_id=None)
        ttl_manager.register_span(ttl_span)
        assert "tr-ttl" in ttl_manager._traces
        assert len(ttl_manager._traces["tr-ttl"].span_dict) == 1

        time.sleep(1.2)
        assert "tr-ttl" not in ttl_manager._traces

    with patch.dict(
        os.environ,
        {"MLFLOW_TRACE_BUFFER_TTL_SECONDS": "3600", "MLFLOW_TRACE_BUFFER_MAX_SIZE": "1", "MLFLOW_TRACE_TIMEOUT_SECONDS": "0"},
    ), patch(
        "mlflow.tracing.trace_manager.MLFLOW_TRACE_TIMEOUT_SECONDS.get",
        return_value=None,
    ):
        max_manager = InMemoryTraceManager()
        max_manager.register_trace(1, make_trace_info("tr-max-1"))
        max_span_1, _ = make_live_span("tr-max-1", span_id=1, parent_id=None)
        max_manager.register_span(max_span_1)
        assert "tr-max-1" in max_manager._traces
        assert len(max_manager._traces) == 1

        max_manager.register_trace(2, make_trace_info("tr-max-2"))
        max_span_2, _ = make_live_span("tr-max-2", span_id=1, parent_id=None)
        max_manager.register_span(max_span_2)

        assert "tr-max-1" not in max_manager._traces
        assert "tr-max-2" in max_manager._traces
        assert len(max_manager._traces) == 1


def _all_checks():
    return [
        check_trace_to_mlflow_trace_previews,
        check_span_attributes_deserialized,
        check_span_events_plain_dicts,
        check_span_request_id_alias,
        check_span_span_type,
        check_span_to_dict_v3_base64,
        check_span_from_dict_roundtrip_v3_base64,
        check_span_from_dict_v2,
        check_span_from_dict_legacy_35,
        check_span_from_dict_missing_request_id,
        check_span_from_otel_proto_basic,
        check_span_from_otel_proto_status_mapping,
        check_span_from_otel_proto_location_id,
        check_span_to_otel_proto_export,
        check_live_span_from_dict_raises,
        check_live_span_set_span_type,
        check_live_span_to_immutable_span,
        check_live_span_end_applies_processors,
        check_span_record_exception,
        check_noop_trace_id_constant,
        check_noop_readonly_properties_none,
        check_noop_mutators_noop,
        check_cached_span_attributes_set_raises,
        check_create_mlflow_span_invalid_type,
        check_decode_otel_proto_anyvalue_primitives,
        check_decode_otel_proto_anyvalue_recursive,
        check_span_attributes_registry_get_all,
        check_base64_helpers,
        check_v2_schema_helpers,
        check_trace_data_request_response,
        check_sqlalchemy_update_trace_info_preview_side_effects,
        check_truncation_and_preview_setters,
        check_trace_manager_ttl_and_max_size_cleanup,
    ]


if __name__ == "__main__":
    import traceback

    failed = 0
    for check in _all_checks():
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as exc:
            failed += 1
            print(f"FAIL: {check.__name__}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    if failed:
        sys.exit(1)
