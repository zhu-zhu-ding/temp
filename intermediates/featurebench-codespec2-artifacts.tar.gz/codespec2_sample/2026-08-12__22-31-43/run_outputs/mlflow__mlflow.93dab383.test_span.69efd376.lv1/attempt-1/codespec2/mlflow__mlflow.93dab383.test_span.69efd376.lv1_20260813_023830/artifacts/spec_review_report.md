# Spec Review Report

## Evidence Reviewed

- Task document and all three Interface Descriptions (primary oracle).
- Semantic IR: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_span.69efd376.lv1_20260813_023830/artifacts/semantic_ir.md`
- Architecture spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_span.69efd376.lv1_20260813_023830/artifacts/arch_spec.py`
- Behavior spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_span.69efd376.lv1_20260813_023830/artifacts/behavior_spec.py`
- Static issues and static analysis artifacts.
- Review skill: `/installed-agent/codespec2/review_skill.md`
- Repository source: `mlflow/entities/span.py`, `mlflow/tracing/trace_manager.py`, `mlflow/entities/trace_data.py`, `mlflow/tracing/utils/otlp.py`, `mlflow/tracing/utils/processor.py`, `mlflow/tracing/utils/truncation.py`, `mlflow/tracing/processor/base_mlflow.py`, `mlflow/store/tracking/sqlalchemy_store.py`, and `libs/tracing/mlflow/*` reference copies.
- Repository tests examined for target and analogous APIs:
  - `tests/tracing/test_trace_manager.py`
  - `tests/tracing/test_tracing_client.py`
  - `tests/tracking/test_client.py`
  - `tests/tracing/test_fluent.py`
  - `tests/tracing/test_otel_logging.py`
  - `tests/tracing/test_otel_loading.py`
  - `tests/entities/test_trace.py`
  - `tests/entities/test_trace_data.py`
  - `tests/entities/test_span_event.py`
  - `tests/tracing/utils/test_processor.py`
  - `tests/tracing/utils/test_truncation.py`
  - `tests/tracing/utils/test_otlp.py`
  - `tests/tracing/otel/test_span_translation.py`
  - `tests/tracing/helper.py`

## Rubric Scores

### Seed: Requirement coverage
**Score:** FAIL  
**Evidence:** The IR assigns R/G/C paths for most interface-described span APIs, but two atomic task obligations have no IR record or executable observation: (1) "Event logging and exception recording within spans" has no `record_exception` requirement despite repository-tested `LiveSpan.record_exception` and `NoOpSpan.record_exception`; (2) "Thread-safe in-memory trace management with timeout-based cleanup" has no requirement or generated check despite repository tests for concurrent registration and TTL/max-size expiration.  
**Affected R/E/C IDs:** none assigned (gap); nearest existing C22 covers only no-op setters.

### Seed: Requirement fidelity
**Score:** FAIL  
**Evidence:** Several checks observe a narrower or looser relation than the task requires: `Span.from_otel_proto` status mapping only observes `ERROR`; `create_mlflow_span` never exercises `span_type=None`; `Span.to_otel_proto` never exercises a root span; `apply_span_processors` never observes the non-null-return warning semantics.  
**Affected R/E/C IDs:** C12/R11, C14/R12, C19/R42, C24/R32.

### Seed: Caller binding and architecture
**Score:** FAIL  
**Evidence:** Static issues 4 and 5 are on-path, but their generated checks use import-identity assertions plus output equality rather than a real observer on the CALL edge. `on_start` could import `create_mlflow_span` but construct `LiveSpan` inline; `_update_trace_info_attributes` could import `_get_truncated_preview` but compute previews inline, and both would pass.  
**Affected R/E/C IDs:** C26/R34/E35, C35/R44/E40/E41; static issues 4 and 5.

### Seed: Dataflow and lifecycle
**Score:** FAIL  
**Evidence:** Root-span boundary is not tested for `to_otel_proto` parent omission, and the live-span factory default dataflow (`span_type=None -> SpanType.UNKNOWN`) is not tested. Live-to-immutable identity, attribute deserialization, event plain-dict conversion, and preview side effects are otherwise well observed.  
**Affected R/E/C IDs:** C14/R12, C24/R32.

### Seed: Failure and compatibility
**Score:** PASS  
**Evidence:** Declared failure paths are generally exact: `LiveSpan.from_dict` raises `NotImplementedError`; `_CachedSpanAttributesRegistry.set` raises `MlflowException(INVALID_PARAMETER_VALUE)`; `create_mlflow_span` invalid type raises the documented error; missing request ID is checked with `error_code`.  
**Affected R/E/C IDs:** C11/R10, C15/R13, C23/R31, C25/R33.

### Seed: Static-issue closure strength
**Score:** FAIL  
**Evidence:** Issues 1, 2, and 3 are closed by runtime execution of `Span.from_dict` and `LiveSpan.end`, so those closures are materially stronger than import checks. Issues 4 and 5 are not: their checks can pass when the required symbol is imported but never called. A static pass is not runtime proof.  
**Affected R/E/C IDs:** C26/R34 (issue 4), C35/R44 (issue 5).

### Seed: Chain integrity
**Score:** PASS  
**Evidence:** No generated check was found that reaches the observer while bypassing a delegation layer that itself contains an unresolved static issue. The C26 and C35 weaknesses are call-observation weaknesses, not bypasses of the layer containing the static issue.  
**Affected R/E/C IDs:** none.

### Seed: Repository-test alignment
**Score:** FAIL  
**Evidence:** Repository tests reveal several concrete oracles the specs do not adapt: `test_span_record_exception_*`, `test_add_and_pop_span_thread_safety`, TTL expiry tests, `test_apply_span_processors_returns_non_none_warning`, and OTel ingestion status tests.  
**Affected R/E/C IDs:** C12/R11, C19/R42; missing exception/thread-safety R records.

### Seed: Oracle strength
**Score:** FAIL  
**Evidence:** Several assertions are broad (`logger.warning.called`), single-branch (`ERROR` only), or omit a default/optional path (`span_type=None`, root `parent_span_id`). These are success-only or non-discriminating with respect to plausible wrong implementations.  
**Affected R/E/C IDs:** C12/R11, C14/R12, C19/R42, C24/R32.

## Findings

### Finding 1
- **Type:** `missing_requirement`
- **Affected IDs:** none assigned; task obligation "Event logging and exception recording within spans" is absent from IR and both specs.
- **Static issue:** none.
- **Repository source/test evidence:** `mlflow/entities/span.py` already defines `LiveSpan.record_exception` and `NoOpSpan.record_exception`; `tests/tracing/test_fluent.py::test_span_record_exception_with_string`, `::test_span_record_exception_with_exception`, `::test_span_record_exception_invalid_type`, and `::test_span_record_exception_no_op_span` all exercise this public API.
- **Gap:** No generated check calls `record_exception`; a broken implementation that fails to set `ERROR` status, fails to add an exception event, accepts invalid input, or makes `NoOpSpan.record_exception` raise would still pass the specs.
- **Rework:** Add an IR requirement and executable behavior check(s) that exercise `LiveSpan.record_exception` with both string and `Exception` inputs and assert status `ERROR` plus a preserved exception event, assert invalid input raises `MlflowException`, and assert `NoOpSpan.record_exception(...)` is a no-op.

### Finding 2
- **Type:** `missing_requirement`
- **Affected IDs:** none assigned; task obligation "Thread-safe in-memory trace management with timeout-based cleanup" is absent from IR and both specs.
- **Static issue:** none.
- **Repository source/test evidence:** `tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety`, `::test_traces_buffer_expires_after_ttl`, `::test_traces_buffer_expires_and_log_when_timeout_is_set`, and `::test_traces_buffer_max_size_limit`.
- **Gap:** No generated check observes concurrent registration or TTL/max-size cleanup. A regression in `InMemoryTraceManager` locking or timeout cache behavior would not be detected.
- **Rework:** Add an IR requirement and generated checks that register spans from multiple threads and assert no lost spans after `pop_trace`, and separately set the TTL/max-size environment variables and assert expired entries are removed/cleaned up with expected status behavior.

### Finding 3
- **Type:** `weak_constraint`
- **Affected IDs:** C26, R34, E35; static issue 4.
- **Static issue:** `create_mlflow_span` used but not defined or imported in `mlflow/tracing/processor/base_mlflow.py`.
- **Repository source/test evidence:** `mlflow/tracing/processor/base_mlflow.py::BaseMlflowSpanProcessor.on_start` calls `create_mlflow_span`; arch_spec `check_on_start_calls_imported_create_mlflow_span` only asserts `bm.create_mlflow_span is real_factory` and then checks the registered span.
- **Gap:** The import-identity assertion plus the resulting `LiveSpan` observation cannot distinguish a correct `on_start` that calls the factory from an incorrect one that imports the factory but constructs `LiveSpan` inline. The required CALL edge has no observer.
- **Rework:** Patch `mlflow.tracing.processor.base_mlflow.create_mlflow_span` with a `Mock(wraps=real_factory)` or `Mock(return_value=...)`, call `on_start`, and assert the mock was called exactly once with `(otel_span, "tr-mapped")` and that its return value was passed to `register_span`.

### Finding 4
- **Type:** `weak_constraint`
- **Affected IDs:** C35, R44, E40, E41; static issue 5.
- **Static issue:** `_get_truncated_preview` used but not defined or imported in `mlflow/store/tracking/sqlalchemy_store.py`.
- **Repository source/test evidence:** `mlflow/store/tracking/sqlalchemy_store.py::_update_trace_info_attributes` calls `_get_truncated_preview`; arch_spec `check_sqlalchemy_update_calls_truncation_via_otel_span` only asserts `sql_store._get_truncated_preview is _get_truncated_preview` and then compares method output to helper output.
- **Gap:** The method could import the helper but compute previews inline and still pass. The required CALL edge from `_update_trace_info_attributes` to `_get_truncated_preview` is not observed.
- **Rework:** Patch `mlflow.store.tracking.sqlalchemy_store._get_truncated_preview` with a `Mock(wraps=...)` and assert it is called with `(raw_inputs, role="user")` and `(raw_outputs, role="assistant")`, or return distinct sentinels and assert those sentinels appear in the update dict.

### Finding 5
- **Type:** `weak_constraint`
- **Affected IDs:** C19, R42, E28.
- **Static issue:** none.
- **Repository source/test evidence:** `tests/tracing/utils/test_processor.py::test_apply_span_processors_returns_non_none_warning` asserts a warning whose message starts with `"Span processors ['bad_processor'] returned a non-null value"`; arch_spec `check_apply_span_processors_import_and_sequence` only asserts `logger.warning.called`.
- **Gap:** Because a failing processor is also configured, the failure warning alone makes `logger.warning.called` true. A wrong implementation that silently ignores non-null returns would pass.
- **Rework:** Split the check: with only a non-null-return processor configured, patch `_logger` and assert the exact non-null warning; with a failing processor followed by a good processor, assert the exact failure warning and the good processor's side effect. This adapts the repository test's exact message oracle.

### Finding 6
- **Type:** `weak_constraint`
- **Affected IDs:** C12, R11.
- **Static issue:** none.
- **Repository source/test evidence:** `tests/tracing/test_otel_loading.py::test_get_trace_for_otel_sent_span` asserts OTel UNSET maps to `SpanStatusCode.UNSET`; `::test_get_trace_with_otel_span_status` asserts OTel ERROR maps to `SpanStatusCode.ERROR`. Behavior spec `check_span_from_otel_proto_basic` only sets and asserts `STATUS_CODE_ERROR`.
- **Gap:** OK and UNSET proto status branches are unobserved. An implementation that maps every proto status to `ERROR` would pass the generated spec.
- **Rework:** Add parametrized `Span.from_otel_proto` cases for `STATUS_CODE_OK` and `STATUS_CODE_UNSET` and assert `SpanStatusCode.OK` and `SpanStatusCode.UNSET`, preserving description where applicable.

### Finding 7
- **Type:** `weak_constraint`
- **Affected IDs:** C14, R12, E23, E24.
- **Static issue:** none.
- **Repository source/test evidence:** Interface Description 2 states the parent relation is set "if applicable"; C14 acceptance states a root span omits `parent_span_id`. Behavior spec `check_span_to_otel_proto_export` only constructs a span with a parent and asserts its parent bytes.
- **Gap:** No root-span case. An implementation that always writes some parent bytes for root spans would pass.
- **Rework:** Add a root-span `to_otel_proto` case and assert `proto_span.parent_span_id == b""` (the protobuf default for an unset bytes field) or otherwise assert no parent bytes are populated.

### Finding 8
- **Type:** `weak_constraint`
- **Affected IDs:** C24, R32, E32.
- **Static issue:** none.
- **Repository source/test evidence:** Interface Description 2 states `span_type=None` should result in `SpanType.UNKNOWN` for live spans. Arch spec `check_create_mlflow_span_dispatch_control_flow` only calls the factory with explicit `"LLM"`.
- **Gap:** The omitted-argument/default path is unobserved. A factory that passes `None` explicitly into `LiveSpan` rather than relying on the constructor default would store `None` instead of `"UNKNOWN"` and still pass.
- **Rework:** Add a live-span factory call with no `span_type` argument and assert `get_attribute(SpanAttributeKey.SPAN_TYPE) == SpanType.UNKNOWN`.

## Decision

`Decision: REWORK`
