"""
Architecture spec for the MLflow distributed tracing span IR.

This file checks public scope, import/dependency binding, graph connectivity,
real CALL/CONTROL paths, and dataflow. It does not modify production code and
does not execute repository tests. Each check is a no-argument callable and
prints PASS on success. The process exits nonzero when any check fails.
"""

import base64
import os
import sys
import threading
from contextlib import contextmanager
from threading import Thread
from unittest.mock import Mock, call, patch

REPO = "/testbed"
if REPO not in sys.path:
    sys.path.insert(0, REPO)

from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import Event as OTelEvent
from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
from opentelemetry.trace import NonRecordingSpan
from opentelemetry.trace import Status as OTelStatus
from opentelemetry.trace import StatusCode as OTelStatusCode

from mlflow.entities import LiveSpan, Span, Trace, TraceInfo
from mlflow.entities.span_status import SpanStatus, SpanStatusCode
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.tracing.utils import (
    build_otel_context,
    dump_span_attribute_value,
    encode_span_id,
    generate_mlflow_trace_id_from_otel_trace_id,
)

from tests.tracing.helper import create_mock_otel_span


def make_trace_info(trace_id: str = "tr-1") -> TraceInfo:
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState

    return TraceInfo(
        trace_id=trace_id,
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        state=TraceState.OK,
    )


def make_otel_readable_span(
    name="root",
    trace_id=1,
    span_id=2,
    parent_id=None,
    start_time=100,
    end_time=200,
    attributes=None,
    events=None,
    status=None,
):
    return OTelReadableSpan(
        name=name,
        context=build_otel_context(trace_id, span_id),
        parent=build_otel_context(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        end_time=end_time,
        attributes=attributes or {},
        status=status or OTelStatus(OTelStatusCode.OK),
        resource=Resource.get_empty(),
        events=events or [],
    )


def make_live_span(trace_id="tr-1", span_id=1, parent_id=None, span_type=None):
    otel_span = create_mock_otel_span(
        trace_id=12345,
        span_id=span_id,
        parent_id=parent_id,
        name=f"span-{span_id}",
    )
    live_span = LiveSpan(
        otel_span,
        trace_id=trace_id,
        span_type=span_type if span_type is not None else "UNKNOWN",
    )
    return live_span, otel_span


@contextmanager
def raises(exc_type, error_code=None):
    try:
        yield
    except exc_type as exc:
        if error_code is not None:
            assert getattr(exc, "error_code", None) == error_code, (
                f"Expected error_code {error_code}, got {getattr(exc, 'error_code', None)}"
            )
    else:
        raise AssertionError(f"Expected {exc_type.__name__} to be raised")


# ---------------------------------------------------------------------------
# C1/R1/R15: _Trace.to_mlflow_trace must create TraceData, append immutable
# spans through LiveSpan.to_immutable_span, and leave the internal span_dict
# mutable. Repository test used as guidance:
# tests/tracing/test_trace_manager.py::test_add_spans.
# Perspective: lifecycle finalization and representation transition.
# Source path: mlflow/tracing/trace_manager.py::_Trace.to_mlflow_trace
# -> mlflow/entities/span.py::LiveSpan.to_immutable_span -> Span.__init__.
# ---------------------------------------------------------------------------
def check_trace_to_mlflow_trace_immutable_span_path():
    from mlflow.tracing.trace_manager import _Trace

    trace = _Trace(info=make_trace_info("tr-1"))
    root, root_otel = make_live_span("tr-1", span_id=1, parent_id=None)
    child, child_otel = make_live_span("tr-1", span_id=2, parent_id=1)
    trace.span_dict[root.span_id] = root
    trace.span_dict[child.span_id] = child

    result = trace.to_mlflow_trace()

    assert isinstance(result, Trace)
    assert len(result.data.spans) == 2
    assert all(isinstance(span, Span) and not isinstance(span, LiveSpan) for span in result.data.spans)
    assert all(isinstance(span, LiveSpan) for span in trace.span_dict.values())
    assert result.data.spans[0]._span is root_otel
    assert result.data.spans[1]._span is child_otel


# ---------------------------------------------------------------------------
# C26/R34: BaseMlflowSpanProcessor.on_start must bind the module-level
# create_mlflow_span import and call it through the real on_start call site.
# Static issue 4 is on-path and is closed by observing the CALL edge with a
# wrapping spy, not merely by import identity.
# Repository test used as guidance:
# tests/tracking/test_client.py (create_mlflow_span factory import usage).
# Perspective: caller binding and argument/dataflow into register_span.
# Source path: mlflow/tracing/processor/base_mlflow.py::on_start
# -> mlflow/entities/span.py::create_mlflow_span -> fake register_span observer.
# ---------------------------------------------------------------------------
def check_on_start_calls_imported_create_mlflow_span():
    import mlflow.tracing.processor.base_mlflow as bm
    from mlflow.entities.span import create_mlflow_span as real_factory

    # Import-boundary binding: the module must use the real factory object.
    assert bm.create_mlflow_span is real_factory

    class FakeTraceManager:
        def __init__(self):
            self.registered = []

        def get_mlflow_trace_id_from_otel_id(self, otel_trace_id):
            return "tr-mapped"

        def register_span(self, span):
            self.registered.append(span)

    fake_manager = FakeTraceManager()
    otel_span = create_mock_otel_span(trace_id=999, span_id=777, parent_id=1)

    class ConcreteProcessor(bm.BaseMlflowSpanProcessor):
        pass

    processor = object.__new__(ConcreteProcessor)
    processor._trace_manager = fake_manager

    with patch.object(bm, "create_mlflow_span", wraps=real_factory) as factory_mock:
        with patch.object(bm.InMemoryTraceManager, "get_instance", return_value=fake_manager):
            processor.on_start(otel_span, parent_context=None)

    assert factory_mock.call_args == call(otel_span, "tr-mapped")
    assert len(fake_manager.registered) == 1
    registered = fake_manager.registered[0]
    assert isinstance(registered, LiveSpan)
    assert registered._span is otel_span
    assert registered.get_attribute(SpanAttributeKey.REQUEST_ID) == "tr-mapped"


# ---------------------------------------------------------------------------
# C35/R43/R44: The SQLAlchemy store path must call _get_truncated_preview for
# translated root-span inputs/outputs. Static issue 5 is on-path and is closed
# by observing the CALL edge with a wrapping spy, not merely by import identity.
# The check starts at Span.from_otel_proto (OTLP entry), then goes through
# translate_span_when_storing into SqlAlchemyStore._update_trace_info_attributes.
# Repository test used as guidance: tests/tracing/test_otel_logging.py
# (OTLP endpoint to SQL store path); no direct unit test for this helper.
# Perspective: regression reach and caller binding.
# Source path: mlflow/entities/span.py::Span.from_otel_proto
# -> mlflow/tracing/otel/translation.py::translate_span_when_storing
# -> mlflow/store/tracking/sqlalchemy_store.py::_update_trace_info_attributes
# -> mlflow/tracing/utils/truncation.py::_get_truncated_preview.
# ---------------------------------------------------------------------------
def check_sqlalchemy_update_calls_truncation_via_otel_span():
    import mlflow.store.tracking.sqlalchemy_store as sql_store
    from mlflow.entities.span import Span
    from mlflow.store.tracking.dbmodels.models import SqlTraceInfo
    from mlflow.tracing.otel.translation import translate_span_when_storing
    from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue
    from mlflow.tracing.utils.truncation import _get_truncated_preview

    # Import boundary for static issue 5.
    assert sql_store._get_truncated_preview is _get_truncated_preview

    trace_id_int = 0x102030405060708090A0B0C0D0E0F10
    span_id_int = 0x0102030405060708
    proto_span = OTelProtoSpan()
    proto_span.trace_id = trace_id_int.to_bytes(16, byteorder="big", signed=False)
    proto_span.span_id = span_id_int.to_bytes(8, byteorder="big", signed=False)
    proto_span.name = "otel-root"
    proto_span.start_time_unix_nano = 100
    proto_span.end_time_unix_nano = 200
    proto_span.status.code = OTelProtoStatus.STATUS_CODE_OK

    in_attr = proto_span.attributes.add()
    in_attr.key = SpanAttributeKey.INPUTS
    _set_otel_proto_anyvalue(
        in_attr.value, {"messages": [{"role": "user", "content": "hello"}]}
    )
    out_attr = proto_span.attributes.add()
    out_attr.key = SpanAttributeKey.OUTPUTS
    _set_otel_proto_anyvalue(
        out_attr.value, {"messages": [{"role": "assistant", "content": "goodbye"}]}
    )

    # Prove the OTLP entry and then translate into the span dictionary used by
    # the SQLAlchemy store log_spans path.
    span = Span.from_otel_proto(proto_span)
    span_dict = translate_span_when_storing(span)

    sql_trace_info = SqlTraceInfo()
    sql_trace_info.request_preview = None
    sql_trace_info.response_preview = None

    store = object.__new__(sql_store.SqlAlchemyStore)
    raw_inputs = span_dict["attributes"][SpanAttributeKey.INPUTS]
    raw_outputs = span_dict["attributes"][SpanAttributeKey.OUTPUTS]

    with patch.object(
        sql_store, "_get_truncated_preview", wraps=_get_truncated_preview
    ) as truncate_mock:
        update_dict = store._update_trace_info_attributes(sql_trace_info, span_dict)

    assert truncate_mock.call_args_list == [
        call(raw_inputs, role="user"),
        call(raw_outputs, role="assistant"),
    ]
    assert update_dict[SqlTraceInfo.request_preview] == _get_truncated_preview(
        raw_inputs, role="user"
    )
    assert update_dict[SqlTraceInfo.response_preview] == _get_truncated_preview(
        raw_outputs, role="assistant"
    )


# ---------------------------------------------------------------------------
# C19/R42: apply_span_processors must be importable and apply configured
# processors sequentially, tolerate failures, and warn on non-null returns.
# The previous combined check could pass on the failure warning alone; these
# cases now separately observe the non-null-return warning and the
# failure-then-continue sequence with exact warning oracles.
# Repository test used as guidance:
# tests/tracing/utils/test_processor.py::test_apply_span_processors_*.
# Perspective: helper import boundary, ordered side effects, exact warnings.
# Source path: mlflow/tracing/utils/processor.py::apply_span_processors.
# ---------------------------------------------------------------------------
def check_apply_span_processors_import_and_sequence():
    import mlflow
    from mlflow.tracing.utils.processor import apply_span_processors

    # Case 1: a non-null return must produce the repository-tested warning.
    def bad_return(span):
        return "ignored"

    with mlflow.tracing.configure(span_processors=[bad_return]):
        with patch("mlflow.tracing.utils.processor._logger") as logger:
            apply_span_processors(Mock())

    assert logger.warning.called
    warning_message = logger.warning.call_args.args[0]
    assert warning_message.startswith("Span processors ['bad_return'] returned a non-null value")

    # Case 2: a failing processor is logged and later processors still run.
    order = []

    def first_fail(span):
        order.append("first_fail")
        raise ValueError("boom")

    def second_good(span):
        order.append("second_good")
        span.set_outputs("processed")

    with mlflow.tracing.configure(span_processors=[first_fail, second_good]):
        with patch("mlflow.tracing.utils.processor._logger") as logger:
            apply_span_processors(Mock())

    assert order == ["first_fail", "second_good"]
    failure_warning = logger.warning.call_args.args[0]
    assert failure_warning.startswith("Span processor first_fail failed: boom")


# ---------------------------------------------------------------------------
# NEW C37/R46: InMemoryTraceManager must not lose spans under concurrent
# registration and pop_trace. Repository test used as guidance:
# tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety.
# Perspective: thread-safe in-memory trace management and cardinality.
# Source path: mlflow/tracing/trace_manager.py::InMemoryTraceManager.register_span
# -> pop_trace -> _Trace.to_mlflow_trace.
# ---------------------------------------------------------------------------
def check_trace_manager_concurrent_register_pop_no_lost_spans():
    from mlflow.tracing.trace_manager import InMemoryTraceManager

    with patch.dict(
        os.environ,
        {
            "MLFLOW_TRACE_TIMEOUT_SECONDS": "0",
            "MLFLOW_TRACE_BUFFER_TTL_SECONDS": "3600",
            "MLFLOW_TRACE_BUFFER_MAX_SIZE": "1000",
        },
    ), patch(
        "mlflow.tracing.trace_manager.MLFLOW_TRACE_TIMEOUT_SECONDS.get",
        return_value=None,
    ):
        manager = InMemoryTraceManager()
        trace_ids = list(range(5))
        num_threads = 10

        for trace_id in trace_ids:
            manager.register_trace(trace_id, make_trace_info(f"tr-{trace_id}"))

        def add_spans(thread_id):
            for trace_id in trace_ids:
                live_span, _ = make_live_span(
                    f"tr-{trace_id}", span_id=thread_id, parent_id=None
                )
                manager.register_span(live_span)

        threads = [Thread(target=add_spans, args=(thread_id,)) for thread_id in range(num_threads)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        expected_span_ids = {encode_span_id(thread_id) for thread_id in range(num_threads)}
        for trace_id in trace_ids:
            manager_trace = manager.pop_trace(trace_id)
            assert manager_trace is not None
            assert manager_trace.trace.info.request_id == f"tr-{trace_id}"
            assert len(manager_trace.trace.data.spans) == num_threads
            assert {span.span_id for span in manager_trace.trace.data.spans} == expected_span_ids


# ---------------------------------------------------------------------------
# C24/R32: create_mlflow_span dispatch control flow by OTel span type.
# Repository test used as guidance: tests/tracking/test_client.py imports the
# factory for OTelReadableSpan conversion.
# Perspective: factory dispatch and argument/result dataflow, including the
# default span_type=None -> SpanType.UNKNOWN path required by Interface
# Description 2.
# Source path: mlflow/entities/span.py::create_mlflow_span.
# ---------------------------------------------------------------------------
def check_create_mlflow_span_dispatch_control_flow():
    from mlflow.entities.span import NoOpSpan, SpanType, create_mlflow_span

    live_otel = create_mock_otel_span(trace_id=10, span_id=20, parent_id=None)
    live = create_mlflow_span(live_otel, "tr-live", "LLM")
    assert isinstance(live, LiveSpan)
    assert live.get_attribute(SpanAttributeKey.REQUEST_ID) == "tr-live"
    assert live.get_attribute(SpanAttributeKey.SPAN_TYPE) == "LLM"

    default_live_otel = create_mock_otel_span(trace_id=11, span_id=21, parent_id=None)
    default_live = create_mlflow_span(default_live_otel, "tr-default-live")
    assert isinstance(default_live, LiveSpan)
    assert default_live.get_attribute(SpanAttributeKey.SPAN_TYPE) == SpanType.UNKNOWN

    immutable_otel = make_otel_readable_span(
        name="finished",
        trace_id=3,
        span_id=4,
        attributes={
            SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-immutable"),
        },
    )
    immutable = create_mlflow_span(immutable_otel, "ignored-trace-id")
    assert isinstance(immutable, Span)
    assert not isinstance(immutable, LiveSpan)

    assert isinstance(create_mlflow_span(None, "tr-none"), NoOpSpan)
    assert isinstance(
        create_mlflow_span(NonRecordingSpan(context=None), "tr-nonrecording"), NoOpSpan
    )


# ---------------------------------------------------------------------------
# C29/R37: _otel_proto_bytes_to_id is the protobuf ID bytes-to-integer dataflow
# helper used by Span.from_otel_proto.
# Repository test used as guidance: none direct; task OTLP conversion.
# Perspective: exact representation preservation.
# Source path: mlflow/tracing/utils/otlp.py::_otel_proto_bytes_to_id.
# ---------------------------------------------------------------------------
def check_otel_proto_bytes_to_id_dataflow():
    from mlflow.tracing.utils.otlp import _otel_proto_bytes_to_id

    value = 0x0102030405060708
    assert _otel_proto_bytes_to_id(value.to_bytes(8, "big")) == value


# ---------------------------------------------------------------------------
# C30/R4/R38: _SpanAttributesRegistry.get_all must aggregate every OTel
# attribute through get() and deserialize JSON values.
# Repository test used as guidance: tests/tracing/opentelemetry/test_integration.py
# exercises span attributes through real spans.
# Perspective: registry aggregation and raw-string fallback.
# Source path: mlflow/entities/span.py::_SpanAttributesRegistry.get_all -> get.
# ---------------------------------------------------------------------------
def check_span_registry_get_all_delegation():
    from mlflow.entities.span import _SpanAttributesRegistry

    otel_span = create_mock_otel_span(trace_id=1, span_id=2)
    registry = _SpanAttributesRegistry(otel_span)
    registry.set("json_attr", {"x": 1})
    otel_span.set_attribute("raw_attr", "not-json")

    assert registry.get_all() == {"json_attr": {"x": 1}, "raw_attr": "not-json"}
    assert registry.get("raw_attr") == "not-json"


# ---------------------------------------------------------------------------
# C31/R40: base64 detection and decoding helpers used by Span.from_dict.
# Static issues 1 and 2 are on-path and are also closed through the full
# from_dict round-trip check in behavior_spec.py.
# Repository test used as guidance: none direct; Interface Description 2
# encoding notes.
# Perspective: exact detection/decode semantics.
# Source path: mlflow/entities/span.py::_is_base64_encoded/_decode_id_from_byte.
# ---------------------------------------------------------------------------
def check_base64_helpers_import_binding():
    from mlflow.entities.span import _decode_id_from_byte, _is_base64_encoded

    encoded_span = base64.b64encode((12345).to_bytes(8, "big")).decode("utf-8")
    assert _is_base64_encoded(encoded_span) is True
    assert _decode_id_from_byte(encoded_span) == 12345
    assert _is_base64_encoded("not base64 !!!") is False


# ---------------------------------------------------------------------------
# C32/R41: v2 schema detection and conversion helpers used by Span.from_dict.
# Repository test used as guidance: tests/tracing/test_fluent.py remote trace
# loading exercises v2 compatibility.
# Perspective: schema dispatch and v2 representation preservation.
# Source path: mlflow/entities/span.py::Span._is_span_v2_schema/from_dict_v2.
# ---------------------------------------------------------------------------
def check_span_v2_schema_helper_dispatch():
    from mlflow.entities.span import Span

    data = {"context": {"trace_id": "abc", "span_id": "def"}}
    assert Span._is_span_v2_schema(data) is True
    assert Span._is_span_v2_schema({"trace_id": "abc"}) is False

    v2_span = Span.from_dict_v2(
        {
            "context": {"trace_id": "abc", "span_id": "def"},
            "parent_id": "123",
            "name": "v2-span",
            "start_time": 100,
            "end_time": 200,
            "attributes": {
                SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-v2"),
                SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("CHAIN"),
            },
            "status_code": "OK",
            "status_message": "",
            "events": [],
        }
    )
    assert isinstance(v2_span, Span)
    assert v2_span.trace_id == "tr-v2"
    assert v2_span.span_type == "CHAIN"
    assert v2_span.status.status_code == SpanStatusCode.OK


def _all_checks():
    return [
        check_trace_to_mlflow_trace_immutable_span_path,
        check_on_start_calls_imported_create_mlflow_span,
        check_sqlalchemy_update_calls_truncation_via_otel_span,
        check_apply_span_processors_import_and_sequence,
        check_trace_manager_concurrent_register_pop_no_lost_spans,
        check_create_mlflow_span_dispatch_control_flow,
        check_otel_proto_bytes_to_id_dataflow,
        check_span_registry_get_all_delegation,
        check_base64_helpers_import_binding,
        check_span_v2_schema_helper_dispatch,
    ]


if __name__ == "__main__":
    import traceback

    failed = 0
    for check in _all_checks():
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as exc:
            failed += 1
            print(f"FAIL: {check.__name__}: {type(exc).__name__}: {exc}")
            traceback.print_exc()
    if failed:
        sys.exit(1)
