# Semantic IR

Repository: `/testbed`
Artifact scope: compile the task and repository evidence for the MLflow GenAI
scorer validation interfaces. The generic "MLflow Data Validation System" task
statement is narrowed by the three Interface Descriptions to the following
task-required public entries:

- `/testbed/mlflow/genai/scorers/base.py`: `scorer`
- `/testbed/mlflow/genai/scorers/validation.py`: `valid_data_for_builtin_scorers`
- `/testbed/mlflow/genai/scorers/validation.py`: `validate_scorers`
- `/testbed/mlflow/genai/scorers/builtin_scorers.py`: `get_all_scorers`

Reference implementations exist under `/testbed/libs/skinny/...` and
`/testbed/libs/tracing/...` and are treated as repository evidence only. The
target files under `/testbed/mlflow/...` are currently incomplete: `scorer`
references an undefined local `CustomScorer`; `validation.py` defines only
`validate_aggregations`; `builtin_scorers.py` has no `get_all_scorers`;
`evaluation/base.py` and `optimize/util.py` call validation helpers without
importing them.

Static analysis also lists `not_empty`, `exact_match`, `num_tool_calls`, and
`harmfulness` as "declared interfaces". Those are docstring examples inside
`scorer`, not module-level callable symbols; no executable requirement is
derived for them beyond preserving the `scorer` docstring behavior.

## L1. Requirement Obligations

### R1: `scorer` supports no-parentheses decorator usage
- **Type**: Interface / compatibility
- **Statement**: When `scorer` is called with `func=None`, it must return a
  `functools.partial` bound to `scorer` with the supplied keyword-only
  `name`, `description`, and `aggregations`, so both `@scorer` and
  `@scorer(name="x")` work.
- **Task Evidence**: Interface Description 1 shows `@scorer` and args
  `name`, `description`, `aggregations`.
- **Acceptance**: `scorer(name="x")` returns `functools.partial`; applying it
  to a function returns a scorer named `"x"`.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/base.py:847-997` implements the `func is None`
    partial branch but is followed by the broken `CustomScorer` branch.
  - `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1006` has the
    complete local-class implementation.
- **Uncertainty**: None.

### R2: `scorer` must construct a local decorator scorer class
- **Type**: Dataflow / state
- **Statement**: For a real decorated function, `scorer` must define or
  otherwise construct a `Scorer` subclass named `CustomScorer` that stores the
  original function as `_original_func`, delegates `__call__` to that function,
  and reports `kind == ScorerKind.DECORATOR`.
- **Task Evidence**: Interface Description 1 requires custom scorer instances
  callable in evaluation and states the function name determines metric name.
- **Acceptance**: A decorated function returns a `Scorer` instance whose
  `kind` is `DECORATOR`, whose `_original_func` is the original function, and
  whose `__call__` executes the original function.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/base.py:1025-1031` uses `CustomScorer`
    without defining it (static issue).
  - `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1031` defines the
    local `CustomScorer(Scorer)` with `_original_func` and `kind`.
  - `/testbed/mlflow/genai/scorers/base.py:524-527` shows `Scorer.kind`
    property default is `ScorerKind.CLASS`.
- **Uncertainty**: The target file currently has a large blank region where the
  local class belongs; implementation must restore it, not just import a name.

### R3: decorator scorer exposes the original function's signature
- **Type**: Interface / runtime dispatch
- **Statement**: `scorer` must inspect the decorated function signature and
  replace `CustomScorer.__call__.__signature__` with `("self", *original
  params)` so `Scorer.run` can filter evaluator row fields to the function's
  declared parameters.
- **Task Evidence**: Interface Description 1 says scorer may take a subset of
  `inputs`, `outputs`, `expectations`, `trace`.
- **Acceptance**: For `@scorer def f(outputs, trace): ...`,
  `inspect.signature(f.__call__)` exposes `self`, `outputs`, `trace`.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/base.py:1018-1025`.
  - `/testbed/mlflow/genai/scorers/base.py:374-384` filters row fields using
    `inspect.signature(self.__call__)`.
  - `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1020-1025`.
- **Uncertainty**: None.

### R4: decorator scorer preserves name, description, and aggregations
- **Type**: Dataflow / representation
- **Statement**: The constructed scorer must pass
  `name=name or func.__name__`, `description=description`, and
  `aggregations=aggregations` to `CustomScorer`.
- **Task Evidence**: Interface Description 1 documents these args and metric
  naming by function name or custom name.
- **Acceptance**: `@scorer` over a function named `my_scorer` has name
  `"my_scorer"`; `@scorer(name="x", description="d", aggregations=["mean"])`
  preserves all fields.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py:1027-1031`;
  `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1027-1031`.
- **Uncertainty**: No validation of `aggregations` occurs inside `scorer` in
  the reference; the existing `validate_aggregations` helper is separate.

### R5: decorator scorer run filters fields and validates return values
- **Type**: Behavior / failure
- **Statement**: `Scorer.run` invoked on a decorated scorer must pass only the
  subset of `inputs`, `outputs`, `expectations`, `trace` present in the
  original signature, execute the original function, and accept only
  `int|float|bool|str|Feedback|list[Feedback]|None` as a result; invalid
  results raise `MlflowException.invalid_parameter_value`.
- **Task Evidence**: Interface Description 1 lists allowed return types.
- **Acceptance**: A scorer `def f(outputs): return outputs != ""` receives no
  `inputs`/`expectations`/`trace` arguments when `run` is called with all row
  fields; a scorer returning a dict raises `MlflowException`.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/base.py:374-427` (`Scorer.run`).
  - `/testbed/tests/genai/scorers/test_scorer.py:233-267` tests accepted
    primitive, Feedback, and list-of-Feedback returns.
  - `/testbed/tests/genai/scorers/test_scorer.py:268-274` tests `None` return.
- **Uncertainty**: The `Assessment`/legacy assessment compatibility in `run`
  is existing behavior; not separately task-required.

### R6: `validate_scorers` enforces list shape and permits empty list
- **Type**: Interface / failure
- **Statement**: `validate_scorers(scorers)` must raise
  `MlflowException.invalid_parameter_value` when `scorers` is not a list, and
  must return `[]` when the list is empty.
- **Task Evidence**: Interface Description 2 says empty lists are valid and
  non-list input raises.
- **Acceptance**: `validate_scorers([]) == []`; `validate_scorers(Correctness())`
  raises with a message about the `scorers` argument being a list.
- **Repository Evidence**:
  - `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-43`.
- **Uncertainty**: The exact message text is inferred from the reference
  implementation, not explicitly fixed by the interface.

### R7: `validate_scorers` passes through valid `Scorer` instances
- **Type**: Dataflow / identity
- **Statement**: Each item that is already an instance of
  `mlflow.genai.scorers.base.Scorer` must be appended to the returned list in
  input order and without copying.
- **Task Evidence**: Interface Description 2 condition 1.
- **Acceptance**: For `s = Scorer(name="x")`,
  `validate_scorers([s])[0] is s`.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/base.py:111` (`class Scorer`).
  - `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:44-46`.
- **Uncertainty**: BuiltInScorer subclasses are also `Scorer` and follow the
  same branch.

### R8: legacy databricks metrics are conditionally accepted
- **Type**: Compatibility / state
- **Statement**: When `databricks.agents` is installed, a legacy
  `databricks.rag_eval.evaluation.metrics.Metric` item is accepted and appended;
  a deprecation warning listing legacy metric names is logged. When
  `databricks.agents` is absent, such items are invalid.
- **Task Evidence**: Interface Description 2 condition 2 and notes.
- **Acceptance**: With `IS_DBX_AGENTS_INSTALLED` true and a stub `Metric`
  instance, the item is returned and a warning is logged; with the flag false,
  an invalid-item exception is raised.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/validation.py:23` computes
    `IS_DBX_AGENTS_INSTALLED`.
  - `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:23,48-57,76-82`.
- **Uncertainty**: The `databricks.agents` package is optional and may not be
  importable in the test environment; tests must monkeypatch the module flag.

### R9: `validate_scorers` reports common mistakes with hints
- **Type**: Failure / diagnostics
- **Statement**: Invalid items must raise
  `MlflowException.invalid_parameter_value` with context-aware hints for:
  (1) `scorers=[get_all_scorers()]`; (2)
  `scorers=[get_all_scorers(), s1, s2]`; (3) builtin scorer classes passed
  instead of instances; and (4) any other invalid object type.
- **Task Evidence**: Interface Description 2 raises and hint bullets.
- **Acceptance**: Each invalid shape raises an exception whose text includes
  the corresponding hint or the invalid type name.
- **Repository Evidence**:
  - `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:48-76`.
- **Uncertainty**: Exact punctuation of hints is implementation-defined, but
  the discriminator phrases (`Use \`scorers=get_all_scorers()\``, `passed a
  scorer class instead of an instance`) are evidence-backed.

### R10: `valid_data_for_builtin_scorers` normalizes legacy column names and synthesized columns
- **Type**: Dataflow / compatibility
- **Statement**: The function must start from `data.columns`, rename `request`
  to `inputs` and `response` to `outputs`; if `predict_fn` is provided, add
  `outputs`; if `trace` is present, add `inputs` and `outputs`; and when
  `predict_fn` is provided also add `trace`.
- **Task Evidence**: Interface Description 2 notes column mapping, predict_fn,
  and trace inference.
- **Acceptance**: A spy builtin scorer observes the resulting column set in
  `validate_columns` matching the above rules.
- **Repository Evidence**:
  - `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101-128`.
  - `/testbed/mlflow/genai/evaluation/utils.py:104-127` performs the
    upstream `inputs->request`, `outputs->response` conversion.
- **Uncertainty**: None.

### R11: `valid_data_for_builtin_scorers` explodes `expectations` and rejects non-dict values
- **Type**: Dataflow / failure
- **Statement**: When an `expectations` column exists, each non-null value must
  be a dictionary; dictionary keys become `expectations/<key>` columns in the
  validation column set. Non-dictionary values raise
  `MlflowException.invalid_parameter_value`.
- **Task Evidence**: Interface Description 2 notes and raises section.
- **Acceptance**: A DataFrame with
  `{"expectations": [{"expected_response": "Paris"}]}` adds
  `expectations/expected_response`; a DataFrame with
  `{"expectations": ["Paris"]}` raises.
- **Repository Evidence**:
  - `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:130-140`.
  - `/testbed/mlflow/genai/scorers/builtin_scorers.py:324-328` base
    `validate_columns` compares `required_columns - columns`.
- **Uncertainty**: `pd.isna(value)` is used to skip nulls; non-pandas
  environments are not required.

### R12: missing builtin columns are logged without raising
- **Type**: Behavior / side effect
- **Statement**: For each builtin scorer, call `scorer.validate_columns`; catch
  `MissingColumnsException`; aggregate missing columns by scorer name; log an
  informational message showing each missing column and the scorers requiring
  it; return `None`.
- **Task Evidence**: Interface Description 2 says logging occurs and evaluation
  continues with null results.
- **Acceptance**: With a builtin scorer requiring `outputs`, a DataFrame lacking
  `outputs` produces no exception, returns `None`, and logs a message containing
  `outputs` and the scorer name.
- **Repository Evidence**:
  - `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:142-166`.
  - `/testbed/mlflow/genai/scorers/builtin_scorers.py:324-328`.
- **Uncertainty**: Logging target is `_logger.info`; exact formatting is not
  fixed by the interface.

### R13: `get_all_scorers` returns the correct OSS and Databricks scorer sets
- **Type**: Interface / compatibility
- **Statement**: The function must return a list of built-in scorer instances
  containing `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`,
  `RetrievalSufficiency`, `RetrievalGroundedness`, and `Equivalence`. When the
  tracking URI is Databricks, it must also include `Safety` and
  `RetrievalRelevance`.
- **Task Evidence**: Interface Description 3.
- **Acceptance**: With a non-Databricks tracking URI the list has length 6 and
  all items are `Scorer`; with a Databricks URI it has length 8 and includes
  `Safety` and `RetrievalRelevance`.
- **Repository Evidence**:
  - `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1582`.
  - `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-577`.
- **Uncertainty**: The exact order is fixed by the reference list order; tests
  may assert length/instance membership rather than order.

### R14: caller modules bind the validation helpers
- **Type**: Dependency / compatibility
- **Statement**: `/testbed/mlflow/genai/evaluation/base.py` must bind
  `validate_scorers` and `valid_data_for_builtin_scorers`, and
  `/testbed/mlflow/genai/optimize/util.py` must bind
  `valid_data_for_builtin_scorers`, from
  `mlflow.genai.scorers.validation` so the existing call sites execute without
  `NameError`.
- **Task Evidence**: Static issues identify both names used without
  definition/import; Interface Descriptions 2 makes the symbols public.
- **Acceptance**: Executing `mlflow.genai.evaluate` reaches both validation
  calls; executing `validate_train_data` reaches
  `valid_data_for_builtin_scorers`.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/evaluation/base.py:243,248` (call sites, no import).
  - `/testbed/mlflow/genai/optimize/util.py:91` (call site, no import).
  - `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21` and
    `/testbed/libs/skinny/mlflow/genai/optimize/util.py:11` (reference imports).
  - `/testbed/tests/genai/optimize/test_util.py:195-221` exercises
    `validate_train_data`.
- **Uncertainty**: `optimize_prompts` is not named in the Interface
  Descriptions, but the static-issue call site is directly exercised by the
  repository test above and is kept as a compatibility contract.

### R15: `get_all_scorers` remains available through the package boundary
- **Type**: Interface / import boundary
- **Statement**: `mlflow.genai.scorers.__getattr__` must lazily expose
  `get_all_scorers` from `mlflow.genai.scorers.builtin_scorers`.
- **Task Evidence**: Interface Description 3 and the scorer-import conventions
  in the examples use `from mlflow.genai.scorers import get_all_scorers`.
- **Acceptance**: `from mlflow.genai.scorers import get_all_scorers` resolves
  and calling it returns the same list as the module function.
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/__init__.py:36,67,93` includes
    `get_all_scorers` in `_LAZY_IMPORTS` and `__all__`.
- **Uncertainty**: None.

## L2. Functional Design Graph

### N1: `scorer` public factory
- **Kind**: Public entry / function
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py:847-1031`.

### N2: `CustomScorer` local scorer class
- **Kind**: Class / state holder
- **Repository Evidence**:
  - Static issue: `/testbed/mlflow/genai/scorers/base.py:1025,1027`.
  - Reference: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1027`.

### N3: `Scorer.run`
- **Kind**: Method / behavior
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py:374-427`.

### N4: `validate_scorers`
- **Kind**: Public entry / function
- **Repository Evidence**:
  - Interface target `/testbed/mlflow/genai/scorers/validation.py` (currently
    only imports and `validate_aggregations`; target function absent).
  - Reference: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-82`.

### N5: `valid_data_for_builtin_scorers`
- **Kind**: Public entry / function
- **Repository Evidence**:
  - Interface target `/testbed/mlflow/genai/scorers/validation.py` (absent).
  - Reference: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101-166`.

### N6: `get_all_scorers`
- **Kind**: Public entry / function
- **Repository Evidence**:
  - Interface target `/testbed/mlflow/genai/scorers/builtin_scorers.py` (absent).
  - Reference: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1582`.

### N7: `BuiltInScorer.validate_columns`
- **Kind**: Helper / behavior
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py:324-328`.

### N8: `MissingColumnsException`
- **Kind**: Error state
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py:1584-1590`.

### N9: `mlflow.genai.evaluation.base.evaluate`
- **Kind**: Public caller
- **Repository Evidence**: `/testbed/mlflow/genai/evaluation/base.py:51-262`;
  exported via `/testbed/mlflow/genai/evaluation/__init__.py` and
  `/testbed/mlflow/genai/__init__.py:14,47`.

### N10: `mlflow.genai.optimize.util.validate_train_data`
- **Kind**: Helper / downstream caller
- **Repository Evidence**: `/testbed/mlflow/genai/optimize/util.py:70-92`;
  caller `/testbed/mlflow/genai/optimize/optimize.py:180`.

### N11: `mlflow.genai.scorers` lazy package boundary
- **Kind**: Import boundary
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/__init__.py:29-93`.

### N12: legacy `databricks.rag_eval.evaluation.metrics.Metric`
- **Kind**: External compatibility boundary
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/validation.py:23`.
  - Reference: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:49-57`.

### N13: legacy evaluation DataFrame column state
- **Kind**: Data state
- **Repository Evidence**: `/testbed/mlflow/genai/evaluation/utils.py:104-127`.

### N14: Databricks tracking URI condition
- **Kind**: State / branch
- **Repository Evidence**:
  - `/testbed/mlflow/genai/scorers/builtin_scorers.py` imports
    `is_databricks_uri`.
  - Reference: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1580-1581`.

### E1: N1 -> N2
- **Kind**: CALL / STATE
- **Condition**: `func is not None`
- **Transfer**: Defines and instantiates `CustomScorer`; sets
  `_original_func = func`, `kind = DECORATOR`, and assigns name/description/
  aggregations.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:1025-1031`;
  `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1031`.
- **Obligations**: R2, R4.

### E2: N2 -> N3
- **Kind**: CALL
- **Condition**: Evaluator invokes `decorated_scorer.run(...)`
- **Transfer**: `run` filters evaluator row fields by
  `inspect.signature(self.__call__)` and invokes `self(**filtered)`; the local
  `CustomScorer.__call__` delegates to `_original_func`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:374-384`;
  `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1006-1012`.
- **Obligations**: R3, R5.

### E3: N9 -> N4
- **Kind**: CALL
- **Condition**: `evaluate` starts after the `scorers` argument is received.
- **Transfer**: `scorers = validate_scorers(scorers)`.
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py:243`.
- **Obligations**: R14.

### E4: N9 -> N5
- **Kind**: CALL
- **Condition**: `builtin_scorers` is filtered from validated scorers.
- **Transfer**: `valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)`.
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py:247-248`.
- **Obligations**: R14.

### E5: N10 -> N5
- **Kind**: CALL
- **Condition**: `validate_train_data` has checked `inputs` records and filtered
  builtin scorers.
- **Transfer**: `valid_data_for_builtin_scorers(train_data, builtin_scorers,
  predict_fn)`.
- **Evidence**: `/testbed/mlflow/genai/optimize/util.py:89-91`.
- **Obligations**: R14.

### E6: N4 -> N6
- **Kind**: CALL
- **Condition**: An invalid scorer item is a list equal to
  `get_all_scorers()`.
- **Transfer**: Calls `get_all_scorers()` to construct a nested-list hint.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:62-75`.
- **Obligations**: R9, R13, R15.

### E7: N5 -> N7
- **Kind**: CALL
- **Condition**: For each scorer in `builtin_scorers`.
- **Transfer**: Passes the normalized column set to `scorer.validate_columns`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:144-148`.
- **Obligations**: R10, R11, R12.

### E8: N7 -> N8
- **Kind**: CONTROL
- **Condition**: `self.required_columns - columns` is non-empty.
- **Transfer**: Raises `MissingColumnsException(scorer.name, missing_columns)`.
- **Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py:324-328`.
- **Obligations**: R12.

### E9: N5 -> N8
- **Kind**: CONTROL
- **Condition**: `scorer.validate_columns` raises `MissingColumnsException`.
- **Transfer**: Catches the exception and aggregates missing columns for
  logging.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:146-150`.
- **Obligations**: R12.

### E10: N5 -> N13
- **Kind**: DATA / STATE
- **Condition**: `valid_data_for_builtin_scorers` receives a legacy schema
  DataFrame.
- **Transfer**: Renames `request->inputs`, `response->outputs`, and expands
  `expectations` keys into `expectations/<key>`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101-140`.
- **Obligations**: R10, R11.

### E11: N6 -> N14
- **Kind**: CONTROL
- **Condition**: After building the six OSS scorers.
- **Transfer**: If `is_databricks_uri(mlflow.get_tracking_uri())` is true,
  extends the list with `Safety()` and `RetrievalRelevance()`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1579-1582`.
- **Obligations**: R13.

### E12: N11 -> N6
- **Kind**: CALL
- **Condition**: Attribute access `mlflow.genai.scorers.get_all_scorers`.
- **Transfer**: `__getattr__` imports `mlflow.genai.scorers.builtin_scorers`
  and returns `getattr(builtin_scorers, "get_all_scorers")`.
- **Evidence**: `/testbed/mlflow/genai/scorers/__init__.py:36,57-67`.
- **Obligations**: R15.

### E13: N4 -> N12
- **Kind**: CALL
- **Condition**: `IS_DBX_AGENTS_INSTALLED` is true and an invalid-by-Scorer item
  is encountered.
- **Transfer**: Imports `Metric` and checks `isinstance(scorer, Metric)` before
  deciding acceptance versus invalid-item error.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:48-57`.
- **Obligations**: R8.

## L3. Verifiable Contracts

### C1: `scorer(None)` returns a partial decorator
- **Type**: Interface / return value
- **Subject**: `mlflow.genai.scorers.base.scorer`
- **Relation**: `scorer(None, name="x", description="d", aggregations=["mean"])`
- **Expected**: Returns `functools.partial` whose `func` is `scorer` and whose
  keywords are `name="x"`, `description="d"`, `aggregations=["mean"]`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:994-997`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.base.scorer`
- **Obligations**: R1
- **Graph**: N1, E1

### C2: decorated scorer returns a `Scorer` with decorator state
- **Type**: State / return value
- **Subject**: `mlflow.genai.scorers.base.scorer`
- **Relation**: `s = scorer(lambda outputs: outputs != "")` (or `@scorer`
  equivalent)
- **Expected**: `s` is an instance of `Scorer`; `s.kind ==
  ScorerKind.DECORATOR`; `s._original_func is func`; `s.name == func.__name__`;
  `s.description` and `s.aggregations` match passed values.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1031`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.base.scorer`
- **Obligations**: R2, R4
- **Graph**: N1, N2, E1

### C3: decorator scorer signature is exposed on `__call__`
- **Type**: Interface / field read
- **Subject**: returned custom scorer instance
- **Relation**: `@scorer def f(inputs, outputs): ...`; read
  `inspect.signature(f.__call__)`
- **Expected**: Parameter names are `["self", "inputs", "outputs"]` in order.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:1018-1025`.
- **Observe**: FIELD_READ
- **Target**: `mlflow.genai.scorers.base.scorer` return value
- **Obligations**: R3
- **Graph**: N1, N2, E2

### C4: `Scorer.run` filters arguments and returns accepted primitive
- **Type**: Behavior / return value
- **Subject**: `Scorer.run` on a decorator scorer
- **Relation**: Define
  `@scorer def f(outputs): return outputs != ""`; call
  `f.run(inputs={"q": "x"}, outputs="answer", expectations={"e": 1}, trace=None)`.
- **Expected**: Original function is called with only `outputs="answer"` and the
  result is `True`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:374-384,398-413`;
  `/testbed/tests/genai/scorers/test_scorer.py:247-265`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.base.Scorer.run`
- **Obligations**: R3, R5
- **Graph**: N2, N3, E2

### C5: `Scorer.run` rejects invalid return type
- **Type**: Failure / exception
- **Subject**: `Scorer.run` on a decorator scorer
- **Relation**: `@scorer def f(outputs): return {"bad": object()}`; call
  `f.run(outputs="x")`
- **Expected**: Raises `MlflowException.invalid_parameter_value` with message
  containing "must return one of int, float, bool, str, Feedback, or
  list[Feedback]".
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:386-405`.
- **Observe**: EXCEPTION
- **Target**: `mlflow.genai.scorers.base.Scorer.run`
- **Obligations**: R5
- **Graph**: N2, N3, E2

### C6: `validate_scorers` rejects non-list input
- **Type**: Failure / exception
- **Subject**: `mlflow.genai.scorers.validation.validate_scorers`
- **Relation**: `validate_scorers(Scorer(name="x"))`
- **Expected**: Raises `MlflowException.invalid_parameter_value` containing
  "must be a list of scorers".
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:28-33`.
- **Observe**: EXCEPTION
- **Target**: `mlflow.genai.scorers.validation.validate_scorers`
- **Obligations**: R6
- **Graph**: N4

### C7: `validate_scorers` returns empty list unchanged
- **Type**: Behavior / return value
- **Subject**: `mlflow.genai.scorers.validation.validate_scorers`
- **Relation**: `validate_scorers([])`
- **Expected**: Returns `[]` and does not inspect `databricks.agents`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:35-37`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.validation.validate_scorers`
- **Obligations**: R6
- **Graph**: N4

### C8: `validate_scorers` preserves valid Scorer identity
- **Type**: Dataflow / return value
- **Subject**: `mlflow.genai.scorers.validation.validate_scorers`
- **Relation**: `s = Scorer(name="x"); out = validate_scorers([s])`
- **Expected**: `len(out) == 1` and `out[0] is s`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:44-46`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.validation.validate_scorers`
- **Obligations**: R7
- **Graph**: N4

### C9: legacy `Metric` is accepted only when installed
- **Type**: Compatibility / side effect
- **Subject**: `mlflow.genai.scorers.validation.validate_scorers`
- **Relation**: Monkeypatch `validation.IS_DBX_AGENTS_INSTALLED = True`; install
  a stub module `databricks.rag_eval.evaluation.metrics` in `sys.modules`
  exposing a `Metric` class; pass one `Metric` instance.
- **Expected**: The instance is appended to the returned list and
  `_logger.warning` is called with a message containing "legacy metrics".
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:48-57,76-82`.
- **Observe**: SIDE_EFFECT
- **Target**: `mlflow.genai.scorers.validation.validate_scorers`
- **Obligations**: R8
- **Graph**: N4, N12, E13

### C10: invalid scorer items produce helpful hints
- **Type**: Failure / exception
- **Subject**: `mlflow.genai.scorers.validation.validate_scorers`
- **Relation**: Call with `[get_all_scorers()]`, then with
  `[Correctness]`, then with `[object()]`.
- **Expected**: Each call raises `MlflowException.invalid_parameter_value`; the
  nested-list case contains "Use `scorers=get_all_scorers()`", the class case
  contains "class instead of an instance", and the object case contains the
  invalid type name.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:60-76`.
- **Observe**: EXCEPTION
- **Target**: `mlflow.genai.scorers.validation.validate_scorers`
- **Obligations**: R9
- **Graph**: N4, N6, E6

### C11: `valid_data_for_builtin_scorers` normalizes columns before validation
- **Type**: Dataflow / runtime argument trace
- **Subject**: `mlflow.genai.scorers.validation.valid_data_for_builtin_scorers`
- **Relation**: Build a spy object with `validate_columns(columns)` recording the
  set. Pass a DataFrame with columns `["request", "response", "trace"]`, a
  non-null `predict_fn`, and expectations `[{"expected_response": "Paris"}]`.
- **Expected**: `validate_columns` receives a set containing at least
  `inputs`, `outputs`, `trace`, and `expectations/expected_response`, and not
  containing `request` or `response`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101-148`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `mlflow.genai.scorers.validation.valid_data_for_builtin_scorers`
- **Obligations**: R10, R11
- **Graph**: N5, N7, N13, E7, E10

### C12: non-dict `expectations` raises
- **Type**: Failure / exception
- **Subject**: `mlflow.genai.scorers.validation.valid_data_for_builtin_scorers`
- **Relation**: Pass a DataFrame with column
  `expectations=["not-a-dict"]`.
- **Expected**: Raises `MlflowException.invalid_parameter_value` with message
  containing "must be a dictionary".
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:132-139`.
- **Observe**: EXCEPTION
- **Target**: `mlflow.genai.scorers.validation.valid_data_for_builtin_scorers`
- **Obligations**: R11
- **Graph**: N5, N13, E10

### C13: missing columns are logged and function returns `None`
- **Type**: Side effect / return value
- **Subject**: `mlflow.genai.scorers.validation.valid_data_for_builtin_scorers`
- **Relation**: Pass a DataFrame with only `inputs`, and a builtin scorer whose
  `required_columns` contains `outputs`.
- **Expected**: No exception; return value is `None`; `_logger.info` is called
  with a message containing `outputs` and the scorer name.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:150-166`.
- **Observe**: SIDE_EFFECT
- **Target**: `mlflow.genai.scorers.validation.valid_data_for_builtin_scorers`
- **Obligations**: R12
- **Graph**: N5, N7, N8, E7, E8, E9

### C14: `get_all_scorers` returns six scorers on OSS tracking URI
- **Type**: Return value / compatibility
- **Subject**: `mlflow.genai.scorers.builtin_scorers.get_all_scorers`
- **Relation**: Set tracking URI to `file://test` and call the function.
- **Expected**: Returns length 6; class names are
  `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`,
  `RetrievalSufficiency`, `RetrievalGroundedness`, `Equivalence`; every item is
  a `Scorer`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1582`;
  `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-577`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.builtin_scorers.get_all_scorers`
- **Obligations**: R13
- **Graph**: N6, N14, E11

### C15: `get_all_scorers` includes Databricks-only scorers
- **Type**: Return value / compatibility
- **Subject**: `mlflow.genai.scorers.builtin_scorers.get_all_scorers`
- **Relation**: Set tracking URI to a Databricks URI and call the function.
- **Expected**: Returns length 8 and includes instances of `Safety` and
  `RetrievalRelevance`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1580-1582`;
  `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-577`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers.builtin_scorers.get_all_scorers`
- **Obligations**: R13
- **Graph**: N6, N14, E11

### C16: `evaluate` reaches both validation calls
- **Type**: Runtime argument trace / dependency closure
- **Subject**: `mlflow.genai.evaluation.base.evaluate`
- **Relation**: Patch/spy `validate_scorers` and
  `valid_data_for_builtin_scorers`; call `mlflow.genai.evaluate` with a minimal
  valid dataset and one scorer; mock `_run_harness` to stop after validation.
- **Expected**: `validate_scorers` is called once with the scorers list, and
  `valid_data_for_builtin_scorers` is called once with the converted DataFrame,
  filtered builtin scorers, and `predict_fn`.
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py:243,248`;
  `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `mlflow.genai.evaluation.base.evaluate`
- **Obligations**: R14
- **Graph**: N9, N4, N5, E3, E4

### C17: `validate_train_data` reaches `valid_data_for_builtin_scorers`
- **Type**: Runtime argument trace / dependency closure
- **Subject**: `mlflow.genai.optimize.util.validate_train_data`
- **Relation**: Patch/spy `valid_data_for_builtin_scorers`; call
  `validate_train_data(pd.DataFrame([{"inputs": {"text": "hello"}}]), [],
  lambda **kwargs: None)`.
- **Expected**: The spy is called once with the DataFrame, an empty builtin
  scorer list, and the provided `predict_fn`.
- **Evidence**: `/testbed/mlflow/genai/optimize/util.py:89-91`;
  `/testbed/tests/genai/optimize/test_util.py:218-221`;
  `/testbed/libs/skinny/mlflow/genai/optimize/util.py:11`.
- **Observe**: RUNTIME_ARGUMENT_TRACE
- **Target**: `mlflow.genai.optimize.util.validate_train_data`
- **Obligations**: R14
- **Graph**: N10, N5, E5

### C18: package lazy export resolves `get_all_scorers`
- **Type**: Import boundary / return value
- **Subject**: `mlflow.genai.scorers.__getattr__`
- **Relation**: Execute
  `from mlflow.genai.scorers import get_all_scorers` and call it with an OSS
  tracking URI.
- **Expected**: Import succeeds; the callable is the same as
  `mlflow.genai.scorers.builtin_scorers.get_all_scorers`; the returned list has
  length 6.
- **Evidence**: `/testbed/mlflow/genai/scorers/__init__.py:36,57-67,93`.
- **Observe**: RETURN_VALUE
- **Target**: `mlflow.genai.scorers`
- **Obligations**: R15
- **Graph**: N11, N6, E12

## Static Issue Closure

- **`CustomScorer` in `/testbed/mlflow/genai/scorers/base.py`**
  - Call site: lines 1025 and 1027, enclosing unit `scorer`.
  - Upward trace: `scorer` is itself task-required public entry `P`.
  - Chain: `P scorer -> U scorer -> X CustomScorer`.
  - Disposition: ON-PATH. Recorded as E1, C2, C3.

- **`validate_scorers` in `/testbed/mlflow/genai/evaluation/base.py`**
  - Call site: line 243, enclosing unit `evaluate`.
  - Upward trace: `evaluate` is imported/exported by
    `/testbed/mlflow/genai/evaluation/__init__.py` and
    `/testbed/mlflow/genai/__init__.py`; `mlflow.genai.evaluate` is the public
    entry used throughout the task scorer example.
  - Chain: `P mlflow.genai.evaluate -> evaluate -> validate_scorers`.
  - Disposition: ON-PATH. Recorded as E3, C16.

- **`valid_data_for_builtin_scorers` in `/testbed/mlflow/genai/evaluation/base.py`**
  - Call site: line 248, enclosing unit `evaluate`.
  - Upward trace: same public chain as above.
  - Chain: `P mlflow.genai.evaluate -> evaluate ->
    valid_data_for_builtin_scorers`.
  - Disposition: ON-PATH. Recorded as E4, C16.

- **`valid_data_for_builtin_scorers` in `/testbed/mlflow/genai/optimize/util.py`**
  - Call site: line 91, enclosing unit `validate_train_data`.
  - Upward trace: `validate_train_data` is called by
    `optimize_prompts` (`/testbed/mlflow/genai/optimize/optimize.py:180`) and
    directly by `/testbed/tests/genai/optimize/test_util.py:195-221`.
    `optimize_prompts` is public in `mlflow.genai.__init__` but is not listed in
    the Interface Descriptions. The repository test provides a concrete,
    executable caller path to the call site.
  - Chain: repository-test path `validate_train_data ->
    valid_data_for_builtin_scorers`; public-API path
    `mlflow.genai.optimize_prompts -> validate_train_data ->
    valid_data_for_builtin_scorers`.
  - Disposition: ON-PATH as a compatibility/dependency obligation (R14) because
    the call site is directly reachable by existing repository tests and public
    optimize API. Recorded as E5, C17.

No static issue is dispositioned out of scope.
