#!/usr/bin/env python3
"""Executable architecture spec for the MLflow GenAI scorer validation IR.

This spec compiles the L3 contracts into import/dependency-binding, graph
connectivity, real CALL/CONTROL path, and dataflow observations.  It is
intended to be run after the implementer restores the missing public
functions in /testbed; it never modifies production code itself.
"""

import contextlib
import functools
import inspect
import sys
import types
from unittest import mock

sys.path.insert(0, "/testbed")


def _raise_assertion(message: str) -> None:
    raise AssertionError(message)


# ---------------------------------------------------------------------------
# N1 -> N2 (E1): scorer factory, partial branch, and local CustomScorer class
# ---------------------------------------------------------------------------

def arch_check_scorer_partial_decorator_binding():
    # Contracts: C1; Obligations: R1
    # Guidance: Interface Description 1 no-parentheses usage; no direct repo test
    #   for partial internals, so source evidence is
    #   /testbed/mlflow/genai/scorers/base.py:994-997.
    # Perspective: preserve functools.partial binding and keyword forwarding.
    # Exercised path/symbol: mlflow.genai.scorers.base.scorer (public entry).
    from mlflow.genai.scorers.base import scorer

    partial = scorer(None, name="x", description="d", aggregations=["mean"])
    assert isinstance(partial, functools.partial), "scorer(None) must return a partial"
    assert partial.func is scorer, "partial must bind the public scorer function"
    assert partial.keywords == {
        "name": "x",
        "description": "d",
        "aggregations": ["mean"],
    }, partial.keywords

    def f(outputs):
        return outputs

    decorated = partial(f)
    assert decorated.name == "x", decorated.name


def arch_check_scorer_constructs_local_custom_scorer():
    # Contracts: C2; Obligations: R2, R4
    # Guidance: no exact repository test for local-class shape; source evidence
    #   /testbed/mlflow/genai/scorers/base.py:1025-1031 and reference
    #   /testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1031.
    # Perspective: representation preservation across public factory -> class.
    # Exercised path/symbol: scorer -> local CustomScorer constructor (N1 -> N2).
    from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer

    def my_scorer(outputs):
        return outputs != ""

    instance = scorer(
        my_scorer,
        name="custom_name",
        description="custom description",
        aggregations=["mean"],
    )
    assert isinstance(instance, Scorer), type(instance)
    assert instance.kind == ScorerKind.DECORATOR, instance.kind
    assert getattr(instance, "_original_func", None) is my_scorer
    assert instance.name == "custom_name", instance.name
    assert instance.description == "custom description", instance.description
    assert instance.aggregations == ["mean"], instance.aggregations
    # The __call__ delegation must execute the original function.
    assert instance("answer") is True


def arch_check_decorator_call_signature_binding():
    # Contracts: C3; Obligations: R3
    # Guidance: repository test tests/genai/scorers/test_scorer.py:247-265 uses
    #   evaluator-driven parameter filtering. Python 3.11 binds the method, so
    #   inspect.signature(instance.__call__) strips the leading self; observe the
    #   unbound class attribute for the self-prepended class signature.
    # Perspective: interface/runtime dispatch representation.
    # Exercised path/symbol: scorer -> CustomScorer.__call__.__signature__.
    from mlflow.genai.scorers.base import scorer

    def f(inputs, outputs):
        return outputs

    instance = scorer(f)
    bound_sig = inspect.signature(instance.__call__)
    assert list(bound_sig.parameters) == ["inputs", "outputs"], list(bound_sig.parameters)

    class_sig = inspect.signature(type(instance).__call__)
    assert list(class_sig.parameters) == ["self", "inputs", "outputs"], list(
        class_sig.parameters
    )


# ---------------------------------------------------------------------------
# N2 -> N3 (E2): Scorer.run filtering and delegation for decorator scorers
# ---------------------------------------------------------------------------

def arch_check_scorer_run_full_delegation_chain():
    # Contracts: C4; Obligations: R3, R5
    # Guidance: tests/genai/scorers/test_scorer.py:247-265 and 268-274.
    # Perspective: execute public decorator entry through Scorer.run and observe
    #   argument filtering at the original function.
    # Exercised path/symbol: scorer -> CustomScorer.__call__ -> Scorer.run.
    from mlflow.genai.scorers.base import scorer

    called = []

    @scorer
    def f(outputs):
        called.append(outputs)
        return outputs != ""

    result = f.run(
        inputs={"q": "x"},
        outputs="answer",
        expectations={"e": 1},
        trace=None,
    )
    assert result is True, result
    assert called == ["answer"], called


# ---------------------------------------------------------------------------
# N4: validate_scorers import/dependency and graph edges
# ---------------------------------------------------------------------------

def arch_check_validate_scorers_list_contracts():
    # Contracts: C6, C7, C8; Obligations: R6, R7
    # Guidance: Interface Description 2; no dedicated validation test file, so
    #   source/reference evidence is
    #   /testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-46.
    # Perspective: exact list-shape, empty-list, and identity semantics.
    # Exercised path/symbol: mlflow.genai.scorers.validation.validate_scorers.
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer
    from mlflow.genai.scorers.validation import validate_scorers

    try:
        validate_scorers(Scorer(name="x"))
    except MlflowException as exc:
        assert "must be a list of scorers" in str(exc), str(exc)
    else:
        _raise_assertion("validate_scorers did not reject a non-list")

    assert validate_scorers([]) == []

    scorer_instance = Scorer(name="x")
    out = validate_scorers([scorer_instance])
    assert len(out) == 1, out
    assert out[0] is scorer_instance, "valid scorer identity must be preserved"


def arch_check_validate_scorers_legacy_metric_import_boundary():
    # Contracts: C9; Obligations: R8
    # Guidance: Interface Description 2 legacy Metric bullet; no repository test.
    #   The reference implementation reads `metric.name` when building the
    #   deprecation warning, so the stub must expose that attribute.
    # Perspective: optional external package boundary N4 -> N12 (E13) must be
    #   live when IS_DBX_AGENTS_INSTALLED is true.
    # Exercised path/symbol: validate_scorers -> databricks.rag_eval...Metric.
    from mlflow.genai.scorers import validation

    class Metric:
        name = "legacy_metric"

    metric = Metric()
    dbx = types.ModuleType("databricks")
    rag_eval = types.ModuleType("databricks.rag_eval")
    evaluation = types.ModuleType("databricks.rag_eval.evaluation")
    metrics = types.ModuleType("databricks.rag_eval.evaluation.metrics")
    metrics.Metric = Metric
    modules = {
        "databricks": dbx,
        "databricks.rag_eval": rag_eval,
        "databricks.rag_eval.evaluation": evaluation,
        "databricks.rag_eval.evaluation.metrics": metrics,
    }
    old_flag = validation.IS_DBX_AGENTS_INSTALLED
    try:
        validation.IS_DBX_AGENTS_INSTALLED = True
        with mock.patch.dict(sys.modules, modules), mock.patch.object(
            validation._logger, "warning"
        ) as warning:
            out = validation.validate_scorers([metric])
        assert len(out) == 1, out
        assert out[0] is metric
        assert warning.called, "legacy metric warning was not logged"
        warning_text = " ".join(str(call) for call in warning.call_args_list)
        assert "legacy metrics" in warning_text, warning_text
        assert "legacy_metric" in warning_text, warning_text
    finally:
        validation.IS_DBX_AGENTS_INSTALLED = old_flag


def arch_check_validate_scorers_nested_get_all_hint_path():
    # Contracts: C10 (nested-list case); Obligations: R9
    # Guidance: Interface Description 2 common mistake hints; no repository test.
    # Perspective: graph edge N4 -> N6 (E6) is executed when an invalid item is
    #   exactly get_all_scorers().
    # Exercised path/symbol: validate_scorers -> builtin_scorers.get_all_scorers.
    import mlflow
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers import builtin_scorers
    from mlflow.genai.scorers.validation import validate_scorers

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("file://test")
        all_scorers = builtin_scorers.get_all_scorers()
        try:
            validate_scorers([all_scorers])
        except MlflowException as exc:
            assert "Use `scorers=get_all_scorers()`" in str(exc), str(exc)
        else:
            _raise_assertion("nested get_all_scorers() was not rejected")
    finally:
        mlflow.set_tracking_uri(old_uri)


# ---------------------------------------------------------------------------
# N5 -> N7 -> N8: valid_data_for_builtin_scorers dataflow/control path
# ---------------------------------------------------------------------------

def arch_check_valid_data_normalizes_columns_dataflow():
    # Contracts: C11; Obligations: R10, R11
    # Guidance: Interface Description 2 column mapping and trace/predict_fn notes;
    #   no dedicated repo test found. Use isolated cases with exact column sets
    #   so swapped request/response mappings or omitted trace/predict_fn branches
    #   cannot satisfy the check.
    # Perspective: legacy DataFrame column state N13 -> N5 -> N7 (E10/E7).
    # Exercised path/symbol: valid_data_for_builtin_scorers -> scorer.validate_columns.
    import pandas as pd

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    seen = []

    class SpyScorer:
        name = "spy"

        def validate_columns(self, columns):
            seen.append(set(columns))

    def capture(data, predict_fn=None):
        seen.clear()
        valid_data_for_builtin_scorers(data, [SpyScorer()], predict_fn=predict_fn)
        assert len(seen) == 1, seen
        return seen[0]

    # (a) request-only, no predict_fn/trace -> exactly {"inputs"}.
    assert capture(pd.DataFrame({"request": [{"q": "x"}]})) == {"inputs"}

    # (b) response-only, no predict_fn/trace -> exactly {"outputs"}.
    assert capture(pd.DataFrame({"response": ["answer"]})) == {"outputs"}

    # (c) trace-only, no predict_fn -> trace infers both inputs and outputs.
    assert capture(pd.DataFrame({"trace": [object()]})) == {"inputs", "outputs", "trace"}

    # (d) request + predict_fn, no trace -> inputs, synthesized outputs, and
    #     synthesized trace are all present.
    assert capture(
        pd.DataFrame({"request": [{"q": "x"}]}),
        predict_fn=lambda **kwargs: "output",
    ) == {"inputs", "outputs", "trace"}

    # (e) expectations-only -> expectation keys are exploded into
    #     expectations/<key> while preserving the original column.
    assert capture(
        pd.DataFrame({"expectations": [{"expected_response": "Paris"}]})
    ) == {"expectations", "expectations/expected_response"}


def arch_check_valid_data_missing_columns_control_path():
    # Contracts: C13; Obligations: R12
    # Guidance: Interface Description 2 logging behavior; repository test absent.
    # Perspective: BuiltInScorer.validate_columns -> MissingColumnsException
    #   (N7 -> N8) caught and aggregated by N5.
    # Exercised path/symbol: valid_data_for_builtin_scorers -> BuiltInScorer.validate_columns.
    import pandas as pd

    from mlflow.genai.scorers import validation
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer

    class OutputsOnlyScorer(BuiltInScorer):
        name: str = "needs_outputs"
        required_columns: set[str] = {"outputs"}

        @property
        def instructions(self) -> str:
            return "requires outputs"

        def get_input_fields(self):
            return []

    df = pd.DataFrame({"inputs": [{"q": "x"}]})
    with mock.patch.object(validation._logger, "info") as info:
        result = validation.valid_data_for_builtin_scorers(
            df, [OutputsOnlyScorer()], predict_fn=None
        )
    assert result is None, result
    assert info.called, "missing-column info log was not emitted"
    message = " ".join(str(call) for call in info.call_args_list)
    assert "outputs" in message, message
    assert "needs_outputs" in message, message


# ---------------------------------------------------------------------------
# N6 -> N14 (E11): get_all_scorers branch behavior
# ---------------------------------------------------------------------------

def arch_check_get_all_scorers_oss_and_databricks_branches():
    # Contracts: C14, C15; Obligations: R13
    # Guidance: tests/genai/scorers/test_builtin_scorers.py:570-577.
    # Perspective: tracking-URI control branch yields exact public scorer sets.
    # Exercised path/symbol: builtin_scorers.get_all_scorers -> is_databricks_uri.
    import mlflow
    from mlflow.genai.scorers import builtin_scorers
    from mlflow.genai.scorers.base import Scorer

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("file://test")
        oss_scorers = builtin_scorers.get_all_scorers()
        assert len(oss_scorers) == 6, len(oss_scorers)
        assert [type(s).__name__ for s in oss_scorers] == [
            "ExpectationsGuidelines",
            "Correctness",
            "RelevanceToQuery",
            "RetrievalSufficiency",
            "RetrievalGroundedness",
            "Equivalence",
        ], [type(s).__name__ for s in oss_scorers]
        assert all(isinstance(s, Scorer) for s in oss_scorers)

        mlflow.set_tracking_uri("databricks")
        dbx_scorers = builtin_scorers.get_all_scorers()
        assert len(dbx_scorers) == 8, len(dbx_scorers)
        names = {type(s).__name__ for s in dbx_scorers}
        assert {"Safety", "RetrievalRelevance"} <= names, names
        assert all(isinstance(s, Scorer) for s in dbx_scorers)
    finally:
        mlflow.set_tracking_uri(old_uri)


# ---------------------------------------------------------------------------
# Static-issue caller bindings: evaluation.base and optimize.util
# ---------------------------------------------------------------------------

def arch_check_evaluate_reaches_both_validation_calls():
    # Contracts: C16; Obligations: R14
    # Guidance: tests/genai/evaluate/test_evaluation.py:658-666
    #   (test_empty_scorers_allowed) proves evaluate runs with scorers=[] and a
    #   patched _run_harness; we extend that lens to observe both validation calls.
    # Perspective: public entry mlflow.genai.evaluate -> evaluate -> real
    #   validate_scorers and valid_data_for_builtin_scorers call sites.
    # Exercised path/symbol: mlflow.genai.evaluation.base.evaluate (E3, E4).
    from mlflow.genai.evaluation import evaluate
    from mlflow.genai.evaluation import base as evaluation_base
    from mlflow.genai.scorers import validation

    real_validate_scorers = validation.validate_scorers
    real_valid_data = validation.valid_data_for_builtin_scorers

    with mock.patch.object(
        evaluation_base, "validate_scorers", wraps=real_validate_scorers
    ) as validate_spy, mock.patch.object(
        evaluation_base, "valid_data_for_builtin_scorers", wraps=real_valid_data
    ) as valid_data_spy, mock.patch.object(
        evaluation_base, "_run_harness"
    ) as harness:
        harness.return_value = object()
        evaluate(
            data=[{"inputs": {"q": "What is MLflow?"}, "outputs": "MLflow"}],
            scorers=[],
        )

    assert validate_spy.called, "validate_scorers was not called"
    assert validate_spy.call_count == 1, validate_spy.call_count
    assert valid_data_spy.called, "valid_data_for_builtin_scorers was not called"
    assert valid_data_spy.call_count == 1, valid_data_spy.call_count

    df, builtin_scorers, predict_fn = valid_data_spy.call_args.args
    assert builtin_scorers == [], builtin_scorers
    assert predict_fn is None, predict_fn
    assert {"request", "response"} <= set(df.columns), set(df.columns)


def arch_check_validate_train_data_reaches_valid_data_direct():
    # Contracts: C17 (repository-test path); Obligations: R14
    # Guidance: tests/genai/optimize/test_util.py:195-221 exercises
    #   validate_train_data directly with an empty scorer list.
    # Perspective: helper caller binding through the real function call site.
    # Exercised path/symbol: mlflow.genai.optimize.util.validate_train_data (E5).
    import pandas as pd

    from mlflow.genai.optimize import util as optimize_util

    real_valid_data = optimize_util.valid_data_for_builtin_scorers
    calls = []

    def spy(data, builtin_scorers, predict_fn=None):
        calls.append((data, builtin_scorers, predict_fn))
        return real_valid_data(data, builtin_scorers, predict_fn)

    with mock.patch.object(
        optimize_util, "valid_data_for_builtin_scorers", side_effect=spy
    ):
        optimize_util.validate_train_data(
            pd.DataFrame([{"inputs": {"text": "hello"}}]),
            [],
            lambda **kwargs: None,
        )

    assert len(calls) == 1, calls
    data, builtin_scorers, predict_fn = calls[0]
    assert builtin_scorers == [], builtin_scorers
    assert callable(predict_fn), predict_fn


def arch_check_optimize_prompts_public_path_reaches_valid_data():
    # Contracts: C17 (public-API path); Obligations: R14
    # Guidance: no direct repository test executes optimize_prompts with mocks;
    #   source evidence is /testbed/mlflow/genai/optimize/optimize.py:178-180.
    # Perspective: close the optimize.util static issue through the public
    #   mlflow.genai.optimize_prompts entry, patching only downstream/external
    #   prompt and optimization machinery after validate_train_data.
    # Exercised path/symbol: optimize_prompts -> validate_train_data ->
    #   valid_data_for_builtin_scorers.
    from mlflow.genai.optimize import optimize as optimize_mod
    from mlflow.genai.optimize import util as optimize_util

    real_valid_data = optimize_util.valid_data_for_builtin_scorers
    calls = []

    def spy(data, builtin_scorers, predict_fn=None):
        calls.append((data, builtin_scorers, predict_fn))
        return real_valid_data(data, builtin_scorers, predict_fn)

    class DummyPrompt:
        is_text_prompt = True
        name = "qa"
        template = "Answer: {{question}}"
        uri = "prompts:/qa"

    class DummyOptimizerOutput:
        optimized_prompts = {"qa": "Answer: {{question}}"}
        initial_eval_score = 0.0
        final_eval_score = 1.0

    class DummyOptimizer:
        def optimize(self, eval_fn, train_data, target_prompts, enable_tracking):
            return DummyOptimizerOutput()

    with mock.patch.object(
        optimize_util, "valid_data_for_builtin_scorers", side_effect=spy
    ), mock.patch.object(
        optimize_mod,
        "convert_predict_fn",
        side_effect=lambda **kwargs: kwargs["predict_fn"],
    ), mock.patch.object(
        optimize_mod,
        "create_metric_from_scorers",
        return_value=lambda *args, **kwargs: (0.0, {}),
    ), mock.patch.object(
        optimize_mod, "_build_eval_fn", return_value=lambda *args, **kwargs: []
    ), mock.patch.object(
        optimize_mod, "load_prompt", side_effect=lambda uri: DummyPrompt()
    ), mock.patch.object(
        optimize_mod,
        "register_prompt",
        side_effect=lambda name, template: DummyPrompt(),
    ), mock.patch.object(
        optimize_mod,
        "prompt_optimization_autolog",
        return_value=contextlib.nullcontext({}),
    ), mock.patch.object(
        optimize_mod, "PromptOptimizationResult", side_effect=lambda **kwargs: kwargs
    ):
        result = optimize_mod.optimize_prompts(
            predict_fn=lambda **kwargs: "ok",
            train_data=[{"inputs": {"question": "What is MLflow?"}, "outputs": "MLflow"}],
            prompt_uris=["prompts:/qa"],
            optimizer=DummyOptimizer(),
            scorers=[],
            enable_tracking=False,
        )

    assert len(calls) == 1, calls
    data, builtin_scorers, predict_fn = calls[0]
    assert builtin_scorers == [], builtin_scorers
    assert callable(predict_fn), predict_fn
    assert result["optimizer_name"] == "DummyOptimizer", result


# ---------------------------------------------------------------------------
# N11 -> N6 (E12): package lazy export boundary
# ---------------------------------------------------------------------------

def arch_check_package_lazy_export_binds_get_all_scorers():
    # Contracts: C18; Obligations: R15
    # Guidance: Interface Description 3 import style; source evidence
    #   /testbed/mlflow/genai/scorers/__init__.py:36,57-67,93.
    # Perspective: import boundary must return the real builtin module callable.
    # Exercised path/symbol: mlflow.genai.scorers.__getattr__ -> builtin_scorers.
    import mlflow
    from mlflow.genai.scorers import builtin_scorers
    from mlflow.genai.scorers import get_all_scorers as lazy_get_all_scorers

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("file://test")
        assert lazy_get_all_scorers is builtin_scorers.get_all_scorers
        assert len(lazy_get_all_scorers()) == 6
    finally:
        mlflow.set_tracking_uri(old_uri)


def main() -> None:
    checks = [
        arch_check_scorer_partial_decorator_binding,
        arch_check_scorer_constructs_local_custom_scorer,
        arch_check_decorator_call_signature_binding,
        arch_check_scorer_run_full_delegation_chain,
        arch_check_validate_scorers_list_contracts,
        arch_check_validate_scorers_legacy_metric_import_boundary,
        arch_check_validate_scorers_nested_get_all_hint_path,
        arch_check_valid_data_normalizes_columns_dataflow,
        arch_check_valid_data_missing_columns_control_path,
        arch_check_get_all_scorers_oss_and_databricks_branches,
        arch_check_evaluate_reaches_both_validation_calls,
        arch_check_validate_train_data_reaches_valid_data_direct,
        arch_check_optimize_prompts_public_path_reaches_valid_data,
        arch_check_package_lazy_export_binds_get_all_scorers,
    ]
    failed = False
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as exc:  # noqa: BLE001 - spec runner intentionally broad
            failed = True
            print(f"FAIL: {check.__name__}: {type(exc).__name__}: {exc}")
    if failed:
        raise SystemExit(1)
    print("PASS: all architecture checks passed")


if __name__ == "__main__":
    main()
