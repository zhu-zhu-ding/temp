#!/usr/bin/env python3
"""Executable behavior spec for the MLflow GenAI scorer validation IR.

This spec compiles L3 contracts into state, outcome, default, failure, side
effect, boundary, and compatibility assertions.  It is intended to be run after
the implementer restores the missing public functions in /testbed.
"""

import functools
import inspect
import sys
import types
from unittest import mock

sys.path.insert(0, "/testbed")


def _assert_raises(exc_type, match, fn):
    try:
        fn()
    except exc_type as exc:
        assert match in str(exc), f"expected {match!r} in {exc!r}"
        return exc
    raise AssertionError(f"expected {exc_type.__name__} containing {match!r}")


# ---------------------------------------------------------------------------
# scorer decorator behavior
# ---------------------------------------------------------------------------

def behavior_check_scorer_partial_and_decorator_state():
    # Contracts: C1, C2, C3; Obligations: R1, R2, R3, R4
    # Guidance: tests/genai/scorers/test_scorer.py:247-265 and 268-274;
    #   tests/genai/scorers/test_scorer_description.py:27-44.
    # Perspective: representational preservation from factory input to scorer.
    #   Python 3.11 bound-method signatures strip the leading self, so assert the
    #   original parameters on the bound method and self on the unbound class.
    # Exercised path/symbol: mlflow.genai.scorers.base.scorer.
    from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer

    partial = scorer(name="x", description="d", aggregations=["mean"])
    assert isinstance(partial, functools.partial), type(partial)
    assert partial.func is scorer
    assert partial.keywords == {
        "name": "x",
        "description": "d",
        "aggregations": ["mean"],
    }

    def f(inputs, outputs):
        return outputs

    instance = partial(f)
    assert isinstance(instance, Scorer), type(instance)
    assert instance.kind == ScorerKind.DECORATOR, instance.kind
    assert getattr(instance, "_original_func", None) is f
    assert instance.name == "x", instance.name
    assert instance.description == "d", instance.description
    assert instance.aggregations == ["mean"], instance.aggregations
    assert list(inspect.signature(instance.__call__).parameters) == [
        "inputs",
        "outputs",
    ]
    assert list(inspect.signature(type(instance).__call__).parameters) == [
        "self",
        "inputs",
        "outputs",
    ]


def behavior_check_scorer_default_metadata():
    # Contracts: C2; Obligations: R4
    # Guidance: tests/genai/scorers/test_scorer_description.py:27-44 asserts
    #   default description is None and custom name/description are preserved;
    #   tests/genai/scorers/test_scorer.py:61-71 asserts metric name derives from
    #   the function name.
    # Perspective: no-parentheses @scorer must use func.__name__ and the Scorer
    #   model defaults for unset metadata.
    # Exercised path/symbol: mlflow.genai.scorers.base.scorer.
    from mlflow.genai.scorers.base import scorer

    @scorer
    def simple_scorer(outputs):
        return True

    assert simple_scorer.name == "simple_scorer", simple_scorer.name
    assert simple_scorer.description is None, simple_scorer.description
    assert simple_scorer.aggregations is None, simple_scorer.aggregations


def behavior_check_scorer_run_filters_and_accepts_primitive():
    # Contracts: C4; Obligations: R3, R5
    # Guidance: tests/genai/scorers/test_scorer.py:247-265.
    # Perspective: exact argument filtering and accepted boolean result.
    # Exercised path/symbol: Scorer.run on a decorator scorer.
    from mlflow.genai.scorers.base import scorer

    seen = []

    @scorer
    def f(outputs):
        seen.append(outputs)
        return outputs != ""

    result = f.run(
        inputs={"q": "x"},
        outputs="answer",
        expectations={"e": 1},
        trace=None,
    )
    assert result is True, result
    assert seen == ["answer"], seen


def behavior_check_scorer_run_accepts_none():
    # Contracts: C4 (accepted-result complement); Obligations: R5
    # Guidance: tests/genai/scorers/test_scorer.py:268-274.
    # Perspective: None is explicitly accepted by Scorer.run.
    # Exercised path/symbol: Scorer.run on a decorator scorer.
    from mlflow.genai.scorers.base import scorer

    @scorer
    def f(inputs, outputs):
        return None

    assert f.run(inputs={"q": "query"}, outputs="answer") is None


def behavior_check_scorer_run_accepts_all_supported_returns():
    # Contracts: C4; Obligations: R5
    # Guidance: tests/genai/scorers/test_scorer.py:247-265 parametrizes str,
    #   int, float, Feedback, and list[Feedback] positive returns through
    #   mlflow.genai.evaluate. We isolate the same accepted-return contract at
    #   the Scorer.run boundary.
    # Perspective: every task-supported positive return type survives the real
    #   decorator/run delegation chain without being rejected.
    # Exercised path/symbol: Scorer.run on a decorator scorer.
    from mlflow.entities import Feedback
    from mlflow.genai.scorers.base import scorer

    str_result = "yes"
    int_result = 42
    float_result = 42.0
    feedback_result = Feedback(name="big_question", value=42, rationale="answer")
    feedback_list_result = [
        Feedback(name="big_question", value=42, rationale="answer"),
        Feedback(name="small_question", value=1, rationale="guess"),
    ]

    @scorer
    def return_str(inputs, outputs):
        return str_result

    @scorer
    def return_int(inputs, outputs):
        return int_result

    @scorer
    def return_float(inputs, outputs):
        return float_result

    @scorer
    def return_feedback(inputs, outputs):
        return feedback_result

    @scorer
    def return_feedback_list(inputs, outputs):
        return feedback_list_result

    assert return_str.run(inputs={"q": "query"}, outputs="answer") == str_result
    assert return_int.run(inputs={"q": "query"}, outputs="answer") == int_result
    assert return_float.run(inputs={"q": "query"}, outputs="answer") == float_result
    assert (
        return_feedback.run(inputs={"q": "query"}, outputs="answer")
        is feedback_result
    )
    assert (
        return_feedback_list.run(inputs={"q": "query"}, outputs="answer")
        is feedback_list_result
    )


def behavior_check_scorer_run_rejects_invalid_return():
    # Contracts: C5; Obligations: R5
    # Guidance: tests/genai/scorers/test_scorer.py:247-265 demonstrates accepted
    #   returns; the negative case is specified by the IR and source evidence
    #   /testbed/mlflow/genai/scorers/base.py:386-405.
    # Perspective: precise failure semantics for invalid return types.
    # Exercised path/symbol: Scorer.run on a decorator scorer.
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import scorer

    @scorer
    def bad(outputs):
        return {"bad": object()}

    _assert_raises(
        MlflowException,
        "must return one of int, float, bool, str, Feedback, or list[Feedback]",
        lambda: bad.run(outputs="x"),
    )


# ---------------------------------------------------------------------------
# validate_scorers behavior
# ---------------------------------------------------------------------------

def behavior_check_validate_scorers_list_shape_empty_and_identity():
    # Contracts: C6, C7, C8; Obligations: R6, R7
    # Guidance: Interface Description 2; source/reference evidence
    #   /testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-46.
    # Perspective: exact list/empty/identity semantics.
    # Exercised path/symbol: mlflow.genai.scorers.validation.validate_scorers.
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer
    from mlflow.genai.scorers.validation import validate_scorers

    _assert_raises(
        MlflowException,
        "must be a list of scorers",
        lambda: validate_scorers(Scorer(name="x")),
    )
    assert validate_scorers([]) == []

    scorer_instance = Scorer(name="x")
    out = validate_scorers([scorer_instance])
    assert len(out) == 1, out
    assert out[0] is scorer_instance


def behavior_check_legacy_metric_accept_and_reject():
    # Contracts: C9; Obligations: R8
    # Guidance: Interface Description 2 legacy metric bullets; no repo test.
    #   The reference warning builds a list of `metric.name`, so the stub must
    #   expose a real name attribute for the success path to be observable.
    # Perspective: optional-dependency state controls acceptance and warning.
    # Exercised path/symbol: validate_scorers -> databricks.rag_eval...Metric.
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers import validation

    class Metric:
        name = "legacy_metric"

    metric = Metric()
    modules = {
        "databricks": types.ModuleType("databricks"),
        "databricks.rag_eval": types.ModuleType("databricks.rag_eval"),
        "databricks.rag_eval.evaluation": types.ModuleType(
            "databricks.rag_eval.evaluation"
        ),
        "databricks.rag_eval.evaluation.metrics": types.ModuleType(
            "databricks.rag_eval.evaluation.metrics"
        ),
    }
    modules["databricks.rag_eval.evaluation.metrics"].Metric = Metric

    old_flag = validation.IS_DBX_AGENTS_INSTALLED
    try:
        validation.IS_DBX_AGENTS_INSTALLED = True
        with mock.patch.dict(sys.modules, modules), mock.patch.object(
            validation._logger, "warning"
        ) as warning:
            out = validation.validate_scorers([metric])
        assert out == [metric], out
        warning_text = " ".join(str(call) for call in warning.call_args_list)
        assert "legacy metrics" in warning_text, warning_text
        assert "legacy_metric" in warning_text, warning_text

        validation.IS_DBX_AGENTS_INSTALLED = False
        _assert_raises(
            MlflowException,
            "invalid item with type",
            lambda: validation.validate_scorers([Metric()]),
        )
    finally:
        validation.IS_DBX_AGENTS_INSTALLED = old_flag


def behavior_check_validate_scorers_helpful_hints():
    # Contracts: C10; Obligations: R9
    # Guidance: Interface Description 2 hint bullets; no repo test.
    # Perspective: context-aware failure diagnostics for all common mistakes.
    # Exercised path/symbol: validate_scorers -> get_all_scorers for nested case.
    import mlflow
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers import builtin_scorers
    from mlflow.genai.scorers.validation import validate_scorers

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("file://test")
        all_scorers = builtin_scorers.get_all_scorers()
        _assert_raises(
            MlflowException,
            "Use `scorers=get_all_scorers()`",
            lambda: validate_scorers([all_scorers]),
        )
        _assert_raises(
            MlflowException,
            "class instead of an instance",
            lambda: validate_scorers([builtin_scorers.Correctness]),
        )
        _assert_raises(
            MlflowException,
            "invalid item with type",
            lambda: validate_scorers([object()]),
        )
    finally:
        mlflow.set_tracking_uri(old_uri)


# ---------------------------------------------------------------------------
# valid_data_for_builtin_scorers behavior
# ---------------------------------------------------------------------------

def behavior_check_valid_data_normalizes_columns():
    # Contracts: C11; Obligations: R10, R11
    # Guidance: Interface Description 2 column mapping and trace/predict_fn notes.
    #   Isolated exact-set cases make swapped mappings and omitted synthesized
    #   branches observable, unlike one saturated set-membership fixture.
    # Perspective: legacy schema conversion and expectations explosion.
    # Exercised path/symbol: valid_data_for_builtin_scorers -> scorer.validate_columns.
    import pandas as pd

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    seen = []

    class SpyScorer:
        name = "spy"

        def validate_columns(self, columns):
            seen.append(set(columns))

    def capture(data, predict_fn=None):
        seen.clear()
        valid_data_for_builtin_scorers(data, [SpyScorer()], predict_fn=predict_fn)
        assert len(seen) == 1, seen
        return seen[0]

    # request -> inputs only.
    assert capture(pd.DataFrame({"request": [{"q": "x"}]})) == {"inputs"}

    # response -> outputs only.
    assert capture(pd.DataFrame({"response": ["answer"]})) == {"outputs"}

    # trace implies inputs and outputs.
    assert capture(pd.DataFrame({"trace": [object()]})) == {"inputs", "outputs", "trace"}

    # predict_fn synthesizes outputs and trace.
    assert capture(
        pd.DataFrame({"request": [{"q": "x"}]}),
        predict_fn=lambda **kwargs: "out",
    ) == {"inputs", "outputs", "trace"}

    # expectations keys are exploded into expectations/<key>.
    assert capture(
        pd.DataFrame({"expectations": [{"expected_response": "Paris"}]})
    ) == {"expectations", "expectations/expected_response"}


def behavior_check_valid_data_rejects_nondict_expectations():
    # Contracts: C12; Obligations: R11
    # Guidance: Interface Description 2 Raises section; no repo test.
    # Perspective: exact failure semantics for malformed expectations.
    # Exercised path/symbol: valid_data_for_builtin_scorers.
    import pandas as pd
    from mlflow.exceptions import MlflowException

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    _assert_raises(
        MlflowException,
        "must be a dictionary",
        lambda: valid_data_for_builtin_scorers(
            pd.DataFrame({"expectations": ["not-a-dict"]}), []
        ),
    )


def behavior_check_valid_data_logs_missing_columns_and_returns_none():
    # Contracts: C13; Obligations: R12
    # Guidance: Interface Description 2 logging behavior; no repo test.
    # Perspective: side effect and return value for missing required columns.
    # Exercised path/symbol: valid_data_for_builtin_scorers -> BuiltInScorer.
    import pandas as pd

    from mlflow.genai.scorers import validation
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer

    class OutputsOnlyScorer(BuiltInScorer):
        name: str = "needs_outputs"
        required_columns: set[str] = {"outputs"}

        @property
        def instructions(self) -> str:
            return "requires outputs"

        def get_input_fields(self):
            return []

    with mock.patch.object(validation._logger, "info") as info:
        result = validation.valid_data_for_builtin_scorers(
            pd.DataFrame({"inputs": [{"q": "x"}]}),
            [OutputsOnlyScorer()],
            predict_fn=None,
        )
    assert result is None, result
    assert info.called, "missing-column info log was not emitted"
    message = " ".join(str(call) for call in info.call_args_list)
    assert "outputs" in message, message
    assert "needs_outputs" in message, message


# ---------------------------------------------------------------------------
# get_all_scorers behavior
# ---------------------------------------------------------------------------

def behavior_check_get_all_scorers_oss_and_databricks():
    # Contracts: C14, C15; Obligations: R13
    # Guidance: tests/genai/scorers/test_builtin_scorers.py:570-577.
    # Perspective: exact set/length across tracking-URI compatibility modes.
    # Exercised path/symbol: builtin_scorers.get_all_scorers.
    import mlflow
    from mlflow.genai.scorers import builtin_scorers
    from mlflow.genai.scorers.base import Scorer

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("file://test")
        oss = builtin_scorers.get_all_scorers()
        assert len(oss) == 6, len(oss)
        assert [type(s).__name__ for s in oss] == [
            "ExpectationsGuidelines",
            "Correctness",
            "RelevanceToQuery",
            "RetrievalSufficiency",
            "RetrievalGroundedness",
            "Equivalence",
        ], [type(s).__name__ for s in oss]
        assert all(isinstance(s, Scorer) for s in oss)

        mlflow.set_tracking_uri("databricks")
        dbx = builtin_scorers.get_all_scorers()
        assert len(dbx) == 8, len(dbx)
        names = {type(s).__name__ for s in dbx}
        assert {"Safety", "RetrievalRelevance"} <= names, names
        assert all(isinstance(s, Scorer) for s in dbx)
    finally:
        mlflow.set_tracking_uri(old_uri)


def main() -> None:
    checks = [
        behavior_check_scorer_partial_and_decorator_state,
        behavior_check_scorer_default_metadata,
        behavior_check_scorer_run_filters_and_accepts_primitive,
        behavior_check_scorer_run_accepts_none,
        behavior_check_scorer_run_accepts_all_supported_returns,
        behavior_check_scorer_run_rejects_invalid_return,
        behavior_check_validate_scorers_list_shape_empty_and_identity,
        behavior_check_legacy_metric_accept_and_reject,
        behavior_check_validate_scorers_helpful_hints,
        behavior_check_valid_data_normalizes_columns,
        behavior_check_valid_data_rejects_nondict_expectations,
        behavior_check_valid_data_logs_missing_columns_and_returns_none,
        behavior_check_get_all_scorers_oss_and_databricks,
    ]
    failed = False
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as exc:  # noqa: BLE001 - spec runner intentionally broad
            failed = True
            print(f"FAIL: {check.__name__}: {type(exc).__name__}: {exc}")
    if failed:
        raise SystemExit(1)
    print("PASS: all behavior checks passed")


if __name__ == "__main__":
    main()
