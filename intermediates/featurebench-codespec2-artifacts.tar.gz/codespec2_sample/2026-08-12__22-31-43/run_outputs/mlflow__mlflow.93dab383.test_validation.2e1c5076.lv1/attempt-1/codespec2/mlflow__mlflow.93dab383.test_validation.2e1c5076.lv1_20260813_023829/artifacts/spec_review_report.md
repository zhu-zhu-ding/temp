# Spec Review Report

## Evidence Reviewed
- Task document and Interface Descriptions 1-3.
- Semantic IR: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260813_023829/artifacts/semantic_ir.md`
- Architecture spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260813_023829/artifacts/arch_spec.py`
- Behavior spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260813_023829/artifacts/behavior_spec.py`
- Static issues and static analysis: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260813_023829/artifacts/static_issues.md`, `static_analysis.md`
- Review skill: `/installed-agent/codespec2/review_skill.md`
- Repository source: `mlflow/genai/scorers/base.py`, `mlflow/genai/scorers/validation.py`, `mlflow/genai/scorers/builtin_scorers.py`, `mlflow/genai/scorers/__init__.py`, `mlflow/genai/evaluation/base.py`, `mlflow/genai/optimize/util.py`, `mlflow/genai/optimize/optimize.py`
- Reference implementations under `/testbed/libs/skinny/...`
- Repository tests: `tests/genai/scorers/test_scorer.py`, `tests/genai/scorers/test_scorer_description.py`, `tests/genai/scorers/test_builtin_scorers.py`, `tests/genai/evaluate/test_evaluation.py`, `tests/genai/optimize/test_util.py`
- Python 3.11 runtime probes for `inspect.signature` on bound methods and for `BuiltInScorer` subclass instantiation.

## Rubric Scores
- **Requirement coverage** — WEAK. All IR obligations R1-R15 have at least one nominal check, but R4 default metadata and R5 accepted positive return types are only partially observed. Affected: R4, R5, C2, C4, C5.
- **Requirement fidelity** — FAIL. C3 and its spec checks assert a bound-method signature containing `self`; the actual repository/task-supported relation, and Python 3.11 semantics, expose only the original function parameters on `inspect.signature(instance.__call__)`. Affected: R3, C3.
- **Caller binding and architecture** — PASS. Static-issue upward traces for `CustomScorer`, evaluation-base `validate_scorers`, evaluation-base `valid_data_for_builtin_scorers`, and optimize-util `valid_data_for_builtin_scorers` are on-path and are exercised through real caller paths (`scorer`, `evaluate`, `validate_train_data`, `optimize_prompts`) rather than import-boundary-only assertions. Affected: R14, C16, C17, E1, E3, E4, E5.
- **Dataflow and lifecycle** — FAIL. The column-normalization check uses one saturated fixture and set-membership assertions; it cannot distinguish correct request->inputs/response->outputs mapping from swapped mapping, and it does not isolate the trace-inference or predict_fn->trace branches. Affected: R10, C11, E10.
- **Failure and compatibility** — WEAK. Non-list, invalid-item, non-dict-expectations, and missing-column logging checks are good, but the legacy `Metric` success-path fixture is malformed: the reference implementation reads `metric.name` while the stub defines no name. Affected: R8, C9, E13.
- **Static-issue closure strength** — PASS. No on-path static issue is closed by import-boundary-only assertion, and no static issue is dispositioned out of scope. Affected: R2, R14.
- **Chain integrity** — PASS. Public caller checks are paired with direct lower-layer checks for the validation helpers, and the decorator path checks force the local `CustomScorer` class to exist and delegate. Affected: E1, E3, E4, E5.
- **Repository-test alignment** — WEAK. Generated specs did not adapt the positive-return parametrization from `tests/genai/scorers/test_scorer.py:247-265`, the default metadata assertions from `tests/genai/scorers/test_scorer_description.py:27-44`, or the `.name` requirement of legacy metric-shaped objects. Affected: R4, R5, R8.
- **Oracle strength** — WEAK. Column-set membership is used where directional and branch-isolated observations are needed; the signature oracle is wrong for bound methods; legacy warning oracle cannot be reached by its own fixture. Affected: R3, R8, R10.

## Findings

### Finding 1
- **Type:** `requirement_misread`
- **Affected IDs:** R3, C3; `arch_check_decorator_call_signature_binding` (arch_spec.py:81-95); `behavior_check_scorer_partial_and_decorator_state` (behavior_spec.py:31-58)
- **Static issue:** `CustomScorer` in `mlflow/genai/scorers/base.py` (on-path)
- **Evidence:** `mlflow/genai/scorers/base.py:374-384` uses `inspect.signature(self.__call__)` to filter evaluator row fields. `base.py:1018-1025` sets `CustomScorer.__call__.__signature__` to a signature with `self` prepended. A Python 3.11 probe confirms `inspect.signature(instance.__call__)` on a bound method strips the first parameter, returning `(inputs, outputs)`, not `(self, inputs, outputs)`. The repository has no test expecting `self` in the bound signature.
- **Gap:** The specs assert a representation that a correct implementation does not produce. The generated checks would fail a faithful implementation.
- **Rework:** Assert `list(inspect.signature(instance.__call__).parameters) == ["inputs", "outputs"]` (the original function parameters), or if the `self`-prepended class signature must be observed, inspect the unbound class attribute `inspect.signature(type(instance).__call__)`.

### Finding 2
- **Type:** `weak_constraint`
- **Affected IDs:** R8, C9; `arch_check_validate_scorers_legacy_metric_import_boundary` (arch_spec.py:157-190); `behavior_check_legacy_metric_accept_and_reject` (behavior_spec.py:150-185)
- **Static issue:** None
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:90-95` builds `legacy_metric_names = [metric.name for metric in legacy_metrics]` before calling `_logger.warning`. Both specs define `class Metric: pass` and pass an instance with no `name` attribute.
- **Gap:** A correct implementation reaches `metric.name` and raises `AttributeError` before the warning is emitted. The generated success-path check cannot pass and does not observe the warning behavior it claims to cover.
- **Rework:** Give the stub `Metric` a `name` attribute (for example `name = "legacy_metric"` or set it on the instance) and assert the warning contains that name.

### Finding 3
- **Type:** `weak_constraint`
- **Affected IDs:** R10, C11; `arch_check_valid_data_normalizes_columns_dataflow` (arch_spec.py:224-257); `behavior_check_valid_data_normalizes_columns` (behavior_spec.py:231-259)
- **Static issue:** `valid_data_for_builtin_scorers` in `mlflow/genai/evaluation/base.py` and `mlflow/genai/optimize/util.py` (both on-path)
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:115-136` implements four independent transformations: rename `request`->`inputs`, rename `response`->`outputs`, add `outputs` when `predict_fn` is provided, add `inputs`/`outputs` when `trace` exists, and add `trace` when `predict_fn` is provided. The spec fixture contains `request`, `response`, `trace`, `expectations`, and a `predict_fn` all at once, then asserts only set membership.
- **Gap:** A wrong implementation that swaps `request`->`outputs` and `response`->`inputs`, omits the `trace` inference branch, or omits the `predict_fn`->`trace` branch would still satisfy the spec. The check does not isolate or directionally observe the dataflow.
- **Rework:** Replace the saturated fixture with separate spy cases: (a) `request`-only with no predict_fn/trace -> exactly `{"inputs"}`; (b) `response`-only -> exactly `{"outputs"}`; (c) `trace`-only with no predict_fn -> includes `trace`, `inputs`, `outputs`; (d) `request` + predict_fn with no trace -> includes `inputs`, `outputs`, `trace`. Assert exact sets, not just membership.

### Finding 4
- **Type:** `missing_requirement`
- **Affected IDs:** R4, C2
- **Static issue:** `CustomScorer` in `mlflow/genai/scorers/base.py` (on-path)
- **Evidence:** R4 requires `name=name or func.__name__` and unchanged `description`/`aggregations` forwarding. Repository tests `tests/genai/scorers/test_scorer_description.py:27-44` assert default `description is None` and custom name/description, and `tests/genai/scorers/test_scorer.py:61-71` assert metric name derives from the function name. Generated specs only exercise `@scorer` with explicit `name`, `description`, and `aggregations`; no check observes the no-parentheses default metadata.
- **Gap:** A plausible wrong implementation that always sets a fixed name or non-None description for `@scorer` would pass every generated check.
- **Rework:** Add a check for `@scorer` with no keyword arguments, asserting `name == func.__name__`, `description is None`, and `aggregations is None`.

### Finding 5
- **Type:** `missing_requirement`
- **Affected IDs:** R5, C4, C5
- **Static issue:** `CustomScorer` in `mlflow/genai/scorers/base.py` (on-path)
- **Evidence:** Interface Description 1 explicitly permits boolean, integer, float, string, single `Feedback`, and list of `Feedback` returns. The repository test `tests/genai/scorers/test_scorer.py:247-265` parametrizes `str`, `int`, `float`, `Feedback`, and `list[Feedback]` positive returns. Generated specs only observe boolean, `None`, and an invalid dict.
- **Gap:** A wrong implementation that accepts `bool` but rejects numeric, string, `Feedback`, or `list[Feedback]` would pass the generated specs, despite violating the task-supported accepted-return contract.
- **Rework:** Add a parametrized `Scorer.run` positive check covering `int`, `float`, `str`, `Feedback`, and `list[Feedback]`, mirroring `test_scorer_on_genai_evaluate`, in addition to the existing invalid-return check.

## Decision
Decision: REWORK
