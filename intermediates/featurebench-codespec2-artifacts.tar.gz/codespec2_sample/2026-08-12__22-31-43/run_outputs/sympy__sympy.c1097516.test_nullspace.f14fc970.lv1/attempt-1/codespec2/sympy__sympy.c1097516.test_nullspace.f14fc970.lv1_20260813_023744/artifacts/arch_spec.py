"""Architecture spec for DomainMatrix conversion/nullspace/primitive task.

This file compiles the path/connectivity half of the typed semantic IR into
executable runtime observations.  It is intentionally not a unit-test suite:
each check drives the real public DomainMatrix API through the repository
delegation chain and observes that the correct lower-level helper is reached.

Static-issue dispositions (see static_issues.md / semantic_ir.md):
- domainmatrix.py dup_content      : ON-PATH, closed by
  check_C16_primitive_reaches_dup_content.
- rref.py _dm_rref_den_FF         : ON-PATH through nullspace, closed by
  check_C11_zz_nullspace_default_reaches_dm_rref_den_FF.
- rref.py _dm_rref_choose_method_QQ: ON-PATH through nullspace, closed by
  check_C12_qq_nullspace_auto_reaches_choose_method_QQ.
- rref.py _dm_elements            : ON-PATH through nullspace, closed by
  check_C13_zz_auto_nullspace_reaches_dm_elements.
- rref.py ddm_irref               : ON-PATH through nullspace over RR, closed by
  check_C14_rr_nullspace_reaches_ddm_irref.
- sdm.py sdm_rref_den             : ON-PATH through nullspace over sparse ZZ,
  closed by check_C15_sparse_zz_nullspace_reaches_sdm_rref_den.
- sdm.py sdm_scalar_mul           : ON-PATH through DomainMatrix scalar
  multiplication, closed by
  check_C20_sparse_forward_scalar_mul_reaches_sdm_scalar_mul.
- ddm.py ddm_imul                 : ON-PATH through DomainMatrix scalar
  multiplication, closed by
  check_C20_dense_forward_scalar_mul_reaches_ddm_imul.
- domainmatrix.py dup_convert     : OUT-OF-SCOPE. Upward trace dead-ends at
  charpoly_base/charpoly_*; no task-required entry reaches it.
- sdm.py sdm_nullspace_from_rref  : OUT-OF-SCOPE. SDM.nullspace is reached only
  from DomainMatrix._solve; _solve is not a task-required public entry.
- Non-matrix polys issues          : OUT-OF-SCOPE.  No upward caller chain from
  DomainMatrix.nullspace/primitive/to_sdm/to_sparse reaches those units.
"""

from __future__ import annotations

import sys
from contextlib import contextmanager
from typing import Iterator, List, Tuple

ROOT = "/testbed"
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from sympy.external.gmpy import GROUND_TYPES  # noqa: E402
from sympy import QQ, ZZ, RR  # noqa: E402
from sympy.polys.matrices import DomainMatrix, DM  # noqa: E402
from sympy.polys.matrices.domainscalar import DomainScalar  # noqa: E402
from sympy.polys.matrices.sdm import SDM  # noqa: E402
import sympy.polys.matrices.domainmatrix as dm_mod  # noqa: E402
import sympy.polys.matrices.rref as rref_mod  # noqa: E402
import sympy.polys.matrices.sdm as sdm_mod  # noqa: E402
import sympy.polys.matrices.ddm as ddm_mod  # noqa: E402


@contextmanager
def spied_module_function(module: object, name: str) -> Iterator[List[Tuple[tuple, dict]]]:
    """Replace *module.name* with a recording wrapper that still calls the original.

    The original implementation remains live; the wrapper is only an observer.
    """
    original = getattr(module, name)
    calls: List[Tuple[tuple, dict]] = []

    def observer(*args, **kwargs):
        calls.append((args, kwargs))
        return original(*args, **kwargs)

    setattr(module, name, observer)
    try:
        yield calls
    finally:
        setattr(module, name, original)


@contextmanager
def spied_class_method(cls: type, name: str) -> Iterator[List[Tuple[tuple, dict]]]:
    """Replace a normal class method with a recording wrapper that calls the original."""
    original = getattr(cls, name)
    calls: List[Tuple[tuple, dict]] = []

    def observer(self, *args, **kwargs):
        calls.append((args, kwargs))
        return original(self, *args, **kwargs)

    setattr(cls, name, observer)
    try:
        yield calls
    finally:
        setattr(cls, name, original)


def _pivots_from_dm(A: DomainMatrix) -> tuple:
    """Return pivots for an already-reduced DomainMatrix."""
    sdm = A.to_sdm()
    if not sdm:
        return ()
    return tuple(sorted(map(min, sdm.values())))


def _check_rref_den_cancel(result, rref_ans: DomainMatrix, den_ans) -> None:
    """Assert an rref_den result equals the canonical repository-test oracle."""
    rref, den, pivots = result
    rref_c, den_c = rref.cancel_denom(den)
    assert rref_c.domain == rref_ans.domain
    assert rref_c.shape == rref_ans.shape
    assert rref_c.to_list() == rref_ans.to_list()
    assert den_c == den_ans
    assert tuple(pivots) == _pivots_from_dm(rref_c)


def check_public_api_surface():
    """# Contracts: R1,R2,R3,R4,R5,R6 (public scope) and task obligation 2.

    Repository-test guidance: sympy/polys/matrices/tests/test_xxm.py and
    test_domainmatrix.py import DomainMatrix/DM and call these methods.
    Perspective: the supported public surface must expose callable methods,
    including element access used by test_DomainMatrix_getitem.
    Source path/symbol: sympy.polys.matrices.DomainMatrix.
    """
    for name in (
        "__getitem__",
        "to_sdm",
        "to_sparse",
        "nullspace",
        "nullspace_from_rref",
        "primitive",
    ):
        method = getattr(DomainMatrix, name, None)
        assert callable(method), f"DomainMatrix.{name} is not callable"


def check_C1_to_sdm_delegation_dense_and_sparse():
    """# Contracts: C1; obligations R1,R7.

    Repository-test guidance: test_xxm.py::test_to_XXM expects
    DomainMatrix.to_sdm() == SDM.to_sdm() for dense and sparse reps.
    Perspective: representation conversion must delegate to the wrapped rep and
    return the real SDM object, preserving data.
    Source path/symbol: DomainMatrix.to_sdm -> DDM.to_sdm / SDM.to_sdm.
    """
    A_dense = DomainMatrix([[QQ(1), QQ(0)], [QQ(0), QQ(2)]], (2, 2), QQ)
    sdm_dense = A_dense.to_sdm()
    assert type(sdm_dense) is SDM
    assert dict(sdm_dense) == {0: {0: QQ(1)}, 1: {1: QQ(2)}}
    assert sdm_dense.shape == A_dense.shape
    assert sdm_dense.domain == A_dense.domain

    A_sparse = DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    sdm_sparse = A_sparse.to_sdm()
    assert type(sdm_sparse) is SDM
    assert dict(sdm_sparse) == {0: {0: QQ(1)}, 1: {1: QQ(2)}}


def check_C2_C3_to_sparse_delegation_and_identity():
    """# Contracts: C2,C3; obligations R2,R7.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_to_sparse
    asserts dense->sparse rep conversion; the interface doc requires identity
    for an already sparse DomainMatrix.
    Perspective: to_sparse is a stateful representation transition with exact
    identity semantics for the sparse case.
    Source path/symbol: DomainMatrix.to_sparse -> DDM/SDM/DFM.to_sdm ->
    DomainMatrix.from_rep; sparse identity branch returns self.
    """
    A_dense = DomainMatrix([[QQ(1), QQ(0)], [QQ(0), QQ(2)]], (2, 2), QQ)
    B = A_dense.to_sparse()
    assert isinstance(B, DomainMatrix)
    assert type(B.rep) is SDM
    assert dict(B.rep) == {0: {0: QQ(1)}, 1: {1: QQ(2)}}

    A_sparse = DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    assert A_sparse.rep.fmt == "sparse"
    assert A_sparse.to_sparse() is A_sparse


def check_C4_to_sdm_to_sparse_preserve_shape_domain():
    """# Contracts: C4; obligations R1,R2,R7.

    Repository-test guidance: test_xxm.py::test_to_XXM and
    test_domainmatrix.py::test_DomainMatrix_to_sparse compare repr and value
    while keeping the original domain/shape.
    Perspective: representation conversion must be metadata-preserving.
    Source path/symbol: DomainMatrix.to_sdm / DomainMatrix.to_sparse.
    """
    matrices = [
        DomainMatrix([[QQ(1), QQ(0)], [QQ(0), QQ(2)]], (2, 2), QQ),
        DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ),
    ]
    for A in matrices:
        sdm = A.to_sdm()
        assert sdm.shape == A.shape
        assert sdm.domain == A.domain
        sparse = A.to_sparse()
        assert sparse.shape == A.shape
        assert sparse.domain == A.domain


def check_C5_C6_nullspace_full_delegation_chain():
    """# Contracts: C5,C6; obligations R3,R6,R9.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_nullspace
    calls public nullspace and checks the returned basis for field and ring.
    Perspective: public nullspace must actually delegate through rref_den and
    nullspace_from_rref (not reimplement a parallel path).
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    DomainMatrix.nullspace_from_rref.
    """
    q = DM([[2, -2], [4, -4]], QQ)
    z = DM([[6, -3], [4, -2]], ZZ)

    with spied_class_method(DomainMatrix, "rref_den") as rref_calls, \
         spied_class_method(DomainMatrix, "nullspace_from_rref") as nf_calls:
        q_null = q.nullspace()
        z_null = z.nullspace()

    assert len(rref_calls) == 2, f"rref_den call count = {len(rref_calls)}"
    assert len(nf_calls) == 2, f"nullspace_from_rref call count = {len(nf_calls)}"
    assert q_null.to_list() == [[1, 1]]
    assert z_null.to_list() == [[3, 6]]


def check_C11_zz_nullspace_default_reaches_dm_rref_den_FF():
    """# Contracts: C11; obligations R3,R8.

    Repository-test guidance: test_rref.py RREF_EXAMPLES['zz_19'] gives the
    exact cancelled rref_den oracle for DM([[1,2,4],[4,5,6]], ZZ); the derived
    nullspace is DM([[8,-10,3]], ZZ).  static_issues.md flags
    rref.py _dm_rref_den_FF as undefined.
    Perspective: the default ZZ fraction-free path must be reached through the
    task-required nullspace entry and must produce the exact documented basis.
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    rref._dm_rref_den -> rref._dm_rref_den_FF.
    """
    A = DM([[1, 2, 4], [4, 5, 6]], ZZ)
    with spied_module_function(rref_mod, "_dm_rref_den_FF") as calls:
        null = A.nullspace()
        result = A.rref_den()

    assert calls, "_dm_rref_den_FF was not reached from DomainMatrix.nullspace"
    assert null.domain == ZZ
    assert null.shape == (1, 3)
    assert null.to_list() == [[8, -10, 3]]
    _check_rref_den_cancel(result, DM([[3, 0, -8], [0, 3, 10]], ZZ), ZZ(3))


def check_C12_qq_nullspace_auto_reaches_choose_method_QQ():
    """# Contracts: C12; obligations R3,R8.

    Repository-test guidance: test_rref.py RREF_EXAMPLES['qq_3'] gives the
    exact cancelled rref_den oracle for DM([[1,2,1],[3,4,1]], QQ); the derived
    nullspace is DM([[1,-1,1]], QQ).  static_issues.md flags
    _dm_rref_choose_method_QQ in rref.py.
    Perspective: QQ auto dispatch must be reached through nullspace and return
    the exact basis.
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    rref._dm_rref_den -> rref._dm_rref_choose_method ->
    rref._dm_rref_choose_method_QQ.
    """
    A = DM([[1, 2, 1], [3, 4, 1]], QQ)
    with spied_module_function(rref_mod, "_dm_rref_choose_method_QQ") as calls:
        null = A.nullspace()
        result = A.rref_den()

    assert calls, "_dm_rref_choose_method_QQ was not reached from DomainMatrix.nullspace"
    assert null.domain == QQ
    assert null.shape == (1, 3)
    assert null.to_list() == [[1, -1, 1]]
    _check_rref_den_cancel(result, DM([[1, 0, -1], [0, 1, 1]], QQ), QQ(1))


def check_C13_zz_auto_nullspace_reaches_dm_elements():
    """# Contracts: C13; obligations R3,R8.

    Repository-test guidance: test_rref.py documents the ZZ auto-method switch
    and the threshold branch that requires bit lengths.  A 10x10 matrix with
    density 6 per nonzero row and large entries reaches _dm_elements before FF
    is selected.  The expected reduced row is the all-ones/zero canonical
    cancellation of the rank-one FF result.
    Perspective: the bit-length threshold branch must execute _dm_elements and
    the public nullspace must still produce a valid 9-dimensional basis.
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    rref._dm_rref_den -> rref._dm_rref_choose_method ->
    rref._dm_rref_choose_method_ZZ -> rref._dm_elements.
    """
    large = ZZ(1 << 40)
    rows = [[large] * 6 + [ZZ(0)] * 4 for _ in range(10)]
    A = DomainMatrix(rows, (10, 10), ZZ)

    with spied_module_function(rref_mod, "_dm_elements") as calls:
        null = A.nullspace()
        result = A.rref_den()

    assert calls, "_dm_elements was not reached from DomainMatrix.nullspace"
    assert null.domain == ZZ
    assert null.shape == (9, 10)

    expected_rref = DomainMatrix(
        [[ZZ(1)] * 6 + [ZZ(0)] * 4] + [[ZZ(0)] * 10 for _ in range(9)],
        (10, 10),
        ZZ,
    )
    _check_rref_den_cancel(result, expected_rref, ZZ(1))


def check_C14_rr_nullspace_reaches_ddm_irref():
    """# Contracts: C14; obligations R8,R9.

    Repository-test guidance: test_rref.py imports ddm_irref from
    sympy.polys.matrices.dense; rref.py routes RR/CC to dense GJ.
    Perspective: approximate-domain RREF must reach the dense GJ implementation
    and its ddm_irref helper through the public nullspace entry.
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    rref._dm_rref_den -> rref._dm_rref_GJ_dense -> rref.ddm_irref.
    """
    A = DomainMatrix(
        [[RR(1.0), RR(2.0)], [RR(2.0), RR(4.0)]], (2, 2), RR
    )
    with spied_module_function(rref_mod, "ddm_irref") as calls:
        null = A.nullspace()
        result = A.rref_den()

    assert calls, "ddm_irref was not reached from DomainMatrix.nullspace over RR"
    assert null.domain == RR
    assert null.shape == (1, 2)
    assert null.to_list() == [[RR(-2.0), RR(1.0)]]

    rref, den, pivots = result
    assert tuple(pivots) == (0,)
    assert den == RR.one
    assert rref.to_list() == [[RR(1.0), RR(2.0)], [RR(0.0), RR(0.0)]]


def check_C15_sparse_zz_nullspace_reaches_sdm_rref_den():
    """# Contracts: C15; obligations R3,R8.

    Repository-test guidance: test_rref.py imports sdm_rref_den from
    sympy.polys.matrices.sdm; static_issues.md flags sdm.py sdm_rref_den.
    Perspective: sparse FF rref_den must be reached through nullspace and its
    helper must return the exact zz_19 basis.
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    rref._dm_rref_den -> rref._dm_rref_den_FF -> SDM.rref_den ->
    sdm.sdm_rref_den.
    """
    A = DM([[1, 2, 4], [4, 5, 6]], ZZ).to_sparse()
    with spied_module_function(sdm_mod, "sdm_rref_den") as calls:
        null = A.nullspace()
        result = A.rref_den()

    assert calls, "sdm_rref_den was not reached from DomainMatrix.nullspace over sparse ZZ"
    assert null.domain == ZZ
    assert null.shape == (1, 3)
    assert null.to_list() == [[8, -10, 3]]
    _check_rref_den_cancel(result, DM([[3, 0, -8], [0, 3, 10]], ZZ), ZZ(3))


def check_C16_primitive_reaches_dup_content():
    """# Contracts: C16; obligations R5.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_content_primitive
    calls content() and primitive() over ZZ.
    Perspective: primitive must itself reach densetools.dup_content; a separate
    M.content() call must not be able to satisfy this observation.
    Source path/symbol: DomainMatrix.primitive -> DomainMatrix.content ->
    domainmatrix.dup_content.
    """
    M = DM([[2, 4], [4, 12]], ZZ)
    with spied_module_function(dm_mod, "dup_content") as calls:
        content, primitive = M.primitive()

    assert calls, "primitive did not reach dup_content"
    assert content == ZZ(2)
    assert primitive.domain == ZZ
    assert primitive.shape == M.shape
    assert primitive.to_list() == [[1, 2], [2, 6]]
    assert primitive.content() == ZZ(1)


def check_C17_primitive_product_reaches_domainmatrix_scalarmul():
    """# Contracts: C17; obligations R5.

    Repository-test guidance: the primitive interface requires
    content * primitive == self, so the product must drive the real
    DomainMatrix scalar-multiplication route.
    Perspective: observe DomainMatrix._scalarmul during the required product,
    rather than only checking the reconstructed value.
    Source path/symbol: DomainMatrix.__rmul__ -> DomainMatrix.rscalarmul ->
    DomainMatrix._scalarmul.
    """
    M = DM([[2, 4], [4, 12]], ZZ)
    content, primitive = M.primitive()
    with spied_class_method(DomainMatrix, "_scalarmul") as calls:
        rebuilt = content * primitive

    assert calls, "_scalarmul was not reached from content * primitive"
    assert rebuilt == M


def check_C20_dense_forward_scalar_mul_reaches_ddm_imul():
    """# Contracts: C20; obligations R5 and static issue ddm.py ddm_imul.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_scalarmul
    checks A * 2 and A * DomainScalar for a dense DomainMatrix.
    Perspective: forward dense scalar multiplication must call DDM.mul and its
    ddm_imul helper, not a bypassing elementwise implementation.
    Source path/symbol: DomainMatrix.__mul__ -> DomainMatrix._scalarmul ->
    DDM.mul -> ddm.ddm_imul.
    """
    A = DM([[1, 2], [3, 4]], ZZ)
    with spied_module_function(ddm_mod, "ddm_imul") as calls:
        B = A * 2

    assert calls, "ddm_imul was not reached from dense DomainMatrix scalar multiplication"
    assert B.to_list() == [[2, 4], [6, 8]]


def check_C20_sparse_forward_scalar_mul_reaches_sdm_scalar_mul():
    """# Contracts: C20; obligations R5 and static issue sdm.py sdm_scalar_mul.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_scalarmul
    and test_DomainMatrix_truediv exercise scalar multiplication on sparse
    results.  SDM.mul and SDM.rmul both call sdm_scalar_mul.
    Perspective: sparse scalar multiplication must call SDM.mul/rmul and its
    sdm_scalar_mul helper through the real public operator.
    Source path/symbol: DomainMatrix.__mul__/__rmul__ ->
    DomainMatrix._scalarmul -> SDM.mul/SDM.rmul -> sdm.sdm_scalar_mul.
    """
    A = DomainMatrix({0: {0: ZZ(1)}, 1: {1: ZZ(2)}}, (2, 2), ZZ)
    with spied_module_function(sdm_mod, "sdm_scalar_mul") as calls:
        B = A * 2

    assert calls, "sdm_scalar_mul was not reached from sparse DomainMatrix scalar multiplication"
    assert B.to_list() == [[2, 0], [0, 4]]


def check_C18_getitem_delegates_to_rep_getitem_and_extract_slice():
    """# Contracts: C18; task obligation 2.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_getitem
    checks scalar indexing, slicing, and IndexError.
    Perspective: DomainMatrix.__getitem__ must delegate scalar access to
    rep.getitem and submatrix extraction to rep.extract_slice.
    Source path/symbol: DomainMatrix.__getitem__ -> DDM.getitem /
    DDM.extract_slice (or SDM equivalents).
    """
    A = DomainMatrix([[ZZ(1), ZZ(2)], [ZZ(3), ZZ(4)]], (2, 2), ZZ)
    with spied_class_method(type(A.rep), "getitem") as get_calls, \
         spied_class_method(type(A.rep), "extract_slice") as slice_calls:
        scalar = A[0, 1]
        submatrix = A[:, :1]

    assert get_calls, "rep.getitem was not reached from DomainMatrix scalar indexing"
    assert slice_calls, "rep.extract_slice was not reached from DomainMatrix slicing"
    assert scalar == DomainScalar(ZZ(2), ZZ)
    assert submatrix.to_list() == [[1], [3]]


def check_C19_dfm_conversion_when_flint():
    """# Contracts: C19; obligations R1,R2,R7.

    Repository-test guidance: test_xxm.py::test_to_XXM conditionally includes
    DFM when GROUND_TYPES == 'flint'.
    Perspective: when python-flint is active, DomainMatrix.to_sdm and
    DomainMatrix.to_sparse must convert a DFM-backed matrix through DFM.to_sdm
    and preserve type, values, shape, and domain.
    Source path/symbol: DomainMatrix.to_sdm/to_sparse -> DFM.to_sdm.
    """
    if GROUND_TYPES != "flint":
        return

    from sympy.polys.matrices.domainmatrix import DFM

    A = DomainMatrix([[ZZ(1), ZZ(2)], [ZZ(3), ZZ(4)]], (2, 2), ZZ)
    assert type(A.rep) is DFM

    sdm = A.to_sdm()
    assert type(sdm) is SDM
    assert dict(sdm) == {0: {0: ZZ(1), 1: ZZ(2)}, 1: {0: ZZ(3), 1: ZZ(4)}}
    assert sdm.shape == A.shape
    assert sdm.domain == A.domain

    sparse = A.to_sparse()
    assert type(sparse.rep) is SDM
    assert sparse.to_list() == [[1, 2], [3, 4]]
    assert sparse.shape == A.shape
    assert sparse.domain == A.domain


def main() -> None:
    checks = [
        check_public_api_surface,
        check_C1_to_sdm_delegation_dense_and_sparse,
        check_C2_C3_to_sparse_delegation_and_identity,
        check_C4_to_sdm_to_sparse_preserve_shape_domain,
        check_C5_C6_nullspace_full_delegation_chain,
        check_C11_zz_nullspace_default_reaches_dm_rref_den_FF,
        check_C12_qq_nullspace_auto_reaches_choose_method_QQ,
        check_C13_zz_auto_nullspace_reaches_dm_elements,
        check_C14_rr_nullspace_reaches_ddm_irref,
        check_C15_sparse_zz_nullspace_reaches_sdm_rref_den,
        check_C16_primitive_reaches_dup_content,
        check_C17_primitive_product_reaches_domainmatrix_scalarmul,
        check_C20_dense_forward_scalar_mul_reaches_ddm_imul,
        check_C20_sparse_forward_scalar_mul_reaches_sdm_scalar_mul,
        check_C18_getitem_delegates_to_rep_getitem_and_extract_slice,
        check_C19_dfm_conversion_when_flint,
    ]
    failures = 0
    for check in checks:
        name = check.__name__
        try:
            check()
            print(f"PASS: {name}")
        except Exception as exc:  # noqa: BLE001 - report all contract failures
            failures += 1
            print(f"FAIL: {name}: {type(exc).__name__}: {exc}")
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
