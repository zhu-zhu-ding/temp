# Spec Review Report

## Evidence Reviewed

Artifacts:
- `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260813_023744/artifacts/semantic_ir.md`
- `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260813_023744/artifacts/arch_spec.py`
- `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260813_023744/artifacts/behavior_spec.py`
- `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260813_023744/artifacts/static_issues.md`
- `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260813_023744/artifacts/static_analysis.md`
- `/installed-agent/codespec2/review_skill.md`

Repository source:
- `sympy/polys/matrices/domainmatrix.py` (`__new__`, `__getitem__`, `to_dense`, `to_ddm`, `content`, `rref_den`, `rscalarmul`, `__rmul__`, `__truediv__`, `_solve`)
- `sympy/polys/matrices/rref.py` (`_dm_rref_den`, `_dm_rref_GJ_dense`, `_dm_rref_choose_method`, `_dm_rref_choose_method_ZZ`)
- `sympy/polys/matrices/sdm.py` (`to_sdm`, `mul`, `rmul`, `rref_den`, `nullspace`, `nullspace_from_rref`)
- `sympy/polys/matrices/ddm.py` (`to_sdm`, `mul`, `rmul`, `rref`, `rref_den`, `nullspace`, `nullspace_from_rref`)
- `sympy/polys/matrices/dense.py` (missing `ddm_irref`)
- `sympy/polys/matrices/linsolve.py` (missing `sdm_nullspace_from_rref` call path)
- `sympy/polys/matrices/__init__.py` (exports `DomainMatrix`, `DM`)

Repository tests:
- `sympy/polys/matrices/tests/test_domainmatrix.py::test_DomainMatrix_to_sparse`
- `sympy/polys/matrices/tests/test_domainmatrix.py::test_DomainMatrix_content_primitive`
- `sympy/polys/matrices/tests/test_domainmatrix.py::test_DomainMatrix_nullspace`
- `sympy/polys/matrices/tests/test_domainmatrix.py::test_DomainMatrix_scalarmul`
- `sympy/polys/matrices/tests/test_domainmatrix.py::test_DomainMatrix_truediv`
- `sympy/polys/matrices/tests/test_xxm.py::test_to_XXM`
- `sympy/polys/matrices/tests/test_rref.py` (RREF examples and direct `ddm_irref` / `sdm_rref_den` tests)

## Rubric Scores

### Requirement coverage
Score: FAIL

Evidence: The task statement lists five core obligations. Element access/slicing with bounds checking is task obligation 2, but the semantic IR has no R/G/C record for `DomainMatrix.__getitem__` or slicing, and neither spec observes it. The IR explicitly covers DDM/SDM/DFM conversion in R1/R2, but the specs never exercise the DFM branch; `test_xxm.py::test_to_XXM` does so conditionally with `GROUND_TYPES == 'flint'`. The interface-documented polynomial-ring nullspace example is also absent.

Affected R/E/C IDs: unassigned task obligation (element access); R1, R2, R3, R9; C1, C2, C4, C5, C6.

### Requirement fidelity
Score: FAIL

Evidence: `arch_spec.py::check_C1_to_sdm_delegation_dense_and_sparse` asserts `sdm_sparse is A_sparse.rep`. The interface description for `to_sdm` only requires returning an SDM representation; repository `test_xxm.py::test_to_XXM` asserts equality, not identity. This is a guessed stronger behavior.

Affected R/E/C IDs: R1; E1; C1.

### Caller binding and architecture
Score: FAIL

Evidence: The on-path RREF static-issue checks (`C11`-`C15`) call `DomainMatrix.rref_den()` directly rather than the task-required `DomainMatrix.nullspace()` entry. `check_C5_C6_nullspace_full_delegation_chain` does call `nullspace()`, but spies only `DomainMatrix.rref_den` and `DomainMatrix.nullspace_from_rref`, not the unresolved lower helpers. `check_C16_primitive_content_reaches_dup_content` conflates a separate `M.content()` call with `M.primitive()`, so it does not prove the `primitive -> content/dup_content` CALL edge. The scalar-multiplication path required by `content * M_primitive == M` has no rep-level observer.

Affected R/E/C IDs: R3, R5, R8; E4, E5, E8, E9, E17, E18, E19, E20; C11-C17.

### Dataflow and lifecycle
Score: PARTIAL

Evidence: `to_sparse` dense-to-sparse state transition and sparse identity are well observed (`C2`, `C3`). `to_sdm` value/shape/domain preservation is observed, but the DFM representation transition is not. The sparse `to_sdm` identity assertion is not task-supported.

Affected R/E/C IDs: R1, R2; E1, E2, E3; C1-C4.

### Failure and compatibility
Score: PARTIAL

Evidence: `check_C7_nullspace_divide_last_nonfield_raises_DMNotAField` checks the exact exception class and diagnostic. However `check_C8_nullspace_divide_last_field_normalizes_final_entries` uses a fixture whose unnormalized nullspace already ends in the field unit, so an implementation that ignores `divide_last=True` still passes.

Affected R/E/C IDs: R4; E7; C7, C8.

### Static-issue closure strength
Score: FAIL

Evidence: The rref.py/sdm.py/ddm.py on-path static issues are not closed by a check that both enters the task-required `DomainMatrix.nullspace` entry and observes the specific missing helper. Several checks assert only a three-tuple and a pivot, not an exact RREF/denominator result. `sdm_scalar_mul` and `ddm_imul` are left as “out-of-scope with uncertainty” even though `C17` makes scalar multiplication task-critical.

Affected R/E/C IDs: R3, R5, R8; C11-C17. Static issues: `rref.py _dm_rref_den_FF`, `rref.py _dm_rref_choose_method_QQ`, `rref.py _dm_elements`, `rref.py ddm_irref`, `ddm.py ddm_irref`, `sdm.py sdm_rref_den`, `sdm.py sdm_scalar_mul`, `ddm.py ddm_imul`.

### Chain integrity
Score: FAIL

Evidence: No single check travels from `DomainMatrix.nullspace` through `DomainMatrix.rref_den` through the selected RREF helper and observes that helper. The `C11`-`C15` checks enter at `rref_den`, bypassing the task-required `nullspace` layer. The `C16` check observes `dup_content` but cannot distinguish a primitive path from a separate content path. The `C17` check observes the scalar-product outcome but does not observe `_scalarmul`, `DDM.mul`, `SDM.mul`, or their missing helpers.

Affected R/E/C IDs: R3, R5, R8; E4, E5, E8, E9, E17, E18, E19, E20; C5, C6, C11-C17.

### Repository-test alignment
Score: PARTIAL

Evidence: The specs reuse useful fixtures from `test_domainmatrix.py::test_DomainMatrix_nullspace`, `test_DomainMatrix_content_primitive`, and `test_xxm.py::test_to_XXM`. They miss the conditional DFM branch in `test_to_XXM`, the direct scalar-mul/truediv behavior in `test_DomainMatrix_scalarmul`/`test_DomainMatrix_truediv`, and the exact `rref_den`/`ddm_irref`/`sdm_rref_den` oracles in `test_rref.py`.

Affected R/E/C IDs: R1, R2, R5, R8; C1, C2, C11-C17.

### Oracle strength
Score: PARTIAL

Evidence: `C5`, `C6`, `C9`, `C10`, and `C17` use exact values and are strong. `C8` cannot distinguish normalization from no-op. `C11`-`C15` are mostly call-was-reached plus tuple-length assertions, which do not rule out incorrect helper outputs.

Affected R/E/C IDs: R4, R8; C8, C11-C15.

## Findings

### Finding 1
Type: `missing_requirement`

Affected IDs: None assigned in IR (task obligation 2).

Static issue: None.

Repository source/test evidence: Task statement core obligation 2 requires indexing and slicing with bounds checking. `sympy/polys/matrices/domainmatrix.py:203-226` already contains `__getitem__` with slice/index handling and bounds checks.

Gap: The semantic IR and both specs contain no observation for element access, so this task obligation is not compiled or tested.

Rework instruction: Add an IR requirement and behavior check for `DomainMatrix.__getitem__` scalar retrieval, row/column slicing, and out-of-range `IndexError`, or explicitly record why the existing implementation is out of scope.

### Finding 2
Type: `missing_requirement`

Affected IDs: R1, R2; E1, E2; C1, C2, C4.

Static issue: None.

Repository source/test evidence: `semantic_ir.md` R1/R2 require conversion regardless of DDM/SDM/DFM, and `sympy/polys/matrices/tests/test_xxm.py::test_to_XXM` conditionally includes `DFM` when `GROUND_TYPES == 'flint'`.

Gap: Neither spec constructs a `DFM` or tests `DFM.to_sdm`/`DomainMatrix.to_sparse` behavior. The DFM edge is untested, so a broken DFM conversion path passes.

Rework instruction: Add a conditional check analogous to `test_to_XXM`: when `GROUND_TYPES == 'flint'`, construct a `DFM`, call `to_sdm`/`to_sparse`, and assert exact type, value, shape, and domain preservation.

### Finding 3
Type: `weak_constraint`

Affected IDs: R3, R8; E4, E5, E17, E18, E19; C11, C12, C13, C14, C15.

Static issue: `rref.py _dm_rref_den_FF`, `rref.py _dm_rref_choose_method_QQ`, `rref.py _dm_elements`, `rref.py ddm_irref`, `ddm.py ddm_irref`, `sdm.py sdm_rref_den`.

Repository source/test evidence: The upward traces are `DomainMatrix.nullspace -> DomainMatrix.rref_den -> _dm_rref_den -> ... -> missing helper`. `sympy/polys/matrices/tests/test_domainmatrix.py::test_DomainMatrix_nullspace` enters through `DomainMatrix.nullspace`; `test_rref.py` supplies exact RREF/den oracles and direct helper imports.

Gap: `arch_spec.py` checks `C11`-`C15` call `DomainMatrix.rref_den()` directly rather than `DomainMatrix.nullspace()`. `check_C5_C6_nullspace_full_delegation_chain` enters through `nullspace()` but does not spy the missing lower helper. The checks also assert mostly a three-tuple/pivot rather than exact RREF/denominator values. A wrong helper that returns a tuple can pass.

Rework instruction: For each on-path helper, wrap the call to `A.nullspace()` in a spy on that exact helper and assert both that the helper was reached and the exact nullspace/RREF result from the repository test. Add exact RREF/den oracles for `rref_den` paths or reuse `_check_cancel` from `test_rref.py`.

### Finding 4
Type: `weak_constraint`

Affected IDs: R4; E7; C8.

Static issue: None.

Repository source/test evidence: `behavior_spec.py::check_C8_nullspace_divide_last_field_normalizes_final_entries` uses `DM([[QQ(1), QQ(2)], [QQ(2), QQ(4)]], QQ)`; for this matrix the unnormalized nullspace row already ends in `QQ.one`, so the final-entry assertion does not require any division.

Gap: A `nullspace` implementation that ignores `divide_last=True` passes the check.

Rework instruction: Select a field-domain fixture whose unnormalized nullspace vector has a nonzero non-unit final entry, assert the unnormalized result differs from the normalized result, and assert the exact normalized row values, not only that the final entry is one.

### Finding 5
Type: `missing_requirement`

Affected IDs: R3, R9; C5, C6.

Static issue: None.

Repository source/test evidence: The Interface Description for `nullspace` documents `A * A_null == zero`, `A_null.shape == (cols, nullity)`, and the polynomial-ring example over `ZZ[a,b,c]`. The current behavior spec checks only two small exact bases.

Gap: The algebraic product identity, nullity shape relation, and polynomial-ring compatibility are not observed. A basis that matches the two examples but fails the general nullspace contract could pass.

Rework instruction: Add checks that compute `A * nullspace.transpose()` and assert the zero matrix, assert `nullspace.transpose().shape == (cols, rows - rank)`, and add the documented `ZZ[a,b,c]` nullspace example to behavior spec.

### Finding 6
Type: `weak_constraint`

Affected IDs: R5; E8, E9; C16.

Static issue: `domainmatrix.py dup_content`.

Repository source/test evidence: `arch_spec.py::check_C16_primitive_content_reaches_dup_content` calls `M.content()` and then `M.primitive()[0]` in one spy context and only asserts `calls` is nonempty.

Gap: The check cannot distinguish a primitive implementation that calls `content()`/`dup_content` from one that computes the content another way, because the separate `M.content()` call alone satisfies `calls`. The `primitive -> content` CALL edge is not observed.

Rework instruction: Spy `dup_content` (or `DomainMatrix.content`) around only `M.primitive()`, and assert that the primitive call itself reaches `dup_content`. Keep a separate content check for the existing `DomainMatrix.content`.

### Finding 7
Type: `weak_constraint`

Affected IDs: R5; E20, N30; C17.

Static issue: `sdm.py sdm_scalar_mul`, `ddm.py ddm_imul`.

Repository source/test evidence: `behavior_spec.py::check_C17_primitive_product_identity_and_unit_content` executes `content * primitive`. Repository `sympy/polys/matrices/tests/test_domainmatrix.py::test_DomainMatrix_scalarmul` and `test_DomainMatrix_truediv` exercise scalar multiplication. The current `DomainMatrix.__rmul__ -> rscalarmul -> _scalarmul` route is incomplete, and the rep-level `mul`/`rmul` methods call the missing helpers.

Gap: The specs leave `sdm_scalar_mul` and `ddm_imul` as “out-of-scope with uncertainty” and provide only an outcome check. No check observes `_scalarmul`, `DDM.mul`, `SDM.mul`, or the missing rep helper through the required product. If a different scalar path is used, the missing helpers can remain unresolved while `C17` passes.

Rework instruction: Add an architecture check that spies `DomainMatrix._scalarmul` (or the corresponding rep `mul`/`rmul` helper) during `content * primitive`, and add behavior coverage for `DomainMatrix` scalar multiplication using the existing repository scalar-mul/truediv tests.

### Finding 8
Type: `requirement_misread`

Affected IDs: R1; E1; C1.

Static issue: None.

Repository source/test evidence: Interface Description for `to_sdm` says only “Return a SDM representation of self.” `sympy/polys/matrices/tests/test_xxm.py::test_to_XXM` asserts `A.to_sdm() == A_sdm`, not identity. `arch_spec.py::check_C1_to_sdm_delegation_dense_and_sparse` asserts `sdm_sparse is A_sparse.rep`.

Gap: The spec adds an identity requirement that the task and repository test do not support. A conforming implementation returning an equal SDM copy for sparse input would be rejected.

Rework instruction: Replace the sparse `is` assertion with `type(...) is SDM` and equality/field checks, unless the interface is updated to require identity explicitly.

## Decision

Decision: REWORK
