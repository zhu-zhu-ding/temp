"""Behavior spec for DomainMatrix conversion/nullspace/primitive task.

This file compiles the observable-outcome half of the typed semantic IR.  Each
check starts at the task-required public entry and asserts exact values,
types, state/identity semantics, failure semantics, or boundary behavior.

Static-issue dispositions are mirrored in arch_spec.py.  In this file:
- C16/C17 close the observable side of domainmatrix.py dup_content and the
  scalar-multiplication uncertainty (sdm_scalar_mul / ddm_imul).
- C20 adds explicit scalar-multiplication/truediv behavior from the repository
  tests.
- C21/C22 add the documented nullspace product/nullity and polynomial-ring
  examples.
- Non-matrix polys issues and the charpoly-only dup_convert path do not have a
  task-required public caller and are intentionally not compiled here.
"""

from __future__ import annotations

import sys

ROOT = "/testbed"
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from sympy.external.gmpy import GROUND_TYPES  # noqa: E402
from sympy import Matrix, QQ, ZZ  # noqa: E402
from sympy.polys.matrices import DomainMatrix, DM  # noqa: E402
from sympy.polys.matrices.domainscalar import DomainScalar  # noqa: E402
from sympy.polys.matrices.exceptions import DMNotAField  # noqa: E402
from sympy.polys.matrices.sdm import SDM  # noqa: E402


def _assert_raises(exc_type, func, context=""):
    try:
        func()
    except exc_type:
        return
    except Exception as exc:  # noqa: BLE001 - preserve original failure in message
        raise AssertionError(
            f"{context}: expected {exc_type.__name__}, got {type(exc).__name__}: {exc}"
        ) from exc
    raise AssertionError(f"{context}: {exc_type.__name__} was not raised")


def check_C1_to_sdm_returns_sdm_with_preserved_values():
    """# Contracts: C1; obligations R1,R7.

    Repository-test guidance: test_xxm.py::test_to_XXM compares
    DomainMatrix.to_sdm() against a constructed SDM.
    Perspective: exact return type plus exact dict/values, shape, and domain.
    Source path/symbol: DomainMatrix.to_sdm.
    """
    A = DomainMatrix([[QQ(1), QQ(0)], [QQ(0), QQ(2)]], (2, 2), QQ)
    sdm = A.to_sdm()
    assert type(sdm) is SDM
    assert sdm == SDM({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    assert dict(sdm) == {0: {0: QQ(1)}, 1: {1: QQ(2)}}
    assert sdm.shape == (2, 2)
    assert sdm.domain == QQ

    A_sparse = DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    sdm_sparse = A_sparse.to_sdm()
    assert type(sdm_sparse) is SDM
    assert dict(sdm_sparse) == {0: {0: QQ(1)}, 1: {1: QQ(2)}}
    assert sdm_sparse.shape == (2, 2)
    assert sdm_sparse.domain == QQ


def check_C2_to_sparse_converts_dense_representation():
    """# Contracts: C2; obligations R2,R7.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_to_sparse
    asserts A.to_sparse().rep == expected sparse dict.
    Perspective: exact representation transition and sparse payload.
    Source path/symbol: DomainMatrix.to_sparse.
    """
    A = DomainMatrix([[QQ(1), QQ(0)], [QQ(0), QQ(2)]], (2, 2), QQ)
    B = A.to_sparse()
    assert isinstance(B, DomainMatrix)
    assert B.rep.fmt == "sparse"
    assert B.rep == {0: {0: QQ(1)}, 1: {1: QQ(2)}}
    assert type(B.rep) is SDM
    assert B.shape == A.shape
    assert B.domain == A.domain


def check_C3_to_sparse_returns_self_for_sparse():
    """# Contracts: C3; obligation R2.

    Repository-test guidance: interface doc says already-sparse matrices are
    returned unchanged; analogous to_dense behavior exists in DomainMatrix.
    Perspective: exact identity semantics, not just equality.
    Source path/symbol: DomainMatrix.to_sparse.
    """
    A = DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    assert A.rep.fmt == "sparse"
    assert A.to_sparse() is A


def check_C4_conversions_preserve_shape_and_domain():
    """# Contracts: C4; obligations R1,R2,R7.

    Repository-test guidance: test_xxm.py::test_to_XXM and
    test_domainmatrix.py::test_DomainMatrix_to_sparse exercise conversions
    while preserving matrix metadata.
    Perspective: independent metadata assertions for both conversion targets.
    Source path/symbol: DomainMatrix.to_sdm / DomainMatrix.to_sparse.
    """
    for A in (
        DomainMatrix([[QQ(1), QQ(0)], [QQ(0), QQ(2)]], (2, 2), QQ),
        DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ),
    ):
        sdm = A.to_sdm()
        assert sdm.shape == A.shape
        assert sdm.domain == A.domain
        sparse = A.to_sparse()
        assert sparse.shape == A.shape
        assert sparse.domain == A.domain


def check_C5_nullspace_qq_returns_expected_basis():
    """# Contracts: C5; obligations R3,R9.

    Repository-test guidance: interface doc example
    DM([[2,-2],[4,-4]], QQ).nullspace() == [[1,1]]; repository test
    test_domainmatrix.py::test_DomainMatrix_nullspace checks the same contract
    shape for QQ.
    Perspective: exact returned basis, type, shape, and domain.
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    DomainMatrix.nullspace_from_rref.
    """
    A = DM([[2, -2], [4, -4]], QQ)
    null = A.nullspace()
    assert isinstance(null, DomainMatrix)
    assert null.domain == QQ
    assert null.shape == (1, 2)
    assert null.to_list() == [[1, 1]]


def check_C6_nullspace_zz_returns_unnormalized_ring_basis():
    """# Contracts: C6; obligations R3,R9.

    Repository-test guidance: interface doc example
    DM([[6,-3],[4,-2]], ZZ).nullspace() == [[3,6]]; test_domainmatrix.py
    test_DomainMatrix_nullspace checks a ZZ ring basis and DMNotAField.
    Perspective: unnormalized ring result stays in ZZ and is not converted to
    a field fraction.
    Source path/symbol: DomainMatrix.nullspace -> DomainMatrix.rref_den ->
    DomainMatrix.nullspace_from_rref.
    """
    A = DM([[6, -3], [4, -2]], ZZ)
    null = A.nullspace()
    assert isinstance(null, DomainMatrix)
    assert null.domain == ZZ
    assert null.shape == (1, 2)
    assert null.to_list() == [[3, 6]]


def check_C7_nullspace_divide_last_nonfield_raises_DMNotAField():
    """# Contracts: C7; obligation R4.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_nullspace
    uses raises(DMNotAField, lambda: A.nullspace(divide_last=True)).
    Perspective: precise exception class and task-supported diagnostic.
    Source path/symbol: DomainMatrix.nullspace control branch.
    """
    A = DM([[6, -3], [4, -2]], ZZ)
    try:
        A.nullspace(divide_last=True)
    except DMNotAField as exc:
        assert "Cannot normalize vectors over a non-field" in str(exc)
    else:
        raise AssertionError("DMNotAField was not raised")


def check_C8_nullspace_divide_last_field_normalizes_final_entries():
    """# Contracts: C8; obligations R4,R9.

    Repository-test guidance: the interface doc uses the polynomial-ring
    matrix and its field conversion to show unnormalized ring nullspace vs
    normalized field nullspace.  Unlike the previous weak QQ fixture, this
    matrix's unnormalized final entry is a non-unit denominator polynomial.
    Perspective: divide_last=True must actually divide every row by its final
    element; merely checking that the last entry is one is not sufficient.
    Source path/symbol: DomainMatrix.nullspace -> row normalization over a
    field.
    """
    from sympy.abc import a, b, c

    M = DomainMatrix.from_list_sympy(
        3,
        3,
        [
            [a * b, b + c, c],
            [a - b, b * c, c**2],
            [a * b + a - b, b * c + b + c, c**2 + c],
        ],
    )
    M_field = M.to_field()
    K = M_field.domain

    unnormalized = M_field.nullspace()
    normalized = M_field.nullspace(divide_last=True)

    assert isinstance(normalized, DomainMatrix)
    assert normalized.domain == K
    un_rows = unnormalized.to_list()
    norm_rows = normalized.to_list()
    assert len(un_rows) == len(norm_rows) == 1

    last = un_rows[0][-1]
    assert last != K.one, "unnormalized final entry is already the field unit"
    for i in range(len(un_rows[0])):
        assert norm_rows[0][i] == un_rows[0][i] / last
    assert norm_rows[0][-1] == K.one


def check_C9_primitive_returns_content_and_primitive_matrix():
    """# Contracts: C9; obligation R5.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_content_primitive
    asserts A.primitive() == (ZZ(2), DM([[1,2],[3,4]], ZZ)) for a similar
    matrix; the interface doc gives DM([[2,4],[4,12]], ZZ) -> [[1,2],[2,6]].
    Perspective: exact tuple components, type, and primitive values.
    Source path/symbol: DomainMatrix.primitive.
    """
    M = DM([[2, 4], [4, 12]], ZZ)
    result = M.primitive()
    assert isinstance(result, tuple) and len(result) == 2
    content, primitive = result
    assert content == ZZ(2)
    assert isinstance(primitive, DomainMatrix)
    assert primitive.domain == ZZ
    assert primitive.shape == M.shape
    assert primitive.to_list() == [[1, 2], [2, 6]]


def check_C17_primitive_product_identity_and_unit_content():
    """# Contracts: C17; obligation R5.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_content_primitive
    verifies both content and primitive parts; the interface doc additionally
    requires content * primitive == M and primitive.content() == 1.
    Perspective: scalar-multiplication reconstruction and unit-content state.
    Source path/symbol: DomainMatrix.primitive -> DomainMatrix.content ->
    scalar multiplication path (`content * M_primitive`).
    """
    M = DM([[2, 4], [4, 12]], ZZ)
    content, primitive = M.primitive()
    rebuilt = content * primitive
    assert isinstance(rebuilt, DomainMatrix)
    assert rebuilt == M
    assert primitive.content() == ZZ(1)


def check_C10_nullspace_from_rref_returns_domain_matrix_basis():
    """# Contracts: C10; obligations R3,R6.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_nullspace
    checks Arref.nullspace_from_rref() and Arref.nullspace_from_rref(pivots)
    for dense and sparse reps.
    Perspective: DomainMatrix wrapper returns only the basis matrix, not the
    lower-level (basis, nonpivots) tuple.
    Source path/symbol: DomainMatrix.nullspace_from_rref ->
    DDM.nullspace_from_rref / SDM.nullspace_from_rref.
    """
    A = DomainMatrix([[ZZ(2), ZZ(2)], [ZZ(2), ZZ(2)]], (2, 2), ZZ)
    Arref, den, pivots = A.rref_den()
    assert den == ZZ(2)
    expected = [[-2, 2]]

    for R in (Arref, Arref.to_sparse()):
        for call in (lambda r=R: r.nullspace_from_rref(),
                     lambda r=R: r.nullspace_from_rref(pivots)):
            null = call()
            assert isinstance(null, DomainMatrix)
            assert null.domain == ZZ
            assert null.shape == (1, 2)
            assert null.to_list() == expected


def check_C16_primitive_content_dup_content_outcomes():
    """# Contracts: C16; obligation R5.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_content_primitive
    calls content() and primitive() and compares returned content.
    Perspective: observable outcome of the dup_content binding without mocking.
    Source path/symbol: DomainMatrix.content / DomainMatrix.primitive ->
    domainmatrix.dup_content.
    """
    M = DM([[2, 4], [4, 12]], ZZ)
    assert M.content() == ZZ(2)
    assert M.primitive()[0] == ZZ(2)


def check_C18_getitem_scalar_slice_and_bounds():
    """# Contracts: C18; task obligation 2.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_getitem
    checks scalar retrieval, row/column slicing, and out-of-range IndexError.
    Perspective: exact scalar DomainScalar values, exact submatrix extraction,
    and precise bounds-checking failures.
    Source path/symbol: DomainMatrix.__getitem__.
    """
    dM = DomainMatrix(
        [[ZZ(1), ZZ(2), ZZ(3)], [ZZ(4), ZZ(5), ZZ(6)], [ZZ(7), ZZ(8), ZZ(9)]],
        (3, 3),
        ZZ,
    )

    assert dM[1, 2] == DomainScalar(ZZ(6), ZZ)
    assert dM[-2, 2] == DomainScalar(ZZ(6), ZZ)
    assert dM[1:, :-2] == DomainMatrix([[ZZ(4)], [ZZ(7)]], (2, 1), ZZ)
    assert dM[:, -1] == DomainMatrix([[ZZ(3)], [ZZ(6)], [ZZ(9)]], (3, 1), ZZ)

    _assert_raises(IndexError, lambda: dM[4, :-2], "row index out of range")
    _assert_raises(IndexError, lambda: dM[:-2, 4], "column index out of range")
    _assert_raises(IndexError, lambda: dM[3, 3], "scalar row index out of range")
    _assert_raises(IndexError, lambda: dM[-1, -4], "scalar negative index out of range")


def check_C19_dfm_conversion_preserves_values_when_flint():
    """# Contracts: C19; obligations R1,R2,R7.

    Repository-test guidance: test_xxm.py::test_to_XXM conditionally includes
    DFM when GROUND_TYPES == 'flint'.
    Perspective: when python-flint is active, DFM-backed DomainMatrix
    conversion must preserve exact SDM type, values, shape, and domain.
    Source path/symbol: DomainMatrix.to_sdm / DomainMatrix.to_sparse.
    """
    if GROUND_TYPES != "flint":
        return

    from sympy.polys.matrices.domainmatrix import DFM

    A = DomainMatrix([[ZZ(1), ZZ(2)], [ZZ(3), ZZ(4)]], (2, 2), ZZ)
    assert type(A.rep) is DFM

    sdm = A.to_sdm()
    assert type(sdm) is SDM
    assert dict(sdm) == {0: {0: ZZ(1), 1: ZZ(2)}, 1: {0: ZZ(3), 1: ZZ(4)}}
    assert sdm.shape == A.shape
    assert sdm.domain == A.domain

    sparse = A.to_sparse()
    assert type(sparse.rep) is SDM
    assert sparse.to_list() == [[1, 2], [3, 4]]
    assert sparse.shape == A.shape
    assert sparse.domain == A.domain


def check_C20_scalar_mul_and_truediv_repository_contracts():
    """# Contracts: C20; obligations R5 and scalar-mul/truediv compatibility.

    Repository-test guidance: test_domainmatrix.py::test_DomainMatrix_scalarmul
    and test_DomainMatrix_truediv exercise dense/sparse scalar multiplication
    and scalar division.
    Perspective: exact scalar-multiplication and division results from the
    public DomainMatrix operators.
    Source path/symbol: DomainMatrix.__mul__, DomainMatrix.__rmul__,
    DomainMatrix.__truediv__.
    """
    A = DM([[1, 2], [3, 4]], ZZ)

    assert (A * 2).to_list() == [[2, 4], [6, 8]]
    assert (2 * A).to_list() == [[2, 4], [6, 8]]
    assert (A * DomainScalar(ZZ(1), ZZ)).to_list() == [[1, 2], [3, 4]]
    assert (A * DomainScalar(ZZ(0), ZZ)).to_list() == [[0, 0], [0, 0]]

    lamda = DomainScalar(QQ(3) / QQ(2), QQ)
    B = A * lamda
    assert B.domain == QQ
    assert B.to_list() == [[QQ(3, 2), QQ(3)], [QQ(9, 2), QQ(6)]]

    C = A / 2
    assert C.domain == QQ
    assert C.to_list() == [[QQ(1, 2), QQ(1)], [QQ(3, 2), QQ(2)]]


def check_C21_nullspace_product_identity_and_nullity_shape():
    """# Contracts: C21; obligations R3,R9.

    Repository-test guidance: the interface doc asserts
    A * nullspace.transpose() == zero and
    nullspace.transpose().shape == (cols, rows - rank).  Using rref_den
    pivots computes nullity without depending on the separately stubbed
    DomainMatrix.rref/rank path.
    Perspective: the returned basis must annihilate the original matrix and
    have the exact nullity-derived shape.
    Source path/symbol: DomainMatrix.nullspace; DomainMatrix.matmul/__mul__.
    """
    examples = [
        DM([[2, -2], [4, -4]], QQ),
        DM([[6, -3], [4, -2]], ZZ),
    ]

    for A in examples:
        null = A.nullspace()
        _, _, pivots = A.rref_den()
        expected_nullity = A.shape[1] - len(pivots)
        assert null.shape == (expected_nullity, A.shape[1])
        assert null.transpose().shape == (A.shape[1], expected_nullity)

        product = A * null.transpose()
        assert product.shape == (A.shape[0], expected_nullity)
        flat = [value for row in product.to_list() for value in row]
        assert all(value == A.domain.zero for value in flat)


def check_C22_polynomial_ring_nullspace_documented_basis():
    """# Contracts: C22; obligations R3,R9.

    Repository-test guidance: the interface doc documents the polynomial-ring
    nullspace example over ZZ[a,b,c].
    Perspective: exact ring-preserving basis from DomainMatrix.nullspace.
    Source path/symbol: DomainMatrix.nullspace ->
    DomainMatrix.rref_den -> DomainMatrix.nullspace_from_rref.
    """
    from sympy.abc import a, b, c

    M = DomainMatrix.from_list_sympy(
        3,
        3,
        [
            [a * b, b + c, c],
            [a - b, b * c, c**2],
            [a * b + a - b, b * c + b + c, c**2 + c],
        ],
    )
    null = M.nullspace()
    assert isinstance(null, DomainMatrix)
    assert null.domain == M.domain
    assert null.shape == (1, 3)

    expected = Matrix(
        [[c**3, -a * b * c**2 + a * c - b * c, a * b**2 * c - a * b - a * c + b**2 + b * c]]
    )
    assert null.to_Matrix().tolist() == expected.tolist()


def main() -> None:
    checks = [
        check_C1_to_sdm_returns_sdm_with_preserved_values,
        check_C2_to_sparse_converts_dense_representation,
        check_C3_to_sparse_returns_self_for_sparse,
        check_C4_conversions_preserve_shape_and_domain,
        check_C5_nullspace_qq_returns_expected_basis,
        check_C6_nullspace_zz_returns_unnormalized_ring_basis,
        check_C7_nullspace_divide_last_nonfield_raises_DMNotAField,
        check_C8_nullspace_divide_last_field_normalizes_final_entries,
        check_C9_primitive_returns_content_and_primitive_matrix,
        check_C17_primitive_product_identity_and_unit_content,
        check_C10_nullspace_from_rref_returns_domain_matrix_basis,
        check_C16_primitive_content_dup_content_outcomes,
        check_C18_getitem_scalar_slice_and_bounds,
        check_C19_dfm_conversion_preserves_values_when_flint,
        check_C20_scalar_mul_and_truediv_repository_contracts,
        check_C21_nullspace_product_identity_and_nullity_shape,
        check_C22_polynomial_ring_nullspace_documented_basis,
    ]
    failures = 0
    for check in checks:
        name = check.__name__
        try:
            check()
            print(f"PASS: {name}")
        except Exception as exc:  # noqa: BLE001 - report all contract failures
            failures += 1
            print(f"FAIL: {name}: {type(exc).__name__}: {exc}")
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
