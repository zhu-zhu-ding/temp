# Semantic IR

IR = <R, G, C>

## L1. Requirement Obligations

### R1: DomainMatrix.to_sdm representation conversion
- Type: Interface / Dataflow / Compatibility
- Statement: `DomainMatrix.to_sdm()` shall return the underlying sparse domain matrix representation as a `sympy.polys.matrices.sdm.SDM` regardless of whether the current `rep` is DDM, SDM, or DFM.
- Task Evidence: Interface Description 1, `DomainMatrix.to_sdm` section; task statement requirement 1 "Format Conversion".
- Acceptance: For a DomainMatrix over QQ built from `[[1, 0], [0, 2]]`, `A.to_sdm()` returns `SDM({0: {0: 1}, 1: {1: 2}}, (2, 2), QQ)` and `type(...) is SDM`; for a sparse DomainMatrix the same SDM is returned; shape and domain are preserved.
- Repository Evidence: `sympy/polys/matrices/domainmatrix.py` already defines analogous `to_ddm` at line 638 but has no `to_sdm` method; `sympy/polys/matrices/ddm.py:491` and `_dfm.py:218` and `sdm.py:614` define `to_sdm` on reps; test `sympy/polys/matrices/tests/test_xxm.py:198-200` expects `A.to_sdm() == A_sdm` for DomainMatrix, DDM, SDM, and DFM.
- Uncertainty: Whether DFM is reachable depends on `GROUND_TYPES == 'flint'`; otherwise `A.rep` is DDM or SDM.
- Graph: N1, N2, N18, N19, N20; E1.
- Contracts: C1, C4.

### R2: DomainMatrix.to_sparse conversion and identity
- Type: Interface / State / Compatibility
- Statement: `DomainMatrix.to_sparse()` shall return a DomainMatrix whose internal representation is sparse SDM. If the current representation is already sparse, it shall return `self` unchanged. Domain and shape shall remain unchanged.
- Task Evidence: Interface Description 1, `DomainMatrix.to_sparse` section; task statement requirement 1.
- Acceptance: For dense `A = DomainMatrix([[1, 0], [0, 2]], (2, 2), QQ)`, `B = A.to_sparse()` has `B.rep == {0: {0: 1}, 1: {1: 2}}`, `B.rep.fmt == 'sparse'`, `B.shape == A.shape`, `B.domain == A.domain`; if `A.rep.fmt == 'sparse'`, `A.to_sparse() is A`.
- Repository Evidence: `test_domainmatrix.py:267-270` asserts dense-to-sparse conversion; `domainmatrix.py:614-635` shows analogous `to_dense` identity behavior; `domainmatrix.py:771` and `rref.py:175` call `to_sparse`.
- Uncertainty: For DFM input, conversion must go through `DFM.to_sdm`; exact identity behavior for DFM is not shown in repository tests.
- Graph: N1, N3, N18, N19, N20; E2, E3.
- Contracts: C2, C3, C4.

### R3: DomainMatrix.nullspace default over rings and fields
- Type: Interface / Dataflow / Linear algebra
- Statement: `DomainMatrix.nullspace(divide_last=False)` shall compute a basis for the nullspace and return it as a DomainMatrix whose rows are basis vectors. It shall use `rref_den` and `nullspace_from_rref`, discard the denominator, and work over both field domains and non-field rings.
- Task Evidence: Interface Description 1, `DomainMatrix.nullspace` section; task statement requirement 3 "Linear Algebra Operations".
- Acceptance: Over QQ, `DM([[2, -2], [4, -4]], QQ).nullspace()` equals `DomainMatrix([[1, 1]], (1, 2), QQ)`; over ZZ, `DM([[6, -3], [4, -2]], ZZ).nullspace()` equals `DomainMatrix([[3, 6]], (1, 2), ZZ)`; returned matrix has shape `(ncols, nullity)` after transposition and satisfies `A * nullspace.transpose() == zero`.
- Repository Evidence: `test_domainmatrix.py:757-766`; Interface doc examples; `domainmatrix.py:2242` defines `rref_den` returning `(RREF, denom, pivots)` via `rref._dm_rref_den`; `sdm.py:1159` and `ddm.py:879` define lower-level `nullspace_from_rref`.
- Uncertainty: `DomainMatrix.nullspace` and `DomainMatrix.nullspace_from_rref` are absent from the repository; `DomainMatrix.rref` is also absent although the nullspace doc says the implementation uses `rref_den` rather than `rref`.
- Graph: N1, N4, N5, N8, N9; E4, E5, E6.
- Contracts: C5, C6, C11, C12, C13, C15.

### R4: DomainMatrix.nullspace normalization and non-field failure
- Type: Interface / Failure / Domain compatibility
- Statement: `nullspace(divide_last=True)` shall normalize each returned row by its final element. It requires the domain to be a field and shall raise `DMNotAField` when the domain is not a field.
- Task Evidence: Interface Description 1, `DomainMatrix.nullspace` section; task statement "Domain Compatibility" and "division in non-fields" challenge.
- Acceptance: `DM([[6, -3], [4, -2]], ZZ).nullspace(divide_last=True)` raises `DMNotAField` with diagnostic meaning "Cannot normalize vectors over a non-field"; for a field-domain matrix, every row in the returned nullspace has final element equal to the domain's one.
- Repository Evidence: `test_domainmatrix.py:766`; docstring `Raises` section; `sympy/polys/matrices/exceptions.py` exports `DMNotAField`.
- Uncertainty: Exact implementation of row division is not present; it may use slicing, `__truediv__`, or `applyfunc`, which would create additional missing-method dependencies.
- Graph: N1, N4, N5; E6, E7.
- Contracts: C7, C8.

### R5: DomainMatrix.primitive factorization
- Type: Interface / Dataflow / Factorization
- Statement: `DomainMatrix.primitive()` shall factor the gcd of all matrix elements out of the matrix and return `(content, M_primitive)` where `content` is a DomainElement, `M_primitive` is a DomainMatrix, and `content * M_primitive == self`. The primitive matrix shall have content equal to the domain unit.
- Task Evidence: Interface Description 1, `DomainMatrix.primitive` section; task statement requirement 4 "Matrix Factorization".
- Acceptance: `M = DM([[2, 4], [4, 12]], ZZ)` gives `content == ZZ(2)`, `M_primitive == DM([[1, 2], [2, 6]], ZZ)`, `content * M_primitive == M`, and `M_primitive.content() == ZZ(1)`.
- Repository Evidence: `test_domainmatrix.py:669-674`; `domainmatrix.py:2092` defines `content` but calls currently unresolved `dup_content`; `domainmatrix.py` imports `dup_mul_ground` and `dup_quo_ground` but not `dup_content`.
- Uncertainty: Error class for domains without gcd is not specified in the interface beyond "will raise an error"; no exact exception class is established.
- Graph: N1, N6, N7, N25, N26; E8, E9, E10.
- Contracts: C9, C16, C17.

### R6: DomainMatrix.nullspace_from_rref compatibility
- Type: Interface / Dataflow / Compatibility
- Statement: `DomainMatrix.nullspace_from_rref(pivots=None)` shall return a DomainMatrix basis for the nullspace of an already reduced-row-echelon DomainMatrix, wrapping the underlying rep's `nullspace_from_rref` result and discarding the lower-level `nonpivots` return.
- Task Evidence: Interface Description 1 See Also and Notes; visible repository test `test_domainmatrix.py:773-776`.
- Acceptance: For an RREF `Arref` and pivots from `rref_den`, `Arref.nullspace_from_rref()`, `Arref.nullspace_from_rref(pivots)`, and sparse variants all equal the expected DomainMatrix nullspace basis.
- Repository Evidence: `test_domainmatrix.py:773-776`; lower-level implementations `sdm.py:1159`, `ddm.py:879`, `_dfm.py:843`.
- Uncertainty: The method itself is absent from `domainmatrix.py`; exact signature is inferred from tests and lower-level docs.
- Graph: N1, N5, N23, N24; E11, E12.
- Contracts: C10.

### R7: Representation and domain preservation
- Type: Compatibility / State
- Statement: Conversions `to_sdm` and `to_sparse` must preserve matrix shape, ground domain, element values, and mathematical equality across DDM, SDM, and DFM.
- Task Evidence: Task statement requirements 1 and 5; Interface Description 1 Notes.
- Acceptance: `A.to_sparse().to_ddm() == A.to_ddm()`; `A.to_sparse().to_Matrix() == A.to_Matrix()`; returned rep has the original shape and domain.
- Repository Evidence: `test_domainmatrix.py:312`; `test_xxm.py:198-200`.
- Uncertainty: DFM representation is conditional on `GROUND_TYPES`.
- Graph: N1, N2, N3, N18, N19, N20; E1, E2, E3.
- Contracts: C1, C2, C4.

### R8: RREF dependency closure for nullspace
- Type: Dependency / Dataflow / Failure
- Statement: The nullspace computation path through `DomainMatrix.rref_den` shall resolve all lower-level RREF helpers, including method selection and fraction-free/Gauss-Jordan implementations, with no undefined-name failures.
- Task Evidence: Static issues in `rref.py`, `sdm.py`, and `ddm.py`; task statement requirement 3.
- Acceptance: Calls to `rref_den()` on ZZ, QQ, and real-field matrices complete without `NameError` and return `(rref, denom, pivots)`.
- Repository Evidence: `rref.py:89-165` calls `_dm_rref_den_FF`, `_dm_rref_choose_method`, `_dm_rref_choose_method_QQ`, `_dm_rref_choose_method_ZZ`, `_dm_elements`, and `ddm_irref` without definitions/imports; `test_rref.py:3,5` imports `ddm_irref` and `sdm_rref_den` from modules where they are currently missing.
- Uncertainty: The restored implementations may choose dense or sparse implementations depending on method and ground type.
- Graph: N8, N9, N10, N11, N12, N13, N14, N15, N16, N17, N21, N22.
- Contracts: C11, C12, C13, C14, C15.

### R9: Exact and approximate arithmetic domain compatibility
- Type: Domain compatibility
- Statement: Nullspace and conversion interfaces shall operate correctly for exact domains (ZZ, QQ, polynomial rings) and approximate domains (RR/CC), converting to associated fields only when mathematically valid and preserving the original domain for unnormalized results.
- Task Evidence: Task statement requirement 5 and Main Challenges; Interface Description 1 examples.
- Acceptance: Exact-ring nullspace remains in the original ring; field conversion via `to_field().nullspace(divide_last=True)` succeeds; approximate-domain RREF path does not raise missing-symbol errors.
- Repository Evidence: Interface doc examples for `ZZ[a,b,c]`; `rref.py:267-270` routes RR/CC to dense GJ path.
- Uncertainty: Floating-point exact equality of returned basis values is not specified.
- Graph: N4, N8, N9, N14, N16.
- Contracts: C5, C6, C14.

## L2. Functional Design Graph

### N1: Public DomainMatrix API
- Kind: Public entry / class
- Repository Evidence: `sympy/polys/matrices/domainmatrix.py:89` class `DomainMatrix`; exported by `sympy/polys/matrices/__init__.py:13`.

### N2: DomainMatrix.to_sdm
- Kind: Public method (task-required)
- Repository Evidence: Interface Description 1; currently absent in `domainmatrix.py`.

### N3: DomainMatrix.to_sparse
- Kind: Public method (task-required)
- Repository Evidence: Interface Description 1; currently absent; called by `rref.py:175` and `domainmatrix.py:771`.

### N4: DomainMatrix.nullspace
- Kind: Public method (task-required)
- Repository Evidence: Interface Description 1; currently absent.

### N5: DomainMatrix.nullspace_from_rref
- Kind: Public method (compatibility helper)
- Repository Evidence: `test_domainmatrix.py:773-776`; lower-level docs refer to it.

### N6: DomainMatrix.primitive
- Kind: Public method (task-required)
- Repository Evidence: Interface Description 1; currently absent.

### N7: DomainMatrix.content
- Kind: Existing public method
- Repository Evidence: `domainmatrix.py:2092-2115`.

### N8: DomainMatrix.rref_den
- Kind: Existing public method / call boundary
- Repository Evidence: `domainmatrix.py:2242`.

### N9: rref._dm_rref_den
- Kind: Helper function
- Repository Evidence: `sympy/polys/matrices/rref.py:89`.

### N10: rref._dm_rref_choose_method
- Kind: Helper function
- Repository Evidence: `rref.py:235`.

### N11: rref._dm_rref_choose_method_ZZ
- Kind: Helper function
- Repository Evidence: `rref.py:326`.

### N12: rref._dm_rref_choose_method_QQ
- Kind: Missing helper symbol
- Repository Evidence: called at `rref.py:257`; no definition in file.

### N13: rref._dm_rref_den_FF
- Kind: Missing helper symbol
- Repository Evidence: called at `rref.py:102`; no definition in file.

### N14: rref._dm_rref_GJ_dense
- Kind: Helper function
- Repository Evidence: `rref.py:208`.

### N15: rref._dm_elements
- Kind: Missing helper symbol
- Repository Evidence: called at `rref.py:360`; no definition in file.

### N16: dense.ddm_irref
- Kind: Missing helper symbol
- Repository Evidence: imported by `test_rref.py:3`; called at `rref.py:212` and `ddm.py:846`; absent from `dense.py`.

### N17: dense.ddm_irref_den
- Kind: Existing helper
- Repository Evidence: defined at `dense.py:239`; imported by `rref.py:36`.

### N18: DDM.to_sdm
- Kind: Representation conversion
- Repository Evidence: `ddm.py:491`.

### N19: SDM.to_sdm
- Kind: Representation conversion / identity
- Repository Evidence: `sdm.py:614`.

### N20: DFM.to_sdm
- Kind: Representation conversion
- Repository Evidence: `_dfm.py:218`.

### N21: SDM.rref_den
- Kind: Representation method
- Repository Evidence: `sdm.py:1008-1015`; calls missing `sdm_rref_den`.

### N22: sdm.sdm_rref_den
- Kind: Missing helper symbol
- Repository Evidence: called at `sdm.py:1014`; imported by `test_rref.py:5`; no definition in repository.

### N23: SDM.nullspace_from_rref
- Kind: Representation method
- Repository Evidence: `sdm.py:1159-1245`.

### N24: DDM.nullspace_from_rref
- Kind: Representation method
- Repository Evidence: `ddm.py:879-925`.

### N25: densetools.dup_content
- Kind: Missing import/helper symbol
- Repository Evidence: called at `domainmatrix.py:2009,2115`; no import in `domainmatrix.py`.

### N26: densearith.dup_quo_ground
- Kind: Existing helper import
- Repository Evidence: imported at `domainmatrix.py:48`.

### N27: SDM.nullspace / sdm_nullspace_from_rref
- Kind: Out-of-scope path candidate
- Repository Evidence: `sdm.py:1125-1156` calls `sdm_nullspace_from_rref`; no definition found.

### N28: DDM.mul / ddm_imul
- Kind: Out-of-scope path candidate
- Repository Evidence: `ddm.py:689` calls missing `ddm_imul`.

### N29: DDM.rref / ddm_irref
- Kind: Partially on-path via dense GJ RREF
- Repository Evidence: `ddm.py:832-847`.

### N30: DomainMatrix scalar multiplication path
- Kind: Missing internal methods / uncertainty
- Repository Evidence: `domainmatrix.py:1628-1629` calls missing `_scalarmul`; `domainmatrix.py:1652` calls missing `mul`; primitive test requires `content * M_primitive == M`.

### E1: N2 -> N18/N19/N20
- Kind: CALL
- Condition: `to_sdm` delegates to `self.rep.to_sdm()`; actual target depends on `rep.fmt`.
- Transfer: `self.rep` representation object enters; an SDM object with same shape/domain returns.
- Evidence: `ddm.py:491`, `sdm.py:614`, `_dfm.py:218`.
- Obligations: R1, R7.

### E2: N3 -> N18/N19/N20
- Kind: CALL
- Condition: If `self.rep.fmt != 'sparse'`, convert rep via `to_sdm()` and wrap with `from_rep`; if already sparse, return `self`.
- Transfer: Representation changes from dense/DFM to SDM; shape and domain preserved.
- Evidence: `domainmatrix.py:614-635` analogous `to_dense`; interface doc `to_sparse`.
- Obligations: R2, R7.

### E3: N3 -> N1
- Kind: STATE
- Condition: `self.rep.fmt == 'sparse'`.
- Transfer: Same object returned (identity).
- Evidence: Interface doc `to_sparse`: "If the matrix is already in sparse format, it returns itself unchanged."
- Obligations: R2.

### E4: N4 -> N8
- Kind: CALL
- Condition: `nullspace` computes `rref_den` first.
- Transfer: `rref_den` returns `(A_rref, denom, pivots)`; denominator is discarded by nullspace.
- Evidence: Interface Description 1 Notes.
- Obligations: R3, R9.

### E5: N8 -> N9
- Kind: CALL
- Condition: Always for `DomainMatrix.rref_den`.
- Transfer: DomainMatrix, method, keep_domain pass into `_dm_rref_den`.
- Evidence: `domainmatrix.py:2242` return `_dm_rref_den(self, method=method, keep_domain=keep_domain)`.
- Obligations: R8.

### E6: N4 -> N5
- Kind: CALL
- Condition: After `rref_den`, nullspace extracts basis via `nullspace_from_rref(pivots)`.
- Transfer: RREF DomainMatrix and pivots enter; nullspace basis DomainMatrix returns.
- Evidence: Interface Description 1 Notes; `test_domainmatrix.py:773-776`.
- Obligations: R3, R6.

### E7: N4 -> N1
- Kind: CONTROL
- Condition: `divide_last=True` and `self.domain.is_Field` is false.
- Transfer: Raises `DMNotAField` instead of returning.
- Evidence: Interface Description 1 Raises; `test_domainmatrix.py:766`.
- Obligations: R4.

### E8: N6 -> N7
- Kind: CALL
- Condition: `primitive` obtains content via `content()` (or directly through `dup_content`).
- Transfer: Element list to content computation.
- Evidence: Interface doc `primitive`; `domainmatrix.py:2092-2115`.
- Obligations: R5.

### E9: N6 -> N25
- Kind: CALL
- Condition: Content computation requires `dup_content(elements, K)`.
- Transfer: Flat nonzero elements and domain `K`; returns domain element content.
- Evidence: `domainmatrix.py:2115`; static issue `domainmatrix.py dup_content`.
- Obligations: R5, R8.

### E10: N6 -> N26
- Kind: DATA
- Condition: After content is found, primitive matrix is computed by exact division of elements by content.
- Transfer: Nonzero element list divided by content via `dup_quo_ground`; positions preserved.
- Evidence: `domainmatrix.py:48` already imports `dup_quo_ground`.
- Obligations: R5.

### E11: N5 -> N23
- Kind: CALL
- Condition: `self.rep.fmt == 'sparse'` or DFM conversion path reaches SDM.
- Transfer: `(basis, nonpivots)` returned; DomainMatrix wrapper discards `nonpivots`.
- Evidence: `sdm.py:1159-1245`.
- Obligations: R6.

### E12: N5 -> N24
- Kind: CALL
- Condition: `self.rep.fmt == 'dense'`.
- Transfer: `(basis_ddm, nonpivots)` returned; DomainMatrix wrapper discards `nonpivots`.
- Evidence: `ddm.py:879-925`.
- Obligations: R6.

### E13: N9 -> N10
- Kind: CALL
- Condition: Always before RREF computation.
- Transfer: DomainMatrix and `method='auto'` or explicit method.
- Evidence: `rref.py:95`.
- Obligations: R8.

### E14: N10 -> N11
- Kind: CALL
- Condition: Domain is ZZ and method is auto.
- Transfer: M, denominator flag.
- Evidence: `rref.py:252-253`.
- Obligations: R8.

### E15: N10 -> N12
- Kind: CALL
- Condition: Domain is QQ and method is auto.
- Transfer: M, denominator flag.
- Evidence: `rref.py:255-257`.
- Obligations: R8.

### E16: N11 -> N15
- Kind: CALL
- Condition: Density threshold path requires bit lengths of elements.
- Transfer: Flat element list into bit-length computation.
- Evidence: `rref.py:359-360`.
- Obligations: R8.

### E17: N9 -> N13
- Kind: CALL
- Condition: Chosen method is `FF` (fraction-free).
- Transfer: DomainMatrix in selected format; returns `(rref, den, pivots)`.
- Evidence: `rref.py:99-102`.
- Obligations: R8.

### E18: N13 -> N21 -> N22
- Kind: CALL
- Condition: Sparse FF implementation delegates to SDM `rref_den` and its `sdm_rref_den` helper.
- Transfer: SDM matrix and domain into `sdm_rref_den`.
- Evidence: `sdm.py:1008-1015`; static issue `sdm.py sdm_rref_den`.
- Obligations: R8.

### E19: N9 -> N14 -> N16
- Kind: CALL
- Condition: Chosen method is GJ with dense format (e.g. RR/CC auto, or explicit `GJ_dense`).
- Transfer: Dense DDM copy; `ddm_irref` returns pivots.
- Evidence: `rref.py:208-213`; static issue `rref.py ddm_irref`.
- Obligations: R8, R9.

### E20: N30 -> N3/N5/N4
- Kind: DATA / STATE
- Condition: Primitive acceptance expression `content * M_primitive == M` and divide-last normalization may require scalar multiplication on sparse/dense reps.
- Transfer: Scalar multiplication path from `__rmul__` to missing `_scalarmul`/`mul` and rep scalar-mul helpers.
- Evidence: `domainmatrix.py:1374-1382` (`__rmul__`), `1628-1629` (`rscalarmul` calls missing `_scalarmul`), `1652` (`__truediv__` calls missing `mul`).
- Obligations: R5 uncertainty, R4 uncertainty.

### Static issue closure records

The static findings are closed as follows.

#### domainmatrix.py `dup_content` — ON-PATH
1. Call site: `domainmatrix.py:2115` in `DomainMatrix.content` (also line 2009 in `cancel_denom`).
2. Upward trace: task-required `DomainMatrix.primitive` (`N6`) -> `DomainMatrix.content` (`N7`) -> `dup_content` (`N25`). This reaches task entry `P = DomainMatrix.primitive`.
3. Recorded chain: `DomainMatrix.primitive -> DomainMatrix.content -> dup_content` as E8, E9.
4. Disposition: ON-PATH; contract C16 executes the real path through `primitive`/`content`.

#### domainmatrix.py `dup_convert` — OUT-OF-SCOPE
1. Call site: `domainmatrix.py:3718` in `DomainMatrix.charpoly_base`.
2. Upward trace: `charpoly_base` is reached only by characteristic-polynomial methods (`charpoly`, `charpoly_berk`, etc.); no caller chain reaches task entries `nullspace`, `primitive`, `to_sdm`, or `to_sparse`.
3. Dead-end evidence: `domainmatrix.py:3661` defines `charpoly_base`; no task-required caller in repository reaches it.
4. Disposition: out-of-scope for this task.

#### rref.py `_dm_rref_den_FF` — ON-PATH
1. Call site: `rref.py:102` in `_dm_rref_den`.
2. Upward trace: `DomainMatrix.nullspace` (`N4`) -> `DomainMatrix.rref_den` (`N8`) -> `_dm_rref_den` (`N9`) -> `_dm_rref_den_FF` (`N13`). Reaches `P = DomainMatrix.nullspace`.
3. Recorded chain: E4, E5, E17.
4. Disposition: ON-PATH; contract C11 executes `rref_den` default path.

#### rref.py `_dm_rref_choose_method_QQ` — ON-PATH
1. Call site: `rref.py:257` in `_dm_rref_choose_method`.
2. Upward trace: `DomainMatrix.nullspace` -> `DomainMatrix.rref_den` -> `_dm_rref_den` -> `_dm_rref_choose_method` -> `_dm_rref_choose_method_QQ`.
3. Recorded chain: E4, E5, E13, E15.
4. Disposition: ON-PATH; contract C12 executes the QQ auto-method path.

#### rref.py `_dm_elements` — ON-PATH
1. Call site: `rref.py:360` in `_dm_rref_choose_method_ZZ`.
2. Upward trace: `DomainMatrix.nullspace` -> `DomainMatrix.rref_den` -> `_dm_rref_den` -> `_dm_rref_choose_method` -> `_dm_rref_choose_method_ZZ` -> `_dm_elements`.
3. Recorded chain: E4, E5, E13, E14, E16.
4. Disposition: ON-PATH; contract C13 executes the ZZ auto-method path.

#### rref.py `ddm_irref` — ON-PATH
1. Call site: `rref.py:212` in `_dm_rref_GJ_dense`.
2. Upward trace: `DomainMatrix.nullspace` -> `DomainMatrix.rref_den` -> `_dm_rref_den` -> `_dm_rref_GJ` -> `_dm_rref_GJ_dense` -> `ddm_irref`.
3. Recorded chain: E4, E5, E19.
4. Disposition: ON-PATH; contract C14 executes the dense GJ path (RR/CC or `GJ_dense`).

#### sdm.py `sdm_rref_den` — ON-PATH
1. Call site: `sdm.py:1014` in `SDM.rref_den`.
2. Upward trace: `DomainMatrix.nullspace` -> `DomainMatrix.rref_den` -> `_dm_rref_den` -> `_dm_rref_den_FF` -> `SDM.rref_den` -> `sdm_rref_den`.
3. Recorded chain: E4, E5, E17, E18.
4. Disposition: ON-PATH; contract C15 executes sparse FF `rref_den`.

#### sdm.py `sdm_nullspace_from_rref` — OUT-OF-SCOPE
1. Call site: `sdm.py:1154` in `SDM.nullspace`.
2. Upward trace: `SDM.nullspace` is called by `DomainMatrix._solve` (`domainmatrix.py:3466`), but `_solve` is not a task-required entry and its upward callers (`holonomic`, `numberfields`) do not reach `DomainMatrix.nullspace`, `primitive`, `to_sdm`, or `to_sparse`.
3. Dead-end evidence: `domainmatrix.py:3466`; no task-required public entry calls `_solve` or `SDM.nullspace`.
4. Disposition: out-of-scope for this task.

#### sdm.py `sdm_scalar_mul` — OUT-OF-SCOPE WITH UNCERTAINTY
1. Call site: `sdm.py:837,841` in `SDM.mul`/`SDM.rmul`.
2. Upward trace: `SDM.mul` would be reached by `DomainMatrix.mul`, but `DomainMatrix.mul` is absent and is not a task-required entry. Current trace dead-ends.
3. Dead-end evidence: `domainmatrix.py:1652` calls missing `mul`, but no task-required entry currently reaches `__truediv__`; `domainmatrix.py:1628-1629` calls missing `_scalarmul`.
4. Disposition: out-of-scope today, but retained as uncertainty: if nullspace `divide_last=True` or primitive equality `content * M_primitive == M` is implemented via scalar multiplication, this symbol may become ON-PATH. Contract C8 covers the observable normalized result without assuming the internal scalar-mul route.

#### ddm.py `ddm_imul` — OUT-OF-SCOPE WITH UNCERTAINTY
1. Call site: `ddm.py:689` in `DDM.mul`.
2. Upward trace: `DDM.mul` would be reached by missing `DomainMatrix.mul`; no current task-required caller.
3. Dead-end evidence: `domainmatrix.py:1652` and `1628-1629`.
4. Disposition: out-of-scope today, with the same scalar-multiplication uncertainty noted for `sdm_scalar_mul`.

#### ddm.py `ddm_irref` — ON-PATH
1. Call site in `ddm.py`: `ddm.py:846` in `DDM.rref`; same symbol also called from `rref.py:212`.
2. Upward trace for task path: see `rref.py ddm_irref` closure above. The `DDM.rref` call site itself dead-ends before a task entry because `DomainMatrix.rref` is absent and not specified, but the symbol is still ON-PATH through `_dm_rref_GJ_dense`.
3. Disposition: ON-PATH; contract C14.

#### Non-matrix polys issues — OUT-OF-SCOPE
Files and symbols:
- `compatibility.py`: `dup_clear_denoms`, `dup_content`, `dup_primitive`.
- `euclidtools.py`: `dup_clear_denoms`, `dup_convert`, `dup_primitive`.
- `factortools.py`: `dup_clear_denoms`, `dup_content`, `dup_convert`, `dup_primitive`.
- `numberfields/modules.py`: `dup_clear_denoms`.
- `polyclasses.py`: `dup_convert`.
- `sqfreetools.py`: `dup_convert`, `dup_primitive`.

1. Call sites: the line numbers listed in `static_issues.md`; each call is inside dense-polynomial/sparse-polynomial compatibility, GCD, factorization, number-field, or square-free helper units.
2. Upward trace: no caller chain from the task-required public entries `DomainMatrix.nullspace`, `primitive`, `to_sdm`, or `to_sparse` reaches these units. The nearest matrix-adjacent import `domainmatrix.py` imports only `dup_factor_list` from `factortools`, which is used by characteristic-polynomial factorization rather than any task entry.
3. Dead-end evidence: `domainmatrix.py:51` imports `dup_factor_list`; `domainmatrix.py:3585` and related charpoly methods are not task entries.
4. Disposition: out-of-scope for this task.

## L3. Verifiable Contracts

### C1: to_sdm returns an SDM with preserved values
- Type: Interface / Return value
- Subject: `DomainMatrix.to_sdm`
- Relation: For dense DomainMatrix `A = DomainMatrix([[1, 0], [0, 2]], (2, 2), QQ)`, `A.to_sdm()` equals `SDM({0: {0: 1}, 1: {1: 2}}, (2, 2), QQ)` and `type(A.to_sdm()) is SDM`.
- Expected: Returned object is an `SDM`; its dict form, `shape`, and `domain` match the original matrix values.
- Evidence: Interface Description 1; `test_xxm.py:198-200`; `sdm.py:614`.
- Observe: RETURN_VALUE plus FIELD_READ on returned object's dict/`shape`/`domain`.
- Target: N2 -> N19 via E1.
- Obligations: R1, R7.
- Graph: N2, N19, E1.

### C2: to_sparse converts dense representation
- Type: Interface / State
- Subject: `DomainMatrix.to_sparse`
- Relation: `A = DomainMatrix([[1, 0], [0, 2]], (2, 2), QQ)`; `B = A.to_sparse()`; `B.rep.fmt == 'sparse'` and `B.rep == {0: {0: 1}, 1: {1: 2}}`.
- Expected: Dense rep becomes sparse SDM wrapped in a DomainMatrix.
- Evidence: Interface Description 1; `test_domainmatrix.py:267-270`.
- Observe: FIELD_READ on `B.rep` and `B.rep.fmt`.
- Target: N3 -> N18/N19/N20 via E2.
- Obligations: R2, R7.
- Graph: N3, E2.

### C3: to_sparse returns self for already sparse representation
- Type: State / Identity
- Subject: `DomainMatrix.to_sparse`
- Relation: `A = DomainMatrix({0: {0: 1}, 1: {1: 2}}, (2, 2), QQ)`; `A.to_sparse() is A`.
- Expected: Same object is returned when `A.rep.fmt == 'sparse'`.
- Evidence: Interface Description 1 Notes.
- Observe: RETURN_VALUE identity (`is`) and FIELD_READ `A.rep.fmt`.
- Target: N3 -> N1 via E3.
- Obligations: R2.
- Graph: N3, N1, E3.

### C4: to_sdm/to_sparse preserve shape and domain
- Type: Compatibility / Field read
- Subject: `DomainMatrix.to_sdm` and `DomainMatrix.to_sparse`
- Relation: For any test matrix, returned SDM or sparse DomainMatrix has the original `shape` and `domain`.
- Expected: `shape` and `domain` attributes equal those of `self`.
- Evidence: Interface Description 1; task requirement 5.
- Observe: FIELD_READ on `shape` and `domain`.
- Target: N2/N3 via E1/E2.
- Obligations: R1, R2, R7.
- Graph: N2, N3, E1, E2.

### C5: nullspace over QQ returns expected basis
- Type: Linear algebra / Return value
- Subject: `DomainMatrix.nullspace(divide_last=False)`
- Relation: `A = DM([[2, -2], [4, -4]], QQ)`; `A.nullspace() == DomainMatrix([[1, 1]], (1, 2), QQ)`.
- Expected: Returned DomainMatrix rows form the nullspace basis.
- Evidence: Interface Description 1 example.
- Observe: RETURN_VALUE equality with the documented DomainMatrix.
- Target: N4 -> N8 -> N9 and N4 -> N5 via E4, E5, E6.
- Obligations: R3, R9.
- Graph: N4, N8, N9, N5.

### C6: nullspace over ZZ returns unnormalized ring basis
- Type: Linear algebra / Domain compatibility
- Subject: `DomainMatrix.nullspace(divide_last=False)`
- Relation: `B = DM([[6, -3], [4, -2]], ZZ)`; `B.nullspace() == DomainMatrix([[3, 6]], (1, 2), ZZ)`.
- Expected: Result remains in ZZ and is not normalized to field fractions.
- Evidence: Interface Description 1 example; `test_domainmatrix.py:762-764`.
- Observe: RETURN_VALUE equality and FIELD_READ `result.domain == ZZ`.
- Target: N4 -> N8 -> N9 -> N13 (FF over ring).
- Obligations: R3, R9.
- Graph: N4, N8, N9, N13.

### C7: nullspace divide_last over non-field raises DMNotAField
- Type: Failure / Exception
- Subject: `DomainMatrix.nullspace(divide_last=True)`
- Relation: `DM([[6, -3], [4, -2]], ZZ).nullspace(divide_last=True)` raises `DMNotAField`.
- Expected: Exception type `DMNotAField`; diagnostic indicates normalization over a non-field is not allowed.
- Evidence: Interface Description 1 Raises; `test_domainmatrix.py:766`.
- Observe: EXCEPTION.
- Target: N4 -> E7.
- Obligations: R4.
- Graph: N4, E7.

### C8: nullspace divide_last over a field normalizes final entries
- Type: Linear algebra / Return value
- Subject: `DomainMatrix.nullspace(divide_last=True)`
- Relation: For a field-domain matrix such as `A = DM([[QQ(1), QQ(2)], [QQ(2), QQ(4)]], QQ)`, `A.nullspace(divide_last=True)` returns a DomainMatrix in which every row's final element equals `QQ.one`.
- Expected: Each row is divided by its final element; final entries are the field's unit.
- Evidence: Interface Description 1 parameter description and field example.
- Observe: RETURN_VALUE, then FIELD_READ/slice of the last column.
- Target: N4 -> N5 with normalization.
- Obligations: R4, R9.
- Graph: N4, N5, E6.

### C9: primitive returns content and primitive matrix
- Type: Factorization / Return value
- Subject: `DomainMatrix.primitive`
- Relation: `M = DM([[2, 4], [4, 12]], ZZ)`; `M.primitive() == (ZZ(2), DM([[1, 2], [2, 6]], ZZ))`.
- Expected: Tuple `(content, M_primitive)` with documented values.
- Evidence: Interface Description 1 example; `test_domainmatrix.py:669-674`.
- Observe: RETURN_VALUE tuple equality.
- Target: N6 -> N7/N25/N26 via E8, E9, E10.
- Obligations: R5.
- Graph: N6, N7, N25, N26.

### C17: primitive product identity and unit content
- Type: Factorization / State / Return value
- Subject: `DomainMatrix.primitive` and `content * M_primitive`
- Relation: For `M = DM([[2, 4], [4, 12]], ZZ)`, `content, M_primitive = M.primitive()`; `content * M_primitive == M` evaluates to `True`; `M_primitive.content() == ZZ(1)` evaluates to `True`.
- Expected: The returned content times primitive matrix reconstructs `M`, and the primitive matrix has unit content.
- Evidence: Interface Description 1 example; `test_domainmatrix.py:669-674`.
- Observe: RETURN_VALUE tuple unpacking, then `__eq__` return values for `content * M_primitive == M` and `M_primitive.content() == ZZ(1)`.
- Target: N6 -> N30 scalar multiplication path and N7 -> N25.
- Obligations: R5.
- Graph: N6, N7, N30, E8, E9, E20.

### C10: nullspace_from_rref returns DomainMatrix basis
- Type: Compatibility / Return value
- Subject: `DomainMatrix.nullspace_from_rref`
- Relation: Given `Arref, den, pivots = A.rref_den()`, `Arref.nullspace_from_rref() == Anull` and `Arref.nullspace_from_rref(pivots) == Anull`, with dense and sparse reps.
- Expected: Returns only the DomainMatrix basis (not the lower-level `(basis, nonpivots)` tuple).
- Evidence: `test_domainmatrix.py:773-776`.
- Observe: RETURN_VALUE equality.
- Target: N5 -> N23/N24 via E11/E12.
- Obligations: R3, R6.
- Graph: N5, N23, N24, E11, E12.

### C11: rref_den default path resolves fraction-free helper
- Type: Dependency / Return value
- Subject: `DomainMatrix.rref_den` -> `_dm_rref_den` -> `_dm_rref_den_FF`
- Relation: `DM([[6, -3], [4, -2]], ZZ).rref_den()` returns a 3-tuple `(rref, denom, pivots)` with no `NameError` from `_dm_rref_den_FF`.
- Expected: Normal RREF-den result over ZZ; `_dm_rref_den_FF` is resolved.
- Evidence: `rref.py:99-102`; static issue `rref.py _dm_rref_den_FF`.
- Observe: RETURN_VALUE tuple and absence of EXCEPTION `NameError`.
- Target: N8 -> N9 -> N13.
- Obligations: R3, R8.
- Graph: N8, N9, N13, E5, E17.

### C12: QQ auto RREF resolves method-selection helper
- Type: Dependency / Return value
- Subject: `_dm_rref_choose_method_QQ`
- Relation: `DM([[QQ(1), QQ(2)], [QQ(3), QQ(4)]], QQ).rref_den()` returns `(rref, denom, pivots)` with no `NameError` from `_dm_rref_choose_method_QQ`.
- Expected: QQ auto method selection completes.
- Evidence: `rref.py:255-257`; static issue `rref.py _dm_rref_choose_method_QQ`.
- Observe: RETURN_VALUE and absence of EXCEPTION `NameError`.
- Target: N9 -> N10 -> N12 via E13, E15.
- Obligations: R3, R8.
- Graph: N9, N10, N12, E13, E15.

### C13: ZZ auto RREF resolves element-bit-length helper
- Type: Dependency / Return value
- Subject: `_dm_elements` in `_dm_rref_choose_method_ZZ`
- Relation: `DM([[ZZ(6), ZZ(-3)], [ZZ(4), ZZ(-2)]], ZZ).rref_den(method='auto')` completes without `NameError` and returns pivots matching the ZZ RREF result.
- Expected: `_dm_elements` is resolved when ZZ method selection reaches the bit-length threshold branch.
- Evidence: `rref.py:359-360`; static issue `rref.py _dm_elements`.
- Observe: RETURN_VALUE and absence of EXCEPTION `NameError`.
- Target: N10 -> N11 -> N15 via E14, E16.
- Obligations: R3, R8.
- Graph: N10, N11, N15, E14, E16.

### C14: dense GJ RREF resolves ddm_irref
- Type: Dependency / Return value
- Subject: `ddm_irref` in `_dm_rref_GJ_dense`
- Relation: A real/complex-domain matrix `DM([[RR(1.0), RR(2.0)], [RR(3.0), RR(4.0)]], RR).rref_den()` (or `method='GJ_dense'`) completes without `NameError` and returns `(rref, denom, pivots)`.
- Expected: `ddm_irref` is importable/callable and used by the dense GJ path.
- Evidence: `rref.py:208-213`; `test_rref.py:3` imports `ddm_irref`; static issues `rref.py ddm_irref` and `ddm.py ddm_irref`.
- Observe: RETURN_VALUE and absence of EXCEPTION `NameError`.
- Target: N9 -> N14 -> N16 via E19.
- Obligations: R8, R9.
- Graph: N9, N14, N16, E19.

### C15: sparse FF RREF resolves sdm_rref_den
- Type: Dependency / Return value
- Subject: `sdm_rref_den` in `SDM.rref_den`
- Relation: `DM([[ZZ(6), ZZ(-3)], [ZZ(4), ZZ(-2)]], ZZ, fmt='sparse').rref_den(method='FF')` completes without `NameError` and returns `(rref, denom, pivots)`.
- Expected: `sdm_rref_den` is resolved through `SDM.rref_den`.
- Evidence: `sdm.py:1008-1015`; `test_rref.py:5` imports `sdm_rref_den`; static issue `sdm.py sdm_rref_den`.
- Observe: RETURN_VALUE and absence of EXCEPTION `NameError`.
- Target: N13 -> N21 -> N22 via E18.
- Obligations: R3, R8.
- Graph: N13, N21, N22, E18.

### C16: primitive/content resolve dup_content import
- Type: Dependency / Return value
- Subject: `dup_content` used by `DomainMatrix.content` and `DomainMatrix.primitive`
- Relation: `M = DM([[2, 4], [4, 12]], ZZ)`; `M.content() == ZZ(2)` and `M.primitive()[0] == ZZ(2)` with no `NameError` for `dup_content`.
- Expected: `dup_content` is imported from the dense polynomial tools and returns the gcd of flat nonzero elements.
- Evidence: `domainmatrix.py:2092-2115`; static issue `domainmatrix.py dup_content`; `test_domainmatrix.py:671-674`.
- Observe: RETURN_VALUE and absence of EXCEPTION `NameError`.
- Target: N7 -> N25 via E9 and N6 -> N25.
- Obligations: R5.
- Graph: N6, N7, N25, E8, E9.
