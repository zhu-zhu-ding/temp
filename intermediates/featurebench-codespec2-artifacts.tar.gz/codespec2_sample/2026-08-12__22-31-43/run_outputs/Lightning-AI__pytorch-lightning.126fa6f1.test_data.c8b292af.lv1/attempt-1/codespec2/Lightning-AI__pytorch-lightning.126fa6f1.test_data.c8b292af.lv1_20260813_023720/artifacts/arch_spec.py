"""Executable architecture spec for DataLoader management and optimization utilities.

This spec focuses on public import/export binding, real caller-to-helper
delegation, graph connectivity, and static-issue closure. It is intentionally
not a pytest file. Run it directly after the implementation is available::

    python /agent-logs/.../artifacts/arch_spec.py
"""

from __future__ import annotations

import sys
import warnings
from contextlib import contextmanager
from pathlib import Path
from unittest import mock
from unittest.mock import Mock

import torch
from torch.utils.data import BatchSampler, DataLoader, RandomSampler, SequentialSampler

REPO = Path("/testbed")
if str(REPO / "src") not in sys.path:
    sys.path.insert(0, str(REPO / "src"))


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def check_c1_import_boundary_for_fabric_replace_dunder_methods() -> None:
    """C1/R1/R20: import boundary exposes a real context-manager function.

    Guidance: tests/tests_fabric/utilities/test_data.py:18 imports
    ``_replace_dunder_methods`` from ``lightning.fabric.utilities.data``.
    Perspective: public-surface contract. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_replace_dunder_methods``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods

    _assert(callable(_replace_dunder_methods), "_replace_dunder_methods must be callable")
    cm = _replace_dunder_methods(DataLoader, "dataset")
    _assert(hasattr(cm, "__enter__"), "context manager must have __enter__")
    _assert(hasattr(cm, "__exit__"), "context manager must have __exit__")


def check_c2_fabric_launch_reaches_replace_dunder_methods() -> None:
    """C2/R1/R5/R20: ``Fabric.launch`` -> ``_wrap_with_setup`` -> two patch contexts.

    Guidance: tests/tests_fabric/test_fabric.py::test_setup_dataloaders_captures_dataloader_arguments.
    Perspective: caller-binding contract for the fabric static issue. Source
    path/symbol: ``src/lightning/fabric/fabric.py::_wrap_with_setup``.
    """
    from lightning.fabric import Fabric
    from lightning.fabric import fabric as fabric_module

    real_replace = fabric_module._replace_dunder_methods
    replace_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []

    @contextmanager
    def recording_replace(*args: object, **kwargs: object):
        replace_calls.append((args, kwargs))
        with real_replace(*args, **kwargs):
            yield

    with mock.patch.object(fabric_module, "_replace_dunder_methods", new=recording_replace):
        fabric = Fabric(devices=1, accelerator="cpu")
        entered = []

        def run(_fabric: Fabric) -> None:
            entered.append(True)

        fabric.launch(run)

    _assert(bool(entered), "Fabric.launch must invoke the wrapped run function")
    _assert(len(replace_calls) == 2, f"expected 2 patch calls, got {len(replace_calls)}")
    _assert(replace_calls[0][0] == (DataLoader, "dataset"), "first context must patch DataLoader")
    _assert(replace_calls[1][0] == (BatchSampler,), "second context must patch BatchSampler")


def check_c7_fabric_setup_dataloaders_reaches_reinstantiate_wrapped_cls() -> None:
    """C7/R6/R21/R20: public ``Fabric.setup_dataloaders`` reaches the missing helper.

    Guidance: tests/tests_fabric/utilities/test_data.py:227-243 and
    static issue ``_reinstantiate_wrapped_cls`` in
    ``src/lightning/fabric/utilities/data.py``. Perspective: full-chain
    caller-binding proof. Source path/symbol:
    ``src/lightning/fabric/fabric.py::_setup_dataloader`` ->
    ``src/lightning/fabric/utilities/data.py::_update_dataloader`` ->
    ``src/lightning/fabric/utilities/data.py::_reinstantiate_wrapped_cls``.

    ``_get_distributed_sampler`` is patched with a local sequential sampler
    only because PyTorch's ``DistributedSampler`` requires an initialized
    process group. The repository dispatcher and the observer path stay live.
    """
    from lightning.fabric import Fabric
    from lightning.fabric.utilities import data as fdata

    fabric = Fabric(devices=1, accelerator="cpu")
    fabric._strategy.distributed_sampler_kwargs = {}

    def local_sampler(dataloader: DataLoader, **_: object) -> SequentialSampler:
        return SequentialSampler(dataloader.dataset)

    calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_reinstantiate = fdata._reinstantiate_wrapped_cls

    def recording_reinstantiate(*args: object, **kwargs: object) -> object:
        calls.append((args, kwargs))
        return real_reinstantiate(*args, **kwargs)

    with mock.patch.object(fabric, "_get_distributed_sampler", new=local_sampler), mock.patch.object(
        fdata, "_reinstantiate_wrapped_cls", new=recording_reinstantiate
    ):
        result = fabric.setup_dataloaders(DataLoader(range(8), batch_size=4), move_to_device=False)

    _assert(len(calls) == 1, f"expected _reinstantiate_wrapped_cls to be called once, got {len(calls)}")
    _assert(result is not None, "setup_dataloaders must return a wrapped dataloader")


def check_c8_fabric_setup_dataloaders_reaches_replace_value_in_saved_args() -> None:
    """C8/R7/R21/R20: public ``Fabric.setup_dataloaders`` reaches saved-arg replacement.

    Guidance: tests/tests_fabric/utilities/test_data.py:422-535 and static
    issue ``_replace_value_in_saved_args``. Perspective: full-chain
    caller-binding proof for custom batch-sampler reconstruction. Source
    path/symbol: ``src/lightning/fabric/fabric.py::_setup_dataloader`` ->
    ``src/lightning/fabric/utilities/data.py::_update_dataloader`` ->
    ``_get_dataloader_init_args_and_kwargs`` ->
    ``_dataloader_init_kwargs_resolve_sampler`` ->
    ``_replace_value_in_saved_args``.
    """
    from lightning.fabric import Fabric
    from lightning.fabric.utilities import data as fdata
    from lightning.fabric.utilities.data import _replace_dunder_methods

    class MyBatchSampler(BatchSampler):
        def __init__(self, sampler: object, extra_arg: str, drop_last: bool = True) -> None:
            self.extra_arg = extra_arg
            super().__init__(sampler, 10, drop_last)

    sampler = RandomSampler(range(10))
    with _replace_dunder_methods(BatchSampler):
        batch_sampler = MyBatchSampler(sampler, "random_str")
    dataloader = DataLoader(range(10), batch_sampler=batch_sampler)

    fabric = Fabric(devices=1, accelerator="cpu")
    fabric._strategy.distributed_sampler_kwargs = {}

    def local_sampler(dataloader: DataLoader, **_: object) -> SequentialSampler:
        return SequentialSampler(dataloader.dataset)

    calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_replace = fdata._replace_value_in_saved_args

    def recording_replace(*args: object, **kwargs: object) -> object:
        calls.append((args, kwargs))
        return real_replace(*args, **kwargs)

    with mock.patch.object(fabric, "_get_distributed_sampler", new=local_sampler), mock.patch.object(
        fdata, "_replace_value_in_saved_args", new=recording_replace
    ):
        result = fabric.setup_dataloaders(dataloader, move_to_device=False)

    _assert(len(calls) == 1, f"expected _replace_value_in_saved_args to be called once, got {len(calls)}")
    _assert(calls[0][0][0] == "sampler", "replacement key must be 'sampler'")
    _assert(result is not None, "setup_dataloaders must return a wrapped dataloader")


def check_c24_c27_predict_trainer_predict_static_chain() -> None:
    """C24/C27/R13/R14/R18/R19/R20: public ``Trainer.predict`` reaches pytorch ``_update_dataloader``
    and ``prediction_loop.has_len_all_ranks``.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py:261-335 and
    tests/tests_pytorch/trainer/test_dataloaders.py:704-739. Perspective:
    public trainer entry -> loop setup -> data connector/loop call-site
    binding. Source path/symbol:
    ``src/lightning/pytorch/trainer/trainer.py::Trainer.predict`` ->
    ``src/lightning/pytorch/loops/prediction_loop.py::setup_data`` ->
    ``src/lightning/pytorch/trainer/connectors/data_connector.py::_prepare_dataloader``
    and ``src/lightning/pytorch/loops/prediction_loop.py::has_len_all_ranks``.
    """
    from lightning.pytorch import Trainer
    from lightning.pytorch.demos.boring_classes import BoringModel
    from lightning.pytorch.loops import prediction_loop
    from lightning.pytorch.overrides.distributed import _IndexBatchSamplerWrapper
    from lightning.pytorch.trainer.connectors import data_connector
    from lightning.pytorch.trainer.states import RunningStage

    update_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_update = data_connector._update_dataloader

    def recording_update(*args: object, **kwargs: object) -> object:
        update_calls.append((args, kwargs))
        return real_update(*args, **kwargs)

    len_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_len = prediction_loop.has_len_all_ranks

    def recording_len(*args: object, **kwargs: object) -> object:
        len_calls.append((args, kwargs))
        return real_len(*args, **kwargs)

    model = BoringModel()
    trainer = Trainer(
        devices=1,
        accelerator="cpu",
        logger=False,
        enable_checkpointing=False,
        limit_predict_batches=1,
    )
    with mock.patch.object(data_connector, "_update_dataloader", new=recording_update), mock.patch.object(
        prediction_loop, "has_len_all_ranks", new=recording_len
    ):
        trainer.predict(model)

    _assert(len(update_calls) >= 1, "prediction setup must call _update_dataloader")
    _assert(update_calls[0][1].get("mode") == RunningStage.PREDICTING, "_update_dataloader must receive PREDICTING mode")
    _assert(len(len_calls) >= 1, "prediction setup must call has_len_all_ranks")
    pred_dataloader = trainer.predict_dataloaders
    _assert(pred_dataloader is not None, "predict_dataloaders must be available after predict")
    _assert(
        isinstance(pred_dataloader.batch_sampler, _IndexBatchSamplerWrapper),
        "prediction dataloader batch_sampler must be wrapped by _IndexBatchSamplerWrapper",
    )


def check_c25_c26_c27_eval_c28_trainer_validate_static_chain() -> None:
    """C25/C26/C27/C28/R1/R5/R15/R16/R17/R18/R19/R20: public ``Trainer.validate``
    reaches ``_replace_dunder_methods``, ``_is_dataloader_shuffled``,
    ``evaluation_loop.has_len_all_ranks``, and ``extract_batch_size``.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py:420-449,
    tests/tests_pytorch/trainer/test_dataloaders.py:704-739, and
    ``result.py`` static issue. Perspective: one public validation path closes
    the three loop/connector/logger static-issue call sites with live
    repository dispatchers. Source path/symbol:
    ``Trainer.validate`` -> ``evaluation_loop.setup_data`` ->
    ``_request_dataloader`` -> ``_process_dataloader`` -> loop length check ->
    ``LightningModule.log`` -> ``_ResultCollection.log`` ->
    ``extract_batch_size``.
    """
    from contextlib import contextmanager as cm

    from lightning.pytorch import Trainer
    from lightning.pytorch.demos.boring_classes import BoringModel
    from lightning.pytorch.loops import evaluation_loop
    from lightning.pytorch.trainer.connectors import data_connector
    from lightning.pytorch.trainer.connectors.logger_connector import result as result_module
    from lightning.pytorch.utilities import data as data_utils
    from torch.utils.data import IterableDataset

    class IterableWithLen(IterableDataset):
        def __iter__(self):
            return iter(torch.randn(4, 32))

        def __len__(self) -> int:
            return 4

    replace_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_replace = data_connector._replace_dunder_methods

    @cm
    def recording_replace(*args: object, **kwargs: object):
        replace_calls.append((args, kwargs))
        with real_replace(*args, **kwargs):
            yield

    shuffle_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_shuffle = data_connector._is_dataloader_shuffled

    def recording_shuffle(*args: object, **kwargs: object) -> object:
        shuffle_calls.append((args, kwargs))
        return real_shuffle(*args, **kwargs)

    len_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_len = evaluation_loop.has_len_all_ranks

    def recording_len(*args: object, **kwargs: object) -> object:
        len_calls.append((args, kwargs))
        return real_len(*args, **kwargs)

    extract_calls: list[tuple[object, object]] = []
    real_extract = result_module.extract_batch_size

    def recording_extract(batch: object) -> int:
        size = real_extract(batch)
        extract_calls.append((batch, size))
        return size

    class ValidateModel(BoringModel):
        def val_dataloader(self) -> DataLoader:
            self.hook_loader = DataLoader(IterableWithLen(), batch_size=2)
            return self.hook_loader

        def validation_step(self, batch: object, batch_idx: int) -> dict[str, torch.Tensor]:
            self.log("val_tensor", torch.tensor(0.0), on_epoch=True, on_step=False, batch_size=None)
            return {"val_loss": torch.tensor(0.0)}

    model = ValidateModel()
    trainer = Trainer(
        devices=1,
        accelerator="cpu",
        logger=False,
        enable_checkpointing=False,
        limit_val_batches=1,
    )
    with mock.patch.object(data_connector, "_replace_dunder_methods", new=recording_replace), mock.patch.object(
        data_connector, "_is_dataloader_shuffled", new=recording_shuffle
    ), mock.patch.object(evaluation_loop, "has_len_all_ranks", new=recording_len), mock.patch.object(
        result_module, "extract_batch_size", new=recording_extract
    ), warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        trainer.validate(model)

    _assert(len(replace_calls) == 2, f"expected 2 _replace_dunder_methods calls, got {len(replace_calls)}")
    _assert(replace_calls[0][0] == (DataLoader, "dataset"), "first replace call must wrap DataLoader with dataset")
    _assert(replace_calls[1][0] == (BatchSampler,), "second replace call must wrap BatchSampler")
    _assert(hasattr(model.hook_loader, "__pl_saved_args"), "hook-created DataLoader must carry __pl_saved_args")
    _assert(len(shuffle_calls) >= 1, "validation processing must call _is_dataloader_shuffled")
    _assert(len(len_calls) >= 1, "evaluation setup must call has_len_all_ranks")
    _assert(len(extract_calls) >= 1, "validation logging must call extract_batch_size")
    _assert(extract_calls[0][1] == 2, f"extracted batch size must be 2, got {extract_calls[0][1]!r}")
    _assert(
        any("IterableDataset" in str(w.message) and "__len__" in str(w.message) for w in caught),
        "sized IterableDataset validation must emit the documented __len__ warning",
    )
    _assert(real_extract is data_utils.extract_batch_size, "result.extract_batch_size must bind to pytorch data utility")


def check_c27_fit_trainer_fit_static_chain() -> None:
    """C27/R18/R19/R20: public ``Trainer.fit`` reaches ``fit_loop.has_len_all_ranks``.

    Guidance: tests/tests_pytorch/trainer/test_dataloaders.py:704-739 and
    ``fit_loop.py`` static issue. Perspective: public trainer entry -> fit loop
    caller binding. Source path/symbol:
    ``src/lightning/pytorch/trainer/trainer.py::Trainer.fit`` ->
    ``src/lightning/pytorch/loops/fit_loop.py::setup_data`` ->
    ``has_len_all_ranks``.
    """
    from lightning.pytorch import Trainer
    from lightning.pytorch.demos.boring_classes import BoringModel
    from lightning.pytorch.loops import fit_loop

    len_calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    real_len = fit_loop.has_len_all_ranks

    def recording_len(*args: object, **kwargs: object) -> object:
        len_calls.append((args, kwargs))
        return real_len(*args, **kwargs)

    trainer = Trainer(
        devices=1,
        accelerator="cpu",
        logger=False,
        enable_checkpointing=False,
        max_epochs=1,
        limit_train_batches=1,
        limit_val_batches=0,
        num_sanity_val_steps=0,
    )
    with mock.patch.object(fit_loop, "has_len_all_ranks", new=recording_len):
        trainer.fit(BoringModel())

    _assert(len(len_calls) >= 2, f"fit loop setup must call has_len_all_ranks at least twice, got {len(len_calls)}")


def check_c30_existing_optimization_utilities_preserved() -> None:
    """C30/R22: ``_set_sampler_epoch`` and ``suggested_max_num_workers`` remain functional.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_set_sampler_epoch and
    test_suggested_max_num_workers. Perspective: compatibility boundary for
    pre-existing utilities. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_set_sampler_epoch`` and
    ``::suggested_max_num_workers``.
    """
    from lightning.fabric.utilities import data as fdata
    from lightning.fabric.utilities.data import _set_sampler_epoch, suggested_max_num_workers

    dataloader = Mock()
    dataloader.sampler = Mock()
    dataloader.sampler.set_epoch = Mock()
    dataloader.batch_sampler = Mock()
    dataloader.batch_sampler.sampler = Mock()
    dataloader.batch_sampler.sampler.set_epoch = Mock()
    _set_sampler_epoch(dataloader, 55)
    dataloader.sampler.set_epoch.assert_called_once_with(55)
    dataloader.batch_sampler.sampler.set_epoch.assert_called_once_with(55)

    with mock.patch.object(fdata, "_num_cpus_available", return_value=4):
        _assert(suggested_max_num_workers(1) == 3, "4 cpus / 1 rank - 1 must suggest 3")
        _assert(suggested_max_num_workers(2) == 1, "4 cpus / 2 ranks - 1 must suggest 1")
        _assert(suggested_max_num_workers(4) == 1, "4 cpus / 4 ranks - 1 must floor at 1")

    try:
        suggested_max_num_workers(0)
    except ValueError as exc:
        _assert(">= 1" in str(exc), "ValueError diagnostic must mention >= 1")
    else:
        raise AssertionError("suggested_max_num_workers(0) must raise ValueError")


CHECKS = [
    check_c1_import_boundary_for_fabric_replace_dunder_methods,
    check_c2_fabric_launch_reaches_replace_dunder_methods,
    check_c7_fabric_setup_dataloaders_reaches_reinstantiate_wrapped_cls,
    check_c8_fabric_setup_dataloaders_reaches_replace_value_in_saved_args,
    check_c24_c27_predict_trainer_predict_static_chain,
    check_c25_c26_c27_eval_c28_trainer_validate_static_chain,
    check_c27_fit_trainer_fit_static_chain,
    check_c30_existing_optimization_utilities_preserved,
]


if __name__ == "__main__":
    failures = []
    for check in CHECKS:
        try:
            check()
        except Exception as exc:  # noqa: BLE001 - executable spec must report and continue
            failures.append((check.__name__, exc))
            print(f"FAIL: {check.__name__}: {exc}")
        else:
            print(f"PASS: {check.__name__}")
    if failures:
        raise SystemExit(1)
    print("PASS: all architecture checks")
