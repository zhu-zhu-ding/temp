"""Executable behavior spec for DataLoader management and optimization utilities.

This spec focuses on states, outcomes, defaults, failures, side effects,
boundaries, and compatibility. It is intentionally not a pytest file. Run it
directly after the implementation is available::

    python /agent-logs/.../artifacts/behavior_spec.py
"""

from __future__ import annotations

import contextlib
import random
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path
from unittest import mock
from unittest.mock import Mock

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import BatchSampler, DataLoader, IterableDataset, RandomSampler, SequentialSampler, TensorDataset

REPO = Path("/testbed")
if str(REPO / "src") not in sys.path:
    sys.path.insert(0, str(REPO / "src"))


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _assert_raises(exc_type: type[BaseException], match: str | None, fn) -> None:
    try:
        fn()
    except exc_type as exc:
        if match is not None:
            _assert(match in str(exc), f"exception text {str(exc)!r} must contain {match!r}")
    except BaseException as exc:  # noqa: BLE001 - diagnostic for wrong exception type
        raise AssertionError(f"expected {exc_type.__name__}, got {type(exc).__name__}: {exc}") from exc
    else:
        raise AssertionError(f"expected {exc_type.__name__}, but no exception was raised")


# ---------------------------------------------------------------------------
# Reusable classes and cases for _replace_dunder_methods contracts.
# ---------------------------------------------------------------------------
class _MyBaseDataLoader(DataLoader):
    pass


class _DataLoaderSubclass1(DataLoader):
    def __init__(self, attribute1: str, *args, **kwargs):
        self.at1 = attribute1
        super().__init__(*args, **kwargs)


class _DataLoaderSubclass2(_DataLoaderSubclass1):
    def __init__(self, attribute2: str, *args, **kwargs):
        self.at2 = attribute2
        super().__init__(attribute2 + "-2", *args, **kwargs)


class _MyDataLoader(_MyBaseDataLoader):
    def __init__(self, data: Tensor, *args, **kwargs):
        self.data = data
        super().__init__(range(data.size(0)), *args, **kwargs)


class _PoptorchDataLoader(DataLoader):
    def __init__(self, options, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._options = options

    @property
    def options(self):
        return self._options


class _IncompleteDataLoader(DataLoader):
    def __init__(self, dataset, batch_size, **kwargs):
        batch_size = max(batch_size - 5, 0)
        super().__init__(dataset, batch_size=batch_size, **kwargs)


class _WeirdDataLoader1(DataLoader):
    def __init__(self, arg1, arg2, **kwargs):
        self.arg1 = arg1
        super().__init__(arg2, **kwargs)


class _WeirdDataLoader2(DataLoader):
    def __init__(self, data_part1, data_part2, **kwargs):
        data = list(data_part1) + list(data_part2)
        super().__init__(data, **kwargs)


class _NoneDataLoader(DataLoader):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class _ChangingDataLoader(DataLoader):
    def __init__(self, dataset, **kwargs):
        super().__init__(list(dataset) + list(range(5, 10)), **kwargs)


_C3_TENSOR = torch.randn((10, 20))


def _c3_cases():
    return [
        (
            _DataLoaderSubclass1,
            ("attribute1",),
            {"dataset": range(4), "batch_size": 2},
            ("attribute1",),
            range(4),
            {"batch_size": 2, "at1": "attribute1"},
        ),
        (
            _DataLoaderSubclass2,
            ("attribute2",),
            {"dataset": range(4), "batch_size": 2},
            ("attribute2",),
            range(4),
            {"batch_size": 2, "at1": "attribute2-2", "at2": "attribute2"},
        ),
        (
            _MyDataLoader,
            (_C3_TENSOR,),
            {"batch_size": 2},
            ("data",),
            range(10),
            {"batch_size": 2, "data": _C3_TENSOR},
        ),
        (_PoptorchDataLoader, (123, [1]), {}, ("options",), [1], {"options": 123}),
        (
            _IncompleteDataLoader,
            (range(10),),
            {"batch_size": 10},
            ("dataset",),
            range(10),
            {"batch_size": 5},
        ),
        (
            _WeirdDataLoader1,
            (10, range(10)),
            {"batch_size": 10},
            ("arg1", "arg2"),
            range(10),
            {"arg1": 10, "batch_size": 10},
        ),
        (
            _WeirdDataLoader2,
            (range(10), range(10, 20)),
            {"batch_size": 10},
            ("data_part1", "data_part2"),
            list(range(20)),
            {"batch_size": 10},
        ),
        (_NoneDataLoader, (None,), {}, (), None, {}),
        (_ChangingDataLoader, (range(5),), {}, ("dataset",), list(range(10)), {}),
    ]


def _assert_checked_values(dataloader: DataLoader, checked_values: dict[str, object]) -> None:
    for key, value in checked_values.items():
        dataloader_value = getattr(dataloader, key)
        if isinstance(dataloader_value, Tensor):
            _assert(dataloader_value is value, f"{key} tensor identity must be preserved")
        else:
            _assert(dataloader_value == value, f"{key} value mismatch: {dataloader_value!r} != {value!r}")


# ---------------------------------------------------------------------------
# Contract checks
# ---------------------------------------------------------------------------
def check_c3_constructor_argument_capture_cases() -> None:
    """C3/R2/R3: patched constructors store args, kwargs, arg names, and default kwargs.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_replace_dunder_methods_dataloader
    and ::test_replace_dunder_methods_extra_kwargs. Perspective: exact state
    oracle for wrapped DataLoader construction. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_replace_dunder_methods``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods

    for cls, args, kwargs, arg_names, dataset, checked_values in _c3_cases():
        with _replace_dunder_methods(DataLoader, "dataset"):
            dataloader = cls(*args, **kwargs)

        _assert(dataloader.__pl_saved_args == args, f"{cls.__name__}: saved args mismatch")
        _assert(dataloader.__pl_saved_kwargs == kwargs, f"{cls.__name__}: saved kwargs mismatch")
        _assert(dataloader.__pl_saved_arg_names == arg_names, f"{cls.__name__}: saved arg names mismatch")
        _assert(dataloader.__pl_saved_default_kwargs == {}, f"{cls.__name__}: default kwargs must be empty")
        _assert(dataloader.__dataset == dataset, f"{cls.__name__}: private dataset mismatch")
        _assert(dataloader.dataset == dataset, f"{cls.__name__}: public dataset mismatch")
        _assert_checked_values(dataloader, checked_values)

    class LoaderSubclass(DataLoader):
        def __init__(self, dataset, *args, batch_size=10, **kwargs):
            super().__init__(dataset, *args, batch_size=batch_size, **kwargs)

    with _replace_dunder_methods(DataLoader, "dataset"):
        dataloader = LoaderSubclass(range(10))

    _assert(dataloader.__pl_saved_args == (range(10),), "extra-kwargs: saved args mismatch")
    _assert(dataloader.__pl_saved_kwargs == {}, "extra-kwargs: saved kwargs must be empty")
    _assert(dataloader.__pl_saved_arg_names == ("dataset",), "extra-kwargs: saved arg names mismatch")
    _assert(dataloader.__pl_saved_default_kwargs == {"batch_size": 10}, "extra-kwargs: default kwargs mismatch")
    _assert(dataloader.__dataset == range(10), "extra-kwargs: private dataset mismatch")


def check_c4_explicit_dataset_private_storage() -> None:
    """C4/R3: ``__dataset`` equals the actual post-constructor dataset.

    Guidance: tests/tests_fabric/utilities/test_data.py:212-218 and cases at
    146-205. Perspective: explicit-argument storage after subclass transforms
    the dataset. Source path/symbol: wrapped ``instance.__dataset``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods

    for cls, args, kwargs, _arg_names, _dataset, _checked in _c3_cases():
        with _replace_dunder_methods(DataLoader, "dataset"):
            dataloader = cls(*args, **kwargs)
        _assert(dataloader.__dataset == dataloader.dataset, f"{cls.__name__}: __dataset must track public dataset")
        _assert(
            type(dataloader.__dataset) is type(dataloader.dataset)
            or dataloader.__dataset == dataloader.dataset,
            f"{cls.__name__}: __dataset and dataset must describe the same object",
        )


def check_c5_post_init_attribute_recording() -> None:
    """C5/R4: patched ``__setattr__``/``__delattr__`` record post-init changes and suppress failures.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_replace_dunder_methods_attrs.
    Perspective: exact ordered side-effect record. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_WrapAttrTag`` and wrapped
    instance attributes.
    """
    from lightning.fabric.utilities.data import _WrapAttrTag, _replace_dunder_methods

    class Loader(DataLoader):
        def __setattr__(self, attr, val):
            if attr == "custom_arg":
                val = val + 2
            super().__setattr__(attr, val)

    with _replace_dunder_methods(DataLoader, "dataset"):
        dataloader = Loader(range(10))
        dataloader.custom_arg = 5
        dataloader.my_arg = 10
        dataloader.another_arg = 100
        del dataloader.dataset
        with contextlib.suppress(AttributeError):
            del dataloader.abc_arg

    expected_record = [
        (("custom_arg", 5), _WrapAttrTag.SET),
        (("my_arg", 10), _WrapAttrTag.SET),
        (("another_arg", 100), _WrapAttrTag.SET),
        (("dataset",), _WrapAttrTag.DEL),
    ]
    _assert(dataloader.__pl_attrs_record == expected_record, f"attrs record mismatch: {dataloader.__pl_attrs_record!r}")
    _assert(dataloader.custom_arg == 7, "custom __setattr__ transformation must be preserved")
    _assert(dataloader.my_arg == 10, "plain setattr must be preserved")
    _assert(dataloader.another_arg == 100, "plain setattr must be preserved")
    _assert(not hasattr(dataloader, "dataset"), "successful deletion must remove dataset")



def check_c6_dunder_scope_and_restoration() -> None:
    """C6/R5: only classes that own dunder methods are patched; methods restore on exit.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_replace_dunder_methods_multiple_loaders_without_init
    and ::test_replace_dunder_methods_restore_methods. Perspective: lifecycle,
    inheritance-scope, and patch-scope oracle for all three dunder methods.
    Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_replace_dunder_methods``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods

    classes = [DataLoader]
    random.seed(0)
    for i in range(100):
        classes.append(type(f"DataLoader_{i}", (random.choice(classes),), {}))

    before_init = {cls: cls.__init__ for cls in classes}
    before_setattr = {cls: cls.__setattr__ for cls in classes}
    before_delattr = {cls: cls.__delattr__ for cls in classes}
    with _replace_dunder_methods(DataLoader, "dataset"):
        _assert("__old__init__" in DataLoader.__dict__, "DataLoader must own __old__init__ while wrapped")
        _assert("__old__setattr__" in DataLoader.__dict__, "DataLoader must own __old__setattr__ while wrapped")
        _assert("__old__delattr__" in DataLoader.__dict__, "DataLoader must own __old__delattr__ while wrapped")
        for cls in classes[1:]:
            _assert("__old__init__" not in cls.__dict__, f"{cls.__name__} must not own __old__init__")
            _assert(hasattr(cls, "__old__init__"), f"{cls.__name__} must inherit __old__init__")
            _assert("__old__setattr__" not in cls.__dict__, f"{cls.__name__} must not own __old__setattr__")
            _assert(hasattr(cls, "__old__setattr__"), f"{cls.__name__} must inherit __old__setattr__")
            _assert("__old__delattr__" not in cls.__dict__, f"{cls.__name__} must not own __old__delattr__")
            _assert(hasattr(cls, "__old__delattr__"), f"{cls.__name__} must inherit __old__delattr__")

    for cls in classes:
        _assert(before_init[cls] == cls.__init__, f"{cls.__name__} __init__ must be restored")
        _assert(before_setattr[cls] == cls.__setattr__, f"{cls.__name__} __setattr__ must be restored")
        _assert(before_delattr[cls] == cls.__delattr__, f"{cls.__name__} __delattr__ must be restored")

    class Init(DataLoader):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class SetAttr(DataLoader):
        def __setattr__(self, *args):
            return super().__setattr__(*args)

    class DelAttr(DataLoader):
        def __delattr__(self, *args):
            return super().__delattr__(*args)

    class InitAndSetAttr(Init, SetAttr):
        pass

    class InitAndDelAttr(Init, DelAttr):
        pass

    class SetAttrAndDelAttr(SetAttr, DelAttr):
        pass

    class AllDunder(Init, SetAttr, DelAttr):
        pass

    dunder_classes = (Init, SetAttr, DelAttr, InitAndSetAttr, InitAndDelAttr, SetAttrAndDelAttr, AllDunder)
    before = {cls: {"init": cls.__init__, "setattr": cls.__setattr__, "delattr": cls.__delattr__} for cls in dunder_classes}

    with _replace_dunder_methods(DataLoader, "dataset"):
        _assert("__old__setattr__" in DataLoader.__dict__, "base class must always own __old__setattr__")
        _assert("__old__delattr__" in DataLoader.__dict__, "base class must always own __old__delattr__")
        _assert("__old__init__" in Init.__dict__, "Init must own __old__init__")
        _assert("__old__setattr__" in SetAttr.__dict__, "SetAttr must own __old__setattr__")
        _assert("__old__delattr__" in DelAttr.__dict__, "DelAttr must own __old__delattr__")
        _assert("__old__setattr__" not in DelAttr.__dict__, "DelAttr must not own __old__setattr__")
        _assert(hasattr(DelAttr, "__old__setattr__"), "DelAttr must inherit __old__setattr__")
        _assert("__old__delattr__" not in SetAttr.__dict__, "SetAttr must not own __old__delattr__")
        _assert(hasattr(SetAttr, "__old__delattr__"), "SetAttr must inherit __old__delattr__")
        _assert("__old__setattr__" not in InitAndSetAttr.__dict__, "InitAndSetAttr must inherit, not own, __old__setattr__")
        _assert(hasattr(InitAndSetAttr, "__old__setattr__"), "InitAndSetAttr must inherit __old__setattr__")
        _assert("__old__delattr__" not in InitAndDelAttr.__dict__, "InitAndDelAttr must inherit, not own, __old__delattr__")
        _assert(hasattr(InitAndDelAttr, "__old__delattr__"), "InitAndDelAttr must inherit __old__delattr__")
        _assert("__old__setattr__" not in SetAttrAndDelAttr.__dict__, "SetAttrAndDelAttr must inherit __old__setattr__")
        _assert(hasattr(SetAttrAndDelAttr, "__old__setattr__"), "SetAttrAndDelAttr must inherit __old__setattr__")
        _assert("__old__delattr__" not in SetAttrAndDelAttr.__dict__, "SetAttrAndDelAttr must inherit __old__delattr__")
        _assert(hasattr(SetAttrAndDelAttr, "__old__delattr__"), "SetAttrAndDelAttr must inherit __old__delattr__")

    for cls in dunder_classes:
        _assert(before[cls] == {"init": cls.__init__, "setattr": cls.__setattr__, "delattr": cls.__delattr__},
                f"{cls.__name__} dunder methods must be restored")
def check_c7_reinstantiation_clears_saved_attrs_and_replays_changes() -> None:
    """C7/R6/R21: fabric ``_update_dataloader`` reconstructs and replays attr records.

    Guidance: tests/tests_fabric/utilities/test_data.py:227-243,299-303.
    Perspective: reconstruction outcome and metadata cleanup. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_update_dataloader`` ->
    ``_reinstantiate_wrapped_cls``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods, _update_dataloader

    class Loader(DataLoader):
        def __setattr__(self, attr, val):
            if attr == "custom_arg":
                val = val + 2
            super().__setattr__(attr, val)

    with _replace_dunder_methods(DataLoader, "dataset"):
        dataloader = Loader(range(10))
        dataloader.custom_arg = 5
        dataloader.my_arg = 10
        dataloader.another_arg = 100
        del dataloader.dataset

    new_dataloader = _update_dataloader(dataloader, dataloader.sampler)

    _assert(isinstance(new_dataloader, Loader), "reconstructed dataloader must preserve subclass")
    for saved_attr in ("__pl_saved_args", "__pl_saved_kwargs", "__pl_saved_arg_names", "__pl_saved_default_kwargs", "__dataset"):
        _assert(not hasattr(new_dataloader, saved_attr), f"reconstructed dataloader must not carry {saved_attr}")
    _assert(new_dataloader.custom_arg == 7, "replayed custom_arg must preserve transformed value")
    _assert(new_dataloader.my_arg == 10, "replayed my_arg mismatch")
    _assert(new_dataloader.another_arg == 100, "replayed another_arg mismatch")
    _assert(not hasattr(new_dataloader, "dataset"), "replayed deletion must keep dataset absent")


def check_c8_replace_value_in_saved_args_parameterized() -> None:
    """C8/R7: saved-argument replacement handles positional, keyword, default, and empty cases.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_replace_value_in_args.
    Perspective: exact tuple oracle for the helper. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_replace_value_in_saved_args``.
    """
    from lightning.fabric.utilities.data import _replace_value_in_saved_args

    cases = [
        ((), {}, {}, [], "a", 1, False, (), {}),
        ((1,), {}, {}, ["a"], "a", 2, True, (2,), {}),
        ((1, 2, 3), {}, {}, ["a", "b", "c"], "b", False, True, (1, False, 3), {}),
        ((1, 2, 3), {"a": 1}, {}, ["b", "c", "d"], "a", 2, True, (1, 2, 3), {"a": 2}),
        ((1, 2, 3), {"a": 1}, {"e": 5}, ["b", "c", "d"], "e", 2, True, (1, 2, 3), {"a": 1, "e": 2}),
    ]
    for args, kwargs, default_kwargs, arg_names, replace_key, replace_value, expected_status, expected_args, expected_kwargs in cases:
        result = _replace_value_in_saved_args(replace_key, replace_value, args, kwargs, default_kwargs, arg_names)
        _assert(result == (expected_status, expected_args, expected_kwargs), f"replacement result mismatch: {result!r}")


def check_c9_iterable_dataset_sampler_suppression() -> None:
    """C9/R11: iterable datasets force ``sampler`` and ``batch_sampler`` to ``None``.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_dataloader_kwargs_replacement_with_iterable_dataset.
    Perspective: dataflow for IterableDataset kwargs. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_get_dataloader_init_args_and_kwargs``.
    """
    from lightning.fabric.utilities.data import _get_dataloader_init_args_and_kwargs

    class RandomIterableDataset(IterableDataset):
        def __iter__(self):
            yield from range(100)

    dataset = RandomIterableDataset()
    dataloader = DataLoader(dataset, batch_size=32)
    _, dl_kwargs = _get_dataloader_init_args_and_kwargs(dataloader, dataloader.sampler)
    _assert(dl_kwargs["sampler"] is None, "iterable dataloader sampler must be None")
    _assert(dl_kwargs["batch_sampler"] is None, "iterable dataloader batch_sampler must be None")
    _assert(dl_kwargs["batch_size"] is dataloader.batch_size, "batch_size identity mismatch")
    _assert(dl_kwargs["dataset"] is dataloader.dataset, "dataset identity mismatch")
    _assert(dl_kwargs["collate_fn"] is dataloader.collate_fn, "collate_fn identity mismatch")


def check_c10_array_valued_attribute_default_comparison() -> None:
    """C10/R10: numpy-array attributes are preserved without ambiguous truth-value errors.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_dataloader_kwargs_replacement_with_array_default_comparison.
    Perspective: dataflow and regression boundary. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_get_dataloader_init_args_and_kwargs``.
    """
    from lightning.fabric.utilities.data import _get_dataloader_init_args_and_kwargs

    dataset = TensorDataset(torch.randn(5, 100))

    class ArrayAttributeDataloader(DataLoader):
        def __init__(self, dataset, indices=None, **kwargs):
            super().__init__(dataset)
            self.indices = np.random.rand(2, 2)

    dataloader = ArrayAttributeDataloader(dataset)
    _, dl_kwargs = _get_dataloader_init_args_and_kwargs(dataloader, dataloader.sampler)
    _assert(dl_kwargs["indices"] is dataloader.indices, "array attribute identity must be preserved")


def check_c11_invalid_dataloader_type_rejection() -> None:
    """C11/R9: pytorch ``_update_dataloader`` rejects non-DataLoader inputs with ``ValueError``.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py::test_update_dataloader_raises.
    Perspective: exact failure oracle. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_update_dataloader``.
    """
    from lightning.pytorch.utilities.data import _update_dataloader

    _assert_raises(ValueError, "needs to subclass `torch.utils.data.DataLoader", lambda: _update_dataloader(object(), object(), mode="fit"))


def check_c12_fit_missing_keyword_arguments() -> None:
    """C12/R8/R12: fit-mode sampler injection reports the exact missing keyword list.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py::test_dataloaders_with_missing_keyword_arguments.
    Perspective: failure semantics for non-variadic subclass. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_update_dataloader`` ->
    ``_get_dataloader_init_args_and_kwargs``.
    """
    from lightning.pytorch.utilities.data import _update_dataloader
    from lightning.pytorch.utilities.exceptions import MisconfigurationException

    dataset = TensorDataset(torch.randn(10, 20))

    class TestDataLoader(DataLoader):
        def __init__(self, dataset):
            super().__init__(dataset)

    loader = TestDataLoader(dataset)
    sampler = SequentialSampler(dataset)
    _assert_raises(
        MisconfigurationException,
        "missing arguments are ['batch_sampler', 'sampler', 'shuffle']",
        lambda: _update_dataloader(loader, sampler, mode="fit"),
    )


def check_c13_predict_missing_keyword_arguments_include_batch_keys() -> None:
    """C13/R12/R13: predict-mode expands the missing keyword surface with batch keys.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py:201-203.
    Perspective: mode-dependent failure oracle. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_update_dataloader`` ->
    ``_get_dataloader_init_args_and_kwargs``.
    """
    from lightning.pytorch.utilities.data import _update_dataloader
    from lightning.pytorch.utilities.exceptions import MisconfigurationException

    dataset = TensorDataset(torch.randn(10, 20))

    class TestDataLoader(DataLoader):
        def __init__(self, dataset):
            super().__init__(dataset)

    loader = TestDataLoader(dataset)
    sampler = SequentialSampler(dataset)
    _assert_raises(
        MisconfigurationException,
        "missing arguments are ['batch_sampler', 'batch_size', 'drop_last', 'sampler', 'shuffle']",
        lambda: _update_dataloader(loader, sampler, mode="predict"),
    )


def check_c14_variadic_dataloader_subclasses_reconstruct_successfully() -> None:
    """C14/R12/R14: variadic ``*args``/``**kwargs`` subclasses tolerate injected kwargs.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py:205-221.
    Perspective: compatibility and return type. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_update_dataloader``.
    """
    from lightning.pytorch.utilities.data import _update_dataloader

    dataset = TensorDataset(torch.randn(10, 20))

    class VarArgsLoader(DataLoader):
        def __init__(self, dataset, *args, **kwargs):
            super().__init__(dataset)

    class FullVariadicLoader(DataLoader):
        def __init__(self, *foo, **bar):
            super().__init__(*foo, **bar)

    sampler = SequentialSampler(dataset)
    for cls in (VarArgsLoader, FullVariadicLoader):
        loader = cls(dataset)
        for mode in ("fit", "predict"):
            result = _update_dataloader(loader, sampler, mode=mode)
            _assert(isinstance(result, DataLoader), f"{cls.__name__}/{mode} must reconstruct a DataLoader")


def check_c15_multiprocessing_context_preservation() -> None:
    """C15/R10/R14: sampler injection preserves ``multiprocessing_context``.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py::test_update_dataloader_with_multiprocessing_context.
    Perspective: dataflow preservation across reconstruction. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_update_dataloader``.
    """
    from lightning.pytorch.utilities.data import _update_dataloader

    dataset = TensorDataset(torch.randn(32, 64))
    train = DataLoader(dataset, batch_size=32, num_workers=2, multiprocessing_context="spawn", shuffle=True)
    new_data_loader = _update_dataloader(train, SequentialSampler(dataset))
    _assert(new_data_loader.multiprocessing_context == train.multiprocessing_context, "multiprocessing_context must be preserved")



def check_c16_prediction_batch_sampler_wrapper() -> None:
    """C16/R13: predict mode wraps the reconstructed batch sampler and forces drop_last=False.

    Guidance: tests/tests_pytorch/loops/test_prediction_loop.py:83-88,
    tests/tests_pytorch/trainer/test_trainer.py:1310-1311, and Interface
    Description 2 prediction notes. Perspective: prediction-mode side effect
    with a discriminating drop_last oracle. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_update_dataloader`` ->
    ``_IndexBatchSamplerWrapper``.
    """
    from lightning.pytorch.overrides.distributed import _IndexBatchSamplerWrapper
    from lightning.pytorch.utilities.data import _update_dataloader

    dataset = TensorDataset(torch.randn(5, 3))
    dataloader = DataLoader(dataset, batch_size=2, drop_last=True)
    new_dataloader = _update_dataloader(dataloader, SequentialSampler(dataset), mode="predict")
    _assert(isinstance(new_dataloader.batch_sampler, _IndexBatchSamplerWrapper), "predict mode must wrap batch_sampler")
    _assert(new_dataloader.batch_sampler.drop_last is False, "predict mode must force drop_last=False")

def check_c17_shuffle_detection_through_samplers() -> None:
    """C17/R15: sampler type determines ``_is_dataloader_shuffled`` for ordinary and batch-sampler paths.

    Guidance: tests/tests_pytorch/trainer/connectors/test_data_connector.py:420-449
    and Interface Description 2 batch-sampler fallback notes. Perspective:
    return-value oracle by sampler class and batch-sampler fallback. Source
    path/symbol: ``src/lightning/pytorch/utilities/data.py::_is_dataloader_shuffled``.
    """
    from types import SimpleNamespace

    from lightning.pytorch.utilities.data import _is_dataloader_shuffled

    dataset = TensorDataset(torch.randn(64, 2))
    _assert(_is_dataloader_shuffled(DataLoader(dataset, shuffle=True)) is True, "RandomSampler dataloader must be shuffled")
    _assert(_is_dataloader_shuffled(DataLoader(dataset)) is False, "default SequentialSampler dataloader must not be shuffled")
    _assert(_is_dataloader_shuffled(DataLoader(dataset, sampler=list(range(64)))) is False, "list sampler must default to not shuffled")

    class IterableWithoutLen(IterableDataset):
        def __iter__(self):
            yield from range(10)

    _assert(_is_dataloader_shuffled(DataLoader(IterableWithoutLen(), batch_size=2)) is False, "IterableDataset must not be shuffled")

    internal_random = SimpleNamespace(sampler=RandomSampler(range(10)))
    _assert(_is_dataloader_shuffled(SimpleNamespace(dataset=dataset, sampler=None, batch_sampler=internal_random)) is True,
            "batch_sampler with internal RandomSampler must be shuffled")
    internal_sequential = SimpleNamespace(sampler=SequentialSampler(range(10)))
    _assert(_is_dataloader_shuffled(SimpleNamespace(dataset=dataset, sampler=None, batch_sampler=internal_sequential)) is False,
            "batch_sampler with internal SequentialSampler must not be shuffled")
    fallback_random = RandomSampler(range(10))
    _assert(_is_dataloader_shuffled(SimpleNamespace(dataset=dataset, sampler=None, batch_sampler=fallback_random)) is True,
            "batch_sampler itself must be used as fallback when no internal sampler exists")
def check_c18_shuffle_detection_honors_saved_constructor_args() -> None:
    """C18/R15: wrapped-DataLoader saved shuffle args take precedence over sampler fallback.

    Guidance: Interface Description 2 notes and saved-arg capture contract C3.
    Perspective: precedence/representation-preservation oracle. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_is_dataloader_shuffled``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods
    from lightning.pytorch.utilities.data import _is_dataloader_shuffled

    class ContradictoryLoader(DataLoader):
        def __init__(self, dataset, shuffle=False, **kwargs):
            super().__init__(dataset, shuffle=True, **kwargs)

    with _replace_dunder_methods(DataLoader, "dataset"):
        loader_false = ContradictoryLoader(range(10), shuffle=False)
        loader_true = ContradictoryLoader(range(10), shuffle=True)

    _assert(_is_dataloader_shuffled(loader_false) is False, "saved shuffle=False must override RandomSampler fallback")
    _assert(_is_dataloader_shuffled(loader_true) is True, "saved shuffle=True must return True")


def check_c19_batch_size_extraction_from_tensors_and_containers() -> None:
    """C19/R16: ``extract_batch_size`` recursively finds tensor first dimension.

    Guidance: Interface Description 2 and existing generator
    ``src/lightning/pytorch/utilities/data.py::_extract_batch_size``.
    Perspective: dataflow across representations. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::extract_batch_size``.
    """
    from lightning.pytorch.utilities.data import extract_batch_size
    from lightning.pytorch.utilities.exceptions import MisconfigurationException

    @dataclass
    class DataClassBatch:
        x: Tensor

    _assert(extract_batch_size(torch.zeros(3, 4)) == 3, "tensor batch size must be first dim")
    _assert(extract_batch_size(torch.tensor(1.0)) == 1, "scalar tensor batch size must be 1")
    _assert(extract_batch_size({"a": torch.zeros(3, 4), "b": torch.zeros(3, 4)}) == 3, "mapping batch size mismatch")
    _assert(extract_batch_size(DataClassBatch(torch.zeros(5, 2))) == 5, "dataclass batch size mismatch")
    _assert_raises(MisconfigurationException, None, lambda: extract_batch_size("a string"))



def check_c20_ambiguous_batch_warning_and_tensor_free_failure() -> None:
    """C20/R17: ambiguous tensor sizes warn and use first size; no-tensor input raises; cycles surface RecursionError.

    Guidance: Interface Description 2 notes and Raises; ``MisconfigurationException``
    and ``WarningCache`` imports at ``src/lightning/pytorch/utilities/data.py``.
    Perspective: side-effect and failure boundaries, including recursive
    failure. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::extract_batch_size``.
    """
    from lightning.pytorch.utilities.data import extract_batch_size
    from lightning.pytorch.utilities.exceptions import MisconfigurationException

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = extract_batch_size({"a": torch.zeros(2, 3), "b": torch.zeros(3, 3)})

    _assert(result == 2, "first encountered tensor size must win")
    _assert(len(caught) >= 1, "ambiguous batch sizes must emit a warning")
    _assert_raises(MisconfigurationException, None, lambda: extract_batch_size([object()]))

    circular = []
    circular.append(circular)
    _assert_raises(RecursionError, None, lambda: extract_batch_size(circular))
def check_c21_has_len_all_ranks_false_without_len() -> None:
    """C21/R18: local absence of ``__len__`` short-circuits distributed validation.

    Guidance: tests/tests_pytorch/trainer/test_dataloaders.py:732-734.
    Perspective: local-length gate. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::has_len_all_ranks``.
    """
    from lightning.pytorch.utilities.data import has_len_all_ranks

    class IterableWithoutLen(IterableDataset):
        def __iter__(self):
            yield from range(10)

    dataloader = DataLoader(IterableWithoutLen(), batch_size=16)
    strategy = Mock()
    strategy.reduce = Mock(side_effect=AssertionError("strategy.reduce must not be called when __len__ is absent"))
    _assert(has_len_all_ranks(dataloader, strategy) is False, "object without __len__ must return False")
    strategy.reduce.assert_not_called()



def check_c22_has_len_all_ranks_true_for_sized_iterable_dataloader() -> None:
    """C22/R18/R19: local length present returns true and reduces the actual local length tensor.

    Guidance: tests/tests_pytorch/trainer/test_dataloaders.py:717-729 and
    Strategy.reduce contract at ``src/lightning/pytorch/strategies/strategy.py``.
    Perspective: sized IterableDataset validation with an exact reduce-tensor
    oracle. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::has_len_all_ranks``.
    """
    from lightning.fabric.utilities.data import sized_len
    from lightning.pytorch.utilities.data import has_len_all_ranks

    class IterableWithLen(IterableDataset):
        def __iter__(self):
            return iter(torch.randn(8, 32))

        def __len__(self) -> int:
            return 8

    dataloader = DataLoader(IterableWithLen(), batch_size=16)
    local_len = sized_len(dataloader)
    _assert(local_len is not None, "sized IterableDataset DataLoader must expose a local length")
    strategy = Mock()
    strategy.root_device = torch.device("cpu")
    strategy.world_size = 1
    strategy.reduce.return_value = torch.tensor(local_len, device=strategy.root_device)
    _assert(has_len_all_ranks(dataloader, strategy) is True, "sized IterableDataset must return True")
    strategy.reduce.assert_called_once()
    reduce_tensor = strategy.reduce.call_args[0][0]
    _assert(torch.is_tensor(reduce_tensor), "strategy.reduce must receive a tensor")
    _assert(reduce_tensor.item() == local_len, f"reduce tensor value must be {local_len}, got {reduce_tensor.item()!r}")
    _assert(strategy.reduce.call_args.kwargs.get("reduce_op") == "sum", "strategy.reduce must use sum reduction")

def check_c23_distributed_length_reduction_and_zero_length_runtime_error() -> None:
    """C23/R19: strategy total length drives zero-local-length policy, total-zero warning, and uneven warning.

    Guidance: Interface Description 2 Raises and Notes; strategy reduce
    interface at ``src/lightning/pytorch/strategies/strategy.py``. Perspective:
    distributed failure and warning boundaries with exact reduce-tensor
    observations. Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::has_len_all_ranks``.
    """
    from lightning.fabric.utilities.data import sized_len
    from lightning.pytorch.utilities.data import has_len_all_ranks

    dataloader = DataLoader(TensorDataset(torch.empty(0, 2)), batch_size=1)
    local_len = sized_len(dataloader)

    strategy = Mock()
    strategy.root_device = torch.device("cpu")
    strategy.world_size = 2
    strategy.reduce.return_value = torch.tensor(3, device=strategy.root_device)
    _assert_raises(
        RuntimeError,
        None,
        lambda: has_len_all_ranks(dataloader, strategy, allow_zero_length_dataloader_with_multiple_devices=False),
    )
    strategy.reduce.assert_called_once()
    _assert(strategy.reduce.call_args[0][0].item() == local_len, "zero-local-length reduce tensor must carry local length")
    _assert(strategy.reduce.call_args.kwargs.get("reduce_op") == "sum", "zero-local-length reduction must use sum")

    strategy_allow = Mock()
    strategy_allow.root_device = torch.device("cpu")
    strategy_allow.world_size = 2
    strategy_allow.reduce.return_value = torch.tensor(3, device=strategy_allow.root_device)
    result = has_len_all_ranks(dataloader, strategy_allow, allow_zero_length_dataloader_with_multiple_devices=True)
    _assert(result is True, "allow-zero-length path must return True after validation")
    strategy_allow.reduce.assert_called_once()
    _assert(strategy_allow.reduce.call_args[0][0].item() == local_len, "allow-zero-length reduce tensor must carry local length")
    _assert(strategy_allow.reduce.call_args.kwargs.get("reduce_op") == "sum", "allow-zero-length reduction must use sum")

    strategy_zero = Mock()
    strategy_zero.root_device = torch.device("cpu")
    strategy_zero.world_size = 1
    strategy_zero.reduce.return_value = torch.tensor(0, device=strategy_zero.root_device)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result_zero = has_len_all_ranks(
            dataloader, strategy_zero, allow_zero_length_dataloader_with_multiple_devices=True
        )
    _assert(result_zero is True, "total-zero path must still return True")
    _assert(len(caught) >= 1, "total-zero length must emit a warning")
    strategy_zero.reduce.assert_called_once()
    _assert(strategy_zero.reduce.call_args[0][0].item() == local_len, "total-zero reduce tensor must carry local length")
    _assert(strategy_zero.reduce.call_args.kwargs.get("reduce_op") == "sum", "total-zero reduction must use sum")

    uneven_loader = DataLoader(TensorDataset(torch.randn(3, 2)), batch_size=1)
    uneven_local_len = sized_len(uneven_loader)
    strategy_uneven = Mock()
    strategy_uneven.root_device = torch.device("cpu")
    strategy_uneven.world_size = 2
    strategy_uneven.reduce.return_value = torch.tensor(7, device=strategy_uneven.root_device)
    with warnings.catch_warnings(record=True) as caught_uneven:
        warnings.simplefilter("always")
        result_uneven = has_len_all_ranks(uneven_loader, strategy_uneven)
    _assert(result_uneven is True, "uneven-length path must return True")
    strategy_uneven.reduce.assert_called_once()
    _assert(strategy_uneven.reduce.call_args[0][0].item() == uneven_local_len,
            "uneven-length reduce tensor must carry local length")
    _assert(strategy_uneven.reduce.call_args.kwargs.get("reduce_op") == "sum", "uneven-length reduction must use sum")
    _assert(len(caught_uneven) >= 1, "uneven distribution across ranks must emit a warning")

def check_c29_custom_batch_sampler_compatibility() -> None:
    """C29/R21: wrapped PyTorch and doppelganger batch samplers reconstruct; unsupported and missing-sampler ones fail.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_custom_torch_batch_sampler,
    ::test_custom_torch_batch_sampler_doppelganger, ::test_custom_batch_sampler,
    and ::test_custom_batch_sampler_no_sampler. Perspective: compatibility and
    failure oracle for batch-sampler injection. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_dataloader_init_kwargs_resolve_sampler``
    -> ``_replace_value_in_saved_args`` / ``_reinstantiate_wrapped_cls``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods, _update_dataloader

    class MyBatchSampler(BatchSampler):
        def __init__(self, sampler, extra_arg, drop_last=True):
            self.extra_arg = extra_arg
            super().__init__(sampler, 10, drop_last)

    sampler = RandomSampler(range(10))
    with _replace_dunder_methods(BatchSampler):
        batch_sampler = MyBatchSampler(sampler, "random_str")
    dataloader = DataLoader(range(10), batch_sampler=batch_sampler)
    new_dataloader = _update_dataloader(dataloader, dataloader.sampler)
    new_batch_sampler = new_dataloader.batch_sampler
    _assert(isinstance(new_batch_sampler, MyBatchSampler), "wrapped custom BatchSampler must reconstruct as same class")
    _assert(new_batch_sampler.extra_arg == "random_str", "custom BatchSampler extra_arg must be replayed")
    for saved_attr in ("__pl_saved_args", "__pl_saved_kwargs", "__pl_saved_arg_names", "__pl_saved_default_kwargs"):
        _assert(not hasattr(new_batch_sampler, saved_attr), f"reconstructed batch sampler must not carry {saved_attr}")

    class BatchSamplerDoppelganger:
        def __init__(self, sampler, batch_size, drop_last):
            self.sampler = sampler
            self.batch_size = batch_size
            self.drop_last = drop_last

        def __iter__(self):
            while True:
                yield [0, 1, 2, 3]

        def __len__(self):
            return 4

    doppelganger = BatchSamplerDoppelganger(sampler=Mock(), batch_size=2, drop_last=True)
    dataloader = DataLoader(range(100), batch_sampler=doppelganger)
    new_sampler = Mock()
    new_dataloader = _update_dataloader(dataloader, sampler=new_sampler)
    new_batch_sampler = new_dataloader.batch_sampler
    _assert(isinstance(new_batch_sampler, BatchSamplerDoppelganger), "doppelganger must reconstruct as same class")
    _assert(new_batch_sampler.sampler is new_sampler, "doppelganger sampler must be replaced")

    class UnsupportedBatchSampler:
        def __iter__(self):
            while True:
                yield [0, 1, 2, 3]

    dataloader = DataLoader(range(100), batch_sampler=UnsupportedBatchSampler())
    _assert_raises(
        TypeError,
        "can't inject a (distributed) sampler into your batch sampler",
        lambda: _update_dataloader(dataloader, sampler=Mock()),
    )

    class NoSamplerBatchSampler(BatchSampler):
        def __init__(self, extra_arg):
            self.extra_arg = extra_arg
            super().__init__(RandomSampler(range(10)), 10, False)

    with _replace_dunder_methods(BatchSampler):
        no_sampler_batch_sampler = NoSamplerBatchSampler("random_str")
    no_sampler_dataloader = DataLoader(range(10), batch_sampler=no_sampler_batch_sampler)
    _assert(no_sampler_dataloader.batch_sampler.__pl_saved_args == ("random_str",), "no-sampler saved args mismatch")
    _assert(no_sampler_dataloader.batch_sampler.__pl_saved_kwargs == {}, "no-sampler saved kwargs must be empty")
    _assert(no_sampler_dataloader.batch_sampler.__pl_saved_arg_names == ("extra_arg",), "no-sampler saved arg names mismatch")
    _assert(no_sampler_dataloader.batch_sampler.__pl_saved_default_kwargs == {}, "no-sampler default kwargs must be empty")
    _assert_raises(
        TypeError,
        "sampler into the batch sampler",
        lambda: _update_dataloader(no_sampler_dataloader, no_sampler_dataloader.sampler),
    )


def check_c31_pytorch_get_dataloader_init_args_and_kwargs_direct() -> None:
    """C31/R8/R9/R10/R11/E10/E11: direct pytorch extractor returns sampler-injected kwargs and handles modes.

    Guidance: Interface Description 2 and
    tests/tests_pytorch/trainer/connectors/test_data_connector.py:184-221.
    Perspective: direct public-return oracle for the declared pytorch extractor
    that is otherwise only exercised indirectly through ``_update_dataloader``.
    Source path/symbol:
    ``src/lightning/pytorch/utilities/data.py::_get_dataloader_init_args_and_kwargs``.
    """
    from lightning.pytorch.trainer.states import RunningStage
    from lightning.pytorch.utilities.data import _get_dataloader_init_args_and_kwargs
    from lightning.pytorch.utilities.exceptions import MisconfigurationException

    dataset = TensorDataset(torch.randn(8, 2))
    dataloader = DataLoader(dataset, batch_size=4, drop_last=True)
    sampler = SequentialSampler(dataset)

    args, kwargs = _get_dataloader_init_args_and_kwargs(dataloader, sampler, mode=RunningStage.PREDICTING)
    _assert(isinstance(args, tuple) and args == (), "map-style unwrapped extraction must return empty positional args")
    _assert(kwargs["sampler"] is sampler, "extracted kwargs must contain the injected sampler")
    _assert(kwargs["batch_size"] == dataloader.batch_size, "predict extraction must preserve batch_size")
    _assert(kwargs["drop_last"] is False, "predict extraction must force drop_last=False")

    _, fit_kwargs = _get_dataloader_init_args_and_kwargs(dataloader, sampler, mode=RunningStage.TRAINING)
    _assert(fit_kwargs["sampler"] is sampler, "training extraction must contain the injected sampler")
    _assert(fit_kwargs["shuffle"] is False, "training extraction must set shuffle=False")
    _assert(fit_kwargs["batch_sampler"] is None, "map-style training extraction must set batch_sampler=None")

    class RandomIterableDataset(IterableDataset):
        def __iter__(self):
            yield from range(100)

    iterable_loader = DataLoader(RandomIterableDataset(), batch_size=32)
    _, iterable_kwargs = _get_dataloader_init_args_and_kwargs(iterable_loader, iterable_loader.sampler)
    _assert(iterable_kwargs["sampler"] is None, "IterableDataset extraction must force sampler=None")
    _assert(iterable_kwargs["batch_sampler"] is None, "IterableDataset extraction must force batch_sampler=None")

    _assert_raises(
        ValueError,
        "needs to subclass `torch.utils.data.DataLoader",
        lambda: _get_dataloader_init_args_and_kwargs(object(), object()),
    )

    class TestDataLoader(DataLoader):
        def __init__(self, dataset):
            super().__init__(dataset)

    loader = TestDataLoader(dataset)
    _assert_raises(
        MisconfigurationException,
        "missing arguments are ['batch_sampler', 'batch_size', 'drop_last', 'sampler', 'shuffle']",
        lambda: _get_dataloader_init_args_and_kwargs(loader, sampler, mode=RunningStage.PREDICTING),
    )

def check_c32_fabric_update_dataloader_conflict_diagnostics() -> None:
    """C32/R6/R12/R21: fabric conflict diagnostics distinguish broken unwrapped subclasses from wrapped/good ones.

    Guidance: tests/tests_fabric/utilities/test_data.py::test_update_dataloader_typerror_custom_exception.
    Perspective: repository regression failure oracle for constructor-argument
    conflicts. Source path/symbol:
    ``src/lightning/fabric/utilities/data.py::_update_dataloader`` ->
    ``_get_dataloader_init_args_and_kwargs``.
    """
    from lightning.fabric.utilities.data import _replace_dunder_methods, _update_dataloader
    from lightning.fabric.utilities.exceptions import MisconfigurationException

    def assert_conflict(dataloader, arg_name):
        try:
            _update_dataloader(dataloader, dataloader.sampler)
        except MisconfigurationException as exc:
            text = str(exc)
            _assert("implementation has an error" in text, f"conflict diagnostic must mention implementation error, got {text!r}")
            _assert(f"`{arg_name}`" in text, f"conflict diagnostic must mention `{arg_name}`, got {text!r}")
        except BaseException as exc:
            raise AssertionError(f"expected MisconfigurationException, got {type(exc).__name__}: {exc}") from exc
        else:
            raise AssertionError("expected MisconfigurationException for conflicting unwrapped dataloader")

    class BadStandaloneGoodHookImpl(DataLoader):
        def __init__(self, foo, *args, **kwargs):
            self.foo = foo
            super().__init__(foo, *args, **kwargs)

    bad_standalone = BadStandaloneGoodHookImpl([1, 2, 3])
    assert_conflict(bad_standalone, "dataset")

    with _replace_dunder_methods(DataLoader, "dataset"):
        wrapped_bad = BadStandaloneGoodHookImpl([1, 2, 3])
    wrapped_new = _update_dataloader(wrapped_bad, wrapped_bad.sampler)
    _assert(isinstance(wrapped_new, BadStandaloneGoodHookImpl), "wrapped conflicting dataloader must reconstruct")

    class BadImpl(DataLoader):
        def __init__(self, randomize, *args, **kwargs):
            self.randomize = randomize
            super().__init__(*args, shuffle=randomize, **kwargs)

    bad_shuffle = BadImpl(False, [])
    assert_conflict(bad_shuffle, "shuffle")

    class GoodImpl(DataLoader):
        def __init__(self, randomize, *args, **kwargs):
            self.randomize = randomize or kwargs.pop("shuffle", False)
            super().__init__(*args, shuffle=randomize, **kwargs)

    good = GoodImpl(False, [])
    good_new = _update_dataloader(good, good.sampler)
    _assert(isinstance(good_new, GoodImpl), "non-conflicting custom dataloader must reconstruct")

CHECKS = [
    check_c3_constructor_argument_capture_cases,
    check_c4_explicit_dataset_private_storage,
    check_c5_post_init_attribute_recording,
    check_c6_dunder_scope_and_restoration,
    check_c7_reinstantiation_clears_saved_attrs_and_replays_changes,
    check_c8_replace_value_in_saved_args_parameterized,
    check_c9_iterable_dataset_sampler_suppression,
    check_c10_array_valued_attribute_default_comparison,
    check_c11_invalid_dataloader_type_rejection,
    check_c12_fit_missing_keyword_arguments,
    check_c13_predict_missing_keyword_arguments_include_batch_keys,
    check_c31_pytorch_get_dataloader_init_args_and_kwargs_direct,
    check_c32_fabric_update_dataloader_conflict_diagnostics,
    check_c14_variadic_dataloader_subclasses_reconstruct_successfully,
    check_c15_multiprocessing_context_preservation,
    check_c16_prediction_batch_sampler_wrapper,
    check_c17_shuffle_detection_through_samplers,
    check_c18_shuffle_detection_honors_saved_constructor_args,
    check_c19_batch_size_extraction_from_tensors_and_containers,
    check_c20_ambiguous_batch_warning_and_tensor_free_failure,
    check_c21_has_len_all_ranks_false_without_len,
    check_c22_has_len_all_ranks_true_for_sized_iterable_dataloader,
    check_c23_distributed_length_reduction_and_zero_length_runtime_error,
    check_c29_custom_batch_sampler_compatibility,
]


if __name__ == "__main__":
    failures = []
    for check in CHECKS:
        try:
            check()
        except Exception as exc:  # noqa: BLE001 - executable spec must report and continue
            failures.append((check.__name__, exc))
            print(f"FAIL: {check.__name__}: {exc}")
        else:
            print(f"PASS: {check.__name__}")
    if failures:
        raise SystemExit(1)
    print("PASS: all behavior checks")
