# Semantic IR

IR = <R, G, C> for the DataLoader management and optimization utilities task.

- Task document: primary oracle.
- Repository: `/testbed`.
- Declared interfaces: `src/lightning/fabric/utilities/data.py::_replace_dunder_methods`; `src/lightning/pytorch/utilities/data.py::{_get_dataloader_init_args_and_kwargs,_is_dataloader_shuffled,_update_dataloader,extract_batch_size,has_len_all_ranks}`.
- Static analysis: `/agent-logs/codespec2/Lightning-AI__pytorch-lightning.126fa6f1.test_data.c8b292af.lv1_20260813_023720/artifacts/static_analysis.md`.
- Static issues: `/agent-logs/codespec2/Lightning-AI__pytorch-lightning.126fa6f1.test_data.c8b292af.lv1_20260813_023720/artifacts/static_issues.md`.

---

## L1. Requirement Obligations

### R1: `_replace_dunder_methods` context-manager interface
- **Type**: Interface / Lifecycle
- **Statement**: `src/lightning/fabric/utilities/data.py` must expose a `@contextmanager`-decorated function `_replace_dunder_methods(base_cls: type, store_explicit_arg: Optional[str] = None) -> Generator[None, None, None]`. The context manager patches dunder methods for the lifetime of a `with` block and restores them on exit.
- **Task Evidence**: Interface Description 1.
- **Acceptance**: The symbol imports from `lightning.fabric.utilities.data`; it can be used as `with _replace_dunder_methods(DataLoader, "dataset"):`; entering and exiting performs patch and restore.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py` imports `contextmanager` at line 20, imports `get_all_subclasses` at line 24, and contains a blank implementation region between lines 252 and 414. Tests import the symbol at `tests/tests_fabric/utilities/test_data.py:18`.
- **Uncertainty**: None.

### R2: Constructor-argument capture by `_replace_dunder_methods`
- **Type**: State
- **Statement**: For an instance created while the context is active, the patched `__init__` must store on the instance: `__pl_saved_args` (original positional args), `__pl_saved_kwargs` (original keyword args), `__pl_saved_arg_names` (names of parameters corresponding to positional args), and `__pl_saved_default_kwargs` (default parameter values from the constructor signature).
- **Task Evidence**: Interface Description 1, "The wrapped methods store..." paragraph.
- **Acceptance**: `tests/tests_fabric/utilities/test_data.py::test_replace_dunder_methods_dataloader` asserts these attributes for multiple DataLoader subclasses; `test_replace_dunder_methods_extra_kwargs` asserts default-kwarg capture.
- **Repository Evidence**: `tests/tests_fabric/utilities/test_data.py:208-258`.
- **Uncertainty**: The exact algorithm mapping `*args`/`**kwargs` and inherited defaults to `__pl_saved_arg_names`/`__pl_saved_default_kwargs` is not present in the source because the implementation is blanked; repository tests provide the expected values.

### R3: Explicit constructor-argument private storage
- **Type**: State
- **Statement**: When `store_explicit_arg` is provided, `_replace_dunder_methods` must store the post-construction value of that constructor argument as a private attribute `__{store_explicit_arg}` on each wrapped instance.
- **Task Evidence**: Interface Description 1, `store_explicit_arg` parameter and note.
- **Acceptance**: In DataLoader wrapping, `dataloader.__dataset` equals the actual dataset used by the constructed DataLoader, even when a subclass modifies the dataset in `__init__`.
- **Repository Evidence**: `tests/tests_fabric/utilities/test_data.py:212-225` (includes `ChangingDataLoader`, `WeirdDataLoader1`, `WeirdDataLoader2`).
- **Uncertainty**: Timing is inferred as post-`__init__` from tests; the task wording says "explicitly stored as a private attribute on instances."

### R4: Post-init attribute-change recording
- **Type**: State / Side-effect
- **Statement**: While the context is active, patched `__setattr__` and `__delattr__` must record attribute modifications made after initialization as `((name, value), _WrapAttrTag.SET)` or `((name,), _WrapAttrTag.DEL)` in `instance.__pl_attrs_record`. Changes made during `__init__` and failed deletions must not be recorded.
- **Task Evidence**: Interface Description 1, `__pl_attrs_record` bullet and "track whether they are being called during object initialization."
- **Acceptance**: `test_replace_dunder_methods_attrs` expects exactly four records after three sets and one successful delete plus one suppressed failed delete.
- **Repository Evidence**: `tests/tests_fabric/utilities/test_data.py:261-297`; `_WrapAttrTag` defined at `src/lightning/fabric/utilities/data.py:34-41`.
- **Uncertainty**: The exact duplicate-suppression mechanism for inherited `__setattr__` chains is not visible; the observable record list is proven by the test.

### R5: Dunder patching scope and restoration
- **Type**: Lifecycle
- **Statement**: The context must patch `__init__`, `__setattr__`, and `__delattr__` only on classes that actually define them in their own `__dict__`, except that `__setattr__` and `__delattr__` are always patched on `base_cls` to ensure at least one wrapped implementation exists in the inheritance chain. On exit, every patched class must be restored to its original method object.
- **Task Evidence**: Interface Description 1, "Important Notes."
- **Acceptance**: `test_replace_dunder_methods_multiple_loaders_without_init` and `test_replace_dunder_methods_restore_methods` pass.
- **Repository Evidence**: `tests/tests_fabric/utilities/test_data.py:53-81` and `306-341`.
- **Uncertainty**: Exact internal helper names (`_patch_dunder_method`, `_restore_dunder_method`) are inferred and not separately specified by the task.

### R6: `_reinstantiate_wrapped_cls` reconstruction and replay
- **Type**: Behavior
- **Statement**: A helper must reconstruct an object from `type(original)(*args, **kwargs)` outside the wrapping context and then replay `__pl_attrs_record` on the new instance. The returned object must be the same class and must not carry `__pl_saved_args`, `__pl_saved_kwargs`, `__pl_saved_arg_names`, `__pl_saved_default_kwargs`, or `__dataset`.
- **Task Evidence**: Task statement "Preservation and restoration of custom DataLoader subclass configurations"; static issue naming `_reinstantiate_wrapped_cls`.
- **Acceptance**: `_update_dataloader` tests assert same-class reconstruction, absence of saved attrs, and replayed attribute sets/deletes.
- **Repository Evidence**: `tests/tests_fabric/utilities/test_data.py:227-234`, `299-303`, `454-463`; call sites `src/lightning/fabric/utilities/data.py:77,200`.
- **Uncertainty**: Exact replay order and handling of private `__dataset` are inferred.

### R7: `_replace_value_in_saved_args` replacement contract
- **Type**: Behavior
- **Statement**: A helper `_replace_value_in_saved_args(replace_key, replace_value, args, kwargs, default_kwargs, arg_names)` must replace a saved constructor argument in `kwargs`, in positional `args` by matching `arg_names`, or in `default_kwargs`; it returns `(success: bool, args: tuple, kwargs: dict)` and returns `False` unchanged when the key is absent.
- **Task Evidence**: Static issue naming `_replace_value_in_saved_args`; task statement "Runtime modification of DataLoader parameters without losing original settings."
- **Acceptance**: Parameterized expectations in `tests/tests_fabric/utilities/test_data.py:344-382`.
- **Repository Evidence**: `tests/tests_fabric/utilities/test_data.py:344-382`; call site `src/lightning/fabric/utilities/data.py:190-192`.
- **Uncertainty**: Behavior when the key appears in more than one location is not tested.

### R8: Pytorch `_get_dataloader_init_args_and_kwargs` interface
- **Type**: Interface / Dataflow
- **Statement**: `src/lightning/pytorch/utilities/data.py` must expose `_get_dataloader_init_args_and_kwargs(dataloader: DataLoader, sampler: Union[Sampler, Iterable], mode: Optional[RunningStage] = None) -> tuple[tuple[Any], dict[str, Any]]`.
- **Task Evidence**: Interface Description 2, first function.
- **Acceptance**: The symbol imports from `lightning.pytorch.utilities.data`; it returns a two-tuple `(args, kwargs)`.
- **Repository Evidence**: The current file has an import gap at `src/lightning/pytorch/utilities/data.py:28-31`; fabric already implements an analogous 2-argument function at `src/lightning/fabric/utilities/data.py:80`.
- **Uncertainty**: Whether the implementation is a local wrapper or an import/re-export of the fabric function; hidden tests require the mode-capable interface.

### R9: DataLoader-subclass validation
- **Type**: Failure
- **Statement**: Both `_get_dataloader_init_args_and_kwargs` and `_update_dataloader` must raise `ValueError` when the input is not a subclass of `torch.utils.data.DataLoader`.
- **Task Evidence**: Interface Description 2, `_get_dataloader_init_args_and_kwargs` Raises section and `_update_dataloader` Raises section.
- **Acceptance**: `_update_dataloader(object(), object(), mode="fit")` raises `ValueError` matching `"needs to subclass `torch.utils.data.DataLoader"`.
- **Repository Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:184-186`; fabric analogue at `src/lightning/fabric/utilities/data.py:84-85`.
- **Uncertainty**: None.

### R10: Wrapped vs unwrapped dataloader extraction
- **Type**: Dataflow
- **Statement**: For wrapped DataLoaders, extraction must use `__pl_saved_args`, `__pl_saved_kwargs`, `__pl_saved_arg_names`, and `__dataset`. For unwrapped DataLoaders, it must gather public instance attributes, add `multiprocessing_context`, keep only attributes whose current value differs from the constructor default, and always include `dataset`.
- **Task Evidence**: Interface Description 2 notes; task statement "Preservation and restoration of custom DataLoader subclass configurations."
- **Acceptance**: Fabric extraction tests for array attributes and iterable datasets pass; `test_update_dataloader_with_multiprocessing_context` verifies context preservation.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:87-127`; `tests/tests_fabric/utilities/test_data.py:538-565`; `tests/tests_pytorch/trainer/connectors/test_data_connector.py:252-258`.
- **Uncertainty**: Pytorch wrapper may share the fabric implementation; prediction-mode additions must be layered without breaking these paths.

### R11: IterableDataset sampler suppression
- **Type**: Dataflow
- **Statement**: When the extracted dataset is an `IterableDataset`, reconstruction kwargs must set `batch_sampler=None` and `sampler=None`; otherwise sampler-related kwargs are resolved through `_dataloader_init_kwargs_resolve_sampler`.
- **Task Evidence**: Interface Description 2 notes; task statement "Support for both iterable and map-style datasets."
- **Acceptance**: `test_dataloader_kwargs_replacement_with_iterable_dataset` asserts `sampler is None`, `batch_sampler is None`, and other DataLoader kwargs are preserved.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:129-134`; `tests/tests_fabric/utilities/test_data.py:538-547`.
- **Uncertainty**: None.

### R12: Constructor-signature validation failures
- **Type**: Failure
- **Statement**: Extraction must raise `MisconfigurationException` when required constructor args cannot be satisfied from instance attributes, and `MisconfigurationException` when a non-variadic DataLoader subclass does not expose necessary sampler parameters in its `__init__` signature. Error text must include a sorted list of missing attributes/arguments.
- **Task Evidence**: Interface Description 2 Raises section; task statement "Provide robust error handling for misconfigured or incompatible DataLoader setups."
- **Acceptance**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:189-249` verifies sorted missing-argument/attribute messages for several subclasses.
- **Repository Evidence**: Fabric analogue raises `MisconfigurationException` at `src/lightning/fabric/utilities/data.py:145-155` and `TypeError` at `157-168`; pytorch tests expect `MisconfigurationException` for both.
- **Uncertainty**: The exact translation from fabric `TypeError` to pytorch `MisconfigurationException` is not present in source.

### R13: Prediction-mode DataLoader reconstruction
- **Type**: Dataflow / Side-effect
- **Statement**: When `mode == RunningStage.PREDICTING`, reconstruction must include `batch_size` and `drop_last` in the validation surface (so missing-keyword errors include them), enforce `drop_last=False`, and produce a dataloader whose `batch_sampler` is wrapped by `_IndexBatchSamplerWrapper`.
- **Task Evidence**: Interface Description 2, `_update_dataloader` notes; task statement "epoch-aware sampling."
- **Acceptance**: Predict-mode missing-keyword error includes `batch_size` and `drop_last`; prediction-loop tests assert `trainer.predict_dataloaders.batch_sampler` is `_IndexBatchSamplerWrapper`.
- **Repository Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:201-203`; `tests/tests_pytorch/loops/test_prediction_loop.py:83-88`; `tests/tests_pytorch/trainer/test_trainer.py:1310-1311`; `_IndexBatchSamplerWrapper` imported in `src/lightning/pytorch/utilities/data.py:33`.
- **Uncertainty**: Whether `_get_dataloader_init_args_and_kwargs` or `_update_dataloader` adds the prediction keys/wrapper; the observable error and final batch-sampler type are fixed.

### R14: `_update_dataloader` reconstruction with preservation
- **Type**: Behavior
- **Statement**: `_update_dataloader(dataloader, sampler, mode=None)` must create a new DataLoader of the same subclass with the new sampler while preserving original configuration, including `multiprocessing_context` and custom attributes; variadic `*args`/`**kwargs` subclasses must not require all DataLoader parameters in their own signature.
- **Task Evidence**: Interface Description 2, `_update_dataloader`.
- **Acceptance**: `test_update_dataloader_with_multiprocessing_context`, `test_dataloaders_with_missing_keyword_arguments` success cases, and `test_dataloader_reinit_for_subclass`.
- **Repository Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:205-221,252-315`.
- **Uncertainty**: None.

### R15: `_is_dataloader_shuffled` shuffle detection
- **Type**: Behavior
- **Statement**: `_is_dataloader_shuffled(dataloader: object) -> bool` must return `False` for IterableDatasets, missing samplers, and `SequentialSampler`; return `True` for `RandomSampler`; and inspect Lightning saved arguments before falling back to regular/batch sampler inspection.
- **Task Evidence**: Interface Description 2, `_is_dataloader_shuffled`.
- **Acceptance**: Eval-dataloader warning tests pass: `DataLoader(shuffle=True)` warns, `DataLoader(sampler=list(...))` does not, and `CombinedLoader` variants behave correctly.
- **Repository Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:420-449`; call site `src/lightning/pytorch/trainer/connectors/data_connector.py:482`.
- **Uncertainty**: Exact precedence and behavior for a custom batch sampler without an internal `sampler` are inferred from the docstring; repository tests only cover common paths.

### R16: `extract_batch_size` recursive tensor-size inference
- **Type**: Dataflow
- **Statement**: `extract_batch_size(batch: BType) -> int` must recursively traverse tensors, mappings, iterables, and dataclass fields; scalar tensors yield `1`; strings are atomic; the first encountered tensor's first dimension is used as batch size.
- **Task Evidence**: Interface Description 2, `extract_batch_size`.
- **Acceptance**: Direct observations on tensor, mapping, iterable, dataclass, scalar tensor, and string cases.
- **Repository Evidence**: `_extract_batch_size` generator at `src/lightning/pytorch/utilities/data.py:43-59` already implements traversal; `BType` at line 38.
- **Uncertainty**: Exact handling of nested non-tensor iterables with no tensor is determined by the wrapper's failure path.

### R17: `extract_batch_size` ambiguity and failure semantics
- **Type**: Failure / Side-effect
- **Statement**: When multiple tensors with different batch sizes are found, the function must emit a warning and use the first encountered size; when no tensor is found, it must raise `MisconfigurationException`.
- **Task Evidence**: Interface Description 2, Notes and Raises.
- **Acceptance**: Ambiguous batch warns once via the module warning cache; tensor-free batch raises `MisconfigurationException`.
- **Repository Evidence**: `MisconfigurationException` and `WarningCache`/`warning_cache` are imported in `src/lightning/pytorch/utilities/data.py:35,40`.
- **Uncertainty**: Exact warning text/category is not stated in the task; only the side-effect class and condition are fixed.

### R18: `has_len_all_ranks` local length gate
- **Type**: Interface / Behavior
- **Statement**: `has_len_all_ranks(dataloader, strategy, allow_zero_length_dataloader_with_multiple_devices=False) -> TypeGuard[Sized]` must return `False` when `__len__` is absent on the local object, without performing distributed validation; otherwise it returns `True` after validation.
- **Task Evidence**: Interface Description 2, `has_len_all_ranks`.
- **Acceptance**: `tests/tests_pytorch/trainer/test_dataloaders.py:720` asserts `True` for an IterableDataset with `__len__`; line `734` asserts `False` for an IterableDataset without `__len__`.
- **Repository Evidence**: `tests/tests_pytorch/trainer/test_dataloaders.py:704-739`; fabric `sized_len`/`has_len` at `src/lightning/fabric/utilities/data.py:48-72`.
- **Uncertainty**: Whether the function calls `sized_len` or `has_len` internally; either path must preserve the observed return values.

### R19: `has_len_all_ranks` distributed validation
- **Type**: Distributed / State
- **Statement**: For objects with local length, the function must sum lengths across ranks using `strategy.reduce(..., reduce_op="sum")`. It must warn when total length is zero and when the distribution is uneven; if local length is zero while total length is positive and `allow_zero_length_dataloader_with_multiple_devices` is `False`, it must raise `RuntimeError`.
- **Task Evidence**: Interface Description 2, `has_len_all_ranks` Raises and Notes.
- **Acceptance**: A mocked strategy whose `reduce` returns a positive total causes `RuntimeError` when local length is zero and the allow flag is `False`; with the allow flag `True`, no error is raised.
- **Repository Evidence**: Strategy reduce interface at `src/lightning/pytorch/strategies/strategy.py:295-302`; single-device strategy returns the tensor unchanged at `src/lightning/pytorch/strategies/single_device.py:51-64`.
- **Uncertainty**: Exact warning text and the exact unevenness predicate are not given by the task; warning strings must be inferred by implementation, not invented here.

### R20: Caller import boundaries and runtime binding
- **Type**: Compatibility / Dependency
- **Statement**: The implementation must add/restore module-level bindings so every task-required call site resolves at runtime: `_replace_dunder_methods` in `lightning.fabric.fabric`; `_replace_dunder_methods`, `_update_dataloader`, and `_is_dataloader_shuffled` in `data_connector`; `has_len_all_ranks` in the three loops; and `extract_batch_size` in `result.py`.
- **Task Evidence**: Static issues file.
- **Acceptance**: Importing the caller modules succeeds and executing public entry paths reaches the target definitions.
- **Repository Evidence**: Static issue call sites listed in `static_issues.md`; call-site line numbers verified below in Static Issue Closure.
- **Uncertainty**: None.

### R21: Custom batch sampler compatibility and failure behavior
- **Type**: Compatibility / Failure
- **Statement**: Reconstruction must support PyTorch `BatchSampler` subclasses whose constructor exposes `sampler` and whose init args were captured, support non-PyTorch "doppelganger" batch samplers exposing `batch_size`/`drop_last`, and raise `TypeError` for unsupported custom batch samplers.
- **Task Evidence**: Task statement "Handle complex inheritance hierarchies and custom DataLoader implementations."
- **Acceptance**: `tests/tests_fabric/utilities/test_data.py:422-535` pass.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:173-243` contains the resolver; `_replace_value_in_saved_args` and `_reinstantiate_wrapped_cls` are the missing helpers it depends on.
- **Uncertainty**: Pytorch `_update_dataloader` may delegate this entirely to the fabric resolver.

### R22: Existing optimization utilities remain functional
- **Type**: Compatibility
- **Statement**: Existing worker-count and epoch-aware sampler utilities `suggested_max_num_workers` and `_set_sampler_epoch` must remain importable and preserve their current behavior while the new data utilities are added.
- **Task Evidence**: Task statement "Automatic performance optimization (worker count suggestions, epoch-aware sampling)."
- **Acceptance**: Existing tests `test_set_sampler_epoch` and `test_suggested_max_num_workers` continue to pass.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:415-459`; `tests/tests_fabric/utilities/test_data.py:568-620`.
- **Uncertainty**: None.

---

## L2. Functional Design Graph

### Entities

### N1: `_replace_dunder_methods` (task entry)
- **Kind**: Function / Context manager
- **Repository Evidence**: Interface Description 1; blank region in `src/lightning/fabric/utilities/data.py` between lines 252-414; imports `contextmanager`, `get_all_subclasses`, `functools`, `OrderedDict` at lines 15-24.

### N2: `_reinstantiate_wrapped_cls` (helper)
- **Kind**: Function
- **Repository Evidence**: Static issue names the symbol; call sites `src/lightning/fabric/utilities/data.py:77,200`.

### N3: `_replace_value_in_saved_args` (helper)
- **Kind**: Function
- **Repository Evidence**: Static issue names the symbol; call site `src/lightning/fabric/utilities/data.py:190`; direct test import at `tests/tests_fabric/utilities/test_data.py:19`.

### N4: `_WrapAttrTag`
- **Kind**: Class / enum-callable helper
- **Repository Evidence**: Defined at `src/lightning/fabric/utilities/data.py:34-41`; used by `__pl_attrs_record` expectations in tests.

### N5: fabric `_get_dataloader_init_args_and_kwargs`
- **Kind**: Function (existing)
- **Repository Evidence**: Defined at `src/lightning/fabric/utilities/data.py:80-170`.

### N6: `_dataloader_init_kwargs_resolve_sampler`
- **Kind**: Function (existing)
- **Repository Evidence**: Defined at `src/lightning/fabric/utilities/data.py:173-243`.

### N7: fabric `_update_dataloader`
- **Kind**: Function (existing)
- **Repository Evidence**: Defined at `src/lightning/fabric/utilities/data.py:75-77`.

### N8: pytorch `_get_dataloader_init_args_and_kwargs` (task entry)
- **Kind**: Function / Import boundary
- **Repository Evidence**: Interface Description 2; import gap at `src/lightning/pytorch/utilities/data.py:28-31`; fabric analogue N5.

### N9: pytorch `_update_dataloader` (task entry)
- **Kind**: Function
- **Repository Evidence**: Interface Description 2; static issue call sites in `data_connector.py:192,266`; existing pytorch import gap.

### N10: `_is_dataloader_shuffled` (task entry)
- **Kind**: Function
- **Repository Evidence**: Interface Description 2; static issue call site `data_connector.py:482`.

### N11: `_extract_batch_size` (existing generator)
- **Kind**: Function / Generator
- **Repository Evidence**: Defined at `src/lightning/pytorch/utilities/data.py:43-59`.

### N12: `extract_batch_size` (task entry)
- **Kind**: Function
- **Repository Evidence**: Interface Description 2; static issue call site `result.py:349`.

### N13: `has_len_all_ranks` (task entry)
- **Kind**: Function
- **Repository Evidence**: Interface Description 2; static issue call sites in `evaluation_loop.py:203`, `fit_loop.py:266,279`, `prediction_loop.py:162`.

### N14: fabric `sized_len` / `has_len`
- **Kind**: Functions (existing)
- **Repository Evidence**: Defined at `src/lightning/fabric/utilities/data.py:48-72`.

### N15: `_IndexBatchSamplerWrapper`
- **Kind**: Class (existing)
- **Repository Evidence**: Imported in `src/lightning/pytorch/utilities/data.py:33`; defined at `src/lightning/pytorch/overrides/distributed.py:235-267`.

### N16: `torch.utils.data.DataLoader`
- **Kind**: External class
- **Repository Evidence**: Imported by both target modules and callers; patch target in `Fabric._wrap_with_setup` and `_request_dataloader`.

### N17: `torch.utils.data.BatchSampler`
- **Kind**: External class
- **Repository Evidence**: Imported by target modules and callers; patch target in `Fabric._wrap_with_setup` and `_request_dataloader`.

### N18: Fabric.launch public caller boundary
- **Kind**: Caller boundary
- **Repository Evidence**: `Fabric.launch` at `src/lightning/fabric/fabric.py:931`; `_wrap_and_launch` at `1067`; `_wrap_with_setup` at `1074-1077`.

### N19: Fabric.setup_dataloaders public caller boundary
- **Kind**: Caller boundary
- **Repository Evidence**: `Fabric.setup_dataloaders` at `src/lightning/fabric/fabric.py:412`; `_setup_dataloader` at `449-480`; call to fabric `_update_dataloader` at `471`.

### N20: Trainer loop setup caller boundary
- **Kind**: Caller boundary
- **Repository Evidence**: `Trainer._run_stage` at `src/lightning/pytorch/trainer/trainer.py:1108-1122`; loop `run`/`setup_data` at `evaluation_loop.py:120,155`, `fit_loop.py:208,226`, `prediction_loop.py:104,133`.

### N21: Data connector call helpers
- **Kind**: Caller boundary / Functions
- **Repository Evidence**: `_prepare_dataloader` at `src/lightning/pytorch/trainer/connectors/data_connector.py:177-192`; `_request_dataloader` at `323-335`; `_process_dataloader` at `478-494`; `_resolve_overfit_batches` at `247-269`.

### N22: Result logging caller boundary
- **Kind**: Caller boundary
- **Repository Evidence**: `LightningModule.log` at `src/lightning/pytorch/core/module.py:386-548`; `_ResultCollection.log` at `result.py:355-415`; `_ResultCollection._extract_batch_size` at `result.py:339-352`.

### Edges

### E1: N18 -> N1
- **Kind**: CALL
- **Condition**: `Fabric.launch` is invoked.
- **Transfer**: `Fabric.launch` -> `_wrap_and_launch` -> `_wrap_with_setup` -> two `_replace_dunder_methods` contexts, one for `DataLoader` with `"dataset"` and one for `BatchSampler`.
- **Evidence**: `src/lightning/fabric/fabric.py:931,1067-1077`; test `tests/tests_fabric/test_fabric.py:354-365`.
- **Obligations**: R1, R5, R20.

### E2: N1 -> N16/N17 and subclasses
- **Kind**: CONTROL / STATE
- **Condition**: Context entry.
- **Transfer**: `_replace_dunder_methods` walks `base_cls` and all subclasses, patches dunder methods, and restores them on exit.
- **Evidence**: Interface Description 1; imports `get_all_subclasses` at `src/lightning/fabric/utilities/data.py:24`; tests `tests/tests_fabric/utilities/test_data.py:53-81,306-341`.
- **Obligations**: R1, R2, R3, R4, R5.

### E3: N1 -> N4
- **Kind**: DATA / CALL
- **Condition**: A post-init `__setattr__` or `__delattr__` occurs while wrapped.
- **Transfer**: Wrapped methods append `(args, _WrapAttrTag.SET)` or `(args, _WrapAttrTag.DEL)` to `__pl_attrs_record`.
- **Evidence**: `_WrapAttrTag` at `src/lightning/fabric/utilities/data.py:34-41`; test expectations at `tests/tests_fabric/utilities/test_data.py:292-297`.
- **Obligations**: R4.

### E4: N2 -> N4
- **Kind**: CALL / STATE
- **Condition**: `_reinstantiate_wrapped_cls` replays `__pl_attrs_record`.
- **Transfer**: For each `(args, tag)` record, the tag is called on the new instance with `*args`, applying `setattr` or `delattr`.
- **Evidence**: `_WrapAttrTag.__call__` at `src/lightning/fabric/utilities/data.py:38-41`; reconstruction tests at `tests/tests_fabric/utilities/test_data.py:299-303`.
- **Obligations**: R6.

### E5: N7 -> N5
- **Kind**: CALL
- **Condition**: fabric `_update_dataloader` is called.
- **Transfer**: `_update_dataloader` calls `_get_dataloader_init_args_and_kwargs(dataloader, sampler)` and then `_reinstantiate_wrapped_cls`.
- **Evidence**: `src/lightning/fabric/utilities/data.py:75-77`.
- **Obligations**: R6, R10, R11, R12, R21.

### E6: N5 -> N6
- **Kind**: CALL / DATA
- **Condition**: The extracted dataset is map-style.
- **Transfer**: `_get_dataloader_init_args_and_kwargs` updates `dl_kwargs` with the return value of `_dataloader_init_kwargs_resolve_sampler`.
- **Evidence**: `src/lightning/fabric/utilities/data.py:129-134`.
- **Obligations**: R11, R21.

### E7: N6 -> N3
- **Kind**: CALL / DATA
- **Condition**: The dataloader has a non-`BatchSampler` custom batch sampler and `batch_sampler.__pl_saved_args` exists.
- **Transfer**: `_replace_value_in_saved_args("sampler", sampler, args, kwargs, default_kwargs, arg_names)` replaces the sampler in saved batch-sampler init args.
- **Evidence**: `src/lightning/fabric/utilities/data.py:183-200`.
- **Obligations**: R7, R21.

### E8: N6 -> N2
- **Kind**: CALL / DATA
- **Condition**: A wrapped custom batch sampler is reconstructed with modified sampler args.
- **Transfer**: `_reinstantiate_wrapped_cls(batch_sampler, *args, **kwargs)` returns the new batch sampler.
- **Evidence**: `src/lightning/fabric/utilities/data.py:200`.
- **Obligations**: R6, R21.

### E9: N19 -> N7
- **Kind**: CALL
- **Condition**: `Fabric.setup_dataloaders` determines that distributed sampler injection is required.
- **Transfer**: `_setup_dataloader` passes the resolved sampler to fabric `_update_dataloader`.
- **Evidence**: `src/lightning/fabric/fabric.py:467-471`.
- **Obligations**: R6, R7, R10, R11, R12, R21.

### E10: N8 -> N5
- **Kind**: CALL / DATA
- **Condition**: Pytorch extraction delegates to or reuses the fabric extraction logic, then adds prediction-mode keys when `mode == RunningStage.PREDICTING`.
- **Transfer**: Returns `(dl_args, dl_kwargs)` with sampler-related kwargs and, for prediction, `batch_size`/`drop_last`.
- **Evidence**: Interface Description 2; fabric implementation at `src/lightning/fabric/utilities/data.py:80-170`; predict missing-keyword expectations at `tests/tests_pytorch/trainer/connectors/test_data_connector.py:201-203`.
- **Obligations**: R8, R9, R10, R11, R12, R13.

### E11: N9 -> N8
- **Kind**: CALL
- **Condition**: Pytorch `_update_dataloader` is called.
- **Transfer**: `_update_dataloader` obtains `(args, kwargs)` from N8, then reconstructs the dataloader with `_reinstantiate_wrapped_cls`.
- **Evidence**: Interface Description 2; fabric analogue at `src/lightning/fabric/utilities/data.py:75-77`.
- **Obligations**: R8, R12, R13, R14.

### E12: N9 -> N2
- **Kind**: CALL
- **Condition**: Reconstruction of the dataloader.
- **Transfer**: Passes `*dl_args, **dl_kwargs` to `_reinstantiate_wrapped_cls(dataloader, ...)`.
- **Evidence**: Interface Description 2; static issue symbol N2; fabric analogue `src/lightning/fabric/utilities/data.py:77`.
- **Obligations**: R6, R14.

### E13: N9 -> N15
- **Kind**: CALL / DATA
- **Condition**: `mode == RunningStage.PREDICTING`.
- **Transfer**: The reconstructed dataloader's `batch_sampler` is wrapped by `_IndexBatchSamplerWrapper` so prediction can record batch indices; `drop_last` is forced `False`.
- **Evidence**: Interface Description 2 notes; `_IndexBatchSamplerWrapper` import at `src/lightning/pytorch/utilities/data.py:33`; prediction-loop assertions at `tests/tests_pytorch/loops/test_prediction_loop.py:83-88`.
- **Obligations**: R13.

### E14: N20 -> N21
- **Kind**: CALL
- **Condition**: `Trainer.fit`, `Trainer.validate`, `Trainer.test`, or `Trainer.predict` runs loop setup.
- **Transfer**: `Trainer._run_stage` dispatches to `fit_loop.run`, `_evaluation_loop.run`, or `predict_loop.run`; each loop's `run`/`setup_data` calls `_request_dataloader`, `_process_dataloader`, and `_prepare_dataloader`/`_resolve_overfit_batches`.
- **Evidence**: `src/lightning/pytorch/trainer/trainer.py:1108-1122`; loop files as cited in N20; `_process_dataloader` calls `_prepare_dataloader` at `data_connector.py:494`.
- **Obligations**: R13, R15, R18, R19, R20.

### E15: N21 -> N9
- **Kind**: CALL
- **Condition**: `_prepare_dataloader` requires distributed-sampler injection or prediction mode; or `_resolve_overfit_batches` replaces samplers with `SequentialSampler`.
- **Transfer**: Calls `_update_dataloader(dataloader, sampler, mode=mode)`.
- **Evidence**: `src/lightning/pytorch/trainer/connectors/data_connector.py:192,266`.
- **Obligations**: R9, R12, R13, R14, R20.

### E16: N21 -> N1
- **Kind**: CALL
- **Condition**: `_request_dataloader` invokes a user `*_dataloader` hook.
- **Transfer**: Enters `_replace_dunder_methods(DataLoader, "dataset")` and `_replace_dunder_methods(BatchSampler)` so constructor args and attr changes are captured.
- **Evidence**: `src/lightning/pytorch/trainer/connectors/data_connector.py:330-335`.
- **Obligations**: R1, R5, R20.

### E17: N21 -> N10
- **Kind**: CALL
- **Condition**: `_process_dataloader` handles a non-training stage.
- **Transfer**: Calls `_is_dataloader_shuffled(dataloader)` and warns if `True`.
- **Evidence**: `src/lightning/pytorch/trainer/connectors/data_connector.py:481-489`.
- **Obligations**: R15, R20.

### E18: N20 -> N13
- **Kind**: CALL
- **Condition**: Loop setup computes number of batches.
- **Transfer**: Calls `has_len_all_ranks(dl_or_combined_loader, trainer.strategy, allow_zero_length)`; uses `len(dl)` only when the call returns `True`.
- **Evidence**: `evaluation_loop.py:203`; `fit_loop.py:266,279`; `prediction_loop.py:162`.
- **Obligations**: R18, R19, R20.

### E19: N13 -> N14
- **Kind**: CALL / DATA
- **Condition**: Local length is checked.
- **Transfer**: Uses `sized_len`/`has_len` to obtain local length or to determine `__len__` presence; `False` when no length is available.
- **Evidence**: Fabric `sized_len`/`has_len` at `src/lightning/fabric/utilities/data.py:48-72`; pytorch data imports `sized_len` at line 26.
- **Obligations**: R18, R19.

### E20: N13 -> strategy.reduce
- **Kind**: CALL / DATA
- **Condition**: Local length is not `None`.
- **Transfer**: Reduces local length tensor with `reduce_op="sum"` to compute total length across ranks.
- **Evidence**: Strategy reduce interface at `src/lightning/pytorch/strategies/strategy.py:295-302`; Interface Description 2 notes.
- **Obligations**: R19.

### E21: N12 -> N11
- **Kind**: CALL / DATA
- **Condition**: `extract_batch_size` is called.
- **Transfer**: Iterates `_extract_batch_size(batch)` and selects the first non-`None` yielded size.
- **Evidence**: `_extract_batch_size` at `src/lightning/pytorch/utilities/data.py:43-59`; Interface Description 2.
- **Obligations**: R16, R17.

### E22: N22 -> N12
- **Kind**: CALL
- **Condition**: `LightningModule.log` logs an epoch-mean tensor metric without explicit `batch_size`.
- **Transfer**: `LightningModule.log` -> `_ResultCollection.log` -> `_ResultCollection._extract_batch_size` -> `extract_batch_size(self.batch)`.
- **Evidence**: `src/lightning/pytorch/core/module.py:386-548`; `result.py:339-352,414`.
- **Obligations**: R16, R17, R20.

### Static Issue Closure

Each static-issue symbol is ON-PATH; the trace reaches a task-required or existing public entry and must be compiled to a runtime L3 contract, not disposed out-of-scope.

1. **`_replace_dunder_methods` in `src/lightning/fabric/fabric.py`**
   - Call site/unit: line 1076 in `Fabric._wrap_with_setup`.
   - Upward trace: `Fabric.launch` (`fabric.py:931`) -> `_wrap_and_launch` (`1067-1072`) -> `_wrap_with_setup` (`1074-1077`).
   - Public entry: `Fabric.launch`.
   - Closed chain: `Fabric.launch -> _wrap_and_launch -> _wrap_with_setup -> _replace_dunder_methods`.
   - Graph: N18 -> N1 (E1); contract C2.

2. **`_reinstantiate_wrapped_cls` in `src/lightning/fabric/utilities/data.py`**
   - Call sites/units: line 77 in `_update_dataloader`; line 200 in `_dataloader_init_kwargs_resolve_sampler`.
   - Upward trace: `Fabric.setup_dataloaders` (`fabric.py:412`) -> `_setup_dataloader` (`449-480`) -> fabric `_update_dataloader` (`471`) -> `_reinstantiate_wrapped_cls`; and `_update_dataloader` -> `_get_dataloader_init_args_and_kwargs` -> `_dataloader_init_kwargs_resolve_sampler`.
   - Public entry: `Fabric.setup_dataloaders` (also reached through pytorch `_update_dataloader` for Trainer public entries).
   - Closed chain: `Fabric.setup_dataloaders -> _setup_dataloader -> fabric _update_dataloader -> _reinstantiate_wrapped_cls`.
   - Graph: N19 -> N7 -> N2 (E9, E5); N6 -> N2 (E8). Contract C7.

3. **`_replace_value_in_saved_args` in `src/lightning/fabric/utilities/data.py`**
   - Call site/unit: line 190 in `_dataloader_init_kwargs_resolve_sampler`.
   - Upward trace: `Fabric.setup_dataloaders` -> `_setup_dataloader` -> fabric `_update_dataloader` -> fabric `_get_dataloader_init_args_and_kwargs` -> `_dataloader_init_kwargs_resolve_sampler`.
   - Public entry: `Fabric.setup_dataloaders`.
   - Closed chain: `Fabric.setup_dataloaders -> _setup_dataloader -> _update_dataloader -> _get_dataloader_init_args_and_kwargs -> _dataloader_init_kwargs_resolve_sampler -> _replace_value_in_saved_args`.
   - Graph: N19 -> N7 -> N5 -> N6 -> N3 (E9, E5, E6, E7). Contract C8.

4. **`has_len_all_ranks` in `evaluation_loop.py`, `fit_loop.py`, `prediction_loop.py`**
   - Call sites/units: `_EvaluationLoop.setup_data` (`evaluation_loop.py:203`); `_FitLoop.setup_data` (`fit_loop.py:266,279`); `_PredictionLoop.setup_data` (`prediction_loop.py:162`).
   - Upward trace: public `Trainer.fit`/`validate`/`test`/`predict` -> `Trainer._run` -> `Trainer._run_stage` -> `fit_loop.run`, `_evaluation_loop.run`, or `predict_loop.run` -> `setup_data`.
   - Public entries: `Trainer.fit`, `Trainer.validate`, `Trainer.test`, `Trainer.predict`.
   - Closed chain: `Trainer.{fit,validate,test,predict} -> _run -> _run_stage -> loop.run -> loop.setup_data -> has_len_all_ranks`.
   - Graph: N20 -> N13 (E18). Contracts C21-C23, C27.

5. **`_update_dataloader` in `data_connector.py`**
   - Call sites/units: line 192 in `_DataConnector._prepare_dataloader`; line 266 in `_resolve_overfit_batches`.
   - Upward trace: `Trainer.{fit,validate,test,predict}` -> loop setup -> `_process_dataloader` -> `_prepare_dataloader`; and loop setup -> `_resolve_overfit_batches`.
   - Public entries: `Trainer.fit`, `Trainer.validate`, `Trainer.test`, `Trainer.predict`.
   - Closed chain: `Trainer.* -> loop.setup_data -> _process_dataloader -> _prepare_dataloader -> _update_dataloader`.
   - Graph: N20 -> N21 -> N9 (E14, E15). Contract C24.

6. **`_replace_dunder_methods` in `data_connector.py`**
   - Call site/unit: line 330 in `_request_dataloader`.
   - Upward trace: `Trainer.*` -> loop `run`/`setup_data` -> `_request_dataloader`.
   - Public entries: `Trainer.fit`, `Trainer.validate`, `Trainer.test`, `Trainer.predict`.
   - Closed chain: `Trainer.* -> loop.setup_data -> _request_dataloader -> _replace_dunder_methods`.
   - Graph: N20 -> N21 -> N1 (E14, E16). Contract C25.

7. **`_is_dataloader_shuffled` in `data_connector.py`**
   - Call site/unit: line 482 in `_process_dataloader`.
   - Upward trace: `Trainer.{validate,test,predict}` (and fit validation loop) -> loop setup -> `_process_dataloader`.
   - Public entries: `Trainer.validate`, `Trainer.test`, `Trainer.predict`; also validation during `Trainer.fit`.
   - Closed chain: `Trainer.* -> loop.setup_data -> _process_dataloader -> _is_dataloader_shuffled`.
   - Graph: N20 -> N21 -> N10 (E14, E17). Contract C26.

8. **`extract_batch_size` in `result.py`**
   - Call site/unit: line 349 in `_ResultCollection._extract_batch_size`.
   - Upward trace: `LightningModule.log` (`core/module.py:386`) -> `results.log` (`core/module.py:531`) -> `_ResultCollection.log` (`result.py:414`) -> `_ResultCollection._extract_batch_size`.
   - Public entry: `LightningModule.log`.
   - Closed chain: `LightningModule.log -> _ResultCollection.log -> _ResultCollection._extract_batch_size -> extract_batch_size`.
   - Graph: N22 -> N12 (E22). Contract C28.

---

## L3. Verifiable Contracts

### C1: Import boundary for fabric dunder patch
- **Type**: Compatibility / Interface
- **Subject**: `lightning.fabric.utilities.data`
- **Relation**: module exposes `_replace_dunder_methods`
- **Expected**: `from lightning.fabric.utilities.data import _replace_dunder_methods` succeeds; the object is a context manager function.
- **Evidence**: Interface Description 1; test import at `tests/tests_fabric/utilities/test_data.py:18`.
- **Observe**: `IMPORT_BOUNDARY`
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R1, R20
- **Graph**: N1

### C2: Fabric.launch runtime reaches `_replace_dunder_methods`
- **Type**: Compatibility / Call-chain
- **Subject**: `Fabric.launch` -> `_wrap_with_setup` -> `_replace_dunder_methods`
- **Relation**: public entry executes the real caller path
- **Expected**: Patching `lightning.fabric.fabric._replace_dunder_methods` with a mock and calling `fabric.launch(run)` yields two context-manager `__enter__` calls and two `__exit__` calls (one for `DataLoader`, one for `BatchSampler`).
- **Evidence**: `tests/tests_fabric/test_fabric.py:354-365`; call chain `fabric.py:931,1067-1077`.
- **Observe**: `RUNTIME_ARGUMENT_TRACE`
- **Target**: `src/lightning/fabric/fabric.py:1076`
- **Obligations**: R1, R5, R20
- **Graph**: N18 -> N1 (E1)

### C3: Constructor arguments captured on wrapped instances
- **Type**: State
- **Subject**: Instances constructed inside `_replace_dunder_methods(DataLoader, "dataset")`
- **Relation**: `__pl_saved_args`, `__pl_saved_kwargs`, `__pl_saved_arg_names`, `__pl_saved_default_kwargs` equal the constructor inputs
- **Expected**: For each parametrized subclass in `test_replace_dunder_methods_dataloader`, the four saved attributes match `args`, `kwargs`, `arg_names`, and `{}`; for `LoaderSubclass(range(10))` with default `batch_size=10`, `__pl_saved_default_kwargs == {"batch_size": 10}`.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:146-258`.
- **Observe**: `FIELD_READ`
- **Target**: wrapped instance attributes after context exit
- **Obligations**: R2, R3
- **Graph**: N1 (E2)

### C4: Explicit `dataset` private storage
- **Type**: State
- **Subject**: `_replace_dunder_methods(DataLoader, "dataset")`
- **Relation**: post-init dataset value is saved privately
- **Expected**: For `DataLoaderSubclass1`, `MyDataLoader`, `PoptorchDataLoader`, `WeirdDataLoader1/2`, `NoneDataLoader`, and `ChangingDataLoader`, `dataloader.__dataset` equals the actual `dataloader.dataset` (after subclass transformation).
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:212-218` and cases at `146-205`.
- **Observe**: `FIELD_READ`
- **Target**: `instance.__dataset`
- **Obligations**: R3
- **Graph**: N1

### C5: Attribute modifications recorded after init
- **Type**: State / Side-effect
- **Subject**: `_replace_dunder_methods(DataLoader, "dataset")`
- **Relation**: patched `__setattr__`/`__delattr__` append records
- **Expected**: After `custom_arg=5`, `my_arg=10`, `another_arg=100`, `del dataset`, and a suppressed `del abc_arg`, `__pl_attrs_record` equals `[(("custom_arg",5), SET), (("my_arg",10), SET), (("another_arg",100), SET), (("dataset",), DEL)]`.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:275-297`.
- **Observe**: `FIELD_READ`
- **Target**: `instance.__pl_attrs_record`
- **Obligations**: R4
- **Graph**: N1 -> N4 (E3)

### C6: Dunder methods restored after context
- **Type**: Lifecycle
- **Subject**: `_replace_dunder_methods(DataLoader, "dataset")`
- **Relation**: original method objects restored; subclasses without own `__init__` do not receive a private `__old__init__`
- **Expected**: Before/after `__init__`, `__setattr__`, `__delattr__` for all test classes are equal; inside the context, subclasses without own `__init__` have `"__old__init__" not in cls.__dict__` but `hasattr(cls, "__old__init__")`; `DataLoader` has `"__old__init__" in DataLoader.__dict__`.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:53-81,306-341`.
- **Observe**: `FIELD_READ`
- **Target**: class `__dict__` and method attributes before/after context
- **Obligations**: R5
- **Graph**: N1 -> N16/N17 (E2)

### C7: Reinstantiation clears saved attrs and replays changes
- **Type**: Behavior
- **Subject**: `_reinstantiate_wrapped_cls`
- **Relation**: reconstructed object preserves class and recorded attribute state without saved metadata
- **Expected**: After `_update_dataloader`, the result is an instance of the original subclass; it has no `__pl_saved_args`, `__pl_saved_kwargs`, `__pl_saved_arg_names`, `__pl_saved_default_kwargs`, or `__dataset`; replayed attributes match final values (`custom_arg == 7`, `my_arg == 10`, `another_arg == 100`, `dataset` absent).
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:227-243,299-303,454-463`.
- **Observe**: `FIELD_READ` / `RETURN_VALUE`
- **Target**: returned dataloader or batch sampler
- **Obligations**: R6, R21
- **Graph**: N2 -> N4 (E4); N19 -> N7 -> N2 (E9, E5)

### C8: Saved-argument value replacement
- **Type**: Behavior
- **Subject**: `_replace_value_in_saved_args`
- **Relation**: replacement in kwargs, positional args, or default kwargs
- **Expected**: Parameterized cases produce exactly `(expected_status, expected_args, expected_kwargs)`, including `(False, (), {})` for empty input and `(True, (2,), {})` for simple positional replacement.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:344-382`.
- **Observe**: `RETURN_VALUE`
- **Target**: `_replace_value_in_saved_args` return tuple
- **Obligations**: R7
- **Graph**: N3

### C9: IterableDataset sampler suppression
- **Type**: Dataflow
- **Subject**: fabric `_get_dataloader_init_args_and_kwargs`
- **Relation**: iterable datasets produce `sampler=None` and `batch_sampler=None`
- **Expected**: For `DataLoader(RandomIterableDataset(7,100), batch_size=32)`, returned `dl_kwargs["sampler"] is None`, `dl_kwargs["batch_sampler"] is None`, `dl_kwargs["batch_size"] is dataloader.batch_size`, `dl_kwargs["dataset"] is dataloader.dataset`, and `dl_kwargs["collate_fn"] is dataloader.collate_fn`.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:538-547`.
- **Observe**: `RETURN_VALUE`
- **Target**: returned kwargs
- **Obligations**: R11
- **Graph**: N5

### C10: Array-valued attribute default comparison
- **Type**: Dataflow
- **Subject**: fabric `_get_dataloader_init_args_and_kwargs`
- **Relation**: default-vs-attribute comparison avoids ambiguous truth-value errors
- **Expected**: For a DataLoader subclass with a numpy array attribute not present in the constructor, the returned kwargs preserve `dl_kwargs["indices"] is dataloader.indices` without raising.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:550-565`.
- **Observe**: `RETURN_VALUE`
- **Target**: returned kwargs
- **Obligations**: R10
- **Graph**: N5

### C11: Invalid dataloader type rejection
- **Type**: Failure
- **Subject**: pytorch `_update_dataloader`
- **Relation**: non-DataLoader input raises `ValueError`
- **Expected**: `_update_dataloader(object(), object(), mode="fit")` raises `ValueError` with text matching `"needs to subclass `torch.utils.data.DataLoader"`.
- **Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:184-186`.
- **Observe**: `EXCEPTION`
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R9
- **Graph**: N9

### C12: Fit-mode missing keyword arguments
- **Type**: Failure
- **Subject**: pytorch `_update_dataloader` / `_get_dataloader_init_args_and_kwargs`
- **Relation**: non-variadic subclass without sampler parameters raises `MisconfigurationException`
- **Expected**: For `TestDataLoader(dataset)` with a `SequentialSampler`, `mode="fit"` raises `MisconfigurationException` whose text matches `"missing arguments are ['batch_sampler', 'sampler', 'shuffle']"`.
- **Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:189-200`.
- **Observe**: `EXCEPTION`
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R8, R12
- **Graph**: N8 -> N5 (E10); N9 -> N8 (E11)

### C13: Predict-mode missing keyword arguments include batch keys
- **Type**: Failure
- **Subject**: pytorch `_update_dataloader` / `_get_dataloader_init_args_and_kwargs`
- **Relation**: prediction mode expands the missing-keyword surface
- **Expected**: For the same `TestDataLoader(dataset)`, `mode="predict"` raises `MisconfigurationException` matching `"missing arguments are ['batch_sampler', 'batch_size', 'drop_last', 'sampler', 'shuffle']"`.
- **Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:201-203`.
- **Observe**: `EXCEPTION`
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R12, R13
- **Graph**: N8 -> N5 (E10); N9 -> N8 (E11)

### C14: Variadic DataLoader subclasses reconstruct successfully
- **Type**: Behavior
- **Subject**: pytorch `_update_dataloader`
- **Relation**: `*args`/`**kwargs` signatures tolerate injected DataLoader kwargs
- **Expected**: For `TestDataLoader(dataset, *args, **kwargs)` and `TestDataLoader(*foo, **bar)`, both `mode="fit"` and `mode="predict"` return a DataLoader without raising.
- **Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:205-221`.
- **Observe**: `RETURN_VALUE`
- **Target**: returned DataLoader
- **Obligations**: R12, R14
- **Graph**: N9 -> N8 (E11)

### C15: Multiprocessing context preservation
- **Type**: Dataflow
- **Subject**: pytorch `_update_dataloader`
- **Relation**: reconstructing with a new sampler preserves `multiprocessing_context`
- **Expected**: `new_data_loader.multiprocessing_context == train.multiprocessing_context` for a `DataLoader(..., num_workers=2, multiprocessing_context="spawn")`.
- **Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:252-258`.
- **Observe**: `FIELD_READ`
- **Target**: returned DataLoader
- **Obligations**: R10, R14
- **Graph**: N9 -> N2 (E12)

### C16: Prediction dataloader batch-sampler wrapper
- **Type**: Side-effect / State
- **Subject**: pytorch `_update_dataloader`
- **Relation**: prediction mode wraps the batch sampler
- **Expected**: After `Trainer.predict`, `trainer.predict_dataloaders.batch_sampler` is an `_IndexBatchSamplerWrapper`; its `sampler` is the resolved sampler (`SequentialSampler` or `DistributedSampler`/`UnrepeatedDistributedSampler` in distributed cases).
- **Evidence**: `tests/tests_pytorch/loops/test_prediction_loop.py:83-88`; `tests/tests_pytorch/trainer/test_trainer.py:1310-1311`.
- **Observe**: `FIELD_READ`
- **Target**: `dataloader.batch_sampler`
- **Obligations**: R13
- **Graph**: N9 -> N15 (E13)

### C17: Shuffle detection through samplers
- **Type**: Behavior
- **Subject**: `_is_dataloader_shuffled`
- **Relation**: sampler type determines shuffle state
- **Expected**: `True` for `DataLoader(dataset, shuffle=True)` (RandomSampler); `False` for `DataLoader(dataset)` (SequentialSampler), `DataLoader(dataset, sampler=list(range(64)))`, and IterableDataset dataloaders.
- **Evidence**: `tests/tests_pytorch/trainer/connectors/test_data_connector.py:420-449` (caller warning behavior); Interface Description 2.
- **Observe**: `RETURN_VALUE`
- **Target**: `_is_dataloader_shuffled`
- **Obligations**: R15
- **Graph**: N10

### C18: Shuffle detection honors saved constructor args
- **Type**: Behavior
- **Subject**: `_is_dataloader_shuffled`
- **Relation**: wrapped-DataLoader saved args take precedence
- **Expected**: For a DataLoader constructed inside `_replace_dunder_methods` with `shuffle=True` (or `shuffle` as a positional arg), the function returns `True`; with `shuffle=False`, it returns `False`, before sampler fallback.
- **Evidence**: Interface Description 2 notes; saved-arg capture contracts C3.
- **Observe**: `RETURN_VALUE`
- **Target**: `_is_dataloader_shuffled`
- **Obligations**: R15
- **Graph**: N10 -> N1 (saved attrs dependency)

### C19: Batch-size extraction from tensors and containers
- **Type**: Dataflow
- **Subject**: `extract_batch_size`
- **Relation**: recursive traversal returns first tensor dimension
- **Expected**: `torch.zeros(3,4) -> 3`; scalar tensor -> `1`; mapping of two `(3,4)` tensors -> `3`; dataclass containing a `(5,2)` tensor -> `5`; a bare string raises `MisconfigurationException`.
- **Evidence**: Interface Description 2; `_extract_batch_size` at `src/lightning/pytorch/utilities/data.py:43-59`.
- **Observe**: `RETURN_VALUE` / `EXCEPTION`
- **Target**: `extract_batch_size`
- **Obligations**: R16
- **Graph**: N12 -> N11 (E21)

### C20: Ambiguous batch warning and tensor-free failure
- **Type**: Failure / Side-effect
- **Subject**: `extract_batch_size`
- **Relation**: differing tensor sizes warn; no tensor raises
- **Expected**: For a mapping containing tensors of shape `(2,...)` and `(3,...)`, a warning is emitted and the returned size is the first encountered (`2`); for a collection with no tensors, `MisconfigurationException` is raised.
- **Evidence**: Interface Description 2 notes; `MisconfigurationException` and `WarningCache` imports at `src/lightning/pytorch/utilities/data.py:35,40`.
- **Observe**: `SIDE_EFFECT` / `EXCEPTION`
- **Target**: `extract_batch_size`
- **Obligations**: R17
- **Graph**: N12 -> N11 (E21)

### C21: `has_len_all_ranks` returns false without `__len__`
- **Type**: Behavior
- **Subject**: `has_len_all_ranks`
- **Relation**: no local length short-circuits validation
- **Expected**: For `DataLoader(IterableWithoutLen(), batch_size=16)`, `has_len_all_ranks(dataloader, trainer.strategy)` returns `False` and does not call `strategy.reduce`.
- **Evidence**: `tests/tests_pytorch/trainer/test_dataloaders.py:732-734`.
- **Observe**: `RETURN_VALUE` / `RUNTIME_ARGUMENT_TRACE`
- **Target**: `has_len_all_ranks`
- **Obligations**: R18
- **Graph**: N13 -> N14 (E19)

### C22: `has_len_all_ranks` true for sized iterable dataloader
- **Type**: Behavior / Side-effect
- **Subject**: `has_len_all_ranks`
- **Relation**: local length present returns true and participates in loop setup warnings
- **Expected**: For `DataLoader(IterableWithLen(), batch_size=16)`, `has_len_all_ranks(dataloader, trainer.strategy)` returns `True`; subsequent `trainer.validate/fit/test/predict` with this dataloader emits the existing `"Your `IterableDataset` has `__len__` defined."` warning.
- **Evidence**: `tests/tests_pytorch/trainer/test_dataloaders.py:717-729`.
- **Observe**: `RETURN_VALUE` / `SIDE_EFFECT`
- **Target**: `has_len_all_ranks`
- **Obligations**: R18, R19
- **Graph**: N13 -> N14 (E19); N20 -> N13 (E18)

### C23: Distributed length reduction and zero-length runtime error
- **Type**: Distributed / Failure
- **Subject**: `has_len_all_ranks`
- **Relation**: strategy reduction determines total length and zero-local-length policy
- **Expected**: With a mock strategy whose `reduce` returns `torch.tensor(3)`, a local dataloader of length `0` and `allow_zero_length_dataloader_with_multiple_devices=False` raises `RuntimeError`; with the flag `True`, no `RuntimeError` is raised. With total length `0`, a warning is emitted.
- **Evidence**: Interface Description 2 Raises and Notes; strategy reduce interface at `src/lightning/pytorch/strategies/strategy.py:295-302`.
- **Observe**: `EXCEPTION` / `SIDE_EFFECT`
- **Target**: `has_len_all_ranks`
- **Obligations**: R19
- **Graph**: N13 -> strategy.reduce (E20)

### C24: Trainer data-preparation path reaches pytorch `_update_dataloader`
- **Type**: Call-chain
- **Subject**: Trainer loop setup -> `_prepare_dataloader` -> `_update_dataloader`
- **Relation**: public trainer entry executes the real caller path
- **Expected**: Running `Trainer.validate` or `Trainer.predict` with a dataloader requiring sampler injection executes `_update_dataloader` at `data_connector.py:192`; the returned dataloader is the same subclass and uses the injected sampler.
- **Evidence**: `trainer.py:1108-1122`; `data_connector.py:177-192,494`; `tests/tests_pytorch/trainer/connectors/test_data_connector.py:261-335`.
- **Observe**: `RUNTIME_ARGUMENT_TRACE`
- **Target**: `src/lightning/pytorch/trainer/connectors/data_connector.py:192`
- **Obligations**: R13, R14, R20
- **Graph**: N20 -> N21 -> N9 (E14, E15)

### C25: Trainer dataloader-request path reaches `_replace_dunder_methods`
- **Type**: Call-chain
- **Subject**: loop setup -> `_request_dataloader` -> `_replace_dunder_methods`
- **Relation**: public trainer entry executes the real caller path
- **Expected**: Running a trainer loop that invokes a user `*_dataloader` hook enters both `_replace_dunder_methods(DataLoader, "dataset")` and `_replace_dunder_methods(BatchSampler)` contexts; DataLoader instances created in the hook carry saved args after the call.
- **Evidence**: `data_connector.py:323-335`; loop call sites `fit_loop.py:238`, `evaluation_loop.py:177`, `prediction_loop.py:140`.
- **Observe**: `RUNTIME_ARGUMENT_TRACE` / `FIELD_READ`
- **Target**: `src/lightning/pytorch/trainer/connectors/data_connector.py:330`
- **Obligations**: R1, R5, R20
- **Graph**: N20 -> N21 -> N1 (E14, E16)

### C26: Trainer processing path reaches `_is_dataloader_shuffled`
- **Type**: Call-chain
- **Subject**: loop setup -> `_process_dataloader` -> `_is_dataloader_shuffled`
- **Relation**: public trainer entry executes the real caller path
- **Expected**: During validation/test/prediction setup with a shuffled eval dataloader, `_is_dataloader_shuffled` is called and the caller emits `PossibleUserWarning` recommending shuffling be turned off.
- **Evidence**: `data_connector.py:478-489`; `tests/tests_pytorch/trainer/connectors/test_data_connector.py:420-449`.
- **Observe**: `RUNTIME_ARGUMENT_TRACE` / `SIDE_EFFECT`
- **Target**: `src/lightning/pytorch/trainer/connectors/data_connector.py:482`
- **Obligations**: R15, R20
- **Graph**: N20 -> N21 -> N10 (E14, E17)

### C27: Trainer loops reach `has_len_all_ranks`
- **Type**: Call-chain
- **Subject**: loop setup -> `has_len_all_ranks`
- **Relation**: public trainer entry executes the real caller path
- **Expected**: During `Trainer.fit`, `Trainer.validate`, `Trainer.test`, or `Trainer.predict`, the relevant loop calls `has_len_all_ranks` and uses `len(dl)` only when it returns true.
- **Evidence**: `evaluation_loop.py:203`; `fit_loop.py:266,279`; `prediction_loop.py:162`; `tests/tests_pytorch/trainer/test_dataloaders.py:717-739`.
- **Observe**: `RUNTIME_ARGUMENT_TRACE`
- **Target**: loop call sites listed above
- **Obligations**: R18, R19, R20
- **Graph**: N20 -> N13 (E18)

### C28: LightningModule.log path reaches `extract_batch_size`
- **Type**: Call-chain
- **Subject**: `LightningModule.log` -> `_ResultCollection.log` -> `extract_batch_size`
- **Relation**: public logging entry executes the real caller path
- **Expected**: Logging an epoch-mean tensor metric with `batch_size=None` and a non-empty `self.batch` invokes `extract_batch_size(self.batch)` and stores the returned int in `result.batch_size`.
- **Evidence**: `core/module.py:386-548`; `result.py:339-352,414`; Interface Description 2.
- **Observe**: `RUNTIME_ARGUMENT_TRACE` / `FIELD_READ`
- **Target**: `src/lightning/pytorch/trainer/connectors/logger_connector/result.py:349`
- **Obligations**: R16, R17, R20
- **Graph**: N22 -> N12 (E22)

### C29: Custom batch sampler compatibility
- **Type**: Compatibility / Failure
- **Subject**: fabric/pytorch dataloader reconstruction with custom batch samplers
- **Relation**: supported custom batch samplers reconstruct; unsupported ones fail
- **Expected**: A wrapped `BatchSampler` subclass with captured init args and a `sampler` parameter reconstructs as the same class with no saved attrs; a non-PyTorch doppelganger exposing `batch_size`/`drop_last` reconstructs with the new sampler; an unsupported custom batch sampler raises `TypeError` containing `"can't inject a (distributed) sampler into your batch sampler"`.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:422-535`.
- **Observe**: `RETURN_VALUE` / `EXCEPTION`
- **Target**: reconstructed dataloader / `TypeError`
- **Obligations**: R21
- **Graph**: N6 -> N3 (E7); N6 -> N2 (E8)

### C30: Existing optimization utilities preserved
- **Type**: Compatibility
- **Subject**: `_set_sampler_epoch` and `suggested_max_num_workers`
- **Relation**: existing behavior remains unchanged after adding new utilities
- **Expected**: `_set_sampler_epoch` calls `set_epoch(55)` on dataloader sampler and batch-sampler sampler; `suggested_max_num_workers` follows the existing `max(1, cpu_count // local_world_size - 1)` contract and raises `ValueError` for `local_world_size < 1`.
- **Evidence**: `tests/tests_fabric/utilities/test_data.py:568-620`; `src/lightning/fabric/utilities/data.py:415-459`.
- **Observe**: `RETURN_VALUE` / `SIDE_EFFECT`
- **Target**: existing functions
- **Obligations**: R22
- **Graph**: N16/N17 adjacent existing utilities

