# Spec Review Report

## Evidence Reviewed
- Task document (primary oracle) and Interface Descriptions 1 and 2.
- Semantic IR: `/agent-logs/codespec2/Lightning-AI__pytorch-lightning.126fa6f1.test_data.c8b292af.lv1_20260813_023720/artifacts/semantic_ir.md`
- Architecture spec: `/agent-logs/codespec2/Lightning-AI__pytorch-lightning.126fa6f1.test_data.c8b292af.lv1_20260813_023720/artifacts/arch_spec.py`
- Behavior spec: `/agent-logs/codespec2/Lightning-AI__pytorch-lightning.126fa6f1.test_data.c8b292af.lv1_20260813_023720/artifacts/behavior_spec.py`
- Static analysis/issues: `/agent-logs/codespec2/Lightning-AI__pytorch-lightning.126fa6f1.test_data.c8b292af.lv1_20260813_023720/artifacts/static_analysis.md`, `static_issues.md`
- Review skill: `/installed-agent/codespec2/review_skill.md`
- Source traced for every static issue: `src/lightning/fabric/fabric.py`, `src/lightning/fabric/utilities/data.py`, `src/lightning/pytorch/utilities/data.py`, `src/lightning/pytorch/trainer/connectors/data_connector.py`, `src/lightning/pytorch/trainer/connectors/logger_connector/result.py`, `src/lightning/pytorch/loops/{evaluation_loop,fit_loop,prediction_loop}.py`, `src/lightning/pytorch/strategies/strategy.py`, `src/lightning/pytorch/overrides/distributed.py`.
- Repository tests inspected: `tests/tests_fabric/utilities/test_data.py`, `tests/tests_fabric/test_fabric.py`, `tests/tests_pytorch/trainer/connectors/test_data_connector.py`, `tests/tests_pytorch/trainer/test_dataloaders.py`, `tests/tests_pytorch/loops/test_prediction_loop.py`.

## Rubric Scores

| Rubric | Score | Evidence | Affected IDs |
|---|---|---|---|
| Requirement coverage (seed) | FAIL | Declared pytorch `_get_dataloader_init_args_and_kwargs` has no import-boundary or direct-return observation; only `_update_dataloader` is exercised indirectly. | R8, R9, R10, R11; E10, E11 |
| Repository-test alignment (seed/derived from `tests/tests_fabric/utilities/test_data.py::test_update_dataloader_typerror_custom_exception`) | FAIL | Fabric `_update_dataloader` conflict diagnostics (`implementation has an error.*dataset/shuffle`) and wrapped-vs-unwrapped success are not represented in either spec. | R12, R6, R21 |
| Failure and compatibility (seed/derived from `tests/tests_fabric/utilities/test_data.py::test_custom_batch_sampler_no_sampler`) | FAIL | Wrapped custom `BatchSampler` without a `sampler` parameter is not observed; C29 tests a different unwrapped unsupported path. | R21; E7, E8 |
| Dataflow and lifecycle (seed/derived from `tests/tests_fabric/utilities/test_data.py::test_replace_dunder_methods_restore_methods`) | FAIL | C6 observes `__old__init__` scope but never observes `__old__setattr__`/`__old__delattr__` patch scope inside the context. | R5; E2 |
| Distributed state (seed/derived from `tests/tests_pytorch/trainer/test_dataloaders.py::test_warning_with_iterable_dataset_and_len` and Strategy.reduce contract) | FAIL | `has_len_all_ranks` uneven-length warning is missing; reduce input tensor is not asserted; mock strategy lacks `root_device`/`world_size`. | R19; C22, C23, E20 |
| Prediction-mode fidelity (seed/derived from `tests/tests_pytorch/loops/test_prediction_loop.py` and Interface Description 2 notes) | FAIL | C16 checks only `_IndexBatchSamplerWrapper` type, not the required `drop_last=False` value. | R13; C16, E13 |
| Recursive failure oracle (seed/derived from Interface Description 2 Raises) | FAIL | `extract_batch_size` circular-reference `RecursionError` is not observed. | R16; C19, C20, E21 |
| Shuffle-detection boundary (seed/derived from Interface Description 2 Notes) | FAIL | Batch-sampler fallback and internal-sampler inspection are not directly observed. | R15; C17, C18, E17 |
| Caller binding and static-issue closure (seed) | PASS | Re-traced all eight static-issue call sites to public entries; C2/C7/C8/C24/C25/C26/C27/C28 execute real caller paths through `Fabric.launch`, `Fabric.setup_dataloaders`, `Trainer.predict`, `Trainer.validate`, and `Trainer.fit`. | R20; E1, E5, E6, E7, E9, E14, E15, E16, E17, E18, E22 |
| Oracle strength (seed) | FAIL | Several checks are success-only, broad-type, or count-only: C14 variadic reconstruction, C16 wrapper-type-only, C22/C23 reduce-return-only, C29 missing wrapped-no-sampler path. | R13, R14, R19, R21 |

## Findings

### Finding 1
- **Type**: `missing_requirement`
- **Affected IDs**: R8, R9, R10, R11; E10, E11
- **Static issue**: none (declared interface, not a static call-site issue)
- **Repository source/test evidence**: Interface Description 2 defines `src/lightning/pytorch/utilities/data.py::_get_dataloader_init_args_and_kwargs(dataloader, sampler, mode=None)`. The generated behavior spec never imports or calls the pytorch function. C9 and C10 call only the fabric analogue at `src/lightning/fabric/utilities/data.py:80`. `tests/tests_pytorch/trainer/connectors/test_data_connector.py` exercises `_update_dataloader`, but that does not prove the declared extractor exists or has the required `mode` parameter.
- **Gap**: An implementation could omit `_get_dataloader_init_args_and_kwargs` or hardcode extraction inside `_update_dataloader`, and every current check would still pass. Hidden tests that import and call the extractor directly would fail.
- **Rework**: Add a direct behavior check that imports `lightning.pytorch.utilities.data._get_dataloader_init_args_and_kwargs`, calls it with an ordinary map-style `DataLoader`, and asserts the returned `(args, kwargs)` tuple contains the injected sampler. Also add direct observations for: non-`DataLoader` input raising `ValueError`, `IterableDataset` forcing `sampler=None`/`batch_sampler=None`, and `mode=RunningStage.PREDICTING` expanding missing-keyword validation with `batch_size`/`drop_last`.

### Finding 2
- **Type**: `missing_requirement`
- **Affected IDs**: R12, R6, R21
- **Static issue**: none
- **Repository source/test evidence**: `tests/tests_fabric/utilities/test_data.py::test_update_dataloader_typerror_custom_exception` requires fabric `_update_dataloader` to raise `MisconfigurationException` matching `implementation has an error.*dataset` for `BadStandaloneGoodHookImpl` and `implementation has an error.*shuffle` for `BadImpl`, while wrapped `BadStandaloneGoodHookImpl` and unwrapped `GoodImpl` succeed. Neither the semantic IR nor the executable specs contain this contract.
- **Gap**: Generated checks C7/C8/C29 cover reconstruction, saved-arg replacement, and batch-sampler compatibility, but a regression in the fabric conflict-detection path would go unnoticed. This is an existing repository test whose failure semantics are not compiled into the spec.
- **Rework**: Add a behavior check that constructs the three repository cases (`BadStandaloneGoodHookImpl`, `BadImpl`, `GoodImpl`) and observes the exact `MisconfigurationException` matches for unwrapped instances, successful reconstruction for the wrapped bad instance, and successful reconstruction for `GoodImpl`.

### Finding 3
- **Type**: `missing_requirement`
- **Affected IDs**: R19; C22, C23, E20
- **Static issue**: none
- **Repository source/test evidence**: Interface Description 2 Notes require a warning for uneven batch length distribution across ranks. The current checks observe only total-zero warning and zero-local-length `RuntimeError`. `src/lightning/pytorch/strategies/strategy.py:296` exposes `reduce(..., reduce_op="sum")`.
- **Gap**: An implementation that sums lengths but never warns on uneven distribution passes all current checks.
- **Rework**: Add a direct check with `strategy.world_size = 2`, a local dataloader length of 3, and `strategy.reduce.return_value = torch.tensor(7)`. Capture warnings and assert that an uneven-distribution warning is emitted while the function returns `True`.

### Finding 4
- **Type**: `weak_constraint`
- **Affected IDs**: R19; C22, C23, E20
- **Static issue**: none
- **Repository source/test evidence**: C22 only asserts `strategy.reduce.assert_called_once()` and `reduce_op == "sum"`. C23 asserts only the final `RuntimeError`/return. The mock strategy is a bare `Mock()` without `root_device` or `world_size`; `Strategy.root_device` exists at `src/lightning/pytorch/strategies/strategy.py:283`.
- **Gap**: A wrong implementation can pass a different tensor value (or omit a device placement) and still satisfy the mocked return-value observations. The fixture may also fail against a correct implementation that places the reduced tensor on `strategy.root_device`.
- **Rework**: Configure the mock strategy with `root_device=torch.device("cpu")` and an explicit `world_size`, then assert the actual reduced tensor, e.g. `strategy.reduce.call_args[0][0].item() == sized_len(dataloader)`, in addition to `reduce_op == "sum"`.

### Finding 5
- **Type**: `weak_constraint`
- **Affected IDs**: R13; C16, E13
- **Static issue**: none
- **Repository source/test evidence**: `tests/tests_pytorch/loops/test_prediction_loop.py:83-88` checks `_IndexBatchSamplerWrapper`, and C16 does the same with a `DataLoader` that already has default `drop_last=False`. Interface Description 2 explicitly requires `drop_last=False` for prediction mode.
- **Gap**: C16 cannot distinguish a correct implementation that forces `drop_last=False` from one that leaves an original `drop_last=True` intact, because the fixture starts with the default value.
- **Rework**: Use `DataLoader(dataset, batch_size=2, drop_last=True)`, call `_update_dataloader(..., mode=RunningStage.PREDICTING)`, and assert `new_dataloader.batch_sampler.drop_last is False` (or the equivalent field exposed through `_IndexBatchSamplerWrapper`).

### Finding 6
- **Type**: `missing_requirement`
- **Affected IDs**: R16; C19, C20, E21
- **Static issue**: none
- **Repository source/test evidence**: Interface Description 2 Raises documents `RecursionError` for circular or excessively nested batches. C19 and C20 test tensor, mapping, dataclass, string, ambiguous-size warning, and no-tensor failure, but no circular structure.
- **Gap**: A recursive `extract_batch_size` that mishandles circular references or otherwise fails to surface `RecursionError` passes the current checks.
- **Rework**: Add a self-referential batch (e.g. `batch = []; batch.append(batch)`) and assert `RecursionError` is raised by `extract_batch_size`.

### Finding 7
- **Type**: `weak_constraint`
- **Affected IDs**: R15; C17, C18, E17
- **Static issue**: none
- **Repository source/test evidence**: Interface Description 2 Notes state that batch samplers are inspected, with custom batch samplers checked for an internal `sampler` and falling back to the batch sampler itself when absent. C17 only observes ordinary `DataLoader` sampler paths, and C18 observes saved constructor args. `tests/tests_pytorch/trainer/connectors/test_data_connector.py::test_non_sequential_sampler_warning_is_raised_for_eval_dataloader` exercises the caller warning path but not these direct fallback branches.
- **Gap**: A wrong `_is_dataloader_shuffled` implementation that ignores batch-sampler fallback can pass.
- **Rework**: Add direct mock observations: a dataloader object whose `batch_sampler` contains an internal `RandomSampler` should return `True`; one with an internal `SequentialSampler` should return `False`; one with no internal sampler but whose `batch_sampler` itself is a `RandomSampler` should return `True`.

### Finding 8
- **Type**: `weak_constraint`
- **Affected IDs**: R5; C6, E2
- **Static issue**: none
- **Repository source/test evidence**: `tests/tests_fabric/utilities/test_data.py::test_replace_dunder_methods_restore_methods` checks restoration and C6 checks `__old__init__` ownership inside the context, but Interface Description 1 also requires patch-scope rules for `__setattr__` and `__delattr__`: only classes owning them in `__dict__` are patched, except the base class always has wrapped set/del.
- **Gap**: A wrong implementation can patch `__setattr__`/`__delattr__` on every subclass, or fail to patch them on the base class, and still satisfy C6 because C6 never inspects those methods while the context is active.
- **Rework**: Inside `_replace_dunder_methods`, assert `__old__setattr__ in DataLoader.__dict__` and `__old__delattr__ in DataLoader.__dict__`. For subclasses defining only `__setattr__` or only `__delattr__`, assert the corresponding old method appears only in the defining class's `__dict__` and is inherited, not owned, by subclasses that do not define it.

### Finding 9
- **Type**: `weak_constraint`
- **Affected IDs**: R21; C29, E7, E8
- **Static issue**: none
- **Repository source/test evidence**: `tests/tests_fabric/utilities/test_data.py::test_custom_batch_sampler_no_sampler` creates a wrapped `BatchSampler` subclass whose constructor lacks a `sampler` argument and expects saved attrs plus a `TypeError` containing `sampler into the batch sampler`. C29 covers wrapped custom `BatchSampler` with `sampler`, doppelganger with `batch_size`/`drop_last`, and an unwrapped unsupported sampler, but not this wrapped-no-sampler branch.
- **Gap**: The `success=False` path of `_replace_value_in_saved_args` in `_dataloader_init_kwargs_resolve_sampler` is never executed by the generated specs.
- **Rework**: Add a case with `with _replace_dunder_methods(BatchSampler): batch_sampler = MyBatchSampler("random_str")`, construct `DataLoader(range(10), batch_sampler=batch_sampler)`, assert the saved attrs, and assert `_update_dataloader` raises `TypeError` matching `sampler into the batch sampler`.

## Decision
`Decision: REWORK`
