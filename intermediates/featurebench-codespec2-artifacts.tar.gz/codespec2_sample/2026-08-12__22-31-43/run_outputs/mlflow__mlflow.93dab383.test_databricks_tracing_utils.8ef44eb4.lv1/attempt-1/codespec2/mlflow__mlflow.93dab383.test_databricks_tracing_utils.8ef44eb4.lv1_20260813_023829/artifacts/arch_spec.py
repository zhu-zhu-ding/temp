"""Executable architecture spec for MLflow tracing/assessment data management.

This file compiles caller-binding and dependency/connectivity contracts from
semantic_ir.md into no-argument runtime checks. Each check executes a real
public entry and follows the repository delegation path to the task-required
helper; external HTTP/backend endpoints are mocked narrowly.
"""

from __future__ import annotations

import json
import os
import sys
import traceback
from unittest import mock

from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

from mlflow.entities import (
    AssessmentSource,
    Feedback,
    Span,
    Trace,
    TraceData,
    TraceInfo,
    TraceLocation,
    TraceLocationType,
)
from mlflow.entities.trace_location import UCSchemaLocation
from mlflow.entities.trace_state import TraceState
from mlflow.protos import databricks_tracing_pb2 as pb
from mlflow.protos.databricks_tracing_pb2 import (
    BatchGetTraces,
    SearchTraces,
    UpdateAssessment,
)
from mlflow.store.tracking.databricks_rest_store import DatabricksTracingRestStore
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue
from mlflow.utils import databricks_tracing_utils as dbu
from mlflow.utils.rest_utils import MlflowHostCreds


def _make_uc_trace_info():
    return TraceInfo(
        trace_id="trace:/catalog.schema/tr-1",
        client_request_id="client-1",
        trace_location=TraceLocation.from_databricks_uc_schema("catalog", "schema"),
        request_time=123,
        execution_duration=456,
        state=TraceState.OK,
        request_preview="request-preview",
        response_preview="response-preview",
        trace_metadata={"meta-key": "meta-value"},
        tags={"tag-key": "tag-value"},
        assessments=[],
    )


def _make_feedback():
    return Feedback(
        trace_id="trace:/catalog.schema/tr-1",
        name="assessment_name",
        value=True,
        source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
        create_time_ms=123,
        last_update_time_ms=456,
        rationale="because",
        metadata={"numeric": 1},
        span_id="span-1",
        overrides="old-assessment",
        valid=False,
    )


def _make_otel_proto_span(name="span1", attributes=None):
    otel_span = OTelProtoSpan()
    otel_span.name = name
    otel_span.trace_id = bytes.fromhex("11" * 16)
    otel_span.span_id = bytes.fromhex("22" * 8)
    for key, value in (attributes or {}).items():
        attr = otel_span.attributes.add()
        attr.key = key
        _set_otel_proto_anyvalue(attr.value, value)
    return otel_span


def _make_store():
    return DatabricksTracingRestStore(lambda: MlflowHostCreds("https://test"))


def _warehouse_env():
    return mock.patch.dict(os.environ, {"MLFLOW_TRACING_SQL_WAREHOUSE_ID": "warehouse"})


def _run(checks):
    failures = []
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as exc:  # noqa: BLE001 - intentional test runner
            failures.append((check.__name__, exc))
            print(f"FAIL: {check.__name__}: {exc!r}")
            traceback.print_exc()
    if failures:
        print(f"ARCHITECTURE SPEC FAILED: {len(failures)} check(s) failed")
        sys.exit(1)
    print("ARCHITECTURE SPEC PASSED")


# Contracts: C24, R6, R17. Static issue: mlflow/entities/trace_info.py uses
# trace_info_to_v4_proto without an import.
# Repo guidance: tests/entities/test_trace_info.py::test_trace_info_v4 calls
# trace_info_v4.to_proto() and checks parsed UC fields.
# Perspective: execute the real TraceInfo.to_proto caller and observe the v4 helper result.
# Source path: mlflow.entities.trace_info.TraceInfo.to_proto ->
# mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto.
def check_trace_info_to_proto_uc_caller_path_binds_v4_helper():
    trace_info = _make_uc_trace_info()
    proto = trace_info.to_proto()

    assert isinstance(proto, pb.TraceInfo)
    assert proto.trace_id == "tr-1"
    assert proto.trace_location.uc_schema.catalog_name == "catalog"
    assert proto.trace_location.uc_schema.schema_name == "schema"
    assert proto == dbu.trace_info_to_v4_proto(trace_info)


# Contracts: C25, R7, R18. Static issue: mlflow/entities/trace_location.py uses
# trace_location_from_proto without an import.
# Repo guidance: tests/entities/test_trace_location.py
# ::test_trace_location_from_v4_proto_mlflow_experiment.
# Perspective: execute the real TraceLocation.from_proto caller and observe the
# oneof-dispatch helper result.
# Source path: mlflow.entities.trace_location.TraceLocation.from_proto ->
# mlflow.utils.databricks_tracing_utils.trace_location_from_proto.
def check_trace_location_from_proto_caller_path_binds_helper():
    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=pb.MlflowExperimentLocation(experiment_id="1234"),
    )
    location = TraceLocation.from_proto(proto)

    assert location.type == TraceLocationType.MLFLOW_EXPERIMENT
    assert location.mlflow_experiment.experiment_id == "1234"
    assert location == dbu.trace_location_from_proto(proto)


# Contracts: C26, R1, R19. Static issue: databricks_rest_store.py uses
# assessment_to_proto without an import (create_assessment call site).
# Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_create_assessment verifies the v4 assessment request JSON and returned entity.
# Perspective: execute DatabricksTracingRestStore.create_assessment, keep _call_endpoint
# mocked, and inspect the real serialized request body produced by assessment_to_proto.
# Source path: mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.create_assessment ->
# mlflow.utils.databricks_tracing_utils.assessment_to_proto.
def check_rest_store_create_assessment_binds_assessment_to_proto():
    feedback = _make_feedback()
    response_proto = dbu.assessment_to_proto(feedback)
    response_proto.assessment_id = "assessment-1"

    store = _make_store()
    with mock.patch.object(store, "_call_endpoint", return_value=response_proto) as call:
        result = store.create_assessment(assessment=feedback)

    request_body = json.loads(call.call_args[0][1])
    assert request_body["assessment_name"] == feedback.name
    assert request_body["trace_id"] == "tr-1"
    assert request_body["trace_location"]["uc_schema"]["catalog_name"] == "catalog"
    assert request_body["trace_location"]["uc_schema"]["schema_name"] == "schema"

    assert isinstance(result, Feedback)
    assert result.assessment_id == "assessment-1"
    assert result.trace_id == "trace:/catalog.schema/tr-1"


# Contracts: C27, R5, R19. Static issue: databricks_rest_store.py uses
# trace_from_proto without an import (batch_get_traces call site).
# Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_batch_get_traces verifies returned Trace list and span count from a v4 response.
# Perspective: execute batch_get_traces with a mocked BatchGetTraces response and prove
# the real response proto passes through trace_from_proto into Trace entities.
# Source path: mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.batch_get_traces ->
# mlflow.utils.databricks_tracing_utils.trace_from_proto.
def check_rest_store_batch_get_traces_binds_trace_from_proto():
    trace_info = _make_uc_trace_info()
    span = Span.from_otel_proto(_make_otel_proto_span("span1"), "catalog.schema")
    trace = Trace(info=trace_info, data=TraceData(spans=[span]))

    response = BatchGetTraces.Response()
    response.traces.extend([dbu.trace_to_proto(trace)])

    store = _make_store()
    with _warehouse_env():
        with mock.patch.object(store, "_call_endpoint", return_value=response) as call:
            result = store.batch_get_traces(["trace:/catalog.schema/tr-1"], "catalog.schema")

    assert len(result) == 1
    assert result[0].info.trace_id == "trace:/catalog.schema/tr-1"
    assert len(result[0].data.spans) == 1
    assert result[0].data.spans[0].name == "span1"

    request_body = json.loads(call.call_args[0][1])
    assert request_body["trace_ids"] == ["tr-1"]
    assert request_body["location_id"] == "catalog.schema"


# Contracts: C28, R10, R11, R19. Static issue: databricks_rest_store.py uses
# uc_schema_location_to_proto and uc_schema_location_from_proto without imports
# (set_experiment_trace_location call sites).
# Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_set_experiment_trace_location inspects both v4 request bodies and returned
# UCSchemaLocation table names.
# Perspective: execute set_experiment_trace_location with mocked endpoint responses and
# observe both serialization and deserialization call sites in the real request/result path.
# Source path: mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.set_experiment_trace_location ->
# mlflow.utils.databricks_tracing_utils.uc_schema_location_to_proto/from_proto.
def check_rest_store_set_experiment_trace_location_binds_uc_schema_converters():
    location = UCSchemaLocation(catalog_name="test_catalog", schema_name="test_schema")

    create_response = mock.MagicMock()
    create_response.uc_schema = pb.UCSchemaLocation(
        catalog_name="test_catalog",
        schema_name="test_schema",
        otel_spans_table_name="test_spans",
        otel_logs_table_name="test_logs",
    )
    link_response = mock.MagicMock()

    store = _make_store()
    with _warehouse_env():
        with mock.patch.object(
            store, "_call_endpoint", side_effect=[create_response, link_response]
        ) as call:
            result = store.set_experiment_trace_location(
                location=location,
                experiment_id="123",
                sql_warehouse_id="warehouse",
            )

    create_body = json.loads(call.call_args_list[0][0][1])
    assert create_body["uc_schema"]["catalog_name"] == "test_catalog"
    assert create_body["uc_schema"]["schema_name"] == "test_schema"
    assert create_body["sql_warehouse_id"] == "warehouse"

    link_body = json.loads(call.call_args_list[1][0][1])
    assert link_body["experiment_id"] == "123"
    assert link_body["uc_schema"]["catalog_name"] == "test_catalog"
    assert link_body["uc_schema"]["schema_name"] == "test_schema"
    assert link_body["uc_schema"]["otel_spans_table_name"] == "test_spans"
    assert link_body["uc_schema"]["otel_logs_table_name"] == "test_logs"

    assert result.catalog_name == "test_catalog"
    assert result.schema_name == "test_schema"
    assert result.full_otel_spans_table_name == "test_catalog.test_schema.test_spans"
    assert result.full_otel_logs_table_name == "test_catalog.test_schema.test_logs"


# Contracts: C28 supplemental, R10, R11, R19. Static issue:
# databricks_rest_store.py uses uc_schema_location_to_proto without an import at the
# unset_experiment_trace_location call site (line 451).
# Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_unset_experiment_trace_location_with_uc_schema asserts the UC schema JSON body.
# Perspective: execute the real unset_experiment_trace_location caller with _call_endpoint
# mocked and inspect the request body produced by uc_schema_location_to_proto. This closes
# the remaining on-path binding site that set_experiment_trace_location does not exercise.
# Source path: mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.unset_experiment_trace_location ->
# mlflow.utils.databricks_tracing_utils.uc_schema_location_to_proto.
def check_rest_store_unset_experiment_trace_location_binds_uc_schema_to_proto():
    location = UCSchemaLocation(catalog_name="test_catalog", schema_name="test_schema")

    store = _make_store()
    with mock.patch.object(store, "_call_endpoint", return_value=mock.MagicMock()) as call:
        result = store.unset_experiment_trace_location(
            experiment_id="123",
            location=location,
        )

    request_body = json.loads(call.call_args[0][1])
    assert request_body["experiment_id"] == "123"
    assert request_body["uc_schema"]["catalog_name"] == "test_catalog"
    assert request_body["uc_schema"]["schema_name"] == "test_schema"
    assert result is None


# Contracts: C29, R8, R19. Static issue: databricks_rest_store.py uses
# trace_location_to_proto without an import (search_traces call sites 290 and 294).
# Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_search_traces_with_mixed_locations asserts both experiment and UC location JSON.
# Perspective: execute search_traces with mixed locations and inspect the real request body
# produced by trace_location_to_proto for both supported v4 location kinds.
# Source path: mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.search_traces ->
# mlflow.utils.databricks_tracing_utils.trace_location_to_proto.
def check_rest_store_search_traces_binds_trace_location_to_proto():
    store = _make_store()
    response = SearchTraces.Response()

    with _warehouse_env():
        with mock.patch.object(store, "_call_endpoint", return_value=response) as call:
            trace_infos, token = store.search_traces(locations=["123", "catalog.schema"])

    request_body = json.loads(call.call_args[0][1])
    assert len(request_body["locations"]) == 2
    assert request_body["locations"][0]["mlflow_experiment"]["experiment_id"] == "123"
    assert request_body["locations"][1]["uc_schema"]["catalog_name"] == "catalog"
    assert request_body["locations"][1]["uc_schema"]["schema_name"] == "schema"
    assert trace_infos == []
    assert token is None


# Contracts: C29 supplemental, R8, R19. Static issue: databricks_rest_store.py uses
# trace_location_to_proto at update_assessment call site line 558.
# Repo guidance: no dedicated repository test for this exact v4 update body, but the same
# task helper is exercised by search_traces tests; this check closes the remaining call site.
# Perspective: execute update_assessment with a mocked response and inspect the v4 request
# body built through trace_location_to_proto.
# Source path: mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.update_assessment ->
# mlflow.utils.databricks_tracing_utils.trace_location_to_proto.
def check_rest_store_update_assessment_binds_trace_location_to_proto():
    feedback = _make_feedback()
    response_proto = dbu.assessment_to_proto(feedback)
    response_proto.assessment_id = "assessment-1"

    store = _make_store()
    with _warehouse_env():
        with mock.patch.object(store, "_call_endpoint", return_value=response_proto) as call:
            result = store.update_assessment(
                trace_id="trace:/catalog.schema/tr-1",
                assessment_id="assessment-1",
                rationale="updated-rationale",
                metadata={"new-key": "new-value"},
            )

    request_body = json.loads(call.call_args[0][1])
    assert request_body["trace_id"] == "tr-1"
    assert request_body["assessment_id"] == "assessment-1"
    assert request_body["trace_location"]["uc_schema"]["catalog_name"] == "catalog"
    assert request_body["trace_location"]["uc_schema"]["schema_name"] == "schema"

    assert isinstance(result, Feedback)
    assert result.trace_id == "trace:/catalog.schema/tr-1"


# Contracts: C30, R13, R20. Repo guidance: tests/entities/test_assessment_source.py
# ::test_assessment_source_case_insensitivity.
# Perspective: execute AssessmentSource dataclass __post_init__ and observe the full
# AssessmentSourceType._standardize chain normalize a lowercase source_type.
# Source path: mlflow.entities.assessment_source.AssessmentSource.__post_init__ ->
# AssessmentSourceType._standardize -> AssessmentSourceType.__init__ -> _parse.
def check_assessment_source_construction_normalizes_source_type():
    source = AssessmentSource(source_type="llm_judge", source_id="gpt-4")
    assert source.source_type == "LLM_JUDGE"


if __name__ == "__main__":
    _run(
        [
            check_trace_info_to_proto_uc_caller_path_binds_v4_helper,
            check_trace_location_from_proto_caller_path_binds_helper,
            check_rest_store_create_assessment_binds_assessment_to_proto,
            check_rest_store_batch_get_traces_binds_trace_from_proto,
            check_rest_store_set_experiment_trace_location_binds_uc_schema_converters,
            check_rest_store_unset_experiment_trace_location_binds_uc_schema_to_proto,
            check_rest_store_search_traces_binds_trace_location_to_proto,
            check_rest_store_update_assessment_binds_trace_location_to_proto,
            check_assessment_source_construction_normalizes_source_type,
        ]
    )
