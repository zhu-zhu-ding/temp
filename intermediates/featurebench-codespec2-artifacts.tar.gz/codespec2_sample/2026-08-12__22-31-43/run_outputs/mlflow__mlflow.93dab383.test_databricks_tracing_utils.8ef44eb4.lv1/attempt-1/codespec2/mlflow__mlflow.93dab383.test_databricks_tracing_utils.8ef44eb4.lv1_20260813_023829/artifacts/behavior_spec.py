"""Executable behavior spec for MLflow tracing/assessment data management.

This file compiles the L3 verifiable contracts from semantic_ir.md into
no-argument runtime checks. It does not modify production code and does not
replace the IR. Each check has explicit C/R traceability comments.
"""

from __future__ import annotations

import json
import os
import sys
import traceback
import warnings
from unittest import mock

from google.protobuf.timestamp_pb2 import Timestamp
from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

from mlflow.entities import (
    AssessmentSource,
    AssessmentSourceType,
    Expectation,
    Feedback,
    Span,
    Trace,
    TraceData,
    TraceInfo,
    TraceLocation,
    TraceLocationType,
)
from mlflow.entities.trace_info_v2 import _truncate_request_metadata, _truncate_tags
from mlflow.entities.trace_location import InferenceTableLocation, MlflowExperimentLocation, UCSchemaLocation
from mlflow.entities.trace_state import TraceState
from mlflow.exceptions import MlflowException
from mlflow.protos import assessments_pb2
from mlflow.protos import databricks_tracing_pb2 as pb
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, ErrorCode
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue
from mlflow.utils import databricks_tracing_utils as dbu


def _make_uc_trace_info(**overrides):
    defaults = dict(
        trace_id="trace:/catalog.schema/tr-1",
        client_request_id="client-1",
        trace_location=TraceLocation.from_databricks_uc_schema("catalog", "schema"),
        request_time=123,
        execution_duration=456,
        state=TraceState.OK,
        request_preview="request-preview",
        response_preview="response-preview",
        trace_metadata={"meta-key": "meta-value"},
        tags={"tag-key": "tag-value"},
        assessments=[],
    )
    defaults.update(overrides)
    return TraceInfo(**defaults)


def _make_feedback():
    return Feedback(
        trace_id="trace:/catalog.schema/tr-1",
        name="assessment_name",
        value=True,
        source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
        create_time_ms=123,
        last_update_time_ms=456,
        rationale="because",
        metadata={"numeric": 1, "text": "value"},
        span_id="span-1",
        overrides="old-assessment",
        valid=False,
    )


def _make_otel_proto_span(name="span1", attributes=None):
    otel_span = OTelProtoSpan()
    otel_span.name = name
    otel_span.trace_id = bytes.fromhex("11" * 16)
    otel_span.span_id = bytes.fromhex("22" * 8)
    for key, value in (attributes or {}).items():
        attr = otel_span.attributes.add()
        attr.key = key
        _set_otel_proto_anyvalue(attr.value, value)
    return otel_span


def _run(checks):
    failures = []
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as exc:  # noqa: BLE001 - intentional test runner
            failures.append((check.__name__, exc))
            print(f"FAIL: {check.__name__}: {exc!r}")
            traceback.print_exc()
    if failures:
        print(f"BEHAVIOR SPEC FAILED: {len(failures)} check(s) failed")
        sys.exit(1)
    print("BEHAVIOR SPEC PASSED")


# Contracts: C1, R1. Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_create_assessment uses assessment_to_proto for a UC v4 assessment.
# Perspective: representation-preservation for every populated Assessment field.
# Source path: mlflow/utils/databricks_tracing_utils.assessment_to_proto.
def check_c1_assessment_to_proto_populates_all_fields():
    feedback = _make_feedback()
    proto = dbu.assessment_to_proto(feedback)

    assert proto.assessment_name == feedback.name
    assert proto.trace_id == "tr-1"
    assert proto.trace_location.uc_schema.catalog_name == "catalog"
    assert proto.trace_location.uc_schema.schema_name == "schema"
    assert proto.create_time.ToMilliseconds() == feedback.create_time_ms
    assert proto.last_update_time.ToMilliseconds() == feedback.last_update_time_ms
    assert proto.source == feedback.source.to_proto()
    assert proto.span_id == feedback.span_id
    assert proto.rationale == feedback.rationale
    assert proto.overrides == feedback.overrides
    assert proto.valid is False
    assert proto.WhichOneof("value") == "feedback"
    assert dict(proto.metadata) == {"numeric": "1", "text": "value"}

    # Optional assessment_id must survive the round-trip when present.
    feedback.assessment_id = "assessment-1"
    assert dbu.assessment_to_proto(feedback).assessment_id == "assessment-1"

    # The expectation branch is the only other legal value oneof.
    expectation = Expectation(
        trace_id="trace:/catalog.schema/tr-1",
        name="expectation_name",
        value={"x": 1},
        source=AssessmentSource(source_type="HUMAN", source_id="human-1"),
        create_time_ms=123,
        last_update_time_ms=456,
        metadata={"k": 1},
    )
    expectation_proto = dbu.assessment_to_proto(expectation)
    assert expectation_proto.WhichOneof("value") == "expectation"
    assert dict(expectation_proto.metadata) == {"k": "1"}


# Contracts: C2, R2. Repo guidance: mlflow/entities/assessment.py:Feedback.from_proto
# and Expectation.from_proto call get_trace_id_from_assessment_proto on v4 protos.
# Perspective: v4 UC trace IDs must be reconstructed as URI strings.
# Source path: mlflow/utils/databricks_tracing_utils.get_trace_id_from_assessment_proto.
def check_c2_get_trace_id_constructs_uc_v4():
    proto = pb.Assessment()
    proto.trace_id = "tr-1"
    proto.trace_location.CopyFrom(
        pb.TraceLocation(
            type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
            uc_schema=pb.UCSchemaLocation(catalog_name="catalog", schema_name="schema"),
        )
    )
    assert dbu.get_trace_id_from_assessment_proto(proto) == "trace:/catalog.schema/tr-1"


# Contracts: C3, R2. Repo guidance: no direct repository test for the v3 fallback;
# task Interface Description 1 documents accepting both pb.Assessment and
# assessments_pb2.Assessment.
# Perspective: compatibility with legacy assessment protos that lack trace_location.
# Source path: mlflow/utils/databricks_tracing_utils.get_trace_id_from_assessment_proto.
def check_c3_get_trace_id_returns_raw_v3():
    legacy = assessments_pb2.Assessment(trace_id="tr-v3")
    assert dbu.get_trace_id_from_assessment_proto(legacy) == "tr-v3"

    v4_without_location = pb.Assessment(trace_id="tr-raw")
    assert dbu.get_trace_id_from_assessment_proto(v4_without_location) == "tr-raw"


# Contracts: C4, R3. Repo guidance: no direct test; Interface Description 1 gives the
# exact mapping.
# Perspective: simple typed field mapping from entity to proto.
# Source path: mlflow/utils/databricks_tracing_utils.inference_table_location_to_proto.
def check_c4_inference_table_location_to_proto_maps_full_table_name():
    proto = dbu.inference_table_location_to_proto(InferenceTableLocation("a.b.c"))
    assert isinstance(proto, pb.InferenceTableLocation)
    assert proto.full_table_name == "a.b.c"


# Contracts: C5, R4. Repo guidance: no direct test; Interface Description 1 gives the
# exact mapping.
# Perspective: simple typed field mapping from entity to proto.
# Source path: mlflow/utils/databricks_tracing_utils.mlflow_experiment_location_to_proto.
def check_c5_mlflow_experiment_location_to_proto_maps_experiment_id():
    proto = dbu.mlflow_experiment_location_to_proto(MlflowExperimentLocation("123"))
    assert isinstance(proto, pb.MlflowExperimentLocation)
    assert proto.experiment_id == "123"


# Contracts: C6, R5. Repo guidance: mlflow/entities/trace.py:328-332 uses the same
# TraceInfo/TraceData/Span composition.
# Perspective: deserialization must compose the two protobuf parts without dropping spans.
# Source path: mlflow/utils/databricks_tracing_utils.trace_from_proto.
def check_c6_trace_from_proto_returns_trace_with_info_and_spans():
    request_time = Timestamp()
    request_time.FromMilliseconds(123)

    trace_info_proto = pb.TraceInfo(
        trace_id="tr-1",
        client_request_id="client-1",
        trace_location=pb.TraceLocation(
            type=pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=pb.MlflowExperimentLocation(experiment_id="123"),
        ),
        request_time=request_time,
        state=pb.TraceInfo.State.Value("OK"),
    )
    proto_trace = pb.Trace(trace_info=trace_info_proto)
    proto_trace.spans.append(_make_otel_proto_span("span1"))

    trace = dbu.trace_from_proto(proto_trace, "catalog.schema")

    assert trace.info == TraceInfo.from_proto(proto_trace.trace_info)
    assert len(trace.data.spans) == 1
    assert isinstance(trace.data.spans[0], Span)
    assert trace.data.spans[0].name == "span1"
    expected_span = Span.from_otel_proto(proto_trace.spans[0], "catalog.schema")
    assert trace.data.spans[0].trace_id == expected_span.trace_id


# Contracts: C7, R6. Repo guidance: tests/entities/test_trace_info.py::test_trace_info_v4
# asserts parsed trace_id, UC location, state, previews, client id, tags, and empty
# assessments.
# Perspective: exact v4 TraceInfo conversion with truncation and assessment delegation.
# Source path: mlflow/utils/databricks_tracing_utils.trace_info_to_v4_proto.
def check_c7_trace_info_to_v4_proto_converts_uc_fields():
    feedback = _make_feedback()
    trace_info = _make_uc_trace_info(assessments=[feedback])
    proto = dbu.trace_info_to_v4_proto(trace_info)

    assert proto.trace_id == "tr-1"
    assert proto.client_request_id == "client-1"
    assert proto.trace_location == dbu.trace_location_to_proto(trace_info.trace_location)
    assert proto.trace_location.uc_schema.catalog_name == "catalog"
    assert proto.trace_location.uc_schema.schema_name == "schema"
    assert proto.request_preview == "request-preview"
    assert proto.response_preview == "response-preview"
    assert proto.request_time.ToMilliseconds() == trace_info.request_time
    assert proto.execution_duration.ToMilliseconds() == trace_info.execution_duration
    assert proto.state == pb.TraceInfo.State.Value(trace_info.state)
    assert dict(proto.trace_metadata) == _truncate_request_metadata(trace_info.trace_metadata)
    assert dict(proto.tags) == _truncate_tags(trace_info.tags)
    assert list(proto.assessments) == [dbu.assessment_to_proto(feedback)]


# Contracts: C8, R6. Repo guidance: tests/entities/test_trace_info.py::test_trace_info_proto
# covers experiment-location TraceInfo round trips.
# Perspective: non-UC v4 conversion must not parse/rewrite the raw trace ID.
# Source path: mlflow/utils/databricks_tracing_utils.trace_info_to_v4_proto.
def check_c8_trace_info_to_v4_proto_preserves_non_uc_trace_id():
    trace_info = TraceInfo(
        trace_id="tr-raw",
        trace_location=TraceLocation.from_experiment_id("123"),
        request_time=123,
        state=TraceState.OK,
    )
    proto = dbu.trace_info_to_v4_proto(trace_info)
    assert proto.trace_id == "tr-raw"
    assert proto.trace_location.WhichOneof("identifier") == "mlflow_experiment"
    assert proto.trace_location.mlflow_experiment.experiment_id == "123"
    assert not proto.HasField("execution_duration")


# Contracts: C9, R7. Repo guidance: tests/entities/test_trace_location.py
# ::test_trace_location_from_v4_proto_mlflow_experiment.
# Perspective: oneof dispatch to MlflowExperimentLocation.from_proto.
# Source path: mlflow/utils/databricks_tracing_utils.trace_location_from_proto.
def check_c9_trace_location_from_proto_dispatches_mlflow_experiment():
    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=pb.MlflowExperimentLocation(experiment_id="1234"),
    )
    location = dbu.trace_location_from_proto(proto)
    assert location.type == TraceLocationType.MLFLOW_EXPERIMENT
    assert location.mlflow_experiment.experiment_id == "1234"


# Contracts: C10, R7. Repo guidance: tests/entities/test_trace_location.py
# ::test_trace_location_from_v4_proto_inference_table.
# Perspective: oneof dispatch to InferenceTableLocation.from_proto.
# Source path: mlflow/utils/databricks_tracing_utils.trace_location_from_proto.
def check_c10_trace_location_from_proto_dispatches_inference_table():
    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.INFERENCE_TABLE,
        inference_table=pb.InferenceTableLocation(full_table_name="c.s.t"),
    )
    location = dbu.trace_location_from_proto(proto)
    assert location.type == TraceLocationType.INFERENCE_TABLE
    assert location.inference_table.full_table_name == "c.s.t"


# Contracts: R7, E26 (UC-schema oneof branch not separately numbered in L3; complements
# C9/C10/C11). Repo guidance: tests/entities/test_trace_location.py exercises UC schema
# locations through TraceLocation.from_databricks_uc_schema round trips.
# Perspective: uc_schema oneof dispatch must construct a UCSchemaLocation entity.
# Source path: mlflow/utils/databricks_tracing_utils.trace_location_from_proto.
def check_r7_trace_location_from_proto_dispatches_uc_schema():
    proto = pb.TraceLocation(
        type=pb.TraceLocation.TraceLocationType.UC_SCHEMA,
        uc_schema=pb.UCSchemaLocation(catalog_name="catalog", schema_name="schema"),
    )
    location = dbu.trace_location_from_proto(proto)
    assert location.type == TraceLocationType.UC_SCHEMA
    assert location.uc_schema.catalog_name == "catalog"
    assert location.uc_schema.schema_name == "schema"


# Contracts: C11, R7. Repo guidance: Interface Description 1 documents unspecified
# fallback when no recognized identifier oneof is set.
# Perspective: fallback state must be an empty unspecified TraceLocation.
# Source path: mlflow/utils/databricks_tracing_utils.trace_location_from_proto.
def check_c11_trace_location_from_proto_falls_back_to_unspecified():
    proto = pb.TraceLocation(type=pb.TraceLocation.TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    location = dbu.trace_location_from_proto(proto)
    assert location.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED
    assert location.mlflow_experiment is None
    assert location.inference_table is None
    assert location.uc_schema is None


# Contracts: C12, R8. Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_search_traces_uc_schema verifies UC oneof JSON.
# Perspective: UC_SCHEMA dispatch must produce a uc_schema oneof.
# Source path: mlflow/utils/databricks_tracing_utils.trace_location_to_proto.
def check_c12_trace_location_to_proto_dispatches_uc_schema():
    proto = dbu.trace_location_to_proto(TraceLocation.from_databricks_uc_schema("catalog", "schema"))
    assert proto.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA
    assert proto.WhichOneof("identifier") == "uc_schema"
    assert proto.uc_schema.catalog_name == "catalog"
    assert proto.uc_schema.schema_name == "schema"


# Contracts: R8 (C12 covers UC; this check closes E30/E31 dispatch). Repo guidance:
# tests/entities/test_trace_location.py round-trips experiment and inference-table
# locations.
# Perspective: the dispatcher must produce the correct oneof for all three supported types.
# Source path: mlflow/utils/databricks_tracing_utils.trace_location_to_proto.
def check_r8_trace_location_to_proto_dispatches_experiment_and_inference_table():
    experiment = TraceLocation.from_experiment_id("123")
    proto = dbu.trace_location_to_proto(experiment)
    assert proto.type == pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    assert proto.WhichOneof("identifier") == "mlflow_experiment"
    assert proto.mlflow_experiment.experiment_id == "123"

    inference = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation("c.s.t"),
    )
    proto = dbu.trace_location_to_proto(inference)
    assert proto.type == pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    assert proto.WhichOneof("identifier") == "inference_table"
    assert proto.inference_table.full_table_name == "c.s.t"


# Contracts: C13, R8. Repo guidance: Interface Description 1 documents ValueError for
# unsupported types.
# Perspective: exact failure type and diagnostic mention the unsupported type.
# Source path: mlflow/utils/databricks_tracing_utils.trace_location_to_proto.
def check_c13_trace_location_to_proto_raises_for_unsupported_type():
    unsupported = TraceLocation(TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    try:
        dbu.trace_location_to_proto(unsupported)
    except ValueError as exc:
        assert "Unsupported trace location type" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unsupported trace location type")


# Contracts: C14, R9. Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_batch_get_traces builds response traces via trace_to_proto.
# Perspective: pb.Trace must be exactly the entity info.to_proto() plus span OTel protos.
# Source path: mlflow/utils/databricks_tracing_utils.trace_to_proto.
def check_c14_trace_to_proto_composes_info_and_span_protos():
    trace_info = _make_uc_trace_info()
    span = Span.from_otel_proto(_make_otel_proto_span("span1"), "catalog.schema")
    trace = Trace(info=trace_info, data=TraceData(spans=[span]))

    proto = dbu.trace_to_proto(trace)

    assert proto.trace_info == trace_info.to_proto()
    assert list(proto.spans) == [span.to_otel_proto()]


# Contracts: C15, R10. Repo guidance: tests/entities/test_trace_location.py
# ::test_uc_schema_location_full_otel_spans_table_name exercises private table names.
# Perspective: optional OTel table fields are copied only when present; defaults remain
# otherwise.
# Source path: mlflow/utils/databricks_tracing_utils.uc_schema_location_from_proto.
def check_c15_uc_schema_location_from_proto_preserves_optional_table_fields():
    proto = pb.UCSchemaLocation(
        catalog_name="catalog",
        schema_name="schema",
        otel_spans_table_name="custom_spans",
        otel_logs_table_name="custom_logs",
    )
    location = dbu.uc_schema_location_from_proto(proto)
    assert location.catalog_name == "catalog"
    assert location.schema_name == "schema"
    assert location._otel_spans_table_name == "custom_spans"
    assert location._otel_logs_table_name == "custom_logs"

    bare_proto = pb.UCSchemaLocation(catalog_name="catalog", schema_name="schema")
    bare_location = dbu.uc_schema_location_from_proto(bare_proto)
    assert bare_location._otel_spans_table_name == "mlflow_experiment_trace_otel_spans"
    assert bare_location._otel_logs_table_name == "mlflow_experiment_trace_otel_logs"


# Contracts: C16, R11. Repo guidance: tests/store/tracking/test_databricks_rest_store.py
# ::test_set_experiment_trace_location checks serialized UC table names.
# Perspective: serialization includes private OTel table-name attributes.
# Source path: mlflow/utils/databricks_tracing_utils.uc_schema_location_to_proto.
def check_c16_uc_schema_location_to_proto_copies_private_table_names():
    location = UCSchemaLocation(catalog_name="catalog", schema_name="schema")
    location._otel_spans_table_name = "spans"
    location._otel_logs_table_name = "logs"
    proto = dbu.uc_schema_location_to_proto(location)
    assert proto.catalog_name == "catalog"
    assert proto.schema_name == "schema"
    assert proto.otel_spans_table_name == "spans"
    assert proto.otel_logs_table_name == "logs"


# Contracts: C17, R12. Repo guidance: tests/entities/test_assessment_source.py relies on
# plain-string constants via AssessmentSource.
# Perspective: interface shape of constants and canonical source-type list.
# Source path: mlflow/entities/assessment_source.AssessmentSourceType.
def check_c17_assessment_source_type_constants_are_plain_strings():
    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.CODE == "CODE"
    assert AssessmentSourceType._SOURCE_TYPES == [
        "SOURCE_TYPE_UNSPECIFIED",
        "LLM_JUDGE",
        "HUMAN",
        "CODE",
    ]


# Contracts: C18, R14. Repo guidance: tests/entities/test_assessment_source.py
# ::test_assessment_source_case_insensitivity.
# Perspective: _parse uppercases valid input without changing canonical values.
# Source path: mlflow/entities/assessment_source.AssessmentSourceType._parse.
def check_c18_assessment_source_type_parse_normalizes_valid_input():
    for raw in ("human", "Human", "HUMAN"):
        assert AssessmentSourceType._parse(raw) == "HUMAN"
    for raw in ("llm_judge", "LLM_JUDGE"):
        assert AssessmentSourceType._parse(raw) == "LLM_JUDGE"
    assert AssessmentSourceType._parse("code") == "CODE"
    assert AssessmentSourceType._parse("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"


# Contracts: C19, R14. Repo guidance: tests/entities/test_assessment_source.py
# ::test_ai_judge_deprecation_warning.
# Perspective: deprecated AI_JUDGE emits FutureWarning and canonicalizes to LLM_JUDGE.
# Source path: mlflow/entities/assessment_source.AssessmentSourceType._parse.
def check_c19_assessment_source_type_parse_emits_ai_judge_deprecation_warning():
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = AssessmentSourceType._parse("AI_JUDGE")

    assert result == "LLM_JUDGE"
    assert any(
        issubclass(item.category, FutureWarning)
        and "AI_JUDGE is deprecated. Use LLM_JUDGE instead." in str(item.message)
        for item in caught
    )


# Contracts: C20, R14. Repo guidance: tests/entities/test_assessment_source.py
# ::test_assessment_source_type_validation.
# Perspective: invalid values raise MlflowException with INVALID_PARAMETER_VALUE and
# a message that names the invalid value and valid alternatives.
# Source path: mlflow/entities/assessment_source.AssessmentSourceType._parse.
def check_c20_assessment_source_type_parse_rejects_invalid_values():
    try:
        AssessmentSourceType._parse("ROBOT")
    except MlflowException as exc:
        assert exc.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)
        assert "Invalid assessment source type: ROBOT" in exc.message
        assert "Valid source types:" in exc.message
    else:
        raise AssertionError("Expected MlflowException for invalid assessment source type")


# Contracts: C21, R13. Repo guidance: Interface Description 2 notes explicitly require
# _standardize to instantiate and stringify an AssessmentSourceType.
# Perspective: public standardization entry returns canonical string form.
# Source path: mlflow/entities/assessment_source.AssessmentSourceType._standardize.
def check_c21_assessment_source_type_standardize_returns_str_instance():
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"

    # Directly observe the constructor + __str__ pair documented by the interface.
    instance = AssessmentSourceType("llm_judge")
    assert str(instance) == "LLM_JUDGE"
    assert instance._source_type == "LLM_JUDGE"


# Contracts: C22, R15. Repo guidance: tests/tracing/test_fluent.py asserts root_span.inputs
# == {"x": 1} for real spans.
# Perspective: property must deserialize the stored INPUTS attribute and return None when
# absent.
# Source path: mlflow/entities/span.Span.inputs.
def check_c22_span_inputs_returns_deserialized_input_attribute():
    span = Span.from_otel_proto(
        _make_otel_proto_span("span-with-inputs", {SpanAttributeKey.INPUTS: {"x": 1}}),
        "catalog.schema",
    )
    assert span.inputs == {"x": 1}

    span_without_inputs = Span.from_otel_proto(_make_otel_proto_span("span-no-inputs"))
    assert span_without_inputs.inputs is None


# Contracts: C23, R16. Repo guidance: tests/tracing/test_fluent.py asserts root_span.outputs
# == 11 for real spans.
# Perspective: property must deserialize the stored OUTPUTS attribute and return None when
# absent.
# Source path: mlflow/entities/span.Span.outputs.
def check_c23_span_outputs_returns_deserialized_output_attribute():
    span = Span.from_otel_proto(
        _make_otel_proto_span("span-with-outputs", {SpanAttributeKey.OUTPUTS: 11}),
        "catalog.schema",
    )
    assert span.outputs == 11

    span_without_outputs = Span.from_otel_proto(_make_otel_proto_span("span-no-outputs"))
    assert span_without_outputs.outputs is None


if __name__ == "__main__":
    _run(
        [
            check_c1_assessment_to_proto_populates_all_fields,
            check_c2_get_trace_id_constructs_uc_v4,
            check_c3_get_trace_id_returns_raw_v3,
            check_c4_inference_table_location_to_proto_maps_full_table_name,
            check_c5_mlflow_experiment_location_to_proto_maps_experiment_id,
            check_c6_trace_from_proto_returns_trace_with_info_and_spans,
            check_c7_trace_info_to_v4_proto_converts_uc_fields,
            check_c8_trace_info_to_v4_proto_preserves_non_uc_trace_id,
            check_c9_trace_location_from_proto_dispatches_mlflow_experiment,
            check_c10_trace_location_from_proto_dispatches_inference_table,
            check_c11_trace_location_from_proto_falls_back_to_unspecified,
            check_r7_trace_location_from_proto_dispatches_uc_schema,
            check_c12_trace_location_to_proto_dispatches_uc_schema,
            check_r8_trace_location_to_proto_dispatches_experiment_and_inference_table,
            check_c13_trace_location_to_proto_raises_for_unsupported_type,
            check_c14_trace_to_proto_composes_info_and_span_protos,
            check_c15_uc_schema_location_from_proto_preserves_optional_table_fields,
            check_c16_uc_schema_location_to_proto_copies_private_table_names,
            check_c17_assessment_source_type_constants_are_plain_strings,
            check_c18_assessment_source_type_parse_normalizes_valid_input,
            check_c19_assessment_source_type_parse_emits_ai_judge_deprecation_warning,
            check_c20_assessment_source_type_parse_rejects_invalid_values,
            check_c21_assessment_source_type_standardize_returns_str_instance,
            check_c22_span_inputs_returns_deserialized_input_attribute,
            check_c23_span_outputs_returns_deserialized_output_attribute,
        ]
    )
