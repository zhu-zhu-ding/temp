# Spec Review Report

## Evidence Reviewed

- Primary task document and Interface Descriptions 1-3 (provided in this review).
- Semantic IR: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_databricks_tracing_utils.8ef44eb4.lv1_20260813_023829/artifacts/semantic_ir.md`
- Architecture spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_databricks_tracing_utils.8ef44eb4.lv1_20260813_023829/artifacts/arch_spec.py`
- Behavior spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_databricks_tracing_utils.8ef44eb4.lv1_20260813_023829/artifacts/behavior_spec.py`
- Static issues: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_databricks_tracing_utils.8ef44eb4.lv1_20260813_023829/artifacts/static_issues.md`
- Static analysis: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_databricks_tracing_utils.8ef44eb4.lv1_20260813_023829/artifacts/static_analysis.md`
- Review skill: `/installed-agent/codespec2/review_skill.md`

Repository source inspected:

- `mlflow/utils/databricks_tracing_utils.py` (current import-only stub)
- `libs/tracing/mlflow/utils/databricks_tracing_utils.py` (reference implementation)
- `mlflow/entities/assessment_source.py` and `libs/tracing/mlflow/entities/assessment_source.py`
- `mlflow/entities/span.py` and `libs/tracing/mlflow/entities/span.py`
- `mlflow/entities/assessment.py`
- `mlflow/entities/trace_info.py`
- `mlflow/entities/trace_location.py`
- `mlflow/store/tracking/databricks_rest_store.py`
- `mlflow/exceptions.py`
- `mlflow/protos/databricks_tracing_pb2.py` and `mlflow/protos/databricks_pb2.py`

Repository tests inspected:

- `tests/entities/test_assessment_source.py`
- `tests/entities/test_trace_info.py`
- `tests/entities/test_trace_location.py`
- `tests/store/tracking/test_databricks_rest_store.py`
- `tests/tracing/test_fluent.py`

I did not run pytest or the generated specs. Static source and runtime import checks were performed with small Python inspection commands only.

## Rubric Scores

| Rubric | Score | Evidence | Affected R/E/C IDs |
|---|---:|---|---|
| Requirement coverage | FAIL | Every task-required converter has at least one spec check, but the `unset_experiment_trace_location` call site for `uc_schema_location_to_proto` (`databricks_rest_store.py:451`) is in IR R19 evidence and is not observed by either spec. The `trace_info_to_v4_proto` optional `execution_duration` absence branch is also not observed. | R6, R19, E24, E40, C28 |
| Requirement fidelity | FAIL | `check_c20` asserts `MlflowException.error_code == INVALID_PARAMETER_VALUE` (integer 1000), but `MlflowException.__init__` stores `ErrorCode.Name(error_code)` as a string. This assertion would fail against the correct repository-supported implementation. | R14, C20, E46 |
| Caller binding and architecture | FAIL | Most static-issue call sites are exercised through real callers (`TraceInfo.to_proto`, `TraceLocation.from_proto`, `create_assessment`, `batch_get_traces`, `search_traces`, `update_assessment`, `set_experiment_trace_location`). However, the sibling `unset_experiment_trace_location` caller for `uc_schema_location_to_proto` is not exercised, so one on-path caller path is missing. | R19, E40 |
| Dataflow and lifecycle | PASS | `assessment_to_proto`, `trace_from_proto`, `trace_info_to_v4_proto`, `trace_location_from_proto/to_proto`, `trace_to_proto`, `uc_schema_location_from_proto/to_proto`, `Span.inputs/outputs`, and `AssessmentSourceType` checks use exact field comparisons, oneof dispatch checks, round-trip comparisons, and both present/absent optional table-name branches. | R1, R3, R4, R5, R7, R8, R9, R10, R11, R13, R15, R16 |
| Failure and compatibility | FAIL | `check_c20` uses the wrong `error_code` representation. The `trace_info_to_v4_proto` duration-absence compatibility path is not asserted, so an always-set-duration implementation would pass the current spec. | R6, R14, C8, C20 |
| Static-issue closure strength | FAIL | `trace_info_to_v4_proto` and `trace_location_from_proto` are closed by executing their real entity callers. Four of the five `databricks_rest_store.py` symbols are closed through real store-method call paths. The fifth symbol, `uc_schema_location_to_proto`, has a third call site in `unset_experiment_trace_location` that is not covered by `set_experiment_trace_location`; a local import or correct wiring in only the tested method would pass the specs. | Static issues: `mlflow/store/tracking/databricks_rest_store.py`, R19, E40 |
| Chain integrity | PASS | No check reaches the observer while bypassing a delegation layer that holds an on-path static issue. The existing store-method checks execute the actual store methods rather than import-boundary assertions. | C24, C25, C26, C27, C28, C29 |
| Repository-test alignment | PASS | The specs adapt repository-test angles for UC v4 trace-info parsing (`test_trace_info_v4`), v4 trace-location oneof dispatch (`test_trace_location_from_v4_proto_*`), REST-store request/result bodies (`test_create_assessment`, `test_batch_get_traces`, `test_search_traces_uc_schema`, `test_search_traces_with_mixed_locations`, `test_set_experiment_trace_location`), and assessment-source validation (`test_assessment_source_type_validation`, `test_ai_judge_deprecation_warning`). | R1, R5, R7, R8, R10, R11, R14 |
| Oracle strength | FAIL | `check_c20` encodes an incorrect oracle for `error_code`. `check_c8` has only positive assertions for non-UC trace ID and location; it does not assert the protobuf `execution_duration` field is unset when the entity duration is `None`. | R6, R14, C8, C20 |

## Findings

### Finding 1 — `requirement_misread`

- **Affected IDs:** R14, C20, E46
- **Static issue:** None
- **Repository source/test evidence:**
  - `behavior_spec.py:38` imports `from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE` (integer `1000`).
  - `behavior_spec.py:485` asserts `exc.error_code == INVALID_PARAMETER_VALUE`.
  - `mlflow/exceptions.py:75-89` shows `MlflowException.__init__` sets `self.error_code = ErrorCode.Name(error_code)`, producing `"INVALID_PARAMETER_VALUE"` (a string), not `1000`.
  - `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` correctly avoids the numeric-vs-string trap by asserting only `pytest.raises(MlflowException, match="Invalid assessment source type")`.
- **Gap:** The spec misreads the repository-supported `MlflowException.error_code` representation. The check would fail for a correct `AssessmentSourceType._parse` implementation.
- **Rework instruction:** Change `check_c20` to assert `exc.error_code == "INVALID_PARAMETER_VALUE"` or `exc.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)` (with `ErrorCode` imported from `mlflow.protos.databricks_pb2`). Keep the message assertions.

### Finding 2 — `missing_requirement`

- **Affected IDs:** R19, E40, C28 (coverage gap)
- **Static issue:** `mlflow/store/tracking/databricks_rest_store.py` — `uc_schema_location_to_proto` is used but not defined or imported
- **Repository source/test evidence:**
  - `mlflow/store/tracking/databricks_rest_store.py:451` uses `uc_schema_location_to_proto(location)` inside `unset_experiment_trace_location`.
  - `semantic_ir.md` R19 evidence explicitly lists line 451 among the binding sites.
  - `tests/store/tracking/test_databricks_rest_store.py::test_unset_experiment_trace_location_with_uc_schema` verifies that method's serialized request body.
  - `arch_spec.py` only contains `check_rest_store_set_experiment_trace_location_binds_uc_schema_converters` for the `set_experiment_trace_location` path (lines 412/434), with no `unset_experiment_trace_location` check.
- **Gap:** The on-path `uc_schema_location_to_proto` call in `unset_experiment_trace_location` has no runtime observer. A solution that imports or otherwise binds the helper only inside `set_experiment_trace_location` (or leaves the unset body broken) would pass the generated specs while failing repository/hidden tests.
- **Rework instruction:** Add an architecture check that executes `store.unset_experiment_trace_location(experiment_id="123", location=UCSchemaLocation(...))` with `_call_endpoint` mocked, and assert the JSON request body contains `uc_schema.catalog_name` and `uc_schema.schema_name` produced by the real `uc_schema_location_to_proto` path.

### Finding 3 — `weak_constraint`

- **Affected IDs:** R6, C8, E24
- **Static issue:** None
- **Repository source/test evidence:**
  - Interface Description 1 for `trace_info_to_v4_proto` states: "Execution duration is only set in the protobuf if it's not None in the input."
  - Reference implementation `libs/tracing/mlflow/utils/databricks_tracing_utils.py:107-110` only constructs `Duration` and sets `execution_duration` when `trace_info.execution_duration is not None`.
  - `behavior_spec.py:256-266` (`check_c8_trace_info_to_v4_proto_preserves_non_uc_trace_id`) constructs a non-UC `TraceInfo` without `execution_duration` but asserts only `trace_id` and location.
  - `tests/entities/test_trace_info.py::test_trace_info_v4` relies on the absence of `execution_duration` for a duration-less v4 round-trip.
- **Gap:** The existing non-UC check cannot distinguish a correct implementation from one that always sets `execution_duration` (for example, always assigning a zero `Duration`). A plausible wrong implementation would pass the generated spec but violate the interface note.
- **Rework instruction:** In `check_c8`, add `assert not proto.HasField("execution_duration")`. Alternatively, add a dedicated check that constructs `TraceInfo` with `execution_duration=None`, calls `dbu.trace_info_to_v4_proto`, and verifies the field is unset, plus the positive counterpart when duration is present.

## Decision

Decision: REWORK
