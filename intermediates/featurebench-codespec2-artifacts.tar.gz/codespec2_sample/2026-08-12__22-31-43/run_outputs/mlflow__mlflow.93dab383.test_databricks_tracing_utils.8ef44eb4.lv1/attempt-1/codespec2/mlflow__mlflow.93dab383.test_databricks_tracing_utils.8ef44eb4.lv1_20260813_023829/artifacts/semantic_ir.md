# Semantic IR

IR = <R, G, C> for the MLflow tracing and assessment data-management task.
Primary oracle: task document + Interface Descriptions 1-3. Repository
evidence: `/testbed/mlflow`, especially
`mlflow/utils/databricks_tracing_utils.py` (currently an import-only stub),
`mlflow/entities/assessment_source.py`, `mlflow/entities/span.py`, the
corresponding complete implementations in
`libs/tracing/mlflow/utils/databricks_tracing_utils.py`,
`libs/tracing/mlflow/entities/assessment_source.py`, and
`libs/tracing/mlflow/entities/span.py`, the generated protobuf modules, and
existing repository tests under `tests/entities` and
`tests/store/tracking/test_databricks_rest_store.py`.

## L1. Requirement Obligations

### R1: assessment_to_proto serialization
- Type: Dataflow/Interface
- Statement: Implement `assessment_to_proto(assessment)` in
  `mlflow/utils/databricks_tracing_utils.py` to convert an MLflow `Assessment`
  entity into `mlflow.protos.databricks_tracing_pb2.Assessment`.
- Task Evidence: Interface Description 1 `assessment_to_proto` docstring.
- Acceptance: Returned proto contains name, parsed trace ID, UC trace location
  when the entity trace ID is v4, source, millisecond timestamps, optional
  span_id/rationale/assessment_id, exactly one of expectation/feedback,
  stringified metadata, and optional overrides/valid.
- Repository Evidence: Complete reference implementation at
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:144-184`; protobuf
  fields in `databricks_tracing_pb2.Assessment`; existing
  `Assessment.to_proto` in `mlflow/entities/assessment.py:115-148`.
- Uncertainty: None material.

### R2: get_trace_id_from_assessment_proto trace ID extraction
- Type: Dataflow/Compatibility
- Statement: Implement `get_trace_id_from_assessment_proto(proto)` to return a
  v4 trace ID for UC-schema proto assessments and the raw `trace_id` otherwise,
  accepting both `pb.Assessment` and `assessments_pb2.Assessment`.
- Task Evidence: Interface Description 1 `get_trace_id_from_assessment_proto`
  docstring.
- Acceptance: UC schema path returns
  `construct_trace_id_v4(f"{catalog}.{schema}", proto.trace_id)`; non-UC or v3
  assessment path returns `proto.trace_id`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:187-200`; caller sites
  `mlflow/entities/assessment.py:288` and `:426`; `assessments_pb2.Assessment`
  has no `trace_location` field.
- Uncertainty: None material.

### R3: inference_table_location_to_proto mapping
- Type: Dataflow/Interface
- Statement: Implement `inference_table_location_to_proto` to map
  `InferenceTableLocation.full_table_name` to
  `pb.InferenceTableLocation.full_table_name`.
- Task Evidence: Interface Description 1 docstring.
- Acceptance: Returned proto's `full_table_name` equals the entity attribute.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:44-47`; field
  definition in `databricks_tracing_pb2.InferenceTableLocation`.
- Uncertainty: None.

### R4: mlflow_experiment_location_to_proto mapping
- Type: Dataflow/Interface
- Statement: Implement `mlflow_experiment_location_to_proto` to map
  `MlflowExperimentLocation.experiment_id` to
  `pb.MlflowExperimentLocation.experiment_id`.
- Task Evidence: Interface Description 1 docstring.
- Acceptance: Returned proto's `experiment_id` equals the entity attribute.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:50-53`; field
  definition in `databricks_tracing_pb2.MlflowExperimentLocation`.
- Uncertainty: None.

### R5: trace_from_proto deserialization
- Type: Dataflow/Interface
- Statement: Implement `trace_from_proto(proto, location_id)` to construct an
  MLflow `Trace` from a v4 `pb.Trace`, using `TraceInfo.from_proto` and
  `Span.from_otel_proto`.
- Task Evidence: Interface Description 1 `trace_from_proto` docstring.
- Acceptance: Returned `Trace.info` is the `TraceInfo` produced by
  `TraceInfo.from_proto(proto.trace_info)` and `Trace.data.spans` has one
  `Span` per `proto.spans` produced by `Span.from_otel_proto(span, location_id)`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:137-141`;
  `mlflow/entities/trace.py:328-332` shows the same composition pattern.
- Uncertainty: None material.

### R6: trace_info_to_v4_proto conversion
- Type: Dataflow/Interface
- Statement: Implement `trace_info_to_v4_proto(trace_info)` to create a v4
  `pb.TraceInfo` with parsed trace IDs for UC schema locations, timestamps,
  duration, location, previews, state, truncated metadata/tags, and converted
  assessments.
- Task Evidence: Interface Description 1 `trace_info_to_v4_proto` docstring.
- Acceptance: UC trace ID is parsed with `parse_trace_id_v4`; non-UC uses
  `trace_info.trace_id`; `request_time` and optional `execution_duration` are
  converted from milliseconds; `trace_metadata` and `tags` are passed through
  `_truncate_request_metadata`/`_truncate_tags`; assessments are converted via
  `assessment_to_proto`; `state` uses `pb.TraceInfo.State.Value`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:102-127`;
  `tests/entities/test_trace_info.py:128-175`.
- Uncertainty: None material.

### R7: trace_location_from_proto deserialization
- Type: Dataflow/Interface
- Statement: Implement `trace_location_from_proto(proto)` to convert a v4
  `pb.TraceLocation` into `TraceLocation` using the `identifier` oneof.
- Task Evidence: Interface Description 1 `trace_location_from_proto` docstring.
- Acceptance: `uc_schema` oneof returns `TraceLocation` with UC schema; 
  `mlflow_experiment` oneof delegates to `MlflowExperimentLocation.from_proto`;
  `inference_table` oneof delegates to `InferenceTableLocation.from_proto`;
  otherwise returns `TraceLocation(TRACE_LOCATION_TYPE_UNSPECIFIED)`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:80-99`;
  `tests/entities/test_trace_location.py:70-89`.
- Uncertainty: None material.

### R8: trace_location_to_proto serialization and failure
- Type: Dataflow/Interface/Failure
- Statement: Implement `trace_location_to_proto(trace_location)` to dispatch on
  `TraceLocationType` and raise `ValueError` for unsupported types.
- Task Evidence: Interface Description 1 `trace_location_to_proto` docstring.
- Acceptance: UC_SCHEMA, MLFLOW_EXPERIMENT, and INFERENCE_TABLE produce
  corresponding `pb.TraceLocation` messages with correct oneof; unsupported
  types raise `ValueError`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:56-77`.
- Uncertainty: None material.

### R9: trace_to_proto serialization
- Type: Dataflow/Interface
- Statement: Implement `trace_to_proto(trace)` to construct a `pb.Trace`
  containing `trace.info.to_proto()` and every span converted to OTel protobuf.
- Task Evidence: Interface Description 1 `trace_to_proto` docstring.
- Acceptance: Returned `pb.Trace.trace_info` equals `trace.info.to_proto()` and
  `spans` equals `[span.to_otel_proto() for span in trace.data.spans]`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:130-134`;
  `mlflow/entities/trace.py:317-325`.
- Uncertainty: None material.

### R10: uc_schema_location_from_proto deserialization
- Type: Dataflow/Interface
- Statement: Implement `uc_schema_location_from_proto(proto)` to produce a
  `UCSchemaLocation` and set optional OTel table names only when `HasField` is
  true.
- Task Evidence: Interface Description 1 `uc_schema_location_from_proto`
  docstring.
- Acceptance: Catalog and schema names are copied; optional
  `otel_spans_table_name`/`otel_logs_table_name` are written to private
  attributes only if present.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:34-41`; entity default
  private attributes in `mlflow/entities/trace_location.py:84-86`.
- Uncertainty: None material.

### R11: uc_schema_location_to_proto serialization
- Type: Dataflow/Interface
- Statement: Implement `uc_schema_location_to_proto(uc_schema_location)` to map
  catalog, schema, and private OTel table names into `pb.UCSchemaLocation`.
- Task Evidence: Interface Description 1 `uc_schema_location_to_proto`
  docstring.
- Acceptance: Returned proto has `catalog_name`, `schema_name`,
  `otel_spans_table_name`, and `otel_logs_table_name` populated from entity
  attributes including private ones.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:25-31`.
- Uncertainty: None material.

### R12: AssessmentSourceType constant shape
- Type: Interface/Compatibility
- Statement: In `mlflow/entities/assessment_source.py`, define
  `AssessmentSourceType` class constants as simple uppercase strings and
  `_SOURCE_TYPES` as `[SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]`.
- Task Evidence: Interface Description 2 notes.
- Acceptance: `SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `AI_JUDGE`, `HUMAN`,
  `CODE` are plain strings; `_SOURCE_TYPES` excludes deprecated `AI_JUDGE`.
- Repository Evidence: Current
  `mlflow/entities/assessment_source.py:148-156` already has these constants.
- Uncertainty: None.

### R13: AssessmentSourceType instance construction and standardization
- Type: Interface/State
- Statement: Implement `AssessmentSourceType.__init__(source_type)`,
  `__str__`, and static `_standardize(source_type)` so string input is parsed
  once, stored, and returned by `_standardize` as `str(AssessmentSourceType(source_type))`.
- Task Evidence: Interface Description 2 `_standardize` notes and examples.
- Acceptance: `_standardize` creates an instance and returns its string form;
  `__str__` returns the stored parsed value.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/entities/assessment_source.py:158-160,179-187`.
- Uncertainty: None material.

### R14: AssessmentSourceType parsing validation and AI_JUDGE deprecation
- Type: Failure/Compatibility/State
- Statement: Implement static `_parse(source_type)` to uppercase input, map
  `AI_JUDGE` to `LLM_JUDGE` with `FutureWarning`, validate against
  `_SOURCE_TYPES`, and raise `MlflowException` with
  `INVALID_PARAMETER_VALUE` for invalid values.
- Task Evidence: Interface Description 2 `_parse` notes; task statement's
  backward-compatibility challenge.
- Acceptance: Case-insensitive valid values normalize to uppercase;
  `AI_JUDGE` emits `FutureWarning` and returns `LLM_JUDGE`; invalid values
  raise `MlflowException` with `INVALID_PARAMETER_VALUE` and a message listing
  valid types.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/entities/assessment_source.py:162-177`;
  `tests/entities/test_assessment_source.py:39-75`.
- Uncertainty: None material.

### R15: Span.inputs property
- Type: Interface/Dataflow
- Statement: In `mlflow/entities/span.py`, implement `Span.inputs` as a
  read-only property returning the deserialized
  `SpanAttributeKey.INPUTS` attribute, or `None` if absent.
- Task Evidence: Interface Description 3 `Span.inputs` docstring.
- Acceptance: Property returns `self.get_attribute(SpanAttributeKey.INPUTS)`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/entities/span.py:158-160`; existing attribute registry
  serialization in `mlflow/entities/span.py:854-889`.
- Uncertainty: None material.

### R16: Span.outputs property
- Type: Interface/Dataflow
- Statement: In `mlflow/entities/span.py`, implement `Span.outputs` as a
  read-only property returning the deserialized
  `SpanAttributeKey.OUTPUTS` attribute, or `None` if absent.
- Task Evidence: Interface Description 3 `Span.outputs` docstring.
- Acceptance: Property returns `self.get_attribute(SpanAttributeKey.OUTPUTS)`.
- Repository Evidence: Reference implementation
  `libs/tracing/mlflow/entities/span.py:163-165`; tests in
  `tests/tracing/test_fluent.py` and `tests/tracing/opentelemetry/test_integration.py`.
- Uncertainty: None material.

### R17: TraceInfo.to_proto binds trace_info_to_v4_proto
- Type: Compatibility/Interface
- Statement: Ensure `TraceInfo.to_proto()` calls the task-required
  `trace_info_to_v4_proto` when `TraceInfo._is_v4()` is true.
- Task Evidence: Static issue in `mlflow/entities/trace_info.py`; repository
  test `tests/entities/test_trace_info.py::test_trace_info_v4`.
- Acceptance: Calling `trace_info.to_proto()` on a UC-schema `TraceInfo`
  reaches `trace_info_to_v4_proto` and returns a v4 `pb.TraceInfo`.
- Repository Evidence: `mlflow/entities/trace_info.py:97-103`; desired import
  location is in the task-required implementation module; complete reference
  exists in `libs/tracing/mlflow/utils/databricks_tracing_utils.py`.
- Uncertainty: The import must be made without introducing a top-level circular
  import; the reference solution imports inside `to_proto`.

### R18: TraceLocation.from_proto binds trace_location_from_proto
- Type: Compatibility/Interface
- Statement: Ensure `TraceLocation.from_proto()` calls the task-required
  `trace_location_from_proto`.
- Task Evidence: Static issue in `mlflow/entities/trace_location.py`;
  repository tests `tests/entities/test_trace_location.py`.
- Acceptance: Calling `TraceLocation.from_proto(proto)` reaches
  `trace_location_from_proto(proto)` and returns the corresponding
  `TraceLocation`.
- Repository Evidence: `mlflow/entities/trace_location.py:244-246`; complete
  reference in `libs/tracing/mlflow/utils/databricks_tracing_utils.py:80-99`.
- Uncertainty: Import must be local to `from_proto` to avoid an import cycle.

### R19: DatabricksTracingRestStore binds databricks conversion helpers
- Type: Compatibility/Dependency
- Statement: Ensure `mlflow/store/tracking/databricks_rest_store.py` imports
  and invokes `assessment_to_proto`, `trace_from_proto`,
  `trace_location_to_proto`, `uc_schema_location_from_proto`, and
  `uc_schema_location_to_proto` at their existing call sites.
- Task Evidence: Static issues in `mlflow/store/tracking/databricks_rest_store.py`.
- Acceptance: The five symbols are resolvable from
  `mlflow.utils.databricks_tracing_utils` and the store methods execute those
  call sites at runtime.
- Repository Evidence: `mlflow/store/tracking/databricks_rest_store.py:189,290,294,412,422,434,451,511,558`;
  reference import block in
  `libs/tracing/mlflow/store/tracking/databricks_rest_store.py:46-52`.
- Uncertainty: Exact import form is a local import or module import; runtime
  tests must exercise store methods, not only inspect import statements.

### R20: AssessmentSource post-init normalization
- Type: Compatibility/State
- Statement: Preserve `AssessmentSource.__post_init__` calling
  `AssessmentSourceType._standardize(self.source_type)` so existing entity
  construction normalizes source types.
- Task Evidence: Interface Description 2 examples; existing tests.
- Acceptance: Constructing `AssessmentSource` with string source types produces
  normalized `source_type`.
- Repository Evidence: `mlflow/entities/assessment_source.py:65-67`;
  `tests/entities/test_assessment_source.py`.
- Uncertainty: None.

## L2. Functional Design Graph

### N1: mlflow.utils.databricks_tracing_utils module
- Kind: Public entry/import boundary
- Repository Evidence: Interface Description 1 path; current stub
  `mlflow/utils/databricks_tracing_utils.py`; reference in `libs/tracing`.

### N2: assessment_to_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:144-184`.

### N3: get_trace_id_from_assessment_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:187-200`.

### N4: inference_table_location_to_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:44-47`.

### N5: mlflow_experiment_location_to_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:50-53`.

### N6: trace_from_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:137-141`.

### N7: trace_info_to_v4_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:102-127`.

### N8: trace_location_from_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:80-99`.

### N9: trace_location_to_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:56-77`.

### N10: trace_to_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:130-134`.

### N11: uc_schema_location_from_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:34-41`.

### N12: uc_schema_location_to_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:25-31`.

### N13: trace_location_type_from_proto
- Kind: Function/helper
- Repository Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:74-76`.

### N14: parse_trace_id_v4
- Kind: External helper
- Repository Evidence: `mlflow/tracing/utils/__init__.py:631-647`.

### N15: construct_trace_id_v4
- Kind: External helper
- Repository Evidence: `mlflow/tracing/utils/__init__.py:649-653`.

### N16: _truncate_request_metadata
- Kind: External helper
- Repository Evidence: `mlflow/entities/trace_info_v2.py:14-20`.

### N17: _truncate_tags
- Kind: External helper
- Repository Evidence: `mlflow/entities/trace_info_v2.py:23-31`.

### N18: TraceInfo.to_proto
- Kind: Caller/public compatibility method
- Repository Evidence: `mlflow/entities/trace_info.py:96-125`.

### N19: TraceLocation.from_proto
- Kind: Caller/public compatibility method
- Repository Evidence: `mlflow/entities/trace_location.py:244-246`.

### N20: DatabricksTracingRestStore
- Kind: Caller/public service class
- Repository Evidence: `mlflow/store/tracking/databricks_rest_store.py:72-612`.

### N21: AssessmentSourceType
- Kind: Class/validator
- Repository Evidence: `mlflow/entities/assessment_source.py:102-190`.

### N22: AssessmentSource.__post_init__
- Kind: Caller/state transition
- Repository Evidence: `mlflow/entities/assessment_source.py:65-67`.

### N23: Feedback.from_proto and Expectation.from_proto
- Kind: Callers
- Repository Evidence: `mlflow/entities/assessment.py:286-308` and `:424-442`.

### N24: Span
- Kind: Class/public entity
- Repository Evidence: `mlflow/entities/span.py:88-453`.

### N25: Span.get_attribute
- Kind: Method
- Repository Evidence: `mlflow/entities/span.py:215-225`.

### N26: _SpanAttributesRegistry / _CachedSpanAttributesRegistry
- Kind: State/attribute serialization
- Repository Evidence: `mlflow/entities/span.py:854-908`.

### N27: Span.from_otel_proto
- Kind: Method/helper
- Repository Evidence: `mlflow/entities/span.py:365-420`.

### N28: TraceData
- Kind: Entity/container
- Repository Evidence: `mlflow/entities/trace_data.py:9-29`.

### N29: TraceInfo.from_proto
- Kind: Method/helper
- Repository Evidence: `mlflow/entities/trace_info.py:126-163`.

### N30: Trace
- Kind: Entity
- Repository Evidence: `mlflow/entities/trace.py:20-33`.

### N31: Protocol buffer message constructors
- Kind: External/data target
- Repository Evidence: `mlflow/protos/databricks_tracing_pb2.py`,
  `mlflow/protos/assessments_pb2.py`, generated field descriptors.

### N32: Span.to_otel_proto
- Kind: Method/helper
- Repository Evidence: `mlflow/entities/span.py:422-453`.

### E1: N1 -> N2
- Kind: CALL
- Condition: Public import/call of `assessment_to_proto`.
- Transfer: Assessment entity to proto.
- Evidence: Interface Description 1 and reference module.
- Obligations: R1.

### E2: N1 -> N3
- Kind: CALL
- Condition: Public import/call.
- Transfer: assessment proto to string trace ID.
- Evidence: Interface Description 1; `mlflow/entities/assessment.py` local imports.
- Obligations: R2.

### E3: N1 -> N4
- Kind: CALL
- Condition: Public import/call.
- Transfer: InferenceTableLocation to proto.
- Evidence: Interface Description 1.
- Obligations: R3.

### E4: N1 -> N5
- Kind: CALL
- Condition: Public import/call.
- Transfer: MlflowExperimentLocation to proto.
- Evidence: Interface Description 1.
- Obligations: R4.

### E5: N1 -> N6
- Kind: CALL
- Condition: Public import/call.
- Transfer: pb.Trace + location_id to Trace.
- Evidence: Interface Description 1.
- Obligations: R5.

### E6: N1 -> N7
- Kind: CALL
- Condition: Public import/call.
- Transfer: TraceInfo to v4 pb.TraceInfo.
- Evidence: Interface Description 1.
- Obligations: R6.

### E7: N1 -> N8
- Kind: CALL
- Condition: Public import/call.
- Transfer: pb.TraceLocation to TraceLocation.
- Evidence: Interface Description 1.
- Obligations: R7.

### E8: N1 -> N9
- Kind: CALL
- Condition: Public import/call.
- Transfer: TraceLocation to pb.TraceLocation.
- Evidence: Interface Description 1.
- Obligations: R8.

### E9: N1 -> N10
- Kind: CALL
- Condition: Public import/call.
- Transfer: Trace to pb.Trace.
- Evidence: Interface Description 1.
- Obligations: R9.

### E10: N1 -> N11
- Kind: CALL
- Condition: Public import/call.
- Transfer: pb.UCSchemaLocation to UCSchemaLocation.
- Evidence: Interface Description 1.
- Obligations: R10.

### E11: N1 -> N12
- Kind: CALL
- Condition: Public import/call.
- Transfer: UCSchemaLocation to pb.UCSchemaLocation.
- Evidence: Interface Description 1.
- Obligations: R11.

### E12: N2 -> N14
- Kind: CALL
- Condition: Always called on assessment.trace_id.
- Transfer: entity trace ID to `(location, trace_id)`.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:148-155`.
- Obligations: R1.

### E13: N2 -> N31
- Kind: DATA
- Condition: Constructing/populating `pb.Assessment`.
- Transfer: assessment name, timestamps, source, optional fields, metadata.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:145-184`.
- Obligations: R1.

### E14: N3 -> N15
- Kind: CALL
- Condition: proto has `trace_location` field and `trace_location.uc_schema` is set.
- Transfer: catalog.schema + raw trace ID to v4 trace ID.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:190-198`.
- Obligations: R2.

### E15: N6 -> N29
- Kind: CALL
- Condition: Always on `proto.trace_info`.
- Transfer: pb.TraceInfo to TraceInfo.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:138-139`.
- Obligations: R5.

### E16: N6 -> N27
- Kind: CALL
- Condition: For every span in `proto.spans`.
- Transfer: OTel proto span + location_id to Span.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:140`.
- Obligations: R5.

### E17: N6 -> N28
- Kind: CALL
- Condition: Wrapping converted spans.
- Transfer: list of Span to TraceData.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:139-140`.
- Obligations: R5.

### E18: N6 -> N30
- Kind: CALL
- Condition: Constructing returned Trace.
- Transfer: TraceInfo + TraceData to Trace.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:138-140`.
- Obligations: R5.

### E19: N7 -> N14
- Kind: CALL
- Condition: `trace_info.trace_location.uc_schema` is truthy.
- Transfer: v4 trace ID to raw trace ID.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:113-116`.
- Obligations: R6.

### E20: N7 -> N9
- Kind: CALL
- Condition: Always on `trace_info.trace_location`.
- Transfer: TraceLocation to pb.TraceLocation.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:119`.
- Obligations: R6.

### E21: N7 -> N16
- Kind: CALL
- Condition: Always for trace_metadata.
- Transfer: dict to truncated string-key/value dict.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:125`.
- Obligations: R6.

### E22: N7 -> N17
- Kind: CALL
- Condition: Always for tags.
- Transfer: dict to truncated string-key/value dict.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:126`.
- Obligations: R6.

### E23: N7 -> N2
- Kind: CALL
- Condition: For every assessment in `trace_info.assessments`.
- Transfer: Assessment to pb.Assessment.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:127`.
- Obligations: R6.

### E24: N7 -> N31
- Kind: DATA
- Condition: Constructing v4 `pb.TraceInfo`.
- Transfer: fields, timestamps, duration, state.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:102-127`.
- Obligations: R6.

### E25: N8 -> N13
- Kind: CALL
- Condition: Always on `proto.type`.
- Transfer: proto enum int to TraceLocationType.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:81`.
- Obligations: R7.

### E26: N8 -> N11
- Kind: CALL
- Condition: `WhichOneof("identifier") == "uc_schema"`.
- Transfer: pb.UCSchemaLocation to UCSchemaLocation.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:83-87`.
- Obligations: R7.

### E27: N8 -> entity location `from_proto` methods
- Kind: CALL
- Condition: `mlflow_experiment` or `inference_table` oneof is set.
- Transfer: pb location to entity location.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:88-95`.
- Obligations: R7.

### E28: N8 -> fallback TraceLocation
- Kind: CONTROL
- Condition: No recognized identifier oneof.
- Transfer: returns `TraceLocation(TRACE_LOCATION_TYPE_UNSPECIFIED)`.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:96-97`.
- Obligations: R7.

### E29: N9 -> N12
- Kind: CALL
- Condition: `type == UC_SCHEMA`.
- Transfer: UCSchemaLocation to pb.UCSchemaLocation.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:57-61`.
- Obligations: R8.

### E30: N9 -> N5
- Kind: CALL
- Condition: `type == MLFLOW_EXPERIMENT`.
- Transfer: MlflowExperimentLocation to proto.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:62-66`.
- Obligations: R8.

### E31: N9 -> N4
- Kind: CALL
- Condition: `type == INFERENCE_TABLE`.
- Transfer: InferenceTableLocation to proto.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:67-71`.
- Obligations: R8.

### E32: N9 -> ValueError
- Kind: CONTROL
- Condition: Unsupported `trace_location.type`.
- Transfer: raises `ValueError`.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:72-73`.
- Obligations: R8.

### E33: N10 -> N18
- Kind: CALL
- Condition: Always on `trace.info`.
- Transfer: TraceInfo to proto.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:131-132`.
- Obligations: R9.

### E34: N10 -> N32
- Kind: CALL
- Condition: For every span in `trace.data.spans`.
- Transfer: Span to OTel proto span.
- Evidence: `libs/tracing/mlflow/utils/databricks_tracing_utils.py:133`.
- Obligations: R9.

### E35: N18 -> N7
- Kind: CALL
- Condition: `TraceInfo._is_v4()` is true.
- Transfer: `self` TraceInfo to v4 proto.
- Evidence: `mlflow/entities/trace_info.py:97-103`; static issue closure.
- Obligations: R6, R17.

### E36: N19 -> N8
- Kind: CALL
- Condition: Always from `TraceLocation.from_proto`.
- Transfer: proto to `trace_location_from_proto`.
- Evidence: `mlflow/entities/trace_location.py:244-246`; static issue closure.
- Obligations: R7, R18.

### E37: N20 -> N2
- Kind: CALL
- Condition: `DatabricksTracingRestStore.create_assessment` with UC v4 trace ID.
- Transfer: Assessment to pb.Assessment for request body.
- Evidence: `mlflow/store/tracking/databricks_rest_store.py:509-521`; static issue closure.
- Obligations: R1, R19.

### E38: N20 -> N6
- Kind: CALL
- Condition: `DatabricksTracingRestStore.batch_get_traces`.
- Transfer: response pb.Trace and location to Trace.
- Evidence: `mlflow/store/tracking/databricks_rest_store.py:165-189`; static issue closure.
- Obligations: R5, R19.

### E39: N20 -> N9
- Kind: CALL
- Condition: `search_traces` and `update_assessment` v4 paths.
- Transfer: TraceLocation to pb.TraceLocation.
- Evidence: `mlflow/store/tracking/databricks_rest_store.py:284-297,552-559`; static issue closure.
- Obligations: R8, R19.

### E40: N20 -> N12
- Kind: CALL
- Condition: `set_experiment_trace_location` and link/unlink paths.
- Transfer: UCSchemaLocation to proto.
- Evidence: `mlflow/store/tracking/databricks_rest_store.py:410-434,449-451`; static issue closure.
- Obligations: R11, R19.

### E41: N20 -> N11
- Kind: CALL
- Condition: `set_experiment_trace_location` response conversion.
- Transfer: pb.UCSchemaLocation to UCSchemaLocation.
- Evidence: `mlflow/store/tracking/databricks_rest_store.py:417-422`; static issue closure.
- Obligations: R10, R19.

### E42: N22 -> N21._standardize
- Kind: CALL
- Condition: Always in `AssessmentSource.__post_init__`.
- Transfer: raw source_type string to standardized string.
- Evidence: `mlflow/entities/assessment_source.py:65-67`.
- Obligations: R13, R14, R20.

### E43: N21._standardize -> N21.__init__
- Kind: CALL
- Condition: Always.
- Transfer: source_type string to instance.
- Evidence: reference `libs/tracing/mlflow/entities/assessment_source.py:186-187`.
- Obligations: R13.

### E44: N21.__init__ -> N21._parse
- Kind: CALL
- Condition: Always.
- Transfer: raw source_type to parsed `_source_type`.
- Evidence: reference `libs/tracing/mlflow/entities/assessment_source.py:159-160`.
- Obligations: R13, R14.

### E45: N21._parse -> FutureWarning
- Kind: CONTROL/SIDE_EFFECT
- Condition: uppercase input equals `AI_JUDGE`.
- Transfer: warning emitted, result becomes `LLM_JUDGE`.
- Evidence: reference `libs/tracing/mlflow/entities/assessment_source.py:166-171`.
- Obligations: R14.

### E46: N21._parse -> MlflowException
- Kind: CONTROL
- Condition: uppercase input not in `_SOURCE_TYPES`.
- Transfer: raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- Evidence: reference `libs/tracing/mlflow/entities/assessment_source.py:173-177`.
- Obligations: R14.

### E47: N23 -> N3
- Kind: CALL
- Condition: `Feedback.from_proto` and `Expectation.from_proto`.
- Transfer: assessment proto to trace ID string.
- Evidence: `mlflow/entities/assessment.py:288,294,426,432`.
- Obligations: R2.

### E48: N24.inputs -> N25
- Kind: CALL
- Condition: Property access.
- Transfer: `SpanAttributeKey.INPUTS` key.
- Evidence: reference `libs/tracing/mlflow/entities/span.py:158-160`.
- Obligations: R15.

### E49: N24.outputs -> N25
- Kind: CALL
- Condition: Property access.
- Transfer: `SpanAttributeKey.OUTPUTS` key.
- Evidence: reference `libs/tracing/mlflow/entities/span.py:163-165`.
- Obligations: R16.

### E50: N25 -> N26
- Kind: CALL
- Condition: `get_attribute` on immutable Span.
- Transfer: attribute key to cached registry.
- Evidence: `mlflow/entities/span.py:215-225` and `:892-903`.
- Obligations: R15, R16.

### E51: N26 -> json.loads
- Kind: CALL
- Condition: Stored OTel attribute value is non-empty.
- Transfer: serialized JSON string to Python value.
- Evidence: `mlflow/entities/span.py:871-879`.
- Obligations: R15, R16.

## L3. Verifiable Contracts

### C1: assessment_to_proto returns a fully populated pb.Assessment
- Type: Dataflow conversion
- Subject: `assessment_to_proto(assessment)`
- Relation: Returned `pb.Assessment` fields match the source entity.
- Expected: For a UC v4 assessment with trace ID
  `"trace:/catalog.schema/tr-1"`, the return has `assessment_name ==
  assessment.name`, `trace_id == "tr-1"`,
  `trace_location.uc_schema.catalog_name == "catalog"`,
  `trace_location.uc_schema.schema_name == "schema"`,
  `create_time.ToMilliseconds() == assessment.create_time_ms`,
  `last_update_time.ToMilliseconds() == assessment.last_update_time_ms`,
  source equal to `assessment.source.to_proto()`, exactly one of
  expectation/feedback set according to the entity, metadata values converted
  to strings, and optional `span_id`, `rationale`, `assessment_id`,
  `overrides`, `valid` set when present.
- Evidence: Interface Description 1; reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:144-184`.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- Obligations: R1
- Graph: E1, E12, E13.

### C2: get_trace_id_from_assessment_proto constructs UC v4 trace ID
- Type: Dataflow compatibility
- Subject: `get_trace_id_from_assessment_proto(pb.Assessment(...))`
- Relation: Return equals v4 URI.
- Expected: For `pb.Assessment(trace_id="tr-1", trace_location=TraceLocation(
  type=UC_SCHEMA, uc_schema=UCSchemaLocation(catalog_name="catalog",
  schema_name="schema")))`, return `"trace:/catalog.schema/tr-1"`.
- Evidence: Interface Description 1; reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:187-198`.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.get_trace_id_from_assessment_proto`
- Obligations: R2
- Graph: E2, E14.

### C3: get_trace_id_from_assessment_proto returns raw v3 trace ID
- Type: Dataflow compatibility
- Subject: `get_trace_id_from_assessment_proto(assessments_pb2.Assessment(...))`
- Relation: Return equals raw `trace_id`.
- Expected: For `assessments_pb2.Assessment(trace_id="tr-v3")`, return
  `"tr-v3"`; the same holds for `pb.Assessment` without UC schema location.
- Evidence: `assessments_pb2.Assessment` has no `trace_location` field;
  reference implementation `libs/tracing/mlflow/utils/databricks_tracing_utils.py:198-200`.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.get_trace_id_from_assessment_proto`
- Obligations: R2
- Graph: E2.

### C4: inference_table_location_to_proto maps full_table_name
- Type: Dataflow conversion
- Subject: `inference_table_location_to_proto(InferenceTableLocation("a.b.c"))`
- Relation: Returned proto field equals entity field.
- Expected: `proto.full_table_name == "a.b.c"`.
- Evidence: Interface Description 1; reference implementation line 44-47.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.inference_table_location_to_proto`
- Obligations: R3
- Graph: E3.

### C5: mlflow_experiment_location_to_proto maps experiment_id
- Type: Dataflow conversion
- Subject: `mlflow_experiment_location_to_proto(MlflowExperimentLocation("123"))`
- Relation: Returned proto field equals entity field.
- Expected: `proto.experiment_id == "123"`.
- Evidence: Interface Description 1; reference implementation line 50-53.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.mlflow_experiment_location_to_proto`
- Obligations: R4
- Graph: E4.

### C6: trace_from_proto returns Trace with info and spans
- Type: Dataflow deserialization
- Subject: `trace_from_proto(pb.Trace(...), "catalog.schema")`
- Relation: Returned `Trace` composition matches proto inputs.
- Expected: `trace.info` equals `TraceInfo.from_proto(proto.trace_info)`; the
  number of `trace.data.spans` equals `len(proto.spans)`; each span is created
  through `Span.from_otel_proto(span, "catalog.schema")`.
- Evidence: Interface Description 1; reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:137-141`.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_from_proto`
- Obligations: R5
- Graph: E5, E15, E16, E17, E18.

### C7: trace_info_to_v4_proto converts UC TraceInfo fields
- Type: Dataflow conversion
- Subject: `trace_info_to_v4_proto(uc_trace_info)`
- Relation: Returned v4 `pb.TraceInfo` fields match parsed/truncated inputs.
- Expected: For UC `trace_id="trace:/catalog.schema/tr-1"` with location
  `catalog.schema`, return `trace_id == "tr-1"`,
  `trace_location.uc_schema.catalog_name == "catalog"`, `schema_name ==
  "schema"`, `request_time.ToMilliseconds() == trace_info.request_time`,
  optional `execution_duration.ToMilliseconds()` matches,
  `state == pb.TraceInfo.State.Value(trace_info.state)`,
  `trace_metadata == _truncate_request_metadata(trace_info.trace_metadata)`,
  `tags == _truncate_tags(trace_info.tags)`, and assessments match
  `assessment_to_proto`.
- Evidence: Interface Description 1; repository test
  `tests/entities/test_trace_info.py:128-175`; reference implementation lines 102-127.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto`
- Obligations: R6
- Graph: E6, E19, E20, E21, E22, E23, E24.

### C8: trace_info_to_v4_proto preserves non-UC trace_id
- Type: Dataflow compatibility
- Subject: `trace_info_to_v4_proto(non_uc_trace_info)`
- Relation: Returned proto uses raw trace ID.
- Expected: For a non-UC location, `proto.trace_id == trace_info.trace_id`; no
  `parse_trace_id_v4` transformation is applied.
- Evidence: Reference implementation
  `libs/tracing/mlflow/utils/databricks_tracing_utils.py:113-116`.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto`
- Obligations: R6
- Graph: E6, E20-E24.

### C9: trace_location_from_proto dispatches MLflow experiment
- Type: Dataflow deserialization
- Subject: `trace_location_from_proto(pb.TraceLocation(...))`
- Relation: Return type and identifier match oneof.
- Expected: For
  `pb.TraceLocation(type=MLFLOW_EXPERIMENT,
  mlflow_experiment=pb.TraceLocation.MlflowExperimentLocation(experiment_id="1234"))`,
  return `TraceLocation(type=TraceLocationType.MLFLOW_EXPERIMENT,
  mlflow_experiment=MlflowExperimentLocation("1234"))`.
- Evidence: Interface Description 1; test
  `tests/entities/test_trace_location.py:70-77`; reference implementation lines 80-95.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- Obligations: R7
- Graph: E7, E25, E27.

### C10: trace_location_from_proto dispatches inference table
- Type: Dataflow deserialization
- Subject: `trace_location_from_proto(pb.TraceLocation(...))`
- Relation: Return type and identifier match oneof.
- Expected: For `pb.TraceLocation(type=INFERENCE_TABLE,
  inference_table=pb.TraceLocation.InferenceTableLocation(full_table_name="c.s.t"))`,
  return `TraceLocation(type=TraceLocationType.INFERENCE_TABLE,
  inference_table=InferenceTableLocation("c.s.t"))`.
- Evidence: Interface Description 1; test
  `tests/entities/test_trace_location.py:80-89`; reference implementation lines 91-95.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- Obligations: R7
- Graph: E7, E25, E27.

### C11: trace_location_from_proto falls back to unspecified
- Type: State fallback
- Subject: `trace_location_from_proto(pb.TraceLocation(type=0))`
- Relation: Returned object has unspecified type and no location fields.
- Expected: Returns
  `TraceLocation(TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)` with no
  identifier populated.
- Evidence: Interface Description 1; reference implementation lines 96-97.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- Obligations: R7
- Graph: E7, E28.

### C12: trace_location_to_proto dispatches UC schema
- Type: Dataflow conversion
- Subject: `trace_location_to_proto(TraceLocation.from_databricks_uc_schema("catalog","schema"))`
- Relation: Returned `pb.TraceLocation` has UC oneof.
- Expected: `proto.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA` and
  `proto.uc_schema.catalog_name == "catalog"` and `schema_name == "schema"`.
- Evidence: Interface Description 1; reference implementation lines 56-61.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_location_to_proto`
- Obligations: R8
- Graph: E8, E29.

### C13: trace_location_to_proto raises ValueError for unsupported type
- Type: Failure
- Subject: `trace_location_to_proto(TraceLocation(type=TRACE_LOCATION_TYPE_UNSPECIFIED))`
- Relation: Unsupported type raises.
- Expected: Raises `ValueError` with message containing the unsupported type.
- Evidence: Interface Description 1; reference implementation lines 72-73.
- Observe: EXCEPTION
- Target: `mlflow.utils.databricks_tracing_utils.trace_location_to_proto`
- Obligations: R8
- Graph: E8, E32.

### C14: trace_to_proto composes info and span protos
- Type: Dataflow conversion
- Subject: `trace_to_proto(trace)`
- Relation: Returned `pb.Trace` fields equal entity conversions.
- Expected: `proto.trace_info == trace.info.to_proto()` and
  `list(proto.spans) == [span.to_otel_proto() for span in trace.data.spans]`.
- Evidence: Interface Description 1; reference implementation lines 130-134;
  `tests/store/tracking/test_databricks_rest_store.py:191-212`.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.trace_to_proto`
- Obligations: R9
- Graph: E9, E33, E34.

### C15: uc_schema_location_from_proto preserves optional table fields
- Type: Dataflow deserialization
- Subject: `uc_schema_location_from_proto(pb.UCSchemaLocation(...))`
- Relation: Returned entity fields match proto.
- Expected: Catalog and schema are copied. When
  `otel_spans_table_name`/`otel_logs_table_name` are present, private
  attributes equal those values; when absent, private attributes retain
  defaults from `UCSchemaLocation`.
- Evidence: Interface Description 1; reference implementation lines 34-41.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.uc_schema_location_from_proto`
- Obligations: R10
- Graph: E10.

### C16: uc_schema_location_to_proto copies private table names
- Type: Dataflow conversion
- Subject: `uc_schema_location_to_proto(uc_schema_location)`
- Relation: Returned proto fields match entity including private attributes.
- Expected: `proto.catalog_name == uc.catalog_name`, `proto.schema_name ==
  uc.schema_name`, `proto.otel_spans_table_name == uc._otel_spans_table_name`,
  `proto.otel_logs_table_name == uc._otel_logs_table_name`.
- Evidence: Interface Description 1; reference implementation lines 25-31.
- Observe: RETURN_VALUE
- Target: `mlflow.utils.databricks_tracing_utils.uc_schema_location_to_proto`
- Obligations: R11
- Graph: E11.

### C17: AssessmentSourceType constants are plain strings and exclude AI_JUDGE
- Type: Interface shape
- Subject: `mlflow.entities.assessment_source.AssessmentSourceType`
- Relation: Class attribute values and `_SOURCE_TYPES` list.
- Expected: `SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"`,
  `LLM_JUDGE == "LLM_JUDGE"`, `AI_JUDGE == "AI_JUDGE"`, `HUMAN == "HUMAN"`,
  `CODE == "CODE"`, and
  `_SOURCE_TYPES == ["SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "HUMAN", "CODE"]`.
- Evidence: Interface Description 2; current file
  `mlflow/entities/assessment_source.py:148-156`.
- Observe: FIELD_READ
- Target: `mlflow.entities.assessment_source.AssessmentSourceType`
- Obligations: R12
- Graph: N21.

### C18: AssessmentSourceType._parse normalizes valid input
- Type: Compatibility/Dataflow
- Subject: `AssessmentSourceType._parse(source_type)`
- Relation: Returned value is uppercase canonical.
- Expected: `"human"`, `"Human"`, and `"HUMAN"` all return `"HUMAN"`;
  `"llm_judge"` and `"LLM_JUDGE"` return `"LLM_JUDGE"`.
- Evidence: Interface Description 2; repository tests
  `tests/entities/test_assessment_source.py:53-68`.
- Observe: RETURN_VALUE
- Target: `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- Obligations: R14
- Graph: E44.

### C19: AssessmentSourceType._parse emits deprecation warning for AI_JUDGE
- Type: Compatibility side effect
- Subject: `AssessmentSourceType._parse("AI_JUDGE")`
- Relation: Emits `FutureWarning` and returns canonical replacement.
- Expected: Raises/warns `FutureWarning` with message
  `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` and returns `"LLM_JUDGE"`.
- Evidence: Interface Description 2; test
  `tests/entities/test_assessment_source.py:71-75`.
- Observe: SIDE_EFFECT
- Target: `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- Obligations: R14
- Graph: E45.

### C20: AssessmentSourceType._parse rejects invalid values
- Type: Failure
- Subject: `AssessmentSourceType._parse("ROBOT")`
- Relation: Invalid source type raises `MlflowException`.
- Expected: Raises `MlflowException` with `error_code ==
  INVALID_PARAMETER_VALUE` and message matching
  `"Invalid assessment source type: ROBOT"` and listing valid types.
- Evidence: Interface Description 2; test
  `tests/entities/test_assessment_source.py:48-50`.
- Observe: EXCEPTION
- Target: `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- Obligations: R14
- Graph: E46.

### C21: AssessmentSourceType._standardize returns str(instance)
- Type: Interface/State
- Subject: `AssessmentSourceType._standardize("llm_judge")`
- Relation: Constructs an instance and returns its string form.
- Expected: Returns `"LLM_JUDGE"`; construction path is
  `AssessmentSourceType(source_type)` followed by `str(instance)`.
- Evidence: Interface Description 2 notes; reference implementation
  `libs/tracing/mlflow/entities/assessment_source.py:186-187`.
- Observe: RETURN_VALUE
- Target: `mlflow.entities.assessment_source.AssessmentSourceType._standardize`
- Obligations: R13
- Graph: E43.

### C22: Span.inputs returns deserialized span input attribute
- Type: Dataflow property
- Subject: `span.inputs` for a Span whose
  `SpanAttributeKey.INPUTS` attribute is set.
- Relation: Return equals deserialized attribute value.
- Expected: When inputs were set with `{"x": 1}`, returns `{"x": 1}`; when no
  inputs attribute exists, returns `None`.
- Evidence: Interface Description 3; reference implementation
  `libs/tracing/mlflow/entities/span.py:158-160`; tests
  `tests/tracing/test_fluent.py:299-300`.
- Observe: RETURN_VALUE
- Target: `mlflow.entities.span.Span.inputs`
- Obligations: R15
- Graph: E48, E50, E51.

### C23: Span.outputs returns deserialized span output attribute
- Type: Dataflow property
- Subject: `span.outputs` for a Span whose
  `SpanAttributeKey.OUTPUTS` attribute is set.
- Relation: Return equals deserialized attribute value.
- Expected: When outputs were set with `11`, returns `11`; when no outputs
  attribute exists, returns `None`.
- Evidence: Interface Description 3; reference implementation
  `libs/tracing/mlflow/entities/span.py:163-165`; tests
  `tests/tracing/test_fluent.py:299-300`.
- Observe: RETURN_VALUE
- Target: `mlflow.entities.span.Span.outputs`
- Obligations: R16
- Graph: E49, E50, E51.

### C24: TraceInfo.to_proto reaches trace_info_to_v4_proto on UC path
- Type: Compatibility caller-path
- Subject: `uc_trace_info.to_proto()` where `uc_trace_info` is a UC-schema
  `TraceInfo`.
- Relation: The real caller path executes `trace_info_to_v4_proto`.
- Expected: Returns a `databricks_tracing_pb2.TraceInfo` whose `trace_id` is
  the parsed raw ID and whose `trace_location.uc_schema` matches the UC
  location. This is the same expected result as C7, observed through
  `TraceInfo.to_proto` rather than by calling the helper directly.
- Evidence: Static issue `mlflow/entities/trace_info.py`;
  `mlflow/entities/trace_info.py:97-103`; test
  `tests/entities/test_trace_info.py:128-175`.
- Observe: RETURN_VALUE
- Target: `mlflow.entities.trace_info.TraceInfo.to_proto`
- Obligations: R6, R17
- Graph: E35.

### C25: TraceLocation.from_proto reaches trace_location_from_proto
- Type: Compatibility caller-path
- Subject: `TraceLocation.from_proto(pb.TraceLocation(...))` with MLflow
  experiment oneof.
- Relation: The real caller path executes `trace_location_from_proto`.
- Expected: Returns the same `TraceLocation` as C9, observed through the public
  `TraceLocation.from_proto` method.
- Evidence: Static issue `mlflow/entities/trace_location.py`;
  `mlflow/entities/trace_location.py:244-246`; tests
  `tests/entities/test_trace_location.py:70-77`.
- Observe: RETURN_VALUE
- Target: `mlflow.entities.trace_location.TraceLocation.from_proto`
- Obligations: R7, R18
- Graph: E36.

### C26: DatabricksTracingRestStore.create_assessment reaches assessment_to_proto
- Type: Compatibility caller-path
- Subject: `store.create_assessment(assessment)` with UC v4 `trace_id`.
- Relation: The real REST-store caller path invokes `assessment_to_proto` and
  sends its output through `message_to_json`.
- Expected: With `_call_endpoint` mocked and `response_proto` supplied, the
  request JSON passed to `_call_endpoint` contains the assessment name, parsed
  raw trace ID, and UC trace location; the method returns an `Assessment`
  constructed from the mocked response. This proves the call site in
  `databricks_rest_store.py:511` binds the task function.
- Evidence: Static issue `mlflow/store/tracking/databricks_rest_store.py`;
  call site lines 509-521; reference import block in
  `libs/tracing/mlflow/store/tracking/databricks_rest_store.py`.
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.create_assessment`
- Obligations: R1, R19
- Graph: E37.

### C27: DatabricksTracingRestStore.batch_get_traces reaches trace_from_proto
- Type: Compatibility caller-path
- Subject: `store.batch_get_traces(["trace:/catalog.schema/tr-1"], "catalog.schema")`
- Relation: The real REST-store caller path invokes `trace_from_proto`.
- Expected: With `_call_endpoint` mocked to return a `BatchGetTraces` response
  containing one `pb.Trace`, the method returns a list with one `Trace` whose
  `trace_id`/location and span count reflect the response. This proves the call
  site in `databricks_rest_store.py:189` binds the task function.
- Evidence: Static issue `mlflow/store/tracking/databricks_rest_store.py`;
  call site lines 165-189.
- Observe: RETURN_VALUE
- Target: `mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.batch_get_traces`
- Obligations: R5, R19
- Graph: E38.

### C28: DatabricksTracingRestStore.set_experiment_trace_location reaches UC schema converters
- Type: Compatibility caller-path
- Subject: `store.set_experiment_trace_location(location, "experiment_id")`
- Relation: The real REST-store caller path invokes
  `uc_schema_location_to_proto` and `uc_schema_location_from_proto`.
- Expected: With `_call_endpoint` mocked to return a
  `CreateTraceUCStorageLocation.Response` containing a UC schema, the method
  returns a `UCSchemaLocationEntity` populated from
  `uc_schema_location_from_proto`, and request bodies passed to
  `_call_endpoint` contain proto UC schema locations produced by
  `uc_schema_location_to_proto`. This proves call sites lines 412, 422, 434
  bind the task functions.
- Evidence: Static issue `mlflow/store/tracking/databricks_rest_store.py`;
  call sites lines 404-444.
- Observe: RETURN_VALUE
- Target: `mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.set_experiment_trace_location`
- Obligations: R10, R11, R19
- Graph: E40, E41.

### C29: DatabricksTracingRestStore.search_traces reaches trace_location_to_proto
- Type: Compatibility caller-path
- Subject: `store.search_traces(locations=["123"], ...)` or another v4 path
  using `trace_location_to_proto`.
- Relation: The real REST-store caller path invokes `trace_location_to_proto`.
- Expected: With `_call_endpoint` mocked, a search request body contains a
  `pb.TraceLocation` with MLflow experiment location for `"123"` (or a UC
  location for `"catalog.schema"`), proving call sites lines 290/294/558 bind
  the task function. The method returns/falls back according to the mocked
  response.
- Evidence: Static issue `mlflow/store/tracking/databricks_rest_store.py`;
  call sites lines 284-297, 552-559.
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `mlflow.store.tracking.databricks_rest_store.DatabricksTracingRestStore.search_traces`
- Obligations: R8, R19
- Graph: E39.

### C30: AssessmentSource construction normalizes source_type
- Type: Compatibility state
- Subject: `AssessmentSource(source_type="llm_judge", source_id="gpt-4")`
- Relation: `source_type` field after construction.
- Expected: `source.source_type == "LLM_JUDGE"`.
- Evidence: `mlflow/entities/assessment_source.py:65-67`; tests
  `tests/entities/test_assessment_source.py:53-68`.
- Observe: FIELD_READ
- Target: `mlflow.entities.assessment_source.AssessmentSource`
- Obligations: R13, R20
- Graph: E42.

