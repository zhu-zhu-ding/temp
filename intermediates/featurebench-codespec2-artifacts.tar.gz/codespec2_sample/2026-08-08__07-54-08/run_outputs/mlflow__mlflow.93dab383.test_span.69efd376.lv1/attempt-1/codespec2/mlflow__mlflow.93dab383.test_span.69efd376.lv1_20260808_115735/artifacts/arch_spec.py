#!/usr/bin/env python3
"""
Executable architecture spec for MLflow Distributed Tracing System.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts:
  C1, C4, C5, C8, C9, C15, C16, C17, C18, C19, C20, C21, C22, C23, C24,
  C25, C27, C28

Each check_* function starts at the public entry and reaches the L3 observer.
"""
import base64
import json
import sys
import time

import pytest  # noqa: F401 – available in test env

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_readable_span(
    trace_id: int = 12345,
    span_id: int = 67890,
    name: str = "test_span",
    parent_id: int | None = None,
    start_time: int | None = None,
    end_time: int | None = None,
    attributes: dict | None = None,
    events: list | None = None,
):
    """Create an OTel ReadableSpan for testing."""
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    from opentelemetry.trace import SpanContext, TraceFlags, Status, StatusCode

    context = SpanContext(
        trace_id=trace_id,
        span_id=span_id,
        is_remote=False,
        trace_flags=TraceFlags(TraceFlags.SAMPLED),
    )
    parent = SpanContext(
        trace_id=trace_id,
        span_id=parent_id,
        is_remote=False,
        trace_flags=TraceFlags(TraceFlags.SAMPLED),
    ) if parent_id is not None else None

    return OTelReadableSpan(
        name=name,
        context=context,
        parent=parent,
        start_time=start_time or int(time.time() * 1e9),
        end_time=end_time,
        attributes=attributes or {},
        status=Status(StatusCode.UNSET),
        resource=None,
        events=events or [],
    )


def _make_mock_otel_span(
    trace_id: int = 12345,
    span_id: int = 67890,
    name: str = "test_span",
    parent_id: int | None = None,
    start_time: int | None = None,
    end_time: int | None = None,
):
    """Create a mock OTel Span (both Span and ReadableSpan) for testing."""
    from dataclasses import dataclass, field

    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import Event, ReadableSpan
    from opentelemetry.trace import Status, StatusCode

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(self, name, context, parent, start_time=None, end_time=None,
                     status=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status or Status(StatusCode.UNSET)
            self._attributes = {}
            self._events = []

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(Event(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self._name = name

        def end(self, end_time_ns=None):
            pass

        def record_exception(self):
            pass

    return _MockOTelSpan(
        name=name,
        context=_MockSpanContext(trace_id, span_id),
        parent=_MockSpanContext(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        end_time=end_time,
    )


# ---------------------------------------------------------------------------
# C5: NoOpSpan._trace_id Returns None
# ---------------------------------------------------------------------------
# Contracts: C5

def check_c5_noopspan_internal_trace_id():
    """NoOpSpan._trace_id must return None."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    result = span._trace_id
    assert result is None, f"Expected None, got {result!r}"
    print("PASS: C5 - NoOpSpan._trace_id returns None")


# ---------------------------------------------------------------------------
# C8: NoOpSpan.end_time_ns Returns None
# ---------------------------------------------------------------------------
# Contracts: C8

def check_c8_noopspan_end_time():
    """NoOpSpan.end_time_ns must return None."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    result = span.end_time_ns
    assert result is None, f"Expected None, got {result!r}"
    print("PASS: C8 - NoOpSpan.end_time_ns returns None")


# ---------------------------------------------------------------------------
# C9: NoOpSpan.name Returns None
# ---------------------------------------------------------------------------
# Contracts: C9

def check_c9_noopspan_name():
    """NoOpSpan.name must return None."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    result = span.name
    assert result is None, f"Expected None, got {result!r}"
    print("PASS: C9 - NoOpSpan.name returns None")


# ---------------------------------------------------------------------------
# C15: NoOpSpan.span_id Returns None
# ---------------------------------------------------------------------------
# Contracts: C15

def check_c15_noopspan_span_id():
    """NoOpSpan.span_id must return None."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    result = span.span_id
    assert result is None, f"Expected None, got {result!r}"
    print("PASS: C15 - NoOpSpan.span_id returns None")


# ---------------------------------------------------------------------------
# C16: NoOpSpan.start_time_ns Returns None
# ---------------------------------------------------------------------------
# Contracts: C16

def check_c16_noopspan_start_time():
    """NoOpSpan.start_time_ns must return None."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    result = span.start_time_ns
    assert result is None, f"Expected None, got {result!r}"
    print("PASS: C16 - NoOpSpan.start_time_ns returns None")


# ---------------------------------------------------------------------------
# C17: NoOpSpan.status Returns None
# ---------------------------------------------------------------------------
# Contracts: C17

def check_c17_noopspan_status():
    """NoOpSpan.status must return None."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    result = span.status
    assert result is None, f"Expected None, got {result!r}"
    print("PASS: C17 - NoOpSpan.status returns None")


# ---------------------------------------------------------------------------
# C18: NoOpSpan.trace_id Returns Constant
# ---------------------------------------------------------------------------
# Contracts: C18

def check_c18_noopspan_trace_id():
    """NoOpSpan.trace_id must return the constant 'MLFLOW_NO_OP_SPAN_TRACE_ID'."""
    from mlflow.entities.span import NO_OP_SPAN_TRACE_ID, NoOpSpan

    span = NoOpSpan()
    result = span.trace_id
    assert result == NO_OP_SPAN_TRACE_ID, (
        f"Expected {NO_OP_SPAN_TRACE_ID!r}, got {result!r}"
    )
    print("PASS: C18 - NoOpSpan.trace_id returns NO_OP_SPAN_TRACE_ID")


# ---------------------------------------------------------------------------
# C4: LiveSpan.to_immutable_span Returns Span Instance
# ---------------------------------------------------------------------------
# Contracts: C4

def check_c4_livespan_to_immutable_span():
    """LiveSpan.to_immutable_span() must return a Span (not LiveSpan)."""
    from mlflow.entities.span import LiveSpan, Span

    otel_span = _make_mock_otel_span(trace_id=111, span_id=222, name="live_test")
    live = LiveSpan(otel_span, "tr-test", "LLM")
    live.set_attribute("custom_key", "custom_val")

    immutable = live.to_immutable_span()
    assert isinstance(immutable, Span), (
        f"Expected Span, got {type(immutable)}"
    )
    assert not isinstance(immutable, LiveSpan), (
        "Result must not be a LiveSpan"
    )
    # Verify data matches
    assert immutable.name == live.name, (
        f"Name mismatch: {immutable.name!r} vs {live.name!r}"
    )
    assert immutable.span_id == live.span_id, (
        f"Span ID mismatch: {immutable.span_id!r} vs {live.span_id!r}"
    )
    assert immutable.start_time_ns == live.start_time_ns, (
        f"Start time mismatch"
    )
    assert immutable.get_attribute("custom_key") == "custom_val", (
        f"Attribute not preserved: {immutable.get_attribute('custom_key')!r}"
    )
    print("PASS: C4 - LiveSpan.to_immutable_span returns Span with matching data")


# ---------------------------------------------------------------------------
# C19: Span.attributes Returns Deserialized Dict
# ---------------------------------------------------------------------------
# Contracts: C19

def check_c19_span_attributes():
    """Span.attributes must return a dict[str, Any] with all keys deserialized."""
    from mlflow.entities.span import Span
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        "key1": dump_span_attribute_value("val1"),
        "key2": dump_span_attribute_value(42),
        "key3": dump_span_attribute_value([1, 2, 3]),
    }
    otel_span = _make_readable_span(
        trace_id=1, span_id=10, name="attr_test", attributes=attrs
    )
    span = Span(otel_span)

    result = span.attributes
    assert isinstance(result, dict), f"Expected dict, got {type(result)}"
    assert result.get("key1") == "val1", f"key1: {result.get('key1')!r}"
    assert result.get("key2") == 42, f"key2: {result.get('key2')!r}"
    assert result.get("key3") == [1, 2, 3], f"key3: {result.get('key3')!r}"
    print("PASS: C19 - Span.attributes returns deserialized dict")


# ---------------------------------------------------------------------------
# C20: Span.events Returns SpanEvent List
# ---------------------------------------------------------------------------
# Contracts: C20

def check_c20_span_events():
    """Span.events must return list[SpanEvent] with plain dict attributes."""
    from opentelemetry.sdk.trace import Event as OTelEvent

    from mlflow.entities.span import Span
    from mlflow.entities.span_event import SpanEvent

    events = [
        OTelEvent(name="ev1", timestamp=1000, attributes={"a": "1"}),
        OTelEvent(name="ev2", timestamp=2000, attributes={"b": "2"}),
    ]
    otel_span = _make_readable_span(
        trace_id=1, span_id=10, name="event_test", events=events
    )
    span = Span(otel_span)

    result = span.events
    assert isinstance(result, list), f"Expected list, got {type(result)}"
    assert len(result) == 2, f"Expected 2 events, got {len(result)}"
    for ev in result:
        assert isinstance(ev, SpanEvent), f"Expected SpanEvent, got {type(ev)}"
        # Attributes should be plain dict, not BoundedAttributes
        assert isinstance(ev.attributes, dict), (
            f"Expected plain dict attributes, got {type(ev.attributes)}"
        )
    assert result[0].name == "ev1"
    assert result[0].timestamp == 1000
    assert result[1].name == "ev2"
    print("PASS: C20 - Span.events returns list of SpanEvent with dict attrs")


# ---------------------------------------------------------------------------
# C22: Span.request_id Equals trace_id
# ---------------------------------------------------------------------------
# Contracts: C22

def check_c22_span_request_id():
    """Span.request_id must equal span.trace_id."""
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    request_id_val = "tr-abc123"
    attrs = {SpanAttributeKey.REQUEST_ID: dump_span_attribute_value(request_id_val)}
    otel_span = _make_readable_span(
        trace_id=1, span_id=10, name="req_test", attributes=attrs
    )
    span = Span(otel_span)

    assert span.request_id == span.trace_id, (
        f"request_id {span.request_id!r} != trace_id {span.trace_id!r}"
    )
    print("PASS: C22 - Span.request_id equals trace_id")


# ---------------------------------------------------------------------------
# C23: Span.span_type Returns Stored Type
# ---------------------------------------------------------------------------
# Contracts: C23

def check_c23_span_span_type():
    """Span.span_type must return the value under SpanAttributeKey.SPAN_TYPE."""
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM")}
    otel_span = _make_readable_span(
        trace_id=1, span_id=10, name="type_test", attributes=attrs
    )
    span = Span(otel_span)

    assert span.span_type == "LLM", f"Expected 'LLM', got {span.span_type!r}"

    # Also test None when not set
    otel_span2 = _make_readable_span(trace_id=2, span_id=20, name="no_type")
    span2 = Span(otel_span2)
    assert span2.span_type is None, f"Expected None, got {span2.span_type!r}"

    print("PASS: C23 - Span.span_type returns stored type or None")


# ---------------------------------------------------------------------------
# C24: Span.to_dict Produces Correct Schema
# ---------------------------------------------------------------------------
# Contracts: C24, R29

def check_c24_span_to_dict():
    """Span.to_dict must produce correct schema with base64-encoded IDs."""
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    trace_id_int = 0xABCDEF1234567890ABCDEF1234567890
    span_id_int = 0x1234567890ABCDEF
    parent_id_int = 0xFEDCBA0987654321

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test123"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("TOOL"),
        "custom": dump_span_attribute_value("value"),
    }
    otel_span = _make_readable_span(
        trace_id=trace_id_int,
        span_id=span_id_int,
        parent_id=parent_id_int,
        name="schema_test",
        attributes=attrs,
        start_time=1000000000,
        end_time=2000000000,
    )
    span = Span(otel_span)

    result = span.to_dict()

    # Required keys
    for key in (
        "trace_id", "span_id", "parent_span_id", "name",
        "start_time_unix_nano", "end_time_unix_nano",
        "events", "status", "attributes",
    ):
        assert key in result, f"Missing key: {key}"

    assert result["name"] == "schema_test"
    assert result["start_time_unix_nano"] == 1000000000
    assert result["end_time_unix_nano"] == 2000000000

    # Verify base64 encoding of IDs
    # trace_id: 16 bytes big-endian, base64 encoded
    expected_trace_bytes = trace_id_int.to_bytes(16, "big", signed=False)
    expected_trace_b64 = base64.b64encode(expected_trace_bytes).decode("utf-8")
    assert result["trace_id"] == expected_trace_b64, (
        f"trace_id encoding: {result['trace_id']!r} != {expected_trace_b64!r}"
    )

    # span_id: 8 bytes big-endian, base64 encoded
    expected_span_bytes = span_id_int.to_bytes(8, "big", signed=False)
    expected_span_b64 = base64.b64encode(expected_span_bytes).decode("utf-8")
    assert result["span_id"] == expected_span_b64, (
        f"span_id encoding: {result['span_id']!r} != {expected_span_b64!r}"
    )

    # parent_span_id: 8 bytes big-endian, base64 encoded
    expected_parent_bytes = parent_id_int.to_bytes(8, "big", signed=False)
    expected_parent_b64 = base64.b64encode(expected_parent_bytes).decode("utf-8")
    assert result["parent_span_id"] == expected_parent_b64, (
        f"parent_span_id encoding: {result['parent_span_id']!r} != {expected_parent_b64!r}"
    )

    # Status
    assert "code" in result["status"]
    assert "message" in result["status"]

    # Events is a list
    assert isinstance(result["events"], list)

    # Attributes dict
    assert isinstance(result["attributes"], dict)

    print("PASS: C24 - Span.to_dict produces correct schema with base64 IDs")


# ---------------------------------------------------------------------------
# C25: Span.to_otel_proto Returns OTelProtoSpan
# ---------------------------------------------------------------------------
# Contracts: C25

def check_c25_span_to_otel_proto():
    """Span.to_otel_proto must return an OTelProtoSpan with correct data."""
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    from mlflow.entities.span import Span

    otel_span = _make_readable_span(
        trace_id=12345, span_id=67890, name="proto_test",
        start_time=1000, end_time=2000,
    )
    span = Span(otel_span)

    result = span.to_otel_proto()
    assert isinstance(result, OTelProtoSpan), (
        f"Expected OTelProtoSpan, got {type(result)}"
    )
    assert result.name == "proto_test", f"name: {result.name!r}"
    assert result.start_time_unix_nano == 1000
    assert result.end_time_unix_nano == 2000
    # trace_id and span_id should be bytes
    assert isinstance(result.trace_id, bytes), (
        f"trace_id should be bytes, got {type(result.trace_id)}"
    )
    assert isinstance(result.span_id, bytes), (
        f"span_id should be bytes, got {type(result.span_id)}"
    )
    print("PASS: C25 - Span.to_otel_proto returns OTelProtoSpan with correct data")


# ---------------------------------------------------------------------------
# C21: Span.from_otel_proto Constructs Span
# ---------------------------------------------------------------------------
# Contracts: C21, R28

def check_c21_span_from_otel_proto():
    """Span.from_otel_proto must return a Span with correct trace_id and attributes."""
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus

    from mlflow.entities.span import Span
    from mlflow.tracing.constant import TRACE_REQUEST_ID_PREFIX

    proto_span = OTelProtoSpan()
    proto_span.trace_id = b'\x00' * 16  # 16 zero bytes
    proto_span.span_id = b'\x00' * 8    # 8 zero bytes
    proto_span.name = "from_proto_test"
    proto_span.start_time_unix_nano = 1000
    proto_span.end_time_unix_nano = 2000
    proto_span.status.code = OTelProtoStatus.STATUS_CODE_OK

    # Add an attribute
    attr = proto_span.attributes.add()
    attr.key = "test_key"
    attr.value.string_value = "test_value"

    span = Span.from_otel_proto(proto_span)

    assert isinstance(span, Span), f"Expected Span, got {type(span)}"
    assert span.name == "from_proto_test"
    # trace_id should start with "tr-" prefix
    assert span.trace_id.startswith(TRACE_REQUEST_ID_PREFIX), (
        f"trace_id should start with {TRACE_REQUEST_ID_PREFIX!r}: {span.trace_id!r}"
    )
    # span_id should be a hex string
    assert len(span.span_id) == 16, f"span_id length: {len(span.span_id)}"

    print("PASS: C21 - Span.from_otel_proto constructs Span correctly")


# ---------------------------------------------------------------------------
# C27: create_mlflow_span Dispatches Correctly
# ---------------------------------------------------------------------------
# Contracts: C27

def check_c27_create_mlflow_span_dispatches():
    """create_mlflow_span must dispatch to correct span type."""
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    from opentelemetry.trace import NonRecordingSpan

    from mlflow.entities.span import (
        LiveSpan,
        NoOpSpan,
        Span,
        create_mlflow_span,
    )

    # None -> NoOpSpan
    result = create_mlflow_span(None, "tr-none")
    assert isinstance(result, NoOpSpan), f"None -> expected NoOpSpan, got {type(result)}"

    # NonRecordingSpan -> NoOpSpan
    non_rec = NonRecordingSpan(context=None)
    result = create_mlflow_span(non_rec, "tr-nonrec")
    assert isinstance(result, NoOpSpan), (
        f"NonRecordingSpan -> expected NoOpSpan, got {type(result)}"
    )

    # Live OTelSpan -> LiveSpan
    live_otel = _make_mock_otel_span(trace_id=1, span_id=2, name="live")
    result = create_mlflow_span(live_otel, "tr-live", "LLM")
    assert isinstance(result, LiveSpan), (
        f"OTelSpan -> expected LiveSpan, got {type(result)}"
    )

    # ReadableSpan -> Span (immutable)
    readable = _make_readable_span(trace_id=3, span_id=4, name="readable",
                                   end_time=int(time.time() * 1e9))
    result = create_mlflow_span(readable, "tr-readable")
    assert isinstance(result, Span), (
        f"OTelReadableSpan -> expected Span, got {type(result)}"
    )
    assert not isinstance(result, LiveSpan), "ReadableSpan must not return LiveSpan"

    # Invalid type -> MlflowException
    from mlflow.exceptions import MlflowException
    try:
        create_mlflow_span("invalid", "tr-invalid")
        assert False, "Should have raised MlflowException"
    except MlflowException:
        pass

    print("PASS: C27 - create_mlflow_span dispatches correctly")


# ---------------------------------------------------------------------------
# C1: _Trace.to_mlflow_trace Returns Trace with Immutable Spans
# ---------------------------------------------------------------------------
# Contracts: C1, R1, R4

def check_c1_trace_to_mlflow_trace():
    """_Trace.to_mlflow_trace must return Trace with immutable Span instances."""
    from mlflow.entities import Span, Trace
    from mlflow.entities.span import LiveSpan
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.tracing.trace_manager import _Trace

    trace_info = TraceInfo(
        trace_id="tr-test",
        trace_location=None,
        request_time=0,
        execution_duration=1,
        state=None,
        trace_metadata={},
        tags={},
    )
    internal = _Trace(info=trace_info)

    # Add some LiveSpan entries
    for i in range(3):
        otel_span = _make_mock_otel_span(
            trace_id=100 + i, span_id=200 + i, name=f"span_{i}"
        )
        live = LiveSpan(otel_span, "tr-test")
        internal.span_dict[live.span_id] = live

    result = internal.to_mlflow_trace()

    assert isinstance(result, Trace), f"Expected Trace, got {type(result)}"
    assert isinstance(result.data, TraceData), (
        f"Expected TraceData, got {type(result.data)}"
    )
    assert len(result.data.spans) == 3, (
        f"Expected 3 spans, got {len(result.data.spans)}"
    )
    for s in result.data.spans:
        assert isinstance(s, Span), f"Expected Span, got {type(s)}"
        assert not isinstance(s, LiveSpan), (
            "Spans must be immutable Span, not LiveSpan"
        )
    print("PASS: C1 - _Trace.to_mlflow_trace returns Trace with immutable Spans")


# ---------------------------------------------------------------------------
# C28: _decode_otel_proto_anyvalue Decodes All Types
# ---------------------------------------------------------------------------
# Contracts: C28, R28

def check_c28_decode_otel_proto_anyvalue():
    """_decode_otel_proto_anyvalue must decode all AnyValue types."""
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue

    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    # Unset -> None
    av = AnyValue()
    assert _decode_otel_proto_anyvalue(av) is None

    # bool_value
    av = AnyValue()
    av.bool_value = True
    assert _decode_otel_proto_anyvalue(av) is True

    # string_value
    av = AnyValue()
    av.string_value = "hello"
    assert _decode_otel_proto_anyvalue(av) == "hello"

    # int_value
    av = AnyValue()
    av.int_value = 42
    assert _decode_otel_proto_anyvalue(av) == 42

    # double_value
    av = AnyValue()
    av.double_value = 3.14
    assert _decode_otel_proto_anyvalue(av) == 3.14

    # bytes_value
    av = AnyValue()
    av.bytes_value = b"data"
    assert _decode_otel_proto_anyvalue(av) == b"data"

    # array_value (recursive)
    av = AnyValue()
    item = av.array_value.values.add()
    item.string_value = "a"
    item = av.array_value.values.add()
    item.int_value = 1
    result = _decode_otel_proto_anyvalue(av)
    assert result == ["a", 1], f"array: {result!r}"

    # kvlist_value (recursive)
    av = AnyValue()
    kv = av.kvlist_value.values.add()
    kv.key = "x"
    kv.value.string_value = "val"
    kv = av.kvlist_value.values.add()
    kv.key = "y"
    kv.value.int_value = 10
    result = _decode_otel_proto_anyvalue(av)
    assert result == {"x": "val", "y": 10}, f"kvlist: {result!r}"

    # Nested: array of kvlist
    av = AnyValue()
    item = av.array_value.values.add()
    kv = item.kvlist_value.values.add()
    kv.key = "nested"
    kv.value.string_value = "deep"
    result = _decode_otel_proto_anyvalue(av)
    assert result == [{"nested": "deep"}], f"nested: {result!r}"

    print("PASS: C28 - _decode_otel_proto_anyvalue decodes all types")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def main():
    failures = []
    checks = [
        check_c5_noopspan_internal_trace_id,
        check_c8_noopspan_end_time,
        check_c9_noopspan_name,
        check_c15_noopspan_span_id,
        check_c16_noopspan_start_time,
        check_c17_noopspan_status,
        check_c18_noopspan_trace_id,
        check_c4_livespan_to_immutable_span,
        check_c19_span_attributes,
        check_c20_span_events,
        check_c22_span_request_id,
        check_c23_span_span_type,
        check_c24_span_to_dict,
        check_c25_span_to_otel_proto,
        check_c21_span_from_otel_proto,
        check_c27_create_mlflow_span_dispatches,
        check_c1_trace_to_mlflow_trace,
        check_c28_decode_otel_proto_anyvalue,
    ]
    for check in checks:
        try:
            check()
        except Exception as e:
            failures.append((check.__name__, e))
            print(f"FAIL: {check.__name__}: {e}")
    if failures:
        print(f"\n{failures} total failures")
        sys.exit(1)
    print(f"\nAll {len(checks)} architecture checks passed.")
    sys.exit(0)


if __name__ == "__main__":
    main()
