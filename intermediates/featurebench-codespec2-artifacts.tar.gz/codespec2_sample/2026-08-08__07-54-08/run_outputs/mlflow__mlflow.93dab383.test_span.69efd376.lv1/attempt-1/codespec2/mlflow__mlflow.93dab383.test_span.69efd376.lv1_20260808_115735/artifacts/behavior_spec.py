#!/usr/bin/env python3
"""
Executable behavior spec for MLflow Distributed Tracing System.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries, and
compatibility contracts that are outcome-focused (not pure interface/connectivity):
  C1, C2, C3, C6, C7, C10, C11, C12, C13, C14, C26, C29

Each check_* function starts at the public entry and reaches the L3 observer.
"""
import base64
import json
import sys
import time

import pytest  # noqa: F401 – available in test env

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_otel_span(
    trace_id: int = 12345,
    span_id: int = 67890,
    name: str = "test_span",
    parent_id: int | None = None,
    start_time: int | None = None,
    end_time: int | None = None,
):
    """Create a mock OTel Span (both Span and ReadableSpan) for testing."""
    from dataclasses import dataclass, field

    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import Event, ReadableSpan
    from opentelemetry.trace import Status, StatusCode

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(self, name, context, parent, start_time=None, end_time=None,
                     status=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status or Status(StatusCode.UNSET)
            self._attributes = {}
            self._events = []

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(Event(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self._name = name

        def end(self, end_time_ns=None):
            pass

        def record_exception(self):
            pass

    return _MockOTelSpan(
        name=name,
        context=_MockSpanContext(trace_id, span_id),
        parent=_MockSpanContext(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        end_time=end_time,
    )


# ---------------------------------------------------------------------------
# C2: LiveSpan.from_dict Raises NotImplementedError
# ---------------------------------------------------------------------------
# Contracts: C2, R2

def check_c2_livespan_from_dict_raises():
    """LiveSpan.from_dict must raise NotImplementedError."""
    from mlflow.entities.span import LiveSpan
    from mlflow.exceptions import MlflowException  # noqa: F401 – may be raised instead

    # LiveSpan.from_dict should be defined and raise NotImplementedError
    # (not just absent from the class)
    try:
        LiveSpan.from_dict({})
        assert False, "LiveSpan.from_dict() should have raised"
    except NotImplementedError:
        pass  # Expected
    except Exception as e:
        # Accept a clear error about not being defined vs NotImplementedError
        if "has no attribute" in str(e) or "has no method" in str(e):
            raise AssertionError(
                f"LiveSpan.from_dict is not defined: {e}"
            ) from e
        raise
    print("PASS: C2 - LiveSpan.from_dict raises NotImplementedError")


# ---------------------------------------------------------------------------
# C3: LiveSpan.set_span_type Stores Attribute
# ---------------------------------------------------------------------------
# Contracts: C3, R3

def check_c3_livespan_set_span_type():
    """LiveSpan.set_span_type must store the type under SpanAttributeKey.SPAN_TYPE."""
    from mlflow.entities.span import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    otel_span = _make_mock_otel_span(trace_id=1, span_id=2, name="type_test")
    live = LiveSpan(otel_span, "tr-test")

    live.set_span_type("LLM")
    result = live.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert result == "LLM", f"Expected 'LLM', got {result!r}"

    # Setting again overwrites
    live.set_span_type("CHAIN")
    result = live.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert result == "CHAIN", f"Expected 'CHAIN' after overwrite, got {result!r}"

    # Custom type
    live.set_span_type("CUSTOM_OPERATION")
    result = live.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert result == "CUSTOM_OPERATION", f"Expected 'CUSTOM_OPERATION', got {result!r}"

    print("PASS: C3 - LiveSpan.set_span_type stores attribute via SpanAttributeKey")


# ---------------------------------------------------------------------------
# C1: _Trace.to_mlflow_trace Behavior
# ---------------------------------------------------------------------------
# Contracts: C1, R1, R4

def check_c1_trace_to_mlflow_trace_full():
    """_Trace.to_mlflow_trace full behavior: spans become immutable, preview set."""
    from unittest import mock

    from mlflow.entities import Span, Trace
    from mlflow.entities.span import LiveSpan
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.tracing.trace_manager import _Trace

    trace_info = TraceInfo(
        trace_id="tr-behavior",
        trace_location=None,
        request_time=1000,
        execution_duration=500,
        state=None,
        trace_metadata={"key": "val"},
        tags={"tag1": "val1"},
    )
    internal = _Trace(info=trace_info)

    # Add LiveSpan entries
    for i in range(2):
        otel_span = _make_mock_otel_span(
            trace_id=100 + i, span_id=200 + i, name=f"span_{i}"
        )
        live = LiveSpan(otel_span, "tr-behavior")
        live.set_attribute("idx", i)
        internal.span_dict[live.span_id] = live

    # Patch set_request_response_preview to verify it's called
    with mock.patch(
        "mlflow.tracing.trace_manager.set_request_response_preview"
    ) as mock_preview:
        result = internal.to_mlflow_trace()

        # Verify set_request_response_preview was called
        mock_preview.assert_called_once()

    assert isinstance(result, Trace)
    assert isinstance(result.data, TraceData)
    assert len(result.data.spans) == 2

    # All spans must be immutable Span (not LiveSpan)
    for s in result.data.spans:
        assert isinstance(s, Span)
        assert not isinstance(s, LiveSpan)

    # Original internal trace unchanged
    for s in internal.span_dict.values():
        assert isinstance(s, LiveSpan)

    print("PASS: C1 - _Trace.to_mlflow_trace full behavior verified")


# ---------------------------------------------------------------------------
# C6: NoOpSpan.add_event Is Silent No-Op
# ---------------------------------------------------------------------------
# Contracts: C6, R6

def check_c6_noopspan_add_event():
    """NoOpSpan.add_event must accept a SpanEvent and perform no operation."""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_event import SpanEvent

    span = NoOpSpan()
    event = SpanEvent(name="test_event", timestamp=1234567890,
                      attributes={"k": "v"})
    # Must not raise
    span.add_event(event)
    # Must be idempotent
    span.add_event(event)
    print("PASS: C6 - NoOpSpan.add_event is silent no-op")


# ---------------------------------------------------------------------------
# C7: NoOpSpan.end Is Silent No-Op
# ---------------------------------------------------------------------------
# Contracts: C7, R7

def check_c7_noopspan_end():
    """NoOpSpan.end must accept all optional params and perform no operation."""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    span = NoOpSpan()
    # All params
    span.end(
        outputs={"x": 1},
        attributes={"k": "v"},
        status=SpanStatus(SpanStatusCode.OK),
        end_time_ns=1234567890,
    )
    # No params
    span.end()
    # Multiple calls
    span.end(status="ERROR")
    print("PASS: C7 - NoOpSpan.end is silent no-op")


# ---------------------------------------------------------------------------
# C10: NoOpSpan.set_attribute Is No-Op
# ---------------------------------------------------------------------------
# Contracts: C10, R10

def check_c10_noopspan_set_attribute():
    """NoOpSpan.set_attribute must accept key/value and perform no operation."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    span.set_attribute("key", "value")
    span.set_attribute("num", 42)
    span.set_attribute("complex", {"nested": True})
    print("PASS: C10 - NoOpSpan.set_attribute is no-op")


# ---------------------------------------------------------------------------
# C11: NoOpSpan.set_attributes Is No-Op
# ---------------------------------------------------------------------------
# Contracts: C11, R11

def check_c11_noopspan_set_attributes():
    """NoOpSpan.set_attributes must accept dict and perform no operation."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    span.set_attributes({"key": "value"})
    span.set_attributes({"a": 1, "b": 2})
    span.set_attributes({})  # empty
    print("PASS: C11 - NoOpSpan.set_attributes is no-op")


# ---------------------------------------------------------------------------
# C12: NoOpSpan.set_inputs Is No-Op
# ---------------------------------------------------------------------------
# Contracts: C12, R12

def check_c12_noopspan_set_inputs():
    """NoOpSpan.set_inputs must accept dict and perform no operation."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    span.set_inputs({"x": 1})
    span.set_inputs({"query": "test"})
    print("PASS: C12 - NoOpSpan.set_inputs is no-op")


# ---------------------------------------------------------------------------
# C13: NoOpSpan.set_outputs Is No-Op
# ---------------------------------------------------------------------------
# Contracts: C13, R13

def check_c13_noopspan_set_outputs():
    """NoOpSpan.set_outputs must accept dict and perform no operation."""
    from mlflow.entities.span import NoOpSpan

    span = NoOpSpan()
    span.set_outputs({"y": 2})
    span.set_outputs({"result": "done"})
    print("PASS: C13 - NoOpSpan.set_outputs is no-op")


# ---------------------------------------------------------------------------
# C14: NoOpSpan.set_status Is No-Op
# ---------------------------------------------------------------------------
# Contracts: C14, R14

def check_c14_noopspan_set_status():
    """NoOpSpan.set_status must accept SpanStatus and perform no operation."""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    span = NoOpSpan()
    span.set_status(SpanStatus(SpanStatusCode.OK))
    span.set_status(SpanStatus(SpanStatusCode.ERROR, "something went wrong"))
    # Also accept string (if the interface doc says so)
    span.set_status("OK")
    print("PASS: C14 - NoOpSpan.set_status is no-op")


# ---------------------------------------------------------------------------
# C26: _CachedSpanAttributesRegistry.set Raises MlflowException
# ---------------------------------------------------------------------------
# Contracts: C26, R26

def check_c26_cached_registry_set_raises():
    """_CachedSpanAttributesRegistry.set must raise MlflowException."""
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    from opentelemetry.trace import SpanContext, TraceFlags, Status, StatusCode

    from mlflow.entities.span import _CachedSpanAttributesRegistry
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    context = SpanContext(
        trace_id=1, span_id=2,
        is_remote=False,
        trace_flags=TraceFlags(TraceFlags.SAMPLED),
    )
    otel_span = OTelReadableSpan(
        name="test", context=context, parent=None,
        start_time=0, end_time=None,
        attributes={}, status=Status(StatusCode.UNSET),
        resource=None, events=[],
    )
    registry = _CachedSpanAttributesRegistry(otel_span)

    try:
        registry.set("key", "value")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        # Verify error code
        assert e.error_code == INVALID_PARAMETER_VALUE, (
            f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}"
        )
    print("PASS: C26 - _CachedSpanAttributesRegistry.set raises MlflowException")


# ---------------------------------------------------------------------------
# C29: Span.to_dict Round-Trip Through from_dict
# ---------------------------------------------------------------------------
# Contracts: C29, R24, R29

def check_c29_span_to_dict_roundtrip():
    """Span.from_dict(span.to_dict()) must produce equivalent span."""
    from opentelemetry.sdk.trace import Event as OTelEvent

    from mlflow.entities.span import Span
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    trace_id_int = 0x11111111222222223333333344444444
    span_id_int = 0x5555555566666666

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-roundtrip"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("TOOL"),
        "custom_attr": dump_span_attribute_value({"nested": [1, 2, 3]}),
    }
    events = [
        OTelEvent(name="ev1", timestamp=1000, attributes={"a": "v1"}),
        OTelEvent(name="ev2", timestamp=2000, attributes={"b": "v2"}),
    ]

    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    from opentelemetry.trace import SpanContext, TraceFlags, Status, StatusCode

    context = SpanContext(
        trace_id=trace_id_int, span_id=span_id_int,
        is_remote=False,
        trace_flags=TraceFlags(TraceFlags.SAMPLED),
    )
    otel_span = OTelReadableSpan(
        name="roundtrip_test",
        context=context,
        parent=None,
        start_time=1000000000,
        end_time=2000000000,
        attributes=attrs,
        status=Status(StatusCode.OK, "all good"),
        resource=None,
        events=events,
    )
    original = Span(otel_span)

    # Convert to dict and back
    d = original.to_dict()
    restored = Span.from_dict(d)

    assert isinstance(restored, Span)
    assert restored.name == original.name, (
        f"name: {restored.name!r} vs {original.name!r}"
    )
    assert restored.span_id == original.span_id, (
        f"span_id: {restored.span_id!r} vs {original.span_id!r}"
    )
    assert restored.trace_id == original.trace_id, (
        f"trace_id: {restored.trace_id!r} vs {original.trace_id!r}"
    )
    assert restored.start_time_ns == original.start_time_ns, (
        f"start_time_ns: {restored.start_time_ns} vs {original.start_time_ns}"
    )
    assert restored.end_time_ns == original.end_time_ns, (
        f"end_time_ns: {restored.end_time_ns} vs {original.end_time_ns}"
    )

    # Attributes
    orig_attrs = original.attributes
    rest_attrs = restored.attributes
    assert rest_attrs.get(SpanAttributeKey.SPAN_TYPE) == "TOOL"
    assert rest_attrs.get("custom_attr") == {"nested": [1, 2, 3]}

    # Status
    orig_status = original.status
    rest_status = restored.status
    assert rest_status.status_code == orig_status.status_code

    # Events
    orig_events = original.events
    rest_events = restored.events
    assert len(rest_events) == len(orig_events), (
        f"events count: {len(rest_events)} vs {len(orig_events)}"
    )
    for oe, re in zip(orig_events, rest_events):
        assert re.name == oe.name
        assert re.timestamp == oe.timestamp

    print("PASS: C29 - Span.to_dict round-trip through from_dict preserves data")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def main():
    failures = []
    checks = [
        check_c2_livespan_from_dict_raises,
        check_c3_livespan_set_span_type,
        check_c1_trace_to_mlflow_trace_full,
        check_c6_noopspan_add_event,
        check_c7_noopspan_end,
        check_c10_noopspan_set_attribute,
        check_c11_noopspan_set_attributes,
        check_c12_noopspan_set_inputs,
        check_c13_noopspan_set_outputs,
        check_c14_noopspan_set_status,
        check_c26_cached_registry_set_raises,
        check_c29_span_to_dict_roundtrip,
    ]
    for check in checks:
        try:
            check()
        except Exception as e:
            failures.append((check.__name__, e))
            print(f"FAIL: {check.__name__}: {e}")
    if failures:
        print(f"\n{failures} total failures")
        sys.exit(1)
    print(f"\nAll {len(checks)} behavior checks passed.")
    sys.exit(0)


if __name__ == "__main__":
    main()
