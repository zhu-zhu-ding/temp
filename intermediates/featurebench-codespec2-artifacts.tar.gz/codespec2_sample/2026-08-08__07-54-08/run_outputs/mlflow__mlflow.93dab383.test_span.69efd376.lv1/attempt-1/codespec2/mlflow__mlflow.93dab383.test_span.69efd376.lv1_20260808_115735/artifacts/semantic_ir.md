# Semantic IR

## L1. Requirement Obligations

### R1: Trace-to-MLflow-Trace Conversion
- Type: Dataflow
- Statement: `_Trace.to_mlflow_trace()` must convert all LiveSpan objects in `span_dict` into immutable Span objects via `to_immutable_span()`, assemble them into a `TraceData`, call `set_request_response_preview`, and return a `Trace` combining `TraceInfo` and `TraceData`.
- Task Evidence: "Convert the internal _Trace representation to an MLflow Trace object... converts all LiveSpan objects in the span dictionary to immutable Span objects, creates a TraceData container, and sets request/response previews."
- Acceptance: Calling `_Trace.to_mlflow_trace()` on a trace with N LiveSpan entries returns a `Trace` whose `data.spans` contains N `Span` (not `LiveSpan`) instances, and `set_request_response_preview` has been called.
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:_Trace.to_mlflow_trace` (empty body); `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:26-31` (reference implementation); `/testbed/mlflow/entities/trace.py:Trace` (target return type); `/testbed/mlflow/entities/trace_data.py:TraceData` (container).
- Uncertainty: None.

### R2: LiveSpan Deserialization Refusal
- Type: Failure
- Statement: `LiveSpan.from_dict()` must raise `NotImplementedError` because LiveSpan objects require an active OpenTelemetry span context and cannot be reconstructed from serialized data.
- Task Evidence: "This method is not supported for the LiveSpan class as LiveSpan objects represent active, mutable spans... LiveSpan objects cannot be reconstructed from serialized dictionary data because they require an active OpenTelemetry span context and tracing session."
- Acceptance: `LiveSpan.from_dict(data)` always raises `NotImplementedError`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:LiveSpan` (no `from_dict` method defined); `/testbed/libs/skinny/mlflow/entities/span.py:LiveSpan.from_dict` (raises NotImplementedError).
- Uncertainty: None.

### R3: LiveSpan Span-Type Setting
- Type: Behavior
- Statement: `LiveSpan.set_span_type(span_type)` must store the given type string as a span attribute under `SpanAttributeKey.SPAN_TYPE`.
- Task Evidence: "Set the type of the span to categorize its purpose or functionality... The span type is stored as a span attribute and will be visible in trace visualizations."
- Acceptance: After calling `span.set_span_type("LLM")`, the span's attribute `SpanAttributeKey.SPAN_TYPE` returns `"LLM"`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:LiveSpan` (`set_span_type` is missing); `/testbed/libs/skinny/mlflow/entities/span.py:525-527` (reference); `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.SPAN_TYPE`.
- Uncertainty: None.

### R4: LiveSpan-to-Immutable Conversion
- Type: Dataflow
- Statement: `LiveSpan.to_immutable_span()` must return an immutable `Span` wrapping the same underlying OpenTelemetry span, with no data copying.
- Task Evidence: "Convert this LiveSpan instance to an immutable Span object... wraps the underlying OpenTelemetry span object. All state of the live span is already persisted in the OpenTelemetry span object, so no data copying is required."
- Acceptance: `live_span.to_immutable_span()` returns a `Span` instance (not `LiveSpan`) whose `span_id`, `name`, `start_time_ns`, attributes, events, and status match the source LiveSpan.
- Repository Evidence: `/testbed/mlflow/entities/span.py:LiveSpan` (no `to_immutable_span`); `/testbed/libs/skinny/mlflow/entities/span.py:LiveSpan.to_immutable_span` (returns `Span(self._span)`).
- Uncertainty: None.

### R5: NoOpSpan Trace-ID Property
- Type: Interface
- Statement: `NoOpSpan._trace_id` must return `None` (internal property for OpenTelemetry trace ID, distinct from the user-facing `trace_id`).
- Task Evidence: "Since no-op spans don't perform actual tracing operations, this property returns None to indicate the absence of a valid trace ID."
- Acceptance: `NoOpSpan()._trace_id` returns `None`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan._trace_id` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:819-821` (returns None).
- Uncertainty: None.

### R6: NoOpSpan Add-Event No-Op
- Type: SideEffect
- Statement: `NoOpSpan.add_event(event)` must accept a `SpanEvent` argument and perform no operation.
- Task Evidence: "This is a no-operation implementation that does nothing when called. It exists to maintain interface compatibility with the regular Span class."
- Acceptance: `NoOpSpan().add_event(any_event)` does not raise and does not modify any observable state.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.add_event` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:838-839` (pass).
- Uncertainty: None.

### R7: NoOpSpan End No-Op
- Type: SideEffect
- Statement: `NoOpSpan.end(outputs, attributes, status, end_time_ns)` must accept all four optional parameters and perform no operation.
- Task Evidence: "This is a no-operation implementation that does nothing when called. It provides the same interface as the regular span's end method."
- Acceptance: `NoOpSpan().end(outputs={"x": 1}, attributes={"k": "v"}, status="OK")` does not raise.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.end` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:844-851` (pass).
- Uncertainty: None.

### R8: NoOpSpan End-Time Property
- Type: Interface
- Statement: `NoOpSpan.end_time_ns` must return `None`.
- Task Evidence: "Always returns None for no-op spans since they don't track actual timing information."
- Acceptance: `NoOpSpan().end_time_ns` returns `None`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.end_time_ns` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:803-805` (returns None).
- Uncertainty: None.

### R9: NoOpSpan Name Property
- Type: Interface
- Statement: `NoOpSpan.name` must return `None`.
- Task Evidence: "This property returns None for no-op spans... Always returns None since no-op spans don't have actual names."
- Acceptance: `NoOpSpan().name` returns `None`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.name` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:795-797` (returns None).
- Uncertainty: None.

### R10: NoOpSpan Set-Attribute No-Op
- Type: SideEffect
- Statement: `NoOpSpan.set_attribute(key, value)` must accept string key and any value and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called... allowing code to continue executing normally even when span creation fails."
- Acceptance: `NoOpSpan().set_attribute("key", "value")` does not raise.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.set_attribute` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:832-833` (pass).
- Uncertainty: None.

### R11: NoOpSpan Set-Attributes No-Op
- Type: SideEffect
- Statement: `NoOpSpan.set_attributes(attributes)` must accept a dict and perform no operation.
- Task Evidence: "This is a no-operation implementation that accepts attribute assignments but performs no actual work. It allows code to call set_attributes() on a NoOpSpan instance without raising errors."
- Acceptance: `NoOpSpan().set_attributes({"k": "v"})` does not raise.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.set_attributes` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:829-830` (pass).
- Uncertainty: None.

### R12: NoOpSpan Set-Inputs No-Op
- Type: SideEffect
- Statement: `NoOpSpan.set_inputs(inputs)` must accept any value and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called. The NoOpSpan class is used as a fallback when span creation fails."
- Acceptance: `NoOpSpan().set_inputs({"x": 1})` does not raise.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.set_inputs` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:823-824` (pass).
- Uncertainty: None.

### R13: NoOpSpan Set-Outputs No-Op
- Type: SideEffect
- Statement: `NoOpSpan.set_outputs(outputs)` must accept any value and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called... ensuring that user code doesn't break even if tracing is not available."
- Acceptance: `NoOpSpan().set_outputs({"y": 2})` does not raise.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.set_outputs` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:826-827` (pass).
- Uncertainty: None.

### R14: NoOpSpan Set-Status No-Op
- Type: SideEffect
- Statement: `NoOpSpan.set_status(status)` must accept a `SpanStatus` or string and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called... It maintains the same interface as the regular Span.set_status() method."
- Acceptance: `NoOpSpan().set_status(SpanStatus("OK"))` does not raise.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.set_status` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:835-836` (pass).
- Uncertainty: None.

### R15: NoOpSpan Span-ID Property
- Type: Interface
- Statement: `NoOpSpan.span_id` must return `None`.
- Task Evidence: "Always returns None for no-op spans since they don't have actual span IDs."
- Acceptance: `NoOpSpan().span_id` returns `None`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.span_id` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:791-793` (returns None).
- Uncertainty: None.

### R16: NoOpSpan Start-Time Property
- Type: Interface
- Statement: `NoOpSpan.start_time_ns` must return `None`.
- Task Evidence: "Always returns None as no-op spans do not have actual start times."
- Acceptance: `NoOpSpan().start_time_ns` returns `None`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.start_time_ns` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:799-801` (returns None).
- Uncertainty: None.

### R17: NoOpSpan Status Property
- Type: Interface
- Statement: `NoOpSpan.status` must return `None`.
- Task Evidence: "Always returns None since this is a no-operation span that doesn't track actual status information."
- Acceptance: `NoOpSpan().status` returns `None`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NoOpSpan.status` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:815-817` (returns None).
- Uncertainty: None.

### R18: NoOpSpan Trace-ID Property
- Type: Interface
- Statement: `NoOpSpan.trace_id` must return the constant `NO_OP_SPAN_TRACE_ID` (`"MLFLOW_NO_OP_SPAN_TRACE_ID"`).
- Task Evidence: "Returns: str: A special constant trace ID 'MLFLOW_NO_OP_SPAN_TRACE_ID' that distinguishes no-op spans from real spans."
- Acceptance: `NoOpSpan().trace_id` returns `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:NO_OP_SPAN_TRACE_ID` (defined line 758); `/testbed/mlflow/entities/span.py:NoOpSpan.trace_id` (inherits from Span which uses `get_attribute`); `/testbed/libs/skinny/mlflow/entities/span.py:784-789` (overrides to return constant).
- Uncertainty: None.

### R19: Span Attributes Property
- Type: Interface
- Statement: `Span.attributes` must return a `dict[str, Any]` of all span attributes, deserialized from their internal JSON representation.
- Task Evidence: "Get all attributes of the span... The attributes are automatically deserialized from their internal JSON string representation to their original Python objects when accessed... For immutable spans, the attributes are cached."
- Acceptance: `span.attributes` returns a dict with all attribute keys mapped to deserialized Python values; repeated calls return the same structure.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.attributes` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:186-195` (uses `_attributes.get_all()`); `/testbed/mlflow/entities/span.py:_CachedSpanAttributesRegistry`.
- Uncertainty: None. `_SpanAttributesRegistry.get_all()` must also be added to support this.

### R20: Span Events Property
- Type: Interface
- Statement: `Span.events` must return `list[SpanEvent]` containing all span events converted from OpenTelemetry internal `BoundedAttributes` format to plain `dict`.
- Task Evidence: "Get all events of the span... The returned events are converted from OpenTelemetry's internal BoundedAttributes format to simple dictionaries to ensure proper serialization."
- Acceptance: `span.events` returns a list of `SpanEvent` objects with plain dict attributes; returns empty list if no events.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.events` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:198-210`; `/testbed/mlflow/entities/span_event.py:SpanEvent`.
- Uncertainty: None.

### R21: Span From-OTel-Proto Construction
- Type: Dataflow
- Statement: `Span.from_otel_proto(otel_proto_span, location_id)` must construct a `Span` from an OpenTelemetry protobuf span, converting trace/span IDs from bytes, mapping status codes, generating MLflow trace IDs (v4 if location_id given), and serializing all attribute values.
- Task Evidence: "Create a Span from an OpenTelemetry protobuf span... converts an OpenTelemetry protobuf span message into an MLflow Span object by extracting all relevant span data including trace/span IDs, timing information, attributes, events, and status."
- Acceptance: `Span.from_otel_proto(valid_proto_span)` returns a `Span` with correct trace_id (prefixed with `tr-`), span_id in hex, all attributes serialized as JSON strings, events preserved, and status mapped from OTel proto status codes.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.from_otel_proto` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:365-420` (reference); `/testbed/mlflow/tracing/utils/__init__.py:generate_mlflow_trace_id_from_otel_trace_id`, `generate_trace_id_v4_from_otel_trace_id`; `/testbed/mlflow/tracing/utils/otlp.py:_otel_proto_bytes_to_id` (missing in mlflow/, present in libs/skinny).
- Uncertainty: `_otel_proto_bytes_to_id` helper must be added to `/testbed/mlflow/tracing/utils/otlp.py`.

### R22: Span Request-ID Property (Deprecated Alias)
- Type: Compatibility
- Statement: `Span.request_id` must return the same value as `Span.trace_id`, serving as a backward-compatibility alias.
- Task Evidence: "The request ID of the span, which is an alias for the trace ID. This property provides backward compatibility for code that uses the deprecated request_id attribute."
- Acceptance: `span.request_id == span.trace_id`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.request_id` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:120-123`.
- Uncertainty: None.

### R23: Span Span-Type Property
- Type: Interface
- Statement: `Span.span_type` must return the span type string from the attribute `SpanAttributeKey.SPAN_TYPE`.
- Task Evidence: "The type of the span... returns the span type as a string, which categorizes the kind of operation or component that the span represents. The span type is stored as an attribute with the key defined in SpanAttributeKey.SPAN_TYPE."
- Acceptance: After `LiveSpan` sets `span_type="LLM"` and converts to immutable, `span.span_type` returns `"LLM"`. Returns `None` if no type was set.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.span_type` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:169-172`; `/testbed/mlflow/tracing/constant.py:SpanAttributeKey.SPAN_TYPE`.
- Uncertainty: None.

### R24: Span To-Dict Serialization
- Type: Dataflow
- Statement: `Span.to_dict()` must serialize the span into a dictionary with base64-encoded trace_id/span_id/parent_span_id (using int→bytes→base64 encoding), timing in nanoseconds, events list, status dict with OTel proto code name, and all attributes with their serialized values.
- Task Evidence: "Convert the span to a dictionary representation... The trace_id, span_id, and parent_span_id are encoded as base64 strings for safe serialization... For trace_id conversion: convert the integer to exactly 16 bytes using big-endian byte order... For span_id and parent_span_id: convert the integer to exactly 8 bytes using big-endian byte order..."
- Acceptance: `span.to_dict()` produces a dict with keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`. The ID fields are base64-encoded strings. Round-trip through `Span.from_dict(span.to_dict())` reconstructs an equivalent span.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.to_dict` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:230-262` (reference); `/testbed/libs/skinny/mlflow/entities/span.py:_encode_trace_id_to_byte`, `_encode_span_id_to_byte`, `_encode_bytes_to_base64`.
- Uncertainty: The helper functions `_encode_trace_id_to_byte`, `_encode_span_id_to_byte`, `_encode_bytes_to_base64`, `_decode_id_from_byte`, and `_is_base64_encoded` are referenced in the existing `from_dict` but are missing from `/testbed/mlflow/entities/span.py`.

### R25: Span To-OTel-Proto Conversion
- Type: Dataflow
- Statement: `Span.to_otel_proto()` must convert the span to an OpenTelemetry protobuf `Span` message with trace_id/span_id as hex bytes, timing, parent span, status, all attributes via `_set_otel_proto_anyvalue`, and all events.
- Task Evidence: "Convert to OpenTelemetry protobuf span format for OTLP export... transforms the MLflow Span object into an OpenTelemetry protobuf Span message."
- Acceptance: `span.to_otel_proto()` returns an `OTelProtoSpan` protobuf message with correct fields populated. The protobuf can be serialized for OTLP export.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.to_otel_proto` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:422-453` (reference); `/testbed/mlflow/tracing/utils/otlp.py:_set_otel_proto_anyvalue`; `/testbed/mlflow/entities/span_status.py:SpanStatus.to_otel_proto_status`.
- Uncertainty: `SpanStatus.to_otel_proto_status()` method needed — check if exists in `/testbed/mlflow/entities/span_status.py`.

### R26: CachedSpanAttributesRegistry Set Prevention
- Type: Failure
- Statement: `_CachedSpanAttributesRegistry.set(key, value)` must raise `MlflowException` with `INVALID_PARAMETER_VALUE` error code, because cached spans are immutable.
- Task Evidence: "Always raised since this method is not supported for immutable spans. The cached registry is designed for read-only access to persisted span attributes and does not allow modifications to maintain data integrity."
- Acceptance: Calling `set()` on a `_CachedSpanAttributesRegistry` instance raises `MlflowException` with error code `INVALID_PARAMETER_VALUE`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:_CachedSpanAttributesRegistry.set` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:905-908`.
- Uncertainty: None.

### R27: Create-MLflow-Span Factory Function
- Type: Dataflow
- Statement: `create_mlflow_span(otel_span, trace_id, span_type)` must return `NoOpSpan` for `None` or `NonRecordingSpan`, `LiveSpan` for active `OTelSpan`, `Span` for finished `OTelReadableSpan`, or raise `MlflowException` for invalid types.
- Task Evidence: "Create an MLflow span object from an OpenTelemetry span. This factory function creates the appropriate MLflow span object based on the type of the input OpenTelemetry span."
- Acceptance: `create_mlflow_span(None, "trace-1")` returns `NoOpSpan`; `create_mlflow_span(active_otel_span, "trace-1", "LLM")` returns `LiveSpan`; `create_mlflow_span(readable_span, "trace-1")` returns `Span`; invalid input raises `MlflowException(INVALID_PARAMETER_VALUE)`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:create_mlflow_span` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:66-88` (reference).
- Uncertainty: None.

### R28: OTLP AnyValue Decoding
- Type: Dataflow
- Statement: `_decode_otel_proto_anyvalue(pb_any_value)` must recursively decode an OpenTelemetry `AnyValue` protobuf message into its Python equivalent: `None` for unset, `bool`, `str`, `int`, `float`, `bytes`, `list` for arrays (recursive), `dict` for kvlist (recursive).
- Task Evidence: "Decode an OpenTelemetry protobuf AnyValue message into a Python object... recursively converts an OpenTelemetry AnyValue protobuf message into its corresponding Python representation."
- Acceptance: `_decode_otel_proto_anyvalue(AnyValue(string_value="hello"))` returns `"hello"`; `_decode_otel_proto_anyvalue(AnyValue(int_value=42))` returns `42`; `_decode_otel_proto_anyvalue(AnyValue(array_value=...))` returns Python list; `_decode_otel_proto_anyvalue(AnyValue(kvlist_value=...))` returns Python dict.
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py:_decode_otel_proto_anyvalue` (missing); `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:154-170` (reference).
- Uncertainty: None.

### R29: Span-to-Dict ↔ From-Dict Round-Trip Compatibility
- Type: Compatibility
- Statement: The serialization format produced by `Span.to_dict()` must be parseable by `Span.from_dict()`, supporting at least v2 and v3 schemas with base64-encoded IDs.
- Task Evidence: "Handle multiple serialization schemas (v2, v3) for backward compatibility... This dictionary format is compatible with the from_dict class method for round-trip conversion."
- Acceptance: `Span.from_dict(span.to_dict())` produces a `Span` with equivalent trace_id, span_id, name, timing, attributes, events, and status.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.from_dict` (already implemented, lines 258-329); `/testbed/mlflow/entities/span.py:Span.to_dict` (missing); `/testbed/mlflow/entities/span.py:from_dict_v2` (missing in /testbed/mlflow/ but present in libs/skinny).
- Uncertainty: `_is_span_v2_schema` and `from_dict_v2` static/class methods are used by the existing `from_dict` but are missing.

## L2. Functional Design Graph

### N1: _Trace (Internal Trace State)
- Kind: State
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:21-24`

### N2: to_mlflow_trace (Method on _Trace)
- Kind: Method
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:_Trace.to_mlflow_trace` (declared but empty)

### N3: Trace
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace.py:24`

### N4: TraceData
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_data.py:10`

### N5: set_request_response_preview
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/truncation.py` (referenced by skinny trace_manager)

### N6: LiveSpan
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:484`

### N7: Span (Immutable)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:91`

### N8: NoOpSpan
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:761`

### N9: create_mlflow_span
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/entities/span.py` (missing); `/testbed/libs/skinny/mlflow/entities/span.py:66-88`

### N10: SpanEvent
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/span_event.py:10`

### N11: SpanStatus / SpanStatusCode
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/span_status.py`

### N12: _SpanAttributesRegistry
- Kind: State
- Repository Evidence: `/testbed/mlflow/entities/span.py:854`

### N13: _CachedSpanAttributesRegistry
- Kind: State
- Repository Evidence: `/testbed/mlflow/entities/span.py:892`

### N14: OTelProtoSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:7` (imported from opentelemetry proto)

### N15: OTelReadableSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:11` (imported)

### N16: OTelSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:13` (imported)

### N17: NonRecordingSpan
- Kind: External
- Repository Evidence: `/testbed/mlflow/entities/span.py:12` (imported)

### N18: AnyValue (OTel Proto)
- Kind: External
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py:8` (imported)

### N19: encode_span_id / encode_trace_id / decode_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py:129-150`

### N20: generate_mlflow_trace_id_from_otel_trace_id / generate_trace_id_v4_from_otel_trace_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py:295-320`

### N21: build_otel_context
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py`

### N22: dump_span_attribute_value
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py`

### N23: _set_otel_proto_anyvalue
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py:122`

### N24: _decode_otel_proto_anyvalue
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py` (missing); `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:154`

### N25: _otel_proto_bytes_to_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py` (missing); `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:122`

### N26: apply_span_processors
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/processor.py` (missing); `/testbed/libs/skinny/mlflow/tracing/utils/processor.py:8`

### N27: InMemoryTraceManager
- Kind: Class
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:52`

### N28: _encode_trace_id_to_byte / _encode_span_id_to_byte / _encode_bytes_to_base64 / _decode_id_from_byte / _is_base64_encoded
- Kind: Function
- Repository Evidence: `/testbed/mlflow/entities/span.py` (missing, used by from_dict); `/testbed/libs/skinny/mlflow/entities/span.py:456-481`

### E1: InMemoryTraceManager.pop_trace -> _Trace.to_mlflow_trace
- Kind: CALL
- Condition: When `pop_trace` has a valid internal trace
- Transfer: Returns `ManagerTrace` wrapping the result of `to_mlflow_trace()`
- Evidence: `/testbed/mlflow/tracing/trace_manager.py:183-187`
- Obligations: R1

### E2: _Trace.to_mlflow_trace -> LiveSpan.to_immutable_span
- Kind: CALL
- Condition: For each LiveSpan in span_dict.values()
- Transfer: Converts mutable LiveSpan to immutable Span
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:27-29`
- Obligations: R1, R4

### E3: _Trace.to_mlflow_trace -> TraceData
- Kind: DATA
- Condition: Always
- Transfer: Populates TraceData.spans with immutable Span list
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:26-30`
- Obligations: R1

### E4: _Trace.to_mlflow_trace -> set_request_response_preview
- Kind: CALL
- Condition: Always
- Transfer: Sets request/response previews on TraceInfo
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:31`
- Obligations: R1

### E5: _Trace.to_mlflow_trace -> Trace
- Kind: DATA
- Condition: Always
- Transfer: Constructs and returns Trace(info, trace_data)
- Evidence: `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:32`
- Obligations: R1

### E6: create_mlflow_span -> NoOpSpan
- Kind: CONTROL
- Condition: otel_span is None or isinstance NonRecordingSpan
- Transfer: Returns NoOpSpan() for graceful failure
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:75-76`
- Obligations: R27

### E7: create_mlflow_span -> LiveSpan
- Kind: CONTROL
- Condition: isinstance(otel_span, OTelSpan)
- Transfer: Returns LiveSpan(otel_span, trace_id, span_type)
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:78-79`
- Obligations: R27

### E8: create_mlflow_span -> Span
- Kind: CONTROL
- Condition: isinstance(otel_span, OTelReadableSpan)
- Transfer: Returns Span(otel_span)
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:81-82`
- Obligations: R27

### E9: LiveSpan.set_span_type -> _SpanAttributesRegistry.set
- Kind: CALL
- Condition: Always
- Transfer: Stores span_type string under SpanAttributeKey.SPAN_TYPE
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:525-527`
- Obligations: R3

### E10: LiveSpan.from_dict -> NotImplementedError
- Kind: CONTROL
- Condition: Always
- Transfer: Raises NotImplementedError
- Evidence: Task doc
- Obligations: R2

### E11: LiveSpan.to_immutable_span -> Span.__init__
- Kind: CALL
- Condition: Always
- Transfer: Wraps self._span in Span constructor
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py` (LiveSpan.to_immutable_span)
- Obligations: R4

### E12: NoOpSpan.trace_id -> NO_OP_SPAN_TRACE_ID
- Kind: DATA
- Condition: Always
- Transfer: Returns constant string
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:784-789`
- Obligations: R18

### E13: NoOpSpan (all no-op methods)
- Kind: CONTROL
- Condition: Always
- Transfer: Each method (add_event, end, set_attribute, set_attributes, set_inputs, set_outputs, set_status) returns None / pass
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:823-851`
- Obligations: R6, R7, R10, R11, R12, R13, R14

### E14: NoOpSpan property getters -> None
- Kind: DATA
- Condition: Always
- Transfer: _trace_id, end_time_ns, name, span_id, start_time_ns, status all return None
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:791-821`
- Obligations: R5, R8, R9, R15, R16, R17

### E15: Span.attributes -> _CachedSpanAttributesRegistry.get_all
- Kind: CALL
- Condition: Always
- Transfer: Returns deserialized dict of all attributes
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:186-195`
- Obligations: R19

### E16: Span.events -> SpanEvent list
- Kind: DATA
- Condition: Always
- Transfer: Converts OTel events to SpanEvent with plain dict attributes
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:198-210`
- Obligations: R20

### E17: Span.from_otel_proto -> _otel_proto_bytes_to_id
- Kind: CALL
- Condition: Always
- Transfer: Converts trace_id/span_id bytes to int
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:371-375`
- Obligations: R21

### E18: Span.from_otel_proto -> _decode_otel_proto_anyvalue
- Kind: CALL
- Condition: For each attribute and event attribute
- Transfer: Decodes OTel AnyValue proto to Python objects
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:401-402,411-412`
- Obligations: R21, R28

### E19: Span.from_otel_proto -> generate_mlflow_trace_id_from_otel_trace_id / generate_trace_id_v4_from_otel_trace_id
- Kind: CALL
- Condition: Based on whether location_id is provided
- Transfer: Generates properly prefixed MLflow trace ID
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:385-389`
- Obligations: R21

### E20: Span.request_id -> Span.trace_id
- Kind: DATA
- Condition: Always
- Transfer: Delegates to trace_id property
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:120-123`
- Obligations: R22

### E21: Span.span_type -> Span.get_attribute
- Kind: CALL
- Condition: Always
- Transfer: Returns attribute under SpanAttributeKey.SPAN_TYPE
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:169-172`
- Obligations: R23

### E22: Span.to_dict -> _encode_trace_id_to_byte / _encode_span_id_to_byte / _encode_bytes_to_base64
- Kind: CALL
- Condition: Always
- Transfer: Converts int IDs to base64-encoded strings
- Evidence: Task doc (encoding spec); `/testbed/libs/skinny/mlflow/entities/span.py:230-262`
- Obligations: R24, R29

### E23: Span.to_otel_proto -> _set_otel_proto_anyvalue
- Kind: CALL
- Condition: For each attribute key-value pair
- Transfer: Sets OTel proto AnyValue fields
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:444-447`
- Obligations: R25

### E24: Span.to_otel_proto -> SpanEvent.to_otel_proto
- Kind: CALL
- Condition: For each event
- Transfer: Converts MLflow SpanEvent to OTel proto event
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:449-451`
- Obligations: R25

### E25: _CachedSpanAttributesRegistry.set -> MlflowException
- Kind: CONTROL
- Condition: Always
- Transfer: Raises MlflowException(INVALID_PARAMETER_VALUE)
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:905-908`
- Obligations: R26

### E26: _decode_otel_proto_anyvalue -> (recursive self)
- Kind: CALL
- Condition: When value_type is array_value or kvlist_value
- Transfer: Recursively decodes nested structures
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:154-170`
- Obligations: R28

## L3. Verifiable Contracts

### C1: _Trace.to_mlflow_trace Returns Trace with Immutable Spans
- Type: Behavior
- Subject: `_Trace.to_mlflow_trace()`
- Relation: TYPE_IS
- Expected: Returns `Trace` where `data.spans` elements are all `Span` (not `LiveSpan`)
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:26-32`; `/testbed/tests/tracing/test_trace_manager.py:69-70` (assert isinstance spans[0], Span)
- Observe: RETURN_VALUE
- Target: `_Trace(...).to_mlflow_trace()`
- Obligations: R1, R4
- Graph: N2, E1, E2, E3, E4, E5

### C2: LiveSpan.from_dict Raises NotImplementedError
- Type: Failure
- Subject: `LiveSpan.from_dict(data)`
- Relation: RAISES
- Expected: `NotImplementedError`
- Evidence: Task doc
- Observe: EXCEPTION
- Target: `LiveSpan.from_dict({})`
- Obligations: R2
- Graph: N6, E10

### C3: LiveSpan.set_span_type Stores Attribute
- Type: State
- Subject: `LiveSpan.set_span_type("LLM")`
- Relation: EQ
- Expected: `span.get_attribute(SpanAttributeKey.SPAN_TYPE) == "LLM"`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:525-527`
- Observe: FIELD_READ
- Target: `span.get_attribute("mlflow.spanType")`
- Obligations: R3
- Graph: N6, E9, N12

### C4: LiveSpan.to_immutable_span Returns Span Instance
- Type: Interface
- Subject: `LiveSpan.to_immutable_span()`
- Relation: TYPE_IS
- Expected: Returns `Span` (not `LiveSpan`), with same span_id, name, attributes, events, status
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py` (LiveSpan.to_immutable_span)
- Observe: RETURN_VALUE
- Target: `live_span.to_immutable_span()`
- Obligations: R4
- Graph: N6, E11, N7

### C5: NoOpSpan._trace_id Returns None
- Type: Interface
- Subject: `NoOpSpan()._trace_id`
- Relation: EQ
- Expected: `None`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:819-821`
- Observe: RETURN_VALUE
- Target: `NoOpSpan()._trace_id`
- Obligations: R5
- Graph: N8, E14

### C6: NoOpSpan.add_event Is Silent No-Op
- Type: SideEffect
- Subject: `NoOpSpan().add_event(event)`
- Relation: UNCHANGED
- Expected: No exception, no state change
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:838-839`
- Observe: SIDE_EFFECT
- Target: `NoOpSpan().add_event(SpanEvent("test"))`
- Obligations: R6
- Graph: N8, E13

### C7: NoOpSpan.end Is Silent No-Op
- Type: SideEffect
- Subject: `NoOpSpan().end(outputs={}, attributes={}, status="OK")`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:844-851`
- Observe: SIDE_EFFECT
- Target: `NoOpSpan().end()`
- Obligations: R7
- Graph: N8, E13

### C8: NoOpSpan.end_time_ns Returns None
- Type: Interface
- Subject: `NoOpSpan().end_time_ns`
- Relation: EQ
- Expected: `None`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:803-805`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().end_time_ns`
- Obligations: R8
- Graph: N8, E14

### C9: NoOpSpan.name Returns None
- Type: Interface
- Subject: `NoOpSpan().name`
- Relation: EQ
- Expected: `None`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:795-797`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().name`
- Obligations: R9
- Graph: N8, E14

### C10: NoOpSpan.set_attribute Is No-Op
- Type: SideEffect
- Subject: `NoOpSpan().set_attribute("k", "v")`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:832-833`
- Observe: SIDE_EFFECT
- Target: `NoOpSpan().set_attribute("key", "value")`
- Obligations: R10
- Graph: N8, E13

### C11: NoOpSpan.set_attributes Is No-Op
- Type: SideEffect
- Subject: `NoOpSpan().set_attributes({"k": "v"})`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:829-830`
- Observe: SIDE_EFFECT
- Target: `NoOpSpan().set_attributes({"key": "value"})`
- Obligations: R11
- Graph: N8, E13

### C12: NoOpSpan.set_inputs Is No-Op
- Type: SideEffect
- Subject: `NoOpSpan().set_inputs({"x": 1})`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:823-824`
- Observe: SIDE_EFFECT
- Target: `NoOpSpan().set_inputs({"x": 1})`
- Obligations: R12
- Graph: N8, E13

### C13: NoOpSpan.set_outputs Is No-Op
- Type: SideEffect
- Subject: `NoOpSpan().set_outputs({"y": 2})`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:826-827`
- Observe: SIDE_EFFECT
- Target: `NoOpSpan().set_outputs({"y": 2})`
- Obligations: R13
- Graph: N8, E13

### C14: NoOpSpan.set_status Is No-Op
- Type: SideEffect
- Subject: `NoOpSpan().set_status(SpanStatus("OK"))`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:835-836`
- Observe: SIDE_EFFECT
- Target: `NoOpSpan().set_status(SpanStatus("OK"))`
- Obligations: R14
- Graph: N8, E13

### C15: NoOpSpan.span_id Returns None
- Type: Interface
- Subject: `NoOpSpan().span_id`
- Relation: EQ
- Expected: `None`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:791-793`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().span_id`
- Obligations: R15
- Graph: N8, E14

### C16: NoOpSpan.start_time_ns Returns None
- Type: Interface
- Subject: `NoOpSpan().start_time_ns`
- Relation: EQ
- Expected: `None`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:799-801`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().start_time_ns`
- Obligations: R16
- Graph: N8, E14

### C17: NoOpSpan.status Returns None
- Type: Interface
- Subject: `NoOpSpan().status`
- Relation: EQ
- Expected: `None`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:815-817`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().status`
- Obligations: R17
- Graph: N8, E14

### C18: NoOpSpan.trace_id Returns Constant
- Type: Interface
- Subject: `NoOpSpan().trace_id`
- Relation: EQ
- Expected: `"MLFLOW_NO_OP_SPAN_TRACE_ID"`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:784-789`; `/testbed/mlflow/entities/span.py:758`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().trace_id`
- Obligations: R18
- Graph: N8, E12

### C19: Span.attributes Returns Deserialized Dict
- Type: Interface
- Subject: `span.attributes`
- Relation: TYPE_IS
- Expected: `dict[str, Any]` with all keys from underlying OTel span attributes, values JSON-deserialized
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:186-195`
- Observe: RETURN_VALUE
- Target: `Span(otel_readable_span).attributes`
- Obligations: R19
- Graph: N7, E15, N13

### C20: Span.events Returns SpanEvent List
- Type: Interface
- Subject: `span.events`
- Relation: TYPE_IS
- Expected: `list[SpanEvent]`, each with plain dict attributes (not BoundedAttributes), empty list if none
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:198-210`; `/testbed/tests/entities/test_span_event.py`
- Observe: RETURN_VALUE
- Target: `Span(otel_readable_span).events`
- Obligations: R20
- Graph: N7, E16, N10

### C21: Span.from_otel_proto Constructs Span
- Type: Dataflow
- Subject: `Span.from_otel_proto(proto_span)`
- Relation: TYPE_IS
- Expected: Returns `Span` with trace_id prefixed `tr-`, correct span_id in hex, attributes serialized as JSON strings
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:365-420`; `/testbed/tests/tracing/otel/test_span_translation.py`
- Observe: RETURN_VALUE
- Target: `Span.from_otel_proto(otel_proto_span)`
- Obligations: R21, R28
- Graph: N7, E17, E18, E19, N14, N24, N25

### C22: Span.request_id Equals trace_id
- Type: Interface
- Subject: `span.request_id`
- Relation: EQ
- Expected: `span.trace_id` (same value)
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:120-123`
- Observe: RETURN_VALUE
- Target: `span.request_id`
- Obligations: R22
- Graph: N7, E20

### C23: Span.span_type Returns Stored Type
- Type: Interface
- Subject: `span.span_type`
- Relation: EQ
- Expected: Value stored under `SpanAttributeKey.SPAN_TYPE`, or `None` if not set
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:169-172`; `/testbed/tests/tracing/otel/test_span_translation.py:19-69`
- Observe: RETURN_VALUE
- Target: `span.span_type`
- Obligations: R23
- Graph: N7, E21

### C24: Span.to_dict Produces Correct Schema
- Type: Dataflow
- Subject: `span.to_dict()`
- Relation: CONTAINS
- Expected: Dict with keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`. trace_id encoded as base64 of 16-byte big-endian int. span_id/parent_span_id as base64 of 8-byte big-endian int.
- Evidence: Task doc (encoding spec); `/testbed/libs/skinny/mlflow/entities/span.py:230-262`; `/testbed/mlflow/entities/span.py:258-329` (from_dict consumes this format)
- Observe: RETURN_VALUE
- Target: `span.to_dict()`
- Obligations: R24, R29
- Graph: N7, E22, N28

### C25: Span.to_otel_proto Returns OTelProtoSpan
- Type: Dataflow
- Subject: `span.to_otel_proto()`
- Relation: TYPE_IS
- Expected: `OTelProtoSpan` with trace_id/span_id as bytes, correct name, timing, parent_span_id, status, attributes, events
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:422-453`; `/testbed/mlflow/entities/trace.py:170` (to_proto uses to_otel_proto)
- Observe: RETURN_VALUE
- Target: `span.to_otel_proto()`
- Obligations: R25
- Graph: N7, E23, E24, N14, N23

### C26: _CachedSpanAttributesRegistry.set Raises MlflowException
- Type: Failure
- Subject: `_CachedSpanAttributesRegistry(...).set("key", "value")`
- Relation: RAISES
- Expected: `MlflowException` with error code `INVALID_PARAMETER_VALUE`
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:905-908`
- Observe: EXCEPTION
- Target: `cached_registry.set("k", "v")`
- Obligations: R26
- Graph: N13, E25

### C27: create_mlflow_span Dispatches Correctly
- Type: Behavior
- Subject: `create_mlflow_span(otel_span, trace_id, span_type)`
- Relation: TYPE_IS
- Expected: `NoOpSpan` for None/NonRecordingSpan; `LiveSpan` for OTelSpan; `Span` for OTelReadableSpan; `MlflowException` for invalid
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/entities/span.py:66-88`
- Observe: RETURN_VALUE
- Target: `create_mlflow_span(otel_span, "trace-id", "LLM")`
- Obligations: R27
- Graph: N9, E6, E7, E8, N6, N7, N8, N16, N17

### C28: _decode_otel_proto_anyvalue Decodes All Types
- Type: Dataflow
- Subject: `_decode_otel_proto_anyvalue(pb_any_value)`
- Relation: EQ
- Expected: `None` for unset; `True` for bool_value; `"hello"` for string_value; `42` for int_value; `3.14` for double_value; `b"data"` for bytes_value; `list` for array_value (recursive); `dict` (str→value) for kvlist_value (recursive)
- Evidence: Task doc; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:154-170`
- Observe: RETURN_VALUE
- Target: `_decode_otel_proto_anyvalue(any_value)`
- Obligations: R28
- Graph: N24, E26, N18

### C29: Span.to_dict Round-Trip Through from_dict
- Type: Dataflow
- Subject: `Span.from_dict(span.to_dict())`
- Relation: PRESERVE
- Expected: Result has equivalent trace_id, span_id, name, start_time_ns, end_time_ns, attributes, events, status to the original span
- Evidence: Task doc; `/testbed/mlflow/entities/span.py:258-329` (existing from_dict); `/testbed/libs/skinny/mlflow/entities/span.py:230-262` (to_dict reference)
- Observe: RETURN_VALUE
- Target: `Span.from_dict(original_span.to_dict())`
- Obligations: R24, R29
- Graph: N7, E22, N28
