# Semantic IR

## L1. Requirement Obligations

### R1: assessment_to_proto — Convert Assessment entity to protobuf Assessment
- **Type:** Dataflow
- **Statement:** Given an Assessment entity with fields (name, trace_id, source, create_time_ms, last_update_time_ms, and optionally span_id, rationale, assessment_id, expectation, feedback, metadata, overrides, valid), the function MUST produce a `pb.Assessment` protobuf message with all non-None fields populated, timestamps converted via `FromMilliseconds()`, metadata converted to string key-value pairs, and `trace_location` populated from trace_id parsing for UC Schema locations.
- **Task Evidence:** "Convert an Assessment entity to its corresponding protobuf representation."
- **Acceptance:** Call with a fully populated Assessment returns a `pb.Assessment` with `assessment_name`, `trace_id`, `source`, `create_time`, `last_update_time` set; optional fields set only when non-None; `trace_location` populated when trace_id is v4 format.
- **Repository Evidence:** `/testbed/mlflow/store/tracking/databricks_rest_store.py:511` calls `assessment_to_proto(assessment)`.
- **Uncertainty:** None.

### R2: get_trace_id_from_assessment_proto — Extract trace ID from assessment proto
- **Type:** Dataflow
- **Statement:** Given a `pb.Assessment` or `assessments_pb2.Assessment` protobuf, the function MUST return the trace ID string—for UC Schema locations it constructs a v4 trace ID using `construct_trace_id_v4`; otherwise it returns the proto's raw `trace_id`.
- **Task Evidence:** "Extract the trace ID from an assessment protocol buffer object."
- **Acceptance:** For a proto without `trace_location.uc_schema`, returns `proto.trace_id`; for a proto with UC Schema location, returns constructed v4 trace ID.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:288,426` calls `get_trace_id_from_assessment_proto(proto)` from `Expectation.from_proto` and `Feedback.from_proto`.
- **Uncertainty:** None.

### R3: inference_table_location_to_proto — Convert InferenceTableLocation to proto
- **Type:** Dataflow
- **Statement:** Given an `InferenceTableLocation` entity with `full_table_name`, the function MUST produce a `pb.InferenceTableLocation` protobuf with `full_table_name` set.
- **Task Evidence:** "Convert an InferenceTableLocation object to its corresponding protobuf representation."
- **Acceptance:** Call returns `pb.InferenceTableLocation(full_table_name=…)` matching the input.
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py:14` imports `InferenceTableLocation`; `/testbed/mlflow/entities/trace_location.py:58-62` has existing `to_proto` on `InferenceTableLocation` class.
- **Uncertainty:** None.

### R4: mlflow_experiment_location_to_proto — Convert MlflowExperimentLocation to proto
- **Type:** Dataflow
- **Statement:** Given an `MlflowExperimentLocation` entity with `experiment_id`, the function MUST produce a `pb.MlflowExperimentLocation` protobuf with `experiment_id` set.
- **Task Evidence:** "Convert an MlflowExperimentLocation object to its corresponding protobuf representation."
- **Acceptance:** Call returns `pb.MlflowExperimentLocation(experiment_id=…)` matching the input.
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py:15` imports `MlflowExperimentLocation`; `/testbed/mlflow/entities/trace_location.py:51-52` has existing `to_proto` on `MlflowExperimentLocation`.
- **Uncertainty:** None.

### R5: trace_from_proto — Convert protobuf Trace to MLflow Trace entity
- **Type:** Dataflow
- **Statement:** Given a `pb.Trace` protobuf with `trace_info` and `spans` fields, and a `location_id` string, the function MUST produce a `Trace` entity with `TraceInfo.from_proto(proto.trace_info)` and `TraceData` containing spans converted via `Span.from_otel_proto(span, location_id)`.
- **Task Evidence:** "Convert a protobuf Trace message to an MLflow Trace entity."
- **Acceptance:** Call returns `Trace(info=TraceInfo, data=TraceData(spans=[Span, ...]))`.
- **Repository Evidence:** `/testbed/mlflow/store/tracking/databricks_rest_store.py:189` calls `trace_from_proto(proto, location)`; `/testbed/mlflow/entities/trace.py:158-160` has `Trace.from_proto` that also calls `Span.from_otel_proto`.
- **Uncertainty:** None.

### R6: trace_info_to_v4_proto — Convert TraceInfo to v4 protobuf TraceInfo
- **Type:** Dataflow
- **Statement:** Given a `TraceInfo` entity, the function MUST produce a `pb.TraceInfo` protobuf with parsed trace_id (using `parse_trace_id_v4` for UC Schema), converted trace_location, timestamps, durations, truncated metadata/tags, and assessments converted via `assessment_to_proto`.
- **Task Evidence:** "Convert a TraceInfo object to its v4 protocol buffer representation."
- **Acceptance:** Call returns `pb.TraceInfo` with `trace_id`, `trace_location`, `request_time` (Timestamp), `execution_duration` (Duration if not None), `state`, `trace_metadata`, `tags`, `assessments`.
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info.py:103` calls `trace_info_to_v4_proto(self)` when `_is_v4()` is True; `/testbed/mlflow/entities/trace_info_v2.py:7,19` imports truncation helpers.
- **Uncertainty:** None.

### R7: trace_location_from_proto — Convert protobuf TraceLocation to entity
- **Type:** Dataflow
- **Statement:** Given a `pb.TraceLocation` protobuf, the function MUST return a `TraceLocation` entity with the correct type and identifier, handling UC_SCHEMA (via `uc_schema_location_from_proto`), MLFLOW_EXPERIMENT (via `MlflowExperimentLocation.from_proto`), and INFERENCE_TABLE (via `InferenceTableLocation.from_proto`). Falls back to `TRACE_LOCATION_TYPE_UNSPECIFIED` when no identifier is set.
- **Task Evidence:** "Convert a protobuf TraceLocation message to a TraceLocation entity object."
- **Acceptance:** Call with each location type proto returns correct typed `TraceLocation` entity.
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:246` calls `trace_location_from_proto(proto)` from `TraceLocation.from_proto`.
- **Uncertainty:** None.

### R8: trace_location_to_proto — Convert TraceLocation entity to proto
- **Type:** Dataflow
- **Statement:** Given a `TraceLocation` entity with type one of `UC_SCHEMA`, `MLFLOW_EXPERIMENT`, or `INFERENCE_TABLE`, the function MUST produce a `pb.TraceLocation` protobuf with type set and the appropriate location sub-message populated. Raises `ValueError` for unsupported types.
- **Task Evidence:** "Convert a TraceLocation object to its corresponding protobuf representation."
- **Acceptance:** Call returns `pb.TraceLocation(type=..., uc_schema=...|mlflow_experiment=...|inference_table=...)`.
- **Repository Evidence:** `/testbed/mlflow/store/tracking/databricks_rest_store.py:290,294,558` calls `trace_location_to_proto(...)`.
- **Uncertainty:** None.

### R9: trace_to_proto — Convert Trace entity to protobuf Trace
- **Type:** Dataflow
- **Statement:** Given a `Trace` entity with `info` (TraceInfo) and `data` (TraceData with spans), the function MUST produce a `pb.Trace` protobuf with `trace_info` (via `trace_info.to_proto()`) and `spans` (via `span.to_otel_proto()` for each span).
- **Task Evidence:** "Convert a Trace object to its corresponding protobuf representation."
- **Acceptance:** Call returns `pb.Trace(trace_info=..., spans=[...])`.
- **Repository Evidence:** `/testbed/mlflow/entities/trace.py:153-157` has `Trace.to_proto()` that returns `ProtoTrace(trace_info=..., spans=...)`; `/testbed/mlflow/entities/span.py:422` has `to_otel_proto`.
- **Uncertainty:** None.

### R10: uc_schema_location_from_proto — Convert protobuf UCSchemaLocation to entity
- **Type:** Dataflow
- **Statement:** Given a `pb.UCSchemaLocation` protobuf with `catalog_name`, `schema_name`, and optionally `otel_spans_table_name`/`otel_logs_table_name`, the function MUST produce a `UCSchemaLocation` entity with those fields. Optional table names are set as private attributes (`_otel_spans_table_name`, `_otel_logs_table_name`) only when present via `HasField()`.
- **Task Evidence:** "Convert a protobuf UCSchemaLocation message to a UCSchemaLocation entity object."
- **Acceptance:** Call returns `UCSchemaLocation(catalog_name=..., schema_name=...)` with optional private table name attrs.
- **Repository Evidence:** `/testbed/mlflow/store/tracking/databricks_rest_store.py:422` calls `uc_schema_location_from_proto(response.uc_schema)`.
- **Uncertainty:** None.

### R11: uc_schema_location_to_proto — Convert UCSchemaLocation entity to proto
- **Type:** Dataflow
- **Statement:** Given a `UCSchemaLocation` entity with `catalog_name`, `schema_name`, and optional `_otel_spans_table_name`/`_otel_logs_table_name`, the function MUST produce a `pb.UCSchemaLocation` protobuf with all fields populated.
- **Task Evidence:** "Convert a UCSchemaLocation entity to its corresponding protobuf representation."
- **Acceptance:** Call returns `pb.UCSchemaLocation(catalog_name=..., schema_name=..., otel_spans_table_name=..., otel_logs_table_name=...)`.
- **Repository Evidence:** `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451` calls `uc_schema_location_to_proto(location)`.
- **Uncertainty:** None.

### R12: AssessmentSourceType — Validate and standardize source types with backward compatibility
- **Type:** Behavior
- **Statement:** The `AssessmentSourceType` class MUST provide an `__init__(source_type: str)` that delegates to `_parse()`, a `__str__()` that returns the stored string, a `_parse()` static method that normalizes case to uppercase, maps deprecated `AI_JUDGE` to `LLM_JUDGE` with `FutureWarning`, validates against `_SOURCE_TYPES`, and a `_standardize()` static method that instantiates and returns `str(instance)`. Class constants MUST be simple string values.
- **Task Evidence:** "Enumeration and validator for assessment source types. ... The constructor must delegate validation and transformation logic to a `_parse(source_type: str)` static method ..."
- **Acceptance:** `AssessmentSourceType("human")` returns instance with str() == "HUMAN"; `AssessmentSourceType("AI_JUDGE")` emits FutureWarning and returns str() == "LLM_JUDGE"; `AssessmentSourceType("INVALID")` raises `MlflowException`; `AssessmentSourceType._standardize("llm_judge")` returns "LLM_JUDGE".
- **Repository Evidence:** `/testbed/tests/entities/test_assessment_source.py` tests `AssessmentSource` validation (delegates to `AssessmentSourceType._standardize`); `/testbed/mlflow/entities/assessment_source.py:156` has existing class constants as strings; existing `_SOURCE_TYPES` list excludes `AI_JUDGE`; existing `from_proto` classmethod.
- **Uncertainty:** None.

### R13: Span.inputs property — Retrieve span inputs from attributes
- **Type:** Interface
- **Statement:** The `Span` class MUST expose an `inputs` property that deserializes and returns the value stored under `SpanAttributeKey.INPUTS` (`"mlflow.spanInputs"`), returning `None` if no inputs were set.
- **Task Evidence:** "The input values of the span. ... Returns: Any: The input values associated with this span. Returns None if no inputs were set."
- **Acceptance:** After `span.set_inputs({"x": 1})` on LiveSpan, `span.inputs` returns `{"x": 1}`; for a Span constructed from OTel proto with `"mlflow.spanInputs"` attribute, `span.inputs` returns the deserialized value.
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:529-531` `LiveSpan.set_inputs` stores via `SpanAttributeKey.INPUTS`; `/testbed/mlflow/entities/span.py:736-737` reads `span.inputs` in clone logic; `/testbed/tests/entities/test_span.py:44-45` tests `span.inputs` on LiveSpan; `/testbed/tests/entities/test_span.py:103-104` tests `span.inputs` on read Span.
- **Uncertainty:** None.

### R14: Span.outputs property — Retrieve span outputs from attributes
- **Type:** Interface
- **Statement:** The `Span` class MUST expose an `outputs` property that deserializes and returns the value stored under `SpanAttributeKey.OUTPUTS` (`"mlflow.spanOutputs"`), returning `None` if no outputs were set.
- **Task Evidence:** "The output values of the span. ... Returns: Any: The output values of the span. Returns None if no outputs were set."
- **Acceptance:** After `span.set_outputs(2)` on LiveSpan, `span.outputs` returns `2`; for a Span constructed from OTel proto with `"mlflow.spanOutputs"` attribute, `span.outputs` returns deserialized value.
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:533-535` `LiveSpan.set_outputs` stores via `SpanAttributeKey.OUTPUTS`; `/testbed/mlflow/entities/span.py:738-739` reads `span.outputs` in clone logic; `/testbed/tests/entities/test_span.py:44-46` tests `span.outputs` on LiveSpan; `/testbed/tests/entities/test_span.py:104` tests `span.outputs` on read Span.
- **Uncertainty:** None.

## L2. Functional Design Graph

### N1: databricks_tracing_utils (Module)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — currently only imports, functions must be added.

### N2: AssessmentSourceType (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:102-156` — class exists with constants and `from_proto`; missing `__init__`, `__str__`, `_parse`, `_standardize`.

### N3: Span (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:93` — `Span` class exists; missing `inputs` and `outputs` properties.

### N4: Assessment (Entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py` — `Assessment` dataclass with all fields.

### N5: Trace (Entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace.py` — `Trace` dataclass with `info: TraceInfo`, `data: TraceData`.

### N6: TraceInfo (Entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info.py` — `TraceInfo` dataclass.

### N7: TraceLocation (Entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py` — `TraceLocation` dataclass, plus `UCSchemaLocation`, `MlflowExperimentLocation`, `InferenceTableLocation`.

### N8: pb.Assessment (Proto)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.pyi:260` — `Assessment` message with `assessment_name`, `trace_id`, `trace_location`, `span_id`, `source`, `create_time`, `last_update_time`, `feedback`, `expectation`, `rationale`, `metadata`, `overrides`, `valid`.

### N9: pb.Trace (Proto)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.pyi:134` — `Trace` message with `trace_info`, `spans`; `/testbed/mlflow/protos/service_pb2.pyi:983` — `Trace` with `trace_info: TraceInfoV3`, `spans`.

### N10: pb.TraceInfo (Proto, v4)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.pyi:63` — `TraceInfo` with `trace_id`, `trace_location`, `request_time`, `execution_duration`, `state`, `trace_metadata`, `assessments`, `tags`.

### N11: pb.TraceLocation (Proto, v4)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.pyi:41` — `TraceLocation` with `type`, `mlflow_experiment`, `inference_table`, `uc_schema`.

### N12: pb.UCSchemaLocation (Proto)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.pyi:17` — `UCSchemaLocation` with `catalog_name`, `schema_name`, `otel_spans_table_name`, `otel_logs_table_name`.

### N13: pb.MlflowExperimentLocation (Proto)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.pyi:29` — `MlflowExperimentLocation` with `experiment_id`.

### N14: pb.InferenceTableLocation (Proto)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.pyi:35` — `InferenceTableLocation` with `full_table_name`.

### N15: parse_trace_id_v4 / construct_trace_id_v4 (Helpers)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/tracing/utils/__init__.py` — `parse_trace_id_v4` and `construct_trace_id_v4`.

### N16: _truncate_request_metadata / _truncate_tags (Helpers)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info_v2.py` — truncation helpers.

### N17: SpanAttributeKey (Constants)
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/tracing/constant.py` — `SpanAttributeKey.INPUTS = "mlflow.spanInputs"`, `SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"`.

### N18: assessments_pb2.Assessment (Proto)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/assessments_pb2.pyi` — `Assessment` message with `trace_id`, `span_id`, `source`, etc. (no `trace_location` field).

### E1: N1:assessment_to_proto -> N8:pb.Assessment
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Maps Assessment entity fields to pb.Assessment fields: `name` → `assessment_name`, `trace_id` → `trace_id`, `source` → `source` (via `source.to_proto()`), `create_time_ms` → `create_time.FromMilliseconds()`, `last_update_time_ms` → `last_update_time.FromMilliseconds()`, optional fields (span_id, rationale, assessment_id, metadata, overrides, valid) set only when non-None; `trace_location` set from parsed v4 trace_id.
- **Evidence:** Task description for `assessment_to_proto`; caller at `/testbed/mlflow/store/tracking/databricks_rest_store.py:511`.
- **Obligations:** R1

### E2: N1:assessment_to_proto -> N15:parse_trace_id_v4
- **Kind:** CALL
- **Condition:** When assessment.trace_id starts with v4 prefix
- **Transfer:** Parses trace_id to extract location and actual trace_id; constructs `pb.TraceLocation` with `uc_schema` from location.
- **Evidence:** Task notes: "The function automatically parses the trace_id to extract location information and constructs the appropriate trace_location proto field for UC Schema locations."
- **Obligations:** R1

### E3: N1:get_trace_id_from_assessment_proto -> N15:construct_trace_id_v4
- **Kind:** CALL
- **Condition:** When proto has `trace_location.uc_schema` set
- **Transfer:** Combines `catalog_name.schema_name` with `proto.trace_id` into v4 trace ID.
- **Evidence:** Task notes for `get_trace_id_from_assessment_proto`; callers at `/testbed/mlflow/entities/assessment.py:288,426`.
- **Obligations:** R2

### E4: N1:get_trace_id_from_assessment_proto -> N8/N18
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Reads `proto.trace_id` (raw) or constructs v4 trace ID depending on `trace_location` presence.
- **Evidence:** Task description; function accepts both `pb.Assessment` and `assessments_pb2.Assessment`.
- **Obligations:** R2

### E5: N1:inference_table_location_to_proto -> N14
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `InferenceTableLocation.full_table_name` → `pb.InferenceTableLocation.full_table_name`.
- **Evidence:** Task description for `inference_table_location_to_proto`.
- **Obligations:** R3

### E6: N1:mlflow_experiment_location_to_proto -> N13
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `MlflowExperimentLocation.experiment_id` → `pb.MlflowExperimentLocation.experiment_id`.
- **Evidence:** Task description for `mlflow_experiment_location_to_proto`.
- **Obligations:** R4

### E7: N1:trace_from_proto -> N5, N6
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `pb.Trace.trace_info` → `TraceInfo.from_proto()`; `pb.Trace.spans` → `[Span.from_otel_proto(s, location_id) for s in spans]` → `TraceData(spans=...)` → `Trace(info=..., data=...)`.
- **Evidence:** Task description; caller at `/testbed/mlflow/store/tracking/databricks_rest_store.py:189`.
- **Obligations:** R5

### E8: N1:trace_info_to_v4_proto -> N10, N15, N16
- **Kind:** CALL
- **Condition:** Always (called when TraceInfo `_is_v4()`)
- **Transfer:** Uses `parse_trace_id_v4` for trace_id, `_truncate_request_metadata` / `_truncate_tags` for metadata/tags, `assessment_to_proto` for assessments; builds `pb.TraceInfo` with timestamps via `FromMilliseconds()`, `execution_duration` via `FromMilliseconds()` (only if not None).
- **Evidence:** Task description; caller at `/testbed/mlflow/entities/trace_info.py:103`.
- **Obligations:** R6

### E9: N1:trace_location_from_proto -> N7, N12
- **Kind:** CALL
- **Condition:** Based on `WhichOneof` result
- **Transfer:** `pb.TraceLocation.uc_schema` → `uc_schema_location_from_proto` → `TraceLocation(type=UC_SCHEMA, uc_schema=...)`; `mlflow_experiment` → `MlflowExperimentLocation.from_proto`; `inference_table` → `InferenceTableLocation.from_proto`; none → `TRACE_LOCATION_TYPE_UNSPECIFIED`.
- **Evidence:** Task description; caller at `/testbed/mlflow/entities/trace_location.py:246`.
- **Obligations:** R7

### E10: N1:trace_location_to_proto -> N11, N12, N13, N14
- **Kind:** CALL
- **Condition:** Based on `trace_location.type`
- **Transfer:** `UC_SCHEMA` → delegates to `uc_schema_location_to_proto`; `MLFLOW_EXPERIMENT` → `mlflow_experiment_location_to_proto`; `INFERENCE_TABLE` → `inference_table_location_to_proto`; else raises `ValueError`.
- **Evidence:** Task description; callers at `/testbed/mlflow/store/tracking/databricks_rest_store.py:290,294,558`.
- **Obligations:** R8

### E11: N1:trace_to_proto -> N9
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `trace.info.to_proto()` → `pb.Trace.trace_info`; `[s.to_otel_proto() for s in trace.data.spans]` → `pb.Trace.spans`.
- **Evidence:** Task description; `/testbed/mlflow/entities/trace.py:153-157` existing `Trace.to_proto()`.
- **Obligations:** R9

### E12: N1:uc_schema_location_from_proto -> N12
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `pb.UCSchemaLocation.catalog_name` → `UCSchemaLocation.catalog_name`; `schema_name` → `schema_name`; uses `HasField()` for optional `otel_spans_table_name` / `otel_logs_table_name` → `_otel_spans_table_name` / `_otel_logs_table_name`.
- **Evidence:** Task description; caller at `/testbed/mlflow/store/tracking/databricks_rest_store.py:422`.
- **Obligations:** R10

### E13: N1:uc_schema_location_to_proto -> N12
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `UCSchemaLocation.catalog_name` → `pb.UCSchemaLocation.catalog_name`; `schema_name` → `schema_name`; `_otel_spans_table_name` → `otel_spans_table_name`; `_otel_logs_table_name` → `otel_logs_table_name`.
- **Evidence:** Task description; callers at `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451`.
- **Obligations:** R11

### E14: N2:AssessmentSourceType.__init__ -> N2:_parse
- **Kind:** CALL
- **Condition:** Always on construction
- **Transfer:** Passes `source_type: str` to `_parse()`; stores result as instance attribute `_value`.
- **Evidence:** Task description: "The constructor must delegate validation and transformation logic to a `_parse(source_type: str)` static method."
- **Obligations:** R12

### E15: N2:AssessmentSourceType.__str__ -> self._value
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns the stored `_value` string.
- **Evidence:** Task description: "a `__str__()` method that returns the stored source type string."
- **Obligations:** R12

### E16: N2:_parse -> N2._SOURCE_TYPES
- **Kind:** CONTROL
- **Condition:** After case normalization and deprecation mapping
- **Transfer:** Validates result against `_SOURCE_TYPES` list; raises `MlflowException(INVALID_PARAMETER_VALUE)` on mismatch.
- **Evidence:** Task description; existing `_SOURCE_TYPES = [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]` at `/testbed/mlflow/entities/assessment_source.py:156`.
- **Obligations:** R12

### E17: N2:_parse -> AI_JUDGE deprecation
- **Kind:** CONTROL
- **Condition:** Input uppercased equals "AI_JUDGE"
- **Transfer:** Emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`, returns "LLM_JUDGE".
- **Evidence:** Task description; existing test at `/testbed/tests/entities/test_assessment_source.py:91-96`.
- **Obligations:** R12

### E18: N2:_standardize -> N2:__init__ -> N2:__str__
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Instantiates `AssessmentSourceType(source_type)`, returns `str(instance)`.
- **Evidence:** Task description: "The _standardize method must instantiate an AssessmentSourceType object by calling the constructor AssessmentSourceType(source_type), then convert the instance to a string representation to obtain the standardized value."
- **Obligations:** R12

### E19: N3:Span.inputs -> N3._attributes -> N17:SpanAttributeKey.INPUTS
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns `self.get_attribute(SpanAttributeKey.INPUTS)` which deserializes from JSON.
- **Evidence:** Task description; `/testbed/mlflow/entities/span.py:531` `LiveSpan.set_inputs` stores via `SpanAttributeKey.INPUTS`; `/testbed/tests/entities/test_span.py:44-45,103` tests `span.inputs`.
- **Obligations:** R13

### E20: N3:Span.outputs -> N3._attributes -> N17:SpanAttributeKey.OUTPUTS
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns `self.get_attribute(SpanAttributeKey.OUTPUTS)` which deserializes from JSON.
- **Evidence:** Task description; `/testbed/mlflow/entities/span.py:535` `LiveSpan.set_outputs` stores via `SpanAttributeKey.OUTPUTS`; `/testbed/tests/entities/test_span.py:45-46,104` tests `span.outputs`.
- **Obligations:** R14

## L3. Verifiable Contracts

### C1: assessment_to_proto basic fields
- **Type:** Dataflow
- **Subject:** `assessment_to_proto(assessment)` return value
- **Relation:** EQ
- **Expected:** A `pb.Assessment` with `assessment_name == assessment.name`, `trace_id == assessment.trace_id`, `source` matching `assessment.source.to_proto()`, `create_time` == `Timestamp.FromMilliseconds(assessment.create_time_ms)`, `last_update_time` == `Timestamp.FromMilliseconds(assessment.last_update_time_ms)`.
- **Evidence:** Task requirements; existing `Assessment.to_proto()` at `/testbed/mlflow/entities/assessment.py:117-126` uses `FromMilliseconds`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, N8, E1

### C2: assessment_to_proto optional fields
- **Type:** Dataflow
- **Subject:** `assessment_to_proto(assessment)` return proto optional fields
- **Relation:** EQ
- **Expected:** `span_id`, `rationale`, `assessment_id`, `overrides`, `valid` set only when `assessment.span_id` etc. are not None; `metadata` converted to string-keyed map; `expectation` or `feedback` set (but not both).
- **Evidence:** Task notes: "The function handles None values gracefully by only setting proto fields when the corresponding assessment fields are not None"; "Either expectation or feedback will be set in the proto, but not both".
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, N8, E1

### C3: assessment_to_proto trace_location for v4 trace_id
- **Type:** Dataflow
- **Subject:** `assessment_to_proto(assessment)` when `assessment.trace_id` is v4 format
- **Relation:** EQ
- **Expected:** `proto.trace_location` is set with `uc_schema` containing parsed catalog/schema from trace_id; `proto.trace_id` is the parsed inner trace_id.
- **Evidence:** Task notes: "The function automatically parses the trace_id to extract location information and constructs the appropriate trace_location proto field for UC Schema locations."
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, N8, N15, E1, E2

### C4: get_trace_id_from_assessment_proto UC schema
- **Type:** Dataflow
- **Subject:** `get_trace_id_from_assessment_proto(proto)` when proto has UC Schema trace_location
- **Relation:** EQ
- **Expected:** Returns `construct_trace_id_v4(location=f"{catalog}.{schema}", trace_id=proto.trace_id)`.
- **Evidence:** Task notes; callers at `/testbed/mlflow/entities/assessment.py:288,426`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`
- **Obligations:** R2
- **Graph:** N1, N15, E3, E4

### C5: get_trace_id_from_assessment_proto no UC schema
- **Type:** Dataflow
- **Subject:** `get_trace_id_from_assessment_proto(proto)` when proto has no UC Schema trace_location
- **Relation:** EQ
- **Expected:** Returns `proto.trace_id` directly.
- **Evidence:** Task notes: "For other locations, returns the raw trace ID from the proto object."
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`
- **Obligations:** R2
- **Graph:** N1, E4

### C6: get_trace_id_from_assessment_proto dual proto types
- **Type:** Interface
- **Subject:** `get_trace_id_from_assessment_proto(proto)` accepts both `pb.Assessment` and `assessments_pb2.Assessment`
- **Relation:** TYPE_IS
- **Expected:** Function signature accepts `pb.Assessment | assessments_pb2.Assessment`; works with both types.
- **Evidence:** Task signature: `proto: pb.Assessment | assessments_pb2.Assessment`; `assessments_pb2.Assessment` has `trace_id` but no `trace_location`, `pb.Assessment` (databricks_tracing) has `trace_location`.
- **Observe:** IMPORT_BOUNDARY
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`
- **Obligations:** R2
- **Graph:** N1, N8, N18, E4

### C7: inference_table_location_to_proto
- **Type:** Dataflow
- **Subject:** `inference_table_location_to_proto(InferenceTableLocation(full_table_name="c.s.t"))`
- **Relation:** EQ
- **Expected:** `pb.InferenceTableLocation(full_table_name="c.s.t")`.
- **Evidence:** Task description; existing pattern at `/testbed/mlflow/entities/trace_location.py:58-62`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:inference_table_location_to_proto`
- **Obligations:** R3
- **Graph:** N1, N14, E5

### C8: mlflow_experiment_location_to_proto
- **Type:** Dataflow
- **Subject:** `mlflow_experiment_location_to_proto(MlflowExperimentLocation(experiment_id="exp-1"))`
- **Relation:** EQ
- **Expected:** `pb.MlflowExperimentLocation(experiment_id="exp-1")`.
- **Evidence:** Task description; existing pattern at `/testbed/mlflow/entities/trace_location.py:51-52`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:mlflow_experiment_location_to_proto`
- **Obligations:** R4
- **Graph:** N1, N13, E6

### C9: trace_from_proto
- **Type:** Dataflow
- **Subject:** `trace_from_proto(proto, location_id)` return value type
- **Relation:** TYPE_IS
- **Expected:** Returns `Trace` entity with `info: TraceInfo` and `data: TraceData`.
- **Evidence:** Task description; caller `/testbed/mlflow/store/tracking/databricks_rest_store.py:189`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`
- **Obligations:** R5
- **Graph:** N1, N5, N6, N9, E7

### C10: trace_from_proto span construction
- **Type:** Dataflow
- **Subject:** `trace_from_proto(proto, location_id)` spans
- **Relation:** CALLS
- **Expected:** Each span in result.data.spans is constructed via `Span.from_otel_proto(span_proto, location_id)`.
- **Evidence:** Task notes: "Individual spans are converted using Span.from_otel_proto() with the provided location_id"; existing `Trace.from_proto` pattern at `/testbed/mlflow/entities/trace.py:158-160`.
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`
- **Obligations:** R5
- **Graph:** N1, N5, N9, E7

### C11: trace_info_to_v4_proto return type
- **Type:** Interface
- **Subject:** `trace_info_to_v4_proto(trace_info)` return
- **Relation:** TYPE_IS
- **Expected:** Returns `pb.TraceInfo` (databricks_tracing_pb2.TraceInfo).
- **Evidence:** Task signature; caller at `/testbed/mlflow/entities/trace_info.py:103`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`
- **Obligations:** R6
- **Graph:** N1, N10, E8

### C12: trace_info_to_v4_proto basic mapping
- **Type:** Dataflow
- **Subject:** `trace_info_to_v4_proto(trace_info)` field mapping
- **Relation:** EQ
- **Expected:** `proto.trace_id` = parsed trace_id (via `parse_trace_id_v4` if UC Schema); `proto.trace_location` = `trace_location_to_proto(trace_info.trace_location)`; `proto.request_time` = `Timestamp.FromMilliseconds(trace_info.request_time)`; `proto.state` = `trace_info.state.to_proto()`; `proto.trace_metadata` = truncated metadata; `proto.tags` = truncated tags; `proto.assessments` = `[assessment_to_proto(a) for a in trace_info.assessments]`.
- **Evidence:** Task description: "trace ID parsing for UC schema locations", "request metadata and tags are truncated", "All timestamps are converted from milliseconds to protobuf Timestamp format".
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`
- **Obligations:** R6
- **Graph:** N1, N6, N10, N15, N16, E8

### C13: trace_info_to_v4_proto execution_duration
- **Type:** Dataflow
- **Subject:** `trace_info_to_v4_proto(trace_info)` when `trace_info.execution_duration` is None
- **Relation:** EQ
- **Expected:** `proto.execution_duration` is not set (or remains default).
- **Evidence:** Task notes: "Execution duration is only set in the protobuf if it's not None in the input."
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`
- **Obligations:** R6
- **Graph:** N1, N6, N10, E8

### C14: trace_location_from_proto UC_SCHEMA
- **Type:** Dataflow
- **Subject:** `trace_location_from_proto(pb.TraceLocation(type=UC_SCHEMA, uc_schema=...))`
- **Relation:** EQ
- **Expected:** Returns `TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=UCSchemaLocation(...))`.
- **Evidence:** Task description; caller at `/testbed/mlflow/entities/trace_location.py:246`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N1, N7, N11, N12, E9

### C15: trace_location_from_proto MLFLOW_EXPERIMENT
- **Type:** Dataflow
- **Subject:** `trace_location_from_proto(pb.TraceLocation(type=MLFLOW_EXPERIMENT, mlflow_experiment=...))`
- **Relation:** EQ
- **Expected:** Returns `TraceLocation(type=TraceLocationType.MLFLOW_EXPERIMENT, mlflow_experiment=MlflowExperimentLocation(...))`.
- **Evidence:** Task description; pattern at `/testbed/mlflow/entities/trace_location.py:246`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N1, N7, N11, E9

### C16: trace_location_from_proto INFERENCE_TABLE
- **Type:** Dataflow
- **Subject:** `trace_location_from_proto(pb.TraceLocation(type=INFERENCE_TABLE, inference_table=...))`
- **Relation:** EQ
- **Expected:** Returns `TraceLocation(type=TraceLocationType.INFERENCE_TABLE, inference_table=InferenceTableLocation(...))`.
- **Evidence:** Task description.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N1, N7, N11, E9

### C17: trace_location_from_proto fallback
- **Type:** Dataflow
- **Subject:** `trace_location_from_proto(pb.TraceLocation())` with no identifier set
- **Relation:** EQ
- **Expected:** Returns `TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)`.
- **Evidence:** Task notes: "If no valid identifier is found in the proto message, returns a TraceLocation with type TRACE_LOCATION_TYPE_UNSPECIFIED."
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N1, N7, E9

### C18: trace_location_to_proto UC_SCHEMA
- **Type:** Dataflow
- **Subject:** `trace_location_to_proto(TraceLocation(type=UC_SCHEMA, uc_schema=...))`
- **Relation:** EQ
- **Expected:** Returns `pb.TraceLocation(type=UC_SCHEMA, uc_schema=uc_schema_location_to_proto(...))`.
- **Evidence:** Task notes: "delegates to specific conversion functions for each location type".
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`
- **Obligations:** R8
- **Graph:** N1, N7, N11, E10

### C19: trace_location_to_proto raises ValueError
- **Type:** Failure
- **Subject:** `trace_location_to_proto(trace_location)` with unsupported type
- **Relation:** RAISES
- **Expected:** `ValueError` with message about unsupported type.
- **Evidence:** Task notes: "Raises: ValueError: If the trace_location.type is not one of the supported types".
- **Observe:** EXCEPTION
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`
- **Obligations:** R8
- **Graph:** N1, E10

### C20: trace_to_proto
- **Type:** Dataflow
- **Subject:** `trace_to_proto(trace)` structure
- **Relation:** EQ
- **Expected:** `pb.Trace` with `trace_info = trace.info.to_proto()` and `spans = [s.to_otel_proto() for s in trace.data.spans]`.
- **Evidence:** Task notes; existing pattern at `/testbed/mlflow/entities/trace.py:153-157`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_to_proto`
- **Obligations:** R9
- **Graph:** N1, N5, N9, E11

### C21: uc_schema_location_from_proto
- **Type:** Dataflow
- **Subject:** `uc_schema_location_from_proto(proto)` with all fields set
- **Relation:** EQ
- **Expected:** Returns `UCSchemaLocation(catalog_name=proto.catalog_name, schema_name=proto.schema_name)` with `_otel_spans_table_name == proto.otel_spans_table_name` and `_otel_logs_table_name == proto.otel_logs_table_name`.
- **Evidence:** Task description; caller at `/testbed/mlflow/store/tracking/databricks_rest_store.py:422`.
- **Observe:** FIELD_READ
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`
- **Obligations:** R10
- **Graph:** N1, N12, E12

### C22: uc_schema_location_from_proto optional fields
- **Type:** Dataflow
- **Subject:** `uc_schema_location_from_proto(proto)` when optional table names absent
- **Relation:** EQ
- **Expected:** Uses `HasField()` to check; returns `UCSchemaLocation` without setting optional table name attrs (they remain defaults).
- **Evidence:** Task notes: "The function uses HasField() to check for optional fields before setting them."
- **Observe:** FIELD_READ
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`
- **Obligations:** R10
- **Graph:** N1, N12, E12

### C23: uc_schema_location_to_proto
- **Type:** Dataflow
- **Subject:** `uc_schema_location_to_proto(uc_schema_location)` return proto
- **Relation:** EQ
- **Expected:** `pb.UCSchemaLocation` with `catalog_name`, `schema_name`, `otel_spans_table_name`, `otel_logs_table_name` from the entity (including private attrs).
- **Evidence:** Task description; callers at `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_to_proto`
- **Obligations:** R11
- **Graph:** N1, N12, E13

### C24: AssessmentSourceType.__init__ stores value
- **Type:** State
- **Subject:** `AssessmentSourceType("human")._value` or internal state
- **Relation:** EQ
- **Expected:** Stores `"HUMAN"` (uppercased).
- **Evidence:** Task description: "__init__(source_type: str) method that stores the parsed source type value"; existing test `/testbed/tests/entities/test_assessment_source.py:67-69`.
- **Observe:** STATE_READ (via `str(instance)` returning parsed value)
- **Target:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType.__init__`
- **Obligations:** R12
- **Graph:** N2, E14

### C25: AssessmentSourceType.__str__ returns stored value
- **Type:** Interface
- **Subject:** `str(AssessmentSourceType("HUMAN"))`
- **Relation:** EQ
- **Expected:** `"HUMAN"`.
- **Evidence:** Task description: "__str__() method that returns the stored source type string."
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType.__str__`
- **Obligations:** R12
- **Graph:** N2, E15

### C26: AssessmentSourceType._standardize returns string
- **Type:** Interface
- **Subject:** `AssessmentSourceType._standardize("llm_judge")`
- **Relation:** EQ
- **Expected:** `"LLM_JUDGE"` (uppercased, validated).
- **Evidence:** Task description; called by `AssessmentSource.__post_init__` at `/testbed/mlflow/entities/assessment_source.py:94`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`
- **Obligations:** R12
- **Graph:** N2, E18

### C27: AssessmentSourceType._parse case normalization
- **Type:** Behavior
- **Subject:** `AssessmentSourceType._parse("human")`
- **Relation:** EQ
- **Expected:** Returns `"HUMAN"`.
- **Evidence:** Task description: "case-insensitive normalization (converting to uppercase)"; existing test `/testbed/tests/entities/test_assessment_source.py:67-78`.
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`
- **Obligations:** R12
- **Graph:** N2, E16

### C28: AssessmentSourceType._parse AI_JUDGE deprecation
- **Type:** SideEffect
- **Subject:** `AssessmentSourceType._parse("AI_JUDGE")`
- **Relation:** EQ
- **Expected:** Returns `"LLM_JUDGE"` and emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`.
- **Evidence:** Task description; existing test `/testbed/tests/entities/test_assessment_source.py:91-96`.
- **Observe:** SIDE_EFFECT (warnings.warn) + RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`
- **Obligations:** R12
- **Graph:** N2, E17

### C29: AssessmentSourceType._parse invalid type
- **Type:** Failure
- **Subject:** `AssessmentSourceType._parse("INVALID")`
- **Relation:** RAISES
- **Expected:** `MlflowException` with `INVALID_PARAMETER_VALUE` error code and message containing "Invalid assessment source type".
- **Evidence:** Task description; existing test `/testbed/tests/entities/test_assessment_source.py:54-56`.
- **Observe:** EXCEPTION
- **Target:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`
- **Obligations:** R12
- **Graph:** N2, E16

### C30: Span.inputs property
- **Type:** Interface
- **Subject:** `span.inputs` on Span with `mlflow.spanInputs` attribute set to `'{"x": 1}'`
- **Relation:** EQ
- **Expected:** Returns `{"x": 1}` (deserialized from JSON).
- **Evidence:** Task description; existing test `/testbed/tests/entities/test_span.py:103` (`assert span.inputs == {"input": 1, "nested": {"foo": "bar"}}`).
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/span.py:Span.inputs`
- **Obligations:** R13
- **Graph:** N3, N17, E19

### C31: Span.outputs property
- **Type:** Interface
- **Subject:** `span.outputs` on Span with `mlflow.spanOutputs` attribute set to `"2"`
- **Relation:** EQ
- **Expected:** Returns `2` (deserialized from JSON).
- **Evidence:** Task description; existing test `/testbed/tests/entities/test_span.py:104` (`assert span.outputs == 2`).
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/span.py:Span.outputs`
- **Obligations:** R14
- **Graph:** N3, N17, E20

### C32: Span.inputs returns None when unset
- **Type:** Dataflow
- **Subject:** `span.inputs` on Span without `mlflow.spanInputs` attribute
- **Relation:** EQ
- **Expected:** Returns `None`.
- **Evidence:** Task description: "Returns None if no inputs were set."
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/span.py:Span.inputs`
- **Obligations:** R13
- **Graph:** N3, N17, E19

### C33: Span.outputs returns None when unset
- **Type:** Dataflow
- **Subject:** `span.outputs` on Span without `mlflow.spanOutputs` attribute
- **Relation:** EQ
- **Expected:** Returns `None`.
- **Evidence:** Task description: "Returns None if no outputs were set."
- **Observe:** RETURN_VALUE
- **Target:** `/testbed/mlflow/entities/span.py:Span.outputs`
- **Obligations:** R14
- **Graph:** N3, N17, E20
