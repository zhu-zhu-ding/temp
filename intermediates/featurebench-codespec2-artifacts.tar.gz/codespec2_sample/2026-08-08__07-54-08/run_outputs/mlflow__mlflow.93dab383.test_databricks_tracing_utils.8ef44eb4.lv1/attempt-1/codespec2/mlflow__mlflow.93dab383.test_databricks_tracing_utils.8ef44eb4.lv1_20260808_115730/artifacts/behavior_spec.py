"""
Behavior spec: L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility.

Each no-argument check_* function validates one or more contracts,
prints PASS:<funcname> on success, and raises AssertionError on failure.
"""

import sys
import warnings

sys.path.insert(0, "/testbed")

import pytest

from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.entities.trace_location import (
    TraceLocation,
    TraceLocationType,
    UCSchemaLocation,
    MlflowExperimentLocation,
    InferenceTableLocation,
)
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE


# ---------------------------------------------------------------------------
# C19: trace_location_to_proto raises ValueError  (Failure)
# ---------------------------------------------------------------------------

def check_trace_location_to_proto_value_error():
    """Contracts: C19"""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto

    # TRACE_LOCATION_TYPE_UNSPECIFIED is not a supported dispatch type
    tl = TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)

    try:
        trace_location_to_proto(tl)
        raise AssertionError("Expected ValueError was not raised")
    except ValueError as e:
        # Verify it's a ValueError about unsupported type
        msg = str(e).lower()
        assert "unsupported" in msg or "type" in msg or "trace_location" in msg, \
            f"Unexpected error message: {e}"
    except Exception as e:
        raise AssertionError(f"Expected ValueError, got {type(e).__name__}: {e}")

    print("PASS:check_trace_location_to_proto_value_error")


# ---------------------------------------------------------------------------
# C24: AssessmentSourceType.__init__ stores value  (State)
# ---------------------------------------------------------------------------

def check_assessment_source_type_init_state():
    """Contracts: C24"""
    # The constructor stores the parsed/normalized value.
    # We verify via str() which returns the stored value (C25).

    instance = AssessmentSourceType("human")
    assert str(instance) == "HUMAN", "Constructor should store normalized value"

    instance2 = AssessmentSourceType("LLM_JUDGE")
    assert str(instance2) == "LLM_JUDGE"

    instance3 = AssessmentSourceType("CODE")
    assert str(instance3) == "CODE"

    instance4 = AssessmentSourceType("SOURCE_TYPE_UNSPECIFIED")
    assert str(instance4) == "SOURCE_TYPE_UNSPECIFIED"

    print("PASS:check_assessment_source_type_init_state")


# ---------------------------------------------------------------------------
# C27: AssessmentSourceType._parse case normalization  (Behavior)
# ---------------------------------------------------------------------------

def check_assessment_source_type_parse_case():
    """Contracts: C27"""
    # Test various case inputs
    assert AssessmentSourceType._parse("human") == "HUMAN"
    assert AssessmentSourceType._parse("Human") == "HUMAN"
    assert AssessmentSourceType._parse("HUMAN") == "HUMAN"
    assert AssessmentSourceType._parse("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("Llm_Judge") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("code") == "CODE"
    assert AssessmentSourceType._parse("CODE") == "CODE"
    assert AssessmentSourceType._parse("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"

    print("PASS:check_assessment_source_type_parse_case")


# ---------------------------------------------------------------------------
# C28: AssessmentSourceType._parse AI_JUDGE deprecation  (SideEffect)
# ---------------------------------------------------------------------------

def check_assessment_source_type_parse_deprecation():
    """Contracts: C28"""
    # AI_JUDGE should trigger FutureWarning and return LLM_JUDGE
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = AssessmentSourceType._parse("AI_JUDGE")
    assert result == "LLM_JUDGE"

    # Also test lowercase "ai_judge"
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result2 = AssessmentSourceType._parse("ai_judge")
    assert result2 == "LLM_JUDGE"

    # Test mixed case
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result3 = AssessmentSourceType._parse("Ai_Judge")
    assert result3 == "LLM_JUDGE"

    print("PASS:check_assessment_source_type_parse_deprecation")


# ---------------------------------------------------------------------------
# C29: AssessmentSourceType._parse invalid type  (Failure)
# ---------------------------------------------------------------------------

def check_assessment_source_type_parse_invalid():
    """Contracts: C29"""
    with pytest.raises(MlflowException) as exc_info:
        AssessmentSourceType._parse("INVALID_TYPE")
    assert exc_info.value.error_code == INVALID_PARAMETER_VALUE, \
        f"Expected INVALID_PARAMETER_VALUE, got {exc_info.value.error_code}"
    assert "Invalid assessment source type" in str(exc_info.value), \
        f"Expected message about invalid source type, got: {exc_info.value}"

    # Also test another invalid value
    with pytest.raises(MlflowException) as exc_info2:
        AssessmentSourceType._parse("ROBOT")
    assert exc_info2.value.error_code == INVALID_PARAMETER_VALUE
    assert "Invalid assessment source type" in str(exc_info2.value)

    print("PASS:check_assessment_source_type_parse_invalid")


# ---------------------------------------------------------------------------
# Supplementary: E18 - _standardize -> __init__ -> __str__ chain
# ---------------------------------------------------------------------------

def check_assessment_source_standardize_through_constructor():
    """Verify _standardize is called through AssessmentSource.__post_init__ (E18)."""
    # Case insensitive through the AssessmentSource constructor
    source = AssessmentSource(source_type="human", source_id="u1")
    assert source.source_type == "HUMAN"

    source2 = AssessmentSource(source_type="llm_judge", source_id="u2")
    assert source2.source_type == "LLM_JUDGE"

    # AI_JUDGE deprecation through the full constructor flow
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        source3 = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
    assert source3.source_type == "LLM_JUDGE"

    print("PASS:check_assessment_source_standardize_through_constructor")


# ---------------------------------------------------------------------------
# Supplementary: trace_location_to_proto delegation completeness
# ---------------------------------------------------------------------------

def check_trace_location_to_proto_delegation():
    """Verify trace_location_to_proto delegates correctly for all supported types."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    # MLFLOW_EXPERIMENT
    tl_exp = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="e1"),
    )
    proto_exp = trace_location_to_proto(tl_exp)
    assert proto_exp.type == pb.TraceLocation.MLFLOW_EXPERIMENT
    assert proto_exp.mlflow_experiment.experiment_id == "e1"

    # INFERENCE_TABLE
    tl_inf = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="c.s.t"),
    )
    proto_inf = trace_location_to_proto(tl_inf)
    assert proto_inf.type == pb.TraceLocation.INFERENCE_TABLE
    assert proto_inf.inference_table.full_table_name == "c.s.t"

    print("PASS:check_trace_location_to_proto_delegation")


# ---------------------------------------------------------------------------
# Supplementary: assessment_to_proto expectation vs feedback mutual exclusion
# ---------------------------------------------------------------------------

def check_assessment_to_proto_expectation_and_feedback():
    """Verify either expectation or feedback is set, but not both (C2 nuance)."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment import Assessment, ExpectationValue, FeedbackValue
    import time

    now_ms = int(time.time() * 1000)

    # With expectation only
    exp_assess = Assessment(
        name="exp_test",
        source=AssessmentSource(source_type="HUMAN", source_id="u1"),
        trace_id="tr-1",
        create_time_ms=now_ms,
        last_update_time_ms=now_ms,
        expectation=ExpectationValue(value="expected_value"),
    )
    proto_exp = assessment_to_proto(exp_assess)
    assert proto_exp.HasField("expectation")
    assert not proto_exp.HasField("feedback")

    # With feedback only
    fb_assess = Assessment(
        name="fb_test",
        source=AssessmentSource(source_type="HUMAN", source_id="u1"),
        trace_id="tr-2",
        create_time_ms=now_ms,
        last_update_time_ms=now_ms,
        feedback=FeedbackValue(value=3.5),
    )
    proto_fb = assessment_to_proto(fb_assess)
    assert proto_fb.HasField("feedback")
    assert not proto_fb.HasField("expectation")

    print("PASS:check_assessment_to_proto_expectation_and_feedback")


# ===========================================================================
# Main
# ===========================================================================

if __name__ == "__main__":
    checks = [
        check_trace_location_to_proto_value_error,
        check_assessment_source_type_init_state,
        check_assessment_source_type_parse_case,
        check_assessment_source_type_parse_deprecation,
        check_assessment_source_type_parse_invalid,
        check_assessment_source_standardize_through_constructor,
        check_trace_location_to_proto_delegation,
        check_assessment_to_proto_expectation_and_feedback,
    ]
    for check in checks:
        check()
    print("\nAll behavior checks passed.")
