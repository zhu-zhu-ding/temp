"""
Architecture spec: public interface and graph connectivity.
Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.

Each no-argument check_* function validates one or more contracts,
prints PASS:<funcname> on success, and raises AssertionError on failure.
"""

import json
import sys
import time
import warnings

sys.path.insert(0, "/testbed")

from google.protobuf.timestamp_pb2 import Timestamp
from google.protobuf.duration_pb2 import Duration

from mlflow.entities import (
    Assessment,
    Span,
    Trace,
    TraceData,
    TraceInfo,
)
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.entities.trace_location import (
    InferenceTableLocation,
    MlflowExperimentLocation,
    TraceLocation,
    TraceLocationType,
    UCSchemaLocation,
)
from mlflow.entities.trace_state import TraceState
from mlflow.entities.assessment import ExpectationValue, FeedbackValue
from mlflow.protos import databricks_tracing_pb2 as pb
from mlflow.protos import assessments_pb2
from mlflow.tracing.constant import SpanAttributeKey, TRACE_ID_V4_PREFIX
from mlflow.tracing.utils import construct_trace_id_v4, parse_trace_id_v4

# --- Proto enum helpers (State is nested in TraceInfo, not top-level) ---
def _pb_state_ok():
    """Return the integer value for TraceInfo.State.OK."""
    return pb.TraceInfo().DESCRIPTOR.fields_by_name["state"].enum_type.values_by_name["OK"].number


def _pb_state_error():
    """Return the integer value for TraceInfo.State.ERROR."""
    return pb.TraceInfo().DESCRIPTOR.fields_by_name["state"].enum_type.values_by_name["ERROR"].number


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_assessment(**overrides):
    """Build a minimal valid Assessment with defaults (expectation set)."""
    now_ms = int(time.time() * 1000)
    kwargs = dict(
        name="test_assess",
        source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
        trace_id="tr-abc123",
        create_time_ms=now_ms,
        last_update_time_ms=now_ms,
        expectation=ExpectationValue(value="expected_val"),
    )
    kwargs.update(overrides)
    return Assessment(**kwargs)


def _make_trace_info(uc_schema=False):
    """Build a minimal TraceInfo for testing."""
    if uc_schema:
        tl = TraceLocation(
            type=TraceLocationType.UC_SCHEMA,
            uc_schema=UCSchemaLocation(catalog_name="my_cat", schema_name="my_schema"),
        )
    else:
        tl = TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-1"),
        )

    return TraceInfo(
        trace_id="trace-001",
        trace_location=tl,
        request_time=int(time.time() * 1000),
        state=TraceState.OK,
        client_request_id="client-req-1",
        request_preview='{"q": "hello"}',
        response_preview='{"a": "hi"}',
        execution_duration=1500,
        trace_metadata={"run_id": "run-1"},
        tags={"tag1": "val1"},
        assessments=[],
    )


# ---------------------------------------------------------------------------
# C1: assessment_to_proto basic fields  (Dataflow)
# ---------------------------------------------------------------------------

def check_assessment_to_proto_basic_fields():
    """Contracts: C1"""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    now_ms = int(time.time() * 1000)
    assessment = _make_assessment(
        name="my_assess",
        trace_id="tr-xyz",
        create_time_ms=now_ms,
        last_update_time_ms=now_ms,
    )

    proto = assessment_to_proto(assessment)

    # Basic required fields
    assert proto.assessment_name == "my_assess", f"Expected my_assess, got {proto.assessment_name}"
    assert proto.trace_id == "tr-xyz", f"Expected tr-xyz, got {proto.trace_id}"

    # Source must be set via source.to_proto()
    assert proto.HasField("source"), "source field must be set"
    assert proto.source.source_type == assessments_pb2.AssessmentSource.SourceType.Value("HUMAN")

    # Timestamps via FromMilliseconds
    assert proto.HasField("create_time"), "create_time must be set"
    expected_ct = Timestamp()
    expected_ct.FromMilliseconds(now_ms)
    assert proto.create_time == expected_ct, \
        f"create_time mismatch: {proto.create_time} vs {expected_ct}"

    assert proto.HasField("last_update_time"), "last_update_time must be set"
    expected_lut = Timestamp()
    expected_lut.FromMilliseconds(now_ms)
    assert proto.last_update_time == expected_lut, \
        f"last_update_time mismatch: {proto.last_update_time} vs {expected_lut}"

    print("PASS:check_assessment_to_proto_basic_fields")


# ---------------------------------------------------------------------------
# C2: assessment_to_proto optional fields  (Dataflow)
# ---------------------------------------------------------------------------

def check_assessment_to_proto_optional_fields():
    """Contracts: C2"""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    now_ms = int(time.time() * 1000)
    # Assessment with all optional fields populated
    assessment = _make_assessment(
        span_id="span-1",
        rationale="because",
        assessment_id="assess-id-1",
        metadata={"k1": "v1", "k2": 2},
        overrides="old-assess-id",
        valid=True,
    )

    proto = assessment_to_proto(assessment)

    # Optional fields set when non-None
    assert proto.span_id == "span-1"
    assert proto.rationale == "because"
    assert proto.assessment_id == "assess-id-1"
    assert proto.overrides == "old-assess-id"
    assert proto.valid is True

    # Metadata converted to string key-value pairs
    assert len(proto.metadata) == 2
    assert proto.metadata["k1"] == "v1"
    assert proto.metadata["k2"] == "2"  # int converted to str

    # Now test with all optional fields None
    assessment2 = _make_assessment(
        span_id=None, rationale=None, assessment_id=None,
        metadata=None, overrides=None, valid=None,
    )
    proto2 = assessment_to_proto(assessment2)

    # Optional fields should not be set (or be empty/default)
    assert not proto2.HasField("span_id") or proto2.span_id == ""
    assert not proto2.HasField("rationale") or proto2.rationale == ""
    assert not proto2.HasField("assessment_id") or proto2.assessment_id == ""
    assert not proto2.HasField("overrides") or proto2.overrides == ""
    assert not proto2.HasField("valid") or proto2.valid is False
    assert len(proto2.metadata) == 0

    print("PASS:check_assessment_to_proto_optional_fields")


# ---------------------------------------------------------------------------
# C3: assessment_to_proto trace_location for v4 trace_id  (Dataflow)
# ---------------------------------------------------------------------------

def check_assessment_to_proto_trace_location_v4():
    """Contracts: C3"""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    v4_trace_id = construct_trace_id_v4(location="cat.sch", trace_id="inner123")
    assessment = _make_assessment(trace_id=v4_trace_id)

    proto = assessment_to_proto(assessment)

    # trace_location must be set with uc_schema from parsed trace_id
    assert proto.HasField("trace_location"), "trace_location must be set for v4 trace_id"
    assert proto.trace_location.HasField("uc_schema"), "uc_schema must be set"
    assert proto.trace_location.uc_schema.catalog_name == "cat"
    assert proto.trace_location.uc_schema.schema_name == "sch"

    # proto.trace_id should be the inner trace_id (parsed)
    assert proto.trace_id == "inner123", f"Expected inner123, got {proto.trace_id}"

    print("PASS:check_assessment_to_proto_trace_location_v4")


# ---------------------------------------------------------------------------
# C4: get_trace_id_from_assessment_proto UC schema  (Dataflow)
# ---------------------------------------------------------------------------

def check_get_trace_id_from_assessment_proto_uc_schema():
    """Contracts: C4"""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    proto = pb.Assessment()
    proto.trace_id = "inner-xyz"
    proto.trace_location.type = pb.TraceLocation.UC_SCHEMA
    proto.trace_location.uc_schema.catalog_name = "my_cat"
    proto.trace_location.uc_schema.schema_name = "my_sch"

    result = get_trace_id_from_assessment_proto(proto)

    expected = construct_trace_id_v4(location="my_cat.my_sch", trace_id="inner-xyz")
    assert result == expected, f"Expected {expected}, got {result}"

    print("PASS:check_get_trace_id_from_assessment_proto_uc_schema")


# ---------------------------------------------------------------------------
# C5: get_trace_id_from_assessment_proto no UC schema  (Dataflow)
# ---------------------------------------------------------------------------

def check_get_trace_id_from_assessment_proto_no_uc_schema():
    """Contracts: C5"""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    # pb.Assessment without trace_location (or with non-UC location)
    proto = pb.Assessment()
    proto.trace_id = "raw-trace-id-123"

    result = get_trace_id_from_assessment_proto(proto)
    assert result == "raw-trace-id-123", f"Expected raw-trace-id-123, got {result}"

    # Also test with MLFLOW_EXPERIMENT location type
    proto2 = pb.Assessment()
    proto2.trace_id = "exp-trace-456"
    proto2.trace_location.type = pb.TraceLocation.MLFLOW_EXPERIMENT
    proto2.trace_location.mlflow_experiment.experiment_id = "exp-1"

    result2 = get_trace_id_from_assessment_proto(proto2)
    assert result2 == "exp-trace-456", f"Expected exp-trace-456, got {result2}"

    print("PASS:check_get_trace_id_from_assessment_proto_no_uc_schema")


# ---------------------------------------------------------------------------
# C6: get_trace_id_from_assessment_proto dual proto types  (Interface)
# ---------------------------------------------------------------------------

def check_get_trace_id_from_assessment_proto_dual_types():
    """Contracts: C6"""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    # Test with assessments_pb2.Assessment (no trace_location field)
    ap = assessments_pb2.Assessment()
    ap.trace_id = "assess-proto-trace"

    result = get_trace_id_from_assessment_proto(ap)
    assert result == "assess-proto-trace", f"Expected assess-proto-trace, got {result}"

    # Test with pb.Assessment (databricks_tracing)
    dp = pb.Assessment()
    dp.trace_id = "db-proto-trace"

    result2 = get_trace_id_from_assessment_proto(dp)
    assert result2 == "db-proto-trace", f"Expected db-proto-trace, got {result2}"

    print("PASS:check_get_trace_id_from_assessment_proto_dual_types")


# ---------------------------------------------------------------------------
# C7: inference_table_location_to_proto  (Dataflow)
# ---------------------------------------------------------------------------

def check_inference_table_location_to_proto():
    """Contracts: C7"""
    from mlflow.utils.databricks_tracing_utils import inference_table_location_to_proto

    loc = InferenceTableLocation(full_table_name="cat.sch.tbl")
    proto = inference_table_location_to_proto(loc)

    assert isinstance(proto, pb.InferenceTableLocation)
    assert proto.full_table_name == "cat.sch.tbl"

    print("PASS:check_inference_table_location_to_proto")


# ---------------------------------------------------------------------------
# C8: mlflow_experiment_location_to_proto  (Dataflow)
# ---------------------------------------------------------------------------

def check_mlflow_experiment_location_to_proto():
    """Contracts: C8"""
    from mlflow.utils.databricks_tracing_utils import mlflow_experiment_location_to_proto

    loc = MlflowExperimentLocation(experiment_id="exp-42")
    proto = mlflow_experiment_location_to_proto(loc)

    assert isinstance(proto, pb.MlflowExperimentLocation)
    assert proto.experiment_id == "exp-42"

    print("PASS:check_mlflow_experiment_location_to_proto")


# ---------------------------------------------------------------------------
# C9: trace_from_proto return type  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_from_proto_return_type():
    """Contracts: C9"""
    from mlflow.utils.databricks_tracing_utils import trace_from_proto

    ti = _make_trace_info(uc_schema=False)
    proto = pb.Trace()
    proto.trace_info.CopyFrom(ti.to_proto())

    result = trace_from_proto(proto, location_id="loc-1")

    assert isinstance(result, Trace), f"Expected Trace, got {type(result)}"
    assert isinstance(result.info, TraceInfo)
    assert isinstance(result.data, TraceData)

    print("PASS:check_trace_from_proto_return_type")


# ---------------------------------------------------------------------------
# C10: trace_from_proto span construction  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_from_proto_span_construction():
    """Contracts: C10"""
    from mlflow.utils.databricks_tracing_utils import trace_from_proto
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    ti = _make_trace_info(uc_schema=False)
    proto = pb.Trace()
    proto.trace_info.CopyFrom(ti.to_proto())

    # Add a minimal OTel span to the proto
    otel_span = OTelProtoSpan()
    otel_span.name = "test-span"
    otel_span.trace_id = b"\x00" * 16
    otel_span.span_id = b"\x00" * 8
    otel_span.start_time_unix_nano = 1000000
    otel_span.end_time_unix_nano = 2000000
    proto.spans.append(otel_span)

    result = trace_from_proto(proto, location_id="loc-1")

    assert len(result.data.spans) == 1
    span = result.data.spans[0]
    assert isinstance(span, Span)
    assert span.name == "test-span"

    print("PASS:check_trace_from_proto_span_construction")


# ---------------------------------------------------------------------------
# C11: trace_info_to_v4_proto return type  (Interface)
# ---------------------------------------------------------------------------

def check_trace_info_to_v4_proto_return_type():
    """Contracts: C11"""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    ti = _make_trace_info(uc_schema=True)
    proto = trace_info_to_v4_proto(ti)

    assert isinstance(proto, pb.TraceInfo), f"Expected pb.TraceInfo, got {type(proto)}"

    print("PASS:check_trace_info_to_v4_proto_return_type")


# ---------------------------------------------------------------------------
# C12: trace_info_to_v4_proto basic mapping  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_info_to_v4_proto_basic_mapping():
    """Contracts: C12"""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    ti = _make_trace_info(uc_schema=True)
    ti.trace_id = construct_trace_id_v4(location="my_cat.my_schema", trace_id="inner-trace")

    proto = trace_info_to_v4_proto(ti)

    # trace_id should be parsed (inner part for UC schema)
    assert proto.trace_id == "inner-trace", f"Expected inner-trace, got {proto.trace_id}"

    # trace_location should be converted
    assert proto.HasField("trace_location")
    assert proto.trace_location.uc_schema.catalog_name == "my_cat"
    assert proto.trace_location.uc_schema.schema_name == "my_schema"

    # request_time as Timestamp
    assert proto.HasField("request_time")

    # state converted (OK = 1)
    assert proto.state == _pb_state_ok(), f"Expected OK state, got {proto.state}"

    # trace_metadata
    assert len(proto.trace_metadata) >= 1
    assert proto.trace_metadata["run_id"] == "run-1"

    # tags
    assert len(proto.tags) >= 1
    assert proto.tags["tag1"] == "val1"

    # client_request_id
    assert proto.client_request_id == "client-req-1"

    # request/response previews
    assert proto.request_preview == '{"q": "hello"}'
    assert proto.response_preview == '{"a": "hi"}'

    print("PASS:check_trace_info_to_v4_proto_basic_mapping")


# ---------------------------------------------------------------------------
# C13: trace_info_to_v4_proto execution_duration None  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_info_to_v4_proto_duration_none():
    """Contracts: C13"""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    ti = _make_trace_info(uc_schema=True)
    ti.execution_duration = None

    proto = trace_info_to_v4_proto(ti)

    # execution_duration should NOT be set when None
    assert not proto.HasField("execution_duration"), \
        "execution_duration must not be set when input is None"

    # Also test with a non-None value
    ti2 = _make_trace_info(uc_schema=True)
    ti2.execution_duration = 2500
    proto2 = trace_info_to_v4_proto(ti2)

    assert proto2.HasField("execution_duration"), \
        "execution_duration must be set when input is not None"

    print("PASS:check_trace_info_to_v4_proto_duration_none")


# ---------------------------------------------------------------------------
# C14: trace_location_from_proto UC_SCHEMA  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_location_from_proto_uc_schema():
    """Contracts: C14"""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.UC_SCHEMA
    proto.uc_schema.catalog_name = "cat1"
    proto.uc_schema.schema_name = "sch1"

    result = trace_location_from_proto(proto)

    assert result.type == TraceLocationType.UC_SCHEMA
    assert result.uc_schema is not None
    assert result.uc_schema.catalog_name == "cat1"
    assert result.uc_schema.schema_name == "sch1"

    print("PASS:check_trace_location_from_proto_uc_schema")


# ---------------------------------------------------------------------------
# C15: trace_location_from_proto MLFLOW_EXPERIMENT  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_location_from_proto_mlflow_experiment():
    """Contracts: C15"""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.MLFLOW_EXPERIMENT
    proto.mlflow_experiment.experiment_id = "exp-999"

    result = trace_location_from_proto(proto)

    assert result.type == TraceLocationType.MLFLOW_EXPERIMENT
    assert result.mlflow_experiment is not None
    assert result.mlflow_experiment.experiment_id == "exp-999"

    print("PASS:check_trace_location_from_proto_mlflow_experiment")


# ---------------------------------------------------------------------------
# C16: trace_location_from_proto INFERENCE_TABLE  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_location_from_proto_inference_table():
    """Contracts: C16"""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.INFERENCE_TABLE
    proto.inference_table.full_table_name = "a.b.c"

    result = trace_location_from_proto(proto)

    assert result.type == TraceLocationType.INFERENCE_TABLE
    assert result.inference_table is not None
    assert result.inference_table.full_table_name == "a.b.c"

    print("PASS:check_trace_location_from_proto_inference_table")


# ---------------------------------------------------------------------------
# C17: trace_location_from_proto fallback  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_location_from_proto_fallback():
    """Contracts: C17"""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto

    # Proto with no identifier set (defaults to TRACE_LOCATION_TYPE_UNSPECIFIED)
    proto = pb.TraceLocation()

    result = trace_location_from_proto(proto)

    assert result.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED

    print("PASS:check_trace_location_from_proto_fallback")


# ---------------------------------------------------------------------------
# C18: trace_location_to_proto UC_SCHEMA  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_location_to_proto_uc_schema():
    """Contracts: C18"""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto

    uc = UCSchemaLocation(catalog_name="cat_x", schema_name="sch_x")
    tl = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc)

    proto = trace_location_to_proto(tl)

    assert proto.type == pb.TraceLocation.UC_SCHEMA
    assert proto.HasField("uc_schema")
    assert proto.uc_schema.catalog_name == "cat_x"
    assert proto.uc_schema.schema_name == "sch_x"

    print("PASS:check_trace_location_to_proto_uc_schema")


# ---------------------------------------------------------------------------
# C20: trace_to_proto  (Dataflow)
# ---------------------------------------------------------------------------

def check_trace_to_proto():
    """Contracts: C20"""
    from mlflow.utils.databricks_tracing_utils import trace_to_proto

    ti = _make_trace_info(uc_schema=False)
    trace = Trace(info=ti, data=TraceData())

    proto = trace_to_proto(trace)

    assert isinstance(proto, pb.Trace)
    assert proto.HasField("trace_info")
    # The spans list should be present (may be empty)
    assert hasattr(proto, "spans")

    print("PASS:check_trace_to_proto")


# ---------------------------------------------------------------------------
# C21: uc_schema_location_from_proto with all fields  (Dataflow)
# ---------------------------------------------------------------------------

def check_uc_schema_location_from_proto():
    """Contracts: C21"""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto

    proto = pb.UCSchemaLocation()
    proto.catalog_name = "cat_all"
    proto.schema_name = "sch_all"
    proto.otel_spans_table_name = "my_spans"
    proto.otel_logs_table_name = "my_logs"

    result = uc_schema_location_from_proto(proto)

    assert result.catalog_name == "cat_all"
    assert result.schema_name == "sch_all"
    # Private attributes should be set via HasField
    assert result._otel_spans_table_name == "my_spans"
    assert result._otel_logs_table_name == "my_logs"

    print("PASS:check_uc_schema_location_from_proto")


# ---------------------------------------------------------------------------
# C22: uc_schema_location_from_proto optional fields  (Dataflow)
# ---------------------------------------------------------------------------

def check_uc_schema_location_from_proto_optional():
    """Contracts: C22"""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.entities.trace_location import (
        _UC_SCHEMA_DEFAULT_SPANS_TABLE_NAME,
        _UC_SCHEMA_DEFAULT_LOGS_TABLE_NAME,
    )

    # Proto without optional table names
    proto = pb.UCSchemaLocation()
    proto.catalog_name = "cat_min"
    proto.schema_name = "sch_min"

    result = uc_schema_location_from_proto(proto)

    assert result.catalog_name == "cat_min"
    assert result.schema_name == "sch_min"
    # HasField returns False for otel_spans/logs_table_name, so defaults remain
    assert result._otel_spans_table_name == _UC_SCHEMA_DEFAULT_SPANS_TABLE_NAME
    assert result._otel_logs_table_name == _UC_SCHEMA_DEFAULT_LOGS_TABLE_NAME

    print("PASS:check_uc_schema_location_from_proto_optional")


# ---------------------------------------------------------------------------
# C23: uc_schema_location_to_proto  (Dataflow)
# ---------------------------------------------------------------------------

def check_uc_schema_location_to_proto():
    """Contracts: C23"""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto

    uc = UCSchemaLocation(catalog_name="c_out", schema_name="s_out")
    uc._otel_spans_table_name = "custom_spans"
    uc._otel_logs_table_name = "custom_logs"

    proto = uc_schema_location_to_proto(uc)

    assert proto.catalog_name == "c_out"
    assert proto.schema_name == "s_out"
    assert proto.otel_spans_table_name == "custom_spans"
    assert proto.otel_logs_table_name == "custom_logs"

    print("PASS:check_uc_schema_location_to_proto")


# ---------------------------------------------------------------------------
# C25: AssessmentSourceType.__str__  (Interface)
# ---------------------------------------------------------------------------

def check_assessment_source_type_str():
    """Contracts: C25"""
    instance = AssessmentSourceType("HUMAN")
    s = str(instance)
    assert s == "HUMAN", f"Expected 'HUMAN', got '{s}'"

    instance2 = AssessmentSourceType("llm_judge")
    s2 = str(instance2)
    assert s2 == "LLM_JUDGE", f"Expected 'LLM_JUDGE', got '{s2}'"

    print("PASS:check_assessment_source_type_str")


# ---------------------------------------------------------------------------
# C26: AssessmentSourceType._standardize  (Interface)
# ---------------------------------------------------------------------------

def check_assessment_source_type_standardize():
    """Contracts: C26"""
    result = AssessmentSourceType._standardize("llm_judge")
    assert result == "LLM_JUDGE", f"Expected 'LLM_JUDGE', got '{result}'"

    result2 = AssessmentSourceType._standardize("HUMAN")
    assert result2 == "HUMAN", f"Expected 'HUMAN', got '{result2}'"

    result3 = AssessmentSourceType._standardize("code")
    assert result3 == "CODE", f"Expected 'CODE', got '{result3}'"

    print("PASS:check_assessment_source_type_standardize")


# ---------------------------------------------------------------------------
# C30: Span.inputs property  (Interface)
# ---------------------------------------------------------------------------

def check_span_inputs():
    """Contracts: C30"""
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    import opentelemetry.trace as trace_api

    otel_span = OTelReadableSpan(
        name="test",
        context=trace_api.SpanContext(
            trace_id=12345, span_id=222, is_remote=False, trace_flags=trace_api.TraceFlags(1)
        ),
        attributes={
            SpanAttributeKey.INPUTS: json.dumps({"x": 1, "y": [2, 3]}),
            "mlflow.traceRequestId": json.dumps("tr-1"),
        },
        start_time=0,
        end_time=1,
    )
    span = Span(otel_span)
    result = span.inputs
    assert result == {"x": 1, "y": [2, 3]}, f"Expected dict, got {result}"

    print("PASS:check_span_inputs")


# ---------------------------------------------------------------------------
# C31: Span.outputs property  (Interface)
# ---------------------------------------------------------------------------

def check_span_outputs():
    """Contracts: C31"""
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    import opentelemetry.trace as trace_api

    otel_span = OTelReadableSpan(
        name="test",
        context=trace_api.SpanContext(
            trace_id=12345, span_id=222, is_remote=False, trace_flags=trace_api.TraceFlags(1)
        ),
        attributes={
            SpanAttributeKey.OUTPUTS: json.dumps(42),
            "mlflow.traceRequestId": json.dumps("tr-1"),
        },
        start_time=0,
        end_time=1,
    )
    span = Span(otel_span)
    result = span.outputs
    assert result == 42, f"Expected 42, got {result}"

    print("PASS:check_span_outputs")


# ---------------------------------------------------------------------------
# C32: Span.inputs returns None when unset  (Dataflow)
# ---------------------------------------------------------------------------

def check_span_inputs_none():
    """Contracts: C32"""
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    import opentelemetry.trace as trace_api

    otel_span = OTelReadableSpan(
        name="test",
        context=trace_api.SpanContext(
            trace_id=12345, span_id=222, is_remote=False, trace_flags=trace_api.TraceFlags(1)
        ),
        attributes={
            "mlflow.traceRequestId": json.dumps("tr-1"),
        },
        start_time=0,
        end_time=1,
    )
    span = Span(otel_span)
    result = span.inputs
    assert result is None, f"Expected None, got {result}"

    print("PASS:check_span_inputs_none")


# ---------------------------------------------------------------------------
# C33: Span.outputs returns None when unset  (Dataflow)
# ---------------------------------------------------------------------------

def check_span_outputs_none():
    """Contracts: C33"""
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    import opentelemetry.trace as trace_api

    otel_span = OTelReadableSpan(
        name="test",
        context=trace_api.SpanContext(
            trace_id=12345, span_id=222, is_remote=False, trace_flags=trace_api.TraceFlags(1)
        ),
        attributes={
            "mlflow.traceRequestId": json.dumps("tr-1"),
        },
        start_time=0,
        end_time=1,
    )
    span = Span(otel_span)
    result = span.outputs
    assert result is None, f"Expected None, got {result}"

    print("PASS:check_span_outputs_none")


# ===========================================================================
# Main
# ===========================================================================

if __name__ == "__main__":
    checks = [
        check_assessment_to_proto_basic_fields,
        check_assessment_to_proto_optional_fields,
        check_assessment_to_proto_trace_location_v4,
        check_get_trace_id_from_assessment_proto_uc_schema,
        check_get_trace_id_from_assessment_proto_no_uc_schema,
        check_get_trace_id_from_assessment_proto_dual_types,
        check_inference_table_location_to_proto,
        check_mlflow_experiment_location_to_proto,
        check_trace_from_proto_return_type,
        check_trace_from_proto_span_construction,
        check_trace_info_to_v4_proto_return_type,
        check_trace_info_to_v4_proto_basic_mapping,
        check_trace_info_to_v4_proto_duration_none,
        check_trace_location_from_proto_uc_schema,
        check_trace_location_from_proto_mlflow_experiment,
        check_trace_location_from_proto_inference_table,
        check_trace_location_from_proto_fallback,
        check_trace_location_to_proto_uc_schema,
        check_trace_to_proto,
        check_uc_schema_location_from_proto,
        check_uc_schema_location_from_proto_optional,
        check_uc_schema_location_to_proto,
        check_assessment_source_type_str,
        check_assessment_source_type_standardize,
        check_span_inputs,
        check_span_outputs,
        check_span_inputs_none,
        check_span_outputs_none,
    ]
    for check in checks:
        check()
    print("\nAll architecture checks passed.")
