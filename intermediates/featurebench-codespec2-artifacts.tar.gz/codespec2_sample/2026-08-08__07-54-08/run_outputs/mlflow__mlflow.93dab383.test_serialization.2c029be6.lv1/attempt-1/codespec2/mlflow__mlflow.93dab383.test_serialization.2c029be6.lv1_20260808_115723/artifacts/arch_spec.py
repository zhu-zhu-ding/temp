"""
Architecture spec: public interface and graph connectivity.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts from the
semantic IR. Each check function asserts a specific contract with its ID
preserved in a comment.

Contracts covered:
  C1  - scorer decorator returns CustomScorer
  C2  - scorer parameterized usage returns partial
  C6  - model_dump produces valid SerializedScorer dict
  C7  - model_validate reconstructs decorator scorer
  C15 - AssessmentSourceType constants are strings
  C20 - scorer is importable from package
"""

import functools
import sys

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    sys.exit(1)


def _pass_msg(msg: str) -> None:
    print(f"PASS: {msg}")


# ===================================================================
# Contracts: C1
# ===================================================================
def check_c1_scorer_decorator_returns_custom_scorer() -> None:
    """
    Verify scorer(func) returns a Scorer instance with kind==DECORATOR.

    L2 Entry: scorer(func) at /testbed/mlflow/genai/scorers/base.py
    L3 Observer: RETURN_VALUE isinstance Scorer, kind == ScorerKind.DECORATOR
    """
    from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer

    def _dummy(outputs):
        return outputs != ""

    result = scorer(_dummy)
    assert isinstance(result, Scorer), f"Expected Scorer instance, got {type(result)}"
    assert result.kind == ScorerKind.DECORATOR, (
        f"Expected ScorerKind.DECORATOR, got {result.kind}"
    )
    _pass_msg("C1: scorer(func) returns CustomScorer with kind DECORATOR")


# ===================================================================
# Contracts: C2
# ===================================================================
def check_c2_scorer_parameterized_returns_partial() -> None:
    """
    Verify scorer(name=..., description=...) returns partial that can decorate.

    L2 Entry: scorer(name="my_name", description="Test desc")
    L3 Observer: RETURN_VALUE isinstance functools.partial, callable, bound kwargs
    """
    from mlflow.genai.scorers.base import Scorer, scorer

    partial = scorer(name="my_custom_name", description="Test desc")
    assert isinstance(partial, functools.partial), (
        f"Expected functools.partial, got {type(partial)}"
    )
    assert callable(partial), "Partial should be callable"

    # Apply the partial to a function → yields a Scorer with custom name
    scorer_instance = partial(lambda outputs: True)
    assert isinstance(scorer_instance, Scorer), (
        f"Expected Scorer instance, got {type(scorer_instance)}"
    )
    assert scorer_instance.name == "my_custom_name", (
        f"Expected name 'my_custom_name', got {scorer_instance.name}"
    )
    assert scorer_instance.description == "Test desc", (
        f"Expected description 'Test desc', got {scorer_instance.description}"
    )
    _pass_msg("C2: scorer(name=...) returns partial that produces Scorer with custom name")


# ===================================================================
# Contracts: C6
# ===================================================================
def check_c6_model_dump_produces_valid_serialized_dict() -> None:
    """
    Verify model_dump() extracts source code into a dict with expected keys.

    L2 Entry: scorer_instance.model_dump()
    L3 Observer: dict CONTAINS name, call_source, call_signature, original_func_name,
                 mlflow_version, serialization_version; None for non-decorator fields.
    """
    from mlflow.genai.scorers.base import scorer

    @scorer
    def my_scorer(outputs):
        return len(outputs) > 0

    d = my_scorer.model_dump()

    # Core fields
    assert d["name"] == "my_scorer", f"Expected name 'my_scorer', got {d.get('name')}"
    assert isinstance(d["call_source"], str) and len(d["call_source"]) > 0, (
        "call_source must be non-empty string"
    )
    assert isinstance(d["call_signature"], str) and len(d["call_signature"]) > 0, (
        "call_signature must be non-empty string"
    )
    assert d["original_func_name"] == "my_scorer", (
        f"Expected original_func_name 'my_scorer', got {d.get('original_func_name')}"
    )
    # Version metadata
    assert "mlflow_version" in d, "mlflow_version key required"
    assert d["serialization_version"] is not None, "serialization_version must be set"
    # Non-decorator fields should be None
    assert d.get("builtin_scorer_class") is None, "builtin_scorer_class must be None"
    assert d.get("builtin_scorer_pydantic_data") is None, (
        "builtin_scorer_pydantic_data must be None"
    )
    assert d.get("instructions_judge_pydantic_data") is None, (
        "instructions_judge_pydantic_data must be None"
    )
    _pass_msg("C6: model_dump produces valid SerializedScorer dict with source code")


# ===================================================================
# Contracts: C7
# ===================================================================
def check_c7_model_validate_reconstructs_decorator_scorer() -> None:
    """
    Verify Scorer.model_validate reconstructs a working scorer from serialized dict.

    L2 Entry: Scorer.model_validate(serialized_dict)
    L3 Observer: reconstructed Scorer PRESERVE original behavior when run()
    """
    from unittest.mock import patch

    from mlflow.genai.scorers.base import Scorer, scorer

    @scorer
    def original(outputs):
        return len(outputs) > 3

    serialized_dict = original.model_dump()

    # model_validate for decorator scorers requires Databricks runtime;
    # mock it so we can test the reconstruction path end-to-end
    with patch(
        "mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True
    ):
        reconstructed = Scorer.model_validate(serialized_dict)

    assert isinstance(reconstructed, Scorer), (
        f"Expected Scorer instance, got {type(reconstructed)}"
    )
    assert reconstructed.name == "original", (
        f"Expected name 'original', got {reconstructed.name}"
    )

    # Run both and compare — behaviour must be preserved
    result_orig = original.run(outputs="hello")
    result_recon = reconstructed.run(outputs="hello")
    assert result_orig == result_recon, (
        f"Expected same result, got {result_orig} vs {result_recon}"
    )

    result_orig2 = original.run(outputs="hi")
    result_recon2 = reconstructed.run(outputs="hi")
    assert result_orig2 == result_recon2, (
        f"Expected same result, got {result_orig2} vs {result_recon2}"
    )
    _pass_msg("C7: model_validate reconstructs decorator scorer with preserved behavior")


# ===================================================================
# Contracts: C15
# ===================================================================
def check_c15_assessment_source_type_constants_are_strings() -> None:
    """
    Verify each AssessmentSourceType constant is a str equal to its name.

    L2 Entry: from mlflow.entities.assessment_source import AssessmentSourceType
    L3 Observer: TYPE_IS str for HUMAN, LLM_JUDGE, CODE, SOURCE_TYPE_UNSPECIFIED
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED", (
        f"Expected 'SOURCE_TYPE_UNSPECIFIED', "
        f"got {AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED!r}"
    )
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE", (
        f"Expected 'LLM_JUDGE', got {AssessmentSourceType.LLM_JUDGE!r}"
    )
    assert AssessmentSourceType.HUMAN == "HUMAN", (
        f"Expected 'HUMAN', got {AssessmentSourceType.HUMAN!r}"
    )
    assert AssessmentSourceType.CODE == "CODE", (
        f"Expected 'CODE', got {AssessmentSourceType.CODE!r}"
    )
    # AI_JUDGE is deprecated but still a valid class constant
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE", (
        f"Expected 'AI_JUDGE', got {AssessmentSourceType.AI_JUDGE!r}"
    )
    # _SOURCE_TYPES list exists and contains the valid types (excludes AI_JUDGE)
    assert hasattr(AssessmentSourceType, "_SOURCE_TYPES"), "_SOURCE_TYPES should exist"
    assert isinstance(AssessmentSourceType._SOURCE_TYPES, list), (
        "_SOURCE_TYPES should be a list"
    )
    assert "HUMAN" in AssessmentSourceType._SOURCE_TYPES, "HUMAN should be in _SOURCE_TYPES"
    assert "LLM_JUDGE" in AssessmentSourceType._SOURCE_TYPES, (
        "LLM_JUDGE should be in _SOURCE_TYPES"
    )
    assert "CODE" in AssessmentSourceType._SOURCE_TYPES, "CODE should be in _SOURCE_TYPES"
    assert "SOURCE_TYPE_UNSPECIFIED" in AssessmentSourceType._SOURCE_TYPES, (
        "SOURCE_TYPE_UNSPECIFIED should be in _SOURCE_TYPES"
    )
    _pass_msg("C15: AssessmentSourceType constants are strings and _SOURCE_TYPES list valid")


# ===================================================================
# Contracts: C20
# ===================================================================
def check_c20_scorer_importable_from_package() -> None:
    """
    Verify scorer is importable and callable from mlflow.genai.scorers.

    L2 Entry: from mlflow.genai.scorers import scorer
    L3 Observer: TYPE_IS callable
    """
    from mlflow.genai.scorers import scorer
    assert callable(scorer), f"scorer should be callable, got {type(scorer)}"
    _pass_msg("C20: scorer is importable and callable from mlflow.genai.scorers")


# ===================================================================
# Main runner
# ===================================================================
def main() -> None:
    checks = [
        ("C1", check_c1_scorer_decorator_returns_custom_scorer),
        ("C2", check_c2_scorer_parameterized_returns_partial),
        ("C6", check_c6_model_dump_produces_valid_serialized_dict),
        ("C7", check_c7_model_validate_reconstructs_decorator_scorer),
        ("C15", check_c15_assessment_source_type_constants_are_strings),
        ("C20", check_c20_scorer_importable_from_package),
    ]
    for cid, fn in checks:
        try:
            fn()
        except Exception as e:
            _fail(f"{cid}: {e}")

    print("arch_spec: ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
