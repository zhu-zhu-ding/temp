"""
Behavior spec: outcomes, state, failures, side effects, defaults, boundaries,
and compatibility.

Covers L3 State, Behavior, Failure, SideEffect contracts from the semantic IR.
Each check function asserts a specific contract with its ID preserved in a
nearby comment.

Contracts covered:
  C3  - Scorer.run parameter filtering
  C4  - Scorer.run validates return types
  C5  - Scorer.run overwrites default feedback name
  C8  - model_validate raises for unknown scorer format
  C9  - Security guard blocks deserialization outside Databricks
  C10 - AssessmentSourceType.__init__ validates source type
  C11 - _standardize returns uppercase string
  C12 - _parse raises for invalid source type
  C13 - _parse issues deprecation warning for AI_JUDGE
  C14 - AssessmentSource.__post_init__ standardizes source_type
  C16 - extract_function_body extracts body without signature/docstring
  C17 - recreate_function builds callable from source
  C18 - SerializedScorer validates single scorer type
  C19 - Scorer.register blocks decorator scorers outside Databricks
  C21 - SerializedScorer rejects zero scorer types
  C22 - FunctionBodyExtractor skips docstring
"""

import sys
import warnings

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    sys.exit(1)


def _pass_msg(msg: str) -> None:
    print(f"PASS: {msg}")


# ===================================================================
# Contracts: C3
# ===================================================================
def check_c3_run_parameter_filtering() -> None:
    """
    Verify Scorer.run only forwards parameters present in __call__ signature.

    L2 Entry: scorer_instance.run(inputs=..., outputs=..., expectations=..., trace=...)
    L3 Observer: underlying function receives only declared parameters (PRESERVE)
    """
    from mlflow.genai.scorers.base import scorer

    # Function that only accepts outputs
    @scorer
    def f_only_outputs(outputs):
        return f"got: {outputs}"

    result = f_only_outputs.run(
        inputs="extra_input",
        outputs="actual_output",
        expectations={"key": "value"},
        trace=None,
    )
    assert result == "got: actual_output", f"Expected 'got: actual_output', got {result!r}"

    # Function that accepts inputs and outputs
    @scorer
    def f_inputs_outputs(inputs, outputs):
        return f"{inputs} -> {outputs}"

    result = f_inputs_outputs.run(
        inputs="in_val",
        outputs="out_val",
        expectations={"key": "value"},
        trace=None,
    )
    assert result == "in_val -> out_val", f"Expected 'in_val -> out_val', got {result!r}"

    # Function that only accepts trace
    @scorer
    def f_only_trace(trace):
        return trace is None

    result = f_only_trace.run(inputs="x", outputs="y", expectations={}, trace=None)
    assert result is True, f"Expected True, got {result!r}"

    # Function that takes NO scorer params (only self)
    @scorer
    def f_no_params():
        return 42

    result = f_no_params.run(inputs="x", outputs="y", expectations={}, trace=None)
    assert result == 42, f"Expected 42, got {result!r}"

    _pass_msg("C3: Scorer.run filters parameters to only accepted subset")


# ===================================================================
# Contracts: C4
# ===================================================================
def check_c4_run_return_type_validation() -> None:
    """
    Verify MlflowException raised for unsupported return types.

    L2 Entry: scorer_instance.run(outputs=...)
    L3 Observer: EXCEPTION MlflowException for dict, tuple; no exception for
                 int, float, bool, str, Feedback, None
    """
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import scorer

    # Invalid: dict
    @scorer
    def bad_dict(outputs):
        return {"key": "value"}

    try:
        bad_dict.run(outputs="test")
        _fail("C4: Expected MlflowException for dict return type")
    except MlflowException as e:
        msg = str(e)
        assert "must return one of" in msg.lower() or "must return one of" in msg, (
            f"Exception message should mention valid return types, got: {msg}"
        )

    # Invalid: tuple
    @scorer
    def bad_tuple(outputs):
        return (1, 2)

    try:
        bad_tuple.run(outputs="test")
        _fail("C4: Expected MlflowException for tuple return type")
    except MlflowException:
        pass

    # Valid: bool
    @scorer
    def good_bool(outputs):
        return True
    good_bool.run(outputs="test")

    # Valid: int
    @scorer
    def good_int(outputs):
        return 42
    good_int.run(outputs="test")

    # Valid: float
    @scorer
    def good_float(outputs):
        return 3.14
    good_float.run(outputs="test")

    # Valid: str
    @scorer
    def good_str(outputs):
        return "ok"
    good_str.run(outputs="test")

    # Valid: None
    @scorer
    def good_none(outputs):
        return None
    good_none.run(outputs="test")

    _pass_msg("C4: Scorer.run raises MlflowException for invalid return types")


# ===================================================================
# Contracts: C5
# ===================================================================
def check_c5_run_overwrites_default_feedback_name() -> None:
    """
    Verify Feedback with DEFAULT_FEEDBACK_NAME gets renamed to scorer name.

    L2 Entry: scorer_instance.run(outputs=...) returns Feedback
    L3 Observer: RETURN_VALUE feedback.name EQ scorer.name when default name used
    """
    from mlflow.entities import Feedback
    from mlflow.genai.scorers.base import scorer

    @scorer
    def my_scorer(outputs):
        return Feedback(value=42)

    feedback = my_scorer.run(outputs="test")
    assert feedback.name == "my_scorer", (
        f"Expected name 'my_scorer', got {feedback.name!r}"
    )
    assert feedback.value == 42

    # Feedback with explicit name should NOT be overwritten
    @scorer
    def named_scorer(outputs):
        return Feedback(name="custom_name", value=99)

    feedback = named_scorer.run(outputs="test")
    assert feedback.name == "custom_name", (
        f"Expected 'custom_name', got {feedback.name!r}"
    )

    _pass_msg("C5: Scorer.run renames default-feedback-name to scorer name")


# ===================================================================
# Contracts: C8
# ===================================================================
def check_c8_model_validate_raises_for_unknown_format() -> None:
    """
    Verify MlflowException when deserializing dict lacking all scorer type fields.

    L2 Entry: Scorer.model_validate({"name": "test"})
    L3 Observer: EXCEPTION MlflowException with "unknown format" message
    """
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer

    try:
        Scorer.model_validate({"name": "test_scorer"})
        _fail("C8: Expected MlflowException for unknown format")
    except MlflowException as e:
        msg = str(e)
        assert "unknown format" in msg.lower() or "failed to load" in msg.lower(), (
            f"Exception should mention unknown format, got: {msg}"
        )

    _pass_msg("C8: model_validate raises MlflowException for unknown scorer format")


# ===================================================================
# Contracts: C9
# ===================================================================
def check_c9_security_guard_blocks_deserialization_outside_databricks() -> None:
    """
    Verify _reconstruct_decorator_scorer raises outside Databricks runtime.

    L2 Entry: Scorer._reconstruct_decorator_scorer(serialized)
    L3 Observer: EXCEPTION MlflowException with "not supported outside" message
    """
    from unittest.mock import patch

    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer, SerializedScorer

    serialized = SerializedScorer(
        name="test_scorer",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="test_scorer",
    )

    with patch(
        "mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=False
    ):
        try:
            Scorer._reconstruct_decorator_scorer(serialized)
            _fail("C9: Expected MlflowException outside Databricks runtime")
        except MlflowException as e:
            msg = str(e)
            assert "not supported outside of" in msg.lower() or "not supported" in msg.lower(), (
                f"Exception should mention 'not supported outside', got: {msg}"
            )

    _pass_msg("C9: Security guard blocks deserialization outside Databricks runtime")


# ===================================================================
# Contracts: C10
# ===================================================================
def check_c10_assessment_source_type_init_validates() -> None:
    """
    Verify AssessmentSourceType accepts valid types and rejects invalid ones.

    L2 Entry: AssessmentSourceType(source_type_string)
    L3 Observer: EXCEPTION MlflowException for invalid; normalized str for valid
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    # Valid types should work and be stored as uppercase
    for vt in ["HUMAN", "LLM_JUDGE", "CODE", "SOURCE_TYPE_UNSPECIFIED"]:
        instance = AssessmentSourceType(vt)
        assert str(instance) == vt, f"Expected {vt!r}, got {str(instance)!r}"

    # Lowercase should be normalized
    instance = AssessmentSourceType("human")
    assert str(instance) == "HUMAN", f"Expected 'HUMAN', got {str(instance)!r}"

    # Invalid type should raise
    try:
        AssessmentSourceType("ROBOT")
        _fail("C10: Expected MlflowException for invalid type 'ROBOT'")
    except MlflowException as e:
        msg = str(e)
        assert "invalid assessment source type" in msg.lower(), (
            f"Exception should mention 'invalid assessment source type', got: {msg}"
        )
        assert "ROBOT" in msg, f"Exception should include invalid value 'ROBOT', got: {msg}"

    _pass_msg("C10: AssessmentSourceType.__init__ validates and normalizes source types")


# ===================================================================
# Contracts: C11
# ===================================================================
def check_c11_standardize_returns_uppercase() -> None:
    """
    Verify _standardize normalizes case for all valid source type inputs.

    L2 Entry: AssessmentSourceType._standardize(source_type_string)
    L3 Observer: RETURN_VALUE EQ uppercase string
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("Human") == "HUMAN"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("code") == "CODE"
    assert (
        AssessmentSourceType._standardize("source_type_unspecified")
        == "SOURCE_TYPE_UNSPECIFIED"
    )

    _pass_msg("C11: _standardize returns uppercase, case-normalized source type")


# ===================================================================
# Contracts: C12
# ===================================================================
def check_c12_parse_raises_for_invalid() -> None:
    """
    Verify _parse raises MlflowException for invalid source type.

    L2 Entry: AssessmentSourceType._parse(invalid_string)
    L3 Observer: EXCEPTION MlflowException with "Invalid assessment source type"
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    try:
        AssessmentSourceType._parse("INVALID_TYPE")
        _fail("C12: Expected MlflowException for invalid type")
    except MlflowException as e:
        msg = str(e)
        assert "invalid assessment source type" in msg.lower(), (
            f"Exception should mention 'invalid assessment source type', got: {msg}"
        )

    # Valid types should work
    assert AssessmentSourceType._parse("HUMAN") == "HUMAN"
    assert AssessmentSourceType._parse("human") == "HUMAN"
    assert AssessmentSourceType._parse("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("CODE") == "CODE"

    _pass_msg("C12: _parse raises MlflowException for invalid source types")


# ===================================================================
# Contracts: C13
# ===================================================================
def check_c13_parse_deprecation_warning_for_ai_judge() -> None:
    """
    Verify _parse emits FutureWarning for AI_JUDGE and converts to LLM_JUDGE.

    L2 Entry: AssessmentSourceType._parse("AI_JUDGE")
    L3 Observer: SIDE_EFFECT FutureWarning emitted; RETURN_VALUE EQ "LLM_JUDGE"
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._parse("AI_JUDGE")
        assert result == "LLM_JUDGE", (
            f"Expected AI_JUDGE to be converted to LLM_JUDGE, got {result!r}"
        )
        assert len(w) >= 1, "Expected at least one warning for AI_JUDGE"
        future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        assert len(future_warnings) >= 1, "Expected a FutureWarning for AI_JUDGE"
        msg = str(future_warnings[0].message)
        assert "AI_JUDGE" in msg and "deprecated" in msg.lower(), (
            f"Warning should mention AI_JUDGE deprecation, got: {msg}"
        )

    # Case-insensitive AI_JUDGE should also trigger warning
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._parse("ai_judge")
        assert result == "LLM_JUDGE", (
            f"Expected lowercase ai_judge to be converted to LLM_JUDGE, got {result!r}"
        )
        future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        assert len(future_warnings) >= 1, "Expected a FutureWarning for 'ai_judge'"

    _pass_msg("C13: _parse emits FutureWarning for AI_JUDGE and converts to LLM_JUDGE")


# ===================================================================
# Contracts: C14
# ===================================================================
def check_c14_assessment_source_post_init_standardizes() -> None:
    """
    Verify AssessmentSource standardizes source_type on initialization.

    L2 Entry: AssessmentSource(source_type=...)
    L3 Observer: STATE self.source_type is uppercase-validated after __post_init__
    """
    from mlflow.entities.assessment_source import AssessmentSource

    src = AssessmentSource(source_type="human", source_id="user_1")
    assert src.source_type == "HUMAN", f"Expected 'HUMAN', got {src.source_type!r}"

    src = AssessmentSource(source_type="llm_judge", source_id="gpt-4")
    assert src.source_type == "LLM_JUDGE", f"Expected 'LLM_JUDGE', got {src.source_type!r}"

    src = AssessmentSource(source_type="CODE", source_id="script.py")
    assert src.source_type == "CODE", f"Expected 'CODE', got {src.source_type!r}"

    # Deprecated AI_JUDGE converted to LLM_JUDGE
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", FutureWarning)
        src = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
        assert src.source_type == "LLM_JUDGE", (
            f"Expected 'LLM_JUDGE', got {src.source_type!r}"
        )

    # Default source_id
    src = AssessmentSource(source_type="HUMAN")
    assert src.source_id == "default", f"Expected 'default', got {src.source_id!r}"

    _pass_msg("C14: AssessmentSource.__post_init__ standardizes source_type")


# ===================================================================
# Contracts: C16
# ===================================================================
def check_c16_extract_function_body() -> None:
    """
    Verify extract_function_body returns body without def/signature/docstring.

    L2 Entry: extract_function_body(func)
    L3 Observer: RETURN_VALUE EQ (body_string, indent_int) without def/docstring
    """
    from mlflow.genai.scorers.scorer_utils import extract_function_body

    def simple_add(x, y):
        return x + y

    body, indent = extract_function_body(simple_add)
    assert isinstance(body, str), f"Body should be string, got {type(body)}"
    assert isinstance(indent, int), f"Indent should be int, got {type(indent)}"
    assert "return x + y" in body, f"Body should contain return statement, got: {body!r}"
    assert "def " not in body, f"Body should not contain 'def', got: {body!r}"

    def func_with_docstring():
        """This is a docstring"""
        return 42

    body2, _ = extract_function_body(func_with_docstring)
    assert "return 42" in body2, f"Body should contain return, got: {body2!r}"
    assert "docstring" not in body2, (
        f"Body should not contain docstring text, got: {body2!r}"
    )

    def complex_func(x):
        if x > 0:
            return "positive"
        else:
            return "non-positive"

    body3, _ = extract_function_body(complex_func)
    assert "if x > 0" in body3, f"Body should contain if-statement, got: {body3!r}"
    assert "return" in body3

    _pass_msg("C16: extract_function_body extracts body without signature and docstring")


# ===================================================================
# Contracts: C17
# ===================================================================
def check_c17_recreate_function() -> None:
    """
    Verify recreate_function builds a working callable from source code strings.

    L2 Entry: recreate_function(source, signature, name)
    L3 Observer: RETURN_VALUE EQ callable with expected behavior
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    # Simple arithmetic
    f = recreate_function("return x + y", "(x, y)", "add")
    assert f.__name__ == "add", f"Expected name 'add', got {f.__name__!r}"
    assert f(3, 4) == 7, f"Expected 7, got {f(3, 4)}"
    assert f(10, -5) == 5, f"Expected 5, got {f(10, -5)}"

    # Control flow
    f2 = recreate_function(
        "if x > 0:\n    return 'positive'\nelse:\n    return 'non-positive'",
        "(x)",
        "classify",
    )
    assert f2(5) == "positive"
    assert f2(-1) == "non-positive"

    # Default parameters
    f3 = recreate_function("return base ** exponent", "(base, exponent=2)", "power")
    assert f3(3) == 9
    assert f3(2, 3) == 8

    # No-args function
    f4 = recreate_function("return 42", "()", "answer")
    assert f4() == 42

    # Function using Feedback (available in exec namespace)
    f5 = recreate_function(
        "return Feedback(value=len(text), rationale=f'Len: {len(text)}')",
        "(text)",
        "len_checker",
    )
    from mlflow.entities import Feedback
    result = f5("hello")
    assert isinstance(result, Feedback), f"Expected Feedback, got {type(result)}"
    assert result.value == 5

    _pass_msg("C17: recreate_function builds working callables from source")


# ===================================================================
# Contracts: C18
# ===================================================================
def check_c18_serialized_scorer_rejects_multiple_types() -> None:
    """
    Verify ValueError when SerializedScorer has multiple scorer-type fields.

    L2 Entry: SerializedScorer(call_source=..., builtin_scorer_class=...)
    L3 Observer: EXCEPTION ValueError with "cannot have multiple types"
    """
    from mlflow.genai.scorers.base import SerializedScorer

    try:
        SerializedScorer(
            name="bad",
            call_source="return 1",
            call_signature="()",
            original_func_name="f",
            builtin_scorer_class="SomeClass",
        )
        _fail("C18: Expected ValueError for multiple scorer types")
    except ValueError as e:
        msg = str(e)
        assert "cannot have multiple types" in msg.lower(), (
            f"Expected 'cannot have multiple types', got: {msg}"
        )

    _pass_msg("C18: SerializedScorer raises ValueError for multiple scorer types")


# ===================================================================
# Contracts: C19
# ===================================================================
def check_c19_register_blocks_decorator_outside_databricks() -> None:
    """
    Verify decorator scorer registration raises MlflowException outside Databricks.

    L2 Entry: scorer_instance.register(experiment_id=...)
    L3 Observer: EXCEPTION MlflowException with Databricks tracking restriction message
    """
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import scorer

    @scorer
    def test_scorer(outputs):
        return len(outputs) > 0

    try:
        test_scorer.register(experiment_id="12345", name="test_scorer")
        _fail("C19: Expected MlflowException for registration outside Databricks")
    except MlflowException as e:
        msg = str(e)
        assert (
            "not supported outside of databricks tracking" in msg.lower()
            or "not supported outside of databricks" in msg.lower()
        ), f"Exception should mention Databricks restriction, got: {msg}"

    _pass_msg("C19: register blocks decorator scorers outside Databricks tracking")


# ===================================================================
# Contracts: C21
# ===================================================================
def check_c21_serialized_scorer_rejects_zero_types() -> None:
    """
    Verify ValueError when SerializedScorer has no scorer-type fields.

    L2 Entry: SerializedScorer(name="empty")
    L3 Observer: EXCEPTION ValueError with "must have either" message
    """
    from mlflow.genai.scorers.base import SerializedScorer

    try:
        SerializedScorer(name="empty")
        _fail("C21: Expected ValueError for zero scorer types")
    except ValueError as e:
        msg = str(e)
        assert (
            "must have either" in msg.lower()
            or "builtin scorer" in msg.lower()
            or "decorator scorer" in msg.lower()
            or "instructions judge" in msg.lower()
        ), f"Exception should mention required scorer fields, got: {msg}"

    _pass_msg("C21: SerializedScorer raises ValueError for zero scorer types")


# ===================================================================
# Contracts: C22
# ===================================================================
def check_c22_function_body_extractor_skips_docstring() -> None:
    """
    Verify body extraction skips docstring (first string constant statement).

    L2 Entry: extract_function_body(func_with_docstring)
    L3 Observer: RETURN_VALUE body does not contain docstring text
    """
    from mlflow.genai.scorers.scorer_utils import extract_function_body

    def func_with_doc():
        """This is a docstring."""
        return 1

    body, _ = extract_function_body(func_with_doc)
    assert "return 1" in body, f"Body should contain executable code, got: {body!r}"
    assert "This is a docstring" not in body, (
        f"Body should NOT contain docstring text, got: {body!r}"
    )

    def func_with_multiline_doc():
        """Line one.
        Line two.
        """
        x = 1
        y = 2
        return x + y

    body2, _ = extract_function_body(func_with_multiline_doc)
    assert "x = 1" in body2, f"Body should contain 'x = 1', got: {body2!r}"
    assert "Line one" not in body2, f"Body should not contain docstring, got: {body2!r}"
    assert "return x + y" in body2

    _pass_msg("C22: FunctionBodyExtractor skips docstring, returns only executable body")


# ===================================================================
# Main runner
# ===================================================================
def main() -> None:
    checks = [
        ("C3", check_c3_run_parameter_filtering),
        ("C4", check_c4_run_return_type_validation),
        ("C5", check_c5_run_overwrites_default_feedback_name),
        ("C8", check_c8_model_validate_raises_for_unknown_format),
        ("C9", check_c9_security_guard_blocks_deserialization_outside_databricks),
        ("C10", check_c10_assessment_source_type_init_validates),
        ("C11", check_c11_standardize_returns_uppercase),
        ("C12", check_c12_parse_raises_for_invalid),
        ("C13", check_c13_parse_deprecation_warning_for_ai_judge),
        ("C14", check_c14_assessment_source_post_init_standardizes),
        ("C16", check_c16_extract_function_body),
        ("C17", check_c17_recreate_function),
        ("C18", check_c18_serialized_scorer_rejects_multiple_types),
        ("C19", check_c19_register_blocks_decorator_outside_databricks),
        ("C21", check_c21_serialized_scorer_rejects_zero_types),
        ("C22", check_c22_function_body_extractor_skips_docstring),
    ]
    for cid, fn in checks:
        try:
            fn()
        except Exception as e:
            _fail(f"{cid}: {e}")

    print("behavior_spec: ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
