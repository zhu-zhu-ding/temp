# Semantic IR

## L1. Requirement Obligations

### R1: Scorer Decorator Entry Point
- **Type:** Interface
- **Statement:** A `scorer` callable must exist at `/testbed/mlflow/genai/scorers/base.py` that can be used as a decorator (without call parentheses) or as a parameterized decorator factory (with keyword arguments `name`, `description`, `aggregations`). When `func` is `None`, it must return a `functools.partial` bound to the keyword arguments for later decoration.
- **Task Evidence:** "A decorator to define a custom scorer that can be used in ``mlflow.genai.evaluate()``." The docstring shows `@scorer` usage and parameterized `@scorer(name=...)` usage. Also: `Args: func: The scorer function to be decorated. name: The name of the scorer. description: A description... aggregations: A list of aggregation functions...`
- **Acceptance:** `scorer(func)` returns a `CustomScorer` (subclass of `Scorer`) instance. `scorer(name="x")` returns a callable that when called with a function returns a `CustomScorer`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:847` defines the full `scorer` function. `/testbed/tests/genai/scorers/test_scorer.py:14` imports `from mlflow.genai.scorers.base import SerializedScorer` and uses `scorer` in tests. `/testbed/tests/genai/scorers/test_validation.py:8` imports `from mlflow.genai.scorers.base import Scorer, scorer`.
- **Uncertainty:** None.

### R2: CustomScorer Class Creation
- **Type:** Behavior
- **Statement:** When `scorer` is applied to a function, it must create a `CustomScorer` subclass of `Scorer` that stores the original function reference in a `_original_func` private attribute, delegates `__call__` to the original function, and sets `kind` to `ScorerKind.DECORATOR`.
- **Task Evidence:** Docstring implies decorated functions become usable scorer instances. The `@scorer` decorator pattern requires the returned object to be callable with the original function's signature (plus `self`).
- **Acceptance:** `isinstance(result, Scorer)` is True. `result._original_func` is the decorated function. `result.kind == ScorerKind.DECORATOR`. Calling `result(inputs=..., outputs=...)` invokes the original function.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1031` defines `CustomScorer` class with `_original_func`, `__call__` delegation, and `kind` property. `/testbed/tests/genai/scorers/test_scorer.py:72-73` tests `scorer(always_yes)` returns a usable scorer.
- **Uncertainty:** None.

### R3: Scorer Parameter Subset Dispatch
- **Type:** Behavior
- **Statement:** The `Scorer.run` method must accept `inputs`, `outputs`, `expectations`, and `trace` keyword arguments, filter them to only those accepted by the underlying function's signature, call the function, and validate the return type.
- **Task Evidence:** "The scorer function should take in a **subset** of the following parameters: inputs, outputs, expectations, trace." The interface description lists all four parameters with descriptions.
- **Acceptance:** Calling `scorer_instance.run(inputs=x, outputs=y)` invokes the underlying function with only `inputs` and `outputs` if the function only declares those parameters. Calling `scorer_instance.run(trace=t)` invokes with only `trace` if the function only declares `trace`.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:372-425` defines `Scorer.run` with parameter filtering via `inspect.signature(self.__call__)`. `/testbed/tests/genai/scorers/test_scorer.py` tests `my_scorer.run(inputs=..., outputs=...)`.
- **Uncertainty:** None.

### R4: Return Type Validation
- **Type:** Failure
- **Statement:** `Scorer.run` must raise `MlflowException` when the scorer returns a type other than `int`, `float`, `bool`, `str`, `Feedback`, `list[Feedback]`, `Assessment`, `list[Assessment]`, or `None`.
- **Task Evidence:** "The scorer function should return one of the following: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects." Also: "Raises: MlflowException: If the scorer function returns an unsupported type."
- **Acceptance:** Returning `dict` or `tuple` raises `MlflowException` with message about valid return types and the invalid type name.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:393-403` validates return types and raises `MlflowException`. `/testbed/tests/genai/scorers/test_scorer.py` tests various return types.
- **Uncertainty:** None.

### R5: Serialization (model_dump with Source Extraction)
- **Type:** Dataflow
- **Statement:** `Scorer.model_dump` must serialize a decorator scorer into a `dict` by extracting the original function's source code body, signature, and name, then constructing a `SerializedScorer` dataclass and converting it to dict via `asdict`. The result must be cached in `_cached_dump`.
- **Task Evidence:** "Provide secure serialization that handles source code extraction and reconstruction." The `SerializedScorer` dataclass includes `call_source`, `call_signature`, `original_func_name` fields.
- **Acceptance:** For a decorated `@scorer` function, `scorer_instance.model_dump()` returns a dict with keys `name`, `call_source` (non-empty string), `call_signature` (e.g., `"(outputs)"`), `original_func_name`, `mlflow_version`, `serialization_version`, `aggregations`, `description`, and `None` for `builtin_scorer_class`, `builtin_scorer_pydantic_data`, `instructions_judge_pydantic_data`.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:137-170` defines `model_dump` and `_extract_source_code_info`. `/testbed/mlflow/genai/scorers/base.py:170-182` defines `_extract_source_code_info`. `/testbed/tests/genai/scorers/test_scorer.py` tests serialization.
- **Uncertainty:** The `_extract_source_code_info` method references `extract_function_body` from `mlflow.genai.scorers.scorer_utils` which is currently a stub (empty body) in `/testbed/mlflow/genai/scorers/scorer_utils.py` but fully implemented in `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:61-66`.

### R6: Deserialization (model_validate Reconstruction)
- **Type:** Dataflow
- **Statement:** `Scorer.model_validate` must accept a `SerializedScorer` or `dict`, detect the scorer type from the fields present (builtin vs decorator vs instructions_judge), and for decorator scorers: reconstruct the function from source code using `recreate_function`, re-apply `scorer()` decorator, and return a new `Scorer` instance.
- **Task Evidence:** "Provide secure serialization that handles source code extraction and reconstruction." "Support multiple scorer types (builtin, decorator-based, class-based) with consistent interfaces."
- **Acceptance:** `Scorer.model_validate(serialized_dict)` where dict has `call_source`, `call_signature`, `original_func_name` returns a working `Scorer` instance that can be called and produces the same output as the original.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:184-299` defines `model_validate` with dispatch logic. `/testbed/mlflow/genai/scorers/base.py:302-370` defines `_reconstruct_decorator_scorer`. `/testbed/tests/genai/scorers/test_scorer_utils.py` tests `recreate_function` extensively.
- **Uncertainty:** `recreate_function` is currently a stub in `/testbed/mlflow/genai/scorers/scorer_utils.py` (only 66 lines, empty bodies); the full implementation exists in `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:77-146`.

### R7: Secure Deserialization Guard
- **Type:** Failure
- **Statement:** `_reconstruct_decorator_scorer` must raise `MlflowException` when called outside a Databricks runtime environment, because custom scorer deserialization uses `exec()` which poses code execution risk.
- **Task Evidence:** "Secure code execution during scorer deserialization (restricted to controlled environments)." "Custom scorers created with this decorator can be registered for automatic trace evaluation, but registration is only supported in Databricks environments due to security considerations around code execution during deserialization."
- **Acceptance:** Calling `Scorer._reconstruct_decorator_scorer(serialized)` outside Databricks raises `MlflowException` with message containing "Loading custom scorer" and "not supported outside of Databricks runtime environments". When connected to Databricks tracking URI remotely, raises with "via remote access is not supported".
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:302-370` checks `is_in_databricks_runtime()` and `is_databricks_uri()`. `/testbed/tests/genai/scorers/test_scorer.py:349-370` tests both blocking scenarios.
- **Uncertainty:** None.

### R8: Scorer Lifecycle Management (register/start/stop/update)
- **Type:** Behavior
- **Statement:** `Scorer` must support `register`, `start`, `stop`, `update` methods for lifecycle management, with `_check_can_be_registered` enforcing that only builtin and decorator scorers can be registered, and decorator scorers only with Databricks tracking URI. `start` requires `sampling_config` with `sample_rate > 0`. `stop` sets `sample_rate=0`. `update` changes sampling configuration.
- **Task Evidence:** "Enable scorer registration, lifecycle management (start/stop/update), and sampling configuration."
- **Acceptance:** `scorer_instance.register(experiment_id=...)` works. `scorer_instance.start(sampling_config=ScorerSamplingConfig(sample_rate=0.5))` works. `scorer_instance.stop()` returns scorer with `sample_rate=0`. `scorer_instance.update(sampling_config=...)` modifies config.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:527-590` defines `register`. `/testbed/mlflow/genai/scorers/base.py:592-660` defines `start`. `/testbed/mlflow/genai/scorers/base.py:664-735` defines `update`. `/testbed/mlflow/genai/scorers/base.py:737-790` defines `stop`. `/testbed/mlflow/genai/scorers/base.py:806-870` defines `_check_can_be_registered`.
- **Uncertainty:** None.

### R9: AssessmentSourceType Constants
- **Type:** Interface
- **Statement:** `AssessmentSourceType` class must define string constants `SOURCE_TYPE_UNSPECIFIED = "SOURCE_TYPE_UNSPECIFIED"`, `LLM_JUDGE = "LLM_JUDGE"`, `AI_JUDGE = "AI_JUDGE"`, `HUMAN = "HUMAN"`, `CODE = "CODE"`, and a list `_SOURCE_TYPES = [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]` (excluding the deprecated `AI_JUDGE`).
- **Task Evidence:** "Available source types: HUMAN, LLM_JUDGE, CODE, SOURCE_TYPE_UNSPECIFIED." "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE'."
- **Acceptance:** `AssessmentSourceType.HUMAN == "HUMAN"`. `AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"`. `AssessmentSourceType.AI_JUDGE == "AI_JUDGE"`. `"AI_JUDGE" not in AssessmentSourceType._SOURCE_TYPES`. These are accessed as plain string class attributes.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:148-155` defines all constants. `/testbed/libs/skinny/mlflow/entities/assessment_source.py:148-155` same. `/testbed/tests/entities/test_assessment_source.py:15-20` tests constants implicitly.
- **Uncertainty:** The interface description shows attributes with dict-value form (`{'_type': 'literal', '_value': '...'}`) but both the main repo and libs use plain strings; task examples use strings.

### R10: AssessmentSourceType Validation (__init__ and _parse)
- **Type:** Behavior
- **Statement:** `AssessmentSourceType(source_type_str)` must convert input to uppercase, check it (or its AI_JUDGE→LLM_JUDGE replacement) against `_SOURCE_TYPES`, and store the validated value. Invalid types must raise `MlflowException` with error code `INVALID_PARAMETER_VALUE`.
- **Task Evidence:** "Case-insensitive string inputs (converts to uppercase)." "Validation of source type values." "Raises: MlflowException: If the provided source_type is not one of the valid source types."
- **Acceptance:** `AssessmentSourceType("human")._source_type == "HUMAN"`. `AssessmentSourceType("llm_judge")._source_type == "LLM_JUDGE"`. `AssessmentSourceType("ROBOT")` raises `MlflowException` with "Invalid assessment source type" message.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:160-161` defines `__init__`. `/testbed/libs/skinny/mlflow/entities/assessment_source.py:163-180` defines `_parse`. `/testbed/tests/entities/test_assessment_source.py:41-47` tests validation.
- **Uncertainty:** The main `/testbed/mlflow/entities/assessment_source.py` is missing the `__init__`, `__str__`, `_parse`, and `_standardize` methods but they exist in the libs version.

### R11: AI_JUDGE Deprecation Warning
- **Type:** Compatibility
- **Statement:** When `AssessmentSourceType._parse` receives `"AI_JUDGE"` (case-insensitive), it must issue a `FutureWarning` with message "AI_JUDGE is deprecated. Use LLM_JUDGE instead." and transparently convert to `"LLM_JUDGE"`.
- **Task Evidence:** "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE' with a deprecation warning." "Deprecation warnings for legacy values (AI_JUDGE → LLM_JUDGE)."
- **Acceptance:** `with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated"): source = AssessmentSource(source_type="AI_JUDGE", source_id="x")` passes and `source.source_type == "LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:165-170` issues `FutureWarning`. `/testbed/tests/entities/test_assessment_source.py:49-53` tests exact behavior.
- **Uncertainty:** None.

### R12: AssessmentSourceType String Conversion (__str__ and _standardize)
- **Type:** Interface
- **Statement:** `str(AssessmentSourceType(source_type_str))` must return the validated, uppercase string. `AssessmentSourceType._standardize(source_type_str)` is a static method that returns `str(AssessmentSourceType(source_type_str))`.
- **Task Evidence:** "This class provides constants for valid assessment source types and handles validation and standardization of source type values." "_standardize: Standardize and validate an assessment source type string."
- **Acceptance:** `str(AssessmentSourceType("human")) == "HUMAN"`. `AssessmentSourceType._standardize("human") == "HUMAN"`. `AssessmentSourceType._standardize("AI_JUDGE") == "LLM_JUDGE"` (with warning).
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:183-184` defines `__str__`. `/testbed/libs/skinny/mlflow/entities/assessment_source.py:186-187` defines `_standardize`.
- **Uncertainty:** None.

### R13: AssessmentSource Integration
- **Type:** Dataflow
- **Statement:** `AssessmentSource.__post_init__` must call `AssessmentSourceType._standardize(self.source_type)` to validate and normalize the source type string on construction.
- **Task Evidence:** The `AssessmentSource` dataclass docstring states: "source_type: The type of the assessment source. Must be one of the values in the AssessmentSourceType enum."
- **Acceptance:** `AssessmentSource(source_type="human", source_id="x").source_type == "HUMAN"`. `AssessmentSource(source_type="AI_JUDGE", source_id="x").source_type == "LLM_JUDGE"` with warning.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:69-70` defines `__post_init__` calling `AssessmentSourceType._standardize`. `/testbed/tests/entities/test_assessment_source.py:21-30` tests `source_type` property.
- **Uncertainty:** None.

### R14: Scorer Feedback Name Overwrite
- **Type:** Behavior
- **Statement:** When `Scorer.run` receives a `Feedback` result with the default name (`DEFAULT_FEEDBACK_NAME`), it must overwrite the feedback name to the scorer's name for consistency.
- **Task Evidence:** Implicit in the task statement "The metric name will be determined by the scorer function's name." 
- **Acceptance:** `@scorer def my_scorer(outputs): return Feedback(value=42, rationale="r")` → `my_scorer.run(outputs="x").name == "my_scorer"`. But if `Feedback(name="custom", value=42)` is returned, name stays "custom".
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:406-423` overwrites default feedback name. `/testbed/tests/genai/scorers/test_scorer.py` tests this behavior.
- **Uncertainty:** None.

### R15: scorer_utils Stub Completion
- **Type:** Behavior
- **Statement:** The file `/testbed/mlflow/genai/scorers/scorer_utils.py` must contain complete implementations of `FunctionBodyExtractor`, `extract_function_body`, and `recreate_function` matching the implementations in `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py`.
- **Task Evidence:** The `_extract_source_code_info` and `_reconstruct_decorator_scorer` methods in `base.py` depend on `extract_function_body` and `recreate_function` from `scorer_utils`. The task requires "Provide secure serialization that handles source code extraction and reconstruction."
- **Acceptance:** `from mlflow.genai.scorers.scorer_utils import extract_function_body, recreate_function` works. `extract_function_body(lambda x: x+1)` returns `("return x + 1", indent_unit)`. `recreate_function("return x + 1", "(x)", "add")` returns a callable `add` where `add(5) == 6`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:15-146` full implementation. `/testbed/tests/genai/scorers/test_scorer_utils.py` extensive tests.
- **Uncertainty:** None.

### R16: SerializedScorer Validation
- **Type:** Failure
- **Statement:** `SerializedScorer.__post_init__` must validate that exactly one type of scorer fields is present (builtin, decorator, or instructions_judge). Zero types or multiple types must raise `ValueError`.
- **Task Evidence:** The `model_validate` dispatch logic requires unambiguous scorer type identification. The `SerializedScorer` dataclass is the serialization schema.
- **Acceptance:** `SerializedScorer(name="x", call_source="return 1", call_signature="()", original_func_name="f")` succeeds. `SerializedScorer(name="x", call_source="return 1", call_signature="()", original_func_name="f", builtin_scorer_class="Foo")` raises `ValueError`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:88-108` defines `__post_init__` validation. The main `/testbed/mlflow/genai/scorers/base.py` is missing this method.
- **Uncertainty:** None.

## L2. Functional Design Graph

### N1: scorer (PublicEntry)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:847` function definition. Imported at `/testbed/mlflow/genai/scorers/__init__.py:4` via `from mlflow.genai.scorers.base import Scorer, ScorerSamplingConfig` (note: `scorer` is listed in `__all__` but not explicitly imported from base in the main `__init__.py`).

### N2: CustomScorer (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1031` inner class within `scorer()`.

### N3: Scorer (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:107-870` Pydantic BaseModel.

### N4: Scorer.run (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:372-425`.

### N5: Scorer.model_dump (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:137-170`.

### N6: Scorer.model_validate (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:184-299`.

### N7: Scorer._reconstruct_decorator_scorer (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:302-370`.

### N8: Scorer._extract_source_code_info (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:172-182` (body empty in main, full in libs).

### N9: extract_function_body (Function)
- **Kind:** Function
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:61-66`. Stub in `/testbed/mlflow/genai/scorers/scorer_utils.py`.

### N10: recreate_function (Function)
- **Kind:** Function
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:77-146`. Stub in `/testbed/mlflow/genai/scorers/scorer_utils.py`.

### N11: FunctionBodyExtractor (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:16-55`.

### N12: SerializedScorer (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:62-86`.

### N13: ScorerSamplingConfig (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:50-54`.

### N14: Scorer.register (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:527-590`.

### N15: Scorer.start (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:592-660`.

### N16: Scorer.update (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:664-735`.

### N17: Scorer.stop (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:737-790`.

### N18: Scorer._check_can_be_registered (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:806-870`.

### N19: AssessmentSourceType (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:108-194`. Methods `__init__`, `__str__`, `_parse`, `_standardize` only present in `/testbed/libs/skinny/mlflow/entities/assessment_source.py:160-187`.

### N20: AssessmentSource (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:11-103`.

### N21: AssessmentSource.__post_init__ (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:69-70`.

### N22: Feedback (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py` (Feedback class).

### N23: MlflowException (Error)
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/exceptions.py`.

### E1: scorer → CustomScorer
- **Kind:** CONTROL
- **Condition:** `func is None` → return `functools.partial`; `func is not None` → instantiate `CustomScorer`
- **Transfer:** Decorated function `func` → stored as `_original_func` on `CustomScorer` instance.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:994-1031`.
- **Obligations:** R1, R2

### E2: CustomScorer.__call__ → original function
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `*args, **kwargs` → forwarded to `func(*args, **kwargs)`
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1008-1009`.
- **Obligations:** R2

### E3: Scorer.run → CustomScorer.__call__
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Filters `inputs`, `outputs`, `expectations`, `trace` kwargs by inspecting `self.__call__` signature, then calls `self(**filtered)`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:372-425`.
- **Obligations:** R3, R4, R14

### E4: Scorer.run → return type validation
- **Kind:** CONTROL
- **Condition:** Return value type not in `(int, float, bool, str, Assessment, Feedback, list)` → raise `MlflowException`
- **Transfer:** Exception raised with formatted message including type name.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:393-403`.
- **Obligations:** R4

### E5: Scorer.model_dump → _extract_source_code_info
- **Kind:** CALL
- **Condition:** `self._original_func` is present (decorator scorer)
- **Transfer:** `_original_func` → `extract_function_body` → `SerializedScorer` dataclass → `asdict` → cached dict.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:137-170`.
- **Obligations:** R5, R15

### E6: _extract_source_code_info → extract_function_body
- **Kind:** CALL
- **Condition:** Always for decorator scorers
- **Transfer:** `self._original_func` passed to `extract_function_body`; returns `(call_body, indent_unit)` tuple.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:172-182`.
- **Obligations:** R5, R15

### E7: Scorer.model_validate → _reconstruct_decorator_scorer
- **Kind:** CALL
- **Condition:** `serialized.call_source and serialized.call_signature and serialized.original_func_name` are all non-None
- **Transfer:** `SerializedScorer` → `recreate_function` → `scorer()` → new `Scorer` instance.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:184-299`.
- **Obligations:** R6, R7

### E8: _reconstruct_decorator_scorer → security guard
- **Kind:** CONTROL
- **Condition:** `not is_in_databricks_runtime()` → raise `MlflowException`
- **Transfer:** Exception raised with "Loading custom scorer ... not supported outside of Databricks runtime environments".
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:302-370`.
- **Obligations:** R7

### E9: _reconstruct_decorator_scorer → recreate_function
- **Kind:** CALL
- **Condition:** `is_in_databricks_runtime()` is True
- **Transfer:** `serialized.call_source`, `serialized.call_signature`, `serialized.original_func_name` → `recreate_function` → recreated callable.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:302-370`.
- **Obligations:** R6, R15

### E10: _reconstruct_decorator_scorer → scorer()
- **Kind:** CALL
- **Condition:** `recreate_function` succeeds
- **Transfer:** Recreated function + serialized `name`, `description`, `aggregations` → `scorer(recreated_func, name=..., description=..., aggregations=...)` → new `Scorer`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:362-369`.
- **Obligations:** R1, R6

### E11: Scorer.register → _check_can_be_registered
- **Kind:** CALL
- **Condition:** Always before registration
- **Transfer:** Checks `self.kind` is in `_ALLOWED_SCORERS_FOR_REGISTRATION` and decorator scorers only with Databricks URI.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:527-590`.
- **Obligations:** R8

### E12: Scorer.start → DatabricksStore.update_registered_scorer
- **Kind:** CALL
- **Condition:** `is_databricks_uri(get_tracking_uri())` is True
- **Transfer:** `sampling_config.sample_rate`, `sampling_config.filter_string` → server update.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:592-660`.
- **Obligations:** R8

### E13: Scorer.stop → Scorer.update
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `sampling_config=ScorerSamplingConfig(sample_rate=0.0)` → `self.update(...)`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:737-790`.
- **Obligations:** R8

### E14: AssessmentSource.__post_init__ → AssessmentSourceType._standardize
- **Kind:** CALL
- **Condition:** Always on dataclass initialization
- **Transfer:** `self.source_type` string → `AssessmentSourceType._standardize(...)` → validated uppercase string assigned back.
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:69-70`.
- **Obligations:** R13

### E15: AssessmentSourceType._standardize → AssessmentSourceType constructor
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Creates temporary `AssessmentSourceType(source_type)` then calls `str()` on it.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:186-187`.
- **Obligations:** R12

### E16: AssessmentSourceType.__init__ → AssessmentSourceType._parse
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Input string → `_parse` → validated uppercase string stored as `self._source_type`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:160-161`.
- **Obligations:** R10, R11

### E17: AssessmentSourceType._parse → FutureWarning branch
- **Kind:** CONTROL
- **Condition:** `source_type == "AI_JUDGE"` after uppercasing
- **Transfer:** Issue `FutureWarning`, convert to `"LLM_JUDGE"`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:165-170`.
- **Obligations:** R11

### E18: AssessmentSourceType._parse → MlflowException branch
- **Kind:** CONTROL
- **Condition:** `source_type not in _SOURCE_TYPES`
- **Transfer:** `MlflowException` with message "Invalid assessment source type: {source_type}. Valid source types: {_SOURCE_TYPES}".
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:172-177`.
- **Obligations:** R10

### E19: recreate_function → exec
- **Kind:** CALL
- **Condition:** Always (the core mechanism)
- **Transfer:** Built function definition string executed with `import_namespace` containing MLflow imports; result captured in `local_namespace`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:142-143`.
- **Obligations:** R15

## L3. Verifiable Contracts

### C1: scorer decorator returns CustomScorer
- **Type:** Interface
- **Subject:** `scorer(func)` return value
- **Relation:** TYPE_IS
- **Expected:** Instance of `Scorer` (specifically `CustomScorer` subclass), with `kind == ScorerKind.DECORATOR`
- **Evidence:** Task docstring shows `@scorer` returns scorer instances. `/testbed/tests/genai/scorers/test_scorer.py:72-73` tests `scorer(always_yes)`.
- **Observe:** RETURN_VALUE
- **Target:** `from mlflow.genai.scorers.base import scorer; result = scorer(lambda outputs: outputs != ""); isinstance(result, Scorer)`
- **Obligations:** R1, R2
- **Graph:** N1, N2, E1

### C2: scorer parameterized usage returns partial
- **Type:** Interface
- **Subject:** `scorer(name="x", description="d")` return value
- **Relation:** TYPE_IS
- **Expected:** `functools.partial` object that when called with a function returns a `Scorer` instance
- **Evidence:** Task docstring: "name: The name of the scorer. If not provided, uses the function's name." Implies `@scorer(name="custom")` usage.
- **Observe:** RETURN_VALUE
- **Target:** `result = scorer(name="my_name"); callable(result); scorer_instance = result(lambda outputs: True); scorer_instance.name == "my_name"`
- **Obligations:** R1
- **Graph:** N1, E1

### C3: Scorer.run parameter filtering
- **Type:** Behavior
- **Subject:** `Scorer.run` parameter dispatch
- **Relation:** PRESERVE
- **Expected:** Only parameters present in the underlying `__call__` signature are forwarded; extra parameters are silently dropped.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:386-389` filters by `inspect.signature(self.__call__)`. Task docstring: "take in a **subset** of the following parameters."
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** `@scorer def f(outputs): return outputs` → `f.run(inputs="i", outputs="o", expectations={}, trace=None)` calls underlying function with only `outputs="o"`.
- **Obligations:** R3
- **Graph:** N4, E3

### C4: Scorer.run validates return types
- **Type:** Failure
- **Subject:** Invalid return type from scorer function
- **Relation:** RAISES
- **Expected:** `MlflowException` with message matching "must return one of int, float, bool, str, Feedback, or list[Feedback]"
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:393-403`. Task docstring: "Raises: MlflowException: If the scorer function returns an unsupported type."
- **Observe:** EXCEPTION
- **Target:** `@scorer def bad(outputs): return {"key": "value"}` → `bad.run(outputs="x")` raises `MlflowException`.
- **Obligations:** R4
- **Graph:** N4, E4, N23

### C5: Scorer.run overwrites default feedback name
- **Type:** Behavior
- **Subject:** `Feedback` with `name == DEFAULT_FEEDBACK_NAME` returned from scorer
- **Relation:** EQ
- **Expected:** Returned feedback's `.name` equals the scorer's `.name`
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:406-423`. `/testbed/tests/genai/scorers/test_scorer.py` test "test_custom_scorer_overwrites_default_feedback_name".
- **Observe:** RETURN_VALUE
- **Target:** `@scorer def my_scorer(outputs): return Feedback(value=42)` → `my_scorer.run(outputs="x").name == "my_scorer"`
- **Obligations:** R14
- **Graph:** N4, E3, N22

### C6: model_dump produces valid SerializedScorer dict
- **Type:** Dataflow
- **Subject:** `scorer_instance.model_dump()` output
- **Relation:** CONTAINS
- **Expected:** Dict contains keys `name`, `call_source`, `call_signature`, `original_func_name`, `mlflow_version`, `serialization_version`, `aggregations`, `description` with non-None values for decorator-specific fields.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:137-170`. Task requirement: "Provide secure serialization that handles source code extraction."
- **Observe:** RETURN_VALUE
- **Target:** `d = scorer(lambda outputs: len(outputs) > 0).model_dump(); assert d["call_source"] is not None; assert d["call_signature"] is not None`
- **Obligations:** R5
- **Graph:** N5, E5, E6, N12

### C7: model_validate reconstructs decorator scorer
- **Type:** Dataflow
- **Subject:** `Scorer.model_validate(serialized_dict)` for decorator scorer
- **Relation:** PRESERVE
- **Expected:** Returns a `Scorer` instance that when called with same inputs produces the same output as the original.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:184-299`. Task requirement: "Support multiple scorer types (builtin, decorator-based, class-based) with consistent interfaces."
- **Observe:** RETURN_VALUE
- **Target:** `reconstructed = Scorer.model_validate(original.model_dump()); reconstructed.run(outputs="hello") == original.run(outputs="hello")`
- **Obligations:** R6
- **Graph:** N6, E7, E9, E10

### C8: model_validate raises for unknown scorer format
- **Type:** Failure
- **Subject:** `Scorer.model_validate` with dict lacking all scorer type fields
- **Relation:** RAISES
- **Expected:** `MlflowException` with message "Failed to load scorer" and "unknown format"
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:285-299`.
- **Observe:** EXCEPTION
- **Target:** `Scorer.model_validate({"name": "test"})` raises `MlflowException`.
- **Obligations:** R6
- **Graph:** N6, N23

### C9: Security guard blocks deserialization outside Databricks
- **Type:** Failure
- **Subject:** `_reconstruct_decorator_scorer` called outside Databricks runtime
- **Relation:** RAISES
- **Expected:** `MlflowException` with message "Loading custom scorer ... not supported outside of Databricks runtime environments"
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:302-370`. `/testbed/tests/genai/scorers/test_scorer.py:349-360`.
- **Observe:** EXCEPTION
- **Target:** `Scorer._reconstruct_decorator_scorer(SerializedScorer(name="x", call_source="return True", call_signature="()", original_func_name="f"))` raises `MlflowException`.
- **Obligations:** R7
- **Graph:** N7, E8, N23

### C10: Security guard blocks remote Databricks access
- **Type:** Failure
- **Subject:** `_reconstruct_decorator_scorer` with Databricks URI but not in Databricks runtime
- **Relation:** RAISES
- **Expected:** `MlflowException` with message "via remote access is not supported"
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:317-330`. `/testbed/tests/genai/scorers/test_scorer.py:362-377`.
- **Observe:** EXCEPTION
- **Target:** With `is_in_databricks_runtime=False` and `is_databricks_uri=True`, `_reconstruct_decorator_scorer` raises with "via remote access is not supported".
- **Obligations:** R7
- **Graph:** N7, E8, N23

### C11: AssessmentSourceType validates valid types
- **Type:** Behavior
- **Subject:** `AssessmentSourceType("HUMAN")` and `AssessmentSourceType("llm_judge")`
- **Relation:** EQ
- **Expected:** `_source_type` equals `"HUMAN"` and `"LLM_JUDGE"` respectively; `str()` returns same.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:160-184`. `/testbed/tests/entities/test_assessment_source.py:21-40`.
- **Observe:** RETURN_VALUE
- **Target:** `str(AssessmentSourceType("human")) == "HUMAN"`; `str(AssessmentSourceType("LLM_JUDGE")) == "LLM_JUDGE"`
- **Obligations:** R10, R12
- **Graph:** N19, E16, E15

### C12: AssessmentSourceType raises for invalid type
- **Type:** Failure
- **Subject:** `AssessmentSourceType("ROBOT")`
- **Relation:** RAISES
- **Expected:** `MlflowException` with message matching "Invalid assessment source type: ROBOT" and listing valid types.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:172-177`. `/testbed/tests/entities/test_assessment_source.py:48-49`.
- **Observe:** EXCEPTION
- **Target:** `AssessmentSourceType("ROBOT")` raises `MlflowException`.
- **Obligations:** R10
- **Graph:** N19, E18, N23

### C13: AssessmentSourceType issues deprecation warning for AI_JUDGE
- **Type:** SideEffect
- **Subject:** `AssessmentSourceType("AI_JUDGE")` or `AssessmentSource(source_type="AI_JUDGE", ...)`
- **Relation:** EQ
- **Expected:** Issues `FutureWarning` with "AI_JUDGE is deprecated. Use LLM_JUDGE instead." Result has `source_type == "LLM_JUDGE"`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:165-170`. `/testbed/tests/entities/test_assessment_source.py:49-53`.
- **Observe:** SIDE_EFFECT (warnings.warn)
- **Target:** `with pytest.warns(FutureWarning): AssessmentSource(source_type="AI_JUDGE", source_id="x")`
- **Obligations:** R11
- **Graph:** N19, E17, N20, N21

### C14: AssessmentSource standardizes on construction
- **Type:** Dataflow
- **Subject:** `AssessmentSource(source_type="human", source_id="x")`
- **Relation:** EQ
- **Expected:** `source.source_type == "HUMAN"` (uppercased and validated)
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:69-70`. `/testbed/tests/entities/test_assessment_source.py:21-25`.
- **Observe:** FIELD_READ
- **Target:** `AssessmentSource(source_type="human", source_id="x").source_type == "HUMAN"`
- **Obligations:** R13
- **Graph:** N20, N21, E14

### C15: AssessmentSourceType constants are strings
- **Type:** Interface
- **Subject:** `AssessmentSourceType.HUMAN`, `AssessmentSourceType.LLM_JUDGE`, `AssessmentSourceType.CODE`, `AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED`
- **Relation:** TYPE_IS
- **Expected:** Each is a `str` equal to its name.
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:148-155`. `/testbed/tests/entities/test_assessment_source.py:15-20`.
- **Observe:** IMPORT_BOUNDARY
- **Target:** `from mlflow.entities.assessment_source import AssessmentSourceType; AssessmentSourceType.HUMAN == "HUMAN"`
- **Obligations:** R9
- **Graph:** N19

### C16: extract_function_body extracts body without signature/docstring
- **Type:** Behavior
- **Subject:** `extract_function_body(func)` where `func` is `def add(x, y): """Doc.""" return x + y`
- **Relation:** EQ
- **Expected:** Returns `("return x + y", indent_unit)` tuple with indent_unit integer.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:61-72`. `/testbed/tests/genai/scorers/test_scorer_utils.py` tests.
- **Observe:** RETURN_VALUE
- **Target:** `from mlflow.genai.scorers.scorer_utils import extract_function_body; body, indent = extract_function_body(some_func)`
- **Obligations:** R15
- **Graph:** N9, N11

### C17: recreate_function builds callable from source
- **Type:** Behavior
- **Subject:** `recreate_function("return x + y", "(x, y)", "add")`
- **Relation:** EQ
- **Expected:** Returns callable `add` where `add(3, 4) == 7`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:77-146`. `/testbed/tests/genai/scorers/test_scorer_utils.py:15-27`.
- **Observe:** RETURN_VALUE
- **Target:** `from mlflow.genai.scorers.scorer_utils import recreate_function; f = recreate_function("return x + 1", "(x)", "inc"); f(5) == 6`
- **Obligations:** R15
- **Graph:** N10, E19

### C18: SerializedScorer validates single scorer type
- **Type:** Failure
- **Subject:** `SerializedScorer(name="x", call_source="s", call_signature="()", original_func_name="f", builtin_scorer_class="Foo")`
- **Relation:** RAISES
- **Expected:** `ValueError` with "cannot have multiple types of scorer fields"
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:88-108`.
- **Observe:** EXCEPTION
- **Target:** `SerializedScorer(name="x", call_source="return 1", call_signature="()", original_func_name="f", builtin_scorer_class="Foo")` raises `ValueError`.
- **Obligations:** R16
- **Graph:** N12

### C19: Scorer.register blocks decorator scorers outside Databricks
- **Type:** Failure
- **Subject:** `scorer_instance.register()` for decorator scorer with non-Databricks URI
- **Relation:** RAISES
- **Expected:** `MlflowException` with "Custom scorer registration ... not supported outside of Databricks tracking"
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:806-841`. `/testbed/tests/genai/scorers/test_scorer.py:339-347`.
- **Observe:** EXCEPTION
- **Target:** `@scorer def f(outputs): return True` → `f.register(experiment_id="123")` raises `MlflowException` outside Databricks.
- **Obligations:** R8
- **Graph:** N14, E11, N18, N23

### C20: scorer is importable from package
- **Type:** Interface
- **Subject:** `from mlflow.genai.scorers import scorer`
- **Relation:** TYPE_IS
- **Expected:** `scorer` is a callable (the decorator function)
- **Evidence:** `/testbed/mlflow/genai/scorers/__init__.py` lists `"scorer"` in `__all__`. `/testbed/tests/genai/scorers/test_scorer.py:14` imports via `from mlflow.genai import Scorer, scorer`.
- **Observe:** IMPORT_BOUNDARY
- **Target:** `from mlflow.genai.scorers import scorer; callable(scorer)` is True.
- **Obligations:** R1
- **Graph:** N1
- **Uncertainty:** The `__init__.py` currently imports `Scorer` and `ScorerSamplingConfig` from base but does not import `scorer`. The `scorer` function and the import line need to be added.


### E20: AssessmentSourceType class attributes → consumers
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** String constants `SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `HUMAN`, `CODE` accessible as class attributes. List `_SOURCE_TYPES = [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]` used by `_parse` for validation.
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:148-155`. Used by `_parse` at `/testbed/libs/skinny/mlflow/entities/assessment_source.py:172`.
- **Obligations:** R9

### E21: SerializedScorer.__post_init__ validation
- **Kind:** CONTROL
- **Condition:** On `SerializedScorer` dataclass instantiation → counts present field groups → raises `ValueError` if count != 1
- **Transfer:** Validates that exactly one of `(builtin_scorer_class is not None)`, `(call_source is not None)`, `(instructions_judge_pydantic_data is not None)` is true.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:88-108`.
- **Obligations:** R16

### C21: SerializedScorer rejects zero scorer types
- **Type:** Failure
- **Subject:** `SerializedScorer(name="x")` with no scorer-type fields
- **Relation:** RAISES
- **Expected:** `ValueError` with "must have either builtin scorer fields ... decorator scorer fields ... or instructions judge fields"
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:94-99`.
- **Observe:** EXCEPTION
- **Target:** `SerializedScorer(name="test")` raises `ValueError`.
- **Obligations:** R16
- **Graph:** N12, E21

### C22: FunctionBodyExtractor skips docstring
- **Type:** Behavior
- **Subject:** `FunctionBodyExtractor.extract_body` for function with docstring
- **Relation:** EQ
- **Expected:** Body extraction skips the first statement if it is a string constant (docstring). Returns only the executable body lines.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:32-38`.
- **Observe:** RETURN_VALUE
- **Target:** `extract_function_body` on `def f(): """doc.""" return 1` returns `("return 1", indent)` without the docstring.
- **Obligations:** R15
- **Graph:** N11, N9
