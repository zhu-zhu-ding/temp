"""
Behavior spec for the MLflow GenAI scorer subsystem.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries, and
compatibility contracts. Each check exercises a public-entry-to-observer
path and asserts the expected outcome.

Contracts covered: C1, C2, C3, C7, C8, C9, C10, C11, C12, C17, C19, C20,
                    C21, C23, C24, C29
"""

import logging
import sys
from io import StringIO

import pandas as pd
import pytest

from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import Scorer, scorer
from mlflow.genai.scorers.base import ScorerKind as _ScorerKind


# ── helpers ──────────────────────────────────────────────────────────────────

def _fail(reason: str):
    print(f"FAIL: {reason}", file=sys.stderr)
    sys.exit(1)


def _capture_logs(logger_name: str, level: int = logging.INFO):
    """Context manager that captures log output from a named logger."""
    logger = logging.getLogger(logger_name)
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(level)
    old_level = logger.level
    logger.setLevel(level)
    logger.addHandler(handler)
    try:
        yield stream
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)


# ── C1: scorer returns CustomScorer instance (Behavior path) ────────────────
# Contracts: C1

def check_c1_scorer_returns_customscorer():
    """scorer(func) must return a Scorer with kind == ScorerKind.DECORATOR."""
    def f(inputs, outputs):
        return True

    obj = scorer(f)
    if not isinstance(obj, Scorer):
        _fail("scorer(func) did not return a Scorer instance")
    if obj.kind != _ScorerKind.DECORATOR:
        _fail(f"kind is {obj.kind}, expected DECORATOR")
    print("PASS: C1 - scorer returns Scorer with kind=DECORATOR")


# ── C2: scorer(func=None) returns functools.partial (Behavior path) ─────────
# Contracts: C2

def check_c2_scorer_partial_works_as_decorator():
    """scorer(name='x') returns partial that can decorate a function."""
    def f(inputs):
        return "ok"

    decorated = scorer(name="custom_name")(f)
    if not isinstance(decorated, Scorer):
        _fail("Parameterized scorer did not produce a Scorer")
    if decorated.name != "custom_name":
        _fail(f"Name is {decorated.name!r}, expected 'custom_name'")
    print("PASS: C2 - scorer(func=None) partial works as decorator")


# ── C3: CustomScorer delegates to original function ─────────────────────────
# Contracts: C3

def check_c3_customscorer_delegates_call():
    """Calling a scorer instance invokes the original function."""
    def add_one(x):
        return x + 1

    instance = scorer(add_one)
    result = instance(x=1)
    if result != 2:
        _fail(f"Delegation failed: expected 2, got {result!r}")
    print("PASS: C3 - CustomScorer delegates to original function")


# ── C7: validate_scorers rejects non-list input ─────────────────────────────
# Contracts: C7

def check_c7_validate_scorers_rejects_non_list():
    """validate_scorers('not_a_list') raises MlflowException."""
    from mlflow.genai.scorers.validation import validate_scorers

    with pytest.raises(MlflowException, match="must be a list"):
        validate_scorers("not_a_list")
    print("PASS: C7 - validate_scorers rejects non-list input")


# ── C8: validate_scorers returns empty list ─────────────────────────────────
# Contracts: C8

def check_c8_validate_scorers_empty_list():
    """validate_scorers([]) returns []."""
    from mlflow.genai.scorers.validation import validate_scorers

    result = validate_scorers([])
    if result != []:
        _fail(f"Expected [], got {result!r}")
    print("PASS: C8 - validate_scorers returns empty list")


# ── C9: validate_scorers passthrough (behavior) ─────────────────────────────
# Contracts: C9

def check_c9_validate_scorers_passthrough_identity():
    """validate_scorers preserves Scorer instances."""
    from mlflow.genai.scorers.validation import validate_scorers

    s = Scorer(name="x")
    result = validate_scorers([s])
    if result[0] is not s:
        _fail("validate_scorers did not return the same instance")
    print("PASS: C9 - validate_scorers preserves Scorer identity")


# ── C10: validate_scorers rejects non-Scorer item ───────────────────────────
# Contracts: C10

def check_c10_validate_scorers_rejects_invalid_item():
    """validate_scorers([42]) raises MlflowException."""
    from mlflow.genai.scorers.validation import validate_scorers

    with pytest.raises(MlflowException, match="invalid item"):
        validate_scorers([42])
    print("PASS: C10 - validate_scorers rejects non-Scorer item")


# ── C11: validate_scorers hints for class-instead-of-instance ───────────────
# Contracts: C11

def check_c11_validate_scorers_hints_class_not_instance():
    """validate_scorers([BuiltInScorer_subclass]) hints about instance."""
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    with pytest.raises(MlflowException, match="class instead of an instance"):
        validate_scorers([Correctness])
    print("PASS: C11 - validate_scorers hints for class-instead-of-instance")


# ── C12: validate_scorers hints for nested get_all_scorers ──────────────────
# Contracts: C12

def check_c12_validate_scorers_hints_nested_get_all():
    """validate_scorers([get_all_scorers()]) hints about direct usage."""
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import get_all_scorers

    with pytest.raises(MlflowException, match="scorers=get_all_scorers()"):
        validate_scorers([get_all_scorers()])
    print("PASS: C12 - validate_scorers hints for nested get_all_scorers")


# ── C17: valid_data_for_builtin_scorers raises on non-dict expectations ────
# Contracts: C17

def check_c17_valid_data_raises_non_dict_expectations():
    """Non-dict value in expectations column raises MlflowException."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    df = pd.DataFrame({
        "inputs": ["test"],
        "outputs": ["test"],
        "expectations": ["not_a_dict"],  # string, not a dict
    })
    with pytest.raises(MlflowException, match="must be a dictionary"):
        valid_data_for_builtin_scorers(df, [])
    print("PASS: C17 - valid_data raises on non-dict expectations")


# ── C19: valid_data_for_builtin_scorers logs missing columns ───────────────
# Contracts: C19

def check_c19_valid_data_logs_missing_columns():
    """Missing columns produce INFO log; no exception raised."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    with _capture_logs("mlflow.genai.scorers.validation", logging.INFO) as stream:
        df = pd.DataFrame({"inputs": ["test"]})  # missing 'outputs'
        # Should not raise
        valid_data_for_builtin_scorers(df, [Correctness()])

    log_text = stream.getvalue()
    if "missing following columns" not in log_text:
        _fail(f"Expected 'missing following columns' in log, got: {log_text}")
    print("PASS: C19 - valid_data logs missing columns without raising")


# ── C20: valid_data_for_builtin_scorers calls validate_columns ─────────────
# Contracts: C20

def check_c20_valid_data_calls_validate_columns():
    """Each builtin scorer's validate_columns is invoked with a set."""
    from unittest.mock import MagicMock

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    mock_scorer = MagicMock()
    mock_scorer.name = "mock_scorer"
    mock_scorer.validate_columns = MagicMock()

    df = pd.DataFrame({"inputs": ["test"], "outputs": ["test"]})
    valid_data_for_builtin_scorers(df, [mock_scorer])

    mock_scorer.validate_columns.assert_called_once()
    call_arg = mock_scorer.validate_columns.call_args[0][0]
    if not isinstance(call_arg, set):
        _fail(f"validate_columns did not receive a set, got {type(call_arg)}")
    if "inputs" not in call_arg:
        _fail(f"validate_columns set missing 'inputs': {call_arg}")
    print("PASS: C20 - valid_data calls validate_columns on each scorer")


# ── C21: get_all_scorers returns 6 scorers on OSS ──────────────────────────
# Contracts: C21

def check_c21_get_all_scorers_oss_count():
    """On non-Databricks URI, get_all_scorers() returns 6 scorers."""
    import mlflow
    from mlflow.genai.scorers.builtin_scorers import get_all_scorers

    # Ensure we are on an OSS URI
    mlflow.set_tracking_uri("file:///tmp/mlflow_test")
    scorers = get_all_scorers()
    if len(scorers) != 6:
        _fail(f"Expected 6 scorers on OSS, got {len(scorers)}")
    print("PASS: C21 - get_all_scorers returns 6 scorers on OSS")


# ── C23: get_all_scorers includes Safety on Databricks URI ─────────────────
# Contracts: C23

def check_c23_get_all_scorers_includes_safety_on_dbx():
    """On Databricks URI, get_all_scorers() includes Safety."""
    import mlflow
    from mlflow.genai.scorers.builtin_scorers import Safety, get_all_scorers

    mlflow.set_tracking_uri("databricks")
    scorers = get_all_scorers()
    if not any(isinstance(s, Safety) for s in scorers):
        _fail("Safety scorer missing on Databricks URI")
    print("PASS: C23 - get_all_scorers includes Safety on Databricks URI")


# ── C24: get_all_scorers excludes Safety on OSS URI ────────────────────────
# Contracts: C24

def check_c24_get_all_scorers_excludes_safety_on_oss():
    """On OSS URI, get_all_scorers() excludes Safety and RetrievalRelevance."""
    import mlflow
    from mlflow.genai.scorers.builtin_scorers import (
        RetrievalRelevance,
        Safety,
        get_all_scorers,
    )

    mlflow.set_tracking_uri("file:///tmp/mlflow_test")
    scorers = get_all_scorers()
    if len(scorers) != 6:
        _fail(f"Expected 6 scorers on OSS, got {len(scorers)}")
    if any(isinstance(s, Safety) for s in scorers):
        _fail("Safety scorer present on OSS URI")
    if any(isinstance(s, RetrievalRelevance) for s in scorers):
        _fail("RetrievalRelevance scorer present on OSS URI")
    print("PASS: C24 - get_all_scorers excludes Safety on OSS URI")


# ── C29: validate_scorers logs warning for legacy metrics ──────────────────
# Contracts: C29

def check_c29_validate_scorers_warns_legacy_metrics():
    """When databricks.agents is installed, legacy Metric triggers warning."""
    import importlib

    from mlflow.genai.scorers.validation import IS_DBX_AGENTS_INSTALLED, validate_scorers

    if not IS_DBX_AGENTS_INSTALLED:
        # In OSS, legacy metrics are treated as invalid items (C10),
        # which is the correct fallback behavior per R7.
        # Verify that validate_scorers still functions correctly.
        with pytest.raises(MlflowException, match="invalid item"):
            validate_scorers([42])
        print("PASS: C29 - legacy metrics raise in OSS (databricks.agents not installed)")
        return

    # If databricks.agents IS installed, test the deprecation warning path.
    with _capture_logs("mlflow.genai.scorers.validation", logging.WARNING) as stream:
        try:
            from databricks.rag_eval.evaluation.metrics import Metric

            m = Metric(name="legacy_metric")
            result = validate_scorers([m])
            log_text = stream.getvalue()
            if "legacy metrics" not in log_text and "deprecated" not in log_text.lower():
                _fail("Warning about legacy metrics not logged")
        except MlflowException:
            # If the Metric passes through but still triggers the warning
            # path, it's fine
            pass
    print("PASS: C29 - validate_scorers logs warning for legacy metrics")


# ── runner ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    check_c1_scorer_returns_customscorer()
    check_c2_scorer_partial_works_as_decorator()
    check_c3_customscorer_delegates_call()
    check_c7_validate_scorers_rejects_non_list()
    check_c8_validate_scorers_empty_list()
    check_c9_validate_scorers_passthrough_identity()
    check_c10_validate_scorers_rejects_invalid_item()
    check_c11_validate_scorers_hints_class_not_instance()
    check_c12_validate_scorers_hints_nested_get_all()
    check_c17_valid_data_raises_non_dict_expectations()
    check_c19_valid_data_logs_missing_columns()
    check_c20_valid_data_calls_validate_columns()
    check_c21_get_all_scorers_oss_count()
    check_c23_get_all_scorers_includes_safety_on_dbx()
    check_c24_get_all_scorers_excludes_safety_on_oss()
    check_c29_validate_scorers_warns_legacy_metrics()
    print("behavior_spec: all checks passed")
