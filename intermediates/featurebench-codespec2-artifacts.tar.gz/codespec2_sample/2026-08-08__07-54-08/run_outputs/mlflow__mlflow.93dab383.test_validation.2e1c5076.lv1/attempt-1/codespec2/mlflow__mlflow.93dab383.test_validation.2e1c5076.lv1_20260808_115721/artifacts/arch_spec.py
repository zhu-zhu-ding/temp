"""
Architecture spec for the MLflow GenAI scorer subsystem.

Covers public interface connectivity and L2 CALL/CONTROL paths plus L3
Interface/Dataflow contracts. Each check traces a path from a public entry
point through call/control edges to a verifiable observer.

Contracts covered: C1, C2, C4, C5, C6, C9, C13, C14, C15, C16, C18,
                    C22, C25, C26, C27, C28
"""

import functools
import inspect
import sys

import pandas as pd

from mlflow.genai.scorers.base import Scorer, scorer
from mlflow.genai.scorers.base import ScorerKind as _ScorerKind


# ── helpers ──────────────────────────────────────────────────────────────────

def _passthrough_fn(*args, **kwargs):
    return True


def _fail(reason: str):
    print(f"FAIL: {reason}", file=sys.stderr)
    sys.exit(1)


# ── C1: scorer returns CustomScorer instance ────────────────────────────────
# Contracts: C1

def check_c1_scorer_returns_customscorer():
    """scorer(func) must return a Scorer instance (CustomScorer subclass)."""
    obj = scorer(_passthrough_fn)
    if not isinstance(obj, Scorer):
        _fail("scorer(func) did not return a Scorer instance")
    # The IR says kind must be ScorerKind.DECORATOR
    if getattr(obj, "kind", None) != _ScorerKind.DECORATOR:
        _fail("scorer(func).kind is not ScorerKind.DECORATOR")
    print("PASS: C1 - scorer returns CustomScorer (Scorer instance, kind=DECORATOR)")


# ── C2: scorer(func=None) returns functools.partial ─────────────────────────
# Contracts: C2

def check_c2_scorer_param_no_func_returns_partial():
    """scorer(name='test') must return a functools.partial."""
    obj = scorer(name="my_scorer")
    if not isinstance(obj, functools.partial):
        _fail(f"scorer(name='my_scorer') returned {type(obj)}, expected functools.partial")
    # The partial should be bound to scorer
    if obj.func is not scorer:
        _fail("functools.partial is not bound to scorer")
    print("PASS: C2 - scorer(func=None) returns functools.partial")


# ── C4: CustomScorer.__call__ signature includes self ───────────────────────
# Contracts: C4

def check_c4_customscorer_call_signature_has_self():
    """inspect.signature(scorer(fn).__call__) must start with 'self'."""
    def my_fn(inputs, outputs):
        return True

    instance = scorer(my_fn)
    sig = inspect.signature(instance.__call__)
    param_names = list(sig.parameters.keys())
    if param_names[0] != "self":
        _fail(f"First parameter is {param_names[0]!r}, expected 'self'")
    # Remaining params should be the original function's params
    assert "inputs" in param_names, f"inputs not in signature: {param_names}"
    assert "outputs" in param_names, f"outputs not in signature: {param_names}"
    print("PASS: C4 - CustomScorer.__call__ signature starts with self")


# ── C5: scorer name defaults to function name ───────────────────────────────
# Contracts: C5

def check_c5_scorer_name_defaults_to_func_name():
    """scorer(fn).name == fn.__name__ when no explicit name given."""
    def my_evaluator(inputs):
        return 1.0

    instance = scorer(my_evaluator)
    if instance.name != "my_evaluator":
        _fail(f"Expected name 'my_evaluator', got {instance.name!r}")
    print("PASS: C5 - scorer name defaults to function name")


# ── C6: scorer explicit name overrides function name ────────────────────────
# Contracts: C6

def check_c6_scorer_explicit_name_overrides():
    """scorer(name='override')(fn).name == 'override'."""
    def some_fn(inputs):
        return 1.0

    instance = scorer(name="override")(some_fn)
    if instance.name != "override":
        _fail(f"Expected name 'override', got {instance.name!r}")
    print("PASS: C6 - scorer explicit name overrides function name")


# ── C9: validate_scorers passes through Scorer instances ────────────────────
# Contracts: C9

def check_c9_validate_scorers_passthrough():
    """validate_scorers([Scorer_instance]) returns list with same instance."""
    from mlflow.genai.scorers.validation import validate_scorers

    s = Scorer(name="test_scorer")
    result = validate_scorers([s])
    if result != [s]:
        _fail(f"validate_scorers did not pass through Scorer instance: {result}")
    print("PASS: C9 - validate_scorers passes through Scorer instances")


# ── C13: valid_data_for_builtin_scorers normalizes request→inputs ──────────
# Contracts: C13

def check_c13_valid_data_normalizes_request_to_inputs():
    """Data with 'request' column is treated as having 'inputs' for validation."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    df = pd.DataFrame({"request": ["test request"], "outputs": ["test output"]})
    try:
        valid_data_for_builtin_scorers(df, [])
    except Exception as exc:
        _fail(f"valid_data_for_builtin_scorers raised: {exc}")
    print("PASS: C13 - valid_data_for_builtin_scorers normalizes request->inputs")


# ── C14: valid_data_for_builtin_scorers normalizes response→outputs ────────
# Contracts: C14

def check_c14_valid_data_normalizes_response_to_outputs():
    """Data with 'response' column is treated as having 'outputs' for validation."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    df = pd.DataFrame({"inputs": ["test input"], "response": ["test response"]})
    try:
        valid_data_for_builtin_scorers(df, [])
    except Exception as exc:
        _fail(f"valid_data_for_builtin_scorers raised: {exc}")
    print("PASS: C14 - valid_data_for_builtin_scorers normalizes response->outputs")


# ── C15: valid_data_for_builtin_scorers with predict_fn adds outputs ───────
# Contracts: C15

def check_c15_valid_data_predict_fn_adds_outputs():
    """When predict_fn provided, 'outputs' considered present even if absent."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    df = pd.DataFrame({"inputs": ["test input"]})
    try:
        valid_data_for_builtin_scorers(df, [], predict_fn=lambda x: x)
    except Exception as exc:
        _fail(f"valid_data_for_builtin_scorers with predict_fn raised: {exc}")
    print("PASS: C15 - valid_data_for_builtin_scorers with predict_fn adds outputs")


# ── C16: valid_data_for_builtin_scorers with trace adds inputs/outputs ─────
# Contracts: C16

def check_c16_valid_data_trace_adds_inputs_outputs():
    """When 'trace' column present, inputs and outputs considered available."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    df = pd.DataFrame({"trace": ["trace_data_1"]})
    try:
        valid_data_for_builtin_scorers(df, [])
    except Exception as exc:
        _fail(f"valid_data_for_builtin_scorers with trace raised: {exc}")
    print("PASS: C16 - valid_data_for_builtin_scorers with trace adds inputs/outputs")


# ── C18: valid_data_for_builtin_scorers explodes expectation keys ──────────
# Contracts: C18

def check_c18_valid_data_explodes_expectation_keys():
    """For dict expectations, virtual columns 'expectations/{key}' are added."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    df = pd.DataFrame({
        "inputs": ["test"],
        "outputs": ["test"],
        "expectations": [{"expected_response": "x", "expected_facts": ["y"]}],
    })
    try:
        valid_data_for_builtin_scorers(df, [])
    except Exception as exc:
        _fail(f"valid_data_for_builtin_scorers with expectations raised: {exc}")
    print("PASS: C18 - valid_data_for_builtin_scorers explodes expectation keys")


# ── C22: get_all_scorers returns BuiltInScorer instances ───────────────────
# Contracts: C22

def check_c22_get_all_scorers_builtinscorer_instances():
    """Each element of get_all_scorers() is a BuiltInScorer instance."""
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, get_all_scorers

    scorers = get_all_scorers()
    if not scorers:
        _fail("get_all_scorers() returned empty list")
    for s in scorers:
        if not isinstance(s, BuiltInScorer):
            _fail(f"get_all_scorers() element is not BuiltInScorer: {type(s)}")
    print("PASS: C22 - get_all_scorers returns BuiltInScorer instances")


# ── C25: scorer aggregation defaults ────────────────────────────────────────
# Contracts: C25

def check_c25_scorer_aggregations_default():
    """scorer(fn).aggregations is None (default applied downstream)."""
    def my_fn(inputs, outputs):
        return True

    instance = scorer(my_fn)
    if instance.aggregations is not None:
        _fail(f"Expected aggregations=None, got {instance.aggregations!r}")
    print("PASS: C25 - scorer aggregations defaults to None")


# ── C26: scorer accepts and stores description ──────────────────────────────
# Contracts: C26

def check_c26_scorer_stores_description():
    """scorer(description='evaluates X')(fn).description == 'evaluates X'."""
    def my_fn(inputs):
        return True

    instance = scorer(description="evaluates X")(my_fn)
    if instance.description != "evaluates X":
        _fail(f"Expected description 'evaluates X', got {instance.description!r}")
    print("PASS: C26 - scorer stores description")


# ── C27: scorer accepts and stores aggregations ─────────────────────────────
# Contracts: C27

def check_c27_scorer_stores_aggregations():
    """scorer(aggregations=['min','max'])(fn).aggregations == ['min','max']."""
    def my_fn(inputs):
        return True

    instance = scorer(aggregations=["min", "max"])(my_fn)
    if instance.aggregations != ["min", "max"]:
        _fail(f"Expected aggregations ['min','max'], got {instance.aggregations!r}")
    print("PASS: C27 - scorer stores aggregations")


# ── C28: scorer preserves _original_func reference ─────────────────────────
# Contracts: C28

def check_c28_scorer_preserves_original_func():
    """scorer(fn)._original_func is fn."""
    def my_original_fn(inputs, outputs, expectations, trace):
        return {"ok": True}

    instance = scorer(my_original_fn)
    stored = getattr(instance, "_original_func", None)
    if stored is not my_original_fn:
        _fail(f"_original_func is {stored!r}, expected the original function")
    print("PASS: C28 - scorer preserves _original_func reference")


# ── runner ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    check_c1_scorer_returns_customscorer()
    check_c2_scorer_param_no_func_returns_partial()
    check_c4_customscorer_call_signature_has_self()
    check_c5_scorer_name_defaults_to_func_name()
    check_c6_scorer_explicit_name_overrides()
    check_c9_validate_scorers_passthrough()
    check_c13_valid_data_normalizes_request_to_inputs()
    check_c14_valid_data_normalizes_response_to_outputs()
    check_c15_valid_data_predict_fn_adds_outputs()
    check_c16_valid_data_trace_adds_inputs_outputs()
    check_c18_valid_data_explodes_expectation_keys()
    check_c22_get_all_scorers_builtinscorer_instances()
    check_c25_scorer_aggregations_default()
    check_c26_scorer_stores_description()
    check_c27_scorer_stores_aggregations()
    check_c28_scorer_preserves_original_func()
    print("arch_spec: all checks passed")
