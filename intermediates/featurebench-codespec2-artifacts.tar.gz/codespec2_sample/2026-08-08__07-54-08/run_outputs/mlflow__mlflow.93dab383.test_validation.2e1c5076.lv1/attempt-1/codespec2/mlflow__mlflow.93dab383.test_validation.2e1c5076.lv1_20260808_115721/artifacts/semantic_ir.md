# Semantic IR

## L1. Requirement Obligations

### R1: scorer decorator — parameterized and direct usage
- **Type:** Interface
- **Statement:** The `scorer` callable at `/testbed/mlflow/genai/scorers/base.py` must operate as both a direct decorator (`@scorer`) and a parameterized decorator factory (`@scorer(name="...", description="...", aggregations=[...])`). When called with `func=None`, it must return a `functools.partial` bound to the supplied keyword arguments. When called with a callable `func`, it must return a `CustomScorer` instance.
- **Task Evidence:** Interface Description 1: "def scorer(func = None):" with args `func`, `name`, `description`, `aggregations`. Docstring states "A decorator to define a custom scorer."
- **Acceptance:** `scorer` (no args) can be placed above a `def`; `scorer(name="x")` can be placed above a `def`; `scorer(name="x")(some_func)` returns a Scorer instance.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:847-1031` (full reference); `/testbed/mlflow/genai/scorers/base.py:847-1031` (skeleton — missing `CustomScorer` inner class); `/testbed/tests/genai/scorers/test_scorer.py:62-75` (test_scorer_existence_in_metrics, test_scorer_name_works).
- **Uncertainty:** None.

### R2: CustomScorer inner class — delegation and metadata
- **Type:** Behavior
- **Statement:** Within the `scorer` function, when `func` is not None, a local class `CustomScorer(Scorer)` must be defined. Its `__call__` must delegate to the original `func`. It must store a reference to `func` via `_original_func` private attribute (set using `object.__setattr__` in `__init__`). Its `kind` property must return `ScorerKind.DECORATOR`.
- **Task Evidence:** Interface Description 1 docstring and examples show that the decorated function's parameters and return values are preserved; the `@scorer` decorator wraps a function into a `Scorer` subclass.
- **Acceptance:** `isinstance(scorer(always_yes), Scorer)` is True; calling the instance invokes the original function; `instance.kind == ScorerKind.DECORATOR`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1016` (CustomScorer definition); `/testbed/tests/genai/scorers/test_scorer.py:62` (test uses `scorer(always_yes)` as a Scorer).
- **Uncertainty:** None.

### R3: scorer signature rewriting — self parameter injection
- **Type:** Interface
- **Statement:** The `CustomScorer.__call__.__signature__` must be updated to prepend a `self` parameter while preserving the original function's parameter names and kinds. This enables MLflow's evaluation harness to inspect the scorer's parameter requirements.
- **Task Evidence:** Interface Description 1: scorer function accepts `inputs`, `outputs`, `expectations`, `trace` parameters. Task states "Support both strict validation and graceful degradation."
- **Acceptance:** `inspect.signature(scorer_instance.__call__)` reveals `(self, inputs, outputs, ...)` matching the original function.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1021-1029` (signature rewriting); `/testbed/tests/genai/scorers/test_scorer.py:189` (test_trace_passed_correctly checks parameter passing).
- **Uncertainty:** None.

### R4: scorer return value normalization — primitive types and Feedback
- **Type:** Behavior
- **Statement:** The decorated scorer function may return `bool`, `int`, `float`, `str`, a single `Feedback` object, or a list of `Feedback` objects. The return value is not transformed by the decorator itself; normalization is handled downstream by the evaluation harness.
- **Task Evidence:** Interface Description 1: "The scorer function should return one of the following: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects."
- **Acceptance:** A `@scorer`-decorated function returning any of these types passes through to the caller.
- **Repository Evidence:** `/testbed/tests/genai/scorers/test_scorer.py:247-266` (test_scorer_on_genai_evaluate parametrized with multiple return types); `/testbed/tests/genai/scorers/test_scorer.py:304-315` (test_custom_scorer_overwrites_default_feedback_name).
- **Uncertainty:** None.

### R5: validate_scorers — list type guard and empty-list passthrough
- **Type:** Failure
- **Statement:** `validate_scorers(scorers)` in `/testbed/mlflow/genai/scorers/validation.py` must raise `MlflowException` if `scorers` is not a `list`. If `scorers` is an empty list, it must return an empty list without error.
- **Task Evidence:** Interface Description 2: "Validate a list of specified scorers and ensure they are valid Scorer instances." Notes: "Empty lists are valid and return an empty list."
- **Acceptance:** `validate_scorers("not_a_list")` raises MlflowException; `validate_scorers([])` returns `[]`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:28-39` (type check, empty list guard); `/testbed/mlflow/genai/evaluation/base.py:243` (caller: `scorers = validate_scorers(scorers)`).
- **Uncertainty:** None.

### R6: validate_scorers — Scorer instance passthrough
- **Type:** Behavior
- **Statement:** Each element in the `scorers` list that is an instance of `Scorer` must be included in the return list unchanged.
- **Task Evidence:** Interface Description 2: "validates that each item is either an instance of mlflow.genai.scorers.base.Scorer or a legacy databricks.rag_eval.evaluation.metrics.Metric."
- **Acceptance:** `validate_scorers([BuiltInScorer_instance, custom_scorer_instance])` returns the same list.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:44-45` (`isinstance(scorer, Scorer)` check); `/testbed/tests/genai/scorers/test_scorer.py:62` (indirect test via evaluate pipeline).
- **Uncertainty:** None.

### R7: validate_scorers — legacy Metric support (Databricks only)
- **Type:** Compatibility
- **Statement:** If `databricks.agents` is installed (`IS_DBX_AGENTS_INSTALLED` is True), elements that are instances of `databricks.rag_eval.evaluation.metrics.Metric` must be accepted and included in the return list. A deprecation warning must be logged.
- **Task Evidence:** Interface Description 2: "Legacy databricks.rag_eval metrics are supported but deprecated, and will log warnings."
- **Acceptance:** When `databricks.agents` is installed, `validate_scorers([legacy_metric])` returns a list containing the metric and logs a warning.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:48-55` (Metric check); `/testbed/tests/genai/conftest.py:17` (`IS_DBX_AGENTS_INSTALLED` used in fixtures).
- **Uncertainty:** The exact warning message format may vary; the skinny reference provides the canonical format.

### R8: validate_scorers — helpful error hints for common mistakes
- **Type:** Failure
- **Statement:** When an invalid element is encountered, `validate_scorers` must raise `MlflowException` with context-specific hints: (1) if the element equals `get_all_scorers()` (nested list mistake), hint to flatten; (2) if the element is a `type` and subclass of `BuiltInScorer`, hint to instantiate; (3) otherwise, a generic invalid-type message.
- **Task Evidence:** Interface Description 2: "The function provides context-aware error messages to help users correct common mistakes." Examples: "[get_all_scorers()]" → hint, "AnswerRelevance instead of AnswerRelevance()" → hint.
- **Acceptance:** `validate_scorers([get_all_scorers()])` raises with hint about flattening; `validate_scorers([Correctness])` raises with hint about instantiation.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:58-82` (hint logic); `/testbed/mlflow/genai/evaluation/base.py:243` (caller).
- **Uncertainty:** None.

### R9: valid_data_for_builtin_scorers — column name normalization
- **Type:** Dataflow
- **Statement:** `valid_data_for_builtin_scorers` must normalize legacy column names: `"request"` → `"inputs"` and `"response"` → `"outputs"` in the column set used for validation. This handles upstream conversion performed by `_convert_to_eval_set`.
- **Task Evidence:** Interface Description 2: "The function performs automatic column name mapping: 'request' -> 'inputs' and 'response' -> 'outputs' to handle legacy schema conversions."
- **Acceptance:** Data with `"request"` column validates as if `"inputs"` were present.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:119-124` (revert replacement); `/testbed/mlflow/genai/evaluation/base.py:248` (caller passes df from `_convert_to_eval_set`).
- **Uncertainty:** None.

### R10: valid_data_for_builtin_scorers — predict_fn relaxes outputs requirement
- **Type:** State
- **Statement:** When `predict_fn` is not None, the `"outputs"` column is considered available even if absent from the DataFrame, and the `"trace"` column is also considered available.
- **Task Evidence:** Interface Description 2: "When provided, the data doesn't need to contain the 'outputs' column as it can be generated by the predict function."
- **Acceptance:** `valid_data_for_builtin_scorers(df_without_outputs, [Correctness()], predict_fn=some_fn)` does not log `"outputs"` as missing.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:126-128,133` (predict_fn logic); `/testbed/mlflow/genai/evaluation/base.py:248` (caller).
- **Uncertainty:** None.

### R11: valid_data_for_builtin_scorers — trace column infers inputs and outputs
- **Type:** Dataflow
- **Statement:** When the `"trace"` column is present, both `"inputs"` and `"outputs"` columns are considered available (inferred from trace).
- **Task Evidence:** Interface Description 2: "The presence of a 'trace' column implies that both 'inputs' and 'outputs' can be inferred from the trace data."
- **Acceptance:** `valid_data_for_builtin_scorers(df_with_trace_only, [Correctness()])` does not log `"inputs"` or `"outputs"` as missing.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:130-131` (trace inference); `/testbed/tests/genai/scorers/test_scorer.py:76-145` (test_trace_passed_to_builtin_scorers_correctly uses trace column).
- **Uncertainty:** None.

### R12: valid_data_for_builtin_scorers — expectations column explosion
- **Type:** Dataflow
- **Statement:** When the `"expectations"` column is present, its dictionary values are exploded: each key `k` in the dictionary becomes a virtual column `"expectations/{k}"`. Non-dictionary values in the expectations column must raise `MlflowException`.
- **Task Evidence:** Interface Description 2: "The 'expectations' column is treated specially - its dictionary values are exploded into individual expectation fields for validation." "Raises: MlflowException if the 'expectations' column contains non-dictionary values."
- **Acceptance:** `expectations = {"expected_response": "Paris"}` generates virtual column `"expectations/expected_response"`; `expectations = "not_a_dict"` raises MlflowException.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:136-148` (explosion logic); `/testbed/tests/genai/scorers/test_builtin_scorers.py:542` (test_equivalence).
- **Uncertainty:** None.

### R13: valid_data_for_builtin_scorers — missing column logging (not raising)
- **Type:** SideEffect
- **Statement:** When required columns are missing, `valid_data_for_builtin_scorers` must log an informative message via `_logger.info` but must NOT raise an exception. The message must list each missing column and the scorers that require it.
- **Task Evidence:** Interface Description 2: "When required columns are missing, the function logs an informative message but doesn't raise an exception, allowing the evaluation to continue with null results for affected scorers."
- **Acceptance:** Missing columns produce an INFO log line; no exception is raised.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:151-173` (logging logic); `/testbed/mlflow/genai/evaluation/base.py:243-248` (validation precedes execution).
- **Uncertainty:** None.

### R14: valid_data_for_builtin_scorers — per-scorer column validation via validate_columns
- **Type:** Dataflow
- **Statement:** For each builtin scorer, `valid_data_for_builtin_scorers` must call `scorer.validate_columns(input_columns)`. If `MissingColumnsException` is raised, the missing columns are aggregated per scorer name.
- **Task Evidence:** Interface Description 2: "Each scorer defines its own required columns through the `validate_columns` method."
- **Acceptance:** Each builtin scorer's `validate_columns` is invoked; `MissingColumnsException` is caught and aggregated.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:152-158` (validate_columns loop); `/testbed/mlflow/genai/scorers/builtin_scorers.py:324-328` (BuiltInScorer.validate_columns).
- **Uncertainty:** None.

### R15: get_all_scorers — returns all builtin scorer instances
- **Type:** Interface
- **Statement:** `get_all_scorers()` in `/testbed/mlflow/genai/scorers/builtin_scorers.py` must return a `list[BuiltInScorer]` containing one default instance each of: `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, `Equivalence`. On Databricks tracking URIs, it must additionally include `Safety` and `RetrievalRelevance`.
- **Task Evidence:** Interface Description 3: "Returns: list[BuiltInScorer]: A list containing instances of all available built-in scorers."
- **Acceptance:** `get_all_scorers()` returns a list of 6 scorers on OSS, 8 on Databricks; each is a `BuiltInScorer` instance.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1597` (full implementation); `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-578` (test_get_all_scorers_oss); `/testbed/mlflow/genai/scorers/__init__.py:36,77,93` (lazy import and __all__ export).
- **Uncertainty:** None.

### R16: get_all_scorers — Databricks-only scorers conditional
- **Type:** Compatibility
- **Statement:** The `Safety` and `RetrievalRelevance` scorers must only be included when `is_databricks_uri(mlflow.get_tracking_uri())` returns True.
- **Task Evidence:** Interface Description 3: "Some scorers (Safety and RetrievalRelevance) are only available when using a Databricks tracking URI."
- **Acceptance:** On OSS tracking URI, `get_all_scorers()` excludes Safety and RetrievalRelevance; on Databricks URI, they are included.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1595-1596` (conditional extend); `/testbed/tests/genai/scorers/test_builtin_scorers.py:570` (test_get_all_scorers_oss).
- **Uncertainty:** None.

### R17: scorer name determination — function name or explicit name parameter
- **Type:** Interface
- **Statement:** The `Scorer.name` attribute must be set to the explicit `name` parameter if provided, otherwise to `func.__name__`. The metric name in evaluation results is derived from this attribute.
- **Task Evidence:** Interface Description 1: "The metric name will be determined by the scorer function's name or a custom name specified in the `name` parameter."
- **Acceptance:** `scorer(name="custom")(fn).name == "custom"`; `scorer(fn).name == fn.__name__`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1027` (`name=name or func.__name__`); `/testbed/tests/genai/scorers/test_scorer.py:70-75` (test_scorer_name_works).
- **Uncertainty:** None.

### R18: scorer aggregations default — "mean" when unspecified
- **Type:** Interface
- **Statement:** When `aggregations` is not explicitly provided, downstream aggregation processing defaults to `["mean"]`. This default is applied in the aggregation module, not in the scorer decorator itself.
- **Task Evidence:** Interface Description 1: "By default, 'mean' is used as the aggregation function."
- **Acceptance:** A scorer instance with `aggregations=None` has its results aggregated using `"mean"`.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/aggregation.py:54-55` (`scorer_aggregations[scorer.name] = ["mean"]` default); `/testbed/tests/genai/scorers/test_aggregation.py`.
- **Uncertainty:** None.

---

## L2. Functional Design Graph

### N1: scorer (public entry)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:847`; exported via `/testbed/mlflow/genai/scorers/__init__.py:6` (`from mlflow.genai.scorers.base import Scorer, ScorerSamplingConfig, scorer`)

### N2: Scorer (base class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:108` (`class Scorer(BaseModel)`)

### N3: CustomScorer (inner class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999` (`class CustomScorer(Scorer)`)

### N4: ScorerKind.DECORATOR (enum value)
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:29-31` (enum definition)

### N5: PrivateAttr._original_func
- **Kind:** State
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1001` (`_original_func: Callable[..., Any] | None = PrivateAttr(default=None)`)

### N6: functools.partial (parameterized decorator)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:997-999` (imported `functools`; `return functools.partial(scorer, ...)`)

### N7: validate_scorers (public entry)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:28`; called from `/testbed/mlflow/genai/evaluation/base.py:243`

### N8: valid_data_for_builtin_scorers (public entry)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:109`; called from `/testbed/mlflow/genai/evaluation/base.py:248`

### N9: get_all_scorers (public entry)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567`; called from `/testbed/mlflow/genai/evaluation/base.py:361,385` and `/testbed/mlflow/cli/genai_eval_utils.py:121`; exported via `/testbed/mlflow/genai/scorers/__init__.py:77`

### N10: BuiltInScorer (base class for builtins)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py:261` (`class BuiltInScorer(Judge)`)

### N11: BuiltInScorer.validate_columns
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py:324`

### N12: MissingColumnsException
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py:1601`

### N13: MlflowException (error)
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/exceptions.py`; used throughout

### N14: IS_DBX_AGENTS_INSTALLED (config flag)
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/validation.py:23`

### N15: BuiltInScorer subclasses (Correctness, Equivalence, etc.)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py` (multiple class definitions from line ~380 onward)

### N16: is_databricks_uri (utility)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/utils/uri.py`; imported in `/testbed/mlflow/genai/scorers/builtin_scorers.py:58`

### N17: mlflow.get_tracking_uri (utility)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/tracking/fluent.py`; called in `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1595`

### N18: _logger (logging observer)
- **Kind:** Observer
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/validation.py:20`

### N19: evaluate (caller)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/evaluation/base.py:243,248`

### N20: inspect.signature (stdlib utility)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:2` (import inspect)

---

### E1: scorer -> CustomScorer (construction)
- **Kind:** CONTROL
- **Condition:** `func is not None`
- **Transfer:** When `func` is provided, `scorer` defines `CustomScorer` class locally, rewrites its `__call__` signature, instantiates it with `name=name or func.__name__`, `description`, `aggregations`, and returns it.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:997-1031` (full path); `/testbed/tests/genai/scorers/test_scorer.py:62` (uses `scorer(always_yes)`).
- **Obligations:** R1, R2, R3, R17

### E2: scorer -> functools.partial (parameterized decorator)
- **Kind:** CONTROL
- **Condition:** `func is None`
- **Transfer:** Returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:997-1000`; `/testbed/tests/genai/scorers/test_scorer.py:71` (`scorer(name="always_no")(always_yes)`).
- **Obligations:** R1

### E3: CustomScorer.__init__ -> _original_func (state set)
- **Kind:** STATE
- **Condition:** Always (on construction)
- **Transfer:** Stores the original `func` reference via `object.__setattr__(self, "_original_func", func)`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1003-1007`
- **Obligations:** R2

### E4: CustomScorer.__call__ -> func (delegation)
- **Kind:** CALL
- **Condition:** Always (on invocation)
- **Transfer:** Passes `*args, **kwargs` through to the original `func` and returns its result unchanged.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1009-1010`
- **Obligations:** R2, R4

### E5: CustomScorer.kind -> ScorerKind.DECORATOR
- **Kind:** DATA
- **Condition:** Always (on property access)
- **Transfer:** Returns `ScorerKind.DECORATOR` enum value.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1012-1014`
- **Obligations:** R2

### E6: scorer -> inspect.signature (signature rewrite)
- **Kind:** CALL
- **Condition:** `func is not None`
- **Transfer:** Reads original function's signature, prepends `self` parameter, assigns to `CustomScorer.__call__.__signature__`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1021-1025`
- **Obligations:** R3

### E7: validate_scorers -> Scorer (type check)
- **Kind:** CONTROL
- **Condition:** `isinstance(scorer_item, Scorer)`
- **Transfer:** Appends valid Scorer instances to output list.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:44-45`
- **Obligations:** R6

### E8: validate_scorers -> IS_DBX_AGENTS_INSTALLED / Metric (legacy check)
- **Kind:** CONTROL
- **Condition:** `IS_DBX_AGENTS_INSTALLED and isinstance(scorer_item, Metric)`
- **Transfer:** Appends legacy Metric to output list and logs deprecation warning.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:48-55`
- **Obligations:** R7

### E9: validate_scorers -> MlflowException (invalid item)
- **Kind:** CONTROL
- **Condition:** Item is not `Scorer` and (not installed or not `Metric`)
- **Transfer:** Raises `MlflowException` with context-aware hint based on item type.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:58-82`
- **Obligations:** R5, R8

### E10: validate_scorers -> MlflowException (not a list)
- **Kind:** CONTROL
- **Condition:** `not isinstance(scorers, list)`
- **Transfer:** Raises `MlflowException` with message about list requirement.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:36-39`
- **Obligations:** R5

### E11: validate_scorers -> [] (empty list passthrough)
- **Kind:** DATA
- **Condition:** `len(scorers) == 0`
- **Transfer:** Returns empty list.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:41-42`
- **Obligations:** R5

### E12: valid_data_for_builtin_scorers -> DataFrame.columns (column normalization)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Removes `"request"` adds `"inputs"`; removes `"response"` adds `"outputs"`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:119-124`
- **Obligations:** R9

### E13: valid_data_for_builtin_scorers -> predict_fn (outputs relaxation)
- **Kind:** DATA
- **Condition:** `predict_fn is not None`
- **Transfer:** Adds `"outputs"` and `"trace"` to the column set.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:126-128,133`
- **Obligations:** R10

### E14: valid_data_for_builtin_scorers -> trace column (inputs/outputs inference)
- **Kind:** DATA
- **Condition:** `"trace" in input_columns`
- **Transfer:** Adds `"inputs"` and `"outputs"` to the column set.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:130-131`
- **Obligations:** R11

### E15: valid_data_for_builtin_scorers -> expectations column (explosion)
- **Kind:** DATA
- **Condition:** `"expectations" in input_columns`
- **Transfer:** Iterates expectation dict values; raises `MlflowException` for non-dicts; adds `"expectations/{key}"` columns.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:136-148`
- **Obligations:** R12

### E16: valid_data_for_builtin_scorers -> BuiltInScorer.validate_columns (per-scorer check)
- **Kind:** CALL
- **Condition:** For each scorer in `builtin_scorers`
- **Transfer:** Calls `scorer.validate_columns(input_columns)`, catches `MissingColumnsException`, aggregates missing columns.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:152-158`
- **Obligations:** R14

### E17: valid_data_for_builtin_scorers -> _logger (missing column report)
- **Kind:** DATA
- **Condition:** `missing_col_to_scorers` is non-empty
- **Transfer:** Logs INFO message listing missing columns and affected scorers. No exception raised.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:160-173`
- **Obligations:** R13

### E18: get_all_scorers -> BuiltInScorer subclasses (instantiation)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Instantiates `ExpectationsGuidelines()`, `Correctness()`, `RelevanceToQuery()`, `RetrievalSufficiency()`, `RetrievalGroundedness()`, `Equivalence()` with defaults.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1588-1594`
- **Obligations:** R15

### E19: get_all_scorers -> is_databricks_uri (conditional extension)
- **Kind:** CONTROL
- **Condition:** `is_databricks_uri(mlflow.get_tracking_uri())`
- **Transfer:** If True, extends the list with `Safety()` and `RetrievalRelevance()`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1595-1596`
- **Obligations:** R16

### E20: evaluate -> validate_scorers (call)
- **Kind:** CALL
- **Condition:** Always (on evaluate entry)
- **Transfer:** Passes user-provided `scorers` argument; receives validated `list[Scorer]`.
- **Evidence:** `/testbed/mlflow/genai/evaluation/base.py:243`
- **Obligations:** R5, R6, R7, R8

### E21: evaluate -> valid_data_for_builtin_scorers (call)
- **Kind:** CALL
- **Condition:** Always (after validation, before execution)
- **Transfer:** Passes DataFrame, filtered builtin scorers, and `predict_fn`.
- **Evidence:** `/testbed/mlflow/genai/evaluation/base.py:246-248`
- **Obligations:** R9, R10, R11, R12, R13, R14

### E22: evaluate -> get_all_scorers (call, default scorers)
- **Kind:** CALL
- **Condition:** When `scorers` not explicitly provided
- **Transfer:** Receives list of all builtin scorer instances as default.
- **Evidence:** `/testbed/mlflow/genai/evaluation/base.py:361,385`
- **Obligations:** R15, R16

---

## L3. Verifiable Contracts

### C1: scorer returns CustomScorer instance
- **Type:** Behavior
- **Subject:** `scorer(some_func)` return value
- **Relation:** TYPE_IS
- **Expected:** Instance of `Scorer` (specifically the dynamically created `CustomScorer` subclass) with `kind == ScorerKind.DECORATOR`
- **Evidence:** Interface Description 1 examples; `/testbed/tests/genai/scorers/test_scorer.py:62-68` (test_scorer_existence_in_metrics uses `scorer(always_yes)` as a Scorer); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1027-1031`
- **Observe:** RETURN_VALUE
- **Target:** `isinstance(scorer(lambda x: x), Scorer)` evaluates to True
- **Obligations:** R1, R2
- **Graph:** N1, N3, E1

### C2: scorer(func=None) returns functools.partial
- **Type:** Behavior
- **Subject:** `scorer(name="test")` return value
- **Relation:** TYPE_IS
- **Expected:** `functools.partial` bound to `scorer` with `name="test"`
- **Evidence:** Interface Description 1: "func: The scorer function to be decorated." / `/testbed/mlflow/genai/scorers/base.py:997-1000`
- **Observe:** RETURN_VALUE
- **Target:** `type(scorer(name="x")).__name__` contains `"partial"`
- **Obligations:** R1
- **Graph:** N1, N6, E2

### C3: CustomScorer delegates to original function
- **Type:** Behavior
- **Subject:** `scorer(fn)(*args, **kwargs)` invocation
- **Relation:** EQ
- **Expected:** Result equals `fn(*args, **kwargs)`
- **Evidence:** Interface Description 1: scorer function's behavior is preserved; `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1009-1010`; `/testbed/tests/genai/scorers/test_scorer.py:304-315` (test_custom_scorer_overwrites_default_feedback_name shows delegation with Feedback return).
- **Observe:** RETURN_VALUE
- **Target:** `scorer(lambda x: x+1)(x=1) == 2`
- **Obligations:** R2, R4
- **Graph:** N3, E4

### C4: CustomScorer.__call__ signature includes self
- **Type:** Interface
- **Subject:** `inspect.signature(scorer(fn).__call__)`
- **Relation:** CONTAINS
- **Expected:** First parameter is `self`; remaining parameters match `fn`'s signature
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1021-1025`; `/testbed/tests/genai/scorers/test_scorer.py:189` (test_trace_passed_correctly depends on correct signature).
- **Observe:** RETURN_VALUE
- **Target:** `inspect.signature(scorer(fn).__call__).parameters.keys()` starts with `"self"`
- **Obligations:** R3
- **Graph:** N3, N20, E6

### C5: scorer name defaults to function name
- **Type:** Interface
- **Subject:** `scorer(fn).name`
- **Relation:** EQ
- **Expected:** `fn.__name__`
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1027`; `/testbed/tests/genai/scorers/test_scorer.py:70-75` (test_scorer_name_works).
- **Observe:** FIELD_READ
- **Target:** `scorer(always_yes).name == "always_yes"`
- **Obligations:** R17
- **Graph:** N3, E1

### C6: scorer explicit name overrides function name
- **Type:** Interface
- **Subject:** `scorer(name="custom")(fn).name`
- **Relation:** EQ
- **Expected:** `"custom"`
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1027`; `/testbed/tests/genai/scorers/test_scorer.py:70-75`.
- **Observe:** FIELD_READ
- **Target:** `scorer(name="always_no")(always_yes).name == "always_no"`
- **Obligations:** R17
- **Graph:** N3, E1

### C7: validate_scorers rejects non-list input
- **Type:** Failure
- **Subject:** `validate_scorers("not_a_list")`
- **Relation:** RAISES
- **Expected:** `MlflowException` with message containing "must be a list"
- **Evidence:** Interface Description 2: "Raises: MlflowException: If scorers is not a list"; `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:36-39`
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, match="must be a list"): validate_scorers("x")`
- **Obligations:** R5
- **Graph:** N7, N13, E10

### C8: validate_scorers returns empty list for empty input
- **Type:** Behavior
- **Subject:** `validate_scorers([])`
- **Relation:** EQ
- **Expected:** `[]`
- **Evidence:** Interface Description 2 Notes: "Empty lists are valid and return an empty list"; `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:41-42`
- **Observe:** RETURN_VALUE
- **Target:** `validate_scorers([]) == []`
- **Obligations:** R5
- **Graph:** N7, E11

### C9: validate_scorers passes through Scorer instances
- **Type:** Behavior
- **Subject:** `validate_scorers([scorer_instance])`
- **Relation:** EQ
- **Expected:** Returns list containing the same instance
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:44-45`
- **Observe:** RETURN_VALUE
- **Target:** `validate_scorers([Scorer(name="x")])[0].name == "x"`
- **Obligations:** R6
- **Graph:** N7, N2, E7

### C10: validate_scorers rejects non-Scorer item with hint
- **Type:** Failure
- **Subject:** `validate_scorers([42])`
- **Relation:** RAISES
- **Expected:** `MlflowException` with message containing "invalid item" and the type name
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:80-83`
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, match="invalid item"): validate_scorers([42])`
- **Obligations:** R8
- **Graph:** N7, N13, E9

### C11: validate_scorers hints for class-instead-of-instance mistake
- **Type:** Failure
- **Subject:** `validate_scorers([Correctness])` (class, not instance)
- **Relation:** RAISES
- **Expected:** `MlflowException` with hint "passed a scorer class instead of an instance" and `Correctness()`
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:74-78`
- **Observe:** EXCEPTION
- **Target:** Exception message contains "class instead of an instance" and `Correctness()`
- **Obligations:** R8
- **Graph:** N7, N10, E9

### C12: validate_scorers hints for nested get_all_scorers mistake
- **Type:** Failure
- **Subject:** `validate_scorers([get_all_scorers()])`
- **Relation:** RAISES
- **Expected:** `MlflowException` with hint "Use `scorers=get_all_scorers()`"
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:62-68`
- **Observe:** EXCEPTION
- **Target:** Exception message contains "scorers=get_all_scorers()"
- **Obligations:** R8
- **Graph:** N7, N9, E9

### C13: valid_data_for_builtin_scorers normalizes request->inputs
- **Type:** Dataflow
- **Subject:** Column set after `valid_data_for_builtin_scorers` processing
- **Relation:** PRESERVE
- **Expected:** Data with `"request"` column is treated as having `"inputs"` for validation purposes
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:119-121`
- **Observe:** SIDE_EFFECT (no missing-column log for "inputs" when "request" is present)
- **Target:** Log output does not contain "inputs" as missing when "request" column exists
- **Obligations:** R9
- **Graph:** N8, E12

### C14: valid_data_for_builtin_scorers normalizes response->outputs
- **Type:** Dataflow
- **Subject:** Column set after `valid_data_for_builtin_scorers` processing
- **Relation:** PRESERVE
- **Expected:** Data with `"response"` column is treated as having `"outputs"` for validation purposes
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:122-124`
- **Observe:** SIDE_EFFECT
- **Target:** Log output does not contain "outputs" as missing when "response" column exists
- **Obligations:** R9
- **Graph:** N8, E12

### C15: valid_data_for_builtin_scorers with predict_fn adds outputs
- **Type:** Dataflow
- **Subject:** Internal column set when `predict_fn is not None`
- **Relation:** CONTAINS
- **Expected:** `"outputs"` is considered present even if not in DataFrame columns
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:126-128`
- **Observe:** SIDE_EFFECT
- **Target:** No "outputs" missing log when predict_fn is provided and outputs column absent
- **Obligations:** R10
- **Graph:** N8, E13

### C16: valid_data_for_builtin_scorers with trace column adds inputs and outputs
- **Type:** Dataflow
- **Subject:** Internal column set when `"trace"` in columns
- **Relation:** CONTAINS
- **Expected:** Both `"inputs"` and `"outputs"` are considered present
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:130-131`
- **Observe:** SIDE_EFFECT
- **Target:** No "inputs" or "outputs" missing log when trace column present
- **Obligations:** R11
- **Graph:** N8, E14

### C17: valid_data_for_builtin_scorers raises on non-dict expectations
- **Type:** Failure
- **Subject:** `valid_data_for_builtin_scorers(df, [Correctness()])` where `df["expectations"]` contains a non-dict value
- **Relation:** RAISES
- **Expected:** `MlflowException` with message about expectations column must be a dictionary
- **Evidence:** Interface Description 2 Raises; `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:142-148`
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, match="must be a dictionary")`
- **Obligations:** R12
- **Graph:** N8, N13, E15

### C18: valid_data_for_builtin_scorers explodes expectation keys
- **Type:** Dataflow
- **Subject:** Virtual columns after processing expectations column
- **Relation:** CONTAINS
- **Expected:** For `{"expected_response": "x", "expected_facts": ["y"]}`, virtual columns `"expectations/expected_response"` and `"expectations/expected_facts"` are added
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:149-150`
- **Observe:** SIDE_EFFECT
- **Target:** No "expectations/expected_response" missing log when expectations contains that key
- **Obligations:** R12
- **Graph:** N8, E15

### C19: valid_data_for_builtin_scorers logs missing columns without raising
- **Type:** SideEffect
- **Subject:** Logger output when columns are missing
- **Relation:** CONTAINS
- **Expected:** INFO log message listing missing columns and affected scorers; no exception raised
- **Evidence:** Interface Description 2 Notes; `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:160-173`
- **Observe:** SIDE_EFFECT
- **Target:** `caplog` contains INFO message with "missing following columns"
- **Obligations:** R13
- **Graph:** N8, N18, E17

### C20: valid_data_for_builtin_scorers calls validate_columns on each scorer
- **Type:** Behavior
- **Subject:** `BuiltInScorer.validate_columns` invocations
- **Relation:** CALLS
- **Expected:** Each scorer in `builtin_scorers` has `validate_columns` called with the normalized column set
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:152-158`
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** Mock on `BuiltInScorer.validate_columns` receives `set` argument
- **Obligations:** R14
- **Graph:** N8, N11, E16

### C21: get_all_scorers returns at least 6 scorers on OSS
- **Type:** Behavior
- **Subject:** `len(get_all_scorers())` on non-Databricks URI
- **Relation:** EQ
- **Expected:** 6 (ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence)
- **Evidence:** Interface Description 3 Returns; `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1588-1594`; `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-578`
- **Observe:** RETURN_VALUE
- **Target:** `len(get_all_scorers()) == 6`
- **Obligations:** R15
- **Graph:** N9, E18

### C22: get_all_scorers returns all BuiltInScorer instances
- **Type:** Interface
- **Subject:** Each element of `get_all_scorers()`
- **Relation:** TYPE_IS
- **Expected:** Each element is an instance of `BuiltInScorer`
- **Evidence:** Interface Description 3 Returns; `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-578`
- **Observe:** RETURN_VALUE
- **Target:** `all(isinstance(s, BuiltInScorer) for s in get_all_scorers())` is True
- **Obligations:** R15
- **Graph:** N9, N10, E18

### C23: get_all_scorers includes Safety on Databricks URI
- **Type:** Behavior
- **Subject:** `get_all_scorers()` with Databricks tracking URI
- **Relation:** CONTAINS
- **Expected:** Result list contains an instance of `Safety`
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1595-1596`
- **Observe:** RETURN_VALUE
- **Target:** `any(isinstance(s, Safety) for s in get_all_scorers())` is True when `is_databricks_uri(...)` is True
- **Obligations:** R16
- **Graph:** N9, N16, N17, E19

### C24: get_all_scorers excludes Safety on OSS URI
- **Type:** Behavior
- **Subject:** `get_all_scorers()` with non-Databricks tracking URI
- **Relation:** NE (does not contain)
- **Expected:** Result list does NOT contain `Safety` or `RetrievalRelevance` instances
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1595` (conditional); `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-578` (test_get_all_scorers_oss)
- **Observe:** RETURN_VALUE
- **Target:** `len(get_all_scorers()) == 6` and no Safety/RetrievalRelevance in result
- **Obligations:** R16
- **Graph:** N9, N16, N17, E19

### C25: scorer aggregation defaults to mean
- **Type:** Interface
- **Subject:** `scorer(fn).aggregations`
- **Relation:** EQ
- **Expected:** `None` (aggregations default is applied downstream in aggregation module, not in the decorator)
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1027-1031`; `/testbed/mlflow/genai/scorers/aggregation.py:54-55`
- **Observe:** FIELD_READ
- **Target:** `scorer(fn).aggregations is None`; downstream aggregation uses "mean" as default
- **Obligations:** R18
- **Graph:** N3, E1

### C26: scorer accepts and stores description
- **Type:** Interface
- **Subject:** `scorer(description="evaluates X")(fn).description`
- **Relation:** EQ
- **Expected:** `"evaluates X"`
- **Evidence:** Interface Description 1 Args: "description: A description of what the scorer evaluates."; `/testbed/mlflow/genai/scorers/base.py:108-110` (Scorer model fields)
- **Observe:** FIELD_READ
- **Target:** `scorer(description="test desc")(fn).description == "test desc"`
- **Obligations:** R1
- **Graph:** N3, E1

### C27: scorer accepts and stores aggregations
- **Type:** Interface
- **Subject:** `scorer(aggregations=["min", "max"])(fn).aggregations`
- **Relation:** EQ
- **Expected:** `["min", "max"]`
- **Evidence:** Interface Description 1 Args: "aggregations: A list of aggregation functions"; `/testbed/mlflow/genai/scorers/base.py:108-110`
- **Observe:** FIELD_READ
- **Target:** `scorer(aggregations=["min", "max"])(fn).aggregations == ["min", "max"]`
- **Obligations:** R1
- **Graph:** N3, E1

### C28: scorer preserves function __name__ and __doc__
- **Type:** Interface
- **Subject:** The returned `CustomScorer` instance
- **Relation:** PRESERVE
- **Expected:** The instance is a class, not the original function; the original function's metadata is accessible via `_original_func`
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1014`; `/testbed/mlflow/genai/scorers/scorer_utils.py` (extract_function_body uses the original function reference for serialization)
- **Observe:** FIELD_READ
- **Target:** `scorer(fn)._original_func is fn`
- **Obligations:** R2
- **Graph:** N3, N5, E3

### C29: validate_scorers logs warning for legacy metrics
- **Type:** SideEffect
- **Subject:** Logger output when legacy Metric is passed (Databricks only)
- **Relation:** CONTAINS
- **Expected:** WARNING log with "legacy metrics" and "soon be deprecated"
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:86-91`
- **Observe:** SIDE_EFFECT
- **Target:** `caplog` contains WARNING with "legacy metrics"
- **Obligations:** R7
- **Graph:** N7, N14, N18, E8
