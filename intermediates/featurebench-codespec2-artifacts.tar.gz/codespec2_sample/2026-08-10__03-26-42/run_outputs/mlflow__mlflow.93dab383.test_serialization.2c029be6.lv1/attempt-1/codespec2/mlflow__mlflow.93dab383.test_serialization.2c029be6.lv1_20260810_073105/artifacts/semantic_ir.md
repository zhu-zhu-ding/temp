# Semantic IR

## L1. Requirement Obligations

### R1: AssessmentSourceType instance creation with validation
- Type: Behavior
- Statement: `AssessmentSourceType(source_type: str)` must accept a case-insensitive string, validate it against known types (`SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `HUMAN`, `CODE`), and store the validated uppercase form. The deprecated value `AI_JUDGE` must be accepted with a `FutureWarning` and silently converted to `LLM_JUDGE`.
- Task Evidence: "Initialize an AssessmentSourceType instance with validation and standardization." from Interface Description 2; "The class automatically handles: Case-insensitive string inputs (converts to uppercase), Deprecation warnings for legacy values (AI_JUDGE → LLM_JUDGE), Validation of source type values."
- Acceptance: `AssessmentSourceType("llm_judge")` produces an instance whose `__str__()` returns `"LLM_JUDGE"`. `AssessmentSourceType("AI_JUDGE")` emits `FutureWarning` and `__str__()` returns `"LLM_JUDGE"`. Invalid values raise `MlflowException` with `INVALID_PARAMETER_VALUE`.
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:102-176` declares constants and empty methods; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:102-151` provides full reference implementation; tests at `/testbed/tests/genai/judges/optimizers/conftest.py:13,120` use `AssessmentSourceType.HUMAN` and `AssessmentSourceType.LLM_JUDGE`.
- Uncertainty: None — exact expected behavior is provided by the interface description and reference implementation.

### R2: AssessmentSourceType string conversion
- Type: Interface
- Statement: `AssessmentSourceType.__str__()` must return the validated uppercase string representation of the source type, reflecting any deprecation conversion that occurred during initialization.
- Task Evidence: "Return the standardized assessment source type string (e.g., 'LLM_JUDGE', 'HUMAN', 'CODE', or 'SOURCE_TYPE_UNSPECIFIED'). If the original input was a deprecated value like 'AI_JUDGE', this will return the updated equivalent 'LLM_JUDGE'." from Interface Description 2.
- Acceptance: `str(AssessmentSourceType("human"))` returns `"HUMAN"`. `str(AssessmentSourceType("AI_JUDGE"))` returns `"LLM_JUDGE"`.
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:102-176` declares but does not implement `__str__`; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:148-149` provides `def __str__(self): return self._source_type`.
- Uncertainty: None.

### R3: AssessmentSourceType static parse method
- Type: Behavior
- Statement: `AssessmentSourceType._parse(source_type: str) -> str` must uppercase the input, convert deprecated `AI_JUDGE` to `LLM_JUDGE` with a `FutureWarning`, and raise `MlflowException` for unrecognized values. It must return the validated uppercase string.
- Task Evidence: "This internal method performs case-insensitive validation and standardization of assessment source type values." from Interface Description 2.
- Acceptance: `_parse("human")` returns `"HUMAN"`. `_parse("AI_JUDGE")` emits `FutureWarning` and returns `"LLM_JUDGE"`. `_parse("INVALID")` raises `MlflowException`.
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:176` has only `from_proto`; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:138-146` provides reference.
- Uncertainty: None.

### R4: AssessmentSourceType static standardize method
- Type: Interface
- Statement: `AssessmentSourceType._standardize(source_type: str) -> str` must create a temporary `AssessmentSourceType` instance from the input string and return its string representation. This provides a one-shot validation-and-normalization entry point.
- Task Evidence: "This static method provides a convenient interface for standardizing assessment source type values by creating a temporary AssessmentSourceType instance and converting it to its string representation." from Interface Description 2.
- Acceptance: `_standardize("human")` returns `"HUMAN"`. `_standardize("AI_JUDGE")` returns `"LLM_JUDGE"` with a warning. Used by `AssessmentSource.__post_init__` for source_type normalization.
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:77` calls `AssessmentSourceType._standardize(self.source_type)` in `AssessmentSource.__post_init__`; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:152-153` provides reference.
- Uncertainty: None.

### R5: Backward compatibility for AI_JUDGE deprecation
- Type: Compatibility
- Statement: The legacy `AI_JUDGE` source type must be accepted everywhere a source type string is validated (instance constructor, `_parse`, `_standardize`), must emit a `FutureWarning` when used, and must be transparently converted to `LLM_JUDGE`.
- Task Evidence: "Maintain backward compatibility while deprecating legacy source types" from task Key Challenges; "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE' with a deprecation warning." from Interface Description 2.
- Acceptance: `AssessmentSource(source_type="AI_JUDGE", source_id="gpt-4")` creates an `AssessmentSource` with `source_type == "LLM_JUDGE"` and triggers a `FutureWarning`.
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:31-33` docstring warns about AI_JUDGE deprecation; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:140-145` shows `warnings.warn("AI_JUDGE is deprecated...", FutureWarning)`.
- Uncertainty: None.

### R6: scorer decorator function existence
- Type: Interface
- Statement: A public `scorer(func=None, *, name=None, description=None, aggregations=None)` function must exist at `/testbed/mlflow/genai/scorers/base.py` that acts as a decorator to wrap a plain function into a `CustomScorer` subclass of `Scorer`. When called with `func=None`, it must return a `functools.partial` to support parameterized decorator usage.
- Task Evidence: "A decorator to define a custom scorer that can be used in mlflow.genai.evaluate()." from Interface Description 1.
- Acceptance: `@scorer` and `@scorer(name="x")` both produce callable `CustomScorer` instances with `kind == ScorerKind.DECORATOR`. The scorers module `__init__.py` exports `scorer`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py` ends at line 882 with blank lines, missing the `scorer` function; `/testbed/libs/skinny/mlflow/genai/scorers/base.py:847-882` provides full reference; `/testbed/tests/genai/scorers/test_scorer.py:8` imports `from mlflow.genai import Scorer, scorer`; `/testbed/mlflow/genai/scorers/__init__.py:91` lists `scorer` in `__all__` but line 3 does not import it.
- Uncertainty: None — the function is entirely missing from the main code path and must be implemented.

### R7: scorer decorator CustomScorer creation
- Type: Behavior
- Statement: The `scorer` decorator must create a `CustomScorer` subclass of `Scorer` that stores the original function in `_original_func`, delegates `__call__` to the original function, reports `kind == ScorerKind.DECORATOR`, and patches `__call__.__signature__` to include `self` as the first parameter matching the original function's signature.
- Task Evidence: The task refers to "decorator-based" scorer type and "Support multiple scorer types (builtin, decorator-based, class-based) with consistent interfaces" from task Main Features.
- Acceptance: `@scorer def f(inputs, outputs): return True` creates a `CustomScorer` where `f._original_func` is the original function, `f(inputs=x, outputs=y)` returns `True`, and `f.kind == ScorerKind.DECORATOR`.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:847-882` provides reference; `/testbed/tests/genai/scorers/test_scorer.py:52` uses `scorer(always_yes)`.
- Uncertainty: None.

### R8: scorer decorator serialization via model_dump
- Type: Dataflow
- Statement: `Scorer.model_dump()` must detect decorator scorers via `_original_func`, extract source code via `_extract_source_code_info()`, and produce a `SerializedScorer` dataclass dict containing `call_source`, `call_signature`, and `original_func_name`. The result must be cached in `_cached_dump`.
- Task Evidence: "Provide secure serialization that handles source code extraction and reconstruction" from task Key Challenges; "Enable scorer registration, lifecycle management" from task Main Features.
- Acceptance: Calling `scorer_instance.model_dump()` returns a dict with keys `name`, `description`, `aggregations`, `call_source`, `call_signature`, `original_func_name`, `mlflow_version`, `serialization_version`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:146-185` implements `model_dump` (calls `_extract_source_code_info`); `/testbed/mlflow/genai/scorers/base.py:187-199` implements `_extract_source_code_info` (calls `extract_function_body`); `/testbed/tests/genai/scorers/test_scorer_description.py:108-118` tests serialization.
- Uncertainty: None — `_extract_source_code_info` is present but depends on `extract_function_body` from `scorer_utils.py` which is missing.

### R9: scorer deserialization via model_validate
- Type: Behavior
- Statement: `Scorer.model_validate(obj)` must accept a `SerializedScorer` or dict, detect the scorer type from fields, and route to `BuiltInScorer.model_validate` for builtins, `_reconstruct_decorator_scorer` for decorator scorers, or `InstructionsJudge` reconstruction for instructions-judge scorers.
- Task Evidence: "Support multiple scorer types (builtin, decorator-based, class-based) with consistent interfaces" and "Handle dynamic function reconstruction from serialized source code" from task.
- Acceptance: Deserializing a decorator scorer dict with `call_source`, `call_signature`, `original_func_name` produces a working `CustomScorer` instance.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:203-288` implements `model_validate`; `/testbed/tests/genai/scorers/test_scorer_description.py:120-135` tests deserialization.
- Uncertainty: None.

### R10: scorer deserialization security restrictions
- Type: Failure
- Statement: `Scorer._reconstruct_decorator_scorer` must block deserialization outside Databricks runtime environments, raising `MlflowException` with informative error messages including the reconstructed code snippet. It must provide distinct messages for non-Databricks URIs and Databricks-remote-access scenarios.
- Task Evidence: "Secure code execution during scorer deserialization (restricted to controlled environments)" from task Key Challenges; "registration is only supported in Databricks environments due to security considerations around code execution during deserialization" from Interface Description 1.
- Acceptance: Calling `_reconstruct_decorator_scorer` with `is_in_databricks_runtime() == False` raises `MlflowException` matching "not supported outside of Databricks runtime environments". With `is_databricks_uri` True but not in runtime, raises matching "via remote access is not supported".
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:290-347` implements `_reconstruct_decorator_scorer` with security checks; `/testbed/tests/genai/scorers/test_scorer.py:377-434` tests security restrictions.
- Uncertainty: None.

### R11: scorer run method validation
- Type: Behavior
- Statement: `Scorer.run(*, inputs=None, outputs=None, expectations=None, trace=None)` must filter arguments based on the `__call__` signature, invoke the scorer, and validate the return type. Accepted return types are: `int`, `float`, `bool`, `str`, `Feedback`, `list[Feedback]`, or `None`. Other return types must raise `MlflowException`. When a `Feedback` is returned with the default name (`DEFAULT_FEEDBACK_NAME`), the name must be overwritten to the scorer's name.
- Task Evidence: "Support various return types (primitives, Feedback objects, lists) from scorer functions" from task Main Features; "The scorer function should return one of the following: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects" from Interface Description 1.
- Acceptance: Scorer returning `True` passes; returning a `dict` raises `MlflowException`; returning `Feedback(value=42)` gets name overwritten to scorer name.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:349-397` implements `run`; `/testbed/tests/genai/scorers/test_scorer.py:247-265` tests return types; `/testbed/tests/genai/scorers/test_scorer.py:304-332` tests name overwriting.
- Uncertainty: None.

### R12: scorer lifecycle management (register, start, update, stop)
- Type: State
- Statement: `Scorer` must support `register()`, `start()`, `update()`, and `stop()` methods that manage scorer registration and sampling configuration. `register()` must validate the scorer can be registered (builtin or decorator, Databricks URI for decorators), create a copy, and store it. `start()`/`update()`/`stop()` must be Databricks-only and delegate to `DatabricksStore`.
- Task Evidence: "Enable scorer registration, lifecycle management (start/stop/update), and sampling configuration" from task Main Features.
- Acceptance: `builtin_scorer.register(experiment_id=exp_id)` works in any environment; `@scorer` decorated scorer's `.register()` raises `MlflowException` outside Databricks; `.start()` raises outside Databricks.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:450-780` implements register/start/update/stop; `/testbed/tests/genai/scorers/test_scorer.py:350-375` tests registration blocking; `/testbed/tests/genai/scorers/test_scorer_CRUD.py` tests CRUD operations.
- Uncertainty: None.

### R13: extract_function_body utility
- Type: Behavior
- Statement: `extract_function_body(func: Callable) -> tuple[str, int]` must extract the body of a function as a dedented string (excluding signature and docstring) and return the indent unit. It must use AST parsing via `FunctionBodyExtractor` to robustly extract function bodies.
- Task Evidence: Required by `Scorer._extract_source_code_info()` for serialization; referenced in task as part of "secure serialization that handles source code extraction."
- Acceptance: `extract_function_body(lambda x: x + 1)` returns `("return x + 1", 4)` (or similar). Multi-line functions with docstrings have docstrings stripped.
- Repository Evidence: `/testbed/mlflow/genai/scorers/scorer_utils.py` has `FunctionBodyExtractor` class skeleton (lines 16-60) and `extract_function_body` stub (line 63); `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:15-75` provides full reference; called from `/testbed/mlflow/genai/scorers/base.py:194`.
- Uncertainty: None.

### R14: recreate_function utility
- Type: Behavior
- Statement: `recreate_function(source: str, signature: str, func_name: str) -> Callable` must reconstruct a callable function from its source code body, parameter signature string, and name. It must use `exec()` in a controlled namespace containing essential MLflow imports (`Feedback`, `Assessment`, `AssessmentSource`, `AssessmentSourceType`, `Trace`, `CategoricalRating`, `mlflow` module) and handle `from __future__ import annotations` for deferred type hint evaluation.
- Task Evidence: "Handle dynamic function reconstruction from serialized source code" from task Key Challenges; used by `Scorer._reconstruct_decorator_scorer`.
- Acceptance: `recreate_function("return x + y", "(x, y)", "add")` returns a callable where `add(3, 4) == 7`. Functions using MLflow types (e.g., `Feedback`) must work. Invalid signatures raise `MlflowException`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/scorer_utils.py` has `recreate_function` stub (line 77+); `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:77-143` provides full reference; `/testbed/tests/genai/scorers/test_scorer_utils.py` provides comprehensive tests.
- Uncertainty: None.

### R15: scorer function export chain
- Type: Interface
- Statement: The `scorer` function must be importable as `from mlflow.genai import scorer` and `from mlflow.genai.scorers import scorer`. This requires `scorer` to be exported from both `mlflow.genai.scorers.__init__` and `mlflow.genai.__init__`.
- Task Evidence: Interface Description 1 specifies Path `/testbed/mlflow/genai/scorers/base.py` with `def scorer(...)`; test code at `/testbed/tests/genai/scorers/test_scorer.py:8` imports `from mlflow.genai import Scorer, scorer`.
- Acceptance: `from mlflow.genai import scorer` succeeds and returns the scorer decorator function.
- Repository Evidence: `/testbed/mlflow/genai/__init__.py:50` lists `"scorer"` in `__all__` but line 43 only imports `Scorer` (not `scorer`); `/testbed/mlflow/genai/scorers/__init__.py:91` lists `"scorer"` in `__all__` but line 3 does not import `scorer` from base; reference at `/testbed/libs/skinny/mlflow/genai/__init__.py:43` imports `from mlflow.genai.scorers import Scorer, scorer` and `/testbed/libs/skinny/mlflow/genai/scorers/__init__.py:3` imports `from mlflow.genai.scorers.base import Scorer, ScorerSamplingConfig, scorer`.
- Uncertainty: None.

### R16: Case-insensitive assessment source validation
- Type: Behavior
- Statement: Assessment source type validation must be case-insensitive: any casing of valid type names (e.g., "human", "HUMAN", "Human", "llm_judge") must be accepted and normalized to uppercase.
- Task Evidence: "Case-insensitive string inputs (converts to uppercase)" from Interface Description 2.
- Acceptance: `AssessmentSourceType("human")`, `AssessmentSourceType("HUMAN")`, `AssessmentSourceType("Human")` all produce `str() == "HUMAN"`.
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py:139` calls `source_type.upper()`; `/testbed/mlflow/entities/assessment_source.py:77` calls `AssessmentSourceType._standardize(self.source_type)` in `__post_init__`.
- Uncertainty: None.

## L2. Functional Design Graph

### N1: AssessmentSourceType class
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:102-176`

### N2: AssessmentSourceType.__init__
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:102-138` (declared but empty template); `/testbed/libs/skinny/mlflow/entities/assessment_source.py:136-137`

### N3: AssessmentSourceType._parse
- Kind: Method (static)
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:139-176` (declared but empty); `/testbed/libs/skinny/mlflow/entities/assessment_source.py:139-146`

### N4: AssessmentSourceType.__str__
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:138` (declared but empty); `/testbed/libs/skinny/mlflow/entities/assessment_source.py:148-149`

### N5: AssessmentSourceType._standardize
- Kind: Method (static)
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:138` (declared but empty); `/testbed/libs/skinny/mlflow/entities/assessment_source.py:151-153`

### N6: AssessmentSource.__post_init__
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:76-77`

### N7: scorer function (decorator)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:847+` (missing); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:847-882`

### N8: CustomScorer (inner class)
- Kind: Class
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:866-878`

### N9: Scorer._extract_source_code_info
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:187-199`

### N10: extract_function_body
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/scorers/scorer_utils.py:63` (stub); `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:61-75`

### N11: FunctionBodyExtractor
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/scorer_utils.py:15-60` (skeleton); `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:14-55`

### N12: recreate_function
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/scorers/scorer_utils.py:77` (stub); `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:77-143`

### N13: Scorer.model_validate
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:203-288`

### N14: Scorer._reconstruct_decorator_scorer
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:290-347`

### N15: Scorer.model_dump
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:146-185`

### N16: Scorer.run
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:349-397`

### N17: mlflow.genai.scorers.__init__ (module export)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/scorers/__init__.py:1-97`

### N18: mlflow.genai.__init__ (module export)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/__init__.py:1-81`

### N19: MlflowException
- Kind: Error
- Repository Evidence: `/testbed/mlflow/exceptions.py`

### N20: FutureWarning (Python builtin)
- Kind: External
- Repository Evidence: Python standard library `warnings` module

### N21: SerializedScorer
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:63-91`

### N22: Scorer (base class)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:94-445`

### N23: AssessmentSource
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:11-98`

### N24: Test suite (observer)
- Kind: Observer
- Repository Evidence: `/testbed/tests/genai/scorers/test_scorer.py`, `/testbed/tests/genai/scorers/test_scorer_utils.py`, `/testbed/tests/genai/scorers/test_scorer_description.py`, `/testbed/tests/genai/scorers/test_scorer_CRUD.py`

### E1: N6 (AssessmentSource.__post_init__) -> N5 (AssessmentSourceType._standardize)
- Kind: CALL
- Condition: Always (during dataclass initialization)
- Transfer: raw `source_type` string -> standardized uppercase string
- Evidence: `/testbed/mlflow/entities/assessment_source.py:77` calls `AssessmentSourceType._standardize(self.source_type)`
- Obligations: R4, R5, R16

### E2: N5 (_standardize) -> N2 (__init__)
- Kind: CALL
- Condition: Always
- Transfer: input string -> AssessmentSourceType instance
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py:152-153` shows `_standardize` creates `AssessmentSourceType(source_type)` instance and returns `str()` of it
- Obligations: R1, R4

### E3: N2 (__init__) -> N3 (_parse)
- Kind: CALL
- Condition: Always
- Transfer: raw string -> validated uppercase string
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py:137` calls `self._source_type = AssessmentSourceType._parse(source_type)`
- Obligations: R1, R3, R16

### E4: N3 (_parse) -> N20 (warnings.warn)
- Kind: CONTROL
- Condition: `source_type == "AI_JUDGE"` (after uppercasing)
- Transfer: emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py:140-145`
- Obligations: R1, R3, R5

### E5: N3 (_parse) -> N19 (MlflowException)
- Kind: CONTROL
- Condition: `source_type not in _SOURCE_TYPES`
- Transfer: raises `MlflowException` with `INVALID_PARAMETER_VALUE` error code
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py:147-150`
- Obligations: R1, R3

### E6: N4 (__str__) -> N2 (__init__)
- Kind: DATA
- Condition: Always
- Transfer: returns `self._source_type` (stored during init)
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py:148-149`
- Obligations: R2

### E7: N7 (scorer function) -> N8 (CustomScorer)
- Kind: CALL
- Condition: `func is not None` (when used as decorator without arguments or with arguments via partial)
- Transfer: original function `func` -> `CustomScorer._original_func`; `func.__name__` -> `CustomScorer.name`; `func.__signature__` -> `CustomScorer.__call__.__signature__` (with `self` prepended)
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:860-882`
- Obligations: R6, R7

### E8: N7 (scorer function) -> functools.partial
- Kind: CONTROL
- Condition: `func is None` (parameterized decorator usage, e.g., `@scorer(name="x")`)
- Transfer: returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:860-863`
- Obligations: R6

### E9: N9 (_extract_source_code_info) -> N10 (extract_function_body)
- Kind: CALL
- Condition: Always
- Transfer: `self._original_func` -> function body string + indent unit
- Evidence: `/testbed/mlflow/genai/scorers/base.py:194` calls `extract_function_body(self._original_func)`
- Obligations: R8, R13

### E10: N10 (extract_function_body) -> N11 (FunctionBodyExtractor)
- Kind: CALL
- Condition: Always
- Transfer: function source -> AST-extracted body string
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:61-75`
- Obligations: R13

### E11: N15 (model_dump) -> N9 (_extract_source_code_info)
- Kind: CALL
- Condition: `getattr(self, "_original_func", None)` is truthy
- Transfer: extracted source info -> `SerializedScorer` dataclass -> `asdict()` -> cached dict
- Evidence: `/testbed/mlflow/genai/scorers/base.py:159-185`
- Obligations: R8

### E12: N14 (_reconstruct_decorator_scorer) -> N19 (MlflowException)
- Kind: CONTROL
- Condition: `not is_in_databricks_runtime()`
- Transfer: raises `MlflowException` with security error message including reconstructed code snippet
- Evidence: `/testbed/mlflow/genai/scorers/base.py:296-340`
- Obligations: R10

### E13: N14 (_reconstruct_decorator_scorer) -> N12 (recreate_function)
- Kind: CALL
- Condition: `is_in_databricks_runtime()` is True
- Transfer: `serialized.call_source`, `serialized.call_signature`, `serialized.original_func_name` -> recreated callable
- Evidence: `/testbed/mlflow/genai/scorers/base.py:342-344`
- Obligations: R9, R14

### E14: N14 (_reconstruct_decorator_scorer) -> N7 (scorer function)
- Kind: CALL
- Condition: After successful `recreate_function`
- Transfer: recreated function + serialized name/description/aggregations -> `scorer()` -> `CustomScorer` instance
- Evidence: `/testbed/mlflow/genai/scorers/base.py:349-354`
- Obligations: R6, R7, R9

### E15: N13 (model_validate) -> N14 (_reconstruct_decorator_scorer)
- Kind: CONTROL
- Condition: `serialized.call_source and serialized.call_signature and serialized.original_func_name` are all truthy
- Transfer: `SerializedScorer` -> `_reconstruct_decorator_scorer(serialized)` -> `CustomScorer`
- Evidence: `/testbed/mlflow/genai/scorers/base.py:248-249`
- Obligations: R9, R10

### E16: N17 (scorers __init__) -> N7 (scorer function)
- Kind: CALL (import)
- Condition: Always (module load)
- Transfer: `scorer` function imported from `mlflow.genai.scorers.base`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/__init__.py:3`; missing in `/testbed/mlflow/genai/scorers/__init__.py:3`
- Obligations: R15

### E17: N18 (genai __init__) -> N17 (scorers __init__)
- Kind: CALL (import)
- Condition: Always (module load)
- Transfer: `scorer` re-exported from `mlflow.genai.scorers`
- Evidence: `/testbed/libs/skinny/mlflow/genai/__init__.py:43`; missing in `/testbed/mlflow/genai/__init__.py:43`
- Obligations: R15

### E18: N16 (Scorer.run) -> N22 (Scorer.__call__)
- Kind: CALL
- Condition: Always (run filters args and delegates to __call__)
- Transfer: filtered `{inputs, outputs, expectations, trace}` -> result
- Evidence: `/testbed/mlflow/genai/scorers/base.py:378-381`
- Obligations: R11

### E19: N16 (Scorer.run) -> N19 (MlflowException)
- Kind: CONTROL
- Condition: result type not in `{int, float, bool, str, Assessment, Feedback, list[Assessment/Feedback], None}`
- Transfer: raises `MlflowException` with invalid return type message
- Evidence: `/testbed/mlflow/genai/scorers/base.py:382-396`
- Obligations: R11

### E20: N24 (test suite) -> N17 (scorers __init__)
- Kind: CALL (import)
- Condition: Always
- Transfer: `from mlflow.genai import Scorer, scorer` verifies public export chain
- Evidence: `/testbed/tests/genai/scorers/test_scorer.py:8`
- Obligations: R15

### E21: N24 (test suite) -> N12 (recreate_function)
- Kind: CALL
- Condition: Always in scorer_utils tests
- Transfer: source code strings -> recreated callables, exercised with various inputs
- Evidence: `/testbed/tests/genai/scorers/test_scorer_utils.py:5,15-30`
- Obligations: R14

### E22: N23 (AssessmentSource) -> N5 (_standardize)
- Kind: CALL
- Condition: Always during `__post_init__`
- Transfer: raw source_type -> standardized string
- Evidence: `/testbed/mlflow/entities/assessment_source.py:77`
- Obligations: R4, R5, R16

## L3. Verifiable Contracts

### C1: AssessmentSourceType constructor validates and stores
- Type: Behavior
- Subject: `AssessmentSourceType.__init__`
- Relation: EQ
- Expected: `AssessmentSourceType("human")._source_type == "HUMAN"`; `AssessmentSourceType("LLM_JUDGE")._source_type == "LLM_JUDGE"`
- Evidence: Interface Description 2 `__init__` specification; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:136-137`
- Observe: RETURN_VALUE (via `__str__` observation)
- Target: `str(AssessmentSourceType("human"))`
- Obligations: R1, R16
- Graph: N2, N3, E3

### C2: AssessmentSourceType rejects invalid types
- Type: Failure
- Subject: `AssessmentSourceType.__init__`
- Relation: RAISES
- Expected: `AssessmentSourceType("INVALID")` raises `MlflowException` with message containing "Invalid assessment source type"
- Evidence: Interface Description 2 `__init__` raises clause; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:147-150`
- Observe: EXCEPTION
- Target: `AssessmentSourceType("INVALID")`
- Obligations: R1, R3
- Graph: N2, N3, N19, E5

### C3: AssessmentSourceType AI_JUDGE deprecation warning
- Type: SideEffect
- Subject: `AssessmentSourceType.__init__` / `_parse`
- Relation: EQ (warning emitted) + EQ (value converted)
- Expected: `AssessmentSourceType("AI_JUDGE")` emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"`
- Evidence: Interface Description 2 `_parse` warns clause; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:140-145`
- Observe: SIDE_EFFECT (warnings.warn) + RETURN_VALUE (via __str__)
- Target: `pytest.warns(FutureWarning)` context manager
- Obligations: R1, R3, R5
- Graph: N2, N3, N20, E4

### C4: AssessmentSourceType case insensitivity
- Type: Behavior
- Subject: `AssessmentSourceType._parse`
- Relation: EQ
- Expected: `AssessmentSourceType._parse("human") == "HUMAN"`, `AssessmentSourceType._parse("Human") == "HUMAN"`, `AssessmentSourceType._parse("HUMAN") == "HUMAN"`
- Evidence: Interface Description 2 "case-insensitive string inputs"; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:139`
- Observe: RETURN_VALUE
- Target: `AssessmentSourceType._parse("human")`
- Obligations: R1, R16
- Graph: N3, E3

### C5: AssessmentSourceType._standardize creates and converts
- Type: Behavior
- Subject: `AssessmentSourceType._standardize`
- Relation: EQ
- Expected: `AssessmentSourceType._standardize("human") == "HUMAN"`; `AssessmentSourceType._standardize("AI_JUDGE") == "LLM_JUDGE"` (with warning)
- Evidence: Interface Description 2 `_standardize` specification; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:151-153`
- Observe: RETURN_VALUE
- Target: `AssessmentSourceType._standardize("human")`
- Obligations: R4, R5
- Graph: N5, N2, E2

### C6: AssessmentSourceType.__str__ returns stored value
- Type: Interface
- Subject: `AssessmentSourceType.__str__`
- Relation: EQ
- Expected: `str(AssessmentSourceType("HUMAN")) == "HUMAN"`; `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"`
- Evidence: Interface Description 2 `__str__` specification; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:148-149`
- Observe: RETURN_VALUE
- Target: `str(AssessmentSourceType("HUMAN"))`
- Obligations: R2
- Graph: N4, E6

### C7: AssessmentSource.__post_init__ normalizes source_type
- Type: Dataflow
- Subject: `AssessmentSource.__post_init__`
- Relation: EQ
- Expected: `AssessmentSource(source_type="human", source_id="x").source_type == "HUMAN"`; `AssessmentSource(source_type="AI_JUDGE", source_id="x").source_type == "LLM_JUDGE"` (with warning)
- Evidence: `/testbed/mlflow/entities/assessment_source.py:76-77`; test usage at `/testbed/tests/genai/judges/optimizers/conftest.py:120`
- Observe: FIELD_READ (`source.source_type`)
- Target: `AssessmentSource(source_type="human", source_id="x").source_type`
- Obligations: R4, R5, R16
- Graph: N6, N5, N23, E1, E22

### C8: scorer decorator creates CustomScorer with correct kind
- Type: Interface
- Subject: `scorer(func)`
- Relation: EQ
- Expected: `s = scorer(lambda inputs, outputs: True); s.kind == ScorerKind.DECORATOR`
- Evidence: Interface Description 1; `/testbed/libs/skinny/mlflow/genai/scorers/base.py:876-877`
- Observe: FIELD_READ (`s.kind`)
- Target: `scorer(some_func).kind`
- Obligations: R6, R7
- Graph: N7, N8, E7

### C9: scorer decorator preserves function behavior
- Type: Behavior
- Subject: `scorer(func)`
- Relation: EQ
- Expected: `s = scorer(lambda inputs, outputs: inputs == outputs); s(inputs="a", outputs="a") == True; s(inputs="a", outputs="b") == False`
- Evidence: Interface Description 1 example `not_empty` and `exact_match`; `/testbed/libs/skinny/mlflow/genai/scorers/base.py:872-873`
- Observe: RETURN_VALUE
- Target: `scorer(func)(inputs=x, outputs=y)`
- Obligations: R6, R7
- Graph: N7, N8, E7

### C10: scorer parameterized decorator returns partial
- Type: Interface
- Subject: `scorer(func=None, name="custom_name")`
- Relation: TYPE_IS
- Expected: `scorer(name="custom_name")` returns a `functools.partial` object callable as a decorator
- Evidence: Interface Description 1 "If not provided, uses the function's name"; `/testbed/libs/skinny/mlflow/genai/scorers/base.py:860-863`
- Observe: RETURN_VALUE
- Target: `type(scorer(name="x"))` is `functools.partial`
- Obligations: R6
- Graph: N7, E8

### C11: Scorer.model_dump produces SerializedScorer fields
- Type: Dataflow
- Subject: `Scorer.model_dump()` on decorator scorer
- Relation: CONTAINS
- Expected: Returned dict contains keys: `name`, `description`, `aggregations`, `call_source`, `call_signature`, `original_func_name`, `mlflow_version`, `serialization_version`
- Evidence: `/testbed/mlflow/genai/scorers/base.py:171-184`; `/testbed/tests/genai/scorers/test_scorer_description.py:108-118`
- Observe: RETURN_VALUE
- Target: `scorer_instance.model_dump().keys()`
- Obligations: R8
- Graph: N15, N9, N10, N21, E9, E11

### C12: Scorer.model_validate reconstructs decorator scorer
- Type: Behavior
- Subject: `Scorer.model_validate(serialized_dict)`
- Relation: EQ
- Expected: A scorer serialized via `model_dump()` and deserialized via `model_validate()` behaves identically to the original scorer
- Evidence: `/testbed/mlflow/genai/scorers/base.py:248-249`; `/testbed/tests/genai/scorers/test_scorer_description.py:120-135`
- Observe: RETURN_VALUE
- Target: `Scorer.model_validate(dump_dict)(inputs=x, outputs=y)`
- Obligations: R9, R14
- Graph: N13, N14, N12, N7, E13, E14, E15

### C13: Scorer._reconstruct_decorator_scorer blocks non-Databricks
- Type: Failure
- Subject: `Scorer._reconstruct_decorator_scorer`
- Relation: RAISES
- Expected: With `is_in_databricks_runtime() == False` and `is_databricks_uri() == False`, raises `MlflowException` matching "not supported outside of Databricks runtime environments"
- Evidence: `/testbed/mlflow/genai/scorers/base.py:296-340`; `/testbed/tests/genai/scorers/test_scorer.py:377-389`
- Observe: EXCEPTION
- Target: `Scorer._reconstruct_decorator_scorer(serialized)`
- Obligations: R10
- Graph: N14, N19, E12

### C14: Scorer._reconstruct_decorator_scorer blocks Databricks remote
- Type: Failure
- Subject: `Scorer._reconstruct_decorator_scorer`
- Relation: RAISES
- Expected: With `is_in_databricks_runtime() == False` and `is_databricks_uri() == True`, raises `MlflowException` matching "via remote access is not supported"
- Evidence: `/testbed/mlflow/genai/scorers/base.py:296-340`; `/testbed/tests/genai/scorers/test_scorer.py:391-403`
- Observe: EXCEPTION
- Target: `Scorer._reconstruct_decorator_scorer(serialized)`
- Obligations: R10
- Graph: N14, N19, E12

### C15: Scorer.run validates return types
- Type: Failure
- Subject: `Scorer.run`
- Relation: RAISES
- Expected: A scorer returning a `dict` raises `MlflowException` matching "must return one of int, float, bool, str, Feedback, or list[Feedback]"
- Evidence: `/testbed/mlflow/genai/scorers/base.py:382-396`; `/testbed/tests/genai/scorers/test_scorer.py:247-265`
- Observe: EXCEPTION
- Target: `scorer_instance.run(inputs=x, outputs=y)`
- Obligations: R11
- Graph: N16, N19, E18, E19

### C16: Scorer.run allows None return
- Type: Behavior
- Subject: `Scorer.run`
- Relation: EQ
- Expected: A scorer that returns `None` does not raise and returns `None`
- Evidence: `/testbed/mlflow/genai/scorers/base.py:389` allows `result is None`; `/testbed/tests/genai/scorers/test_scorer.py:268-273`
- Observe: RETURN_VALUE
- Target: `none_returning_scorer.run(inputs=x)`
- Obligations: R11
- Graph: N16, E18

### C17: Scorer.run overwrites default Feedback name
- Type: Dataflow
- Subject: `Scorer.run` when scorer returns `Feedback` with default name
- Relation: EQ
- Expected: If scorer returns `Feedback(value=42)` (default name "feedback"), the returned Feedback's name is changed to the scorer's name
- Evidence: `/testbed/mlflow/genai/scorers/base.py:398-413`; `/testbed/tests/genai/scorers/test_scorer.py:304-315`
- Observe: FIELD_READ (`result.name`)
- Target: `scorer_instance.run(inputs=x, outputs=y).name`
- Obligations: R11
- Graph: N16, E18

### C18: extract_function_body extracts body without signature
- Type: Behavior
- Subject: `extract_function_body`
- Relation: CONTAINS (body content) + NE (excludes signature)
- Expected: `extract_function_body(func)` returns `(body_str, indent_int)` where `body_str` does not contain `def` or docstring, and `indent_int` is a positive integer
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:61-75`; called from `_extract_source_code_info`
- Observe: RETURN_VALUE
- Target: `extract_function_body(some_function)`
- Obligations: R13
- Graph: N10, N11, E10

### C19: recreate_function produces callable with correct behavior
- Type: Behavior
- Subject: `recreate_function`
- Relation: EQ
- Expected: `f = recreate_function("return x + y", "(x, y)", "add"); f(3, 4) == 7; f.__name__ == "add"`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:77-143`; `/testbed/tests/genai/scorers/test_scorer_utils.py:13-26`
- Observe: RETURN_VALUE
- Target: `recreate_function(source, sig, name)(*args)`
- Obligations: R14
- Graph: N12, E13, E21

### C20: recreate_function provides MLflow imports namespace
- Type: Behavior
- Subject: `recreate_function`
- Relation: PRESERVE
- Expected: Recreated functions can use `Feedback`, `Assessment`, `AssessmentSource`, `AssessmentSourceType`, `Trace`, `CategoricalRating`, and `mlflow` module without explicit imports
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:106-133`; `/testbed/tests/genai/scorers/test_scorer_utils.py:89-140, 286-320`
- Observe: RETURN_VALUE (no NameError when using MLflow types)
- Target: `recreate_function(source_using_feedback, sig, name)(*args)`
- Obligations: R14
- Graph: N12

### C21: recreate_function raises MlflowException on invalid signature
- Type: Failure
- Subject: `recreate_function`
- Relation: RAISES
- Expected: `recreate_function("return 1", "invalid", "f")` raises `MlflowException` matching "Invalid signature format"
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py:88-91`; `/testbed/tests/genai/scorers/test_scorer_utils.py:236-244`
- Observe: EXCEPTION
- Target: `recreate_function("return 1", "invalid", "f")`
- Obligations: R14
- Graph: N12, N19

### C22: scorer importable from mlflow.genai
- Type: Interface
- Subject: `mlflow.genai.scorer` public export
- Relation: TYPE_IS
- Expected: `from mlflow.genai import scorer` succeeds and `scorer` is a callable function (not a class)
- Evidence: `/testbed/tests/genai/scorers/test_scorer.py:8` imports `from mlflow.genai import Scorer, scorer`; `/testbed/libs/skinny/mlflow/genai/__init__.py:43`
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.genai import scorer`
- Obligations: R15
- Graph: N7, N17, N18, E16, E17, E20

### C23: AssessmentSourceType constants are accessible directly
- Type: Interface
- Subject: `AssessmentSourceType` class attributes
- Relation: EQ
- Expected: `AssessmentSourceType.HUMAN == "HUMAN"`, `AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"`, `AssessmentSourceType.CODE == "CODE"`, `AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"`
- Evidence: `/testbed/mlflow/entities/assessment_source.py:132-136`; `/testbed/tests/genai/scorers/test_scorer.py:282`
- Observe: FIELD_READ
- Target: `AssessmentSourceType.HUMAN`
- Obligations: R1, R2
- Graph: N1

### C24: recreate_function handles syntax errors gracefully
- Type: Failure
- Subject: `recreate_function`
- Relation: RAISES
- Expected: `recreate_function("if x > 0\n    return True", "(x)", "bad")` raises `SyntaxError` (missing colon)
- Evidence: `/testbed/tests/genai/scorers/test_scorer_utils.py:256-262`
- Observe: EXCEPTION
- Target: `recreate_function(malformed_source, sig, name)`
- Obligations: R14
- Graph: N12

### C25: Scorer.register blocks non-Databricks for decorator scorers
- Type: Failure
- Subject: `Scorer.register`
- Relation: RAISES
- Expected: A decorator scorer's `.register()` raises `MlflowException` matching "Custom scorer registration.*not supported outside of Databricks tracking" when tracking URI is not Databricks
- Evidence: `/testbed/mlflow/genai/scorers/base.py:498-510`; `/testbed/tests/genai/scorers/test_scorer.py:350-375`
- Observe: EXCEPTION
- Target: `custom_scorer.register(experiment_id=exp_id)`
- Obligations: R12
- Graph: N22, N19

### C26: Scorer.start requires Databricks URI
- Type: Failure
- Subject: `Scorer.start`
- Relation: RAISES
- Expected: Calling `.start()` outside Databricks raises `MlflowException` matching "Scheduling scorers is only supported by Databricks tracking URI"
- Evidence: `/testbed/mlflow/genai/scorers/base.py:602-605`
- Observe: EXCEPTION
- Target: `scorer_instance.start(sampling_config=...)`
- Obligations: R12
- Graph: N22, N19

### E23: N22 (Scorer.register) -> N22._check_can_be_registered
- Kind: CALL
- Condition: Always during register()
- Transfer: validates scorer kind and tracking URI
- Evidence: `/testbed/mlflow/genai/scorers/base.py:483`
- Obligations: R12

### E24: N22 (Scorer.start) -> N22._check_can_be_registered
- Kind: CALL
- Condition: Always during start()
- Transfer: validates scorer can be registered; checks Databricks URI
- Evidence: `/testbed/mlflow/genai/scorers/base.py:597-605`
- Obligations: R12
