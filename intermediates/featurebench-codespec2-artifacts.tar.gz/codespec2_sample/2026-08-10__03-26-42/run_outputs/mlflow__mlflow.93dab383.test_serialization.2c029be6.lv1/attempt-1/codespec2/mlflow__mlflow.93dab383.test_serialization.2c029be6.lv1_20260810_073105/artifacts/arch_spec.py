"""
Executable architecture spec for Assessment Source Management and Custom Scorer Framework.

Proves L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts through
live imports and runtime trace observations.

Each check_* function verifies connectivity from public entry to observer.
"""

import sys
import unittest.mock as mock

# Ensure /testbed is on the path
sys.path.insert(0, "/testbed")


# ============================================================================
# Contracts: C23 — AssessmentSourceType constants are accessible directly
# Graph: N1
# ============================================================================
def check_assessment_source_type_constants_accessible() -> None:
    """C23: AssessmentSourceType.HUMAN, .LLM_JUDGE, .CODE, .SOURCE_TYPE_UNSPECIFIED exist."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType.HUMAN == "HUMAN", (
        f"Expected 'HUMAN', got {AssessmentSourceType.HUMAN!r}"
    )
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE", (
        f"Expected 'LLM_JUDGE', got {AssessmentSourceType.LLM_JUDGE!r}"
    )
    assert AssessmentSourceType.CODE == "CODE", (
        f"Expected 'CODE', got {AssessmentSourceType.CODE!r}"
    )
    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED", (
        f"Expected 'SOURCE_TYPE_UNSPECIFIED', got {AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED!r}"
    )
    # _SOURCE_TYPES list should contain all valid types
    assert "HUMAN" in AssessmentSourceType._SOURCE_TYPES
    assert "LLM_JUDGE" in AssessmentSourceType._SOURCE_TYPES
    assert "CODE" in AssessmentSourceType._SOURCE_TYPES
    assert "SOURCE_TYPE_UNSPECIFIED" in AssessmentSourceType._SOURCE_TYPES
    print("PASS: C23 — AssessmentSourceType constants accessible")


# ============================================================================
# Contracts: C7 — AssessmentSource.__post_init__ normalizes source_type via E1/E22
# Graph: N6, N5, N23, E1, E22
# ============================================================================
def check_assessment_source_post_init_calls_standardize() -> None:
    """C7: AssessmentSource.__post_init__ delegates to AssessmentSourceType._standardize."""
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    # Verify _standardize exists and is callable
    assert hasattr(AssessmentSourceType, "_standardize"), (
        "AssessmentSourceType._standardize must exist"
    )
    assert callable(AssessmentSourceType._standardize), (
        "AssessmentSourceType._standardize must be callable"
    )

    # Spy on _standardize to verify it's called during __post_init__
    with mock.patch.object(
        AssessmentSourceType, "_standardize", wraps=AssessmentSourceType._standardize
    ) as spy:
        src = AssessmentSource(source_type="HUMAN", source_id="test_user")
        spy.assert_called_once_with("HUMAN")
        assert src.source_type == "HUMAN", (
            f"Expected 'HUMAN', got {src.source_type!r}"
        )

    # Test with lowercase input
    with mock.patch.object(
        AssessmentSourceType, "_standardize", wraps=AssessmentSourceType._standardize
    ) as spy:
        src = AssessmentSource(source_type="llm_judge", source_id="gpt-4")
        spy.assert_called_once_with("llm_judge")
        assert src.source_type == "LLM_JUDGE", (
            f"Expected 'LLM_JUDGE', got {src.source_type!r}"
        )

    print("PASS: C7 — AssessmentSource.__post_init__ calls _standardize (E1, E22)")


# ============================================================================
# Contracts: C22 — scorer importable from mlflow.genai
# Graph: N7, N17, N18, E16, E17, E20
# ============================================================================
def check_scorer_import_chain() -> None:
    """C22: scorer is importable from mlflow.genai and mlflow.genai.scorers."""
    # Check mlflow.genai.scorers export
    from mlflow.genai.scorers import __all__ as scorers_all
    assert "scorer" in scorers_all, (
        f"'scorer' must be in mlflow.genai.scorers.__all__, got {scorers_all}"
    )

    # Check mlflow.genai export
    from mlflow.genai import __all__ as genai_all
    assert "scorer" in genai_all, (
        f"'scorer' must be in mlflow.genai.__all__, got {genai_all}"
    )

    # Check actual importability
    from mlflow.genai.scorers import scorer as scorer_from_scorers
    assert callable(scorer_from_scorers), (
        f"scorer from mlflow.genai.scorers must be callable, got {type(scorer_from_scorers)}"
    )

    from mlflow.genai import scorer as scorer_from_genai
    assert callable(scorer_from_genai), (
        f"scorer from mlflow.genai must be callable, got {type(scorer_from_genai)}"
    )

    # Both imports should refer to the same object
    assert scorer_from_scorers is scorer_from_genai, (
        "scorer from mlflow.genai.scorers and mlflow.genai must be the same object"
    )

    print("PASS: C22 — scorer importable from mlflow.genai (E16, E17, E20)")


# ============================================================================
# Contracts: C8 — scorer decorator creates CustomScorer with correct kind
# Graph: N7, N8, E7
# ============================================================================
def check_scorer_decorator_creates_custom_scorer() -> None:
    """C8: scorer(func) returns CustomScorer with kind=DECORATOR."""
    from mlflow.genai.scorers import scorer
    from mlflow.genai.scorers.base import ScorerKind

    # Define a simple scorer function
    def my_scorer(outputs) -> bool:
        return bool(outputs)

    s = scorer(my_scorer)

    # Must be a Scorer instance
    from mlflow.genai.scorers.base import Scorer
    assert isinstance(s, Scorer), f"Expected Scorer instance, got {type(s)}"

    # Must have kind DECORATOR
    assert s.kind == ScorerKind.DECORATOR, (
        f"Expected ScorerKind.DECORATOR, got {s.kind}"
    )

    # Must have the correct name
    assert s.name == "my_scorer", f"Expected 'my_scorer', got {s.name!r}"

    print("PASS: C8 — scorer decorator creates CustomScorer with DECORATOR kind (E7)")


# ============================================================================
# Contracts: C10 — scorer parameterized decorator returns partial
# Graph: N7, E8
# ============================================================================
def check_scorer_parameterized_returns_partial() -> None:
    """C10: scorer(name='x') returns functools.partial for parameterized usage."""
    import functools
    from mlflow.genai.scorers import scorer

    # When called without func (parameterized), returns a partial
    partial_result = scorer(name="custom_name", description="desc")

    assert isinstance(partial_result, functools.partial), (
        f"Expected functools.partial, got {type(partial_result)}"
    )

    # The partial should be callable as a decorator
    def test_func(inputs):
        return True

    decorated = partial_result(test_func)
    assert decorated.name == "custom_name", (
        f"Expected 'custom_name', got {decorated.name!r}"
    )
    assert decorated.description == "desc", (
        f"Expected 'desc', got {decorated.description!r}"
    )

    print("PASS: C10 — scorer parameterized decorator returns functools.partial (E8)")


# ============================================================================
# Contracts: C11 — Scorer.model_dump produces SerializedScorer fields
# Graph: N15, N9, N10, N21, E9, E11
# ============================================================================
def check_model_dump_produces_serialized_fields() -> None:
    """C11: model_dump() on decorator scorer includes source fields."""
    from mlflow.genai.scorers import scorer

    def my_func(inputs, outputs) -> bool:
        return inputs == outputs

    s = scorer(my_func)
    dump = s.model_dump()

    # Must contain core fields
    assert "name" in dump, f"Missing 'name' in dump: {list(dump.keys())}"
    assert dump["name"] == "my_func"

    # Must contain serialization metadata
    assert "mlflow_version" in dump, f"Missing 'mlflow_version' in dump"
    assert "serialization_version" in dump, f"Missing 'serialization_version' in dump"

    # Must contain decorator scorer fields (source code)
    assert "call_source" in dump, f"Missing 'call_source' in dump"
    assert dump["call_source"] is not None, "call_source must not be None"
    assert "return inputs == outputs" in dump["call_source"], (
        f"call_source should contain function body, got: {dump['call_source']!r}"
    )

    assert "call_signature" in dump, f"Missing 'call_signature' in dump"
    assert dump["call_signature"] is not None, "call_signature must not be None"

    assert "original_func_name" in dump, f"Missing 'original_func_name' in dump"
    assert dump["original_func_name"] == "my_func"

    print("PASS: C11 — model_dump produces SerializedScorer fields (E9, E11)")


# ============================================================================
# Contracts: C14 — Scorer.run calls __call__ with filtered args
# Graph: N16, N22, E18
# ============================================================================
def check_scorer_run_filters_and_calls() -> None:
    """C14: Scorer.run filters kwargs and delegates to __call__."""
    from mlflow.genai.scorers import scorer

    # Define a scorer that only accepts 'outputs'
    def length_check(outputs) -> int:
        return len(str(outputs))

    s = scorer(length_check)

    # Spy on __call__ to verify argument filtering
    with mock.patch.object(s, "__call__", wraps=s.__call__) as spy:
        result = s.run(inputs="hello", outputs="world", expectations={"x": 1}, trace=None)
        # Should only pass 'outputs' since the function only accepts 'outputs'
        spy.assert_called_once()
        call_kwargs = spy.call_args.kwargs
        assert "outputs" in call_kwargs, "outputs should be passed"
        assert call_kwargs["outputs"] == "world"
        # inputs, expectations, trace not in the function signature => not passed
        assert result == 5  # len("world") == 5

    print("PASS: C14 — Scorer.run filters args and delegates to __call__ (E18)")


# ============================================================================
# Contracts: C17 — Scorer.run overwrites default Feedback name
# Graph: N16, E18
# ============================================================================
def check_scorer_run_overwrites_feedback_name() -> None:
    """C17: Scorer.run changes default Feedback.name to scorer name."""
    from mlflow.entities import Feedback
    from mlflow.genai.scorers import scorer

    def fb_scorer(outputs) -> Feedback:
        return Feedback(value=True)

    s = scorer(fb_scorer)
    result = s.run(outputs="test")
    assert isinstance(result, Feedback), f"Expected Feedback, got {type(result)}"
    assert result.name == "fb_scorer", (
        f"Expected Feedback.name='fb_scorer', got {result.name!r}"
    )

    print("PASS: C17 — Scorer.run overwrites default Feedback name (E18)")


# ============================================================================
# Contracts: E23/E24 — register/start call _check_can_be_registered
# Graph: N22, E23, E24
# ============================================================================
def check_register_and_start_call_check_can_be_registered() -> None:
    """E23/E24: Scorer.register() and Scorer.start() call _check_can_be_registered."""
    from mlflow.genai.scorers.base import Scorer

    # We can verify that the methods exist and that _check_can_be_registered exists
    assert hasattr(Scorer, "_check_can_be_registered"), (
        "Scorer._check_can_be_registered must exist"
    )
    assert callable(Scorer._check_can_be_registered), (
        "Scorer._check_can_be_registered must be callable"
    )

    # Verify register and start methods exist
    assert hasattr(Scorer, "register"), "Scorer.register must exist"
    assert callable(Scorer.register), "Scorer.register must be callable"
    assert hasattr(Scorer, "start"), "Scorer.start must exist"
    assert callable(Scorer.start), "Scorer.start must be callable"

    # Use a mock to verify the call chain without actually registering
    # Create a minimal concrete scorer
    from mlflow.genai.scorers import scorer

    def simple(outputs) -> bool:
        return bool(outputs)

    s = scorer(simple)

    # Verify _check_can_be_registered is called during register (it will fail
    # due to non-Databricks URI, but we can still check the spy)
    with mock.patch.object(s, "_check_can_be_registered") as spy:
        try:
            s.register()
        except Exception:
            pass  # Expected - will raise due to non-Databricks URI
        spy.assert_called_once()

    print("PASS: E23/E24 — register/start call _check_can_be_registered")


# ============================================================================
# Top-level runner
# ============================================================================
if __name__ == "__main__":
    all_checks = [
        ("C23", check_assessment_source_type_constants_accessible),
        ("C7", check_assessment_source_post_init_calls_standardize),
        ("C22", check_scorer_import_chain),
        ("C8", check_scorer_decorator_creates_custom_scorer),
        ("C10", check_scorer_parameterized_returns_partial),
        ("C11", check_model_dump_produces_serialized_fields),
        ("C14", check_scorer_run_filters_and_calls),
        ("C17", check_scorer_run_overwrites_feedback_name),
        ("E23/E24", check_register_and_start_call_check_can_be_registered),
    ]

    failed = []
    for contract_id, check_fn in all_checks:
        try:
            check_fn()
        except Exception as e:
            failed.append((contract_id, e))
            print(f"FAIL: {contract_id} — {type(e).__name__}: {e}")

    if failed:
        print(f"\n{len(failed)} architecture check(s) FAILED:")
        for cid, err in failed:
            print(f"  {cid}: {err}")
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} architecture checks PASSED")
