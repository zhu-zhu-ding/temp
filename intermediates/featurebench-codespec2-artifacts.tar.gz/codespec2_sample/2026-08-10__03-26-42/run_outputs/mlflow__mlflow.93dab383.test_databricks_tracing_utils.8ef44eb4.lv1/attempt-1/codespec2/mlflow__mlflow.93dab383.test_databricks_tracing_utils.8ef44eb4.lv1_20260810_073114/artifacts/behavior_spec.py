"""
Behavior specification: return-value, state, failure, side-effect, defaults,
boundaries, and compatibility proofs.

Covers L3 State, Behavior, Failure, SideEffect contracts.
Each check_* function asserts a concrete observable outcome.
"""

import warnings
import pytest


# ── Helpers ──────────────────────────────────────────────────────────

def _make_span_dict(name="test_span", attributes=None, start_time_ns=1761106494524157000,
                    end_time_ns=1761106494584860000):
    """Create a span dict suitable for Span.from_dict() / Trace.from_dict().

    Uses the same format as the native test_trace.py fixture.
    """
    import base64

    trace_id_bytes = b'\xee\x17\x18Ff\x9c%_\xdc\xfd\xf9)6\xf6\xdc\xcc'
    span_id_bytes = b'\xdcIf\x1cD}!U'

    attr_dict = {
        "mlflow.traceRequestId": '"tr-ee17184669c265ffdcf9299b36f6dccc"',
        "mlflow.spanType": '"UNKNOWN"',
        "test": '"test"',
    }
    if attributes:
        attr_dict.update(attributes)

    return {
        "trace_id": base64.b64encode(trace_id_bytes).decode(),
        "span_id": base64.b64encode(span_id_bytes).decode(),
        "trace_state": "",
        "parent_span_id": "",
        "name": name,
        "start_time_unix_nano": start_time_ns,
        "end_time_unix_nano": end_time_ns,
        "attributes": attr_dict,
        "status": {"message": "", "code": "STATUS_CODE_OK"},
    }


def _make_span_with_inputs(input_value):
    """Create a Span with mlflow.spanInputs attribute set via from_dict."""
    from mlflow.entities.span import Span
    import json

    span_dict = _make_span_dict(attributes={
        "mlflow.spanInputs": json.dumps(input_value),
    })
    return Span.from_dict(span_dict)


def _make_span_with_outputs(output_value):
    """Create a Span with mlflow.spanOutputs attribute set via from_dict."""
    from mlflow.entities.span import Span
    import json

    span_dict = _make_span_dict(attributes={
        "mlflow.spanOutputs": json.dumps(output_value),
    })
    return Span.from_dict(span_dict)


def _make_span_without_io():
    """Create a Span without inputs/outputs attributes."""
    from mlflow.entities.span import Span

    span_dict = _make_span_dict()  # no extra attributes
    return Span.from_dict(span_dict)


# ── C7: get_trace_id_from_assessment_proto UC Schema path ────────────
# Contracts: C7
# Reference: /testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:192-200
def check_get_trace_id_uc_schema_path() -> None:
    """C7: When proto has trace_location.uc_schema, returns v4 trace ID."""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.tracing.utils import construct_trace_id_v4

    proto = pb.Assessment()
    proto.trace_id = "inner-trace-abc"
    proto.trace_location.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto.trace_location.uc_schema.catalog_name = "cat_x"
    proto.trace_location.uc_schema.schema_name = "schema_y"

    result = get_trace_id_from_assessment_proto(proto)

    expected = construct_trace_id_v4("cat_x.schema_y", "inner-trace-abc")
    assert result == expected, f"Expected {expected!r}, got {result!r}"


# ── C8: get_trace_id_from_assessment_proto fallback ──────────────────
# Contracts: C8
# Reference: /testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:201-203
def check_get_trace_id_fallback() -> None:
    """C8: When no uc_schema, returns proto.trace_id unchanged."""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    # Proto without trace_location
    proto = pb.Assessment()
    proto.trace_id = "plain-trace-id"
    result = get_trace_id_from_assessment_proto(proto)
    assert result == "plain-trace-id", f"Expected 'plain-trace-id', got {result!r}"

    # Proto with trace_location but no uc_schema (using experiment location)
    proto2 = pb.Assessment()
    proto2.trace_id = "exp-trace-id"
    proto2.trace_location.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto2.trace_location.mlflow_experiment.experiment_id = "exp_1"
    result2 = get_trace_id_from_assessment_proto(proto2)
    assert result2 == "exp-trace-id", f"Expected 'exp-trace-id', got {result2!r}"


# ── C14: trace_location_from_proto UC Schema dispatch ────────────────
# Contracts: C14
def check_trace_location_from_proto_uc_schema() -> None:
    """C14: WhichOneof('identifier') == 'uc_schema' → UC_SCHEMA TraceLocation."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto.uc_schema.catalog_name = "cat_a"
    proto.uc_schema.schema_name = "schema_b"

    result = trace_location_from_proto(proto)
    assert result.type == TraceLocationType.UC_SCHEMA, (
        f"Expected UC_SCHEMA, got {result.type}"
    )
    assert result.uc_schema is not None
    assert result.uc_schema.catalog_name == "cat_a"
    assert result.uc_schema.schema_name == "schema_b"


# ── C15: trace_location_from_proto MLflow Experiment dispatch ────────
# Contracts: C15
def check_trace_location_from_proto_mlflow_experiment() -> None:
    """C15: WhichOneof('identifier') == 'mlflow_experiment' → delegate."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto.mlflow_experiment.experiment_id = "exp_999"

    result = trace_location_from_proto(proto)
    assert result.type == TraceLocationType.MLFLOW_EXPERIMENT, (
        f"Expected MLFLOW_EXPERIMENT, got {result.type}"
    )
    assert result.mlflow_experiment is not None
    assert result.mlflow_experiment.experiment_id == "exp_999"


# ── C16: trace_location_from_proto Inference Table dispatch ──────────
# Contracts: C16
def check_trace_location_from_proto_inference_table() -> None:
    """C16: WhichOneof('identifier') == 'inference_table' → delegate."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    proto.inference_table.full_table_name = "cat.schema.inf_table"

    result = trace_location_from_proto(proto)
    assert result.type == TraceLocationType.INFERENCE_TABLE, (
        f"Expected INFERENCE_TABLE, got {result.type}"
    )
    assert result.inference_table is not None
    assert result.inference_table.full_table_name == "cat.schema.inf_table"


# ── C17: trace_location_from_proto fallback ──────────────────────────
# Contracts: C17
def check_trace_location_from_proto_fallback() -> None:
    """C17: No recognized identifier → TRACE_LOCATION_TYPE_UNSPECIFIED."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED
    # No identifier set at all

    result = trace_location_from_proto(proto)
    assert result.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED, (
        f"Expected TRACE_LOCATION_TYPE_UNSPECIFIED, got {result.type}"
    )


# ── C18: trace_location_to_proto dispatch ────────────────────────────
# Contracts: C18
def check_trace_location_to_proto_uc_schema() -> None:
    """C18a: UC_SCHEMA → proto with uc_schema set."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation, TraceLocationType, UCSchemaLocation,
    )

    location = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="c1", schema_name="s1"),
    )
    result = trace_location_to_proto(location)
    assert result.HasField("uc_schema")
    assert result.uc_schema.catalog_name == "c1"
    assert result.uc_schema.schema_name == "s1"


def check_trace_location_to_proto_mlflow_experiment() -> None:
    """C18b: MLFLOW_EXPERIMENT → proto with mlflow_experiment set."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation, TraceLocationType, MlflowExperimentLocation,
    )

    location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp_1"),
    )
    result = trace_location_to_proto(location)
    assert result.HasField("mlflow_experiment")
    assert result.mlflow_experiment.experiment_id == "exp_1"


def check_trace_location_to_proto_inference_table() -> None:
    """C18c: INFERENCE_TABLE → proto with inference_table set."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation, TraceLocationType, InferenceTableLocation,
    )

    location = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="cat.s.t"),
    )
    result = trace_location_to_proto(location)
    assert result.HasField("inference_table")
    assert result.inference_table.full_table_name == "cat.s.t"


# ── C19: trace_location_to_proto ValueError ──────────────────────────
# Contracts: C19
def check_trace_location_to_proto_value_error() -> None:
    """C19: Unsupported trace_location.type raises ValueError."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import TraceLocation, TraceLocationType

    # Create a TraceLocation with only type set, no sub-location
    location = TraceLocation(
        type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED,
    )
    with pytest.raises(ValueError, match="Unsupported trace location type"):
        trace_location_to_proto(location)


# ── C25: AssessmentSourceType._parse case normalization ──────────────
# Contracts: C25
# Reference: /testbed/tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity
def check_parse_case_normalization() -> None:
    """C25: _parse uppercases input strings."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._parse("human") == "HUMAN"
    assert AssessmentSourceType._parse("Human") == "HUMAN"
    assert AssessmentSourceType._parse("HUMAN") == "HUMAN"
    assert AssessmentSourceType._parse("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("Llm_Judge") == "LLM_JUDGE"


# ── C26: AssessmentSourceType._parse AI_JUDGE deprecation ────────────
# Contracts: C26
# Reference: /testbed/tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning
def check_parse_ai_judge_deprecation() -> None:
    """C26: _parse('AI_JUDGE') → 'LLM_JUDGE' with FutureWarning."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = AssessmentSourceType._parse("AI_JUDGE")
    assert result == "LLM_JUDGE"


# ── C27: AssessmentSourceType._parse invalid type ────────────────────
# Contracts: C27
# Reference: /testbed/tests/entities/test_assessment_source.py::test_assessment_source_type_validation
def check_parse_invalid_type() -> None:
    """C27: _parse('INVALID') raises MlflowException with INVALID_PARAMETER_VALUE."""
    import pytest
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException) as exc_info:
        AssessmentSourceType._parse("INVALID")
    assert exc_info.value.error_code == INVALID_PARAMETER_VALUE, (
        f"Expected INVALID_PARAMETER_VALUE, got {exc_info.value.error_code}"
    )
    assert "Invalid assessment source type" in str(exc_info.value)


# ── C28: AssessmentSourceType.__init__ stores parsed value ───────────
# Contracts: C28
def check_init_stores_parsed_value() -> None:
    """C28: AssessmentSourceType('LLM_JUDGE')._source_type == 'LLM_JUDGE'."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    obj = AssessmentSourceType("LLM_JUDGE")
    assert obj._source_type == "LLM_JUDGE"


# ── C29: AssessmentSourceType.__str__ returns stored value ───────────
# Contracts: C29
def check_str_returns_stored_value() -> None:
    """C29: str(AssessmentSourceType('code')) == 'CODE'."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert str(AssessmentSourceType("code")) == "CODE"


# ── C30: AssessmentSourceType._standardize returns string ────────────
# Contracts: C30
def check_standardize_returns_string() -> None:
    """C30: _standardize('human') → 'HUMAN'; _standardize('AI_JUDGE') → 'LLM_JUDGE'."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._standardize("human") == "HUMAN"

    with pytest.warns(FutureWarning):
        result = AssessmentSourceType._standardize("AI_JUDGE")
    assert result == "LLM_JUDGE"


# ── C32: Span.inputs returns deserialized attribute ──────────────────
# Contracts: C32
# Reference: /testbed/tests/entities/test_trace.py:544
def check_span_inputs_returns_deserialized() -> None:
    """C32: Span with mlflow.spanInputs returns deserialized value."""
    span = _make_span_with_inputs({"x": 1})
    assert span.inputs == {"x": 1}, f"Expected {{'x': 1}}, got {span.inputs!r}"


def check_span_inputs_string() -> None:
    """C32 (string): Span.inputs returns string value."""
    span = _make_span_with_inputs("abc")
    assert span.inputs == "abc", f"Expected 'abc', got {span.inputs!r}"


# ── C33: Span.outputs returns deserialized attribute ─────────────────
# Contracts: C33
# Reference: /testbed/tests/entities/test_trace.py:545
def check_span_outputs_returns_deserialized() -> None:
    """C33: Span with mlflow.spanOutputs returns deserialized value."""
    span = _make_span_with_outputs({"result": 42})
    assert span.outputs == {"result": 42}, f"Expected {{'result': 42}}, got {span.outputs!r}"


def check_span_outputs_string() -> None:
    """C33 (string): Span.outputs returns string value."""
    span = _make_span_with_outputs("def")
    assert span.outputs == "def", f"Expected 'def', got {span.outputs!r}"


# ── C34: Span.inputs returns None when not set ────────────────────────
# Contracts: C34
def check_span_inputs_none_when_not_set() -> None:
    """C34: Span without mlflow.spanInputs returns None for inputs."""
    span = _make_span_without_io()
    assert span.inputs is None, f"Expected None, got {span.inputs!r}"


# ── C35: Span.outputs returns None when not set ───────────────────────
# Contracts: C35
def check_span_outputs_none_when_not_set() -> None:
    """C35: Span without mlflow.spanOutputs returns None for outputs."""
    span = _make_span_without_io()
    assert span.outputs is None, f"Expected None, got {span.outputs!r}"


# ── Runner ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    checks = [
        check_get_trace_id_uc_schema_path,
        check_get_trace_id_fallback,
        check_trace_location_from_proto_uc_schema,
        check_trace_location_from_proto_mlflow_experiment,
        check_trace_location_from_proto_inference_table,
        check_trace_location_from_proto_fallback,
        check_trace_location_to_proto_uc_schema,
        check_trace_location_to_proto_mlflow_experiment,
        check_trace_location_to_proto_inference_table,
        check_trace_location_to_proto_value_error,
        check_parse_case_normalization,
        check_parse_ai_judge_deprecation,
        check_parse_invalid_type,
        check_init_stores_parsed_value,
        check_str_returns_stored_value,
        check_standardize_returns_string,
        check_span_inputs_returns_deserialized,
        check_span_inputs_string,
        check_span_outputs_returns_deserialized,
        check_span_outputs_string,
        check_span_inputs_none_when_not_set,
        check_span_outputs_none_when_not_set,
    ]
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as e:
            print(f"FAIL: {check.__name__} — {e}")
            import sys
            sys.exit(1)
