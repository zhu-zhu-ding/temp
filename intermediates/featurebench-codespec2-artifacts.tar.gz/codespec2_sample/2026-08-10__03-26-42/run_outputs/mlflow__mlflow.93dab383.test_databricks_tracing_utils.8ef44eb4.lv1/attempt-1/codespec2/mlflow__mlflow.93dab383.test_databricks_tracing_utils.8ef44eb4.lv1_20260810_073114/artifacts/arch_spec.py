"""
Architecture specification: public interface and graph connectivity proofs.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check_* function proves a contract via real runtime traces.
"""

from unittest import mock


# ── Helpers ──────────────────────────────────────────────────────────

def _make_assessment_with_expectation():
    """Create a minimal Assessment with an Expectation for proto conversion tests."""
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.entities.assessment import Assessment, Expectation, ExpectationValue
    src = AssessmentSource(source_type="HUMAN", source_id="user_1")
    ev = ExpectationValue(value="expected_result")
    return Assessment(
        name="test_expectation",
        source=src,
        trace_id="tr-12345",
        expectation=ev,
    )


def _make_assessment_with_feedback():
    """Create a minimal Assessment with Feedback for proto conversion tests."""
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.entities.assessment import Assessment, Feedback, FeedbackValue
    src = AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4")
    fv = FeedbackValue(value=0.95)
    return Assessment(
        name="test_feedback",
        source=src,
        trace_id="tr-67890",
        feedback=fv,
    )


def _make_uc_schema_trace_location():
    """Create a TraceLocation with UC_SCHEMA type."""
    from mlflow.entities.trace_location import (
        TraceLocation, TraceLocationType, UCSchemaLocation,
    )
    return TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="my_cat", schema_name="my_schema"),
    )


def _make_experiment_trace_location():
    """Create a TraceLocation with MLFLOW_EXPERIMENT type."""
    from mlflow.entities.trace_location import (
        TraceLocation, TraceLocationType, MlflowExperimentLocation,
    )
    return TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp_42"),
    )


def _make_inference_table_trace_location():
    """Create a TraceLocation with INFERENCE_TABLE type."""
    from mlflow.entities.trace_location import (
        TraceLocation, TraceLocationType, InferenceTableLocation,
    )
    return TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="cat.schema.table"),
    )


# ── C1: assessment_to_proto output type ──────────────────────────────
# Contracts: C1
def check_assessment_to_proto_output_type() -> None:
    """C1: assessment_to_proto returns a pb.Assessment protobuf message."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    assessment = _make_assessment_with_expectation()
    result = assessment_to_proto(assessment)

    assert isinstance(result, pb.Assessment), (
        f"Expected pb.Assessment, got {type(result)}"
    )


# ── C2: assessment_to_proto maps required fields ─────────────────────
# Contracts: C2
def check_assessment_to_proto_required_fields() -> None:
    """C2: assessment_to_proto maps name, trace_id, source, and timestamps."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assessment = _make_assessment_with_expectation()
    result = assessment_to_proto(assessment)

    assert result.assessment_name == assessment.name
    # trace_id is parsed by parse_trace_id_v4; for non-v4 IDs the trace_id
    # is returned as-is
    assert result.trace_id is not None
    assert result.trace_id != ""
    # source converted
    assert result.source is not None
    # timestamps in milliseconds → protobuf Timestamp
    assert result.create_time.ToMilliseconds() == assessment.create_time_ms
    assert result.last_update_time.ToMilliseconds() == assessment.last_update_time_ms


# ── C3: assessment_to_proto UC Schema trace location ─────────────────
# Contracts: C3
def check_assessment_to_proto_uc_schema_location() -> None:
    """C3: When trace_id is v4, trace_location.uc_schema is set."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.tracing.utils import construct_trace_id_v4
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.entities.assessment import Assessment, Expectation, ExpectationValue

    v4_trace_id = construct_trace_id_v4("my_cat.my_schema", "tr-inner-123")
    src = AssessmentSource(source_type="HUMAN", source_id="u1")
    ev = ExpectationValue(value="ok")
    assessment = Assessment(
        name="v4test",
        source=src,
        trace_id=v4_trace_id,
        expectation=ev,
    )

    result = assessment_to_proto(assessment)

    assert result.trace_location.HasField("uc_schema"), (
        "Expected uc_schema trace_location for v4 trace ID"
    )
    assert result.trace_location.uc_schema.catalog_name == "my_cat"
    assert result.trace_location.uc_schema.schema_name == "my_schema"


# ── C4: assessment_to_proto optional fields ──────────────────────────
# Contracts: C4
def check_assessment_to_proto_optional_fields() -> None:
    """C4: optional fields set only when not None."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.entities.assessment import Assessment, Expectation, ExpectationValue

    # Minimal assessment — many optionals None
    src = AssessmentSource(source_type="HUMAN", source_id="u1")
    ev = ExpectationValue(value="ok")
    assessment = Assessment(
        name="minimal",
        source=src,
        trace_id="tr-min-1",
        expectation=ev,
    )

    result = assessment_to_proto(assessment)

    # span_id not set → proto should not have it
    assert not result.HasField("span_id") or result.span_id == ""
    # rationale not set
    assert not result.HasField("rationale") or result.rationale == ""
    # assessment_id not set
    assert not result.HasField("assessment_id") or result.assessment_id == ""
    # overrides not set
    assert not result.HasField("overrides") or result.overrides == ""


# ── C5: assessment_to_proto metadata stringification ─────────────────
# Contracts: C5
def check_assessment_to_proto_metadata_stringification() -> None:
    """C5: metadata values are converted to strings."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.entities.assessment import Assessment, Expectation, ExpectationValue

    src = AssessmentSource(source_type="HUMAN", source_id="u1")
    ev = ExpectationValue(value="ok")
    assessment = Assessment(
        name="meta_test",
        source=src,
        trace_id="tr-meta-1",
        expectation=ev,
        metadata={"int_key": 42, "bool_key": True, "str_key": "hello"},
    )

    result = assessment_to_proto(assessment)

    assert result.metadata["int_key"] == "42"
    assert result.metadata["bool_key"] == "True"
    assert result.metadata["str_key"] == "hello"
    for v in result.metadata.values():
        assert isinstance(v, str), f"Metadata value {v!r} is not str"


# ── C6: assessment_to_proto exactly one of expectation/feedback ──────
# Contracts: C6
def check_assessment_to_proto_exclusive_expectation_feedback() -> None:
    """C6: Proto has expectation OR feedback, never both."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    # With expectation
    assessment_exp = _make_assessment_with_expectation()
    result_exp = assessment_to_proto(assessment_exp)
    assert result_exp.HasField("expectation"), "Should have expectation"
    assert not result_exp.HasField("feedback"), "Should NOT have feedback"

    # With feedback
    assessment_fb = _make_assessment_with_feedback()
    result_fb = assessment_to_proto(assessment_fb)
    assert result_fb.HasField("feedback"), "Should have feedback"
    assert not result_fb.HasField("expectation"), "Should NOT have expectation"


# ── C9: inference_table_location_to_proto mapping ────────────────────
# Contracts: C9
def check_inference_table_location_to_proto() -> None:
    """C9: full_table_name is mapped correctly."""
    from mlflow.utils.databricks_tracing_utils import inference_table_location_to_proto
    from mlflow.entities.trace_location import InferenceTableLocation

    loc = InferenceTableLocation(full_table_name="my_cat.my_schema.my_table")
    result = inference_table_location_to_proto(loc)

    assert result.full_table_name == "my_cat.my_schema.my_table"


# ── C10: mlflow_experiment_location_to_proto mapping ─────────────────
# Contracts: C10
def check_mlflow_experiment_location_to_proto() -> None:
    """C10: experiment_id is mapped correctly."""
    from mlflow.utils.databricks_tracing_utils import mlflow_experiment_location_to_proto
    from mlflow.entities.trace_location import MlflowExperimentLocation

    loc = MlflowExperimentLocation(experiment_id="exp_99")
    result = mlflow_experiment_location_to_proto(loc)

    assert result.experiment_id == "exp_99"


# ── C11: trace_from_proto structure ──────────────────────────────────
# Contracts: C11
def check_trace_from_proto_structure() -> None:
    """C11: trace_from_proto returns Trace with info and data.spans."""
    from unittest import mock
    from mlflow.utils.databricks_tracing_utils import trace_from_proto
    from mlflow.entities import Trace, TraceData, TraceInfo
    from mlflow.protos import databricks_tracing_pb2 as pb

    # Build a minimal proto Trace
    trace_proto = pb.Trace()
    trace_proto.trace_info.trace_id = "tr-proto-1"
    trace_proto.trace_info.state = pb.TraceInfo.State.OK
    trace_proto.trace_info.request_time.FromMilliseconds(1000)
    # Use a simple experiment location
    trace_proto.trace_info.trace_location.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    trace_proto.trace_info.trace_location.mlflow_experiment.experiment_id = "0"

    result = trace_from_proto(trace_proto, "0")

    assert isinstance(result, Trace)
    assert isinstance(result.info, TraceInfo)
    assert isinstance(result.data, TraceData)
    assert result.info.trace_id is not None


# ── C12: trace_info_to_v4_proto trace_id parsing ─────────────────────
# Contracts: C12
def check_trace_info_to_v4_proto_trace_id_parsing() -> None:
    """C12: For UC Schema, trace_id is parsed via parse_trace_id_v4; else unchanged."""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.utils import construct_trace_id_v4

    # UC Schema case
    uc_loc = _make_uc_schema_trace_location()
    v4_id = construct_trace_id_v4("my_cat.my_schema", "inner-tr-1")
    ti = TraceInfo(
        trace_id=v4_id,
        trace_location=uc_loc,
        request_time=1000,
        state=TraceState.OK,
    )
    result = trace_info_to_v4_proto(ti)
    assert result.trace_id == "inner-tr-1", (
        f"Expected parsed inner trace ID 'inner-tr-1', got {result.trace_id!r}"
    )

    # Non-UC Schema case
    exp_loc = _make_experiment_trace_location()
    ti2 = TraceInfo(
        trace_id="plain-tr-2",
        trace_location=exp_loc,
        request_time=2000,
        state=TraceState.OK,
    )
    result2 = trace_info_to_v4_proto(ti2)
    assert result2.trace_id == "plain-tr-2", (
        f"Expected unchanged trace ID, got {result2.trace_id!r}"
    )


# ── C13: trace_info_to_v4_proto timestamps ───────────────────────────
# Contracts: C13
def check_trace_info_to_v4_proto_timestamps() -> None:
    """C13: request_time → proto Timestamp; execution_duration set only when not None."""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_state import TraceState

    exp_loc = _make_experiment_trace_location()
    # With execution_duration
    ti = TraceInfo(
        trace_id="tr-ts-1",
        trace_location=exp_loc,
        request_time=5000,
        state=TraceState.OK,
        execution_duration=300,
    )
    result = trace_info_to_v4_proto(ti)
    assert result.request_time.ToMilliseconds() == 5000
    assert result.execution_duration.ToMilliseconds() == 300

    # Without execution_duration
    ti2 = TraceInfo(
        trace_id="tr-ts-2",
        trace_location=exp_loc,
        request_time=7000,
        state=TraceState.OK,
    )
    result2 = trace_info_to_v4_proto(ti2)
    assert result2.request_time.ToMilliseconds() == 7000
    # execution_duration should be empty/not set
    assert result2.execution_duration.ToMilliseconds() == 0  # default Duration


# ── C20: trace_to_proto structure ────────────────────────────────────
# Contracts: C20
def check_trace_to_proto_structure() -> None:
    """C20: trace_to_proto returns pb.Trace with trace_info and spans."""
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos import databricks_tracing_pb2 as pb

    exp_loc = _make_experiment_trace_location()
    ti = TraceInfo(
        trace_id="tr-tp-1",
        trace_location=exp_loc,
        request_time=1000,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))

    result = trace_to_proto(trace)
    assert isinstance(result, pb.Trace)
    assert result.HasField("trace_info")
    # spans list is present (empty in this case)
    assert len(result.spans) == 0


# ── C21: uc_schema_location_from_proto fields ────────────────────────
# Contracts: C21
def check_uc_schema_location_from_proto_fields() -> None:
    """C21: Returns UCSchemaLocation with catalog/schema and optional otel fields."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.entities.trace_location import UCSchemaLocation
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.UCSchemaLocation(
        catalog_name="cat1",
        schema_name="schema1",
        otel_spans_table_name="spans_table",
    )

    result = uc_schema_location_from_proto(proto)
    assert isinstance(result, UCSchemaLocation)
    assert result.catalog_name == "cat1"
    assert result.schema_name == "schema1"
    assert result._otel_spans_table_name == "spans_table"
    # otel_logs_table_name not set in proto, should be None or default
    assert result._otel_logs_table_name is None or result._otel_logs_table_name != ""


# ── C22: uc_schema_location_to_proto fields ──────────────────────────
# Contracts: C22
def check_uc_schema_location_to_proto_fields() -> None:
    """C22: Maps catalog_name, schema_name, _otel_* fields to proto."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto
    from mlflow.entities.trace_location import UCSchemaLocation
    from mlflow.protos import databricks_tracing_pb2 as pb

    uc = UCSchemaLocation(catalog_name="cat2", schema_name="schema2")
    uc._otel_spans_table_name = "custom_spans"
    uc._otel_logs_table_name = "custom_logs"

    result = uc_schema_location_to_proto(uc)
    assert isinstance(result, pb.UCSchemaLocation)
    assert result.catalog_name == "cat2"
    assert result.schema_name == "schema2"
    assert result.otel_spans_table_name == "custom_spans"
    assert result.otel_logs_table_name == "custom_logs"


# ── C23: AssessmentSourceType constants are strings ──────────────────
# Contracts: C23
def check_assessment_source_type_constants_are_strings() -> None:
    """C23: All AssessmentSourceType constants are str instances."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert isinstance(AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED, str)
    assert isinstance(AssessmentSourceType.LLM_JUDGE, str)
    assert isinstance(AssessmentSourceType.AI_JUDGE, str)
    assert isinstance(AssessmentSourceType.HUMAN, str)
    assert isinstance(AssessmentSourceType.CODE, str)


# ── C24: _SOURCE_TYPES excludes AI_JUDGE ─────────────────────────────
# Contracts: C24
def check_source_types_excludes_ai_judge() -> None:
    """C24: _SOURCE_TYPES does not contain AI_JUDGE."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType.AI_JUDGE not in AssessmentSourceType._SOURCE_TYPES, (
        "AI_JUDGE should not be in _SOURCE_TYPES"
    )
    expected = [
        AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED,
        AssessmentSourceType.LLM_JUDGE,
        AssessmentSourceType.HUMAN,
        AssessmentSourceType.CODE,
    ]
    assert AssessmentSourceType._SOURCE_TYPES == expected, (
        f"Expected {expected}, got {AssessmentSourceType._SOURCE_TYPES}"
    )


# ── C31: AssessmentSource.__post_init__ calls _standardize ───────────
# Contracts: C31
def check_assessment_source_post_init_standardizes() -> None:
    """C31: AssessmentSource(source_type='llm_judge') → source_type == 'LLM_JUDGE'."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="llm_judge", source_id="x")
    assert source.source_type == "LLM_JUDGE", (
        f"Expected 'LLM_JUDGE', got {source.source_type!r}"
    )


# ── C36: TraceLocation.from_proto delegates to trace_location_from_proto ─
# Contracts: C36
def check_trace_location_from_proto_delegates() -> None:
    """C36: TraceLocation.from_proto(proto) returns same result as
    trace_location_from_proto(proto), proving delegation."""
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto.mlflow_experiment.experiment_id = "exp_77"

    # Call the delegating method
    result_via_classmethod = TraceLocation.from_proto(proto)
    # Call the delegate directly
    result_direct = trace_location_from_proto(proto)

    # Both should produce equivalent TraceLocation objects
    assert result_via_classmethod.type == result_direct.type
    assert result_via_classmethod.mlflow_experiment.experiment_id == \
        result_direct.mlflow_experiment.experiment_id


# ── C37: TraceInfo.to_proto delegates to trace_info_to_v4_proto ──────
# Contracts: C37
def check_trace_info_to_proto_delegates_to_v4() -> None:
    """C37: When _is_v4() is True, TraceInfo.to_proto() result matches
    trace_info_to_v4_proto(self), proving delegation."""
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    uc_loc = _make_uc_schema_trace_location()
    ti = TraceInfo(
        trace_id="tr-v4-1",
        trace_location=uc_loc,
        request_time=1000,
        state=TraceState.OK,
    )

    result_via_to_proto = ti.to_proto()
    result_direct = trace_info_to_v4_proto(ti)

    # Both should produce identical protobuf messages
    assert result_via_to_proto.trace_id == result_direct.trace_id
    assert result_via_to_proto.request_time.ToMilliseconds() == \
        result_direct.request_time.ToMilliseconds()
    assert result_via_to_proto.state == result_direct.state


# ── C38: Expectation.from_proto calls get_trace_id_from_assessment_proto ─
# Contracts: C38
def check_expectation_from_proto_calls_get_trace_id() -> None:
    """C38: Expectation.from_proto uses get_trace_id_from_assessment_proto
    to obtain the trace ID. This is proven by verifying the result matches
    what get_trace_id_from_assessment_proto returns for the same proto."""
    from mlflow.entities.assessment import Expectation
    from mlflow.protos import assessments_pb2 as apb
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto

    # Build assessment proto with expectation
    proto = apb.Assessment()
    proto.assessment_name = "test_exp"
    proto.trace_id = "tr-c38-1"
    proto.source.source_type = apb.AssessmentSource.SourceType.HUMAN
    proto.source.source_id = "user_1"
    proto.expectation.value.string_value = "expected"

    result = Expectation.from_proto(proto)
    expected_trace_id = get_trace_id_from_assessment_proto(proto)

    assert result.trace_id == expected_trace_id, (
        f"Expected trace_id {expected_trace_id!r}, got {result.trace_id!r}"
    )


# ── Runner ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    checks = [
        check_assessment_to_proto_output_type,
        check_assessment_to_proto_required_fields,
        check_assessment_to_proto_uc_schema_location,
        check_assessment_to_proto_optional_fields,
        check_assessment_to_proto_metadata_stringification,
        check_assessment_to_proto_exclusive_expectation_feedback,
        check_inference_table_location_to_proto,
        check_mlflow_experiment_location_to_proto,
        check_trace_from_proto_structure,
        check_trace_info_to_v4_proto_trace_id_parsing,
        check_trace_info_to_v4_proto_timestamps,
        check_trace_to_proto_structure,
        check_uc_schema_location_from_proto_fields,
        check_uc_schema_location_to_proto_fields,
        check_assessment_source_type_constants_are_strings,
        check_source_types_excludes_ai_judge,
        check_assessment_source_post_init_standardizes,
        check_trace_location_from_proto_delegates,
        check_trace_info_to_proto_delegates_to_v4,
        check_expectation_from_proto_calls_get_trace_id,
    ]
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as e:
            print(f"FAIL: {check.__name__} — {e}")
            import sys
            sys.exit(1)
