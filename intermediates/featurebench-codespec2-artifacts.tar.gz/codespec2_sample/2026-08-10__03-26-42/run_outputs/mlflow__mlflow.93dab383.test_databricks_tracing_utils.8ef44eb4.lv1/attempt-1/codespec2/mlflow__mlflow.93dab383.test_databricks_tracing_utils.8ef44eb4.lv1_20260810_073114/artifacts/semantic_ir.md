# Semantic IR

## L1. Requirement Obligations

### R1: Convert Assessment entity to protobuf representation
- **Type:** Dataflow
- **Statement:** `assessment_to_proto` shall convert an MLflow `Assessment` entity into a `pb.Assessment` protobuf message, mapping all fields including trace location derived from `trace_id`, timestamps converted from milliseconds, metadata stringified, and exactly one of expectation or feedback set.
- **Task Evidence:** Interface Description 1, `assessment_to_proto` function specification.
- **Acceptance:** Calling `assessment_to_proto(assessment)` returns a `pb.Assessment` with all non-None fields populated; timestamps are protobuf `Timestamp` via `FromMilliseconds()`; metadata values are `str`; trace_location is set for UC Schema trace IDs.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:148-189` — reference implementation; `/testbed/mlflow/entities/assessment.py` — `Assessment` entity fields; `/testbed/mlflow/tracing/utils/__init__.py:631-663` — `parse_trace_id_v4` and `construct_trace_id_v4`.
- **Uncertainty:** None.

### R2: Extract trace ID from assessment protobuf
- **Type:** Behavior
- **Statement:** `get_trace_id_from_assessment_proto` shall extract a trace ID from a `pb.Assessment` or `assessments_pb2.Assessment` proto, constructing a v4 trace ID for UC Schema locations and returning the raw `trace_id` otherwise.
- **Task Evidence:** Interface Description 1, `get_trace_id_from_assessment_proto` function specification.
- **Acceptance:** For UC Schema proto (has `trace_location.uc_schema`), returns `construct_trace_id_v4(catalog.schema, trace_id)`; for missing/other locations, returns `proto.trace_id`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:192-203` — reference implementation; `/testbed/mlflow/entities/assessment.py` — `Expectation.from_proto` calls this function; `/testbed/mlflow/tracing/utils/__init__.py:649-663` — `construct_trace_id_v4`.
- **Uncertainty:** None.

### R3: Convert InferenceTableLocation to protobuf
- **Type:** Dataflow
- **Statement:** `inference_table_location_to_proto` shall map `InferenceTableLocation.full_table_name` to `pb.InferenceTableLocation.full_table_name`.
- **Task Evidence:** Interface Description 1, `inference_table_location_to_proto` function specification.
- **Acceptance:** Returns `pb.InferenceTableLocation(full_table_name=location.full_table_name)`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:44-47` — reference implementation; `/testbed/mlflow/entities/trace_location.py:64-66` — `InferenceTableLocation.full_table_name`.
- **Uncertainty:** None.

### R4: Convert MlflowExperimentLocation to protobuf
- **Type:** Dataflow
- **Statement:** `mlflow_experiment_location_to_proto` shall map `MlflowExperimentLocation.experiment_id` to `pb.MlflowExperimentLocation.experiment_id`.
- **Task Evidence:** Interface Description 1, `mlflow_experiment_location_to_proto` function specification.
- **Acceptance:** Returns `pb.MlflowExperimentLocation(experiment_id=location.experiment_id)`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:50-53` — reference implementation; `/testbed/mlflow/entities/trace_location.py:37-38` — `MlflowExperimentLocation.experiment_id`.
- **Uncertainty:** None.

### R5: Convert protobuf Trace to MLflow Trace entity
- **Type:** Dataflow
- **Statement:** `trace_from_proto` shall deserialize a `pb.Trace` into an MLflow `Trace` entity by converting `TraceInfo.from_proto(proto.trace_info)` and each span via `Span.from_otel_proto(span, location_id)`.
- **Task Evidence:** Interface Description 1, `trace_from_proto` function specification.
- **Acceptance:** Returns `Trace(info=TraceInfo.from_proto(proto.trace_info), data=TraceData(spans=[...]))` where each span is converted with the given `location_id`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:128-132` — reference implementation; `/testbed/mlflow/entities/trace_info.py:119-146` — `TraceInfo.from_proto`; `/testbed/mlflow/entities/span.py:366` — `Span.from_otel_proto`.
- **Uncertainty:** None.

### R6: Convert TraceInfo to v4 protobuf
- **Type:** Dataflow
- **Statement:** `trace_info_to_v4_proto` shall convert a `TraceInfo` entity to `pb.TraceInfo`, parsing v4 trace IDs for UC Schema locations, converting timestamps/durations to protobuf formats, truncating metadata/tags, and converting assessments.
- **Task Evidence:** Interface Description 1, `trace_info_to_v4_proto` function specification.
- **Acceptance:** Returns `pb.TraceInfo` with: parsed trace_id (via `parse_trace_id_v4` for UC Schema), `trace_location_to_proto` result, `request_time` as protobuf `Timestamp`, optional `execution_duration` as protobuf `Duration`, `state` as enum value, truncated metadata/tags, and assessments converted via `assessment_to_proto`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:107-125` — reference implementation; `/testbed/mlflow/entities/trace_info.py:108-111` — `TraceInfo.to_proto()` calls `trace_info_to_v4_proto(self)` for v4 paths; `/testbed/mlflow/entities/trace_info_v2.py:15-22` — `_truncate_request_metadata` and `_truncate_tags`.
- **Uncertainty:** None.

### R7: Convert protobuf TraceLocation to entity
- **Type:** Dataflow
- **Statement:** `trace_location_from_proto` shall convert `pb.TraceLocation` to `TraceLocation` entity by dispatching on `WhichOneof("identifier")` for `uc_schema`, `mlflow_experiment`, `inference_table`, defaulting to `TRACE_LOCATION_TYPE_UNSPECIFIED`.
- **Task Evidence:** Interface Description 1, `trace_location_from_proto` function specification.
- **Acceptance:** Returns `TraceLocation` with correct type and sub-location; delegates to `MlflowExperimentLocation.from_proto` and `InferenceTableLocation.from_proto` for non-UC types; returns `TRACE_LOCATION_TYPE_UNSPECIFIED` for unrecognized identifiers.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:84-100` — reference implementation; `/testbed/mlflow/entities/trace_location.py:244-246` — `TraceLocation.from_proto` calls `trace_location_from_proto(proto)`.
- **Uncertainty:** None.

### R8: Convert TraceLocation entity to protobuf
- **Type:** Dataflow
- **Statement:** `trace_location_to_proto` shall convert `TraceLocation` to `pb.TraceLocation`, dispatching on `trace_location.type` to populate `uc_schema`, `mlflow_experiment`, or `inference_table`, and raising `ValueError` for unsupported types.
- **Task Evidence:** Interface Description 1, `trace_location_to_proto` function specification.
- **Acceptance:** Returns proper `pb.TraceLocation` for `UC_SCHEMA`, `MLFLOW_EXPERIMENT`, `INFERENCE_TABLE`; raises `ValueError` otherwise.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:60-78` — reference implementation; `/testbed/mlflow/entities/trace_location.py:223-237` — `TraceLocation.to_proto` does not handle UC Schema (delegates to databricks_tracing_utils implicitly).
- **Uncertainty:** None.

### R9: Convert Trace entity to protobuf
- **Type:** Dataflow
- **Statement:** `trace_to_proto` shall convert `Trace` to `pb.Trace` with `trace_info` via the trace's `to_proto()` and `spans` via each span's `to_otel_proto()`.
- **Task Evidence:** Interface Description 1, `trace_to_proto` function specification.
- **Acceptance:** Returns `pb.Trace(trace_info=trace.info.to_proto(), spans=[s.to_otel_proto() for s in trace.data.spans])`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:136-139` — reference implementation; `/testbed/mlflow/entities/trace.py:241-248` — `Trace.to_proto()` calls `self.info.to_proto()` and `span.to_otel_proto()`.
- **Uncertainty:** None.

### R10: Convert UCSchemaLocation protobuf to entity
- **Type:** Dataflow
- **Statement:** `uc_schema_location_from_proto` shall convert `pb.UCSchemaLocation` to `UCSchemaLocation`, extracting `catalog_name` and `schema_name`, optionally setting `_otel_spans_table_name` and `_otel_logs_table_name` via `HasField`.
- **Task Evidence:** Interface Description 1, `uc_schema_location_from_proto` function specification.
- **Acceptance:** Returns `UCSchemaLocation(catalog_name, schema_name)` with private `_otel_*` attributes set when present in proto.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:33-41` — reference implementation; `/testbed/mlflow/entities/trace_location.py:89-96` — `UCSchemaLocation` fields.
- **Uncertainty:** None.

### R11: Convert UCSchemaLocation entity to protobuf
- **Type:** Dataflow
- **Statement:** `uc_schema_location_to_proto` shall convert `UCSchemaLocation` to `pb.UCSchemaLocation`, mapping all four fields including private `_otel_spans_table_name` and `_otel_logs_table_name`.
- **Task Evidence:** Interface Description 1, `uc_schema_location_to_proto` function specification.
- **Acceptance:** Returns `pb.UCSchemaLocation(catalog_name, schema_name, otel_spans_table_name, otel_logs_table_name)`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:25-30` — reference implementation.
- **Uncertainty:** None.

### R12: AssessmentSourceType validation and standardization
- **Type:** Behavior
- **Statement:** `AssessmentSourceType` shall support instance creation with string validation, case-insensitive normalization, `AI_JUDGE` → `LLM_JUDGE` deprecation with `FutureWarning`, and a `_standardize` static method that returns the normalized string.
- **Task Evidence:** Interface Description 2, `AssessmentSourceType` class specification.
- **Acceptance:** `AssessmentSourceType("llm_judge")` stores `"LLM_JUDGE"`; `AssessmentSourceType("AI_JUDGE")` emits `FutureWarning` and stores `"LLM_JUDGE"`; `AssessmentSourceType("invalid")` raises `MlflowException(INVALID_PARAMETER_VALUE)`; `str(AssessmentSourceType("human"))` returns `"HUMAN"`; `AssessmentSourceType._standardize("ai_judge")` returns `"LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:154-191` — reference implementation with `__init__`, `_parse`, `__str__`, `_standardize`; `/testbed/mlflow/entities/assessment_source.py:76-78` — `AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`.
- **Uncertainty:** None.

### R13: Span inputs property
- **Type:** Interface
- **Statement:** `Span.inputs` property shall return the deserialized input values stored as the `mlflow.spanInputs` span attribute.
- **Task Evidence:** Interface Description 3, `Span.inputs` property specification.
- **Acceptance:** `span.inputs` returns the value previously stored via `set_attribute(SpanAttributeKey.INPUTS, value)`, deserialized through `_CachedSpanAttributesRegistry.get()`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/span.py:157-159` — reference implementation `return self.get_attribute(SpanAttributeKey.INPUTS)`; `/testbed/mlflow/tracing/constant.py:60` — `SpanAttributeKey.INPUTS = "mlflow.spanInputs"`; `/testbed/tests/entities/test_trace.py:544` — `assert trace.data.spans[0].inputs == "abc"`.
- **Uncertainty:** None.

### R14: Span outputs property
- **Type:** Interface
- **Statement:** `Span.outputs` property shall return the deserialized output values stored as the `mlflow.spanOutputs` span attribute.
- **Task Evidence:** Interface Description 3, `Span.outputs` property specification.
- **Acceptance:** `span.outputs` returns the value previously stored via `set_attribute(SpanAttributeKey.OUTPUTS, value)`, deserialized through `_CachedSpanAttributesRegistry.get()`.
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/span.py:162-164` — reference implementation `return self.get_attribute(SpanAttributeKey.OUTPUTS)`; `/testbed/mlflow/tracing/constant.py:61` — `SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"`; `/testbed/tests/entities/test_trace.py:545` — `assert trace.data.spans[0].outputs == "def"`.
- **Uncertainty:** None.

## L2. Functional Design Graph

### N1: `assessment_to_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:148-189`.

### N2: `get_trace_id_from_assessment_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:192-203`.

### N3: `inference_table_location_to_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:44-47`.

### N4: `mlflow_experiment_location_to_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:50-53`.

### N5: `trace_from_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:128-132`.

### N6: `trace_info_to_v4_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:107-125`.

### N7: `trace_location_from_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:84-100`.

### N8: `trace_location_to_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:60-78`.

### N9: `trace_to_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:136-139`.

### N10: `uc_schema_location_from_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:33-41`.

### N11: `uc_schema_location_to_proto` (Function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_tracing_utils.py` — declared in Interface Description 1; reference at `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:25-30`.

### N12: `AssessmentSourceType` (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:102-194` — partial implementation; `/testbed/libs/tracing/mlflow/entities/assessment_source.py:154-191` — full reference.

### N13: `AssessmentSourceType.__init__` (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:161-162` — `self._source_type = AssessmentSourceType._parse(source_type)`.

### N14: `AssessmentSourceType._parse` (Method)
- **Kind:** Function
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:164-181` — static method performing normalization, deprecation, validation.

### N15: `AssessmentSourceType.__str__` (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:183-184` — `return self._source_type`.

### N16: `AssessmentSourceType._standardize` (Method)
- **Kind:** Function
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:186-187` — `return str(AssessmentSourceType(source_type))`.

### N17: `AssessmentSource.__post_init__` (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:76-78` — calls `AssessmentSourceType._standardize(self.source_type)`.

### N18: `Span` (Class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:101` — existing Span class definition.

### N19: `Span.inputs` (Property)
- **Kind:** Method
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/span.py:157-159` — `return self.get_attribute(SpanAttributeKey.INPUTS)`.

### N20: `Span.outputs` (Property)
- **Kind:** Method
- **Repository Evidence:** `/testbed/libs/tracing/mlflow/entities/span.py:162-164` — `return self.get_attribute(SpanAttributeKey.OUTPUTS)`.

### N21: `TraceInfo.to_proto` (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info.py:106-111` — calls `trace_info_to_v4_proto(self)` for v4 paths.

### N22: `TraceLocation.from_proto` (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:244-246` — calls `trace_location_from_proto(proto)`.

### N23: `Expectation.from_proto` (Method)
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py` — calls `get_trace_id_from_assessment_proto(proto)`.

### N24: `parse_trace_id_v4` (Function)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/tracing/utils/__init__.py:631-647`.

### N25: `construct_trace_id_v4` (Function)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/tracing/utils/__init__.py:649-663`.

### N26: `SpanAttributeKey.INPUTS` (Constant)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/tracing/constant.py:60` — `INPUTS = "mlflow.spanInputs"`.

### N27: `SpanAttributeKey.OUTPUTS` (Constant)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/tracing/constant.py:61` — `OUTPUTS = "mlflow.spanOutputs"`.

### N28: `MlflowException` (Error)
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/exceptions.py` — used for invalid parameter values.

### N29: `pb.Assessment` (External)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/protos/databricks_tracing_pb2.py` — generated protobuf class.

### N30: `UCSchemaLocation` (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:89-122` — `UCSchemaLocation` dataclass.

### N31: `InferenceTableLocation` (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:64-80` — `InferenceTableLocation` dataclass.

### N32: `MlflowExperimentLocation` (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:33-51` — `MlflowExperimentLocation` dataclass.

### N33: `TraceLocation` (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:159-248` — `TraceLocation` dataclass.

### N34: `TraceInfo` (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info.py:24-193` — `TraceInfo` dataclass.

### N35: `Trace` (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace.py:28-252` — `Trace` dataclass.

### N36: `Assessment` (Payload)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py` — `Assessment` dataclass.

---

### E1: N1 (assessment_to_proto) → N24 (parse_trace_id_v4)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `assessment.trace_id` → `(location, trace_id)` tuple
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:151` — `location, trace_id = parse_trace_id_v4(assessment.trace_id)`
- **Obligations:** R1

### E2: N1 (assessment_to_proto) → N29 (pb.Assessment)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** All mapped fields into `pb.Assessment` message
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:148-189`
- **Obligations:** R1

### E3: N1 (assessment_to_proto) → N8 (trace_location_to_proto)
- **Kind:** CALL
- **Condition:** `location is not None` (v4 trace ID with UC schema)
- **Transfer:** Constructed `pb.TraceLocation(uc_schema=...)` via `CopyFrom`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:152-158`
- **Obligations:** R1

### E4: N2 (get_trace_id_from_assessment_proto) → N25 (construct_trace_id_v4)
- **Kind:** CALL
- **Condition:** `proto.trace_location.HasField("uc_schema")`
- **Transfer:** `(catalog.schema, proto.trace_id)` → v4 trace ID string
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:197-200`
- **Obligations:** R2

### E5: N3 (inference_table_location_to_proto) → N31 (InferenceTableLocation)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** `location.full_table_name` → `pb.InferenceTableLocation.full_table_name`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:44-47`
- **Obligations:** R3

### E6: N4 (mlflow_experiment_location_to_proto) → N32 (MlflowExperimentLocation)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** `location.experiment_id` → `pb.MlflowExperimentLocation.experiment_id`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:50-53`
- **Obligations:** R4

### E7: N5 (trace_from_proto) → N21 (TraceInfo.from_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `proto.trace_info` → `TraceInfo` entity
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:130`
- **Obligations:** R5

### E8: N5 (trace_from_proto) → Span.from_otel_proto
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Each `proto.spans[i]` + `location_id` → `Span` entity
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:131`
- **Obligations:** R5

### E9: N6 (trace_info_to_v4_proto) → N24 (parse_trace_id_v4)
- **Kind:** CALL
- **Condition:** `trace_info.trace_location.uc_schema is not None`
- **Transfer:** `trace_info.trace_id` → `(_, trace_id)` tuple
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:114-115`
- **Obligations:** R6

### E10: N6 (trace_info_to_v4_proto) → N8 (trace_location_to_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `trace_info.trace_location` → `pb.TraceLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:117`
- **Obligations:** R6

### E11: N6 (trace_info_to_v4_proto) → N1 (assessment_to_proto)
- **Kind:** CALL
- **Condition:** Always (for each assessment in trace_info.assessments)
- **Transfer:** Each `assessment` → `pb.Assessment` via list comprehension
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:124`
- **Obligations:** R6

### E12: N7 (trace_location_from_proto) → N10 (uc_schema_location_from_proto)
- **Kind:** CALL
- **Condition:** `proto.WhichOneof("identifier") == "uc_schema"`
- **Transfer:** `proto.uc_schema` → `UCSchemaLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:86-90`
- **Obligations:** R7

### E13: N7 (trace_location_from_proto) → N32 (MlflowExperimentLocation.from_proto)
- **Kind:** CALL
- **Condition:** `proto.WhichOneof("identifier") == "mlflow_experiment"`
- **Transfer:** `proto.mlflow_experiment` → `MlflowExperimentLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:91-94`
- **Obligations:** R7

### E14: N7 (trace_location_from_proto) → N31 (InferenceTableLocation.from_proto)
- **Kind:** CALL
- **Condition:** `proto.WhichOneof("identifier") == "inference_table"`
- **Transfer:** `proto.inference_table` → `InferenceTableLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:95-98`
- **Obligations:** R7

### E15: N8 (trace_location_to_proto) → N11 (uc_schema_location_to_proto)
- **Kind:** CALL
- **Condition:** `trace_location.type == TraceLocationType.UC_SCHEMA`
- **Transfer:** `trace_location.uc_schema` → `pb.UCSchemaLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:61-64`
- **Obligations:** R8

### E16: N8 (trace_location_to_proto) → N4 (mlflow_experiment_location_to_proto)
- **Kind:** CALL
- **Condition:** `trace_location.type == TraceLocationType.MLFLOW_EXPERIMENT`
- **Transfer:** `trace_location.mlflow_experiment` → `pb.MlflowExperimentLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:65-68`
- **Obligations:** R8

### E17: N8 (trace_location_to_proto) → N3 (inference_table_location_to_proto)
- **Kind:** CALL
- **Condition:** `trace_location.type == TraceLocationType.INFERENCE_TABLE`
- **Transfer:** `trace_location.inference_table` → `pb.InferenceTableLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:69-72`
- **Obligations:** R8

### E18: N9 (trace_to_proto) → N21 (TraceInfo.to_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `trace.info.to_proto()` → `pb.TraceInfo`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:138`
- **Obligations:** R9

### E19: N9 (trace_to_proto) → Span.to_otel_proto
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Each `span.to_otel_proto()` → OTel proto Span
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:139`
- **Obligations:** R9

### E20: N10 (uc_schema_location_from_proto) → N30 (UCSchemaLocation)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** `proto.catalog_name`, `proto.schema_name` → `UCSchemaLocation` entity; optional `_otel_*` fields set via `HasField`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:33-41`
- **Obligations:** R10

### E21: N11 (uc_schema_location_to_proto) → N30 (UCSchemaLocation)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** `location.catalog_name`, `schema_name`, `_otel_spans_table_name`, `_otel_logs_table_name` → `pb.UCSchemaLocation`
- **Evidence:** `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:25-30`
- **Obligations:** R11

### E22: N13 (AssessmentSourceType.__init__) → N14 (AssessmentSourceType._parse)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `source_type` string → parsed `source_type` string
- **Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:161-162`
- **Obligations:** R12

### E23: N16 (AssessmentSourceType._standardize) → N13 (AssessmentSourceType.__init__)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `source_type` → `AssessmentSourceType(source_type)` instance → `str()` → standardized string
- **Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:186-187`
- **Obligations:** R12

### E24: N14 (AssessmentSourceType._parse) → N28 (MlflowException)
- **Kind:** CONTROL
- **Condition:** `source_type not in AssessmentSourceType._SOURCE_TYPES`
- **Transfer:** Raises `MlflowException(INVALID_PARAMETER_VALUE)`
- **Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:174-180`
- **Obligations:** R12

### E25: N14 (AssessmentSourceType._parse) → Deprecation Warning
- **Kind:** CONTROL
- **Condition:** `source_type == AssessmentSourceType.AI_JUDGE`
- **Transfer:** Emits `FutureWarning` and converts to `LLM_JUDGE`
- **Evidence:** `/testbed/libs/tracing/mlflow/entities/assessment_source.py:168-172`
- **Obligations:** R12

### E26: N17 (AssessmentSource.__post_init__) → N16 (AssessmentSourceType._standardize)
- **Kind:** CALL
- **Condition:** Always (on AssessmentSource instantiation)
- **Transfer:** `self.source_type` → standardized `source_type` string
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:76-78`
- **Obligations:** R12

### E27: N19 (Span.inputs) → N26 (SpanAttributeKey.INPUTS)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** `SpanAttributeKey.INPUTS` constant → `get_attribute()` key
- **Evidence:** `/testbed/libs/tracing/mlflow/entities/span.py:159`
- **Obligations:** R13

### E28: N20 (Span.outputs) → N27 (SpanAttributeKey.OUTPUTS)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** `SpanAttributeKey.OUTPUTS` constant → `get_attribute()` key
- **Evidence:** `/testbed/libs/tracing/mlflow/entities/span.py:164`
- **Obligations:** R14

### E29: N22 (TraceLocation.from_proto) → N7 (trace_location_from_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `proto` → `TraceLocation` entity
- **Evidence:** `/testbed/mlflow/entities/trace_location.py:246` — `return trace_location_from_proto(proto)`
- **Obligations:** R7

### E30: N23 (Expectation.from_proto) → N2 (get_trace_id_from_assessment_proto)
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `proto` → trace ID string
- **Evidence:** `/testbed/mlflow/entities/assessment.py` — `from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto`
- **Obligations:** R2

### E31: N21 (TraceInfo.to_proto) → N6 (trace_info_to_v4_proto)
- **Kind:** CALL
- **Condition:** `self._is_v4()` returns True (uc_schema is not None)
- **Transfer:** `self` → `pb.TraceInfo`
- **Evidence:** `/testbed/mlflow/entities/trace_info.py:108-111` — v4 branch calls `trace_info_to_v4_proto(self)`
- **Obligations:** R6

## L3. Verifiable Contracts

### C1: assessment_to_proto output type
- **Type:** Interface
- **Subject:** N1
- **Relation:** TYPE_IS
- **Expected:** `pb.Assessment` protobuf message
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:148`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, E1, E2, E3

### C2: assessment_to_proto maps required fields
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** `proto.assessment_name == assessment.name`, `proto.trace_id == parsed_trace_id`, `proto.source == assessment.source.to_proto()`, `proto.create_time.ToMilliseconds() == assessment.create_time_ms`, `proto.last_update_time.ToMilliseconds() == assessment.last_update_time_ms`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:149-162`
- **Observe:** RETURN_VALUE (field inspection)
- **Target:** `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, N24, N36, E1, E2

### C3: assessment_to_proto UC Schema trace location
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** When `parse_trace_id_v4` returns a non-None location, `proto.trace_location.uc_schema.catalog_name` and `schema_name` match the parsed location parts
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:151-158`
- **Observe:** RETURN_VALUE (field inspection with v4 trace ID)
- **Target:** `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, N24, E1, E3

### C4: assessment_to_proto optional fields
- **Type:** Dataflow
- **Relation:** PRESERVE
- **Expected:** `span_id`, `rationale`, `assessment_id`, `overrides`, `valid` are set on proto only when not None in assessment
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:164-185`
- **Observe:** RETURN_VALUE (field inspection with partial assessment)
- **Target:** `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, E2

### C5: assessment_to_proto metadata stringification
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** All metadata values in proto are strings (`str(value)`), regardless of original type
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:180-182`
- **Observe:** RETURN_VALUE (field inspection with non-string metadata values)
- **Target:** `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, E2

### C6: assessment_to_proto exactly one of expectation/feedback
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** Proto has `expectation` set iff assessment has expectation; proto has `feedback` set iff assessment has feedback; both never set simultaneously
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:174-177`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- **Obligations:** R1
- **Graph:** N1, E2

### C7: get_trace_id_from_assessment_proto UC Schema path
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** When proto has `trace_location.uc_schema`, returns `construct_trace_id_v4(f"{catalog_name}.{schema_name}", proto.trace_id)`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:192-200`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.get_trace_id_from_assessment_proto`
- **Obligations:** R2
- **Graph:** N2, N25, E4

### C8: get_trace_id_from_assessment_proto fallback
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** When proto lacks `trace_location` or `uc_schema`, returns `proto.trace_id` unchanged
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:201-203`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.get_trace_id_from_assessment_proto`
- **Obligations:** R2
- **Graph:** N2, E4

### C9: inference_table_location_to_proto mapping
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** `proto.full_table_name == location.full_table_name`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:44-47`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.inference_table_location_to_proto`
- **Obligations:** R3
- **Graph:** N3, N31, E5

### C10: mlflow_experiment_location_to_proto mapping
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** `proto.experiment_id == location.experiment_id`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:50-53`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.mlflow_experiment_location_to_proto`
- **Obligations:** R4
- **Graph:** N4, N32, E6

### C11: trace_from_proto structure
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** Returns `Trace` with `info` from `TraceInfo.from_proto(proto.trace_info)` and `data.spans` as list of `Span.from_otel_proto(span, location_id)` for each span
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:128-132`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_from_proto`
- **Obligations:** R5
- **Graph:** N5, N21, N35, E7, E8

### C12: trace_info_to_v4_proto trace_id parsing
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** When `trace_info.trace_location.uc_schema` is set, `proto.trace_id` is the parsed trace ID from `parse_trace_id_v4`; otherwise it is `trace_info.trace_id` unchanged
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:114-116`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto`
- **Obligations:** R6
- **Graph:** N6, N24, E9

### C13: trace_info_to_v4_proto timestamps
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** `proto.request_time.ToMilliseconds() == trace_info.request_time`; `proto.execution_duration` is set only when `trace_info.execution_duration is not None`, with `ToMilliseconds()` match
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:108-120`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto`
- **Obligations:** R6
- **Graph:** N6, E10, E11

### C14: trace_location_from_proto UC Schema dispatch
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** When `WhichOneof("identifier")` is `"uc_schema"`, returns `TraceLocation(type=UC_SCHEMA, uc_schema=UCSchemaLocation(...))`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:86-90`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N7, N10, E12

### C15: trace_location_from_proto MLflow Experiment dispatch
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** When `WhichOneof("identifier")` is `"mlflow_experiment"`, delegates to `MlflowExperimentLocation.from_proto`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:91-94`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N7, N32, E13

### C16: trace_location_from_proto Inference Table dispatch
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** When `WhichOneof("identifier")` is `"inference_table"`, delegates to `InferenceTableLocation.from_proto`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:95-98`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N7, N31, E14

### C17: trace_location_from_proto fallback
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** When no recognized identifier, returns `TraceLocation(TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:99-100`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- **Obligations:** R7
- **Graph:** N7, N33

### C18: trace_location_to_proto dispatch
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** For `UC_SCHEMA`, returns proto with `uc_schema` set; for `MLFLOW_EXPERIMENT`, returns proto with `mlflow_experiment` set; for `INFERENCE_TABLE`, returns proto with `inference_table` set
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:60-75`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_location_to_proto`
- **Obligations:** R8
- **Graph:** N8, N11, N4, N3, E15, E16, E17

### C19: trace_location_to_proto ValueError
- **Type:** Failure
- **Relation:** RAISES
- **Expected:** Raises `ValueError` for unsupported `trace_location.type`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:76-78`
- **Observe:** EXCEPTION
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_location_to_proto`
- **Obligations:** R8
- **Graph:** N8

### C20: trace_to_proto structure
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** `proto.trace_info` equals result of `trace.info.to_proto()`; `proto.spans` is list of `span.to_otel_proto()` results
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:136-139`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.trace_to_proto`
- **Obligations:** R9
- **Graph:** N9, N21, N35, E18, E19

### C21: uc_schema_location_from_proto fields
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** Returns `UCSchemaLocation` with `catalog_name` and `schema_name` from proto; optional `_otel_spans_table_name` and `_otel_logs_table_name` set via `HasField`
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:33-41`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.uc_schema_location_from_proto`
- **Obligations:** R10
- **Graph:** N10, N30, E20

### C22: uc_schema_location_to_proto fields
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** `proto.catalog_name`, `proto.schema_name`, `proto.otel_spans_table_name`, `proto.otel_logs_table_name` match entity fields
- **Evidence:** Interface Description 1; `/testbed/libs/tracing/mlflow/utils/databricks_tracing_utils.py:25-30`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.utils.databricks_tracing_utils.uc_schema_location_to_proto`
- **Obligations:** R11
- **Graph:** N11, N30, E21

### C23: AssessmentSourceType constants are strings
- **Type:** Interface
- **Subject:** N12 class attributes
- **Relation:** TYPE_IS
- **Expected:** `SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `AI_JUDGE`, `HUMAN`, `CODE` are all `str` instances
- **Evidence:** Task Interface Description 2 notes; `/testbed/mlflow/entities/assessment_source.py:153-158`
- **Observe:** FIELD_READ
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType`
- **Obligations:** R12
- **Graph:** N12

### C24: AssessmentSourceType._SOURCE_TYPES excludes AI_JUDGE
- **Type:** Interface
- **Subject:** N12 `_SOURCE_TYPES`
- **Relation:** NE
- **Expected:** `AI_JUDGE` not in `_SOURCE_TYPES`; `_SOURCE_TYPES` contains `[SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]`
- **Evidence:** Task Interface Description 2 notes; `/testbed/mlflow/entities/assessment_source.py:158`
- **Observe:** FIELD_READ
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType._SOURCE_TYPES`
- **Obligations:** R12
- **Graph:** N12

### C25: AssessmentSourceType._parse normalization
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** `_parse("llm_judge")` returns `"LLM_JUDGE"`; `_parse("Human")` returns `"HUMAN"`
- **Evidence:** Interface Description 2; `/testbed/libs/tracing/mlflow/entities/assessment_source.py:165-166`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- **Obligations:** R12
- **Graph:** N14, E22, E24, E25

### C26: AssessmentSourceType._parse AI_JUDGE deprecation
- **Type:** SideEffect
- **Relation:** EQ
- **Expected:** `_parse("AI_JUDGE")` emits `FutureWarning` and returns `"LLM_JUDGE"`; `_parse("ai_judge")` emits `FutureWarning` and returns `"LLM_JUDGE"`
- **Evidence:** Interface Description 2; `/testbed/libs/tracing/mlflow/entities/assessment_source.py:168-173`
- **Observe:** RETURN_VALUE + SIDE_EFFECT (warning)
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- **Obligations:** R12
- **Graph:** N14, E25

### C27: AssessmentSourceType._parse invalid type
- **Type:** Failure
- **Relation:** RAISES
- **Expected:** `_parse("INVALID")` raises `MlflowException` with error_code `INVALID_PARAMETER_VALUE`
- **Evidence:** Interface Description 2; `/testbed/libs/tracing/mlflow/entities/assessment_source.py:174-180`
- **Observe:** EXCEPTION
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType._parse`
- **Obligations:** R12
- **Graph:** N14, N28, E24

### C28: AssessmentSourceType.__init__ stores parsed value
- **Type:** State
- **Relation:** EQ
- **Expected:** `AssessmentSourceType("LLM_JUDGE")._source_type == "LLM_JUDGE"`
- **Evidence:** Interface Description 2; `/testbed/libs/tracing/mlflow/entities/assessment_source.py:161-162`
- **Observe:** STATE_READ
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType`
- **Obligations:** R12
- **Graph:** N13, N14, E22

### C29: AssessmentSourceType.__str__ returns stored value
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** `str(AssessmentSourceType("code")) == "CODE"`
- **Evidence:** Interface Description 2; `/testbed/libs/tracing/mlflow/entities/assessment_source.py:183-184`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType.__str__`
- **Obligations:** R12
- **Graph:** N15, E23

### C30: AssessmentSourceType._standardize returns string
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** `AssessmentSourceType._standardize("human")` returns `"HUMAN"`; `AssessmentSourceType._standardize("AI_JUDGE")` returns `"LLM_JUDGE"` with warning
- **Evidence:** Interface Description 2; `/testbed/libs/tracing/mlflow/entities/assessment_source.py:186-187`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.entities.assessment_source.AssessmentSourceType._standardize`
- **Obligations:** R12
- **Graph:** N16, N13, N15, E23

### C31: AssessmentSource.__post_init__ calls _standardize
- **Type:** Dataflow
- **Relation:** EQ
- **Expected:** After `AssessmentSource(source_type="llm_judge", source_id="x")`, `source.source_type == "LLM_JUDGE"`
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:76-78`
- **Observe:** FIELD_READ
- **Target:** `mlflow.entities.assessment_source.AssessmentSource`
- **Obligations:** R12
- **Graph:** N17, N16, E26

### C32: Span.inputs returns deserialized attribute
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** For a span with `mlflow.spanInputs` attribute set to serialized value, `span.inputs` returns the deserialized value (e.g., `"abc"` → `"abc"`, `{"x": 1}` → `{"x": 1}`)
- **Evidence:** Interface Description 3; `/testbed/tests/entities/test_trace.py:544`; `/testbed/libs/tracing/mlflow/entities/span.py:157-159`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.entities.span.Span.inputs`
- **Obligations:** R13
- **Graph:** N19, N26, E27

### C33: Span.outputs returns deserialized attribute
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** For a span with `mlflow.spanOutputs` attribute set to serialized value, `span.outputs` returns the deserialized value (e.g., `"def"` → `"def"`, `{"result": 42}` → `{"result": 42}`)
- **Evidence:** Interface Description 3; `/testbed/tests/entities/test_trace.py:545`; `/testbed/libs/tracing/mlflow/entities/span.py:162-164`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.entities.span.Span.outputs`
- **Obligations:** R14
- **Graph:** N20, N27, E28

### C34: Span.inputs returns None when not set
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** For a span without `mlflow.spanInputs` attribute, `span.inputs` returns `None`
- **Evidence:** Interface Description 3 ("Returns None if no inputs were set"); `_CachedSpanAttributesRegistry.get()` returns `None` for missing keys per `/testbed/mlflow/entities/span.py`
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.entities.span.Span.inputs`
- **Obligations:** R13
- **Graph:** N19, N26, E27

### C35: Span.outputs returns None when not set
- **Type:** Behavior
- **Relation:** EQ
- **Expected:** For a span without `mlflow.spanOutputs` attribute, `span.outputs` returns `None`
- **Evidence:** Interface Description 3 ("Returns None if no outputs were set"); `_CachedSpanAttributesRegistry.get()` returns `None` for missing keys
- **Observe:** RETURN_VALUE
- **Target:** `mlflow.entities.span.Span.outputs`
- **Obligations:** R14
- **Graph:** N20, N27, E28

### C36: TraceLocation.from_proto delegates to trace_location_from_proto
- **Type:** Dataflow
- **Relation:** CALLS
- **Expected:** `TraceLocation.from_proto(proto)` calls and returns result of `trace_location_from_proto(proto)`
- **Evidence:** `/testbed/mlflow/entities/trace_location.py:246`
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** `mlflow.entities.trace_location.TraceLocation.from_proto`
- **Obligations:** R7
- **Graph:** N22, N7, E29

### C37: TraceInfo.to_proto delegates to trace_info_to_v4_proto for v4
- **Type:** Dataflow
- **Relation:** CALLS
- **Expected:** When `trace_info._is_v4()` is True (uc_schema present), `TraceInfo.to_proto()` calls `trace_info_to_v4_proto(self)`
- **Evidence:** `/testbed/mlflow/entities/trace_info.py:108-111`
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** `mlflow.entities.trace_info.TraceInfo.to_proto`
- **Obligations:** R6
- **Graph:** N21, N6, E31

### C38: Expectation.from_proto calls get_trace_id_from_assessment_proto
- **Type:** Dataflow
- **Relation:** CALLS
- **Expected:** `Expectation.from_proto(proto)` calls `get_trace_id_from_assessment_proto(proto)` to obtain the trace ID
- **Evidence:** `/testbed/mlflow/entities/assessment.py` — import and call in `Expectation.from_proto`
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** `mlflow.entities.assessment.Expectation.from_proto`
- **Obligations:** R2
- **Graph:** N23, N2, E30
