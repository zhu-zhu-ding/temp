"""
Executable behavior spec for SearchTracesTool and AssessmentSourceType.

Proves what each requirement visibly does: return values, state transitions,
failures, side effects, defaults, boundaries, and compatibility.

Covers L3 State, Behavior, Failure, SideEffect contracts.
Each check_* function references its contract IDs in a ``# Contracts: Cn``
comment.  Does not modify production code.
"""

import sys
import warnings
from unittest import mock

# ---------------------------------------------------------------------------
# Safe imports – symbols that may not exist yet in the main stubs
# ---------------------------------------------------------------------------

from mlflow.entities.assessment import AssessmentSource, Expectation, Feedback
from mlflow.entities.assessment_error import AssessmentError
from mlflow.entities.assessment_source import AssessmentSourceType
from mlflow.entities.trace import Trace, TraceData
from mlflow.entities.trace_info import TraceInfo
from mlflow.entities.trace_location import (
    MlflowExperimentLocation,
    TraceLocation,
    TraceLocationType,
    UCSchemaLocation,
)
from mlflow.entities.trace_state import TraceState
from mlflow.exceptions import MlflowException
from mlflow.genai.judges.tools.types import (
    JudgeToolExpectation,
    JudgeToolFeedback,
    JudgeToolTraceInfo,
)
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, ErrorCode

# These symbols are stubs in the main repo; import may fail until implemented.
try:
    from mlflow.genai.judges.tools.search_traces import (
        SearchTracesTool,
        _convert_assessments_to_tool_types,
        _get_experiment_id,
    )
except ImportError:
    SearchTracesTool = None
    _convert_assessments_to_tool_types = None
    _get_experiment_id = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _require(cond, msg):
    if not cond:
        raise AssertionError(msg)


def _make_valid_trace(experiment_id="exp-42"):
    return Trace(
        info=TraceInfo(
            trace_id="trace-abc",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=MlflowExperimentLocation(
                    experiment_id=experiment_id,
                ),
            ),
            request_time=1700000000000,
            state=TraceState.OK,
            execution_duration=500,
        ),
        data=TraceData(spans=[]),
    )


def _make_trace_without_location():
    return Trace(
        info=TraceInfo(
            trace_id="trace-no-loc",
            trace_location=None,
            request_time=1700000000000,
            state=TraceState.OK,
        ),
        data=TraceData(spans=[]),
    )


def _make_trace_uc_schema():
    return Trace(
        info=TraceInfo(
            trace_id="trace-uc",
            trace_location=TraceLocation(
                type=TraceLocationType.UC_SCHEMA,
                uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
            ),
            request_time=1700000000000,
            state=TraceState.OK,
        ),
        data=TraceData(spans=[]),
    )


def _make_trace_no_experiment_id():
    return Trace(
        info=TraceInfo(
            trace_id="trace-no-exp",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=MlflowExperimentLocation(experiment_id=None),
            ),
            request_time=1700000000000,
            state=TraceState.OK,
        ),
        data=TraceData(spans=[]),
    )


def _make_expectation(name="correctness", value="yes"):
    exp = Expectation(
        name=name,
        source=AssessmentSource(source_type="HUMAN", source_id="tester"),
        value=value,
        rationale="looks good",
        span_id="span-1",
    )
    return exp


def _make_feedback(name="quality", value=0.9, with_error=False):
    err = None
    if with_error:
        err = AssessmentError(
            error_code="RATE_LIMIT",
            error_message="Too many requests",
            stack_trace="line 42\nline 99",
        )
    fb = Feedback(
        name=name,
        source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
        value=value,
        rationale="seems fine",
        span_id="span-2",
    )
    if err is not None:
        fb.error = err
    return fb


def _make_search_trace_result(trace_id="result-1", assessments=None):
    """Build a minimal Trace as returned by mlflow.search_traces()."""
    td = TraceData(spans=[])
    td.request = '{"question": "hello"}'
    td.response = '{"answer": "world"}'

    info = TraceInfo(
        trace_id=trace_id,
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-42"),
        ),
        request_time=1700000000000,
        state=TraceState.OK,
        execution_duration=300,
        assessments=assessments or [],
    )
    return Trace(info=info, data=td)


def _instantiate_tool():
    """Return a SearchTracesTool instance or raise with a clear message."""
    _require(SearchTracesTool is not None,
             "SearchTracesTool class not available (stub not yet implemented)")
    try:
        return SearchTracesTool()
    except TypeError as exc:
        raise AssertionError(
            f"SearchTracesTool cannot be instantiated (abstract methods missing): {exc}"
        )


# ============================================================================
# C6: _get_experiment_id raises on missing trace_location
# ============================================================================
# Contracts: C6
def check_c6_raises_no_trace_location() -> None:
    """MlflowException(INVALID_PARAMETER_VALUE) when trace_location is None."""
    _require(_get_experiment_id is not None,
             "_get_experiment_id not available (stub not yet implemented)")
    trace = _make_trace_without_location()
    try:
        _get_experiment_id(trace)
        raise AssertionError("Expected MlflowException but none was raised")
    except MlflowException as exc:
        _require(exc.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE),
                 f"Expected INVALID_PARAMETER_VALUE, got {exc.error_code!r}")
        msg = (exc.message if hasattr(exc, 'message') else str(exc)).lower()
        _require("trace location" in msg,
                 f"Message missing 'trace location': {exc}")
    print("PASS: C6 - _get_experiment_id raises on missing trace_location")


# ============================================================================
# C7: _get_experiment_id raises on non-MLflow-experiment location
# ============================================================================
# Contracts: C7
def check_c7_raises_wrong_location_type() -> None:
    """MlflowException when location type != MLFLOW_EXPERIMENT."""
    _require(_get_experiment_id is not None, "_get_experiment_id not available")
    trace = _make_trace_uc_schema()
    try:
        _get_experiment_id(trace)
        raise AssertionError("Expected MlflowException but none was raised")
    except MlflowException as exc:
        _require(exc.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE),
                 f"Expected INVALID_PARAMETER_VALUE, got {exc.error_code!r}")
    print("PASS: C7 - _get_experiment_id raises on non-MLflow-experiment location")


# ============================================================================
# C8: _get_experiment_id raises on missing experiment_id
# ============================================================================
# Contracts: C8
def check_c8_raises_no_experiment_id() -> None:
    """MlflowException when experiment_id is None/falsy in MLflow experiment location."""
    _require(_get_experiment_id is not None, "_get_experiment_id not available")
    trace = _make_trace_no_experiment_id()
    try:
        _get_experiment_id(trace)
        raise AssertionError("Expected MlflowException but none was raised")
    except MlflowException as exc:
        _require(exc.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE),
                 f"Expected INVALID_PARAMETER_VALUE, got {exc.error_code!r}")
        msg = (exc.message if hasattr(exc, 'message') else str(exc)).lower()
        _require("experiment_id" in msg,
                 f"Message missing 'experiment_id': {exc}")
    print("PASS: C8 - _get_experiment_id raises on missing experiment_id")


# ============================================================================
# C9: _get_experiment_id returns experiment_id on valid trace
# ============================================================================
# Contracts: C9
def check_c9_returns_experiment_id() -> None:
    """Returns the experiment_id string for a valid MLflow experiment trace."""
    _require(_get_experiment_id is not None, "_get_experiment_id not available")
    trace = _make_valid_trace("my-experiment-99")
    result = _get_experiment_id(trace)
    _require(result == "my-experiment-99",
             f"Expected 'my-experiment-99', got {result!r}")
    print("PASS: C9 - _get_experiment_id returns experiment_id on valid trace")


# ============================================================================
# C10: invoke defaults order_by to ["timestamp ASC"]
# ============================================================================
# Contracts: C10
def check_c10_invoke_defaults_order_by() -> None:
    """When order_by=None, mlflow.search_traces receives ['timestamp ASC']."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-defaults")
    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = []
        tool.invoke(trace)
    _require(mock_search.call_count == 1, "search_traces not called exactly once")
    call_kwargs = mock_search.call_args.kwargs
    _require(call_kwargs["order_by"] == ["timestamp ASC"],
             f"Expected default ['timestamp ASC'], got {call_kwargs['order_by']!r}")
    print("PASS: C10 - invoke defaults order_by to ['timestamp ASC']")


# ============================================================================
# C11: invoke calls mlflow.search_traces with correct locations
# ============================================================================
# Contracts: C11
def check_c11_invoke_locations_argument() -> None:
    """mlflow.search_traces receives locations=[experiment_id]."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-locations-test")
    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = []
        tool.invoke(trace)
    call_kwargs = mock_search.call_args.kwargs
    _require("locations" in call_kwargs, "locations kwarg missing from search_traces call")
    _require(call_kwargs["locations"] == ["exp-locations-test"],
             f"Expected locations=['exp-locations-test'], got {call_kwargs['locations']!r}")
    print("PASS: C11 - invoke calls search_traces with locations=[experiment_id]")


# ============================================================================
# C12: invoke wraps search errors in MlflowException
# ============================================================================
# Contracts: C12
def check_c12_invoke_wraps_search_errors() -> None:
    """When mlflow.search_traces raises, invoke raises MlflowException(INTERNAL_ERROR)."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-search-error")
    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.side_effect = RuntimeError("backend offline")
        try:
            tool.invoke(trace)
            raise AssertionError("Expected MlflowException but none was raised")
        except MlflowException as exc:
            _require(exc.error_code == "INTERNAL_ERROR",
                     f"Expected INTERNAL_ERROR, got {exc.error_code!r}")
            _require("Failed to search traces" in str(exc),
                     f"Expected 'Failed to search traces' prefix, got: {exc}")
    print("PASS: C12 - invoke wraps search errors in MlflowException(INTERNAL_ERROR)")


# ============================================================================
# C13: invoke converts traces to JudgeToolTraceInfo list
# ============================================================================
# Contracts: C13
def check_c13_invoke_converts_to_judge_tool_trace_info() -> None:
    """Returns list[JudgeToolTraceInfo] with correct field mapping from Trace."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-convert")
    result_trace1 = _make_search_trace_result("tr-aaa")
    result_trace2 = _make_search_trace_result("tr-bbb")

    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = [result_trace1, result_trace2]
        results = tool.invoke(trace)

    _require(isinstance(results, list), f"Expected list, got {type(results)}")
    _require(len(results) == 2, f"Expected 2 results, got {len(results)}")
    _require(all(isinstance(r, JudgeToolTraceInfo) for r in results),
             "All results must be JudgeToolTraceInfo instances")
    _require(results[0].trace_id == "tr-aaa")
    _require(results[0].request_time == 1700000000000)
    _require(results[0].state == TraceState.OK)
    _require(results[0].request == '{"question": "hello"}')
    _require(results[0].response == '{"answer": "world"}')
    _require(results[0].execution_duration == 300)
    _require(results[0].assessments == [])
    _require(results[1].trace_id == "tr-bbb")
    print("PASS: C13 - invoke converts traces to JudgeToolTraceInfo list")


# ============================================================================
# C14: invoke skips failed trace conversions
# ============================================================================
# Contracts: C14
def check_c14_invoke_skips_failed_conversions() -> None:
    """When one trace conversion raises, others are returned; warning is logged."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-skip")

    good_trace = _make_search_trace_result("good-one")
    bad_trace = _make_search_trace_result("bad-one")
    bad_trace.info = None  # accessing .info.trace_id will raise

    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = [good_trace, bad_trace]
        with mock.patch(
            "mlflow.genai.judges.tools.search_traces._logger"
        ) as mock_logger:
            results = tool.invoke(trace)

    _require(len(results) == 1, f"Expected 1 good trace, got {len(results)}")
    _require(results[0].trace_id == "good-one")
    warning_calls = [
        c for c in mock_logger.warning.call_args_list if "bad-one" in str(c)
    ]
    _require(len(warning_calls) >= 1,
             f"No warning logged for bad-one; calls: {mock_logger.warning.call_args_list}")
    print("PASS: C14 - invoke skips failed trace conversions and logs warnings")


# ============================================================================
# C15: _convert_assessments_to_tool_types converts Expectation correctly
# ============================================================================
# Contracts: C15
def check_c15_convert_expectation() -> None:
    """Expectation -> JudgeToolExpectation with all fields mapped."""
    _require(_convert_assessments_to_tool_types is not None,
             "_convert_assessments_to_tool_types not available")
    exp = _make_expectation(name="accuracy", value="high")
    exp.assessment_id = "asmt-1"
    result = _convert_assessments_to_tool_types([exp])

    _require(len(result) == 1, f"Expected 1 result, got {len(result)}")
    converted = result[0]
    _require(isinstance(converted, JudgeToolExpectation),
             f"Expected JudgeToolExpectation, got {type(converted)}")
    _require(converted.name == "accuracy")
    _require(converted.source == "HUMAN",
             f"Expected source='HUMAN', got {converted.source!r}")
    _require(converted.rationale == "looks good")
    _require(converted.span_id == "span-1")
    _require(converted.assessment_id == "asmt-1")
    _require(converted.value == "high")
    print("PASS: C15 - Expectation converted to JudgeToolExpectation correctly")


# ============================================================================
# C16: _convert_assessments_to_tool_types converts Feedback correctly (with error)
# ============================================================================
# Contracts: C16
def check_c16_convert_feedback_with_error() -> None:
    """Feedback with AssessmentError -> JudgeToolFeedback including error fields."""
    _require(_convert_assessments_to_tool_types is not None,
             "_convert_assessments_to_tool_types not available")
    fb = _make_feedback(name="relevance", value=0.8, with_error=True)
    fb.assessment_id = "asmt-2"
    fb.overrides = "asmt-old"
    fb.valid = False

    result = _convert_assessments_to_tool_types([fb])

    _require(len(result) == 1)
    converted = result[0]
    _require(isinstance(converted, JudgeToolFeedback),
             f"Expected JudgeToolFeedback, got {type(converted)}")
    _require(converted.name == "relevance")
    _require(converted.source == "LLM_JUDGE")
    _require(converted.rationale == "seems fine")
    _require(converted.span_id == "span-2")
    _require(converted.assessment_id == "asmt-2")
    _require(converted.value == 0.8)
    _require(converted.error_code == "RATE_LIMIT")
    _require(converted.error_message == "Too many requests")
    _require(converted.stack_trace == "line 42\nline 99")
    _require(converted.overrides == "asmt-old")
    _require(converted.valid is False)
    print("PASS: C16 - Feedback with error converted correctly")


# ============================================================================
# C17: _convert_assessments_to_tool_types converts Feedback correctly (without error)
# ============================================================================
# Contracts: C17
def check_c17_convert_feedback_without_error() -> None:
    """Feedback without error -> JudgeToolFeedback with None error fields."""
    _require(_convert_assessments_to_tool_types is not None,
             "_convert_assessments_to_tool_types not available")
    fb = _make_feedback(name="clarity", value="good", with_error=False)
    fb.assessment_id = "asmt-3"
    fb.overrides = None
    fb.valid = None

    result = _convert_assessments_to_tool_types([fb])

    _require(len(result) == 1)
    converted = result[0]
    _require(isinstance(converted, JudgeToolFeedback))
    _require(converted.name == "clarity")
    _require(converted.error_code is None)
    _require(converted.error_message is None)
    _require(converted.stack_trace is None)
    _require(converted.overrides is None)
    _require(converted.valid is None)
    print("PASS: C17 - Feedback without error has None error fields")


# ============================================================================
# C18: AssessmentSourceType._standardize normalizes case
# ============================================================================
# Contracts: C18
def check_c18_standardize_normalizes_case() -> None:
    """Lowercase/mixed-case input is uppercased."""
    _require(hasattr(AssessmentSourceType, '_standardize'),
             "AssessmentSourceType._standardize not implemented")
    _require(AssessmentSourceType._standardize("human") == "HUMAN")
    _require(AssessmentSourceType._standardize("Human") == "HUMAN")
    _require(AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE")
    _require(AssessmentSourceType._standardize("code") == "CODE")
    print("PASS: C18 - _standardize normalizes case to uppercase")


# ============================================================================
# C19: AssessmentSourceType._standardize handles deprecated AI_JUDGE
# ============================================================================
# Contracts: C19
def check_c19_standardize_deprecated_ai_judge() -> None:
    """AI_JUDGE -> LLM_JUDGE with FutureWarning."""
    _require(hasattr(AssessmentSourceType, '_standardize'),
             "AssessmentSourceType._standardize not implemented")
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")

    _require(result == "LLM_JUDGE",
             f"Expected 'LLM_JUDGE', got {result!r}")
    future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
    _require(len(future_warnings) >= 1,
             f"Expected at least one FutureWarning, got {len(future_warnings)}")
    msg = str(future_warnings[0].message).lower()
    _require("deprecated" in msg or "ai_judge" in msg,
             f"Warning message does not mention deprecation: {future_warnings[0].message}")
    print("PASS: C19 - _standardize handles deprecated AI_JUDGE with FutureWarning")


# ============================================================================
# C20: AssessmentSourceType._standardize raises on invalid type
# ============================================================================
# Contracts: C20
def check_c20_standardize_raises_on_invalid() -> None:
    """Invalid source type raises MlflowException(INVALID_PARAMETER_VALUE)."""
    _require(hasattr(AssessmentSourceType, '_standardize'),
             "AssessmentSourceType._standardize not implemented")
    try:
        AssessmentSourceType._standardize("NOT_A_REAL_TYPE")
        raise AssertionError("Expected MlflowException but none was raised")
    except MlflowException as exc:
        _require(exc.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE),
                 f"Expected INVALID_PARAMETER_VALUE, got {exc.error_code!r}")
    print("PASS: C20 - _standardize raises MlflowException on invalid type")


# ============================================================================
# C21: AssessmentSource.__post_init__ standardizes source_type
# ============================================================================
# Contracts: C21
# Reference: tests/genai/judges/test_builtin.py (uses AssessmentSource with source_type strings)
# Perspective: state transition in __post_init__ normalizes the source_type field
def check_c21_assessment_source_post_init() -> None:
    """AssessmentSource(source_type='llm_judge') ends up with 'LLM_JUDGE'."""
    source = AssessmentSource(source_type="llm_judge")
    _require(source.source_type == "LLM_JUDGE",
             f"Expected 'LLM_JUDGE', got {source.source_type!r}")

    source2 = AssessmentSource(source_type="human")
    _require(source2.source_type == "HUMAN")

    source3 = AssessmentSource(source_type="CODE")
    _require(source3.source_type == "CODE")
    print("PASS: C21 - AssessmentSource.__post_init__ standardizes source_type")


# ============================================================================
# Supplemental behavior checks: defaults, edge cases, additional forwarding
# ============================================================================

def check_invoke_forwards_filter_string() -> None:
    """filter_string kwarg is forwarded to mlflow.search_traces."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-filter")
    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = []
        tool.invoke(trace, filter_string='status = "OK"')
    _require(mock_search.call_args.kwargs["filter_string"] == 'status = "OK"')
    print("PASS: invoke forwards filter_string to mlflow.search_traces")


def check_invoke_forwards_max_results() -> None:
    """max_results kwarg is forwarded to mlflow.search_traces."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-max")
    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = []
        tool.invoke(trace, max_results=5)
    _require(mock_search.call_args.kwargs["max_results"] == 5)
    print("PASS: invoke forwards max_results to mlflow.search_traces")


def check_invoke_return_type_is_list() -> None:
    """mlflow.search_traces is always called with return_type='list'."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-rt")
    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = []
        tool.invoke(trace)
    _require(mock_search.call_args.kwargs.get("return_type") == "list")
    print("PASS: invoke calls search_traces with return_type='list'")


def check_convert_empty_assessments() -> None:
    """Empty assessment list returns empty list."""
    _require(_convert_assessments_to_tool_types is not None,
             "_convert_assessments_to_tool_types not available")
    result = _convert_assessments_to_tool_types([])
    _require(result == [], f"Expected empty list, got {result!r}")
    print("PASS: _convert_assessments_to_tool_types handles empty list")


def check_convert_mixed_assessments() -> None:
    """Mixed Expectation and Feedback list converts correctly."""
    _require(_convert_assessments_to_tool_types is not None,
             "_convert_assessments_to_tool_types not available")
    exp = _make_expectation(name="e1", value="yes")
    exp.assessment_id = "a1"
    fb = _make_feedback(name="f1", value=0.5, with_error=False)
    fb.assessment_id = "a2"

    result = _convert_assessments_to_tool_types([exp, fb])

    _require(len(result) == 2)
    _require(isinstance(result[0], JudgeToolExpectation))
    _require(isinstance(result[1], JudgeToolFeedback))
    _require(result[0].name == "e1")
    _require(result[1].name == "f1")
    print("PASS: _convert_assessments_to_tool_types handles mixed assessments")


def check_invoke_returns_empty_list_for_no_results() -> None:
    """When search returns no traces, invoke returns empty list."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-empty")
    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = []
        results = tool.invoke(trace)
    _require(results == [], f"Expected empty list, got {results!r}")
    print("PASS: invoke returns empty list when no traces found")


def check_invoke_with_assessments_in_result() -> None:
    """Trace assessments are converted and included in JudgeToolTraceInfo."""
    tool = _instantiate_tool()
    trace = _make_valid_trace("exp-with-asmt")
    exp = _make_expectation(name="correctness", value="yes")
    exp.assessment_id = "asmt-1"
    result_trace = _make_search_trace_result("tr-with-asmt", assessments=[exp])

    with mock.patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces"
    ) as mock_search:
        mock_search.return_value = [result_trace]
        results = tool.invoke(trace)

    _require(len(results) == 1)
    _require(len(results[0].assessments) == 1)
    asmt = results[0].assessments[0]
    _require(isinstance(asmt, JudgeToolExpectation))
    _require(asmt.name == "correctness")
    _require(asmt.source == "HUMAN")
    print("PASS: invoke includes converted assessments in trace info")


# ============================================================================
# Runner
# ============================================================================

def main() -> None:
    checks = [
        # _get_experiment_id
        check_c6_raises_no_trace_location,
        check_c7_raises_wrong_location_type,
        check_c8_raises_no_experiment_id,
        check_c9_returns_experiment_id,
        # invoke behavior
        check_c10_invoke_defaults_order_by,
        check_c11_invoke_locations_argument,
        check_c12_invoke_wraps_search_errors,
        check_c13_invoke_converts_to_judge_tool_trace_info,
        check_c14_invoke_skips_failed_conversions,
        # _convert_assessments_to_tool_types
        check_c15_convert_expectation,
        check_c16_convert_feedback_with_error,
        check_c17_convert_feedback_without_error,
        # AssessmentSourceType._standardize
        check_c18_standardize_normalizes_case,
        check_c19_standardize_deprecated_ai_judge,
        check_c20_standardize_raises_on_invalid,
        # AssessmentSource.__post_init__
        check_c21_assessment_source_post_init,
        # Supplemental
        check_invoke_forwards_filter_string,
        check_invoke_forwards_max_results,
        check_invoke_return_type_is_list,
        check_convert_empty_assessments,
        check_convert_mixed_assessments,
        check_invoke_returns_empty_list_for_no_results,
        check_invoke_with_assessments_in_result,
    ]
    failed = 0
    for check in checks:
        try:
            check()
        except Exception as exc:
            print(f"FAIL: {check.__name__}: {exc}", file=sys.stderr)
            failed += 1
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
