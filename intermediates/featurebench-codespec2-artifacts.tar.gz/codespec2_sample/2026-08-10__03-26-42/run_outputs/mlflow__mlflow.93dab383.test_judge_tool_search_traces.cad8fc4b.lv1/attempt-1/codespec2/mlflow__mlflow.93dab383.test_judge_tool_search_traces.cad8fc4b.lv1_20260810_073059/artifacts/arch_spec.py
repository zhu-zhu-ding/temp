"""
Executable architecture spec for SearchTracesTool and AssessmentSourceType.

Proves public interface structure and graph connectivity (L2 CALL/CONTROL
paths and L3 Interface/Dataflow contracts).  Does not modify production code.

Each check_* function covers one or more L3 contracts; contract IDs are
listed in a ``# Contracts: Cn`` comment above each function.
"""

import sys
import warnings
from unittest import mock

# ---------------------------------------------------------------------------
# Safe imports – symbols that may not exist yet in the main stubs
# ---------------------------------------------------------------------------

from mlflow.entities.assessment import AssessmentSource, Expectation, Feedback
from mlflow.entities.assessment_error import AssessmentError
from mlflow.entities.assessment_source import AssessmentSourceType
from mlflow.entities.trace import Trace, TraceData
from mlflow.entities.trace_info import TraceInfo
from mlflow.entities.trace_location import (
    MlflowExperimentLocation,
    TraceLocation,
    TraceLocationType,
)
from mlflow.entities.trace_state import TraceState
from mlflow.exceptions import MlflowException
from mlflow.genai.judges.tools.base import JudgeTool
from mlflow.genai.judges.tools.constants import ToolNames
from mlflow.genai.judges.tools.types import (
    JudgeToolExpectation,
    JudgeToolFeedback,
    JudgeToolTraceInfo,
)
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, ErrorCode
from mlflow.types.llm import (
    FunctionToolDefinition,
    ParamProperty,
    ToolDefinition,
    ToolParamsSchema,
)

# Symbols that are stubs in the main repo – import may fail or the class may
# be abstract until the implementation is completed.
try:
    from mlflow.genai.judges.tools.search_traces import (
        SearchTracesTool,
        _convert_assessments_to_tool_types,
        _get_experiment_id,
    )
except ImportError:
    SearchTracesTool = None
    _convert_assessments_to_tool_types = None
    _get_experiment_id = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_valid_trace(experiment_id="exp-42"):
    """Create a minimal valid Trace for MLflow experiment context."""
    return Trace(
        info=TraceInfo(
            trace_id="trace-abc",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=MlflowExperimentLocation(
                    experiment_id=experiment_id,
                ),
            ),
            request_time=1700000000000,
            state=TraceState.OK,
            execution_duration=500,
        ),
        data=TraceData(spans=[]),
    )


def _require(cond, msg):
    """Assert-or-die helper."""
    if not cond:
        raise AssertionError(msg)


# ============================================================================
# C1: SearchTracesTool.name returns constant
# ============================================================================
# Contracts: C1
def check_c1_name_returns_constant() -> None:
    """The .name property returns ToolNames._SEARCH_TRACES ('_search_traces')."""
    _require(SearchTracesTool is not None,
             "SearchTracesTool class not available (stub not yet implemented)")
    try:
        tool = SearchTracesTool()
    except TypeError as exc:
        raise AssertionError(
            f"SearchTracesTool cannot be instantiated (abstract methods missing): {exc}"
        )
    _require(tool.name == "_search_traces",
             f"Expected '_search_traces', got {tool.name!r}")
    _require(tool.name == ToolNames._SEARCH_TRACES,
             f"Expected {ToolNames._SEARCH_TRACES!r}, got {tool.name!r}")
    print("PASS: C1 - SearchTracesTool.name returns '_search_traces'")


# ============================================================================
# C2: SearchTracesTool.get_definition returns proper ToolDefinition
# ============================================================================
# Contracts: C2
def check_c2_get_definition_structure() -> None:
    """get_definition() returns ToolDefinition with type='function', correct name, params."""
    _require(SearchTracesTool is not None, "SearchTracesTool not available")
    try:
        tool = SearchTracesTool()
    except TypeError as exc:
        raise AssertionError(f"SearchTracesTool abstract: {exc}")
    definition = tool.get_definition()

    _require(isinstance(definition, ToolDefinition),
             f"Expected ToolDefinition, got {type(definition)}")
    _require(definition.type == "function",
             f"Expected type='function', got {definition.type!r}")
    _require(definition.function.name == "_search_traces",
             f"Expected name='_search_traces', got {definition.function.name!r}")
    _require(definition.function.name == ToolNames._SEARCH_TRACES,
             "Name does not match ToolNames._SEARCH_TRACES")
    _require(definition.function.parameters is not None,
             "Expected non-None parameters")
    _require(definition.function.parameters.type == "object",
             f"Expected parameters.type='object', got {definition.function.parameters.type!r}")
    _require(definition.function.parameters.required == [],
             f"Expected empty required list, got {definition.function.parameters.required!r}")
    print("PASS: C2 - get_definition returns proper ToolDefinition structure")


# ============================================================================
# C3: get_definition includes filter_string param
# ============================================================================
# Contracts: C3
def check_c3_filter_string_param() -> None:
    """filter_string property: type='string', default=None."""
    _require(SearchTracesTool is not None, "SearchTracesTool not available")
    try:
        tool = SearchTracesTool()
    except TypeError as exc:
        raise AssertionError(f"SearchTracesTool abstract: {exc}")
    props = tool.get_definition().function.parameters.properties
    _require("filter_string" in props,
             f"filter_string missing from properties: {list(props.keys())}")
    fs = props["filter_string"]
    _require(isinstance(fs, ParamProperty),
             f"Expected ParamProperty, got {type(fs)}")
    _require(fs.type == "string",
             f"Expected type='string', got {fs.type!r}")
    _require(fs.default is None,
             f"Expected default=None, got {fs.default!r}")
    print("PASS: C3 - filter_string param: type=string, default=None")


# ============================================================================
# C4: get_definition includes order_by param with default
# ============================================================================
# Contracts: C4
def check_c4_order_by_param() -> None:
    """order_by property: type='array', items.type='string', default=['timestamp ASC']."""
    _require(SearchTracesTool is not None, "SearchTracesTool not available")
    try:
        tool = SearchTracesTool()
    except TypeError as exc:
        raise AssertionError(f"SearchTracesTool abstract: {exc}")
    props = tool.get_definition().function.parameters.properties
    _require("order_by" in props,
             f"order_by missing from properties: {list(props.keys())}")
    ob = props["order_by"]
    _require(ob.type == "array",
             f"Expected type='array', got {ob.type!r}")
    _require(ob.items is not None, "Expected non-None items for array type")
    _require(ob.items.type == "string",
             f"Expected items.type='string', got {ob.items.type!r}")
    _require(ob.default == ["timestamp ASC"],
             f"Expected default=['timestamp ASC'], got {ob.default!r}")
    print("PASS: C4 - order_by param: type=array, items=string, default=['timestamp ASC']")


# ============================================================================
# C5: get_definition includes max_results param with default
# ============================================================================
# Contracts: C5
def check_c5_max_results_param() -> None:
    """max_results property: type='integer', default=20."""
    _require(SearchTracesTool is not None, "SearchTracesTool not available")
    try:
        tool = SearchTracesTool()
    except TypeError as exc:
        raise AssertionError(f"SearchTracesTool abstract: {exc}")
    props = tool.get_definition().function.parameters.properties
    _require("max_results" in props,
             f"max_results missing from properties: {list(props.keys())}")
    mr = props["max_results"]
    _require(mr.type == "integer",
             f"Expected type='integer', got {mr.type!r}")
    _require(mr.default == 20,
             f"Expected default=20, got {mr.default!r}")
    print("PASS: C5 - max_results param: type=integer, default=20")


# ============================================================================
# C22: GetTracesInSession delegates to SearchTracesTool
# ============================================================================
# Contracts: C22
# Reference: tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_success
# Perspective: verify caller forwards filter_string, order_by, max_results
def check_c22_get_traces_in_session_delegation() -> None:
    """GetTracesInSession.invoke calls SearchTracesTool().invoke with correct args."""
    _require(SearchTracesTool is not None, "SearchTracesTool not available")
    from mlflow.genai.judges.tools.get_traces_in_session import GetTracesInSession
    from mlflow.tracing.constant import TraceMetadataKey

    trace = _make_valid_trace()
    trace.info.trace_metadata = {TraceMetadataKey.TRACE_SESSION: "session-123"}

    with mock.patch(
        "mlflow.genai.judges.tools.get_traces_in_session.SearchTracesTool"
    ) as mock_search_class:
        mock_instance = mock.MagicMock()
        mock_instance.invoke.return_value = []
        mock_search_class.return_value = mock_instance

        tool = GetTracesInSession()
        tool.invoke(trace, max_results=50, order_by=["timestamp DESC"])

    mock_instance.invoke.assert_called_once()
    call_kwargs = mock_instance.invoke.call_args.kwargs
    _require(call_kwargs["trace"] is trace, "trace argument not forwarded")
    _require("filter_string" in call_kwargs, "filter_string not forwarded")
    _require(call_kwargs["order_by"] == ["timestamp DESC"],
             f"order_by mismatch: {call_kwargs['order_by']!r}")
    _require(call_kwargs["max_results"] == 50,
             f"max_results mismatch: {call_kwargs['max_results']!r}")
    print("PASS: C22 - GetTracesInSession delegates to SearchTracesTool.invoke")


# ============================================================================
# Supplemental architecture checks
# ============================================================================

def check_inheritance() -> None:
    """SearchTracesTool inherits from JudgeTool."""
    _require(SearchTracesTool is not None, "SearchTracesTool not available")
    _require(issubclass(SearchTracesTool, JudgeTool),
             "SearchTracesTool must inherit from JudgeTool")
    print("PASS: SearchTracesTool inherits from JudgeTool")


def check_exported_from_package() -> None:
    """SearchTracesTool is exported from mlflow.genai.judges.tools."""
    _require(SearchTracesTool is not None, "SearchTracesTool not available")
    from mlflow.genai.judges import tools as judge_tools
    _require(hasattr(judge_tools, "SearchTracesTool"),
             "SearchTracesTool not exported from mlflow.genai.judges.tools")
    _require(judge_tools.SearchTracesTool is SearchTracesTool,
             "Exported SearchTracesTool is not the same class")
    print("PASS: SearchTracesTool exported from package")


# ============================================================================
# Runner
# ============================================================================

def main() -> None:
    checks = [
        check_c1_name_returns_constant,
        check_c2_get_definition_structure,
        check_c3_filter_string_param,
        check_c4_order_by_param,
        check_c5_max_results_param,
        check_c22_get_traces_in_session_delegation,
        check_inheritance,
        check_exported_from_package,
    ]
    failed = 0
    for check in checks:
        try:
            check()
        except Exception as exc:
            print(f"FAIL: {check.__name__}: {exc}", file=sys.stderr)
            failed += 1
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
