# Semantic IR

## L1. Requirement Obligations

### R1: SearchTracesTool name property
- **Type:** Interface
- **Statement:** `SearchTracesTool.name` must return the string constant `ToolNames._SEARCH_TRACES` (`"_search_traces"`).
- **Task Evidence:** "Get the name identifier for the SearchTracesTool. ... This property returns the standardized tool name used to identify this tool within the MLflow GenAI judges framework."
- **Acceptance:** Calling `.name` on a `SearchTracesTool` instance returns `"_search_traces"`.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.name` returns `ToolNames._SEARCH_TRACES`.
- **Uncertainty:** None.

### R2: SearchTracesTool get_definition method
- **Type:** Interface
- **Statement:** `SearchTracesTool.get_definition()` must return a `ToolDefinition` with `type="function"`, a `FunctionToolDefinition` named `ToolNames._SEARCH_TRACES`, and a `ToolParamsSchema` with three optional properties: `filter_string` (string), `order_by` (array of strings, default `["timestamp ASC"]`), and `max_results` (integer, default `20`).
- **Task Evidence:** "Get the tool definition for the SearchTracesTool. ... Returns: ToolDefinition: A tool definition object containing: - function: FunctionToolDefinition with tool name, description, and parameters - type: Set to 'function' ..."
- **Acceptance:** The returned `ToolDefinition` has `type == "function"`, `function.name == "_search_traces"`, `function.parameters.type == "object"`, properties for `filter_string`, `order_by`, `max_results`, and empty `required` list.
- **Repository Evidence:** `/testbed/mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`, `ParamProperty`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.get_definition`.
- **Uncertainty:** None.

### R3: SearchTracesTool invoke method — experiment context validation
- **Type:** Failure
- **Statement:** `SearchTracesTool.invoke(trace, ...)` must validate that `trace` belongs to an MLflow experiment context by calling `_get_experiment_id(trace)`. If the trace has no `trace_location`, or its location type is not `MLFLOW_EXPERIMENT`, or no `experiment_id` exists, an `MlflowException` with `INVALID_PARAMETER_VALUE` error code must be raised.
- **Task Evidence:** "Raises: MlflowException: Raised in the following scenarios: - The provided trace has no trace location information - The trace is not from an MLflow experiment context - The trace has no associated experiment_id"
- **Acceptance:** Invalid traces raise `MlflowException` with `error_code=INVALID_PARAMETER_VALUE`; valid traces return the experiment_id for search.
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:TraceLocationType.MLFLOW_EXPERIMENT`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id`.
- **Uncertainty:** None.

### R4: SearchTracesTool invoke method — trace search delegation
- **Type:** Dataflow
- **Statement:** `SearchTracesTool.invoke(trace, filter_string, order_by, max_results)` must delegate to `mlflow.search_traces()` with `locations=[experiment_id]`, the given `filter_string`, `order_by` (defaulting to `["timestamp ASC"]`), `max_results`, and `return_type="list"`. The result is a list of `Trace` objects.
- **Task Evidence:** "This method enables searching and retrieving traces from the same MLflow experiment context as the provided trace."; "Only traces within the same experiment as the input trace can be searched"
- **Acceptance:** `mlflow.search_traces` is called with `locations=[exp_id]`, the provided filter/order/max_results, and `return_type="list"`.
- **Repository Evidence:** `/testbed/mlflow/tracing/fluent.py:search_traces` signature accepts `locations`, `filter_string`, `max_results`, `order_by`, `return_type`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke`.
- **Uncertainty:** None.

### R5: SearchTracesTool invoke method — trace-to-JudgeToolTraceInfo conversion
- **Type:** Dataflow
- **Statement:** Each `Trace` object returned by `mlflow.search_traces()` must be converted to a `JudgeToolTraceInfo` dataclass instance with fields: `trace_id` (from `trace.info.trace_id`), `request_time` (from `trace.info.request_time`), `state` (from `trace.info.state`), `request` (from `trace.data.request`), `response` (from `trace.data.response`), `execution_duration` (from `trace.info.execution_duration`), and `assessments` (via `_convert_assessments_to_tool_types(trace.info.assessments)`).
- **Task Evidence:** "Returns: List of JudgeToolTraceInfo objects, each containing: - trace_id ... - request_time ... - state ... - request ... - response ... - execution_duration ... - assessments ..."
- **Acceptance:** Each returned `JudgeToolTraceInfo` carries the exact mapped fields from the source `Trace`.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo` dataclass; `/testbed/mlflow/entities/trace.py:Trace` with `info` and `data`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke`.
- **Uncertainty:** None.

### R6: SearchTracesTool invoke method — graceful per-trace error handling
- **Type:** Failure
- **Statement:** If converting an individual trace to `JudgeToolTraceInfo` fails (raises any `Exception`), the tool must log a warning and skip that trace (continue to the next), rather than failing the entire invocation.
- **Task Evidence:** "- Traces that fail to process during retrieval are logged as warnings and skipped"
- **Acceptance:** A trace whose conversion raises is silently skipped with a `_logger.warning`; other valid traces are still returned.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke` try/except block around `JudgeToolTraceInfo` construction.
- **Uncertainty:** None.

### R7: SearchTracesTool invoke method — search failure propagation
- **Type:** Failure
- **Statement:** If `mlflow.search_traces()` raises any exception, the tool must raise an `MlflowException` with message `"Failed to search traces: {error}"` and error_code `"INTERNAL_ERROR"`.
- **Task Evidence:** "Raises: MlflowException: ... - The search operation fails due to invalid filter syntax or other errors"
- **Acceptance:** Underlying search errors are wrapped in `MlflowException` with descriptive message.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke` outer try/except.
- **Uncertainty:** None.

### R8: _convert_assessments_to_tool_types — Expectation conversion
- **Type:** Dataflow
- **Statement:** For each `Expectation` assessment, `_convert_assessments_to_tool_types` must produce a `JudgeToolExpectation` with fields: `name`, `source` (from `assessment.source.source_type`), `rationale`, `span_id`, `assessment_id`, and `value`.
- **Task Evidence:** "- Expectation objects are converted to JudgeToolExpectation instances"; "The function preserves all core assessment properties including name, source, rationale, span_id, assessment_id, and value"
- **Acceptance:** `JudgeToolExpectation` fields match the source `Expectation` fields.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:Expectation`; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_convert_assessments_to_tool_types`.
- **Uncertainty:** None.

### R9: _convert_assessments_to_tool_types — Feedback conversion
- **Type:** Dataflow
- **Statement:** For each `Feedback` assessment, `_convert_assessments_to_tool_types` must produce a `JudgeToolFeedback` with fields: `name`, `source` (from `assessment.source.source_type`), `rationale`, `span_id`, `assessment_id`, `value`, and additionally `error_code`, `error_message`, `stack_trace` (from `assessment.error` if present, else `None`), `overrides`, and `valid`.
- **Task Evidence:** "- Feedback objects are converted to JudgeToolFeedback instances with additional error handling fields (error_code, error_message, stack_trace) and validation properties (overrides, valid)"; "- Error fields in JudgeToolFeedback are set to None if the original Feedback object has no associated error"
- **Acceptance:** `JudgeToolFeedback` fields match source `Feedback` fields; error fields are `None` when no error in source.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:Feedback`; `/testbed/mlflow/entities/assessment_error.py:AssessmentError`; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolFeedback`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_convert_assessments_to_tool_types`.
- **Uncertainty:** None.

### R10: _get_experiment_id — missing trace_location
- **Type:** Failure
- **Statement:** If `trace.info.trace_location` is falsy/None, `_get_experiment_id` must raise `MlflowException` with message `"Current trace has no trace location. Cannot determine experiment context."` and `error_code=INVALID_PARAMETER_VALUE`.
- **Task Evidence:** "Raises: MlflowException: ... - The provided trace has no trace location information"
- **Acceptance:** `MlflowException` with `INVALID_PARAMETER_VALUE` on missing location.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` first check.
- **Uncertainty:** None.

### R11: _get_experiment_id — non-MLflow-experiment location
- **Type:** Failure
- **Statement:** If `trace.info.trace_location.type != TraceLocationType.MLFLOW_EXPERIMENT`, `_get_experiment_id` must raise `MlflowException` with message indicating the actual type and that only MLflow experiment traces are supported, with `error_code=INVALID_PARAMETER_VALUE`.
- **Task Evidence:** "Raises: MlflowException: ... - The trace location type is not MLFLOW_EXPERIMENT (trace not from MLflow experiment)"
- **Acceptance:** `MlflowException` with `INVALID_PARAMETER_VALUE` on wrong location type.
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:TraceLocationType`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` second check.
- **Uncertainty:** None.

### R12: _get_experiment_id — missing experiment_id
- **Type:** Failure
- **Statement:** If `trace.info.trace_location.mlflow_experiment` is falsy or its `experiment_id` is falsy, `_get_experiment_id` must raise `MlflowException` with message `"Current trace has no experiment_id. Cannot search for traces."` and `error_code=INVALID_PARAMETER_VALUE`.
- **Task Evidence:** "Raises: MlflowException: ... - The trace has no experiment_id in its MLflow experiment location data"
- **Acceptance:** `MlflowException` with `INVALID_PARAMETER_VALUE` on missing experiment_id.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` third check.
- **Uncertainty:** None.

### R13: AssessmentSourceType._standardize — case-insensitive standardization
- **Type:** Behavior
- **Statement:** `AssessmentSourceType._standardize(source_type: str)` must accept case-insensitive input, convert it to uppercase, validate it against `_SOURCE_TYPES`, and return the standardized uppercase string. It must delegate to `AssessmentSourceType(source_type)` constructor and return `str()` of the instance.
- **Task Evidence:** "Case-insensitive string inputs (converts to uppercase)"; "Input is case-insensitive but output is always uppercase"
- **Acceptance:** `_standardize("human")` returns `"HUMAN"`; `_standardize("llm_judge")` returns `"LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._SOURCE_TYPES`; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`, `__init__`, `_parse`, `__str__`.
- **Uncertainty:** None.

### R14: AssessmentSourceType._standardize — deprecated AI_JUDGE migration
- **Type:** Compatibility
- **Statement:** When `_standardize` receives `"AI_JUDGE"` (case-insensitive), it must emit a `FutureWarning` with message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` and return `"LLM_JUDGE"`.
- **Task Evidence:** "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE' with a deprecation warning."; "Handle case-insensitive input standardization and deprecated value migration with warnings"
- **Acceptance:** `_standardize("ai_judge")` emits `FutureWarning` and returns `"LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType.AI_JUDGE`; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`.
- **Uncertainty:** None.

### R15: AssessmentSourceType._standardize — invalid source type rejection
- **Type:** Failure
- **Statement:** If the input `source_type` (after uppercasing) is not in `_SOURCE_TYPES` and is not `"AI_JUDGE"`, `_standardize` must raise `MlflowException` with message containing the invalid value and listing valid types, with `error_code=INVALID_PARAMETER_VALUE`.
- **Task Evidence:** "Raises: MlflowException: If the provided source_type is not a valid assessment source type after case normalization and deprecation handling."
- **Acceptance:** `_standardize("INVALID")` raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:_SOURCE_TYPES`, `INVALID_PARAMETER_VALUE`; `/testbed/libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`.
- **Uncertainty:** None.

### R16: AssessmentSource.__post_init__ delegates to _standardize
- **Type:** Dataflow
- **Statement:** `AssessmentSource.__post_init__` must call `AssessmentSourceType._standardize(self.source_type)` and assign the result back to `self.source_type`, ensuring all `AssessmentSource` instances have standardized source types.
- **Task Evidence:** The `AssessmentSource` class docstring describes source_type validation through `AssessmentSourceType`; `AssessmentSource.__post_init__` is already written to call `_standardize`.
- **Acceptance:** `AssessmentSource(source_type="human", source_id="x")` produces `source_type == "HUMAN"`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`.
- **Uncertainty:** None.

---

## L2. Functional Design Graph

### N1: AssessmentSourceType
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType`

### N2: AssessmentSourceType._standardize
- **Kind:** Method (Static)
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize` (stub); `/testbed/libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize` (full impl)

### N3: AssessmentSourceType.__init__
- **Kind:** Method
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType.__init__` (missing in main)

### N4: AssessmentSourceType._parse
- **Kind:** Method (Static)
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType._parse` (missing in main)

### N5: AssessmentSourceType.__str__
- **Kind:** Method
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:AssessmentSourceType.__str__` (missing in main)

### N6: AssessmentSource
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource`

### N7: SearchTracesTool
- **Kind:** Class (PublicEntry)
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool`; `/testbed/mlflow/genai/judges/tools/__init__.py` exports `SearchTracesTool`

### N8: SearchTracesTool.name
- **Kind:** Method (Property)
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.name` (stub); `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.name` (full)

### N9: SearchTracesTool.get_definition
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.get_definition` (stub); `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.get_definition` (full)

### N10: SearchTracesTool.invoke
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke` (stub); `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke` (full)

### N11: _get_experiment_id
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` (stub); `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` (full)

### N12: _convert_assessments_to_tool_types
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:_convert_assessments_to_tool_types` (stub); `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_convert_assessments_to_tool_types` (full)

### N13: JudgeTool (base class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool`

### N14: mlflow.search_traces
- **Kind:** External (Public API)
- **Repository Evidence:** `/testbed/mlflow/tracing/fluent.py:search_traces`

### N15: TracingClient.search_traces
- **Kind:** Method (Internal)
- **Repository Evidence:** `/testbed/mlflow/tracing/client.py:TracingClient.search_traces`

### N16: JudgeToolTraceInfo
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`

### N17: JudgeToolExpectation
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation`

### N18: JudgeToolFeedback
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolFeedback`

### N19: ToolNames._SEARCH_TRACES
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES`

### N20: ToolDefinition / FunctionToolDefinition / ToolParamsSchema
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`

### N21: Expectation (assessment entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:Expectation`

### N22: Feedback (assessment entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:Feedback`

### N23: AssessmentError
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_error.py:AssessmentError`

### N24: Trace
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace.py:Trace`

### N25: TraceLocation / TraceLocationType
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py`

### N26: MlflowException
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/exceptions.py:MlflowException`

### N27: _logger
- **Kind:** Observer
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:_logger`

### N28: warnings.warn (FutureWarning)
- **Kind:** Observer
- **Repository Evidence:** Python stdlib `warnings`; `/testbed/libs/skinny/mlflow/entities/assessment_source.py`

### N29: GetTracesInSession (caller)
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession` calls `SearchTracesTool().invoke()`

---

### E1: SearchTracesTool -> JudgeTool (inheritance)
- **Kind:** CONTROL
- **Condition:** Always
- **Transfer:** `SearchTracesTool` inherits abstract interface (`name`, `get_definition`, `invoke`) from `JudgeTool`.
- **Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:class SearchTracesTool(JudgeTool)`
- **Obligations:** R1, R2, R3

### E2: SearchTracesTool.name -> ToolNames._SEARCH_TRACES
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns the constant `"_search_traces"`.
- **Evidence:** `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:name` property.
- **Obligations:** R1

### E3: SearchTracesTool.get_definition -> ToolDefinition
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns a `ToolDefinition` with `type="function"`, `function.name="_search_traces"`, `function.parameters` with three optional properties and empty required list.
- **Evidence:** `/testbed/mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:get_definition`.
- **Obligations:** R2

### E4: SearchTracesTool.invoke -> _get_experiment_id
- **Kind:** CALL
- **Condition:** Always (first step of invoke)
- **Transfer:** Passes `trace` argument; receives experiment_id string or raises `MlflowException`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool.invoke` calls `_get_experiment_id(trace)`.
- **Obligations:** R3, R10, R11, R12

### E5: _get_experiment_id -> MlflowException (error path: no location)
- **Kind:** CONTROL
- **Condition:** `trace.info.trace_location` is falsy
- **Transfer:** Raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` first check.
- **Obligations:** R10

### E6: _get_experiment_id -> MlflowException (error path: wrong type)
- **Kind:** CONTROL
- **Condition:** `trace.info.trace_location.type != TraceLocationType.MLFLOW_EXPERIMENT`
- **Transfer:** Raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` second check.
- **Obligations:** R11

### E7: _get_experiment_id -> MlflowException (error path: no experiment_id)
- **Kind:** CONTROL
- **Condition:** `mlflow_experiment` or its `experiment_id` is falsy
- **Transfer:** Raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` third check.
- **Obligations:** R12

### E8: _get_experiment_id -> experiment_id (success)
- **Kind:** DATA
- **Condition:** All validation checks pass
- **Transfer:** Returns `trace.info.trace_location.mlflow_experiment.experiment_id`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_get_experiment_id` return.
- **Obligations:** R3

### E9: SearchTracesTool.invoke -> mlflow.search_traces
- **Kind:** CALL
- **Condition:** After experiment_id extraction succeeds
- **Transfer:** Calls with `locations=[experiment_id]`, `filter_string`, `order_by` (default `["timestamp ASC"]`), `max_results`, `return_type="list"`. Receives list of `Trace` objects.
- **Evidence:** `/testbed/mlflow/tracing/fluent.py:search_traces`; `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:invoke`.
- **Obligations:** R4

### E10: SearchTracesTool.invoke -> MlflowException (search failure)
- **Kind:** CONTROL
- **Condition:** `mlflow.search_traces()` raises any Exception
- **Transfer:** Wraps in `MlflowException` with `error_code="INTERNAL_ERROR"`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:invoke` outer try/except.
- **Obligations:** R7

### E11: SearchTracesTool.invoke -> _convert_assessments_to_tool_types (per trace)
- **Kind:** CALL
- **Condition:** For each Trace in search results
- **Transfer:** Passes `trace_obj.info.assessments` (list of `Assessment`); receives list of `JudgeToolExpectation | JudgeToolFeedback`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:invoke` calls `_convert_assessments_to_tool_types(trace_obj.info.assessments)`.
- **Obligations:** R5, R8, R9

### E12: SearchTracesTool.invoke -> JudgeToolTraceInfo (per trace)
- **Kind:** DATA
- **Condition:** Per-trace conversion succeeds
- **Transfer:** Constructs `JudgeToolTraceInfo` from trace fields and converted assessments.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:invoke` constructs `JudgeToolTraceInfo`.
- **Obligations:** R5

### E13: SearchTracesTool.invoke -> _logger (per-trace error skip)
- **Kind:** CONTROL
- **Condition:** Per-trace `JudgeToolTraceInfo` construction raises any Exception
- **Transfer:** Logs warning and continues to next trace.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:invoke` inner try/except.
- **Obligations:** R6

### E14: _convert_assessments_to_tool_types -> JudgeToolExpectation
- **Kind:** DATA
- **Condition:** `isinstance(assessment, Expectation)`
- **Transfer:** Maps `Expectation` fields to `JudgeToolExpectation(name, source=source.source_type, rationale, span_id, assessment_id, value)`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_convert_assessments_to_tool_types` Expectation branch.
- **Obligations:** R8

### E15: _convert_assessments_to_tool_types -> JudgeToolFeedback
- **Kind:** DATA
- **Condition:** `isinstance(assessment, Feedback)`
- **Transfer:** Maps `Feedback` fields to `JudgeToolFeedback(name, source=source.source_type, rationale, span_id, assessment_id, value, error_code, error_message, stack_trace, overrides, valid)`. Error fields are `None` when `assessment.error` is `None`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/judges/tools/search_traces.py:_convert_assessments_to_tool_types` Feedback branch.
- **Obligations:** R9

### E16: AssessmentSourceType._standardize -> AssessmentSourceType.__init__
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Calls `AssessmentSourceType(source_type)` to create instance, then calls `str()` on it.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:_standardize` returns `str(AssessmentSourceType(source_type))`.
- **Obligations:** R13, R14, R15

### E17: AssessmentSourceType.__init__ -> AssessmentSourceType._parse
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Passes `source_type` to `_parse`; stores result in `self._source_type`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:__init__` calls `self._source_type = AssessmentSourceType._parse(source_type)`.
- **Obligations:** R13, R14, R15

### E18: AssessmentSourceType._parse -> uppercase conversion
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Converts input to uppercase via `source_type.upper()`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:_parse` first line.
- **Obligations:** R13

### E19: AssessmentSourceType._parse -> FutureWarning (AI_JUDGE deprecation)
- **Kind:** CONTROL
- **Condition:** `source_type == AssessmentSourceType.AI_JUDGE`
- **Transfer:** Emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and remaps to `LLM_JUDGE`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:_parse` AI_JUDGE branch.
- **Obligations:** R14

### E20: AssessmentSourceType._parse -> MlflowException (invalid)
- **Kind:** CONTROL
- **Condition:** `source_type not in _SOURCE_TYPES`
- **Transfer:** Raises `MlflowException` with `INVALID_PARAMETER_VALUE` and message listing valid types.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:_parse` validation.
- **Obligations:** R15

### E21: AssessmentSourceType.__str__ -> _source_type
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns `self._source_type` (the standardized string).
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py:__str__`.
- **Obligations:** R13

### E22: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
- **Kind:** CALL
- **Condition:** Always during `AssessmentSource` initialization
- **Transfer:** Calls `AssessmentSourceType._standardize(self.source_type)` and assigns result to `self.source_type`.
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`.
- **Obligations:** R16

### E23: GetTracesInSession.invoke -> SearchTracesTool.invoke (caller)
- **Kind:** CALL
- **Condition:** When searching for traces in same session
- **Transfer:** Instantiates `SearchTracesTool()` and calls `.invoke(trace, filter_string, order_by, max_results)`.
- **Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke` calls `SearchTracesTool().invoke(...)`.
- **Obligations:** R4, R5

---

## L3. Verifiable Contracts

### C1: SearchTracesTool.name returns constant
- **Type:** Interface
- **Subject:** `SearchTracesTool.name` property
- **Relation:** EQ
- **Expected:** `"_search_traces"`
- **Evidence:** Task doc "The returned name must be unique within the judge tools ecosystem."; `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`.
- **Observe:** RETURN_VALUE
- **Target:** `SearchTracesTool().name`
- **Obligations:** R1
- **Graph:** N7, N8, N19, E2

### C2: SearchTracesTool.get_definition returns proper ToolDefinition
- **Type:** Interface
- **Subject:** `SearchTracesTool.get_definition()` return value
- **Relation:** TYPE_IS
- **Expected:** `ToolDefinition` with `type == "function"`, `function.name == "_search_traces"`, `function.parameters.type == "object"`, `function.parameters.required == []`.
- **Evidence:** Task doc specifies optional parameters `filter_string`, `order_by`, `max_results` with defaults; `/testbed/mlflow/types/llm.py:ToolDefinition`.
- **Observe:** RETURN_VALUE
- **Target:** `SearchTracesTool().get_definition()`
- **Obligations:** R2
- **Graph:** N7, N9, N20, E3

### C3: get_definition includes filter_string param
- **Type:** Interface
- **Subject:** `parameters.properties["filter_string"]`
- **Relation:** PRESERVE
- **Expected:** Property exists with `type == "string"` and `default is None`.
- **Evidence:** Task doc states filter_string is optional with SQL-like syntax.
- **Observe:** FIELD_READ
- **Target:** `SearchTracesTool().get_definition().function.parameters.properties["filter_string"]`
- **Obligations:** R2
- **Graph:** N9, N20, E3

### C4: get_definition includes order_by param with default
- **Type:** Interface
- **Subject:** `parameters.properties["order_by"]`
- **Relation:** PRESERVE
- **Expected:** Property exists with `type == "array"`, `items.type == "string"`, `default == ["timestamp ASC"]`.
- **Evidence:** Task doc "Defaults to ['timestamp ASC'] for chronological ordering if None."
- **Observe:** FIELD_READ
- **Target:** `SearchTracesTool().get_definition().function.parameters.properties["order_by"]`
- **Obligations:** R2
- **Graph:** N9, N20, E3

### C5: get_definition includes max_results param with default
- **Type:** Interface
- **Subject:** `parameters.properties["max_results"]`
- **Relation:** PRESERVE
- **Expected:** Property exists with `type == "integer"` and `default == 20`.
- **Evidence:** Task doc "Defaults to 20 to prevent excessive memory usage."
- **Observe:** FIELD_READ
- **Target:** `SearchTracesTool().get_definition().function.parameters.properties["max_results"]`
- **Obligations:** R2
- **Graph:** N9, N20, E3

### C6: _get_experiment_id raises on missing trace_location
- **Type:** Failure
- **Subject:** `_get_experiment_id(trace)` with trace having `info.trace_location = None`
- **Relation:** RAISES
- **Expected:** `MlflowException` with `error_code == INVALID_PARAMETER_VALUE` and message containing "no trace location".
- **Evidence:** Task doc "The provided trace has no trace location information"; `/testbed/mlflow/entities/trace_location.py`.
- **Observe:** EXCEPTION
- **Target:** `_get_experiment_id(trace_without_location)`
- **Obligations:** R10
- **Graph:** N11, N26, E5

### C7: _get_experiment_id raises on non-MLflow-experiment location
- **Type:** Failure
- **Subject:** `_get_experiment_id(trace)` with `trace.info.trace_location.type != MLFLOW_EXPERIMENT`
- **Relation:** RAISES
- **Expected:** `MlflowException` with `error_code == INVALID_PARAMETER_VALUE`.
- **Evidence:** Task doc "The trace location type is not MLFLOW_EXPERIMENT"; `/testbed/mlflow/entities/trace_location.py:TraceLocationType`.
- **Observe:** EXCEPTION
- **Target:** `_get_experiment_id(trace_with_uc_schema_location)`
- **Obligations:** R11
- **Graph:** N11, N25, N26, E6

### C8: _get_experiment_id raises on missing experiment_id
- **Type:** Failure
- **Subject:** `_get_experiment_id(trace)` with MLFLOW_EXPERIMENT type but no experiment_id
- **Relation:** RAISES
- **Expected:** `MlflowException` with `error_code == INVALID_PARAMETER_VALUE` and message containing "no experiment_id".
- **Evidence:** Task doc "The trace has no experiment_id in its MLflow experiment location data."
- **Observe:** EXCEPTION
- **Target:** `_get_experiment_id(trace_with_null_experiment_id)`
- **Obligations:** R12
- **Graph:** N11, N25, N26, E7

### C9: _get_experiment_id returns experiment_id on valid trace
- **Type:** Behavior
- **Subject:** `_get_experiment_id(valid_trace)`
- **Relation:** EQ
- **Expected:** Returns the string experiment_id from `trace.info.trace_location.mlflow_experiment.experiment_id`.
- **Evidence:** Task doc "Extract and validate the experiment ID from a trace object."
- **Observe:** RETURN_VALUE
- **Target:** `_get_experiment_id(valid_mlflow_trace)`
- **Obligations:** R3
- **Graph:** N11, E8

### C10: invoke defaults order_by to ["timestamp ASC"]
- **Type:** Behavior
- **Subject:** `SearchTracesTool.invoke` when `order_by=None`
- **Relation:** DEFAULTS_TO
- **Expected:** `mlflow.search_traces` is called with `order_by=["timestamp ASC"]`.
- **Evidence:** Task doc "Defaults to ['timestamp ASC'] for chronological ordering if None."
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** Mock `mlflow.search_traces` and verify `order_by` arg.
- **Obligations:** R4
- **Graph:** N10, N14, E9

### C11: invoke calls mlflow.search_traces with correct locations
- **Type:** Behavior
- **Subject:** `SearchTracesTool.invoke(trace, ...)`
- **Relation:** EQ
- **Expected:** `mlflow.search_traces` is called with `locations=[experiment_id]` where experiment_id comes from `_get_experiment_id(trace)`.
- **Evidence:** Task doc "Only traces within the same experiment as the input trace can be searched."
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** Mock `mlflow.search_traces`, verify `locations` kwarg.
- **Obligations:** R4
- **Graph:** N10, N11, N14, E4, E9

### C12: invoke wraps search errors in MlflowException
- **Type:** Failure
- **Subject:** `SearchTracesTool.invoke` when `mlflow.search_traces` raises
- **Relation:** RAISES
- **Expected:** `MlflowException` with message starting `"Failed to search traces:"` and `error_code="INTERNAL_ERROR"`.
- **Evidence:** Task doc "The search operation fails due to invalid filter syntax or other errors."
- **Observe:** EXCEPTION
- **Target:** `SearchTracesTool().invoke(trace, filter_string="invalid!!")` (with mock that raises)
- **Obligations:** R7
- **Graph:** N10, N14, N26, E10

### C13: invoke converts traces to JudgeToolTraceInfo list
- **Type:** Dataflow
- **Subject:** `SearchTracesTool.invoke` return value
- **Relation:** TYPE_IS
- **Expected:** Returns `list[JudgeToolTraceInfo]` where each element maps from a `Trace` object.
- **Evidence:** Task doc "Returns: List of JudgeToolTraceInfo objects."
- **Observe:** RETURN_VALUE
- **Target:** `SearchTracesTool().invoke(trace)` return type and element types.
- **Obligations:** R5
- **Graph:** N10, N16, E12

### C14: invoke skips failed trace conversions
- **Type:** Behavior
- **Subject:** `SearchTracesTool.invoke` when one trace conversion raises
- **Relation:** PRESERVE
- **Expected:** Other valid traces are still returned; failed trace is logged as warning.
- **Evidence:** Task doc "Traces that fail to process during retrieval are logged as warnings and skipped."
- **Observe:** SIDE_EFFECT (log output) + RETURN_VALUE (still contains successful traces)
- **Target:** `SearchTracesTool().invoke(trace)` with mock traces where one raises on conversion.
- **Obligations:** R6
- **Graph:** N10, N27, E13

### C15: _convert_assessments_to_tool_types converts Expectation correctly
- **Type:** Dataflow
- **Subject:** `_convert_assessments_to_tool_types([expectation])`
- **Relation:** EQ
- **Expected:** Returns `[JudgeToolExpectation(name=e.name, source=e.source.source_type, rationale=e.rationale, span_id=e.span_id, assessment_id=e.assessment_id, value=e.value)]`.
- **Evidence:** Task doc "Expectation objects are converted to JudgeToolExpectation instances."
- **Observe:** RETURN_VALUE
- **Target:** `_convert_assessments_to_tool_types([expectation_obj])`
- **Obligations:** R8
- **Graph:** N12, N17, N21, E14

### C16: _convert_assessments_to_tool_types converts Feedback correctly (with error)
- **Type:** Dataflow
- **Subject:** `_convert_assessments_to_tool_types([feedback_with_error])`
- **Relation:** EQ
- **Expected:** Returns `[JudgeToolFeedback(name=f.name, source=f.source.source_type, ..., error_code=f.error.error_code, error_message=f.error.error_message, stack_trace=f.error.stack_trace, overrides=f.overrides, valid=f.valid)]`.
- **Evidence:** Task doc "Feedback objects are converted to JudgeToolFeedback instances with additional error handling fields."
- **Observe:** RETURN_VALUE
- **Target:** `_convert_assessments_to_tool_types([feedback_with_error_obj])`
- **Obligations:** R9
- **Graph:** N12, N18, N22, N23, E15

### C17: _convert_assessments_to_tool_types converts Feedback correctly (without error)
- **Type:** Dataflow
- **Subject:** `_convert_assessments_to_tool_types([feedback_without_error])`
- **Relation:** EQ
- **Expected:** `JudgeToolFeedback` has `error_code=None, error_message=None, stack_trace=None`.
- **Evidence:** Task doc "Error fields in JudgeToolFeedback are set to None if the original Feedback object has no associated error."
- **Observe:** RETURN_VALUE
- **Target:** `_convert_assessments_to_tool_types([feedback_no_error_obj])`
- **Obligations:** R9
- **Graph:** N12, N18, N22, E15

### C18: AssessmentSourceType._standardize normalizes case
- **Type:** Behavior
- **Subject:** `AssessmentSourceType._standardize("human")`
- **Relation:** EQ
- **Expected:** `"HUMAN"`
- **Evidence:** Task doc "Case-insensitive string inputs (converts to uppercase)"; "human becomes HUMAN".
- **Observe:** RETURN_VALUE
- **Target:** `AssessmentSourceType._standardize("human")`
- **Obligations:** R13
- **Graph:** N2, N3, N4, E16, E17, E18

### C19: AssessmentSourceType._standardize handles deprecated AI_JUDGE
- **Type:** Behavior
- **Subject:** `AssessmentSourceType._standardize("AI_JUDGE")`
- **Relation:** EQ
- **Expected:** Returns `"LLM_JUDGE"` and emits `FutureWarning`.
- **Evidence:** Task doc "AI_JUDGE becomes LLM_JUDGE (with deprecation warning)."
- **Observe:** RETURN_VALUE + SIDE_EFFECT (warnings)
- **Target:** `AssessmentSourceType._standardize("AI_JUDGE")` with `warnings.catch_warnings`.
- **Obligations:** R14
- **Graph:** N2, N4, N28, E19

### C20: AssessmentSourceType._standardize raises on invalid type
- **Type:** Failure
- **Subject:** `AssessmentSourceType._standardize("INVALID_TYPE")`
- **Relation:** RAISES
- **Expected:** `MlflowException` with `error_code == INVALID_PARAMETER_VALUE`.
- **Evidence:** Task doc "Raises: MlflowException: If the provided source_type is not a valid assessment source type."
- **Observe:** EXCEPTION
- **Target:** `AssessmentSourceType._standardize("INVALID")`
- **Obligations:** R15
- **Graph:** N2, N4, N26, E20

### C21: AssessmentSource.__post_init__ standardizes source_type
- **Type:** State
- **Subject:** `AssessmentSource(source_type="llm_judge")`
- **Relation:** EQ
- **Expected:** `source.source_type == "LLM_JUDGE"` after initialization.
- **Evidence:** Task doc describes string input case-insensitive handling for `AssessmentSource`.
- **Observe:** FIELD_READ
- **Target:** `AssessmentSource(source_type="llm_judge").source_type`
- **Obligations:** R16
- **Graph:** N6, N2, E22

### C22: GetTracesInSession delegates to SearchTracesTool
- **Type:** Dataflow
- **Subject:** `GetTracesInSession.invoke` internal call
- **Relation:** CALLS
- **Expected:** `SearchTracesTool().invoke` is called with `trace`, `filter_string`, `order_by`, `max_results`.
- **Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` calls `SearchTracesTool().invoke(...)`.
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** Mock `SearchTracesTool` and verify `invoke` call from `GetTracesInSession.invoke`.
- **Obligations:** R4, R5
- **Graph:** N29, N10, E23
