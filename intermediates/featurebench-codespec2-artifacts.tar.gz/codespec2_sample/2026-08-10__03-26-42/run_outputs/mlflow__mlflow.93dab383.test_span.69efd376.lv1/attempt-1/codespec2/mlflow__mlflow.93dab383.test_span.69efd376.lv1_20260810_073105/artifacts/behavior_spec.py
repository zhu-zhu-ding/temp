"""
Behavior specification: public observable semantics.

Compiles L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility contracts from the semantic IR. Each check proves what
a requirement visibly does through public API.
"""

import json
import time
from threading import Thread
from unittest import mock

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_otel_span(trace_id=1, span_id=2, name="test_span",
                          parent_id=None, start_time=None, end_time=None):
    """Create a mock OpenTelemetry span (both OTelSpan and OTelReadableSpan)."""
    from opentelemetry import trace as trace_api
    from opentelemetry.sdk.trace import Event as OTelEvent
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan

    class _MockSpanContext:
        def __init__(self, trace_id, span_id):
            self.trace_id = trace_id
            self.span_id = span_id
            self.trace_flags = trace_api.TraceFlags(1)
            self.trace_state = trace_api.TraceState()
            self.is_remote = False

    class _MockOTelSpan(trace_api.Span, OTelReadableSpan):
        def __init__(self, name, context, parent, start_time=None,
                     end_time=None, status=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time or int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status or trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = {}
            self._events = []

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(OTelEvent(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self._name = name

        def end(self, end_time=None):
            pass

        def record_exception(self, *args, **kwargs):
            pass

    ctx = _MockSpanContext(trace_id, span_id)
    parent_ctx = _MockSpanContext(trace_id, parent_id) if parent_id else None
    return _MockOTelSpan(name=name, context=ctx, parent=parent_ctx,
                         start_time=start_time, end_time=end_time)


# ---------------------------------------------------------------------------
# C1: LiveSpan.set_span_type stores span type attribute
# Graph: N2, E15, E16
# ---------------------------------------------------------------------------

# Contracts: C1
# Reference: libs/skinny/mlflow/entities/span.py:525-527
# Perspective: LiveSpan.set_span_type sets the SPAN_TYPE attribute
def check_livespan_set_span_type() -> None:
    """After set_span_type('LLM'), span_type property returns 'LLM'."""
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    live = LiveSpan(mock_span, "tr-test-c1")
    live.set_span_type("LLM")

    assert live.span_type == "LLM"
    assert live.get_attribute(SpanAttributeKey.SPAN_TYPE) == "LLM"

    # Also verify via underlying OTel attribute
    raw = mock_span._attributes.get(SpanAttributeKey.SPAN_TYPE)
    assert raw is not None
    assert json.loads(raw) == "LLM"


# ---------------------------------------------------------------------------
# C2: LiveSpan.to_immutable_span returns Span with same data
# Graph: N2, N1, E4
# ---------------------------------------------------------------------------

# Contracts: C2
# Reference: libs/skinny/mlflow/entities/span.py:668-676
# Perspective: to_immutable_span preserves all span data
def check_livespan_to_immutable_span() -> None:
    """to_immutable_span() returns Span with same name, trace_id,
    span_id, attributes, events, status."""
    from mlflow.entities import LiveSpan, Span, SpanEvent, SpanStatus, SpanStatusCode

    mock_span = _make_mock_otel_span(trace_id=0xABCD, span_id=0x5678, name="my_span")
    live = LiveSpan(mock_span, "tr-test-c2", span_type="CHAIN")
    live.set_inputs({"x": 1})
    live.set_outputs({"y": 2})
    live.set_attribute("custom", "value")
    event = SpanEvent(name="an_event", timestamp=1000)
    live.add_event(event)
    live.set_status(SpanStatus(SpanStatusCode.OK))

    immutable = live.to_immutable_span()
    assert isinstance(immutable, Span)
    assert immutable.name == "my_span"
    assert immutable.trace_id == "tr-test-c2"
    assert immutable.span_id == live.span_id
    assert immutable.span_type == "CHAIN"
    assert immutable.inputs == {"x": 1}
    assert immutable.outputs == {"y": 2}
    assert immutable.get_attribute("custom") == "value"
    assert len(immutable.events) == 1
    assert immutable.events[0].name == "an_event"


# ---------------------------------------------------------------------------
# C5: Span.from_dict handles v2 and v3 schemas
# Graph: N1, E8, N21, N22
# ---------------------------------------------------------------------------

# Contracts: C5
# Reference: tests/tracing/helper.py:V2_TRACE_DICT
# Perspective: from_dict reconstructs spans from both v2 and v3 dict formats
def check_span_from_dict_v3_schema() -> None:
    """Span.from_dict reconstructs from v3 schema dict."""
    from mlflow.entities import LiveSpan, Span, SpanStatus, SpanStatusCode

    # Create + serialize
    mock_span = _make_mock_otel_span(trace_id=0xABCDEF01, span_id=0x1234,
                                      name="v3_span", start_time=100, end_time=200)
    live = LiveSpan(mock_span, "tr-test-c5a")
    live.set_status(SpanStatus(SpanStatusCode.OK))
    live.set_inputs({"in": "val"})
    immutable = live.to_immutable_span()
    d = immutable.to_dict()

    # Deserialize
    reconstructed = Span.from_dict(d)
    assert isinstance(reconstructed, Span)
    assert reconstructed.name == "v3_span"
    assert reconstructed.trace_id == "tr-test-c5a"
    # Round-trip from_dict -> to_dict
    d2 = reconstructed.to_dict()
    assert d["trace_id"] == d2["trace_id"]
    assert d["span_id"] == d2["span_id"]
    assert d["name"] == d2["name"]


# Contracts: C5, C29
# Reference: tests/tracing/helper.py:V2_TRACE_DICT
# Perspective: v2 schema backwards compatibility
def check_span_from_dict_v2_schema() -> None:
    """Span.from_dict reconstructs from v2 schema via from_dict_v2."""
    from mlflow.entities import Span
    from mlflow.entities.span_event import SpanEvent

    v2_data = {
        "name": "predict",
        "context": {
            "span_id": "0d48a6670588966b",
            "trace_id": "63076d0c1b90f1df0970f897dc428bd6",
        },
        "parent_id": None,
        "start_time": 100,
        "end_time": 200,
        "status_code": "OK",
        "status_message": "",
        "attributes": {
            "mlflow.traceRequestId": '"tr-v2-test"',
            "mlflow.spanType": '"UNKNOWN"',
            "mlflow.spanInputs": '{"x": 2}',
        },
        "events": [],
    }

    result = Span.from_dict(v2_data)
    assert isinstance(result, Span)
    assert result.name == "predict"


# ---------------------------------------------------------------------------
# C6: LiveSpan.from_dict raises NotImplementedError
# Graph: N2
# ---------------------------------------------------------------------------

# Contracts: C6
# Reference: libs/skinny/mlflow/entities/span.py:665-666
# Perspective: LiveSpan cannot be constructed from dict
def check_livespan_from_dict_raises() -> None:
    """LiveSpan.from_dict raises NotImplementedError."""
    from mlflow.entities import LiveSpan

    try:
        LiveSpan.from_dict({})
        assert False, "Expected NotImplementedError"
    except NotImplementedError:
        pass


# ---------------------------------------------------------------------------
# C10: _CachedSpanAttributesRegistry.set raises MlflowException
# Graph: N6, E13
# ---------------------------------------------------------------------------

# Contracts: C10
# Reference: libs/skinny/mlflow/entities/span.py:905-908
# Perspective: Immutable span attributes must not be updated
def check_cached_registry_set_raises() -> None:
    """_CachedSpanAttributesRegistry.set raises MlflowException."""
    from mlflow.entities.span import _CachedSpanAttributesRegistry
    from mlflow.exceptions import MlflowException

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    registry = _CachedSpanAttributesRegistry(mock_span)

    try:
        registry.set("key", "value")
        assert False, "Expected MlflowException"
    except MlflowException as e:
        assert "immutable" in str(e).lower() or "must not be updated" in str(e).lower()


# ---------------------------------------------------------------------------
# C11: NoOpSpan.trace_id returns NO_OP_SPAN_TRACE_ID constant
# Graph: N3
# ---------------------------------------------------------------------------

# Contracts: C11
# Reference: libs/skinny/mlflow/entities/span.py:784-789
# Perspective: NoOpSpan returns a distinguished trace ID
def check_noop_span_trace_id() -> None:
    """NoOpSpan().trace_id returns 'MLFLOW_NO_OP_SPAN_TRACE_ID'."""
    from mlflow.entities import NoOpSpan

    assert NoOpSpan().trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"


# ---------------------------------------------------------------------------
# C12: NoOpSpan properties return None
# Graph: N3
# ---------------------------------------------------------------------------

# Contracts: C12
# Reference: libs/skinny/mlflow/entities/span.py:791-821
# Perspective: All NoOpSpan accessor properties return None
def check_noop_span_properties_none() -> None:
    """NoOpSpan properties (span_id, name, start_time_ns, end_time_ns,
    status, _trace_id) all return None."""
    from mlflow.entities import NoOpSpan

    n = NoOpSpan()
    assert n.span_id is None
    assert n.name is None
    assert n.start_time_ns is None
    assert n.end_time_ns is None
    assert n.status is None
    assert n._trace_id is None


# ---------------------------------------------------------------------------
# C13, C21, C22: NoOpSpan setter methods are no-ops
# Graph: N3, E19
# ---------------------------------------------------------------------------

# Contracts: C13
# Reference: libs/skinny/mlflow/entities/span.py:823-850
# Perspective: All NoOpSpan mutators silently succeed
def check_noop_span_setters_noop() -> None:
    """All NoOpSpan setter methods do nothing and do not raise."""
    from mlflow.entities import NoOpSpan, SpanEvent, SpanStatus, SpanStatusCode

    n = NoOpSpan()

    # Each should return None and not raise
    assert n.set_attribute("key", "value") is None
    assert n.set_attributes({"a": 1}) is None
    assert n.set_inputs({"x": 1}) is None
    assert n.set_outputs({"y": 2}) is None
    assert n.set_status(SpanStatus(SpanStatusCode.OK)) is None

    # Post-mutation, properties still None
    assert n.span_id is None


# Contracts: C21
# Reference: libs/skinny/mlflow/entities/span.py:844-850
# Perspective: NoOpSpan.end accepts all args and returns None
def check_noop_span_end_noop() -> None:
    """NoOpSpan().end(...) does nothing and returns None."""
    from mlflow.entities import NoOpSpan

    result = NoOpSpan().end(
        outputs={"x": 1},
        attributes={"a": 1},
        status="OK",
    )
    assert result is None


# Contracts: C22
# Reference: libs/skinny/mlflow/entities/span.py:838-839
# Perspective: NoOpSpan.add_event is a silent no-op
def check_noop_span_add_event_noop() -> None:
    """NoOpSpan().add_event(...) does nothing and returns None."""
    from mlflow.entities import NoOpSpan, SpanEvent

    event = SpanEvent(name="test")
    result = NoOpSpan().add_event(event)
    assert result is None


# ---------------------------------------------------------------------------
# C19: Thread-safe InMemoryTraceManager.pop_trace
# Graph: N8, N7, E1
# ---------------------------------------------------------------------------

# Contracts: C19
# Reference: tests/tracing/test_trace_manager.py:76-97
# Perspective: Concurrent register_span calls do not corrupt traces
def check_thread_safe_pop_trace() -> None:
    """After concurrent register_span from 10 threads on 5 traces,
    pop_trace returns the correct number of spans per trace."""
    from mlflow.entities import LiveSpan, TraceInfo
    from mlflow.tracing.trace_manager import InMemoryTraceManager
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState

    mgr = InMemoryTraceManager.get_instance()
    try:
        num_traces = 5
        num_threads = 10

        for i in range(num_traces):
            info = TraceInfo(
                trace_id=f"tr-thread-{i}",
                trace_location=TraceLocation.from_experiment_id("test"),
                request_time=0,
                execution_duration=1,
                state=TraceState.OK,
                trace_metadata={"mlflow.trace_schema.version": "3"},
                tags={},
            )
            mgr.register_trace(i, info)

        def add_spans(thread_id):
            for trace_idx in range(num_traces):
                mock_s = _make_mock_otel_span(trace_id=trace_idx,
                                               span_id=thread_id * 100 + trace_idx)
                live = LiveSpan(mock_s, f"tr-thread-{trace_idx}")
                mgr.register_span(live)

        threads = [Thread(target=add_spans, args=[i]) for i in range(num_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        for i in range(num_traces):
            result = mgr.pop_trace(i)
            assert result is not None
            # Each trace should have num_threads spans
            assert len(result.trace.data.spans) == num_threads, (
                f"Trace {i}: expected {num_threads} spans, got {len(result.trace.data.spans)}"
            )

        # Non-existent trace returns None
        assert mgr.pop_trace(99999) is None
    finally:
        InMemoryTraceManager.reset()


# ---------------------------------------------------------------------------
# C23: set_request_response_preview populates previews
# Graph: N14, N11, N10, E3
# ---------------------------------------------------------------------------

# Contracts: C23
# Reference: libs/skinny/mlflow/tracing/utils/truncation.py:15-24
# Perspective: set_request_response_preview sets non-empty previews from
# trace data request/response
def check_set_request_response_preview() -> None:
    """set_request_response_preview populates request/response previews
    on a TraceInfo object."""
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities import LiveSpan, SpanStatus, SpanStatusCode
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.utils.truncation import set_request_response_preview

    # Build a trace with root span inputs/outputs
    mock_span = _make_mock_otel_span(trace_id=1, span_id=1, name="root")
    live = LiveSpan(mock_span, "tr-test-c23")
    live.set_inputs({"query": "hello"})
    live.set_outputs({"answer": "world"})
    live.set_status(SpanStatus(SpanStatusCode.OK))
    immutable = live.to_immutable_span()

    td = TraceData(spans=[immutable])
    td.request = json.dumps({"query": "hello"})
    td.response = json.dumps({"answer": "world"})

    info = TraceInfo(
        trace_id="tr-test-c23",
        trace_location=TraceLocation.from_experiment_id("test"),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
        trace_metadata={"mlflow.trace_schema.version": "3"},
        tags={},
    )

    set_request_response_preview(info, td)

    # Preview should be non-empty string
    assert info.request_preview is not None
    assert len(info.request_preview) > 0
    assert info.response_preview is not None
    assert len(info.response_preview) > 0

    # If already set by user, it should NOT be overwritten
    info.request_preview = "user-set-preview"
    set_request_response_preview(info, td)
    assert info.request_preview == "user-set-preview"


# ---------------------------------------------------------------------------
# C24: apply_span_processors invokes configured processors
# Graph: N15, E14
# ---------------------------------------------------------------------------

# Contracts: C24
# Reference: libs/skinny/mlflow/tracing/utils/processor.py:9-30
# Perspective: Span processors are called with the span object
def check_apply_span_processors_invocation() -> None:
    """apply_span_processors calls each configured processor with the span."""
    from mlflow.entities import LiveSpan
    from mlflow.tracing.utils.processor import apply_span_processors
    from mlflow.tracing.config import get_config

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    live = LiveSpan(mock_span, "tr-test-c24")

    # Simulate a processor that records it was called
    called_args = []

    def test_processor(span):
        called_args.append(span)

    # Patch config to include our test processor
    config = get_config()
    original_processors = config.span_processors
    try:
        config.span_processors = [test_processor]
        apply_span_processors(live)

        assert len(called_args) == 1
        assert called_args[0] is live
    finally:
        config.span_processors = original_processors


# ---------------------------------------------------------------------------
# C26: LiveSpan.end automatically sets OK status
# Graph: N2, E14
# ---------------------------------------------------------------------------

# Contracts: C26
# Reference: libs/skinny/mlflow/entities/span.py:648-649
# Perspective: end() sets OK status unless status is ERROR
def check_livespan_end_auto_ok_status() -> None:
    """LiveSpan.end() automatically sets OK status if not ERROR."""
    from mlflow.entities import LiveSpan, SpanStatus, SpanStatusCode
    from mlflow.tracing.utils.processor import apply_span_processors

    # Patch apply_span_processors to avoid config dependency
    with mock.patch("mlflow.entities.span.apply_span_processors"):
        mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
        live = LiveSpan(mock_span, "tr-test-c26")

        # Status should be OK after end() (set automatically)
        live.end()
        assert live.status.status_code == SpanStatusCode.OK

    # When status is explicitly set to ERROR, it stays ERROR
    with mock.patch("mlflow.entities.span.apply_span_processors"):
        mock_span2 = _make_mock_otel_span(trace_id=3, span_id=4)
        live2 = LiveSpan(mock_span2, "tr-test-c26b")
        live2.set_status(SpanStatus(SpanStatusCode.ERROR))
        live2.end()
        assert live2.status.status_code == SpanStatusCode.ERROR


# ---------------------------------------------------------------------------
# C29: Span.from_dict_v2 handles v2 schema
# Graph: N1, E8
# ---------------------------------------------------------------------------

# Contracts: C29
# Reference: tests/tracing/helper.py:V2_TRACE_DICT
# Perspective: V2 dicts with context.span_id, context.trace_id deserialize
def check_span_from_dict_v2() -> None:
    """Span.from_dict_v2 creates valid Span from v2 schema dict."""
    from mlflow.entities import Span

    v2_span = {
        "name": "test_v2",
        "context": {
            "span_id": "0d48a6670588966b",
            "trace_id": "63076d0c1b90f1df0970f897dc428bd6",
        },
        "parent_id": None,
        "start_time": 100,
        "end_time": 200,
        "status_code": "OK",
        "status_message": "",
        "attributes": {
            "mlflow.traceRequestId": '"tr-from-v2"',
            "mlflow.spanType": '"LLM"',
        },
        "events": [],
    }

    result = Span.from_dict(v2_span)
    assert isinstance(result, Span)
    assert result.name == "test_v2"


# ---------------------------------------------------------------------------
# C30: _is_span_v2_schema detects v2 format
# Graph: N1, E8
# ---------------------------------------------------------------------------

# Contracts: C30
# Reference: libs/skinny/mlflow/entities/span.py:332-334
# Perspective: _is_span_v2_schema returns True for dicts with "context" key
def check_is_span_v2_schema() -> None:
    """_is_span_v2_schema returns True for v2 dicts, False for v3."""
    from mlflow.entities.span import Span

    # v2 schema has "context" key
    v2 = {"context": {"span_id": "abc", "trace_id": "def"}, "name": "x"}
    assert Span._is_span_v2_schema(v2) is True

    # v3 schema does not have "context" key
    v3 = {"trace_id": "abc123", "span_id": "def456", "name": "y",
          "start_time_unix_nano": 100, "status": {"code": "OK"},
          "attributes": {"mlflow.traceRequestId": '"tr-test"'}}
    assert Span._is_span_v2_schema(v3) is False


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    failures = []
    for name, fn in sorted(globals().items()):
        if name.startswith("check_") and callable(fn):
            try:
                fn()
                print(f"PASS: {name}")
            except Exception as e:
                failures.append(name)
                print(f"FAIL: {name} -- {e}")
                import traceback; traceback.print_exc()
    if failures:
        print(f"\n{failures} tests FAILED: {failures}")
        raise SystemExit(1)
    else:
        print(f"\nAll tests PASSED")
