# Semantic IR

## L1. Requirement Obligations

### R1: Span Lifecycle Management
- Type: Behavior
- Statement: The system must support span lifecycle management including creation, attribute setting, status updates, and termination. LiveSpan provides mutable span operations (set_attribute, set_attributes, set_inputs, set_outputs, set_status, set_span_type, add_event, end); NoOpSpan provides no-op fallbacks that accept the same arguments without raising errors; Span provides immutable read-only access.
- Task Evidence: "Span lifecycle management (creation, attribute setting, status updates, termination)" and "No-op span implementation for graceful failure handling"
- Acceptance: LiveSpan.set_attribute(key, value) stores attribute; LiveSpan.end() terminates span and sets OK status unless ERROR; NoOpSpan.set_attribute(key, value) does nothing; Span.attributes returns deserialized dict.
- Repository Evidence: `/testbed/mlflow/entities/span.py:LiveSpan` (partial), `/testbed/mlflow/entities/span.py:NoOpSpan` (partial), `/testbed/mlflow/entities/span.py:Span` (partial), `/testbed/libs/skinny/mlflow/entities/span.py` (complete reference)
- Uncertainty: None

### R2: Span Serialization to Dictionary
- Type: Dataflow
- Statement: `Span.to_dict()` must serialize the span to a dictionary with trace_id, span_id, parent_span_id as base64-encoded byte strings, name, start/end times in nanoseconds, events list, status dict, and attributes dict.
- Task Evidence: "Enable trace data serialization/deserialization across different formats (dict, protobuf)" and Interface Description 2 `Span.to_dict()` notes 1-5 about base64 encoding.
- Acceptance: `Span.to_dict()` returns dict with keys: trace_id (b64), span_id (b64), parent_span_id (b64|None), name, start_time_unix_nano, end_time_unix_nano, events, status, attributes.
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:227` (complete reference), `/testbed/mlflow/entities/span.py:~227` (empty)
- Uncertainty: None

### R3: Span Deserialization from Dictionary
- Type: Dataflow
- Statement: `Span.from_dict(data)` must reconstruct a Span from a dictionary, handling both v2 schema (via `from_dict_v2`) and v3 schema (base64-encoded IDs or property-format IDs), and `LiveSpan.from_dict(data)` must raise NotImplementedError.
- Task Evidence: "Handle multiple serialization schemas (v2, v3) for backward compatibility" and Interface Description 2 `LiveSpan.from_dict`
- Acceptance: `Span.from_dict(dict)` returns Span; `LiveSpan.from_dict(dict)` raises NotImplementedError; v2 spans with request_id/experiment_id detected by `_is_span_v2_schema`.
- Repository Evidence: `/testbed/mlflow/entities/span.py:258` (partial from_dict), `/testbed/libs/skinny/mlflow/entities/span.py:258-365` (complete reference)
- Uncertainty: None

### R4: OpenTelemetry Protocol Buffer Conversion
- Type: Compatibility
- Statement: `Span.from_otel_proto(otel_proto_span, location_id)` must create a Span from an OTLP protobuf span; `Span.to_otel_proto()` must convert to OTelProtoSpan; `_decode_otel_proto_anyvalue(pb_any_value)` must decode AnyValue protobuf to Python types.
- Task Evidence: "Provide OpenTelemetry protocol compatibility for trace data exchange" and Interface Description 2 `Span.from_otel_proto`, `Span.to_otel_proto`, Interface Description 3 `_decode_otel_proto_anyvalue`
- Acceptance: Round-trip: OTelProtoSpan -> Span.from_otel_proto -> Span.to_otel_proto preserves trace_id, span_id, attributes, events, status.
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:366-455` (complete reference), `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:_decode_otel_proto_anyvalue` (complete reference)
- Uncertainty: None

### R5: Span Attribute Registry with JSON Serialization
- Type: Dataflow
- Statement: `_SpanAttributesRegistry` serializes all attribute values to JSON before storing in OTel span attributes; `_CachedSpanAttributesRegistry` caches deserialized values for immutable spans and prevents mutation via `set()`.
- Task Evidence: "Attribute registry with JSON serialization for complex data types" and "Implement efficient caching for immutable span attributes while preventing updates"
- Acceptance: `_SpanAttributesRegistry.get(key)` returns deserialized Python value; `_SpanAttributesRegistry.set(key, value)` stores JSON-serialized string; `_CachedSpanAttributesRegistry.set(key, value)` raises MlflowException.
- Repository Evidence: `/testbed/mlflow/entities/span.py:854-904` (partial), `/testbed/libs/skinny/mlflow/entities/span.py:854-908` (complete reference)
- Uncertainty: None

### R6: Span Events and Exceptions
- Type: Behavior
- Statement: `Span.events` must return list of SpanEvent objects from the OTel span; `LiveSpan.add_event(event)` must add event to OTel span; `LiveSpan.record_exception(exception)` must add exception event and set ERROR status.
- Task Evidence: "Event logging and exception recording within spans" and Interface Description 2 `Span.events`, `NoOpSpan.add_event`
- Acceptance: `Span.events` returns list[SpanEvent]; `LiveSpan.add_event(SpanEvent(...))` adds to OTel span events; `NoOpSpan.add_event(event)` is no-op.
- Repository Evidence: `/testbed/mlflow/entities/span.py:191` (empty), `/testbed/libs/skinny/mlflow/entities/span.py:190-207` (complete reference)
- Uncertainty: None

### R7: NoOp Span Graceful Fallback
- Type: Failure
- Statement: `NoOpSpan` must implement all Span/LiveSpan interface methods as no-ops returning None/null values, allowing user code to continue without errors when span creation fails. Properties: trace_id returns NO_OP_SPAN_TRACE_ID constant, span_id/name/start_time_ns/end_time_ns/status/_trace_id return None.
- Task Evidence: "No-op span implementation for graceful failure handling" and Interface Description 2 `NoOpSpan` methods
- Acceptance: All NoOpSpan method calls complete without exceptions; NoOpSpan.trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"; all other properties return None; setter methods accept arguments silently.
- Repository Evidence: `/testbed/mlflow/entities/span.py:761-850` (partial), `/testbed/libs/skinny/mlflow/entities/span.py:761-850` (complete reference)
- Uncertainty: None

### R8: Span Type Management
- Type: Behavior
- Statement: `LiveSpan.set_span_type(span_type)` must set the span type attribute; `Span.span_type` property must return the span type from attributes; the type defaults to SpanType.UNKNOWN.
- Task Evidence: "Span lifecycle management (creation, attribute setting, status updates, termination)" and Interface Description 2 `LiveSpan.set_span_type`, `Span.span_type`
- Acceptance: `span.set_span_type("LLM")` results in `span.span_type == "LLM"`; `Span.span_type` reads from SpanAttributeKey.SPAN_TYPE attribute.
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span.span_type` (empty), `/testbed/libs/skinny/mlflow/entities/span.py:167-169, 525-527` (complete reference)
- Uncertainty: None

### R9: Live-to-Immutable Span Conversion
- Type: State
- Statement: `LiveSpan.to_immutable_span()` must convert the mutable LiveSpan to an immutable Span by wrapping the underlying OTel span in a Span object without data copying.
- Task Evidence: "Support both live (mutable) and immutable span states during execution lifecycle" and Interface Description 2 `LiveSpan.to_immutable_span`
- Acceptance: `live_span.to_immutable_span()` returns Span instance; returned Span has same data as original LiveSpan; returned Span's attributes are accessed via _CachedSpanAttributesRegistry.
- Repository Evidence: `/testbed/mlflow/entities/span.py:~668` (empty), `/testbed/libs/skinny/mlflow/entities/span.py:668-676` (complete reference)
- Uncertainty: None

### R10: Trace-to-MLflow-Trace Conversion
- Type: Dataflow
- Statement: `_Trace.to_mlflow_trace()` must convert all LiveSpan objects in span_dict to immutable Span objects via `to_immutable_span()`, create a TraceData container, call `set_request_response_preview` on the trace info, and return a Trace.
- Task Evidence: "Manage trace state transitions from live to immutable spans" and Interface Description 1 `_Trace.to_mlflow_trace`
- Acceptance: `_Trace.to_mlflow_trace()` returns Trace with TraceData containing immutable Span objects; TraceInfo request_preview/response_preview populated.
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:26-33` (empty), `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:26-33` (complete reference)
- Uncertainty: None

### R11: Factory Function for Span Creation
- Type: Interface
- Statement: `create_mlflow_span(otel_span, trace_id, span_type)` must return LiveSpan for OTelSpan (active), Span for OTelReadableSpan (finished), NoOpSpan for NonRecordingSpan or None.
- Task Evidence: "Span lifecycle management" and Interface Description 2 `create_mlflow_span`
- Acceptance: `create_mlflow_span(OTelSpan(...), "trace-1", "LLM")` returns LiveSpan; `create_mlflow_span(OTelReadableSpan(...), "trace-1")` returns Span; `create_mlflow_span(NonRecordingSpan(...), "trace-1")` returns NoOpSpan; `create_mlflow_span(None, "trace-1")` returns NoOpSpan.
- Repository Evidence: `/testbed/mlflow/entities/span.py:~66` (empty), `/testbed/libs/skinny/mlflow/entities/span.py:66-88` (complete reference)
- Uncertainty: None

### R12: Trace ID and Span ID Encoding/Decoding
- Type: Dataflow
- Statement: Trace IDs (16 bytes) and span IDs (8 bytes) must be encoded from integer to base64 string via int.to_bytes(big-endian) then base64.b64encode, and decoded in reverse. Helper functions: `_encode_trace_id_to_byte`, `_encode_span_id_to_byte`, `_encode_bytes_to_base64`, `_decode_id_from_byte`, `_is_base64_encoded`.
- Task Evidence: "Trace ID and span ID generation/encoding for distributed system coordination" and Interface Description 2 `Span.to_dict` encoding notes
- Acceptance: `_encode_trace_id_to_byte(trace_id_int)` -> 16 bytes; `_encode_span_id_to_byte(span_id_int)` -> 8 bytes; `_encode_bytes_to_base64(b)` -> base64 string; round-trip decode preserves value.
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:456-476` (complete reference), `/testbed/mlflow/entities/span.py:~456` (empty)
- Uncertainty: None

### R13: Request/Response Preview Population
- Type: SideEffect
- Statement: `set_request_response_preview(trace_info, trace_data)` must populate trace_info.request_preview and trace_info.response_preview from root span inputs/outputs, truncated to max length, unless already set by user.
- Task Evidence: "Enable trace data serialization/deserialization" and Interface Description 1 `_Trace.to_mlflow_trace` notes about set_request_response_preview
- Acceptance: After calling `set_request_response_preview(info, data)`, info.request_preview and info.response_preview are non-empty strings (or empty string if no root span).
- Repository Evidence: `/testbed/mlflow/tracing/utils/truncation.py` (partial), `/testbed/libs/skinny/mlflow/tracing/utils/truncation.py` (complete reference)
- Uncertainty: None

### R14: Thread-Safe Trace Management
- Type: State
- Statement: `InMemoryTraceManager` must use threading.RLock to protect concurrent access to `_traces` dict and `_otel_id_to_mlflow_trace_id` dict during register, pop, and access operations.
- Task Evidence: "Ensure thread-safe operations across concurrent trace operations" and "Thread-safe in-memory trace management with timeout-based cleanup"
- Acceptance: Concurrent `register_span` calls from multiple threads never corrupt trace span_dict; `pop_trace` atomically removes and returns trace.
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:54-56, 72-74` (existing locks)
- Uncertainty: None

### R15: OTLP AnyValue Decoding
- Type: Compatibility
- Statement: `_decode_otel_proto_anyvalue(pb_any_value)` must recursively decode OpenTelemetry protobuf AnyValue messages to Python types: None for unset, bool, str, int, float, bytes, list for arrays, dict for kvlist.
- Task Evidence: "Provide OpenTelemetry protocol compatibility for trace data exchange" and Interface Description 3
- Acceptance: `_decode_otel_proto_anyvalue(AnyValue(string_value="hello"))` returns "hello"; `_decode_otel_proto_anyvalue(AnyValue(array_value=...))` returns Python list.
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py` (empty after `_set_otel_proto_anyvalue`), `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:_decode_otel_proto_anyvalue` (complete reference)
- Uncertainty: None

## L2. Functional Design Graph

### N1: Span (immutable entity)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:91`

### N2: LiveSpan (mutable entity, extends Span)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:484`

### N3: NoOpSpan (fallback entity, extends Span)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:761`

### N4: create_mlflow_span (factory function)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/entities/span.py:~66` (empty), `/testbed/libs/skinny/mlflow/entities/span.py:66`

### N5: _SpanAttributesRegistry (attribute store)
- Kind: State
- Repository Evidence: `/testbed/mlflow/entities/span.py:854`

### N6: _CachedSpanAttributesRegistry (immutable attribute store)
- Kind: State
- Repository Evidence: `/testbed/mlflow/entities/span.py:892`

### N7: _Trace (internal trace state)
- Kind: State
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:20`

### N8: InMemoryTraceManager (singleton registry)
- Kind: State
- Repository Evidence: `/testbed/mlflow/tracing/trace_manager.py:49`

### N9: Trace (public trace entity)
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace.py:29`

### N10: TraceData (span container)
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_data.py:12`

### N11: TraceInfo (trace metadata)
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_info.py:23`

### N12: SpanEvent (event payload)
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/span_event.py:13`

### N13: SpanStatus (status payload)
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/span_status.py:62`

### N14: set_request_response_preview (helper)
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/truncation.py` (partial), `/testbed/libs/skinny/mlflow/tracing/utils/truncation.py:15`

### N15: apply_span_processors (helper)
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/processor.py` (partial), `/testbed/libs/skinny/mlflow/tracing/utils/processor.py:9`

### N16: _decode_otel_proto_anyvalue (OTLP helper)
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py` (empty), `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:_decode_otel_proto_anyvalue`

### N17: _set_otel_proto_anyvalue (OTLP helper)
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/otlp.py:_set_otel_proto_anyvalue` (exists)

### N18: _encode_trace_id_to_byte (ID encoding helper)
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:461`

### N19: _encode_span_id_to_byte (ID encoding helper)
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:456`

### N20: _encode_bytes_to_base64 (base64 encoding helper)
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:466`

### N21: _decode_id_from_byte (ID decoding helper)
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:470`

### N22: _is_base64_encoded (validation helper)
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:476`

### N23: _otel_proto_bytes_to_id (OTLP bytes-to-int helper)
- Kind: Function
- Repository Evidence: `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:_otel_proto_bytes_to_id`

### N24: MlflowV3SpanProcessor (span processor)
- Kind: Observer
- Repository Evidence: `/testbed/mlflow/tracing/processor/mlflow_v3.py:16`

### N25: BaseMlflowSpanProcessor (base span processor)
- Kind: Observer
- Repository Evidence: `/testbed/mlflow/tracing/processor/base_mlflow.py:39`

### E1: InMemoryTraceManager.pop_trace -> _Trace.to_mlflow_trace
- Kind: CALL
- Condition: Always when popping a trace
- Transfer: _Trace internal state (span_dict, info) -> Trace (with immutable spans)
- Evidence: `/testbed/mlflow/tracing/trace_manager.py:186`: `internal_trace.to_mlflow_trace()`
- Obligations: R10, R13

### E2: _Trace.to_mlflow_trace -> LiveSpan.to_immutable_span
- Kind: CALL
- Condition: For each LiveSpan in span_dict
- Transfer: LiveSpan -> Span (immutable)
- Evidence: `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:28-29`
- Obligations: R9, R10

### E3: _Trace.to_mlflow_trace -> N14 (set_request_response_preview)
- Kind: CALL
- Condition: Always
- Transfer: TraceInfo, TraceData -> populated request_preview/response_preview
- Evidence: `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:32`
- Obligations: R10, R13

### E4: LiveSpan.to_immutable_span -> Span.__init__
- Kind: CALL
- Condition: Always
- Transfer: OTelReadableSpan -> Span (wrapping _CachedSpanAttributesRegistry)
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:668-676`
- Obligations: R9

### E5: create_mlflow_span -> LiveSpan / Span / NoOpSpan
- Kind: CONTROL
- Condition: isinstance(otel_span, OTelSpan) -> LiveSpan; isinstance(otel_span, OTelReadableSpan) -> Span; NonRecordingSpan or None -> NoOpSpan
- Transfer: otel_span type -> appropriate MLflow span class
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:66-88`
- Obligations: R1, R7, R11

### E6: BaseMlflowSpanProcessor.on_start -> create_mlflow_span
- Kind: CALL
- Condition: When OTel span starts and trace ID is known
- Transfer: OTelSpan + trace_id -> LiveSpan registered in InMemoryTraceManager
- Evidence: `/testbed/mlflow/tracing/processor/base_mlflow.py:93`: `create_mlflow_span(span, trace_id)`
- Obligations: R1, R11

### E7: Span.to_dict -> N18, N19, N20 (encoding helpers)
- Kind: CALL
- Condition: Always
- Transfer: int trace_id/span_id -> bytes -> base64 string
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:227-257`
- Obligations: R2, R12

### E8: Span.from_dict -> N21, N22 (decoding helpers)
- Kind: CALL
- Condition: When data uses base64-encoded IDs
- Transfer: base64 string -> bytes -> int
- Evidence: `/testbed/mlflow/entities/span.py:272-277`
- Obligations: R3, R12

### E9: Span.from_otel_proto -> N16 (_decode_otel_proto_anyvalue), N23 (_otel_proto_bytes_to_id)
- Kind: CALL
- Condition: Always
- Transfer: OTelProtoSpan -> Span (decoded attributes, events, status)
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:366-421`
- Obligations: R4, R15

### E10: Span.to_otel_proto -> N17 (_set_otel_proto_anyvalue)
- Kind: CALL
- Condition: Always
- Transfer: Span -> OTelProtoSpan
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:422-455`
- Obligations: R4

### E11: _SpanAttributesRegistry.set -> json.dumps
- Kind: DATA
- Condition: Always
- Transfer: Python value -> JSON string stored in OTel span attribute
- Evidence: `/testbed/mlflow/entities/span.py:881-889`
- Obligations: R5

### E12: _SpanAttributesRegistry.get -> json.loads
- Kind: DATA
- Condition: When serialized value exists
- Transfer: JSON string -> deserialized Python value
- Evidence: `/testbed/mlflow/entities/span.py:871-879`
- Obligations: R5

### E13: _CachedSpanAttributesRegistry.set -> MlflowException
- Kind: CONTROL
- Condition: Always (immutable span)
- Transfer: Raises MlflowException(INVALID_PARAMETER_VALUE)
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:905-908`
- Obligations: R5

### E14: LiveSpan.end -> N15 (apply_span_processors)
- Kind: CALL
- Condition: Before ending the OTel span
- Transfer: LiveSpan -> configured span processors
- Evidence: `/testbed/mlflow/entities/span.py:654`
- Obligations: R1

### E15: LiveSpan.set_span_type -> _SpanAttributesRegistry.set
- Kind: CALL
- Condition: Always
- Transfer: span_type string -> SpanAttributeKey.SPAN_TYPE attribute
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:525-527`
- Obligations: R8

### E16: Span.span_type -> _CachedSpanAttributesRegistry.get
- Kind: DATA
- Condition: Always
- Transfer: SpanAttributeKey.SPAN_TYPE -> deserialized span type string
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:167-169`
- Obligations: R8

### E17: Span.attributes -> _CachedSpanAttributesRegistry.get_all
- Kind: DATA
- Condition: Always
- Transfer: All OTel span attributes -> deserialized dict
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:180-188`
- Obligations: R1, R5

### E18: Span.events -> OTelEvent list -> SpanEvent list
- Kind: DATA
- Condition: Always
- Transfer: OTel span events -> list[SpanEvent] with dict attributes
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:190-207`
- Obligations: R6

### E19: NoOpSpan (all methods) -> void/None
- Kind: CONTROL
- Condition: Always
- Transfer: All setter calls are no-ops; property reads return None or NO_OP_SPAN_TRACE_ID
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:761-850`
- Obligations: R7

### E20: Span.request_id -> Span.trace_id
- Kind: DATA
- Condition: Always
- Transfer: trace_id value aliased as request_id
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:120-123`
- Obligations: R1

### E21: _Trace.to_mlflow_trace -> Trace.__init__
- Kind: CALL
- Condition: Always
- Transfer: TraceInfo + TraceData -> Trace
- Evidence: `/testbed/mlflow/entities/trace.py:29`
- Obligations: R10

## L3. Verifiable Contracts

### C1: LiveSpan.set_span_type stores span type attribute
- Type: Behavior
- Subject: N2.LiveSpan.set_span_type
- Relation: EQ
- Expected: After `span.set_span_type("LLM")`, `span.span_type` returns `"LLM"` and the OTel attribute `SpanAttributeKey.SPAN_TYPE` contains JSON-serialized `"LLM"`.
- Evidence: Interface Description 2 `LiveSpan.set_span_type`, `/testbed/libs/skinny/mlflow/entities/span.py:525-527`
- Observe: RETURN_VALUE / FIELD_READ
- Target: `LiveSpan.set_span_type` -> `Span.span_type` property
- Obligations: R8
- Graph: N2, E15, E16

### C2: LiveSpan.to_immutable_span returns Span with same data
- Type: State
- Subject: N2.LiveSpan.to_immutable_span
- Relation: EQ
- Expected: `live_span.to_immutable_span()` returns `Span` instance; returned Span has same name, trace_id, span_id, attributes, events, status as the original LiveSpan.
- Evidence: Interface Description 2 `LiveSpan.to_immutable_span`, `/testbed/libs/skinny/mlflow/entities/span.py:668-676`
- Observe: RETURN_VALUE
- Target: `LiveSpan.to_immutable_span()`
- Obligations: R9
- Graph: N2, N1, E4

### C3: _Trace.to_mlflow_trace returns Trace with immutable spans
- Type: Dataflow
- Subject: N7._Trace.to_mlflow_trace
- Relation: TYPE_IS
- Expected: Returns `Trace` instance; `trace.data.spans` contains only `Span` instances (not `LiveSpan`); `trace.info` is the same TraceInfo; `trace.info.request_preview` and `trace.info.response_preview` are set.
- Evidence: Interface Description 1 `/testbed/mlflow/tracing/trace_manager.py:_Trace.to_mlflow_trace`, `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:26-33`, `/testbed/tests/tracing/test_trace_manager.py:64-66`
- Observe: RETURN_VALUE
- Target: `InMemoryTraceManager.pop_trace()` -> `ManagerTrace.trace`
- Obligations: R10, R13
- Graph: N7, N9, N10, E1, E2, E3, E21

### C4: Span.to_dict encodes IDs as base64
- Type: Dataflow
- Subject: N1.Span.to_dict
- Relation: EQ
- Expected: trace_id is base64(16-byte big-endian int); span_id is base64(8-byte big-endian int); parent_span_id is base64(8-byte big-endian int) or None; round-trip via `Span.from_dict(span.to_dict())` preserves span data.
- Evidence: Interface Description 2 `Span.to_dict` notes 1-5, `/testbed/libs/skinny/mlflow/entities/span.py:227-257`
- Observe: RETURN_VALUE
- Target: `Span.to_dict()`
- Obligations: R2, R12
- Graph: N1, E7, N18, N19, N20

### C5: Span.from_dict handles v2 and v3 schemas
- Type: Compatibility
- Subject: N1.Span.from_dict
- Relation: EQ
- Expected: v2 schema dict (with request_id/experiment_id in info) -> valid Span; v3 schema dict (base64 IDs) -> valid Span; v3 schema dict (property-format IDs from 3.5.0) -> valid Span.
- Evidence: Interface Description 2 `Span.to_dict` cross-reference, `/testbed/mlflow/entities/span.py:258-325`, `/testbed/tests/tracing/helper.py:V2_TRACE_DICT`
- Observe: RETURN_VALUE
- Target: `Span.from_dict(data)`
- Obligations: R3, R12
- Graph: N1, E8, N21, N22

### C6: LiveSpan.from_dict raises NotImplementedError
- Type: Failure
- Subject: N2.LiveSpan.from_dict
- Relation: RAISES
- Expected: `LiveSpan.from_dict({...})` raises `NotImplementedError`.
- Evidence: Interface Description 2 `LiveSpan.from_dict`, `/testbed/libs/skinny/mlflow/entities/span.py:665-666`
- Observe: EXCEPTION
- Target: `LiveSpan.from_dict(data)`
- Obligations: R3
- Graph: N2

### C7: Span.from_otel_proto creates Span from protobuf
- Type: Compatibility
- Subject: N1.Span.from_otel_proto
- Relation: EQ
- Expected: OTelProtoSpan with trace_id bytes, span_id bytes, name, timestamps, attributes, events, status -> Span with matching fields; REQUEST_ID attribute set from generated MLflow trace ID.
- Evidence: Interface Description 2 `Span.from_otel_proto`, `/testbed/libs/skinny/mlflow/entities/span.py:366-421`
- Observe: RETURN_VALUE
- Target: `Span.from_otel_proto(otel_proto_span)`
- Obligations: R4, R15
- Graph: N1, E9, N16, N23

### C8: Span.to_otel_proto converts to protobuf
- Type: Compatibility
- Subject: N1.Span.to_otel_proto
- Relation: EQ
- Expected: Returns OTelProtoSpan with trace_id/span_id bytes, name, start/end times, status, attributes as AnyValue, events.
- Evidence: Interface Description 2 `Span.to_otel_proto`, `/testbed/libs/skinny/mlflow/entities/span.py:422-455`
- Observe: RETURN_VALUE
- Target: `Span.to_otel_proto()`
- Obligations: R4
- Graph: N1, E10, N17

### C9: _decode_otel_proto_anyvalue decodes all types
- Type: Dataflow
- Subject: N16._decode_otel_proto_anyvalue
- Relation: EQ
- Expected: string_value -> str; int_value -> int; double_value -> float; bool_value -> bool; bytes_value -> bytes; array_value -> list; kvlist_value -> dict; unset -> None.
- Evidence: Interface Description 3, `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:_decode_otel_proto_anyvalue`
- Observe: RETURN_VALUE
- Target: `_decode_otel_proto_anyvalue(AnyValue(...))`
- Obligations: R15
- Graph: N16

### C10: _CachedSpanAttributesRegistry.set raises MlflowException
- Type: Failure
- Subject: N6._CachedSpanAttributesRegistry.set
- Relation: RAISES
- Expected: `_CachedSpanAttributesRegistry(...).set("key", "value")` raises `MlflowException` with error_code `INVALID_PARAMETER_VALUE`.
- Evidence: Interface Description 2 `_CachedSpanAttributesRegistry.set`, `/testbed/libs/skinny/mlflow/entities/span.py:905-908`
- Observe: EXCEPTION
- Target: `_CachedSpanAttributesRegistry(span).set("key", "value")`
- Obligations: R5
- Graph: N6, E13

### C11: NoOpSpan.trace_id returns NO_OP_SPAN_TRACE_ID constant
- Type: Interface
- Subject: N3.NoOpSpan.trace_id
- Relation: EQ
- Expected: `NoOpSpan().trace_id` returns `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Evidence: Interface Description 2 `NoOpSpan.trace_id`, `/testbed/libs/skinny/mlflow/entities/span.py:784-789`
- Observe: FIELD_READ
- Target: `NoOpSpan().trace_id`
- Obligations: R7
- Graph: N3

### C12: NoOpSpan properties return None
- Type: Interface
- Subject: N3.NoOpSpan (span_id, name, start_time_ns, end_time_ns, status, _trace_id)
- Relation: EQ
- Expected: All of `NoOpSpan().span_id`, `NoOpSpan().name`, `NoOpSpan().start_time_ns`, `NoOpSpan().end_time_ns`, `NoOpSpan().status`, `NoOpSpan()._trace_id` return `None`.
- Evidence: Interface Description 2 NoOpSpan properties, `/testbed/libs/skinny/mlflow/entities/span.py:791-821`
- Observe: FIELD_READ
- Target: `NoOpSpan()` property accessors
- Obligations: R7
- Graph: N3

### C13: NoOpSpan setter methods are no-ops
- Type: Behavior
- Subject: N3.NoOpSpan (set_inputs, set_outputs, set_attributes, set_attribute, set_status, add_event, end)
- Relation: EQ
- Expected: Calling any setter method on NoOpSpan with any arguments does nothing and does not raise.
- Evidence: Interface Description 2 NoOpSpan methods, `/testbed/libs/skinny/mlflow/entities/span.py:823-850`
- Observe: RETURN_VALUE (None)
- Target: `NoOpSpan().set_attribute("key", "value")` etc.
- Obligations: R7
- Graph: N3, E19

### C14: create_mlflow_span returns correct type
- Type: Interface
- Subject: N4.create_mlflow_span
- Relation: TYPE_IS
- Expected: OTelSpan -> LiveSpan; OTelReadableSpan -> Span; NonRecordingSpan -> NoOpSpan; None -> NoOpSpan.
- Evidence: Interface Description 2 `create_mlflow_span`, `/testbed/libs/skinny/mlflow/entities/span.py:66-88`
- Observe: RETURN_VALUE
- Target: `create_mlflow_span(otel_span, trace_id, span_type)`
- Obligations: R11
- Graph: N4, E5

### C15: Span.attributes returns all deserialized attributes
- Type: Dataflow
- Subject: N1.Span.attributes
- Relation: EQ
- Expected: Returns dict with all span attribute keys mapped to deserialized Python values (via json.loads).
- Evidence: Interface Description 2 `Span.attributes`, `/testbed/libs/skinny/mlflow/entities/span.py:180-188`
- Observe: FIELD_READ
- Target: `Span.attributes`
- Obligations: R1, R5
- Graph: N1, E17, N6

### C16: Span.events returns list of SpanEvent
- Type: Dataflow
- Subject: N1.Span.events
- Relation: TYPE_IS
- Expected: Returns `list[SpanEvent]`; each SpanEvent has name, timestamp, attributes as plain dict.
- Evidence: Interface Description 2 `Span.events`, `/testbed/libs/skinny/mlflow/entities/span.py:190-207`
- Observe: FIELD_READ
- Target: `Span.events`
- Obligations: R6
- Graph: N1, E18, N12

### C17: Span.request_id is alias for trace_id
- Type: Interface
- Subject: N1.Span.request_id
- Relation: EQ
- Expected: `span.request_id` returns same value as `span.trace_id`.
- Evidence: Interface Description 2 `Span.request_id`, `/testbed/libs/skinny/mlflow/entities/span.py:120-123`
- Observe: FIELD_READ
- Target: `Span.request_id`
- Obligations: R1
- Graph: N1, E20

### C18: Span.span_type reads from attributes
- Type: Dataflow
- Subject: N1.Span.span_type
- Relation: EQ
- Expected: Returns value of `SpanAttributeKey.SPAN_TYPE` attribute via `get_attribute`.
- Evidence: Interface Description 2 `Span.span_type`, `/testbed/libs/skinny/mlflow/entities/span.py:167-169`
- Observe: FIELD_READ
- Target: `Span.span_type`
- Obligations: R8
- Graph: N1, E16

### C19: Thread-safe InMemoryTraceManager.pop_trace
- Type: State
- Subject: N8.InMemoryTraceManager.pop_trace
- Relation: PRESERVE
- Expected: After concurrent `register_span` calls from 10 threads on 5 traces, `pop_trace` for each trace returns ManagerTrace with exactly `num_threads` spans.
- Evidence: `/testbed/tests/tracing/test_trace_manager.py:76-97` (`test_add_and_pop_span_thread_safety`), `/testbed/mlflow/tracing/trace_manager.py:175-187`
- Observe: RETURN_VALUE
- Target: `InMemoryTraceManager.pop_trace(otel_trace_id)`
- Obligations: R14
- Graph: N8, N7, E1

### C20: ID encoding round-trip preserves value
- Type: Dataflow
- Subject: N18, N19, N20, N21
- Relation: EQ
- Expected: `_decode_id_from_byte(_encode_bytes_to_base64(_encode_trace_id_to_byte(n))) == n` for any int n; similarly for span_id with 8 bytes.
- Evidence: Interface Description 2 `Span.to_dict` encoding notes, `/testbed/libs/skinny/mlflow/entities/span.py:456-476`
- Observe: RETURN_VALUE
- Target: `_decode_id_from_byte(_encode_bytes_to_base64(_encode_span_id_to_byte(span_id)))`
- Obligations: R12
- Graph: N18, N19, N20, N21

### C21: NoOpSpan.end is no-op
- Type: Behavior
- Subject: N3.NoOpSpan.end
- Relation: EQ
- Expected: `NoOpSpan().end(outputs={"x": 1}, attributes={"a": 1}, status="OK")` does nothing and returns None.
- Evidence: Interface Description 2 `NoOpSpan.end`, `/testbed/libs/skinny/mlflow/entities/span.py:844-850`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().end(...)`
- Obligations: R7
- Graph: N3, E19

### C22: NoOpSpan.add_event is no-op
- Type: Behavior
- Subject: N3.NoOpSpan.add_event
- Relation: EQ
- Expected: `NoOpSpan().add_event(SpanEvent(name="test"))` does nothing and returns None.
- Evidence: Interface Description 2 `NoOpSpan.add_event`, `/testbed/libs/skinny/mlflow/entities/span.py:838-839`
- Observe: RETURN_VALUE
- Target: `NoOpSpan().add_event(event)`
- Obligations: R7
- Graph: N3, E19

### C23: set_request_response_preview populates previews
- Type: SideEffect
- Subject: N14.set_request_response_preview
- Relation: PRESERVE
- Expected: After calling, `trace_info.request_preview` is a non-empty string (if root span has inputs); if preview already set by user, it is NOT overwritten.
- Evidence: `/testbed/libs/skinny/mlflow/tracing/utils/truncation.py:15-24`
- Observe: SIDE_EFFECT
- Target: `set_request_response_preview(trace_info, trace_data)`
- Obligations: R13
- Graph: N14, N11, N10, E3

### C24: apply_span_processors invokes configured processors
- Type: SideEffect
- Subject: N15.apply_span_processors
- Relation: CALLS
- Expected: If `get_config().span_processors` is non-empty, each processor is called with the span; processor exceptions are caught and logged.
- Evidence: `/testbed/libs/skinny/mlflow/tracing/utils/processor.py:9-30`
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `apply_span_processors(span)` (indirect via `LiveSpan.end()`)
- Obligations: R1
- Graph: N15, E14

### C25: _otel_proto_bytes_to_id converts bytes to int
- Type: Dataflow
- Subject: N23._otel_proto_bytes_to_id
- Relation: EQ
- Expected: `_otel_proto_bytes_to_id(b'\x00\x00\x00\x00\x00\x00\x00\x01')` returns `1`.
- Evidence: `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:_otel_proto_bytes_to_id`
- Observe: RETURN_VALUE
- Target: `_otel_proto_bytes_to_id(id_bytes)`
- Obligations: R4, R15
- Graph: N23, E9

### C26: LiveSpan.end automatically sets OK status
- Type: State
- Subject: N2.LiveSpan.end
- Relation: TRANSITIONS
- Expected: If span status is not ERROR when `end()` is called, status is set to OK before ending.
- Evidence: `/testbed/mlflow/entities/span.py:648-649`, `/testbed/libs/skinny/mlflow/entities/span.py:648-649`
- Observe: STATE_READ
- Target: `LiveSpan.end()` -> `span.status`
- Obligations: R1
- Graph: N2, E14

### C27: _SpanAttributesRegistry.get_all returns all attributes
- Type: Dataflow
- Subject: N5._SpanAttributesRegistry.get_all
- Relation: EQ
- Expected: Returns dict mapping all attribute keys to deserialized values.
- Evidence: `/testbed/libs/skinny/mlflow/entities/span.py:868-869`
- Observe: RETURN_VALUE
- Target: `_SpanAttributesRegistry(span).get_all()`
- Obligations: R5
- Graph: N5, E17

### C28: _is_base64_encoded detects base64 strings
- Type: Dataflow
- Subject: N22._is_base64_encoded
- Relation: EQ
- Expected: Returns True for valid base64 strings (no hex prefix), False for hex strings like "0d48a6670588966b".
- Evidence: `/testbed/mlflow/entities/span.py:272` (used in from_dict), `/testbed/libs/skinny/mlflow/entities/span.py:476-481`
- Observe: RETURN_VALUE
- Target: `_is_base64_encoded(s)`
- Obligations: R3, R12
- Graph: N22, E8

### C29: Span.from_dict_v2 handles v2 schema
- Type: Compatibility
- Subject: N1.Span.from_dict_v2
- Relation: EQ
- Expected: V2 dict with context.span_id, context.trace_id, parent_id, status_code -> valid Span.
- Evidence: `/testbed/tests/tracing/helper.py:V2_TRACE_DICT`, `/testbed/libs/skinny/mlflow/entities/span.py:336-365`
- Observe: RETURN_VALUE
- Target: `Span.from_dict_v2(v2_data)`
- Obligations: R3
- Graph: N1, E8

### C30: _is_span_v2_schema detects v2 format
- Type: Dataflow
- Subject: N1.Span._is_span_v2_schema
- Relation: EQ
- Expected: Returns True for v2 dicts (containing "context" or "status_code" keys), False for v3 dicts.
- Evidence: `/testbed/mlflow/entities/span.py:269` (used), `/testbed/libs/skinny/mlflow/entities/span.py:332-334`
- Observe: RETURN_VALUE
- Target: `Span._is_span_v2_schema(data)`
- Obligations: R3
- Graph: N1, E8
