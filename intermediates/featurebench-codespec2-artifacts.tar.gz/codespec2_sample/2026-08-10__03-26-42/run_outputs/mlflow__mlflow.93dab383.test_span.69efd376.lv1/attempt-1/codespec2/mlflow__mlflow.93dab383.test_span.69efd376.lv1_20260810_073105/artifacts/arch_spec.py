"""
Architecture specification: public interface and graph connectivity.

Compiles L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts from the
semantic IR. Each check proves that a requirement travels through real
repository code from a public entry to the stated observer.
"""

import base64
import json
import time
from unittest import mock

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_otel_span(trace_id=1, span_id=2, name="test_span",
                          parent_id=None, start_time=None, end_time=None):
    """Create a mock OpenTelemetry span (both OTelSpan and OTelReadableSpan)."""
    from opentelemetry import trace as trace_api
    from opentelemetry.sdk.trace import Event as OTelEvent
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan

    class _MockSpanContext:
        def __init__(self, trace_id, span_id):
            self.trace_id = trace_id
            self.span_id = span_id
            self.trace_flags = trace_api.TraceFlags(1)
            self.trace_state = trace_api.TraceState()
            self.is_remote = False

    class _MockOTelSpan(trace_api.Span, OTelReadableSpan):
        def __init__(self, name, context, parent, start_time=None,
                     end_time=None, status=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time or int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status or trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = {}
            self._events = []

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(OTelEvent(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self._name = name

        def end(self, end_time=None):
            pass

        def record_exception(self, *args, **kwargs):
            pass

    ctx = _MockSpanContext(trace_id, span_id)
    parent_ctx = _MockSpanContext(trace_id, parent_id) if parent_id else None
    return _MockOTelSpan(name=name, context=ctx, parent=parent_ctx,
                         start_time=start_time, end_time=end_time)


# ---------------------------------------------------------------------------
# C3: _Trace.to_mlflow_trace returns Trace with immutable spans
# Graph: N7, N9, N10, E1, E2, E3
# ---------------------------------------------------------------------------

# Contracts: C3
def check_trace_to_mlflow_trace_connectivity() -> None:
    """Prove _Trace.to_mlflow_trace returns Trace with immutable Span objects.
    The method converts LiveSpan objects in span_dict to immutable Span via
    to_immutable_span(), creates TraceData, and returns a Trace."""
    from mlflow.tracing.trace_manager import _Trace
    from mlflow.entities import LiveSpan, Span, TraceInfo, Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-test-c3",
        trace_location=TraceLocation.from_experiment_id("test"),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
        trace_metadata={"mlflow.trace_schema.version": "3"},
        tags={},
    )

    internal_trace = _Trace(info=info)

    # Add a LiveSpan to span_dict
    mock_span = _make_mock_otel_span(trace_id=99999, span_id=1, name="root")
    live = LiveSpan(mock_span, "tr-test-c3")
    internal_trace.span_dict[live.span_id] = live

    # Direct call to to_mlflow_trace()
    result = internal_trace.to_mlflow_trace()

    assert isinstance(result, Trace)
    assert isinstance(result.trace_data, TraceData)
    assert result.info is info
    for s in result.trace_data.spans:
        assert isinstance(s, Span)
        assert not isinstance(s, LiveSpan)


# ---------------------------------------------------------------------------
# C4: Span.to_dict encodes IDs as base64 via helpers
# Graph: N1, E7, N18, N19, N20
# ---------------------------------------------------------------------------

# Contracts: C4
def check_span_to_dict_base64_encoding() -> None:
    """Span.to_dict() produces base64-encoded trace_id and span_id."""
    from mlflow.entities import LiveSpan, Span, SpanStatus, SpanStatusCode
    from mlflow.entities.span import (
        _encode_trace_id_to_byte, _encode_span_id_to_byte, _encode_bytes_to_base64
    )

    # Create a LiveSpan, convert to immutable, then call to_dict
    mock_span = _make_mock_otel_span(trace_id=0xABCDEF01, span_id=0x1234,
                                      name="test", start_time=100, end_time=200)
    live = LiveSpan(mock_span, "tr-test-c4")
    live.set_status(SpanStatus(SpanStatusCode.OK))
    live.set_inputs({"key": "val"})
    immutable = live.to_immutable_span()
    d = immutable.to_dict()

    # Contract: trace_id is base64 of 16-byte big-endian int
    expected_trace_b64 = _encode_bytes_to_base64(
        _encode_trace_id_to_byte(0xABCDEF01)
    )
    assert d["trace_id"] == expected_trace_b64

    # Contract: span_id is base64 of 8-byte big-endian int
    expected_span_b64 = _encode_bytes_to_base64(
        _encode_span_id_to_byte(0x1234)
    )
    assert d["span_id"] == expected_span_b64

    # Contract: parent_span_id is None for root spans
    assert d["parent_span_id"] is None

    assert d["name"] == "test"
    assert d["start_time_unix_nano"] == 100
    assert d["end_time_unix_nano"] == 200
    assert isinstance(d["status"], dict)
    assert "code" in d["status"]
    assert isinstance(d["attributes"], dict)


# ---------------------------------------------------------------------------
# C7: Span.from_otel_proto creates Span from protobuf
# Graph: N1, E9, N16, N23
# ---------------------------------------------------------------------------

# Contracts: C7
def check_span_from_otel_proto_connectivity() -> None:
    """Span.from_otel_proto converts an OTel proto span to MLflow Span."""
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue, KeyValue
    from mlflow.entities import Span, LiveSpan

    proto = OTelProtoSpan()
    proto.trace_id = b'\x00' * 15 + b'\x01'  # trace_id=1
    proto.span_id = b'\x00' * 7 + b'\x02'     # span_id=2
    proto.name = "proto_span"
    proto.start_time_unix_nano = 1000
    proto.end_time_unix_nano = 2000
    proto.status.code = OTelProtoStatus.STATUS_CODE_OK
    proto.status.message = "all good"

    # Add an attribute
    attr = proto.attributes.add()
    attr.key = "custom.key"
    sv = AnyValue()
    sv.string_value = "hello"
    attr.value.CopyFrom(sv)

    result = Span.from_otel_proto(proto)

    assert isinstance(result, Span)
    assert not isinstance(result, LiveSpan)
    assert result.name == "proto_span"
    assert result.start_time_ns == 1000
    assert result.end_time_ns == 2000

    # The trace_id property should be set (as REQUEST_ID attribute)
    assert result.trace_id is not None
    assert result.trace_id.startswith("tr-")


# ---------------------------------------------------------------------------
# C8: Span.to_otel_proto converts to protobuf
# Graph: N1, E10, N17
# ---------------------------------------------------------------------------

# Contracts: C8
def check_span_to_otel_proto_connectivity() -> None:
    """Span.to_otel_proto() returns an OTelProtoSpan with correct fields."""
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    from mlflow.entities import LiveSpan, SpanStatus, SpanStatusCode

    mock_span = _make_mock_otel_span(trace_id=0xABCD, span_id=0x5678,
                                      name="export_span", start_time=1000, end_time=2000)
    live = LiveSpan(mock_span, "tr-test-c8")
    live.set_status(SpanStatus(SpanStatusCode.OK))
    live.set_inputs({"in": "val"})
    immutable = live.to_immutable_span()

    proto = immutable.to_otel_proto()

    assert isinstance(proto, OTelProtoSpan)
    assert proto.name == "export_span"
    assert proto.start_time_unix_nano == 1000
    assert proto.end_time_unix_nano == 2000

    # trace_id/span_id should be bytes
    assert len(proto.trace_id) > 0
    assert len(proto.span_id) > 0


# ---------------------------------------------------------------------------
# C9: _decode_otel_proto_anyvalue decodes all types
# Graph: N16
# ---------------------------------------------------------------------------

# Contracts: C9
def check_decode_otel_proto_anyvalue_all_types() -> None:
    """_decode_otel_proto_anyvalue correctly decodes all AnyValue types."""
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue, KeyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    # string_value
    av = AnyValue(); av.string_value = "hello"
    assert _decode_otel_proto_anyvalue(av) == "hello"

    # int_value
    av = AnyValue(); av.int_value = 42
    assert _decode_otel_proto_anyvalue(av) == 42

    # double_value
    av = AnyValue(); av.double_value = 3.14
    assert _decode_otel_proto_anyvalue(av) == 3.14

    # bool_value
    av = AnyValue(); av.bool_value = True
    assert _decode_otel_proto_anyvalue(av) is True

    # bytes_value
    av = AnyValue(); av.bytes_value = b"data"
    assert _decode_otel_proto_anyvalue(av) == b"data"

    # unset -> None
    av = AnyValue()
    assert _decode_otel_proto_anyvalue(av) is None

    # array_value
    av = AnyValue()
    inner = av.array_value.values.add()
    inner.string_value = "a"
    inner2 = av.array_value.values.add()
    inner2.int_value = 1
    assert _decode_otel_proto_anyvalue(av) == ["a", 1]

    # kvlist_value
    av = AnyValue()
    kv = av.kvlist_value.values.add()
    kv.key = "k1"
    kv.value.string_value = "v1"
    kv2 = av.kvlist_value.values.add()
    kv2.key = "k2"
    kv2.value.int_value = 99
    assert _decode_otel_proto_anyvalue(av) == {"k1": "v1", "k2": 99}


# ---------------------------------------------------------------------------
# C14: create_mlflow_span returns correct type
# Graph: N4, E5
# ---------------------------------------------------------------------------

# Contracts: C14
def check_create_mlflow_span_type_dispatch() -> None:
    """create_mlflow_span returns LiveSpan/Span/NoOpSpan based on input type."""
    from opentelemetry.trace import NonRecordingSpan
    from mlflow.entities import LiveSpan, Span, NoOpSpan
    from mlflow.entities.span import create_mlflow_span

    # Live OTEL span -> LiveSpan
    mock_live = _make_mock_otel_span(trace_id=1, span_id=2)
    result = create_mlflow_span(mock_live, "tr-test-live")
    assert isinstance(result, LiveSpan)

    # Readable span with end_time -> Span
    mock_readable = _make_mock_otel_span(trace_id=3, span_id=4, end_time=100)
    result = create_mlflow_span(mock_readable, "tr-test-readable")
    assert isinstance(result, Span)
    assert not isinstance(result, LiveSpan)

    # NonRecordingSpan -> NoOpSpan
    nr = NonRecordingSpan(context=None)
    result = create_mlflow_span(nr, "tr-test-nr")
    assert isinstance(result, NoOpSpan)

    # None -> NoOpSpan
    result = create_mlflow_span(None, "tr-test-none")
    assert isinstance(result, NoOpSpan)


# ---------------------------------------------------------------------------
# C15: Span.attributes returns all deserialized attributes
# Graph: N1, E17, N6
# ---------------------------------------------------------------------------

# Contracts: C15
def check_span_attributes_dataflow() -> None:
    """Span.attributes returns deserialized dict from _CachedSpanAttributesRegistry."""
    from mlflow.entities import LiveSpan, Span

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    live = LiveSpan(mock_span, "tr-test-c15")
    live.set_attribute("key1", "val1")
    live.set_attribute("key2", {"nested": True})

    immutable = live.to_immutable_span()
    attrs = immutable.attributes

    assert isinstance(attrs, dict)
    assert attrs.get("key1") == "val1"
    assert attrs.get("key2") == {"nested": True}
    # Should contain REQUEST_ID and SPAN_TYPE
    assert "mlflow.traceRequestId" in attrs
    assert "mlflow.spanType" in attrs


# ---------------------------------------------------------------------------
# C16: Span.events returns list of SpanEvent
# Graph: N1, E18, N12
# ---------------------------------------------------------------------------

# Contracts: C16
def check_span_events_dataflow() -> None:
    """Span.events returns list[SpanEvent] from OTel span events."""
    from mlflow.entities import LiveSpan, Span, SpanEvent

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    live = LiveSpan(mock_span, "tr-test-c16")
    event = SpanEvent(name="test_event", timestamp=123456, attributes={"k": "v"})
    live.add_event(event)

    immutable = live.to_immutable_span()
    events = immutable.events

    assert isinstance(events, list)
    assert len(events) == 1
    assert isinstance(events[0], SpanEvent)
    assert events[0].name == "test_event"
    assert events[0].timestamp == 123456


# ---------------------------------------------------------------------------
# C17: Span.request_id is alias for trace_id
# Graph: N1, E20
# ---------------------------------------------------------------------------

# Contracts: C17
def check_span_request_id_alias() -> None:
    """span.request_id returns same value as span.trace_id."""
    from mlflow.entities import LiveSpan

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    live = LiveSpan(mock_span, "tr-test-c17")
    immutable = live.to_immutable_span()

    assert immutable.request_id == immutable.trace_id
    assert immutable.request_id == "tr-test-c17"


# ---------------------------------------------------------------------------
# C18: Span.span_type reads from attributes
# Graph: N1, E16
# ---------------------------------------------------------------------------

# Contracts: C18
def check_span_type_reads_from_attributes() -> None:
    """Span.span_type returns value from SpanAttributeKey.SPAN_TYPE attribute."""
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    live = LiveSpan(mock_span, "tr-test-c18", span_type="LLM")
    assert live.span_type == "LLM"

    # Also verify through the attribute directly
    assert live.get_attribute(SpanAttributeKey.SPAN_TYPE) == "LLM"


# ---------------------------------------------------------------------------
# C20: ID encoding round-trip preserves value
# Graph: N18, N19, N20, N21
# ---------------------------------------------------------------------------

# Contracts: C20
def check_id_encoding_round_trip() -> None:
    """_encode_trace_id_to_byte -> _encode_bytes_to_base64 -> _decode_id_from_byte
    round-trip preserves the original integer value."""
    from mlflow.entities.span import (
        _encode_trace_id_to_byte,
        _encode_span_id_to_byte,
        _encode_bytes_to_base64,
        _decode_id_from_byte,
    )

    # Trace ID roundtrip (16 bytes)
    trace_id_int = 0xABCDEF0123456789ABCDEF0123456789
    trace_bytes = _encode_trace_id_to_byte(trace_id_int)
    assert len(trace_bytes) == 16
    trace_b64 = _encode_bytes_to_base64(trace_bytes)
    assert _decode_id_from_byte(trace_b64) == trace_id_int

    # Span ID roundtrip (8 bytes)
    span_id_int = 0x1234567890ABCDEF
    span_bytes = _encode_span_id_to_byte(span_id_int)
    assert len(span_bytes) == 8
    span_b64 = _encode_bytes_to_base64(span_bytes)
    assert _decode_id_from_byte(span_b64) == span_id_int


# ---------------------------------------------------------------------------
# C25: _otel_proto_bytes_to_id converts bytes to int
# Graph: N23, E9
# ---------------------------------------------------------------------------

# Contracts: C25
def check_otel_proto_bytes_to_id() -> None:
    """_otel_proto_bytes_to_id converts 8-byte big-endian to int."""
    from mlflow.tracing.utils.otlp import _otel_proto_bytes_to_id

    result = _otel_proto_bytes_to_id(b'\x00\x00\x00\x00\x00\x00\x00\x01')
    assert result == 1

    result = _otel_proto_bytes_to_id(b'\x00\x00\x00\x00\x00\x00\x00\xff')
    assert result == 255


# ---------------------------------------------------------------------------
# C27: _SpanAttributesRegistry.get_all returns all attributes
# Graph: N5, E17
# ---------------------------------------------------------------------------

# Contracts: C27
def check_span_attributes_registry_get_all() -> None:
    """_SpanAttributesRegistry.get_all returns dict of all deserialized attrs."""
    from mlflow.entities.span import _SpanAttributesRegistry

    mock_span = _make_mock_otel_span(trace_id=1, span_id=2)
    registry = _SpanAttributesRegistry(mock_span)
    registry.set("a", 1)
    registry.set("b", "hello")

    all_attrs = registry.get_all()
    assert isinstance(all_attrs, dict)
    assert all_attrs["a"] == 1
    assert all_attrs["b"] == "hello"


# ---------------------------------------------------------------------------
# C28: _is_base64_encoded detects base64 strings
# Graph: N22, E8
# ---------------------------------------------------------------------------

# Contracts: C28
def check_is_base64_encoded() -> None:
    """_is_base64_encoded returns True for base64, False for hex."""
    from mlflow.entities.span import _is_base64_encoded

    # Valid base64 string
    assert _is_base64_encoded("aGVsbG8=") is True

    # Empty base64
    assert _is_base64_encoded("") is True

    # Hex string (not valid base64, no padding)
    assert _is_base64_encoded("0d48a6670588966b") is False


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    failures = []
    for name, fn in sorted(globals().items()):
        if name.startswith("check_") and callable(fn):
            try:
                fn()
                print(f"PASS: {name}")
            except Exception as e:
                failures.append(name)
                print(f"FAIL: {name} -- {e}")
                import traceback; traceback.print_exc()
    if failures:
        print(f"\n{failures} tests FAILED: {failures}")
        raise SystemExit(1)
    else:
        print(f"\nAll tests PASSED")
