"""
Behavior spec: proves what each requirement visibly does.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries, and
compatibility contracts from the semantic IR. Each check_* function asserts
observable semantics: return values, exceptions, state changes, side effects.
"""

import functools
import importlib
import logging
import sys
from unittest import mock

import pandas as pd
import pytest

import mlflow
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer as scorer_decorator
from mlflow.genai.scorers.builtin_scorers import (
    BuiltInScorer,
    Correctness,
    MissingColumnsException,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _import_validation_functions():
    """Import validate_scorers, valid_data_for_builtin_scorers from validation module."""
    mod = importlib.import_module("mlflow.genai.scorers.validation")
    return mod.validate_scorers, mod.valid_data_for_builtin_scorers


def _get_all_scorers():
    """Get get_all_scorers via module attribute access (triggers __getattr__)."""
    import mlflow.genai.scorers as scorers_mod
    return scorers_mod.get_all_scorers


# ---------------------------------------------------------------------------
# C3: CustomScorer delegates to original function (Behavior, R1)
# Reference: tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics
# Perspective: verify __call__ returns same value as original decorated function
# ---------------------------------------------------------------------------

# Contracts: C3
def check_custom_scorer_delegates_to_original() -> None:
    """CustomScorer.__call__ returns the same value as the original function."""
    def my_func(inputs, outputs):
        return f"result:{inputs}:{outputs}"

    scorer_obj = scorer_decorator(my_func)
    result = scorer_obj(inputs="hello", outputs="world")
    assert result == "result:hello:world", (
        f"Scorer must delegate to original, got {result!r}"
    )


# ---------------------------------------------------------------------------
# C4: CustomScorer stores original func (State, R9)
# Reference: none found (internal state check)
# Perspective: _original_func must reference the original decorated function
# ---------------------------------------------------------------------------

# Contracts: C4
def check_custom_scorer_stores_original_func() -> None:
    """CustomScorer._original_func is the original decorated function."""
    def my_func(inputs):
        return inputs

    scorer_obj = scorer_decorator(my_func)
    assert scorer_obj._original_func is my_func, (
        "_original_func must be the decorated function reference"
    )


# ---------------------------------------------------------------------------
# C6: get_all_scorers returns correct count in OSS (Behavior, R4)
# Reference: tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss
# Perspective: count verification for non-Databricks context
# ---------------------------------------------------------------------------

# Contracts: C6
def check_get_all_scorers_count_oss() -> None:
    """get_all_scorers() returns 6 scorers when tracking URI is not Databricks."""
    get_all_scorers = _get_all_scorers()
    mlflow.set_tracking_uri("file:///tmp/test")
    scorers = get_all_scorers()
    assert len(scorers) == 6, (
        f"OSS get_all_scorers must return 6 scorers, got {len(scorers)}"
    )
    expected_names = {
        "expectations_guidelines",
        "correctness",
        "relevance_to_query",
        "retrieval_sufficiency",
        "retrieval_groundedness",
        "equivalence",
    }
    actual_names = {s.name for s in scorers}
    assert actual_names == expected_names, (
        f"Expected scorer names {expected_names}, got {actual_names}"
    )


# ---------------------------------------------------------------------------
# C7: get_all_scorers returns correct count in Databricks (Behavior, R4)
# Reference: tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss
# Perspective: count verification for Databricks context
# ---------------------------------------------------------------------------

# Contracts: C7
def check_get_all_scorers_count_databricks() -> None:
    """get_all_scorers() returns 8 scorers with Databricks tracking URI."""
    get_all_scorers = _get_all_scorers()
    mlflow.set_tracking_uri("databricks")
    scorers = get_all_scorers()
    assert len(scorers) == 8, (
        f"Databricks get_all_scorers must return 8 scorers, got {len(scorers)}"
    )
    expected_names = {
        "expectations_guidelines",
        "correctness",
        "relevance_to_query",
        "retrieval_sufficiency",
        "retrieval_groundedness",
        "equivalence",
        "safety",
        "retrieval_relevance",
    }
    actual_names = {s.name for s in scorers}
    assert actual_names == expected_names, (
        f"Expected scorer names {expected_names}, got {actual_names}"
    )


# ---------------------------------------------------------------------------
# C9: validate_scorers returns valid Scorer list (Behavior, R5)
# Reference: none found
# Perspective: same scorer instance passes through
# ---------------------------------------------------------------------------

# Contracts: C9
def check_validate_scorers_returns_valid_list() -> None:
    """validate_scorers returns list with same scorer instance."""
    validate_scorers, _ = _import_validation_functions()
    scorer = Correctness(name="test_c9")
    result = validate_scorers([scorer])
    assert result == [scorer], (
        "validate_scorers must return the same scorer instance"
    )
    assert len(result) == 1
    assert result[0] is scorer


# ---------------------------------------------------------------------------
# C10: validate_scorers empty list returns empty list (Behavior, R5)
# Reference: none found
# Perspective: empty input -> empty output
# ---------------------------------------------------------------------------

# Contracts: C10
def check_validate_scorers_empty_list() -> None:
    """validate_scorers([]) returns []."""
    validate_scorers, _ = _import_validation_functions()
    result = validate_scorers([])
    assert result == [], f"validate_scorers([]) must return [], got {result}"


# ---------------------------------------------------------------------------
# C11: validate_scorers raises on non-list input (Failure, R5)
# Reference: none found
# Perspective: type check rejects non-list with descriptive message
# ---------------------------------------------------------------------------

# Contracts: C11
def check_validate_scorers_raises_on_non_list() -> None:
    """validate_scorers('not_a_list') raises MlflowException."""
    validate_scorers, _ = _import_validation_functions()
    with pytest.raises(MlflowException, match="must be a list of scorers"):
        validate_scorers("not_a_list")


# ---------------------------------------------------------------------------
# C12: validate_scorers raises with hint for nested get_all_scorers (Failure, R5, R7)
# Reference: none found
# Perspective: nested list mistake produces targeted hint
# ---------------------------------------------------------------------------

# Contracts: C12
def check_validate_scorers_raises_on_nested_get_all_scorers() -> None:
    """validate_scorers([get_all_scorers()]) raises with hint."""
    validate_scorers, _ = _import_validation_functions()
    get_all_scorers = _get_all_scorers()

    with pytest.raises(MlflowException, match="Use `scorers=get_all_scorers"):
        validate_scorers([get_all_scorers()])


# ---------------------------------------------------------------------------
# C13: validate_scorers raises with hint for class-not-instance (Failure, R5)
# Reference: none found
# Perspective: passing class instead of instance gives helpful hint
# ---------------------------------------------------------------------------

# Contracts: C13
def check_validate_scorers_raises_on_class_not_instance() -> None:
    """validate_scorers([Correctness]) (class, not instance) raises with hint."""
    validate_scorers, _ = _import_validation_functions()

    with pytest.raises(MlflowException, match="you passed a scorer class instead of an instance"):
        validate_scorers([Correctness])


# ---------------------------------------------------------------------------
# C18: valid_data_for_builtin_scorers raises on non-dict expectations (Failure, R6)
# Reference: none found
# Perspective: non-dict values in expectations column trigger MlflowException
# ---------------------------------------------------------------------------

# Contracts: C18
def check_valid_data_raises_on_non_dict_expectations() -> None:
    """valid_data_for_builtin_scorers raises when expectations contains non-dict."""
    _, valid_data_for_builtin_scorers = _import_validation_functions()

    df = pd.DataFrame({
        "inputs": ["q1"],
        "outputs": ["a1"],
        "expectations": ["not_a_dictionary"],
    })

    with pytest.raises(MlflowException, match="must be a dictionary"):
        valid_data_for_builtin_scorers(df, [Correctness(name="test_c18")])


# ---------------------------------------------------------------------------
# C19: valid_data_for_builtin_scorers logs missing columns without raising
#       (SideEffect, R6, R8)
# Reference: none found
# Perspective: missing columns log info but do not raise
# ---------------------------------------------------------------------------

# Contracts: C19
def check_valid_data_logs_missing_columns_without_raising() -> None:
    """valid_data_for_builtin_scorers logs info for missing columns; no exception."""
    _, valid_data_for_builtin_scorers = _import_validation_functions()

    df = pd.DataFrame({"inputs": ["q1"]})  # missing 'outputs'
    scorer = Correctness(name="test_c19")

    with mock.patch("mlflow.genai.scorers.validation._logger.info") as mock_log:
        # Must not raise
        valid_data_for_builtin_scorers(df, [scorer])

    # Logger.info must have been called at least once
    mock_log.assert_called()
    log_msg = mock_log.call_args.args[0] if mock_log.call_args.args else ""
    assert "missing following columns" in log_msg.lower() or "missing" in log_msg.lower(), (
        f"Log message must mention missing columns, got: {log_msg[:200]}"
    )


# ---------------------------------------------------------------------------
# C3b: scorer default name is function name (boundary / decorator-default)
# Reference: tests/genai/scorers/test_scorer.py::test_scorer_name_works
# Perspective: default name derives from __name__ of decorated function
# ---------------------------------------------------------------------------

def check_scorer_default_name_is_function_name() -> None:
    """scorer(func) uses func.__name__ as default name."""
    def my_unique_scorer_name(inputs):
        return True

    scorer_obj = scorer_decorator(my_unique_scorer_name)
    assert scorer_obj.name == "my_unique_scorer_name", (
        f"Default name must be func.__name__, got {scorer_obj.name!r}"
    )


# ---------------------------------------------------------------------------
# C2b: scorer parameterized usage produces Scorer with correct name
# Reference: tests/genai/scorers/test_scorer.py::test_scorer_name_works
# Perspective: @scorer(name='x') applies name correctly
# ---------------------------------------------------------------------------

def check_scorer_parameterized_name_applies() -> None:
    """scorer(name='custom')(func) produces Scorer with name='custom'."""
    def my_func(inputs):
        return True

    scorer_obj = scorer_decorator(name="overridden_name")(my_func)
    assert scorer_obj.name == "overridden_name", (
        f"Parameterized name must override func name, got {scorer_obj.name!r}"
    )


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    checks = [
        check_custom_scorer_delegates_to_original,
        check_custom_scorer_stores_original_func,
        check_get_all_scorers_count_oss,
        check_get_all_scorers_count_databricks,
        check_validate_scorers_returns_valid_list,
        check_validate_scorers_empty_list,
        check_validate_scorers_raises_on_non_list,
        check_validate_scorers_raises_on_nested_get_all_scorers,
        check_validate_scorers_raises_on_class_not_instance,
        check_valid_data_raises_on_non_dict_expectations,
        check_valid_data_logs_missing_columns_without_raising,
        check_scorer_default_name_is_function_name,
        check_scorer_parameterized_name_applies,
    ]
    failed = 0
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as e:
            failed += 1
            print(f"FAIL: {check.__name__} -> {e}")
    if failed:
        print(f"\n{failed} check(s) FAILED")
        sys.exit(1)
    print(f"\nAll {len(checks)} checks PASSED")
