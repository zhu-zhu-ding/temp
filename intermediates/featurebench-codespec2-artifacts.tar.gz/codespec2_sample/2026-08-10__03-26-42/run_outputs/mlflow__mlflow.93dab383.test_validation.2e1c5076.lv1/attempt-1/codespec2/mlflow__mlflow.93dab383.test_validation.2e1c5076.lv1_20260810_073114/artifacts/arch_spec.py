"""
Architecture spec: proves how each requirement travels through the repository code.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts from the semantic IR.
Each check_* function proves connectivity from a public entry point to the IR-stated
observer using live imports and mock-free or minimally-mocked paths.
"""

import functools
import importlib
import inspect
import logging
import sys
from typing import Any, Callable
from unittest import mock

import pandas as pd
import pytest

import mlflow
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer as scorer_decorator
from mlflow.genai.scorers.builtin_scorers import (
    BuiltInScorer,
    Correctness,
    MissingColumnsException,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _import_validation_functions():
    """Import validate_scorers, valid_data_for_builtin_scorers from validation module."""
    mod = importlib.import_module("mlflow.genai.scorers.validation")
    return mod.validate_scorers, mod.valid_data_for_builtin_scorers


def _get_all_scorers():
    """Get get_all_scorers via module attribute access (triggers __getattr__)."""
    import mlflow.genai.scorers as scorers_mod
    return scorers_mod.get_all_scorers


def _make_trace_df() -> pd.DataFrame:
    """DataFrame with a 'trace' column placeholder."""
    return pd.DataFrame({"trace": ["trace_obj_1", "trace_obj_2"]})


def _make_request_response_df() -> pd.DataFrame:
    """DataFrame with legacy 'request'/'response' columns."""
    return pd.DataFrame(
        {
            "request": ["req1", "req2"],
            "response": ["resp1", "resp2"],
        }
    )


def _make_expectations_df() -> pd.DataFrame:
    """DataFrame with 'expectations' column containing dicts."""
    return pd.DataFrame(
        {
            "inputs": ["q1", "q2"],
            "outputs": ["a1", "a2"],
            "expectations": [
                {"expected_response": "e1", "guidelines": ["be polite"]},
                {"expected_response": "e2"},
            ],
        }
    )


# ---------------------------------------------------------------------------
# C1: scorer decorator produces valid CustomScorer (Interface, R1, R10)
# ---------------------------------------------------------------------------

# Contracts: C1
def check_scorer_decorator_produces_custom_scorer() -> None:
    """scorer(func) returns a Scorer instance with kind==DECORATOR."""
    def my_func(inputs, outputs):
        return True

    result = scorer_decorator(my_func)
    assert isinstance(result, Scorer), (
        f"scorer(func) must return a Scorer instance, got {type(result).__name__}"
    )
    assert result.kind == ScorerKind.DECORATOR, (
        f"CustomScorer.kind must be DECORATOR, got {result.kind}"
    )


# ---------------------------------------------------------------------------
# C2: scorer with no func returns functools.partial (Interface, R2)
# ---------------------------------------------------------------------------

# Contracts: C2
def check_scorer_no_func_returns_partial() -> None:
    """scorer(name='x') returns a functools.partial."""
    result = scorer_decorator(name="custom_name")
    assert isinstance(result, functools.partial), (
        f"scorer(name='x') must return functools.partial, got {type(result).__name__}"
    )
    # The partial, when applied, must produce a Scorer
    def dummy(inputs, outputs):
        return True
    applied = result(dummy)
    assert isinstance(applied, Scorer), (
        f"partial(func) must return Scorer, got {type(applied).__name__}"
    )
    assert applied.name == "custom_name"


# ---------------------------------------------------------------------------
# C5: CustomScorer.__call__ signature matches original with self (Interface, R3)
# ---------------------------------------------------------------------------

# Contracts: C5
def check_custom_scorer_call_signature_matches_original() -> None:
    """inspect.signature(CustomScorer.__call__) adds 'self' to original params."""
    def my_func(inputs, outputs, trace):
        return True

    scorer_obj = scorer_decorator(my_func)
    call_sig = inspect.signature(scorer_obj.__call__)
    param_names = list(call_sig.parameters.keys())
    assert param_names[0] == "self", (
        f"First param must be 'self', got {param_names[0]}"
    )
    assert param_names[1:] == ["inputs", "outputs", "trace"], (
        f"Params after self must match original, got {param_names[1:]}"
    )


# ---------------------------------------------------------------------------
# C8: get_all_scorers items are all Scorer instances (Interface, R4)
# ---------------------------------------------------------------------------

# Contracts: C8
def check_get_all_scorers_items_are_scorers() -> None:
    """Every item in get_all_scorers() is isinstance(Scorer)."""
    get_all_scorers = _get_all_scorers()
    scorers = get_all_scorers()
    assert len(scorers) > 0, "get_all_scorers() must return at least one scorer"
    for s in scorers:
        assert isinstance(s, Scorer), (
            f"Each scorer must be Scorer, got {type(s).__name__}"
        )
        assert isinstance(s, BuiltInScorer), (
            f"Each scorer must be BuiltInScorer, got {type(s).__name__}"
        )


# ---------------------------------------------------------------------------
# C9: validate_scorers returns valid Scorer list (Behavior, R5)
# -- arch perspective: import path, caller resolution
# ---------------------------------------------------------------------------

# Contracts: C9
def check_validate_scorers_importable_and_callable() -> None:
    """validate_scorers is importable and returns valid list for valid input."""
    validate_scorers, _ = _import_validation_functions()
    scorer_instance = Correctness(name="test_correctness")
    result = validate_scorers([scorer_instance])
    assert isinstance(result, list), (
        f"validate_scorers must return list, got {type(result).__name__}"
    )
    assert scorer_instance in result


# ---------------------------------------------------------------------------
# C14: valid_data_for_builtin_scorers normalizes request/response (Dataflow, R6)
# ---------------------------------------------------------------------------

# Contracts: C14
def check_valid_data_normalizes_request_response_columns() -> None:
    """request->inputs and response->outputs mapping passes to validate_columns."""
    _, valid_data_for_builtin_scorers = _import_validation_functions()
    df = _make_request_response_df()
    scorer = Correctness(name="test_corr")

    with mock.patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as spy:
        valid_data_for_builtin_scorers(df, [scorer])

    spy.assert_called_once()
    columns_seen = spy.call_args.args[0]
    assert "inputs" in columns_seen, "request->inputs mapping not applied"
    assert "outputs" in columns_seen, "response->outputs mapping not applied"
    assert "request" not in columns_seen, "request should be removed"
    assert "response" not in columns_seen, "response should be removed"


# ---------------------------------------------------------------------------
# C15: valid_data_for_builtin_scorers adds outputs when predict_fn (Dataflow, R6)
# ---------------------------------------------------------------------------

# Contracts: C15
def check_valid_data_adds_outputs_with_predict_fn() -> None:
    """predict_fn implies 'outputs' column even if absent."""
    _, valid_data_for_builtin_scorers = _import_validation_functions()
    df = pd.DataFrame({"inputs": ["q1", "q2"]})
    scorer = Correctness(name="test_corr")

    def dummy_predict(x):
        return "predicted"

    with mock.patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as spy:
        valid_data_for_builtin_scorers(df, [scorer], predict_fn=dummy_predict)

    columns_seen = spy.call_args.args[0]
    assert "outputs" in columns_seen, (
        "outputs must be in columns when predict_fn is provided"
    )


# ---------------------------------------------------------------------------
# C16: valid_data_for_builtin_scorers adds inputs/outputs with trace (Dataflow, R6)
# ---------------------------------------------------------------------------

# Contracts: C16
def check_valid_data_adds_inputs_outputs_with_trace() -> None:
    """trace column implies 'inputs' and 'outputs' columns."""
    _, valid_data_for_builtin_scorers = _import_validation_functions()
    df = _make_trace_df()
    scorer = Correctness(name="test_corr")

    with mock.patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as spy:
        valid_data_for_builtin_scorers(df, [scorer])

    columns_seen = spy.call_args.args[0]
    assert "inputs" in columns_seen, "inputs missing when trace column present"
    assert "outputs" in columns_seen, "outputs missing when trace column present"


# ---------------------------------------------------------------------------
# C17: valid_data_for_builtin_scorers explodes expectations dict (Dataflow, R6)
# ---------------------------------------------------------------------------

# Contracts: C17
def check_valid_data_explodes_expectations_dict_keys() -> None:
    """expectations dict keys become 'expectations/<key>' columns."""
    _, valid_data_for_builtin_scorers = _import_validation_functions()
    df = _make_expectations_df()
    scorer = Correctness(name="test_corr")

    with mock.patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as spy:
        valid_data_for_builtin_scorers(df, [scorer])

    columns_seen = spy.call_args.args[0]
    assert "expectations/expected_response" in columns_seen, (
        "expectations/expected_response should be exploded"
    )
    assert "expectations/guidelines" in columns_seen, (
        "expectations/guidelines should be exploded"
    )


# ---------------------------------------------------------------------------
# C20: valid_data_for_builtin_scorers catches MissingColumnsException (Dataflow, R6, R8)
# ---------------------------------------------------------------------------

# Contracts: C20
def check_valid_data_catches_missing_columns_exception() -> None:
    """Each scorer's validate_columns is called and MissingColumnsException is caught."""
    _, valid_data_for_builtin_scorers = _import_validation_functions()
    df = pd.DataFrame({"inputs": ["q1"]})  # missing outputs
    scorer = Correctness(name="test_corr")

    with mock.patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as spy:
        # Should not raise - catches MissingColumnsException
        valid_data_for_builtin_scorers(df, [scorer])

    spy.assert_called_once()
    # verify the exception was raised by validate_columns and caught by
    # valid_data_for_builtin_scorers -- this is proven by the fact that no
    # exception propagated


# ---------------------------------------------------------------------------
# C21: evaluate/base.py imports validation functions (Interface, R5, R6)
# ---------------------------------------------------------------------------

# Contracts: C21
def check_evaluate_imports_validation_functions() -> None:
    """evaluation/base.py imports valid_data_for_builtin_scorers and validate_scorers."""
    import mlflow.genai.evaluation.base as eval_base

    source = inspect.getsource(eval_base)
    # The import statement must reference both functions from validation
    assert "valid_data_for_builtin_scorers" in source, (
        "evaluation/base.py source must reference valid_data_for_builtin_scorers"
    )
    assert "validate_scorers" in source, (
        "evaluation/base.py source must reference validate_scorers"
    )


# ---------------------------------------------------------------------------
# C22: CustomScorer.__init__ calls Scorer.__init__ (Behavior, R1)
# ---------------------------------------------------------------------------

# Contracts: C22
def check_custom_scorer_init_calls_scorer_init() -> None:
    """CustomScorer.__init__ delegates to Scorer.__init__ with keyword args."""
    def my_func(inputs):
        return True

    with mock.patch.object(Scorer, "__init__", wraps=Scorer.__init__) as spy:
        scorer_obj = scorer_decorator(my_func)

    spy.assert_called_once()
    # Check that name was forwarded
    assert spy.call_args.kwargs.get("name") == "my_func", (
        f"Scorer.__init__ must receive name='my_func', got {spy.call_args.kwargs}"
    )


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    checks = [
        check_scorer_decorator_produces_custom_scorer,
        check_scorer_no_func_returns_partial,
        check_custom_scorer_call_signature_matches_original,
        check_get_all_scorers_items_are_scorers,
        check_validate_scorers_importable_and_callable,
        check_valid_data_normalizes_request_response_columns,
        check_valid_data_adds_outputs_with_predict_fn,
        check_valid_data_adds_inputs_outputs_with_trace,
        check_valid_data_explodes_expectations_dict_keys,
        check_valid_data_catches_missing_columns_exception,
        check_evaluate_imports_validation_functions,
        check_custom_scorer_init_calls_scorer_init,
    ]
    failed = 0
    for check in checks:
        try:
            check()
            print(f"PASS: {check.__name__}")
        except Exception as e:
            failed += 1
            print(f"FAIL: {check.__name__} -> {e}")
    if failed:
        print(f"\n{failed} check(s) FAILED")
        sys.exit(1)
    print(f"\nAll {len(checks)} checks PASSED")
