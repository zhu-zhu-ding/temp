# Semantic IR

## L1. Requirement Obligations

### R1: scorer decorator returns a callable Scorer instance
- Type: Interface
- Statement: The `scorer` function, when used as a decorator with a callable `func`, must return a `CustomScorer` instance (a subclass of `Scorer`) that wraps the decorated function, delegates `__call__` to the original function, and reports its `kind` as `ScorerKind.DECORATOR`.
- Task Evidence: "A decorator to define a custom scorer that can be used in `mlflow.genai.evaluate()`", "The scorer function should return one of the following: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects"
- Acceptance: `scorer(my_func)` returns an instance that `isinstance(Scorer)` and calling it invokes `my_func` with the same arguments.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:847` (scorer function signature and docstring exist); `/testbed/libs/tracing/mlflow/genai/scorers/base.py:999-1016` (CustomScorer class reference implementation); `/testbed/tests/genai/scorers/test_scorer.py:29-70` (tests exercise decorator and class-based scorers).
- Uncertainty: None.

### R2: scorer supports parameterized usage without func
- Type: Interface
- Statement: When `scorer` is called with keyword arguments but no `func` (i.e., `func is None`), it must return a `functools.partial` that binds the given keyword arguments, enabling usage as `@scorer(name="...", description="...")`.
- Task Evidence: "Args: func: The scorer function to be decorated. name: The name of the scorer. description: A description of what the scorer evaluates. aggregations: A list of aggregation functions..."
- Acceptance: `scorer(name="custom_name")` returns a partial that can be applied to a function, producing a `CustomScorer` with `name="custom_name"`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:995-997` (`if func is None: return functools.partial(...)`); `/testbed/tests/genai/scorers/test_scorer.py:71-74` (test uses `scorer(name="always_no")(always_yes)`).
- Uncertainty: None.

### R3: scorer preserves original function signature on CustomScorer.__call__
- Type: Interface
- Statement: The returned `CustomScorer.__call__` method must have a signature that includes `self` plus all parameters of the original decorated function, so MLflow's evaluation framework can introspect and pass the correct arguments (inputs, outputs, expectations, trace).
- Task Evidence: "The scorer function should take in a subset of the following parameters: inputs, outputs, expectations, trace"
- Acceptance: `inspect.signature(CustomScorer.__call__)` matches the original function's parameters with `self` prepended.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:1022-1025` (signature replacement code exists); `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1022-1025` (matching reference).
- Uncertainty: None.

### R4: get_all_scorers returns all built-in scorers as instances
- Type: Behavior
- Statement: `get_all_scorers()` must return a list of instantiated `BuiltInScorer` objects including `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, and `Equivalence`. When the tracking URI is Databricks, it must also include `Safety` and `RetrievalRelevance`.
- Task Evidence: "Returns: list[BuiltInScorer]: A list containing instances of all available built-in scorers. The list includes: ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence, Safety, RetrievalRelevance"
- Acceptance: In non-Databricks context, `len(get_all_scorers()) == 6`; in Databricks context, `len(get_all_scorers()) == 8`. All items are instances of `BuiltInScorer`.
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/builtin_scorers.py:1568-1599` (reference implementation); `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-577` (test verifies 6 or 8 scorers); `/testbed/mlflow/genai/scorers/__init__.py:36,77,93` (exports `get_all_scorers` via lazy import and `__all__`).
- Uncertainty: None.

### R5: validate_scorers validates a list of scorers and returns valid Scorer list
- Type: Behavior
- Statement: `validate_scorers(scorers)` must accept a list of potential scorer items, validate each is a `Scorer` instance (or legacy `databricks.rag_eval.evaluation.metrics.Metric`), raise `MlflowException` with helpful hints for common mistakes (passing a list-of-list from `get_all_scorers()`, passing class instead of instance), and return a flat list of valid `Scorer` instances.
- Task Evidence: "Validate a list of specified scorers and ensure they are valid Scorer instances... The function also provides helpful error messages for common mistakes"
- Acceptance: `validate_scorers([Correctness()])` returns `[Correctness()]`; `validate_scorers([])` returns `[]`; invalid input raises `MlflowException` with descriptive hints.
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:26-95` (reference implementation); `/testbed/mlflow/genai/evaluation/base.py:243` (caller in evaluate function).
- Uncertainty: None.

### R6: valid_data_for_builtin_scorers validates DataFrame columns for scorers
- Type: Behavior
- Statement: `valid_data_for_builtin_scorers(data, builtin_scorers, predict_fn)` must inspect the columns of a pandas DataFrame, perform column name normalization (`request`→`inputs`, `response`→`outputs`), account for `predict_fn` (which makes `outputs` optional) and `trace` column (which implies `inputs` and `outputs`), explode `expectations` dictionary keys into `expectations/<key>` columns, call each scorer's `validate_columns` method, and log an informative message for missing columns without raising an exception.
- Task Evidence: "Validate that the required columns are present in the data for running the builtin scorers... performs column name transformations... When required columns are missing, the function logs an informative message but doesn't raise an exception"
- Acceptance: Calling with valid data produces no exception; calling with missing columns logs info message listing which columns are missing and which scorers need them; non-dict expectations values raise `MlflowException`.
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:101-174` (reference implementation); `/testbed/mlflow/genai/evaluation/base.py:248` (caller in evaluate); `/testbed/mlflow/genai/optimize/util.py:91` (second caller).
- Uncertainty: None.

### R7: validate_scorers imports and uses get_all_scorers for error hints
- Type: Dataflow
- Statement: `validate_scorers` must import `get_all_scorers` from `builtin_scorers` and compare against it when a list-within-list is detected, to provide context-specific hints (e.g., "Use `scorers=get_all_scorers()`").
- Task Evidence: "The function provides context-aware error messages to help users correct common mistakes... Passing [get_all_scorers()] instead of get_all_scorers()"
- Acceptance: When `validate_scorers([get_all_scorers()])` is called, the raised `MlflowException` message includes a hint about using `scorers=get_all_scorers()`.
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:12,60-70` (imports get_all_scorers, compares against it in error path).
- Uncertainty: None.

### R8: valid_data_for_builtin_scorers does not raise on missing columns
- Type: Failure
- Statement: When required columns are missing for some scorers, `valid_data_for_builtin_scorers` must log the information via `_logger.info()` but must not raise an exception, allowing evaluation to continue with null results for affected scorers.
- Task Evidence: "When required columns are missing, the function logs an informative message but doesn't raise an exception, allowing the evaluation to continue with null results for affected scorers."
- Acceptance: Calling with data missing a required column does not raise; the log output contains the missing column information.
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:160-174` (logs info, does not raise).
- Uncertainty: None.

### R9: CustomScorer stores original function for serialization
- Type: State
- Statement: `CustomScorer` must store the original decorated function in a private attribute `_original_func` using `object.__setattr__` to bypass Pydantic's attribute handling during initialization.
- Task Evidence: Implicit in the scorer's need for serialization and reconstruction (the SerializedScorer dataclass has `call_source`, `call_signature`, `original_func_name` fields).
- Acceptance: After decoration, `custom_scorer._original_func` is the original function.
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1001-1008` (stores _original_func); `/testbed/mlflow/genai/scorers/base.py:62-108` (SerializedScorer supports decorator scorers).
- Uncertainty: None.

### R10: CustomScorer.kind returns ScorerKind.DECORATOR
- Type: Interface
- Statement: The `kind` property of `CustomScorer` must return `ScorerKind.DECORATOR`.
- Task Evidence: Implicit—the scorer decorator creates a decorator-type scorer distinct from class-based (`ScorerKind.CLASS`) and builtin (`ScorerKind.BUILTIN`) scorers.
- Acceptance: `scorer(my_func).kind == ScorerKind.DECORATOR`.
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1014-1016` (kind property); `/testbed/mlflow/genai/scorers/base.py:29-31` (ScorerKind enum).
- Uncertainty: None.

## L2. Functional Design Graph

### N1: scorer (decorator factory)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:847-1031`; exported via `/testbed/mlflow/genai/scorers/__init__.py:3`.

### N2: CustomScorer (inner class)
- Kind: Class
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:999-1016`; missing from `/testbed/mlflow/genai/scorers/base.py`.

### N3: Scorer (base class)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:111`.

### N4: functools.partial
- Kind: External
- Repository Evidence: Python standard library; used at `/testbed/mlflow/genai/scorers/base.py:996`.

### N5: get_all_scorers
- Kind: PublicEntry
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/builtin_scorers.py:1568-1599`; exported via `/testbed/mlflow/genai/scorers/__init__.py:36,77,93`.

### N6: validate_scorers
- Kind: PublicEntry
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:26-95`.

### N7: valid_data_for_builtin_scorers
- Kind: PublicEntry
- Repository Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:101-174`.

### N8: BuiltInScorer
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:259`.

### N9: BuiltInScorer.validate_columns
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py` (defined on BuiltInScorer base class).

### N10: MissingColumnsException
- Kind: Error
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:1600-1606`.

### N11: MlflowException
- Kind: Error
- Repository Evidence: `/testbed/mlflow/exceptions.py`.

### N12: evaluate (caller)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/evaluation/base.py:51` (function definition); imports at line 19-20.

### N13: optimize caller
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/optimize/util.py:91`.

### N14: IS_DBX_AGENTS_INSTALLED
- Kind: State
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:24`.

### N15: _logger
- Kind: Observer
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:22`.

### N16: is_databricks_uri
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/uri.py`.

### N17: ScorerKind.DECORATOR
- Kind: State
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:33`.

### E1: scorer -> functools.partial (func is None)
- Kind: CONTROL
- Condition: `func is None`
- Transfer: Binds `name`, `description`, `aggregations` into a partial of `scorer`.
- Evidence: `/testbed/mlflow/genai/scorers/base.py:995-997`.
- Obligations: R2

### E2: scorer -> CustomScorer (func provided)
- Kind: CONTROL
- Condition: `func is not None`
- Transfer: `func` is wrapped; signature is adapted; `CustomScorer` instance is constructed with `name` (or `func.__name__`), `description`, `aggregations`.
- Evidence: `/testbed/mlflow/genai/scorers/base.py:999-1031`; `/testbed/libs/tracing/mlflow/genai/scorers/base.py:999-1031`.
- Obligations: R1, R3, R9, R10

### E3: CustomScorer.__init__ -> Scorer.__init__
- Kind: CALL
- Condition: Always
- Transfer: `name`, `description`, `aggregations` passed to `Scorer` base `__init__`.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1005`.
- Obligations: R1

### E4: CustomScorer.__call__ -> original func
- Kind: CALL
- Condition: Always
- Transfer: Forwards `*args, **kwargs` to the original decorated function, returns its result.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1011-1012`.
- Obligations: R1

### E5: CustomScorer.kind -> ScorerKind.DECORATOR
- Kind: DATA
- Condition: Always
- Transfer: Returns the enum value `ScorerKind.DECORATOR`.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1014-1016`.
- Obligations: R10

### E6: CustomScorer._original_func stores func
- Kind: STATE
- Condition: Always
- Transfer: Original `func` reference stored via `object.__setattr__` to bypass Pydantic.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1008`.
- Obligations: R9

### E7: scorer -> CustomScorer.__call__.__signature__
- Kind: DATA
- Condition: `func is not None`
- Transfer: `inspect.signature(func)` with `self` prepended is set on `CustomScorer.__call__.__signature__`.
- Evidence: `/testbed/mlflow/genai/scorers/base.py:1022-1025`.
- Obligations: R3

### E8: get_all_scorers -> BuiltInScorer instances
- Kind: DATA
- Condition: Always
- Transfer: Returns list of 6 or 8 instantiated `BuiltInScorer` subclasses.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/builtin_scorers.py:1590-1599`.
- Obligations: R4

### E9: get_all_scorers -> is_databricks_uri
- Kind: CALL
- Condition: Always
- Transfer: Calls `is_databricks_uri(mlflow.get_tracking_uri())` to determine if `Safety` and `RetrievalRelevance` should be included.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/builtin_scorers.py:1598`.
- Obligations: R4

### E10: evaluate -> validate_scorers
- Kind: CALL
- Condition: Always (called at start of evaluate)
- Transfer: Passes `scorers` list argument; receives validated `list[Scorer]`.
- Evidence: `/testbed/mlflow/genai/evaluation/base.py:243`; `/testbed/libs/tracing/mlflow/genai/evaluation/base.py:21,243`.
- Obligations: R5

### E11: evaluate -> valid_data_for_builtin_scorers
- Kind: CALL
- Condition: Always (after validate_scorers, before scoring)
- Transfer: Passes DataFrame, filtered `builtin_scorers` list, and optional `predict_fn`.
- Evidence: `/testbed/mlflow/genai/evaluation/base.py:248`; `/testbed/libs/tracing/mlflow/genai/evaluation/base.py:21,248`.
- Obligations: R6, R8

### E12: validate_scorers -> get_all_scorers (error path)
- Kind: CALL
- Condition: When a list item is itself a list (nested list detection)
- Transfer: Calls `get_all_scorers()` to compare against the nested list for generating helpful error hints.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:62`.
- Obligations: R7

### E13: validate_scorers -> IS_DBX_AGENTS_INSTALLED (legacy check)
- Kind: CONTROL
- Condition: When a scorer is not `isinstance(Scorer)`
- Transfer: Checks if `databricks.agents` is installed; if so, checks for legacy `Metric` type.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:52-58`.
- Obligations: R5

### E14: validate_scorers -> MlflowException (invalid input)
- Kind: CONTROL
- Condition: When `scorers` is not a list, or contains invalid items
- Transfer: Raises `MlflowException.invalid_parameter_value` with context-specific hints.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:37-39,82-86`.
- Obligations: R5

### E15: valid_data_for_builtin_scorers -> BuiltInScorer.validate_columns
- Kind: CALL
- Condition: For each scorer in `builtin_scorers`
- Transfer: Passes the set of normalized column names; catches `MissingColumnsException`.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:152-158`.
- Obligations: R6, R8

### E16: valid_data_for_builtin_scorers -> _logger.info (missing columns)
- Kind: DATA
- Condition: When `missing_col_to_scorers` is non-empty
- Transfer: Logs an informative message listing missing columns and affected scorers.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:160-174`.
- Obligations: R6, R8

### E17: valid_data_for_builtin_scorers -> MlflowException (bad expectations)
- Kind: CONTROL
- Condition: When `expectations` column contains non-dict values
- Transfer: Raises `MlflowException.invalid_parameter_value`.
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:144-147`.
- Obligations: R6

### E18: optimize/util -> valid_data_for_builtin_scorers
- Kind: CALL
- Condition: During data validation for optimization
- Transfer: Passes training data DataFrame, builtin scorers, and predict function.
- Evidence: `/testbed/mlflow/genai/optimize/util.py:91`.
- Obligations: R6, R8

## L3. Verifiable Contracts

### C1: scorer decorator produces valid CustomScorer
- Type: Interface
- Subject: `scorer` return value when `func` is provided
- Relation: TYPE_IS
- Expected: Instance of `Scorer` (specifically `CustomScorer` subclass) with `kind == ScorerKind.DECORATOR`
- Evidence: Task docstring example "Basic scorers that returns primitive values @scorer", test `/testbed/tests/genai/scorers/test_scorer.py:62-74` exercises both class and decorator scorers.
- Observe: RETURN_VALUE
- Target: `scorer(func)` call
- Obligations: R1, R10
- Graph: N1, N2, N3, N17, E2, E5

### C2: scorer with no func returns partial
- Type: Interface
- Subject: `scorer(name="x")` call without func
- Relation: TYPE_IS
- Expected: A `functools.partial` object that, when called with a function, returns a `CustomScorer`
- Evidence: `/testbed/mlflow/genai/scorers/base.py:995-997`; test `/testbed/tests/genai/scorers/test_scorer.py:71-74`.
- Observe: RETURN_VALUE
- Target: `scorer(name="custom")` call
- Obligations: R2
- Graph: N1, N4, E1

### C3: CustomScorer delegates to original function
- Type: Behavior
- Subject: `CustomScorer.__call__`
- Relation: EQ
- Expected: `custom_scorer(inputs=x, outputs=y)` returns the same value as calling the original decorated function with those arguments
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1011-1012`; test `/testbed/tests/genai/scorers/test_scorer.py:29-30` (always_yes function returns "yes" and scorer wraps it).
- Observe: RETURN_VALUE
- Target: `CustomScorer.__call__`
- Obligations: R1
- Graph: N2, E4

### C4: CustomScorer stores original func
- Type: State
- Subject: `CustomScorer._original_func`
- Relation: EQ
- Expected: `custom_scorer._original_func is func` (the original decorated function reference)
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1008`.
- Observe: FIELD_READ
- Target: `custom_scorer._original_func`
- Obligations: R9
- Graph: N2, E6

### C5: CustomScorer.__call__ signature matches original with self
- Type: Interface
- Subject: `inspect.signature(CustomScorer.__call__)`
- Relation: EQ
- Expected: Signature includes `self` followed by all parameters of `func` (e.g., `(self, inputs, outputs, expectations, trace)`)
- Evidence: `/testbed/mlflow/genai/scorers/base.py:1022-1025`.
- Observe: RETURN_VALUE
- Target: `inspect.signature(scorer(func).__call__)`
- Obligations: R3
- Graph: N2, E7

### C6: get_all_scorers returns correct count in OSS
- Type: Behavior
- Subject: `get_all_scorers()` return value length when tracking URI is not Databricks
- Relation: EQ
- Expected: 6 scorers (ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence)
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/builtin_scorers.py:1590-1599`; test `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-577`.
- Observe: RETURN_VALUE
- Target: `len(get_all_scorers())`
- Obligations: R4
- Graph: N5, E8, E9, N16

### C7: get_all_scorers returns correct count in Databricks
- Type: Behavior
- Subject: `get_all_scorers()` return value length when tracking URI is Databricks
- Relation: EQ
- Expected: 8 scorers (adds Safety and RetrievalRelevance)
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/builtin_scorers.py:1598-1599`; test `/testbed/tests/genai/scorers/test_builtin_scorers.py:573-574`.
- Observe: RETURN_VALUE
- Target: `len(get_all_scorers())`
- Obligations: R4
- Graph: N5, E8, E9, N16

### C8: get_all_scorers items are all Scorer instances
- Type: Interface
- Subject: Each item in `get_all_scorers()` return
- Relation: TYPE_IS
- Expected: Each item is `isinstance(Scorer)` and `isinstance(BuiltInScorer)`
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/builtin_scorers.py:1590-1598`; test `/testbed/tests/genai/scorers/test_builtin_scorers.py:576`.
- Observe: RETURN_VALUE
- Target: `all(isinstance(s, Scorer) for s in get_all_scorers())`
- Obligations: R4
- Graph: N5, N8, N3, E8

### C9: validate_scorers returns valid Scorer list
- Type: Behavior
- Subject: `validate_scorers([Correctness()])`
- Relation: EQ
- Expected: Returns `[Correctness()]` — same scorer instance passed through
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:49`; called by `/testbed/mlflow/genai/evaluation/base.py:243`.
- Observe: RETURN_VALUE
- Target: `validate_scorers([Correctness()])`
- Obligations: R5
- Graph: N6, E10

### C10: validate_scorers empty list returns empty list
- Type: Behavior
- Subject: `validate_scorers([])`
- Relation: EQ
- Expected: Returns `[]`
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:41-42`.
- Observe: RETURN_VALUE
- Target: `validate_scorers([])`
- Obligations: R5
- Graph: N6

### C11: validate_scorers raises on non-list input
- Type: Failure
- Subject: `validate_scorers("not_a_list")`
- Relation: RAISES
- Expected: Raises `MlflowException` with message containing "must be a list of scorers"
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:37-39`.
- Observe: EXCEPTION
- Target: `validate_scorers("not_a_list")`
- Obligations: R5
- Graph: N6, N11, E14

### C12: validate_scorers raises with hint for nested get_all_scorers
- Type: Failure
- Subject: `validate_scorers([get_all_scorers()])`
- Relation: RAISES
- Expected: Raises `MlflowException` with hint "Use `scorers=get_all_scorers()`"
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:62-70`.
- Observe: EXCEPTION
- Target: `validate_scorers([get_all_scorers()])`
- Obligations: R5, R7
- Graph: N6, N5, E12, N11, E14

### C13: validate_scorers raises with hint for class-not-instance
- Type: Failure
- Subject: `validate_scorers([Correctness])`  (class, not instance)
- Relation: RAISES
- Expected: Raises `MlflowException` with hint "you passed a scorer class instead of an instance"
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:74-77`.
- Observe: EXCEPTION
- Target: `validate_scorers([Correctness])`
- Obligations: R5
- Graph: N6, N8, N11, E14

### C14: valid_data_for_builtin_scorers normalizes request/response columns
- Type: Dataflow
- Subject: DataFrame column names `"request"` and `"response"`
- Relation: PRESERVE
- Expected: `"request"` is internally mapped to `"inputs"` and `"response"` to `"outputs"` before validation
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:117-123`.
- Observe: SIDE_EFFECT
- Target: Scorer's `validate_columns` receives `"inputs"`/`"outputs"` not `"request"`/`"response"`
- Obligations: R6
- Graph: N7, E15

### C15: valid_data_for_builtin_scorers adds outputs when predict_fn present
- Type: Dataflow
- Subject: `input_columns` when `predict_fn is not None`
- Relation: CONTAINS
- Expected: The internal column set includes `"outputs"` even if the DataFrame lacks it
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:128-130`.
- Observe: SIDE_EFFECT
- Target: Scorer's `validate_columns` does not raise `MissingColumnsException` for `"outputs"`
- Obligations: R6
- Graph: N7, E15

### C16: valid_data_for_builtin_scorers adds inputs/outputs when trace column present
- Type: Dataflow
- Subject: `input_columns` when `"trace"` in DataFrame columns
- Relation: CONTAINS
- Expected: The internal column set includes both `"inputs"` and `"outputs"`
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:132-134`.
- Observe: SIDE_EFFECT
- Target: Scorer's `validate_columns` does not raise for `"inputs"` or `"outputs"`
- Obligations: R6
- Graph: N7, E15

### C17: valid_data_for_builtin_scorers explodes expectations dict keys
- Type: Dataflow
- Subject: `input_columns` when `"expectations"` column exists
- Relation: CONTAINS
- Expected: For each key `k` in each expectations dict, `f"expectations/{k}"` is added to the column set
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:137-148`.
- Observe: SIDE_EFFECT
- Target: Scorer's `validate_columns` receives `"expectations/expected_response"` etc.
- Obligations: R6
- Graph: N7, E15

### C18: valid_data_for_builtin_scorers raises on non-dict expectations
- Type: Failure
- Subject: `valid_data_for_builtin_scorers` with a DataFrame where `expectations` contains a string
- Relation: RAISES
- Expected: Raises `MlflowException` with message "must be a dictionary"
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:143-147`.
- Observe: EXCEPTION
- Target: `valid_data_for_builtin_scorers(df_with_bad_expectations, [...])`
- Obligations: R6
- Graph: N7, N11, E17

### C19: valid_data_for_builtin_scorers logs missing columns without raising
- Type: SideEffect
- Subject: `valid_data_for_builtin_scorers` when columns are missing
- Relation: UNCHANGED
- Expected: No exception is raised; `_logger.info` is called with a message listing missing columns and affected scorers
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:160-174`.
- Observe: SIDE_EFFECT
- Target: Logger output contains "missing following columns" and lists column→scorer mapping
- Obligations: R6, R8
- Graph: N7, N15, E16

### C20: valid_data_for_builtin_scorers catches MissingColumnsException
- Type: Dataflow
- Subject: Each scorer's `validate_columns` call
- Relation: CONTAINS
- Expected: `MissingColumnsException` is caught per scorer, and missing columns are aggregated into `missing_col_to_scorers` dict
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/validation.py:152-158`.
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `scorer.validate_columns` is called and its exception is caught
- Obligations: R6, R8
- Graph: N7, N9, N10, E15

### C21: evaluate imports validate_scorers and valid_data_for_builtin_scorers
- Type: Interface
- Subject: Import statement in `/testbed/mlflow/genai/evaluation/base.py`
- Relation: CALLS
- Expected: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers` is present
- Evidence: `/testbed/libs/tracing/mlflow/genai/evaluation/base.py:21`; call sites at lines 243, 248.
- Observe: IMPORT_BOUNDARY
- Target: `/testbed/mlflow/genai/evaluation/base.py` module imports
- Obligations: R5, R6
- Graph: N12, N6, N7, E10, E11

### C22: CustomScorer.__init__ calls Scorer.__init__
- Type: Behavior
- Subject: `CustomScorer(name="x")` initialization
- Relation: CALLS
- Expected: `super().__init__(**data)` is called, setting `name`, `description`, `aggregations` on the Scorer base
- Evidence: `/testbed/libs/tracing/mlflow/genai/scorers/base.py:1004-1005`.
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `Scorer.__init__` receives the same keyword arguments
- Obligations: R1
- Graph: N2, N3, E3
