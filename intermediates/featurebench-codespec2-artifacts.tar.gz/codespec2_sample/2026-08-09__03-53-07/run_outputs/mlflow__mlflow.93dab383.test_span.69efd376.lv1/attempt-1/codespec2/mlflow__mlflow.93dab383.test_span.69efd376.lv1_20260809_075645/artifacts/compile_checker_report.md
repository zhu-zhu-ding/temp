# Compile Checker Report

- Status: needs_revision

## Req-Test Evidence

### RT1: `span.attributes` returns deserialized dict with correct values
- Test: `tests/tracing/test_fluent.py::test_start_span_context_manager`
- Location: `tests/tracing/test_fluent.py:720-742`
- Key Code:
  ```python
  root_span = trace.data.spans[0]
  assert root_span.attributes == {
      "mlflow.traceRequestId": trace.info.trace_id,
      "mlflow.spanType": "UNKNOWN",
      "mlflow.spanInputs": {"x": 1, "y": 2},
      "mlflow.spanOutputs": 25,
  }
  child_span_1 = trace.data.spans[1]
  assert child_span_1.attributes == {
      "delta": 2,
      "time": str(datetime_now),
      "mlflow.traceRequestId": trace.info.trace_id,
      "mlflow.spanType": "LLM",
      "mlflow.spanInputs": 3,
      "mlflow.spanOutputs": 5,
  }
  ```
- Test Lens: dataflow — attributes are deserialized from internal JSON to Python objects; custom attributes (`delta`, `time`) coexist with system attributes.
- Implied Requirement: `Span.attributes` must return a plain dict where all values are deserialized Python objects (not JSON strings), containing both system keys (`mlflow.traceRequestId`, `mlflow.spanType`, `mlflow.spanInputs`, `mlflow.spanOutputs`) and user-set keys with their original types.
- IR / Spec Mapping: R6, C10, `check_span_attributes_deserialized`, `check_span_attributes_caching`
- Verdict: covered

### RT2: `create_mlflow_span` factory used with OTelReadableSpan to produce a Span with working `attributes`
- Test: `tests/tracing/test_tracing_client.py::test_tracing_client_get_trace_with_database_stored_spans`
- Location: `tests/tracing/test_tracing_client.py:155-185`
- Key Code:
  ```python
  from mlflow.entities.span import create_mlflow_span
  otel_span = OTelReadableSpan(
      name="test_span",
      context=trace_api.SpanContext(trace_id=12345, span_id=111, ...),
      attributes={
          "mlflow.traceRequestId": json.dumps(trace_id, cls=TraceJSONEncoder),
          "llm.model_name": "test-model",
          "custom.attribute": "test-value",
      }, ...
  )
  span = create_mlflow_span(otel_span, trace_id, "LLM")
  store.log_spans(experiment_id, [span])
  ...
  loaded_span = trace.data.spans[0]
  assert loaded_span.attributes.get("llm.model_name") == "test-model"
  assert loaded_span.attributes.get("custom.attribute") == "test-value"
  ```
- Test Lens: dataflow/round-trip — factory creates an immutable Span from OTelReadableSpan; Span survives store log + retrieval; attributes deserialize correctly.
- Implied Requirement: `create_mlflow_span(OTelReadableSpan, trace_id, span_type)` returns a `Span` (not LiveSpan) whose `attributes` property returns deserialized values; the span must be serializable through `store.log_spans`.
- IR / Spec Mapping: R14 (C21), R6, C10
- Verdict: covered

### RT3: `_decode_otel_proto_anyvalue` decodes all AnyValue variants through SpanEvent round-trip
- Test: `tests/entities/test_span_event.py::test_span_event_to_otel_proto_conversion`
- Location: `tests/entities/test_span_event.py:16-35`
- Key Code:
  ```python
  @pytest.mark.parametrize("event_attrs", [
      {},
      {"simple": "string"},
      {"number": 42, "float": 3.14, "bool": True},
      {"list": [1, 2, 3], "dict": {"nested": "value"}},
  ])
  def test_span_event_to_otel_proto_conversion(event_attrs):
      event = SpanEvent(name="test_event", timestamp=1234567890, attributes=event_attrs)
      otel_proto_event = event.to_otel_proto()
      from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue
      decoded_attrs = {}
      for attr in otel_proto_event.attributes:
          decoded_attrs[attr.key] = _decode_otel_proto_anyvalue(attr.value)
      assert decoded_attrs == event_attrs
  ```
- Test Lens: serialization round-trip — `_set_otel_proto_anyvalue` + `_decode_otel_proto_anyvalue` must be inverses for all supported types (empty, string, int, float, bool, list, dict).
- Implied Requirement: `_decode_otel_proto_anyvalue` must handle all primitive types, arrays, and kvlists, and be an exact inverse of `_set_otel_proto_anyvalue`.
- IR / Spec Mapping: R15, C22–C26, `check_decode_otel_proto_anyvalue`, `check_decode_otel_proto_nested`
- Verdict: covered

### RT4: `_Trace.to_mlflow_trace` called via `pop_trace` produces Trace with immutable Span instances
- Test: `tests/tracing/test_trace_manager.py::test_add_spans`
- Location: `tests/tracing/test_trace_manager.py:18-68`
- Key Code:
  ```python
  manager_trace = trace_manager.pop_trace(trace_id_1)
  assert isinstance(manager_trace, ManagerTrace)
  assert manager_trace.trace.info.request_id == request_id_1
  assert len(manager_trace.trace.data.spans) == 3
  # Convert to MLflow trace to check immutable spans
  trace = manager_trace.trace
  assert isinstance(trace.data.spans[0], Span)
  assert not isinstance(trace.data.spans[0], LiveSpan)
  ```
- Test Lens: lifecycle/state — after `pop_trace`, all spans in the returned Trace are immutable `Span` objects, never `LiveSpan`.
- Implied Requirement: `_Trace.to_mlflow_trace()` must convert every LiveSpan in `span_dict` to an immutable Span; the conversion is exercised through the public `pop_trace` path.
- IR / Spec Mapping: R1, R4, C1, `check_to_mlflow_trace_conversion`, `check_to_mlflow_trace_multiple_spans`
- Verdict: covered

### RT5: `span.span_type` returns the configured type
- Test: `tests/anthropic/test_anthropic_autolog.py::test_anthropic_autolog_tracing`
- Location: `tests/anthropic/test_anthropic_autolog.py:187`
- Key Code:
  ```python
  assert span.span_type == SpanType.CHAT_MODEL
  ```
- Test Lens: dataflow — `span_type` property returns the span type stored under `SpanAttributeKey.SPAN_TYPE`.
- Implied Requirement: `Span.span_type` must return the attribute value for `SpanAttributeKey.SPAN_TYPE`.
- IR / Spec Mapping: R10, C14, `check_span_span_type`, `check_span_type_edge_cases`
- Verdict: covered

### RT6: NoOpSpan constructor used in test without raising
- Test: `tests/tracing/test_fluent.py::test_span_record_exception_no_op_span`
- Location: `tests/tracing/test_fluent.py:1831-1838`
- Key Code:
  ```python
  from mlflow.entities.span import NoOpSpan
  no_op_span = NoOpSpan()
  no_op_span.record_exception("This should be ignored")
  assert get_traces() == []
  ```
- Test Lens: error handling — `NoOpSpan()` constructs without error; `record_exception` is a no-op.
- Implied Requirement: `NoOpSpan` must be constructable with no arguments and all setter calls must be safe no-ops.
- IR / Spec Mapping: R5, C6–C9, `check_noop_span_getters`, `check_noop_span_setters_noop`, `check_noop_span_complete_interface`
- Verdict: covered

## Findings

### Finding 1: Missing transitive dependency `SpanStatus.to_otel_proto_status()`
- Category: lost_obligation
- Subrequirements: R12 (`Span.to_otel_proto`)
- Evidence: The reference implementation at `/testbed/libs/tracing/mlflow/entities/span.py:442` calls `self.status.to_otel_proto_status()` inside `Span.to_otel_proto()`. The method `SpanStatus.to_otel_proto_status()` exists in the reference (`/testbed/libs/tracing/mlflow/entities/span_status.py:115`) but not in the target (`/testbed/mlflow/entities/span_status.py`), where only `to_otel_proto_status_code_name` (on SpanStatusCode) and `from_otel_proto_status` (on SpanStatus) exist. The production callers at `/testbed/mlflow/store/tracking/rest_store.py:1739` and `/testbed/mlflow/entities/trace.py:324` both call `span.to_otel_proto()`.
- Cause: The IR graph for R12 (N12→E8) captures `_set_otel_proto_anyvalue` as a dependency but does not traverse into `self.status.to_otel_proto_status()`. The `SpanStatus` class is not mentioned in the IR at all.
- Impact: The spec check C17 (`check_span_to_otel_proto`) and C17 behavior variant (`check_to_otel_proto_with_parent`) both call `span.to_otel_proto()`. These checks would fail at runtime with `AttributeError: 'SpanStatus' object has no attribute 'to_otel_proto_status'` because the dependency is not satisfied. The spec is therefore unexecutable until `SpanStatus` is also modified.
- Required Change: Add a graph node for `SpanStatus.to_otel_proto_status` and an edge N12→node(span_status). Add a contract that verifies `SpanStatus.to_otel_proto_status()` returns a valid `OTelProtoStatus`. The IR should note that `SpanStatus` needs both `to_otel_status()` (already called by `LiveSpan.set_status` at span.py:578 and `Span.from_dict` at span.py:310) and `to_otel_proto_status()` (called by `Span.to_otel_proto`).
- Req-Test Evidence: None (no applicable native test) — the production callers are in `rest_store.py`, `trace.py`, `otel_api.py`, and `databricks_rest_store.py`.

### Finding 2: Weak contract C17 — `Span.to_otel_proto` does not verify attribute/status/event fidelity
- Category: weak_contract
- Subrequirements: R12
- Evidence: The arch spec `check_span_to_otel_proto` asserts only `proto.name == span.name`, `len(proto.trace_id) > 0`, and `len(proto.span_id) > 0`. The behavior spec `check_to_otel_proto_with_parent` additionally checks byte lengths (16/8) and `len(proto.attributes) > 0`. Neither verifies that attribute values, status code, events, or timing round-trip correctly.
- Cause: The contracts C17 observe only structural presence (non-empty bytes, attribute count) rather than semantic fidelity of converted data.
- Impact: A wrong implementation that returns a protobuf with correct name/IDs but fabricated or empty attributes, wrong status, and missing events would pass both checks. The production callers in `rest_store.py` and `databricks_rest_store.py` rely on correct attribute/event conversion.
- Required Change: Strengthen C17 to verify: (a) `proto.status.code` matches the Span's status (OK/ERROR); (b) at least one attribute key+value round-trips correctly; (c) `len(proto.events)` matches `len(span.events)`; (d) `proto.start_time_unix_nano == span.start_time_ns` and `proto.end_time_unix_nano == span.end_time_ns`.
- Req-Test Evidence: None (no applicable native test) — native tests exercise `span.to_otel_proto()` indirectly through store logging and OTLP export.

### Finding 3: Behavior spec extends `create_mlflow_span` test to falsy values not documented in interface
- Category: weak_contract
- Subrequirements: R14
- Evidence: The behavior spec `check_create_mlflow_span_boundaries` tests `create_mlflow_span(0, "tid")`, `create_mlflow_span(False, "tid")`, and `create_mlflow_span("", "tid")`, expecting `NoOpSpan`. The Interface Description 2 only documents four valid input categories: `OTelSpan`, `OTelReadableSpan`, `NonRecordingSpan`, and `None`. The production code in the reference uses `if not otel_span`, which catches all Python falsy values.
- Cause: The spec encodes an implementation detail (Python truthiness check) rather than the documented interface contract.
- Impact: A plausible implementation that checks `if otel_span is None or isinstance(otel_span, NonRecordingSpan)` instead of `if not otel_span` would be correct per the documented interface but would fail this spec check. The check is over-specified.
- Required Change: Either (a) reduce the test to only `None` and `NonRecordingSpan` as documented, or (b) add a note that the falsy-value behavior is an implementation choice tested against the reference, not a documented contract. The R14 acceptance criteria should clarify the boundary.
- Req-Test Evidence: None (no applicable native test) — no native test passes non-span falsy values to `create_mlflow_span`.

## Coverage

| R   | Contracts | Spec Check Functions |
|-----|-----------|---------------------|
| R1  | C1, C2    | arch: `check_to_mlflow_trace_conversion`; behav: `check_to_mlflow_trace_multiple_spans`, `check_trace_lifecycle_state_transitions` |
| R2  | C3        | arch: `check_live_span_from_dict_raises`; behav: `check_live_span_from_dict_error` |
| R3  | C4        | arch: `check_live_span_set_span_type`; behav: `check_live_span_set_span_type_override` |
| R4  | C5        | arch: `check_live_span_to_immutable`; behav: `check_to_immutable_span_preserves_data` |
| R5  | C6, C7, C8, C9 | arch: `check_noop_span_getters`, `check_noop_span_setters_noop`; behav: `check_noop_span_complete_interface` |
| R6  | C10       | arch: `check_span_attributes_deserialized`; behav: `check_span_attributes_caching` |
| R7  | C11       | arch: `check_span_events`; behav: `check_span_events_with_data` |
| R8  | C12       | arch: `check_span_from_otel_proto`; behav: `check_from_otel_proto_with_location` |
| R9  | C13       | arch: `check_span_request_id_alias`; behav: `check_request_id_backward_compat` |
| R10 | C14       | arch: `check_span_span_type`; behav: `check_span_type_edge_cases` |
| R11 | C15, C16  | arch: `check_span_to_dict_base64_ids`, `check_span_to_dict_roundtrip`; behav: `check_to_dict_from_dict_full_roundtrip`, `check_to_dict_encoding_scheme` |
| R12 | C17       | arch: `check_span_to_otel_proto`; behav: `check_to_otel_proto_with_parent` |
| R13 | C18       | arch: `check_cached_registry_set_raises`; behav: `check_cached_registry_immutability` |
| R14 | C19, C20, C21, C27 | arch: `check_create_mlflow_span_factory`; behav: `check_create_mlflow_span_boundaries`, `check_create_mlflow_span_live_span_attrs` |
| R15 | C22, C23, C24, C25, C26 | arch: `check_decode_otel_proto_anyvalue`; behav: `check_decode_otel_proto_nested` |

Unreferenced C: None. Every C has at least one check in either arch or behavior spec.

Helper-only checks (tests for graph nodes N17–N22, not tied to a formal R): `check_helper_functions`, `check_otel_proto_bytes_to_id`.

## Judge Focus

1. **`SpanStatus.to_otel_proto_status()`**: Before implementing R12, ensure `SpanStatus` gains both `to_otel_status()` (needed by existing callers at span.py:310,578) and `to_otel_proto_status()` (needed by `Span.to_otel_proto`). Verify the protobuf status conversion round-trips correctly.

2. **`Span.to_otel_proto` attribute fidelity**: The current C17 checks are structural (non-empty bytes). When implementing `Span.to_otel_proto`, verify that at least one attribute value survives the Python→AnyValue→Python round-trip. Check status code mapping and event count preservation.

3. **`SpanStatus.to_otel_status()`**: Already called by `Span.from_dict` (line 310) and `LiveSpan.set_status` (line 578) in the target code. If modifying `span_status.py` to add `to_otel_proto_status()`, also add `to_otel_status()` to avoid breaking those existing call sites.

4. **`create_mlflow_span` falsy boundary**: The reference uses `if not otel_span` (Python truthiness). Decide whether to match this behavior (and keep the boundary test) or use an explicit `is None` + `isinstance(NonRecordingSpan)` check (and relax the test).

5. **`_SpanAttributesRegistry.get_all()`**: Required by `Span.attributes` (R6). Ensure it iterates all keys via `self._span.attributes` and deserializes each value using `json.loads` (or returns raw on failure). The method is not in the interface descriptions but is exercised by C10.
