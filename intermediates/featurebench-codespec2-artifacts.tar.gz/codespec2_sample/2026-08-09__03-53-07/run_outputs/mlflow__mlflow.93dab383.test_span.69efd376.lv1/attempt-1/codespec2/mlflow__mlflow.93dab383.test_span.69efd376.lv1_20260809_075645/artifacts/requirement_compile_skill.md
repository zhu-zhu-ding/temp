# Requirement Compile Agent Skill

This is durable method guidance, not task evidence. Update it after compiling
each task with concise lessons about ambiguity, evidence gaps, and IR quality.

## Responsibilities

1. Treat the task as the authority for required behavior and use repository
   evidence only to locate compatible implementation paths and observers.
2. Lower prose into atomic L1 Requirement Obligations. Split independent
   behavior, failure, state, dataflow, and compatibility claims.
3. Build an L2 Functional Design Graph with only `CALL`, `CONTROL`, `DATA`,
   and `STATE` edges supported by source, callers, exports, or native tests.
4. Attach L3 Verifiable Contracts to graph nodes/edges. Every contract needs a
   typed relation, expected result, evidence, and explicit observation method.
5. Make observability first class: identify the public observer or runtime
   boundary where a future test can mechanically validate the contract.
6. Compile every contract into `arch_spec.py` or `behavior_spec.py`, preserving
   its contract ID and public-entry-to-observer path.

## Guardrails

- Write only the supplied executable spec artifacts; never production code or
  repository-native tests.
- Do not infer dataflow from symbol names or docstrings alone.
- Record unknowns explicitly rather than manufacturing exact defaults, errors,
  state values, or call arguments.
- Ensure each L1 obligation reaches at least one L3 contract through L2.

## Lessons

### Lesson 1: Reference implementations in `/testbed/libs/` provide ground truth
When the task involves implementing missing methods in an existing class hierarchy,
look for parallel implementations under `/testbed/libs/` (e.g., `/testbed/libs/tracing/`,
`/testbed/libs/skinny/`). These contain complete reference implementations that resolve
ambiguities about exact signatures, error types, and delegation patterns.
*Evidence*: This task — `/testbed/libs/tracing/mlflow/entities/span.py` contained
the full NoOpSpan, LiveSpan, Span, _CachedSpanAttributesRegistry, and helper functions.

### Lesson 2: Check for dual versions of the same module
MLflow maintains multiple copies of key modules (e.g., `mlflow/entities/span_status.py`
vs `libs/tracing/mlflow/entities/span_status.py`). One may be a stub missing critical
methods (like `to_otel_status`, `from_otel_status`, `to_otel_proto_status`). Always
cross-reference both to identify which methods exist and which are missing.
*Evidence*: `span_status.py` at `/testbed/mlflow/entities/` was missing `to_otel_status`,
`from_otel_status`, and `to_otel_proto_status`; the libs version had them all.

### Lesson 3: Factory functions need explicit type-dispatch contracts
When a factory function like `create_mlflow_span` dispatches on input type, each branch
(falsy → NoOpSpan, OTelSpan → LiveSpan, OTelReadableSpan → Span, invalid → exception)
must be captured as a separate L3 contract. This ensures the spec covers all dispatch
arms including the error path.
*Evidence*: `create_mlflow_span` required C19, C20, C21, C27 to cover all four branches.

### Lesson 4: ID encoding schemes require exact byte-level verification
When the task specifies exact encoding (int → bytes with big-endian → base64), the
contract must verify byte lengths (16 for trace_id, 8 for span_id) and round-trip
fidelity. Abstract "it encodes" is insufficient.
*Evidence*: Interface Description 2's `to_dict` docstring specified exact byte lengths
and encoding order; C15 and C16 verify these mechanically.

### Lesson 5: NoOpSpan requires full interface conformance
A NoOpSpan must match every public method and property of the real Span class. Missing
even one setter or getter will cause runtime errors in user code. The L1 obligations
should enumerate all required getters and setters individually.
*Evidence*: NoOpSpan requires ~12 methods/properties; the task docstring explicitly says
"This class should have exactly the same interface as the Span."

### Lesson 6: Immutability contracts require negative tests
For cached/immutable registries, the contract must include a negative test proving
that mutation is rejected with the correct exception type and error code, not just
that reads work.
*Evidence*: `_CachedSpanAttributesRegistry.set` must raise `MlflowException` with
`INVALID_PARAMETER_VALUE`; C18 verifies this.

### Lesson 7: Trace transitive dependencies through all call chains
When a graph node N (e.g., N12 `Span.to_otel_proto`) calls into method M on a
different class (e.g., `SpanStatus.to_otel_proto_status()`), the IR must include:
(a) a separate node for that class/method, (b) a CALL edge from N to that node,
(c) a requirement obligation and contract for the transitive dependency, and
(d) spec checks that exercise the dependency. Without this, the spec is unexecutable
because contracts on N would fail at runtime due to missing transitive methods.
*Evidence*: Finding 1 — `Span.to_otel_proto` calls `self.status.to_otel_proto_status()`
but the IR had no SpanStatus node. Similarly, existing target code at
`/testbed/mlflow/entities/span.py` lines 155, 310, 578 calls `SpanStatus.from_otel_status()`
and `status.to_otel_status()` which were missing from the target `span_status.py`.
Fixed by adding R16, R17, N24, E13, C28, C29.

### Lesson 8: Structural-only contracts are insufficient for serialization fidelity
A contract like C17 that only checks `proto.name == span.name` and non-empty byte
fields will pass even if attributes are wrong, status is fabricated, events are
dropped, or timing is incorrect. Serialization contracts must verify:
(a) attribute key+value round-trip correctness, (b) status code mapping,
(c) event count and content preservation, and (d) exact timing field values.
*Evidence*: Finding 2 — the original C17 only checked structural presence (name,
non-empty bytes, attribute count > 0). Strengthened to verify status code,
attribute decode round-trip, event count equality, and nanosecond timing precision.

### Lesson 9: Document implementation-behavior vs documented-interface gaps
When the reference implementation uses a broader guard than the documented interface
(e.g., `if not otel_span` catching all falsy values vs the documented `None` and
`NonRecordingSpan`), the spec should match the reference behavior but explicitly
note the divergence. Put the note in both the IR's Uncertainty/Acceptance field
and as a comment in the behavior spec.
*Evidence*: Finding 3 — `create_mlflow_span` uses `if not otel_span` which catches
`0`, `False`, `""` in addition to `None` and `NonRecordingSpan`. The behavior spec
tests this but now includes a comment explaining it's reference-matching, not
documented-contract-matching.

### Lesson 10: Read existing target code for implicit dependencies before compiling IR
Before finalizing the IR, grep the target code under `/testbed/mlflow/` for all
method calls on classes that the task touches. Existing target code may already
call methods (like `SpanStatus.from_otel_status`) that don't yet exist in the
target but do exist in the reference. These implicit dependencies become new
requirements that the IR must capture.
*Evidence*: Grepping `/testbed/mlflow/entities/span.py` revealed calls to
`SpanStatus.from_otel_status()` (line 155) and `status.to_otel_status()` (lines 310, 578)
that were absent from the target `span_status.py` and not captured in the original IR.
