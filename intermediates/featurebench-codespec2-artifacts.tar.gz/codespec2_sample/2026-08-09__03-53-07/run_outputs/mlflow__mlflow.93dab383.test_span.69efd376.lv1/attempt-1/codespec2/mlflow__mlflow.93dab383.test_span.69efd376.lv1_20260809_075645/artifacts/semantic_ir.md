# Semantic IR: MLflow Distributed Tracing System

## L1. Requirement Obligations

### R1: _Trace.to_mlflow_trace Conversion
- **Type**: Behavior
- **Statement**: The `_Trace.to_mlflow_trace()` method shall convert all LiveSpan objects in `span_dict` into immutable Span objects, package them into a TraceData container, call `set_request_response_preview` on the TraceInfo, and return a Trace object wrapping both info and data.
- **Task Evidence**: Interface Description 1 — method signature `def to_mlflow_trace(self) -> Trace` with docstring stating "converts all LiveSpan objects in the span dictionary to immutable Span objects, creates a TraceData container, and sets request/response previews."
- **Acceptance**: Calling `to_mlflow_trace()` on a `_Trace` instance with LiveSpan entries yields a `Trace` whose `data.spans` are all immutable `Span` instances; the `TraceInfo` has populated `request_preview`/`response_preview` fields.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/tracing/trace_manager.py` lines 26-33 contain a reference implementation. The `pop_trace` method (line ~165) calls `internal_trace.to_mlflow_trace()`. The method calls `set_request_response_preview()` from `mlflow.tracing.utils.truncation`.
- **Uncertainty**: None — reference implementation is available.

### R2: LiveSpan.from_dict Rejection
- **Type**: Failure
- **Statement**: `LiveSpan.from_dict(cls, data)` shall raise `NotImplementedError` because LiveSpan objects represent active mutable spans that cannot be reconstructed from serialized data.
- **Task Evidence**: Interface Description 2 — method signature `def from_dict(cls, data: dict[str, Any]) -> 'Span'` with docstring "This method is not supported for the LiveSpan class."
- **Acceptance**: Calling `LiveSpan.from_dict({"name": "test", ...})` raises `NotImplementedError`.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~660: `raise NotImplementedError("The 'from_dict' method is not supported for the LiveSpan class.")`
- **Uncertainty**: None.

### R3: LiveSpan.set_span_type
- **Type**: Behavior
- **Statement**: `LiveSpan.set_span_type(span_type: str)` shall set the span type attribute (`SpanAttributeKey.SPAN_TYPE`) on the underlying OTel span via the attribute registry.
- **Task Evidence**: Interface Description 2 — method signature `def set_span_type(self, span_type: str)` with docstring stating "Set the type of the span to categorize its purpose or functionality."
- **Acceptance**: Calling `set_span_type("LLM")` on a LiveSpan causes `span.get_attribute(SpanAttributeKey.SPAN_TYPE)` to return `"LLM"`.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~527: `self.set_attribute(SpanAttributeKey.SPAN_TYPE, span_type)`.
- **Uncertainty**: None.

### R4: LiveSpan.to_immutable_span Conversion
- **Type**: Behavior
- **Statement**: `LiveSpan.to_immutable_span()` shall wrap the underlying `_span` (OTelReadableSpan) in an immutable `Span` object and return it — no data copying is needed since the OTel span already holds all state.
- **Task Evidence**: Interface Description 2 — method signature `def to_immutable_span(self) -> 'Span'` with docstring "All state of the live span is already persisted in the OpenTelemetry span object, so no data copying is required."
- **Acceptance**: The returned Span has the same `name`, `trace_id`, `span_id`, `attributes`, and `status` as the original LiveSpan.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~665: `return Span(self._span)`.
- **Uncertainty**: None.

### R5: NoOpSpan Pass-Through Interface
- **Type**: Behavior
- **Statement**: The `NoOpSpan` class shall provide all setters (`set_inputs`, `set_outputs`, `set_attributes`, `set_attribute`, `set_status`, `add_event`, `record_exception`, `end`) as no-ops and all getters (`trace_id`, `span_id`, `name`, `start_time_ns`, `end_time_ns`, `status`, `_trace_id`, `parent_id`) returning `None` or `NO_OP_SPAN_TRACE_ID` as appropriate.
- **Task Evidence**: Interface Description 2 — NoOpSpan class docstring "This class should have exactly the same interface as the Span so that user's setter calls do not raise runtime errors."
- **Acceptance**: Every NoOpSpan setter call does not raise; getters return the documented sentinel values.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` full NoOpSpan class (lines ~730-810). `trace_id` returns `NO_OP_SPAN_TRACE_ID`, all other getters return `None`.
- **Uncertainty**: None.

### R6: Span.attributes Deserialization
- **Type**: Dataflow
- **Statement**: `Span.attributes` property shall return all span attributes as a dictionary with JSON-deserialized values using the `_CachedSpanAttributesRegistry`.
- **Task Evidence**: Interface Description 2 — `@property attributes` with docstring "The attributes are automatically deserialized from their internal JSON string representation to their original Python objects."
- **Acceptance**: Accessing `span.attributes` returns a dict where values are deserialized Python objects matching the original types set on the span.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~175: calls `self._attributes.get_all()` which iterates all keys and deserializes each.
- **Uncertainty**: None.

### R7: Span.events List Conversion
- **Type**: Dataflow
- **Statement**: `Span.events` property shall return a list of `SpanEvent` objects created from the OTel span's events, converting OTel BoundedAttributes to plain dicts.
- **Task Evidence**: Interface Description 2 — `@property events` with docstring stating "The returned events are converted from OpenTelemetry's internal BoundedAttributes format to simple dictionaries."
- **Acceptance**: Each returned SpanEvent has `name`, `timestamp`, and `attributes` fields; `attributes` is a plain dict (not BoundedAttributes).
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~195-205.
- **Uncertainty**: None.

### R8: Span.from_otel_proto Construction
- **Type**: Dataflow
- **Statement**: `Span.from_otel_proto(otel_proto_span, location_id=None)` shall construct an immutable Span from an OTel protobuf span, decoding all fields (trace_id, span_id, timing, attributes, events, status). If `location_id` is provided, generates a v4 trace ID; otherwise generates a standard MLflow trace ID.
- **Task Evidence**: Interface Description 2 — `@classmethod from_otel_proto` with docstring detailing conversion from protobuf to Span.
- **Acceptance**: The returned Span has attributes, events, status, and timing matching the protobuf input; `trace_id` is correct per the location_id logic.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~390-420.
- **Uncertainty**: None.

### R9: Span.request_id Backward Compatibility
- **Type**: Dataflow
- **Statement**: `Span.request_id` property shall return the same value as `trace_id` for backward compatibility.
- **Task Evidence**: Interface Description 2 — `@property request_id` with docstring "This property provides backward compatibility for code that uses the deprecated request_id attribute."
- **Acceptance**: `span.request_id == span.trace_id`.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~130-133: `return self.trace_id`.
- **Uncertainty**: None.

### R10: Span.span_type Retrieval
- **Type**: Dataflow
- **Statement**: `Span.span_type` property shall return the span type attribute value stored under `SpanAttributeKey.SPAN_TYPE`.
- **Task Evidence**: Interface Description 2 — `@property span_type` with docstring stating "The type of the span."
- **Acceptance**: For a span with `SPAN_TYPE` set to `"LLM"`, `span.span_type` returns `"LLM"`.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~175-177: `return self.get_attribute(SpanAttributeKey.SPAN_TYPE)`.
- **Uncertainty**: None.

### R11: Span.to_dict Serialization
- **Type**: Dataflow
- **Statement**: `Span.to_dict()` shall serialize the span into a dictionary with base64-encoded IDs using big-endian byte conversion: trace_id → 16 bytes → base64, span_id/parent_span_id → 8 bytes → base64. Shall include all timing, events, status, and attributes.
- **Task Evidence**: Interface Description 2 — `def to_dict(self) -> dict[str, Any]` with detailed encoding specification.
- **Acceptance**: The dictionary has keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`. IDs are base64-encoded. A `from_dict(to_dict(span))` round-trip preserves all data.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~220-250.
- **Uncertainty**: None.

### R12: Span.to_otel_proto Conversion
- **Type**: Dataflow
- **Statement**: `Span.to_otel_proto()` shall convert the MLflow Span into an OpenTelemetry protobuf Span message (OTelProtoSpan). This includes converting trace/span IDs from hex to bytes, mapping timing, converting status via `SpanStatus.to_otel_proto_status()`, serializing attributes via `_set_otel_proto_anyvalue`, converting events, and setting parent span ID if present.
- **Task Evidence**: Interface Description 2 — `def to_otel_proto(self) -> OTelProtoSpan` with detailed docstring.
- **Acceptance**: The returned `OTelProtoSpan` has correct byte-level trace_id (16 bytes hex-decoded), span_id (8 bytes hex-decoded), status code reflecting the span's status (OK/ERROR/UNSET), all attributes encoded as AnyValue, all events converted, and timing in nanoseconds.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~422-452 in reference; calls `self.status.to_otel_proto_status()`, `_set_otel_proto_anyvalue`, `event.to_otel_proto()`.
- **Uncertainty**: None.

### R13: _CachedSpanAttributesRegistry Immutability
- **Type**: Failure
- **Statement**: `_CachedSpanAttributesRegistry.set(key, value)` shall raise `MlflowException` with `INVALID_PARAMETER_VALUE` because the cached registry is for immutable spans only.
- **Task Evidence**: Interface Description 2 — `_CachedSpanAttributesRegistry.set` docstring "This method is intentionally disabled for cached span attributes as they represent immutable, persisted span data."
- **Acceptance**: Calling `set()` on a cached registry raises `MlflowException`.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~902-904: `raise MlflowException(...)`.
- **Uncertainty**: None.

### R14: create_mlflow_span Factory Dispatch
- **Type**: Behavior
- **Statement**: `create_mlflow_span(otel_span, trace_id, span_type=None)` shall dispatch on the type of `otel_span`: falsy values (None, 0, False, "") or `NonRecordingSpan` → `NoOpSpan`; `OTelSpan` → `LiveSpan`; `OTelReadableSpan` → `Span`; any other type → raise `MlflowException`.
- **Task Evidence**: Interface Description 2 — `create_mlflow_span` factory function docstring.
- **Acceptance**: Each dispatch branch returns the correct span subclass; invalid type raises `MlflowException`.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span.py` line ~65-85: `if not otel_span or isinstance(otel_span, NonRecordingSpan): return NoOpSpan()`.
- **Uncertainty**: The `not otel_span` guard catches all Python falsy values (None, 0, False, ""), not just None. This is an implementation detail of the reference; the documented interface only lists None and NonRecordingSpan as NoOpSpan triggers. Acceptance tests should match the reference behavior (Python truthiness), but the documented contract is narrower.

### R15: _decode_otel_proto_anyvalue Full Decoding
- **Type**: Dataflow
- **Statement**: `_decode_otel_proto_anyvalue(pb_any_value)` shall recursively decode an OpenTelemetry protobuf AnyValue into a Python object, handling all types: None (unset), bool, str, int, float, bytes, arrays (list), and key-value lists (dict).
- **Task Evidence**: Interface Description 3 — function signature with detailed type mapping.
- **Acceptance**: Round-trip through `_set_otel_proto_anyvalue` + `_decode_otel_proto_anyvalue` preserves the original Python value for all supported types.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/tracing/utils/otlp.py` reference implementation.
- **Uncertainty**: None.

### R16: SpanStatus.to_otel_proto_status Conversion
- **Type**: Dataflow
- **Statement**: `SpanStatus.to_otel_proto_status()` shall convert the MLflow SpanStatus into an OpenTelemetry protobuf Status message, mapping `SpanStatusCode.OK` → `STATUS_CODE_OK`, `SpanStatusCode.ERROR` → `STATUS_CODE_ERROR`, and `SpanStatusCode.UNSET` → `STATUS_CODE_UNSET`. If a description is set, it shall populate the `message` field.
- **Task Evidence**: Compile Checker Finding 1 — `Span.to_otel_proto` calls `self.status.to_otel_proto_status()`. Reference implementation at `/testbed/libs/tracing/mlflow/entities/span_status.py` lines 115-130.
- **Acceptance**: `span_status.to_otel_proto_status()` returns an `OTelProtoStatus` with code matching the SpanStatusCode and message matching the description.
- **Repository Evidence**: `/testbed/libs/tracing/mlflow/entities/span_status.py` already has `from_otel_proto_status` (line 135). Reference at `/testbed/libs/tracing/mlflow/entities/span_status.py` has the complete `to_otel_proto_status()` at lines 115-130. Target `/testbed/mlflow/entities/span_status.py` is MISSING this method.
- **Uncertainty**: None.

### R17: SpanStatus.to_otel_status and from_otel_status
- **Type**: Dataflow
- **Statement**: `SpanStatus.to_otel_status()` shall convert to an OpenTelemetry `trace_api.Status` object; `SpanStatus.from_otel_status(otel_status)` shall convert from an OTel Status to a SpanStatus. These are called by existing code at `/testbed/mlflow/entities/span.py` lines 155, 310, 578.
- **Task Evidence**: Compile Checker Finding 1 — existing target code calls `SpanStatus.from_otel_status()` (line 155) and `status.to_otel_status()` (lines 310, 578). These methods exist in the reference `/testbed/libs/tracing/mlflow/entities/span_status.py` but NOT in the target `/testbed/mlflow/entities/span_status.py`.
- **Acceptance**: `SpanStatus.from_otel_status(OTelStatus(StatusCode.OK))` returns `SpanStatus(SpanStatusCode.OK)`. `SpanStatus(SpanStatusCode.ERROR, "fail").to_otel_status()` returns `OTelStatus(StatusCode.ERROR, "fail")`.
- **Repository Evidence**: Reference at `/testbed/libs/tracing/mlflow/entities/span_status.py` lines 85-113.
- **Uncertainty**: None.

## L2. Functional Design Graph

### N1: _Trace.to_mlflow_trace (Entry)
- Public entry point called by `InMemoryTraceManager.pop_trace` when finalizing a trace.
- Calls `set_request_response_preview`, `Span.to_immutable_span()`, constructs `TraceData` and `Trace`.

### N2: LiveSpan.set_span_type (Entry)
- Public mutator on active span; delegates to `set_attribute`.

### N3: LiveSpan.from_dict (Entry)
- Public factory; raises `NotImplementedError`.

### N4: LiveSpan.to_immutable_span (Entry)
- Public converter; wraps `self._span` into `Span(self._span)`.

### N5: NoOpSpan (Entry)
- All setters are no-ops; all getters return sentinel values.
- `trace_id` returns `NO_OP_SPAN_TRACE_ID`; `_trace_id` returns None.

### N6: Span.attributes (Entry)
- Observes `_CachedSpanAttributesRegistry.get_all()`.

### N7: Span.events (Entry)
- Reads `self._span.events` and converts to `SpanEvent` list.

### N8: Span.from_otel_proto (Entry)
- Static factory; uses `_otel_proto_bytes_to_id`, `_decode_otel_proto_anyvalue`, `generate_mlflow_trace_id_from_otel_trace_id` or `generate_trace_id_v4_from_otel_trace_id`.

### N9: Span.request_id (Entry)
- Returns `self.trace_id`.

### N10: Span.span_type (Entry)
- Returns `self.get_attribute(SpanAttributeKey.SPAN_TYPE)`.

### N11: Span.to_dict (Entry)
- Uses `_encode_span_id_to_byte`, `_encode_trace_id_to_byte`, `_encode_bytes_to_base64`.

### N12: Span.to_otel_proto (Entry)
- Constructs `OTelProtoSpan`; converts IDs via `bytes.fromhex`, calls `SpanStatus.to_otel_proto_status()` for status, `_set_otel_proto_anyvalue` for attributes, and `SpanEvent.to_otel_proto()` for events. Sets `parent_span_id`, `start_time_unix_nano`, and `end_time_unix_nano`.

### N13: _CachedSpanAttributesRegistry.set (Entry)
- Raises `MlflowException`.

### N14: create_mlflow_span (Entry)
- Factory; branches on `isinstance(otel_span, NonRecordingSpan)`, `OTelSpan`, `OTelReadableSpan`, None/falsy.

### N15: _decode_otel_proto_anyvalue (Entry)
- Uses `WhichOneof("value")`; recursion for arrays and kvlists.

### N16: _SpanAttributesRegistry.get_all (Helper)
- Called by `Span.attributes`; iterates all attribute keys, deserializes each.

### N17: _encode_span_id_to_byte (Helper)
- Converts int span_id to 8-byte big-endian bytes.

### N18: _encode_trace_id_to_byte (Helper)
- Converts int trace_id to 16-byte big-endian bytes.

### N19: _encode_bytes_to_base64 (Helper)
- Base64-encodes bytes to UTF-8 string.

### N20: _decode_id_from_byte (Helper)
- Base64-decodes and converts to int.

### N21: _is_base64_encoded (Helper)
- Validates base64 encoding.

### N22: _otel_proto_bytes_to_id (Helper)
- Converts OTel protobuf bytes to integer ID.

### N23: set_request_response_preview (External)
- Imported from `mlflow.tracing.utils.truncation`; called by `to_mlflow_trace`.

### N24: SpanStatus.to_otel_proto_status (Helper)
- Called by `Span.to_otel_proto` (N12). Converts `SpanStatus` to `OTelProtoStatus` protobuf.
- Maps `SpanStatusCode.OK` → `STATUS_CODE_OK`, `SpanStatusCode.ERROR` → `STATUS_CODE_ERROR`, `SpanStatusCode.UNSET` → `STATUS_CODE_UNSET`.
- Populates `message` field from `description` if non-empty.

### E1: N1→N4
- **Kind**: CALL
- **Condition**: For each LiveSpan in span_dict
- **Transfer**: LiveSpan → Span (immutable)
- **Evidence**: `to_mlflow_trace` iterates `span_dict.values()` and calls `.to_immutable_span()`
- **Obligations**: R1, R4

### E2: N1→N23
- **Kind**: CALL
- **Condition**: After TraceData construction
- **Transfer**: TraceInfo, TraceData → set_request_response_preview
- **Evidence**: Reference implementation calls `set_request_response_preview(self.info, trace_data)`
- **Obligations**: R1

### E3: N2→Span.set_attribute
- **Kind**: CALL
- **Condition**: Always
- **Transfer**: span_type → SpanAttributeKey.SPAN_TYPE
- **Evidence**: Calls `self.set_attribute(SpanAttributeKey.SPAN_TYPE, span_type)`
- **Obligations**: R3

### E4: N6→N16
- **Kind**: CALL
- **Condition**: On property access
- **Transfer**: Returns deserialized attributes dict
- **Evidence**: `_CachedSpanAttributesRegistry.get_all()` via `_SpanAttributesRegistry.get_all()`
- **Obligations**: R6

### E5: N8→N15
- **Kind**: CALL
- **Condition**: When decoding attribute values from protobuf
- **Transfer**: AnyValue → Python object
- **Evidence**: `_decode_otel_proto_anyvalue(attr.value)` per attribute
- **Obligations**: R8, R15

### E6: N8→N22
- **Kind**: CALL
- **Condition**: Converting trace_id and span_id from protobuf bytes
- **Transfer**: bytes → int
- **Evidence**: `_otel_proto_bytes_to_id(otel_proto_span.trace_id)`
- **Obligations**: R8

### E7: N11→N17, N11→N18, N11→N19
- **Kind**: CALL
- **Condition**: During serialization
- **Transfer**: int → bytes → base64 string
- **Evidence**: `to_dict` calls `_encode_bytes_to_base64(_encode_trace_id_to_byte(...))`
- **Obligations**: R11

### E8: N12→_set_otel_proto_anyvalue
- **Kind**: CALL
- **Condition**: Setting attribute values on protobuf
- **Transfer**: Python object → AnyValue via `_set_otel_proto_anyvalue`
- **Evidence**: `_set_otel_proto_anyvalue(attr.value, value)`
- **Obligations**: R12

### E9: N14→N5
- **Kind**: CONTROL
- **Condition**: `not otel_span or isinstance(otel_span, NonRecordingSpan)`
- **Transfer**: Returns NoOpSpan()
- **Evidence**: Factory function branches
- **Obligations**: R5, R14

### E10: N14→LiveSpan
- **Kind**: CONTROL
- **Condition**: `isinstance(otel_span, OTelSpan)`
- **Transfer**: Returns LiveSpan(otel_span, trace_id, span_type)
- **Evidence**: Factory function branches
- **Obligations**: R14

### E11: N14→Span
- **Kind**: CONTROL
- **Condition**: `isinstance(otel_span, OTelReadableSpan)`
- **Transfer**: Returns Span(otel_span)
- **Evidence**: Factory function branches
- **Obligations**: R14

### E12: N14→MlflowException
- **Kind**: CONTROL
- **Condition**: Invalid otel_span type
- **Transfer**: Raises MlflowException
- **Evidence**: Factory function raises
- **Obligations**: R14

### E13: N12→N24
- **Kind**: CALL
- **Condition**: During protobuf construction
- **Transfer**: SpanStatus → OTelProtoStatus via `SpanStatus.to_otel_proto_status()`
- **Evidence**: Reference `Span.to_otel_proto()` calls `self.status.to_otel_proto_status()` at `/testbed/libs/tracing/mlflow/entities/span.py` line 442
- **Obligations**: R12, R16

## L3. Verifiable Contracts

### C1: _Trace.to_mlflow_trace produces Trace with immutable spans
- **Type**: Interface
- **Subject**: `_Trace.to_mlflow_trace()`
- **Relation**: Returns `Trace` instance; `trace.data.spans` contains only immutable `Span` objects (not LiveSpan).
- **Expected**: `isinstance(result, Trace)`; `all(isinstance(s, Span) and not isinstance(s, LiveSpan) for s in result.data.spans)`.
- **Evidence**: Interface Description 1.
- **Observe**: `RETURN_VALUE` → isinstance checks.
- **Target**: `_Trace.to_mlflow_trace`
- **Obligations**: R1
- **Graph**: N1, E1

### C2: _Trace.to_mlflow_trace sets request/response previews
- **Type**: SideEffect
- **Subject**: `_Trace.to_mlflow_trace()`
- **Relation**: After conversion, `TraceInfo.request_preview` and `TraceInfo.response_preview` are non-None.
- **Expected**: `result.info.request_preview is not None` and `result.info.response_preview is not None`.
- **Evidence**: Interface Description 1.
- **Observe**: `FIELD_READ` on TraceInfo.
- **Target**: `_Trace.to_mlflow_trace`
- **Obligations**: R1
- **Graph**: N1, E2

### C3: LiveSpan.from_dict raises NotImplementedError
- **Type**: Failure
- **Subject**: `LiveSpan.from_dict({"name": "test"})`
- **Relation**: Always raises `NotImplementedError`.
- **Expected**: `NotImplementedError` raised.
- **Evidence**: Interface Description 2.
- **Observe**: `EXCEPTION` → `NotImplementedError`.
- **Target**: `LiveSpan.from_dict`
- **Obligations**: R2
- **Graph**: N3

### C4: LiveSpan.set_span_type stores span type
- **Type**: Behavior
- **Subject**: `LiveSpan.set_span_type("CHAIN")`
- **Relation**: Stores `"CHAIN"` under `SpanAttributeKey.SPAN_TYPE`.
- **Expected**: `span.get_attribute(SpanAttributeKey.SPAN_TYPE) == "CHAIN"`.
- **Evidence**: Interface Description 2.
- **Observe**: `RETURN_VALUE` from `get_attribute`.
- **Target**: `LiveSpan.set_span_type`
- **Obligations**: R3
- **Graph**: N2, E3

### C5: LiveSpan.to_immutable_span returns immutable Span
- **Type**: Behavior
- **Subject**: `live_span.to_immutable_span()`
- **Relation**: Returns `Span` instance (not LiveSpan) with same name and span_id.
- **Expected**: `isinstance(result, Span)` and `not isinstance(result, LiveSpan)`; `result.name == live_span.name`.
- **Evidence**: Interface Description 2.
- **Observe**: `RETURN_VALUE` → isinstance + field comparison.
- **Target**: `LiveSpan.to_immutable_span`
- **Obligations**: R4
- **Graph**: N4

### C6: NoOpSpan.trace_id returns sentinel
- **Type**: Behavior
- **Subject**: `NoOpSpan().trace_id`
- **Relation**: Returns `NO_OP_SPAN_TRACE_ID` constant.
- **Expected**: `NoOpSpan().trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- **Evidence**: Interface Description 2.
- **Observe**: `RETURN_VALUE`.
- **Target**: `NoOpSpan.trace_id`
- **Obligations**: R5
- **Graph**: N5

### C7: NoOpSpan getters return None
- **Type**: Behavior
- **Subject**: `NoOpSpan()` getters (`span_id`, `name`, `start_time_ns`, `end_time_ns`, `status`, `_trace_id`, `parent_id`)
- **Relation**: All return `None`.
- **Expected**: Each getter returns `None`.
- **Evidence**: Interface Description 2.
- **Observe**: `RETURN_VALUE` per getter.
- **Target**: NoOpSpan
- **Obligations**: R5
- **Graph**: N5

### C8: NoOpSpan setters are no-ops
- **Type**: Behavior
- **Subject**: `NoOpSpan().set_inputs({"x": 1})`, `set_outputs(...)`, `set_attributes(...)`, `set_attribute(...)`, `set_status(...)`, `add_event(...)`, `end(...)`
- **Relation**: No exceptions raised.
- **Expected**: All setter calls complete without raising.
- **Evidence**: Interface Description 2.
- **Observe**: No exception on any setter call.
- **Target**: NoOpSpan
- **Obligations**: R5
- **Graph**: N5

### C9: NoOpSpan has record_exception as no-op
- **Type**: Behavior
- **Subject**: `NoOpSpan().record_exception("error")`
- **Relation**: No exception raised.
- **Expected**: Call completes without raising.
- **Evidence**: Compile Checker RT6.
- **Observe**: No exception.
- **Target**: NoOpSpan.record_exception
- **Obligations**: R5
- **Graph**: N5

### C10: Span.attributes returns deserialized dict
- **Type**: Dataflow
- **Subject**: `span.attributes`
- **Relation**: Returns dict where values are JSON-deserialized Python objects.
- **Expected**: All values are original Python types, not JSON strings. System attributes (`mlflow.traceRequestId`, `mlflow.spanType`, `mlflow.spanInputs`, `mlflow.spanOutputs`) coexist with user-set keys.
- **Evidence**: Interface Description 2; Compile Checker RT1.
- **Observe**: `RETURN_VALUE` → type checks on values.
- **Target**: `Span.attributes`
- **Obligations**: R6
- **Graph**: N6, E4, N16

### C11: Span.events returns SpanEvent list
- **Type**: Dataflow
- **Subject**: `span.events`
- **Relation**: Returns `list[SpanEvent]` with plain dict attributes.
- **Expected**: Each element is a `SpanEvent`; `event.attributes` is a plain dict (not BoundedAttributes).
- **Evidence**: Interface Description 2.
- **Observe**: `RETURN_VALUE` → isinstance checks.
- **Target**: `Span.events`
- **Obligations**: R7
- **Graph**: N7

### C12: Span.from_otel_proto constructs valid Span
- **Type**: Dataflow
- **Subject**: `Span.from_otel_proto(otel_proto_span)`
- **Relation**: Returns a Span with name, trace_id, status matching the protobuf input.
- **Expected**: `span.name == otel_proto_span.name`; `span.span_id` is non-empty; attributes are deserialized.
- **Evidence**: Interface Description 2.
- **Observe**: `RETURN_VALUE` → field comparisons.
- **Target**: `Span.from_otel_proto`
- **Obligations**: R8
- **Graph**: N8, E5, E6

### C13: Span.request_id equals trace_id
- **Type**: Behavior
- **Subject**: `span.request_id`
- **Relation**: Returns same value as `span.trace_id`.
- **Expected**: `span.request_id == span.trace_id`.
- **Evidence**: Interface Description 2.
- **Observe**: `RETURN_VALUE` → equality check.
- **Target**: Span.request_id
- **Obligations**: R9
- **Graph**: N9

### C14: Span.span_type returns stored type
- **Type**: Behavior
- **Subject**: `span.span_type`
- **Relation**: Returns attribute value for `SpanAttributeKey.SPAN_TYPE`.
- **Expected**: Matches the span type set during creation.
- **Evidence**: Interface Description 2; Compile Checker RT5.
- **Observe**: `RETURN_VALUE`.
- **Target**: Span.span_type
- **Obligations**: R10
- **Graph**: N10

### C15: Span.to_dict encodes IDs as base64 with correct byte lengths
- **Type**: Dataflow
- **Subject**: `Span.to_dict()`
- **Relation**: trace_id is base64-encoded from 16 big-endian bytes; span_id/parent_span_id from 8 bytes.
- **Expected**: `base64.b64decode(d["trace_id"])` has length 16; `base64.b64decode(d["span_id"])` has length 8.
- **Evidence**: Interface Description 2, detailed encoding spec.
- **Observe**: `RETURN_VALUE` → base64 decode and byte lengths.
- **Target**: `Span.to_dict`
- **Obligations**: R11
- **Graph**: N11, E7, N17, N18, N19

### C16: Span.to_dict produces valid round-trip data
- **Type**: Behavior
- **Subject**: `Span.from_dict(Span.to_dict())`
- **Relation**: A span serialized via `to_dict()` and deserialized via `from_dict()` preserves name, start_time_ns, end_time_ns, status, attributes, events.
- **Expected**: Round-trip fields match.
- **Evidence**: Interface Description 2, both `to_dict` and `from_dict` exist.
- **Observe**: `RETURN_VALUE` → field comparisons.
- **Target**: Span.to_dict / Span.from_dict
- **Obligations**: R11
- **Graph**: N11

### C17: Span.to_otel_proto produces valid protobuf with attribute/status/event/timing fidelity
- **Type**: Dataflow
- **Subject**: `Span.to_otel_proto()`
- **Relation**: Returns an OTelProtoSpan. Must verify: (a) `proto.name == span.name`; (b) `proto.trace_id` is 16 bytes and `proto.span_id` is 8 bytes; (c) `proto.status.code` matches the span's status (OK → STATUS_CODE_OK, ERROR → STATUS_CODE_ERROR); (d) at least one attribute key+value survives a Python→AnyValue→Python round-trip correctly; (e) `len(proto.events)` equals `len(span.events)`; (f) `proto.start_time_unix_nano == span.start_time_ns` and `proto.end_time_unix_nano == span.end_time_ns`.
- **Expected**: All fidelity checks pass.
- **Evidence**: Interface Description 2; Compile Checker Finding 2 (strengthened from original weak structural check).
- **Observe**: `RETURN_VALUE` → field comparisons on protobuf, attribute round-trip via `_decode_otel_proto_anyvalue`.
- **Target**: `Span.to_otel_proto`
- **Obligations**: R12, R16
- **Graph**: N12, E8, E13, N24

### C18: _CachedSpanAttributesRegistry.set raises MlflowException
- **Type**: Failure
- **Subject**: `_CachedSpanAttributesRegistry.set(key, value)`
- **Relation**: Calling `set` raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Expected**: `MlflowException` raised.
- **Evidence**: Interface Description 2, `_CachedSpanAttributesRegistry.set`.
- **Observe**: `EXCEPTION` → `MlflowException`.
- **Target**: `_CachedSpanAttributesRegistry.set`
- **Obligations**: R13
- **Graph**: N13

### C19: create_mlflow_span returns NoOpSpan for None/NonRecordingSpan
- **Type**: Behavior
- **Subject**: `create_mlflow_span(None, "trace-id")` and `create_mlflow_span(NonRecordingSpan(...), "trace-id")`
- **Relation**: Returns `NoOpSpan` instance. Note: the reference implementation uses `if not otel_span` which catches all Python falsy values (None, 0, False, ""). The Interface Description documents only None and NonRecordingSpan. Specs match the reference behavior.
- **Expected**: `isinstance(result, NoOpSpan)`.
- **Evidence**: Interface Description 2, `create_mlflow_span`.
- **Observe**: `RETURN_VALUE` → `isinstance` check.
- **Target**: `create_mlflow_span`
- **Obligations**: R14
- **Graph**: N14, E9

### C20: create_mlflow_span returns LiveSpan for OTelSpan
- **Type**: Behavior
- **Subject**: `create_mlflow_span(otel_span_instance, "trace-id", "LLM")`
- **Relation**: Returns `LiveSpan` instance.
- **Expected**: `isinstance(result, LiveSpan)`.
- **Evidence**: Interface Description 2, `create_mlflow_span`.
- **Observe**: `RETURN_VALUE` → `isinstance` check.
- **Target**: `create_mlflow_span`
- **Obligations**: R14
- **Graph**: N14, E10

### C21: create_mlflow_span returns Span for OTelReadableSpan
- **Type**: Behavior
- **Subject**: `create_mlflow_span(readable_span_instance, "trace-id")`
- **Relation**: Returns `Span` (immutable) instance.
- **Expected**: `isinstance(result, Span) and not isinstance(result, LiveSpan)`.
- **Evidence**: Interface Description 2, `create_mlflow_span`.
- **Observe**: `RETURN_VALUE` → `isinstance` check.
- **Target**: `create_mlflow_span`
- **Obligations**: R14
- **Graph**: N14, E11

### C22: _decode_otel_proto_anyvalue decodes primitives
- **Type**: Dataflow
- **Subject**: `_decode_otel_proto_anyvalue(AnyValue)`
- **Relation**: An AnyValue with `string_value="test"` decodes to `"test"`; `int_value=42` decodes to `42`; `bool_value=True` decodes to `True`; `double_value=3.14` decodes to `3.14`.
- **Expected**: Python primitive matches.
- **Evidence**: Interface Description 3.
- **Observe**: `RETURN_VALUE`.
- **Target**: `_decode_otel_proto_anyvalue`
- **Obligations**: R15
- **Graph**: N15

### C23: _decode_otel_proto_anyvalue decodes arrays recursively
- **Type**: Dataflow
- **Subject**: `_decode_otel_proto_anyvalue(AnyValue with array_value)`
- **Relation**: An AnyValue with `array_value` containing `[int_value=1, string_value="a"]` decodes to `[1, "a"]`.
- **Expected**: List with recursively decoded elements.
- **Evidence**: Interface Description 3.
- **Observe**: `RETURN_VALUE`.
- **Target**: `_decode_otel_proto_anyvalue`
- **Obligations**: R15
- **Graph**: N15

### C24: _decode_otel_proto_anyvalue decodes kvlist recursively
- **Type**: Dataflow
- **Subject**: `_decode_otel_proto_anyvalue(AnyValue with kvlist_value)`
- **Relation**: An AnyValue with `kvlist_value` containing `{key: "x", value: {string_value: "y"}}` decodes to `{"x": "y"}`.
- **Expected**: Dict with recursively decoded values.
- **Evidence**: Interface Description 3.
- **Observe**: `RETURN_VALUE`.
- **Target**: `_decode_otel_proto_anyvalue`
- **Obligations**: R15
- **Graph**: N15

### C25: _decode_otel_proto_anyvalue returns None for unset
- **Type**: Dataflow
- **Subject**: `_decode_otel_proto_anyvalue(empty AnyValue)`
- **Relation**: An AnyValue with no value set returns `None`.
- **Expected**: `result is None`.
- **Evidence**: Interface Description 3.
- **Observe**: `RETURN_VALUE`.
- **Target**: `_decode_otel_proto_anyvalue`
- **Obligations**: R15
- **Graph**: N15

### C26: _decode_otel_proto_anyvalue handles bytes
- **Type**: Dataflow
- **Subject**: `_decode_otel_proto_anyvalue(AnyValue with bytes_value)`
- **Relation**: An AnyValue with `bytes_value=b"hello"` decodes to `b"hello"`.
- **Expected**: Bytes match.
- **Evidence**: Interface Description 3.
- **Observe**: `RETURN_VALUE`.
- **Target**: `_decode_otel_proto_anyvalue`
- **Obligations**: R15
- **Graph**: N15

### C27: create_mlflow_span raises MlflowException for invalid type
- **Type**: Failure
- **Subject**: `create_mlflow_span("invalid", "trace-id")`
- **Relation**: Passing an invalid span type raises `MlflowException`.
- **Expected**: `MlflowException` raised.
- **Evidence**: Interface Description 2, `create_mlflow_span`.
- **Observe**: `EXCEPTION` → `MlflowException`.
- **Target**: `create_mlflow_span`
- **Obligations**: R14
- **Graph**: N14, E12

### C28: SpanStatus.to_otel_proto_status produces valid protobuf status
- **Type**: Dataflow
- **Subject**: `SpanStatus.to_otel_proto_status()`
- **Relation**: Converts SpanStatus to OTelProtoStatus with correct code mapping and message.
- **Expected**: For `SpanStatus(SpanStatusCode.OK)`, `proto.code == STATUS_CODE_OK`; for `SpanStatus(SpanStatusCode.ERROR, "fail")`, `proto.code == STATUS_CODE_ERROR` and `proto.message == "fail"`; for `SpanStatus(SpanStatusCode.UNSET)`, `proto.code == STATUS_CODE_UNSET` and `proto.message == ""`.
- **Evidence**: Compile Checker Finding 1; reference `/testbed/libs/tracing/mlflow/entities/span_status.py` lines 115-130.
- **Observe**: `RETURN_VALUE` → protobuf field checks.
- **Target**: `SpanStatus.to_otel_proto_status`
- **Obligations**: R16
- **Graph**: N24

### C29: SpanStatus.to_otel_status and from_otel_status round-trip
- **Type**: Dataflow
- **Subject**: `SpanStatus.from_otel_status(span_status.to_otel_status())`
- **Relation**: Round-trip through OTel Status preserves status_code and description.
- **Expected**: `result.status_code == original.status_code` and `result.description == original.description`.
- **Evidence**: Compile Checker Finding 1; existing callers at `/testbed/mlflow/entities/span.py` lines 155, 310, 578.
- **Observe**: `RETURN_VALUE` → field comparison.
- **Target**: `SpanStatus.to_otel_status` / `SpanStatus.from_otel_status`
- **Obligations**: R17
- **Graph**: N24 (shared SpanStatus node)
