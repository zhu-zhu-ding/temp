# Compile Checker Agent Skill

This is a durable review rubric for judging IR-to-spec compilation. It is not
task evidence. Preserve the base rubric and append concise, generalizable
lessons after each checker run.

## Base Rubric

1. Requirement completeness: split explicit requirements and native-test
   implications into atomic, non-invented obligations.
2. Repository fidelity: each graph node/edge and fixture comes from a real
   public API, caller, constructor, field, or test-supported path.
3. Contract strength: every contract has a distinguishable wrong implementation
   that its check would fail, not only an import/type/symbol assertion.
4. Observation quality: validate actual arguments, returned fields, state,
   exception semantics, or side effects at the contract target.
5. Compatibility: inspect defaults, signatures, aliases, import/export paths,
   serialization round trips, lifecycle invariants, and existing callers.
6. Collection semantics: inspect cardinality, ordering, deduplication,
   aggregation, and partial-failure survival whenever collections/logs/results
   are involved.
7. Spec execution: each C is referenced, each check is called, and at least one
   check reaches a public entry and a real observer for every R.
8. Req-test synthesis: search for tests from task terms and every relevant
   public entry/module/graph symbol. For each material assertion, preserve a
   short exact code excerpt, its `path::test_name` location, the test lens, and
   the implied contract before judging generated IR/spec coverage. Never claim
   a native-test implication without a real test excerpt, unless explicitly
   marked as task/source-only evidence.
9. Test-lens coverage: classify native tests by API/default/signature,
   dataflow/argument forwarding, lifecycle/state, error/message, side-effect
   count/order, collection cardinality/order/partial success, compatibility/
   round trip, and fixture/object-model fidelity. Judge whether generated specs
   cover the material lenses, not just whether they mention the same symbols.
10. Counterfactual strength: for each important native-test lens, identify the
    smallest plausible regression (wrong default, dropped argument, changed
    branch, reordered/filtered item, altered exception, or fake fixture) and
    require an executable generated check that would fail it. Native tests'
    real construction paths take precedence over dynamically fabricated fields
    or mocks of repository dispatchers.

## Lessons

### L1: Transitive dependencies on non-target types must be traced
When a public entry in the interface (e.g., `Span.to_otel_proto()`) calls a
method on a helper type (e.g., `SpanStatus.to_otel_proto_status()`), the IR
must include that helper method as a graph node and edge. If the target
repository does not yet have the helper method, the spec becomes unexecutable
and the requirement is incompletely lowered. Always trace every method call
inside a required method to its declaring class and verify it exists in both
the reference and target repositories.
— Evidence: Finding 1 (this run); `Span.to_otel_proto` in
`/testbed/libs/tracing/mlflow/entities/span.py:442` calls
`self.status.to_otel_proto_status()` which is missing from
`/testbed/mlflow/entities/span_status.py`.

### L2: Protobuf conversion contracts need attribute/status/event fidelity
A contract that checks only `proto.name == span.name` and non-empty byte IDs
for `to_otel_proto()` is too weak: a wrong implementation that fabricates or
drops attributes, events, and status would pass. Strengthen such contracts to
verify at minimum: (a) status code mapping, (b) one attribute key+value
round-trip, (c) event count, (d) timing nanos.
— Evidence: Finding 2 (this run); C17 in arch and behavior specs.

### L3: Factory-function boundary tests must not encode undocumented truthiness
If the task's interface description enumerates specific input types for a
factory function, a spec check that additionally tests all Python falsy values
(`0`, `False`, `""`) encodes an implementation detail (`if not otel_span`)
rather than the documented contract (`None` + `NonRecordingSpan`). Either
match the documented interface or explicitly note the implementation choice.
— Evidence: Finding 3 (this run); `check_create_mlflow_span_boundaries`.
