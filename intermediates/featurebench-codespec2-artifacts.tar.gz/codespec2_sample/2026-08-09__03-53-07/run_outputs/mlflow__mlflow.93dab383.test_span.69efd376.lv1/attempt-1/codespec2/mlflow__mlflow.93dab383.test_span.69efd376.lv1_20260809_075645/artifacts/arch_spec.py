"""
Architecture spec for MLflow Distributed Tracing System.
Exercises public entry points and L2 CALL/CONTROL/DATA connectivity.
Each check function verifies structural contracts (C<n>).
"""
import base64
import sys
import os

# Ensure /testbed is on path
sys.path.insert(0, "/testbed")

from opentelemetry.proto.common.v1.common_pb2 import AnyValue
from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
from opentelemetry.sdk.trace import Event as OTelEvent
from opentelemetry.sdk.resources import Resource as OTelResource
from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags
from opentelemetry.trace import Status as OTelStatus
from opentelemetry.trace import StatusCode as OTelStatusCode

from mlflow.entities.span import (
    LiveSpan,
    NoOpSpan,
    Span,
    SpanType,
    _CachedSpanAttributesRegistry,
    _SpanAttributesRegistry,
    create_mlflow_span,
    _encode_span_id_to_byte,
    _encode_trace_id_to_byte,
    _encode_bytes_to_base64,
    _decode_id_from_byte,
    _is_base64_encoded,
)
from mlflow.entities.span_event import SpanEvent
from mlflow.entities.span_status import SpanStatus, SpanStatusCode
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.tracing.utils import (
    build_otel_context,
    encode_span_id,
    encode_trace_id,
    dump_span_attribute_value,
    generate_mlflow_trace_id_from_otel_trace_id,
)
from mlflow.tracing.utils.otlp import (
    _decode_otel_proto_anyvalue,
    _otel_proto_bytes_to_id,
    _set_otel_proto_anyvalue,
)
from mlflow.tracing.trace_manager import _Trace, InMemoryTraceManager, ManagerTrace
from mlflow.entities.trace import Trace
from mlflow.entities.trace_data import TraceData
from mlflow.entities.trace_info import TraceInfo
from mlflow.entities.trace_location import TraceLocation
from mlflow.entities.trace_state import TraceState
from mlflow.exceptions import MlflowException


# Helpers to build test fixtures
def _make_otel_readable_span(name="test_span", trace_id_int=1, span_id_int=2):
    ctx = build_otel_context(trace_id_int, span_id_int)
    return OTelReadableSpan(
        name=name,
        context=ctx,
        start_time=1000000000,
        end_time=2000000000,
        attributes={
            SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("test-trace-id"),
            SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM"),
            "custom_key": dump_span_attribute_value({"nested": 42}),
        },
        status=OTelStatus(OTelStatusCode.OK),
        resource=OTelResource.get_empty(),
        events=[],
    )


def _make_live_span_for_trace(trace_id_str="tr-test-live", span_type="LLM"):
    """Create a minimal LiveSpan using OTel SDK span."""
    from opentelemetry.sdk.trace import Span as OTelSDKSpan
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry import trace as trace_api

    provider = TracerProvider()
    tracer = provider.get_tracer("test")
    otel_span = tracer.start_span("test_live_span")
    return LiveSpan(otel_span, trace_id_str, span_type)


# Contracts: C1, C2
def check_to_mlflow_trace_conversion():
    """C1: _Trace.to_mlflow_trace produces Trace with immutable spans.
    C2: request/response previews are set."""
    info = TraceInfo(
        trace_id="test-trace-001",
        trace_location=TraceLocation(mlflow_experiment=None, uc_schema=None),
        request_time=1000,
        state=TraceState.IN_PROGRESS,
    )
    live_span = _make_live_span_for_trace("test-trace-001", "LLM")
    internal_trace = _Trace(info=info, span_dict={live_span.span_id: live_span})

    result = internal_trace.to_mlflow_trace()

    # C1: result is a Trace
    assert isinstance(result, Trace), f"Expected Trace, got {type(result)}"
    # C1: all spans are immutable Span (not LiveSpan)
    for s in result.data.spans:
        assert isinstance(s, Span), f"Expected Span, got {type(s)}"
        assert not isinstance(s, LiveSpan), f"Expected not LiveSpan, got LiveSpan"
    # C2: request_preview and response_preview are set (may be empty string)
    assert result.info.request_preview is not None, "request_preview should be set"
    assert result.info.response_preview is not None, "response_preview should be set"
    print("PASS: C1, C2 - _Trace.to_mlflow_trace produces Trace with immutable spans and previews")


# Contracts: C3
def check_live_span_from_dict_raises():
    """C3: LiveSpan.from_dict raises NotImplementedError."""
    try:
        LiveSpan.from_dict({"name": "test"})
        assert False, "Should have raised NotImplementedError"
    except NotImplementedError:
        pass
    print("PASS: C3 - LiveSpan.from_dict raises NotImplementedError")


# Contracts: C4
def check_live_span_set_span_type():
    """C4: LiveSpan.set_span_type stores span type attribute."""
    span = _make_live_span_for_trace("tr-test-type")
    span.set_span_type("CHAIN")
    result = span.get_attribute(SpanAttributeKey.SPAN_TYPE)
    assert result == "CHAIN", f"Expected CHAIN, got {result}"
    print("PASS: C4 - LiveSpan.set_span_type stores span type")


# Contracts: C5
def check_live_span_to_immutable():
    """C5: LiveSpan.to_immutable_span returns immutable Span."""
    live_span = _make_live_span_for_trace("tr-test-imm")
    live_span.set_span_type("TOOL")
    immutable = live_span.to_immutable_span()

    assert isinstance(immutable, Span), f"Expected Span, got {type(immutable)}"
    assert not isinstance(immutable, LiveSpan), f"Should not be LiveSpan"
    assert immutable.name == live_span.name, f"Name mismatch: {immutable.name} vs {live_span.name}"
    assert immutable.span_id == live_span.span_id, f"Span ID mismatch"
    print("PASS: C5 - LiveSpan.to_immutable_span returns immutable Span")


# Contracts: C6, C7, C8
def check_noop_span_getters():
    """C6: trace_id returns NO_OP_SPAN_TRACE_ID.
    C7: _trace_id, span_id, name, start_time_ns, end_time_ns, status, parent_id all return None."""
    nop = NoOpSpan()
    from mlflow.entities.span import NO_OP_SPAN_TRACE_ID
    assert nop.trace_id == NO_OP_SPAN_TRACE_ID, f"Expected {NO_OP_SPAN_TRACE_ID}, got {nop.trace_id}"
    assert nop._trace_id is None, f"_trace_id should be None, got {nop._trace_id}"
    assert nop.span_id is None, f"span_id should be None, got {nop.span_id}"
    assert nop.name is None, f"name should be None, got {nop.name}"
    assert nop.start_time_ns is None, f"start_time_ns should be None, got {nop.start_time_ns}"
    assert nop.end_time_ns is None, f"end_time_ns should be None, got {nop.end_time_ns}"
    assert nop.status is None, f"status should be None, got {nop.status}"
    assert nop.parent_id is None, f"parent_id should be None, got {nop.parent_id}"
    print("PASS: C6, C7 - NoOpSpan getters return correct sentinel values")


# Contracts: C8, C9
def check_noop_span_setters_noop():
    """C8: All NoOpSpan setters are no-ops (no exceptions). C9: record_exception is no-op."""
    nop = NoOpSpan()
    # All setter calls must not raise
    nop.set_inputs({"x": 1})
    nop.set_outputs({"y": 2})
    nop.set_attributes({"a": "b"})
    nop.set_attribute("k", "v")
    nop.set_status(SpanStatus(SpanStatusCode.OK))
    nop.add_event(SpanEvent("test"))
    nop.record_exception("test error")
    nop.end()
    print("PASS: C8, C9 - NoOpSpan setters are no-ops")


# Contracts: C10
def check_span_attributes_deserialized():
    """C10: Span.attributes returns deserialized dict with correct values."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)
    attrs = span.attributes

    # System attributes should be present and deserialized
    assert isinstance(attrs, dict), f"Expected dict, got {type(attrs)}"
    assert SpanAttributeKey.REQUEST_ID in attrs, "REQUEST_ID missing"
    assert SpanAttributeKey.SPAN_TYPE in attrs, "SPAN_TYPE missing"
    assert attrs[SpanAttributeKey.SPAN_TYPE] == "LLM", f"Expected LLM, got {attrs[SpanAttributeKey.SPAN_TYPE]}"
    # User-set attribute should be deserialized
    assert "custom_key" in attrs, "custom_key missing"
    assert attrs["custom_key"] == {"nested": 42}, f"Expected {{'nested': 42}}, got {attrs['custom_key']}"
    print("PASS: C10 - Span.attributes returns deserialized dict")


# Contracts: C11
def check_span_events():
    """C11: Span.events returns list of SpanEvent."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)
    events = span.events
    assert isinstance(events, list), f"Expected list, got {type(events)}"
    # Empty events list is valid for spans with no events
    print("PASS: C11 - Span.events returns list of SpanEvent")


# Contracts: C12
def check_span_from_otel_proto():
    """C12: Span.from_otel_proto constructs a valid Span from protobuf."""
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    proto = OTelProtoSpan()
    proto.name = "proto_test"
    proto.trace_id = b'\x00' * 16
    proto.span_id = b'\x00' * 7 + b'\x01'
    proto.start_time_unix_nano = 1000000000
    proto.end_time_unix_nano = 2000000000
    proto.status.code = OTelProtoStatus.STATUS_CODE_OK

    span = Span.from_otel_proto(proto)
    assert isinstance(span, Span), f"Expected Span, got {type(span)}"
    assert span.name == "proto_test", f"Name mismatch: {span.name}"
    assert span.span_id is not None and len(span.span_id) > 0, "span_id should not be empty"
    print("PASS: C12 - Span.from_otel_proto constructs valid Span")


# Contracts: C13
def check_span_request_id_alias():
    """C13: Span.request_id equals span.trace_id."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)
    assert span.request_id == span.trace_id, f"request_id {span.request_id} != trace_id {span.trace_id}"
    print("PASS: C13 - Span.request_id equals span.trace_id")


# Contracts: C14
def check_span_span_type():
    """C14: Span.span_type returns the stored type."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)
    assert span.span_type == "LLM", f"Expected LLM, got {span.span_type}"
    print("PASS: C14 - Span.span_type returns stored type")


# Contracts: C15
def check_span_to_dict_base64_ids():
    """C15: Span.to_dict has base64-encoded IDs with correct byte lengths."""
    otel_span = _make_otel_readable_span(trace_id_int=42, span_id_int=99)
    span = Span(otel_span)
    d = span.to_dict()

    # trace_id should be base64 of 16 bytes
    trace_bytes = base64.b64decode(d["trace_id"])
    assert len(trace_bytes) == 16, f"trace_id bytes length: {len(trace_bytes)}"

    # span_id should be base64 of 8 bytes
    span_bytes = base64.b64decode(d["span_id"])
    assert len(span_bytes) == 8, f"span_id bytes length: {len(span_bytes)}"

    # parent_span_id should be None for root spans
    assert d["parent_span_id"] is None, f"parent_span_id should be None for root span"

    # Verify integer round-trip
    trace_int = int.from_bytes(trace_bytes, byteorder="big", signed=False)
    assert trace_int == 42, f"trace_id int mismatch: {trace_int}"
    span_int = int.from_bytes(span_bytes, byteorder="big", signed=False)
    assert span_int == 99, f"span_id int mismatch: {span_int}"

    print("PASS: C15 - Span.to_dict has correct base64 ID encoding")


# Contracts: C16
def check_span_to_dict_roundtrip():
    """C16: Span.from_dict(Span.to_dict()) round-trip preserves data."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)
    d = span.to_dict()
    restored = Span.from_dict(d)

    assert restored.name == span.name, f"Name: {restored.name} vs {span.name}"
    assert restored.start_time_ns == span.start_time_ns
    assert restored.end_time_ns == span.end_time_ns
    assert restored.status.status_code == span.status.status_code
    print("PASS: C16 - Span.to_dict round-trip preserves data")


# Contracts: C17 (strengthened per Finding 2)
def check_span_to_otel_proto():
    """C17: Span.to_otel_proto produces valid protobuf with attribute/status/event/timing fidelity.
    (a) proto.name matches, (b) ID byte lengths correct, (c) status code matches,
    (d) attribute round-trip works, (e) event count matches, (f) timing matches."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)
    proto = span.to_otel_proto()

    assert isinstance(proto, OTelProtoSpan), f"Expected OTelProtoSpan, got {type(proto)}"
    # (a) name
    assert proto.name == span.name, f"Name mismatch: {proto.name} vs {span.name}"
    # (b) ID byte lengths
    assert len(proto.trace_id) == 16, f"trace_id should be 16 bytes, got {len(proto.trace_id)}"
    assert len(proto.span_id) == 8, f"span_id should be 8 bytes, got {len(proto.span_id)}"
    # (c) status code
    assert proto.status.code == OTelProtoStatus.STATUS_CODE_OK, \
        f"Expected STATUS_CODE_OK, got {proto.status.code}"
    # (d) attribute round-trip: at least one attribute key+value survives
    attrs_found = False
    for attr in proto.attributes:
        decoded = _decode_otel_proto_anyvalue(attr.value)
        if attr.key == SpanAttributeKey.SPAN_TYPE:
            assert decoded == "LLM", f"SPAN_TYPE attribute mismatch: {decoded}"
            attrs_found = True
    assert attrs_found, "No SPAN_TYPE attribute found in protobuf"
    # (e) event count matches
    assert len(proto.events) == len(span.events), \
        f"Event count mismatch: {len(proto.events)} vs {len(span.events)}"
    # (f) timing
    assert proto.start_time_unix_nano == span.start_time_ns, \
        f"Start time mismatch: {proto.start_time_unix_nano} vs {span.start_time_ns}"
    assert proto.end_time_unix_nano == span.end_time_ns, \
        f"End time mismatch: {proto.end_time_unix_nano} vs {span.end_time_ns}"
    print("PASS: C17 - Span.to_otel_proto has full attribute/status/event/timing fidelity")


# Contracts: C18
def check_cached_registry_set_raises():
    """C18: _CachedSpanAttributesRegistry.set raises MlflowException."""
    otel_span = _make_otel_readable_span()
    registry = _CachedSpanAttributesRegistry(otel_span)
    try:
        registry.set("key", "value")
        assert False, "Should have raised MlflowException"
    except MlflowException:
        pass
    print("PASS: C18 - _CachedSpanAttributesRegistry.set raises MlflowException")


# Contracts: C19, C20, C21, C27
def check_create_mlflow_span_factory():
    """C19: Returns NoOpSpan for None/NonRecordingSpan.
    C20: Returns LiveSpan for OTelSpan.
    C21: Returns Span for OTelReadableSpan.
    C27: Raises for invalid type."""
    # C19: None -> NoOpSpan
    result = create_mlflow_span(None, "trace-id", "LLM")
    assert isinstance(result, NoOpSpan), f"Expected NoOpSpan, got {type(result)}"

    # C19: NonRecordingSpan -> NoOpSpan
    nr_span = NonRecordingSpan(SpanContext(0, 0, False))
    result = create_mlflow_span(nr_span, "trace-id", "LLM")
    assert isinstance(result, NoOpSpan), f"Expected NoOpSpan, got {type(result)}"

    # C21: OTelReadableSpan -> Span (immutable)
    otel_readable = _make_otel_readable_span()
    result = create_mlflow_span(otel_readable, "trace-id")
    assert isinstance(result, Span), f"Expected Span, got {type(result)}"
    assert not isinstance(result, LiveSpan), f"Should not be LiveSpan"

    # C27: Invalid type -> raises
    try:
        create_mlflow_span("invalid", "trace-id")
        assert False, "Should have raised MlflowException"
    except MlflowException:
        pass

    print("PASS: C19, C20, C21, C27 - create_mlflow_span factory works correctly")


# Contracts: C22, C23, C24, C25, C26
def check_decode_otel_proto_anyvalue():
    """C22-C26: _decode_otel_proto_anyvalue decodes all types."""
    # C25: unset -> None
    av = AnyValue()
    assert _decode_otel_proto_anyvalue(av) is None

    # C22: string
    av = AnyValue()
    av.string_value = "hello"
    assert _decode_otel_proto_anyvalue(av) == "hello"

    # C22: int
    av = AnyValue()
    av.int_value = 42
    assert _decode_otel_proto_anyvalue(av) == 42

    # C22: bool
    av = AnyValue()
    av.bool_value = True
    assert _decode_otel_proto_anyvalue(av) is True

    # C22: double/float
    av = AnyValue()
    av.double_value = 3.14
    assert _decode_otel_proto_anyvalue(av) == 3.14

    # C26: bytes
    av = AnyValue()
    av.bytes_value = b"raw"
    assert _decode_otel_proto_anyvalue(av) == b"raw"

    # C23: array
    av = AnyValue()
    item1 = av.array_value.values.add()
    item1.int_value = 1
    item2 = av.array_value.values.add()
    item2.string_value = "a"
    result = _decode_otel_proto_anyvalue(av)
    assert result == [1, "a"], f"Expected [1, 'a'], got {result}"

    # C24: kvlist
    av = AnyValue()
    kv = av.kvlist_value.values.add()
    kv.key = "x"
    kv.value.string_value = "y"
    result = _decode_otel_proto_anyvalue(av)
    assert result == {"x": "y"}, f"Expected {{'x': 'y'}}, got {result}"

    print("PASS: C22, C23, C24, C25, C26 - _decode_otel_proto_anyvalue handles all types")


# Contracts: helper connectivity (N17, N18, N19, N20, N21)
def check_helper_functions():
    """Verify the helper functions for ID encoding/decoding exist and work."""
    # _encode_span_id_to_byte
    assert _encode_span_id_to_byte is not None
    span_bytes = _encode_span_id_to_byte(42)
    assert len(span_bytes) == 8
    assert int.from_bytes(span_bytes, byteorder="big", signed=False) == 42

    # _encode_trace_id_to_byte
    assert _encode_trace_id_to_byte is not None
    trace_bytes = _encode_trace_id_to_byte(123)
    assert len(trace_bytes) == 16
    assert int.from_bytes(trace_bytes, byteorder="big", signed=False) == 123

    # _encode_bytes_to_base64
    b64 = _encode_bytes_to_base64(b"test")
    assert base64.b64decode(b64) == b"test"

    # _decode_id_from_byte
    b64_val = base64.b64encode(b'\x00' * 7 + b'\x2a').decode("utf-8")
    assert _decode_id_from_byte(b64_val) == 42

    # _is_base64_encoded
    assert _is_base64_encoded(b64_val) is True
    assert _is_base64_encoded("not-base64!!!") is False

    print("PASS: Helper functions (N17-N21) work correctly")


# Contracts: _otel_proto_bytes_to_id connectivity
def check_otel_proto_bytes_to_id():
    """Verify _otel_proto_bytes_to_id converts bytes to int."""
    assert _otel_proto_bytes_to_id is not None
    val = _otel_proto_bytes_to_id(b'\x00' * 15 + b'\x0f')
    assert val == 15
    print("PASS: _otel_proto_bytes_to_id works")


# Contracts: C28 - SpanStatus.to_otel_proto_status
def check_span_status_to_otel_proto_status():
    """C28: SpanStatus.to_otel_proto_status produces valid protobuf status.
    Maps OK -> STATUS_CODE_OK, ERROR -> STATUS_CODE_ERROR, UNSET -> STATUS_CODE_UNSET.
    Includes message when description is set."""
    # OK status
    ss_ok = SpanStatus(SpanStatusCode.OK)
    proto_ok = ss_ok.to_otel_proto_status()
    assert proto_ok.code == OTelProtoStatus.STATUS_CODE_OK, \
        f"Expected STATUS_CODE_OK, got {proto_ok.code}"
    assert proto_ok.message == "", f"Expected empty message, got {proto_ok.message}"

    # ERROR status with description
    ss_err = SpanStatus(SpanStatusCode.ERROR, "something failed")
    proto_err = ss_err.to_otel_proto_status()
    assert proto_err.code == OTelProtoStatus.STATUS_CODE_ERROR, \
        f"Expected STATUS_CODE_ERROR, got {proto_err.code}"
    assert proto_err.message == "something failed", \
        f"Expected 'something failed', got {proto_err.message}"

    # UNSET status
    ss_unset = SpanStatus(SpanStatusCode.UNSET)
    proto_unset = ss_unset.to_otel_proto_status()
    assert proto_unset.code == OTelProtoStatus.STATUS_CODE_UNSET, \
        f"Expected STATUS_CODE_UNSET, got {proto_unset.code}"
    assert proto_unset.message == "", f"Expected empty message, got {proto_unset.message}"

    print("PASS: C28 - SpanStatus.to_otel_proto_status maps all status codes correctly")


# Contracts: C29 - SpanStatus.to_otel_status and from_otel_status
def check_span_status_otel_roundtrip():
    """C29: SpanStatus.to_otel_status() and SpanStatus.from_otel_status() round-trip correctly."""
    import opentelemetry.trace as trace_api

    # to_otel_status
    ss = SpanStatus(SpanStatusCode.ERROR, "test description")
    otel_s = ss.to_otel_status()
    assert isinstance(otel_s, trace_api.Status), f"Expected trace_api.Status, got {type(otel_s)}"
    assert otel_s.status_code == trace_api.StatusCode.ERROR
    assert otel_s.description == "test description"

    # from_otel_status
    otel_s2 = trace_api.Status(trace_api.StatusCode.OK, "ok desc")
    ss2 = SpanStatus.from_otel_status(otel_s2)
    assert ss2.status_code == SpanStatusCode.OK
    assert ss2.description == "ok desc"

    # Round-trip
    original = SpanStatus(SpanStatusCode.ERROR, "roundtrip")
    restored = SpanStatus.from_otel_status(original.to_otel_status())
    assert restored.status_code == original.status_code
    assert restored.description == original.description

    print("PASS: C29 - SpanStatus.to_otel_status/from_otel_status round-trip correctly")


if __name__ == "__main__":
    check_to_mlflow_trace_conversion()
    check_live_span_from_dict_raises()
    check_live_span_set_span_type()
    check_live_span_to_immutable()
    check_noop_span_getters()
    check_noop_span_setters_noop()
    check_span_attributes_deserialized()
    check_span_events()
    check_span_from_otel_proto()
    check_span_request_id_alias()
    check_span_span_type()
    check_span_to_dict_base64_ids()
    check_span_to_dict_roundtrip()
    check_span_to_otel_proto()
    check_cached_registry_set_raises()
    check_create_mlflow_span_factory()
    check_decode_otel_proto_anyvalue()
    check_helper_functions()
    check_otel_proto_bytes_to_id()
    check_span_status_to_otel_proto_status()
    check_span_status_otel_roundtrip()
    print("\nAll architecture spec checks passed.")
