"""
Behavior spec for MLflow Distributed Tracing System.
Exercises outcomes, state, failure, side effects, defaults, boundaries,
and compatibility.
Each check function targets specific contracts (C<n>).
"""
import base64
import json
import sys
import os

sys.path.insert(0, "/testbed")

from opentelemetry.proto.common.v1.common_pb2 import AnyValue
from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
from opentelemetry.sdk.trace import Event as OTelEvent
from opentelemetry.sdk.resources import Resource as OTelResource
from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags
from opentelemetry.trace import Status as OTelStatus
from opentelemetry.trace import StatusCode as OTelStatusCode

from mlflow.entities.span import (
    LiveSpan,
    NoOpSpan,
    Span,
    SpanType,
    _CachedSpanAttributesRegistry,
    _SpanAttributesRegistry,
    create_mlflow_span,
    NO_OP_SPAN_TRACE_ID,
)
from mlflow.entities.span_event import SpanEvent
from mlflow.entities.span_status import SpanStatus, SpanStatusCode
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.tracing.utils import (
    build_otel_context,
    encode_span_id,
    dump_span_attribute_value,
)
from mlflow.tracing.utils.otlp import (
    _decode_otel_proto_anyvalue,
    _set_otel_proto_anyvalue,
)
from mlflow.tracing.trace_manager import _Trace
from mlflow.entities.trace_info import TraceInfo
from mlflow.entities.trace_location import TraceLocation
from mlflow.entities.trace_state import TraceState
from mlflow.entities import LiveSpan as LiveSpanEntity
from mlflow.exceptions import MlflowException


def _make_otel_readable_span(name="test_span", trace_id_int=1, span_id_int=2,
                              attributes=None, status_code=OTelStatusCode.OK,
                              events=None, parent_span_id=None):
    ctx = build_otel_context(trace_id_int, span_id_int)
    parent = build_otel_context(trace_id_int, parent_span_id) if parent_span_id else None
    if attributes is None:
        attributes = {
            SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("test-trace-id"),
            SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM"),
        }
    return OTelReadableSpan(
        name=name,
        context=ctx,
        parent=parent,
        start_time=1000000000,
        end_time=2000000000,
        attributes=attributes,
        status=OTelStatus(status_code),
        resource=OTelResource.get_empty(),
        events=events or [],
    )


def _make_live_span():
    from opentelemetry.sdk.trace import TracerProvider
    provider = TracerProvider()
    tracer = provider.get_tracer("test")
    otel_span = tracer.start_span("test_live")
    return LiveSpan(otel_span, "tr-live-test", SpanType.UNKNOWN)


# Contracts: C1, C2 - Trace conversion with multiple spans
def check_to_mlflow_trace_multiple_spans():
    """C1: Multiple LiveSpans all converted to immutable Spans.
    C2: Preview fields are populated."""
    info = TraceInfo(
        trace_id="test-trace-multi",
        trace_location=TraceLocation(mlflow_experiment=None, uc_schema=None),
        request_time=1000,
        state=TraceState.IN_PROGRESS,
    )
    span1 = _make_live_span()
    span2 = _make_live_span()

    internal = _Trace(info=info, span_dict={
        span1.span_id: span1,
        span2.span_id: span2,
    })
    trace = internal.to_mlflow_trace()

    assert len(trace.data.spans) == 2, f"Expected 2 spans, got {len(trace.data.spans)}"
    for s in trace.data.spans:
        assert not isinstance(s, LiveSpan), "All spans should be immutable"
    assert trace.info.request_preview is not None
    assert trace.info.response_preview is not None
    print("PASS: C1, C2 - Multiple spans converted, previews populated")


# Contracts: C3 - LiveSpan.from_dict error message
def check_live_span_from_dict_error():
    """C3: LiveSpan.from_dict raises NotImplementedError with meaningful message."""
    try:
        LiveSpan.from_dict({"name": "x", "attributes": {}})
        assert False, "Should raise"
    except NotImplementedError as e:
        assert "from_dict" in str(e).lower() or "not supported" in str(e).lower(), \
            f"Unexpected message: {e}"
    print("PASS: C3 - LiveSpan.from_dict raises with meaningful message")


# Contracts: C4 - LiveSpan.set_span_type multiple calls and custom types
def check_live_span_set_span_type_override():
    """C4: Setting span type multiple times overwrites previous value."""
    span = _make_live_span()
    span.set_span_type("LLM")
    assert span.get_attribute(SpanAttributeKey.SPAN_TYPE) == "LLM"
    span.set_span_type("CUSTOM_TYPE")
    assert span.get_attribute(SpanAttributeKey.SPAN_TYPE) == "CUSTOM_TYPE"
    print("PASS: C4 - set_span_type overwrites correctly")


# Contracts: C5 - to_immutable_span preserves attributes and events
def check_to_immutable_span_preserves_data():
    """C5: Immutable span preserves attributes, inputs, outputs, events."""
    span = _make_live_span()
    span.set_inputs({"query": "hello"})
    span.set_outputs({"answer": "world"})
    span.set_attributes({"custom": 123})
    span.add_event(SpanEvent("test_event", attributes={"k": "v"}))
    span.set_status(SpanStatus(SpanStatusCode.OK))

    imm = span.to_immutable_span()
    assert imm.inputs == {"query": "hello"}, f"Inputs: {imm.inputs}"
    assert imm.outputs == {"answer": "world"}, f"Outputs: {imm.outputs}"
    assert imm.get_attribute("custom") == 123
    assert imm.status.status_code == SpanStatusCode.OK
    assert len(imm.events) >= 1
    print("PASS: C5 - to_immutable_span preserves all data")


# Contracts: C6-C9 - NoOpSpan complete interface
def check_noop_span_complete_interface():
    """C6-C9: NoOpSpan has complete interface matching Span."""
    nop = NoOpSpan()
    # All getters
    assert nop.trace_id == NO_OP_SPAN_TRACE_ID, f"trace_id: {nop.trace_id}"
    assert nop._trace_id is None
    assert nop.span_id is None
    assert nop.name is None
    assert nop.start_time_ns is None
    assert nop.end_time_ns is None
    assert nop.status is None
    assert nop.parent_id is None

    # All setters are no-ops
    nop.set_inputs({"x": 1})
    nop.set_outputs({"y": 2})
    nop.set_attributes({"a": 1})
    nop.set_attribute("b", 2)
    nop.set_status(SpanStatus(SpanStatusCode.ERROR))
    nop.add_event(SpanEvent("ev"))
    nop.record_exception(Exception("test"))
    nop.end(outputs={"out": 1}, attributes={"at": 2}, status="OK")

    # Verify no state is accrued
    assert nop.trace_id == NO_OP_SPAN_TRACE_ID
    print("PASS: C6-C9 - NoOpSpan complete interface works")


# Contracts: C10 - Span attributes caching (immutable spans cache results)
def check_span_attributes_caching():
    """C10: Span.attributes uses _CachedSpanAttributesRegistry which caches reads."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)

    attrs1 = span.attributes
    attrs2 = span.attributes
    assert attrs1 == attrs2, "Cached attributes should be equal"
    assert attrs1[SpanAttributeKey.SPAN_TYPE] == "LLM"
    print("PASS: C10 - Span.attributes caching works")


# Contracts: C11 - Span.events with data
def check_span_events_with_data():
    """C11: Span.events correctly processes events with attributes."""
    otel_events = [
        OTelEvent(
            name="event_1",
            timestamp=1234567890,
            attributes={"key1": "value1", "key2": 42},
        )
    ]
    otel_span = _make_otel_readable_span(events=otel_events)
    span = Span(otel_span)
    events = span.events

    assert len(events) == 1, f"Expected 1 event, got {len(events)}"
    assert events[0].name == "event_1", f"Event name: {events[0].name}"
    assert events[0].timestamp == 1234567890
    # attributes should be a plain dict
    assert isinstance(events[0].attributes, dict), \
        f"Expected dict, got {type(events[0].attributes)}"
    print("PASS: C11 - Span.events processes events with attributes")


# Contracts: C12 - from_otel_proto with location_id
def check_from_otel_proto_with_location():
    """C12: Span.from_otel_proto with location_id generates v4 trace ID."""
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    proto = OTelProtoSpan()
    proto.name = "location_test"
    proto.trace_id = b'\x00' * 16
    proto.span_id = b'\x00' * 7 + b'\x01'
    proto.start_time_unix_nano = 1000000000
    proto.end_time_unix_nano = 2000000000
    proto.status.code = OTelProtoStatus.STATUS_CODE_OK

    span = Span.from_otel_proto(proto, location_id="LOC123")
    assert isinstance(span, Span)
    assert span.name == "location_test"
    # With location_id, trace_id should contain the location
    assert span.trace_id is not None and len(span.trace_id) > 0
    print("PASS: C12 - from_otel_proto with location_id works")


# Contracts: C13 - request_id backward compatibility
def check_request_id_backward_compat():
    """C13: Span.request_id is an alias for trace_id."""
    otel_span = _make_otel_readable_span()
    span = Span(otel_span)
    assert span.request_id == span.trace_id
    assert span.request_id is not None
    print("PASS: C13 - request_id backward compatibility")


# Contracts: C14 - span_type edge cases (UNKNOWN, custom)
def check_span_type_edge_cases():
    """C14: Span.span_type handles UNKNOWN and custom types."""
    # UNKNOWN span type
    attrs_unknown = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tid-unk"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("UNKNOWN"),
    }
    otel_span = _make_otel_readable_span(attributes=attrs_unknown)
    span = Span(otel_span)
    assert span.span_type == "UNKNOWN"

    # Custom type
    attrs_custom = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tid-cust"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("CUSTOM_OPERATION"),
    }
    otel_span2 = _make_otel_readable_span(attributes=attrs_custom)
    span2 = Span(otel_span2)
    assert span2.span_type == "CUSTOM_OPERATION"
    print("PASS: C14 - span_type handles edge cases")


# Contracts: C15, C16 - Full round-trip with events, status, complex attributes
def check_to_dict_from_dict_full_roundtrip():
    """C15, C16: Full round-trip through to_dict/from_dict preserves all data."""
    from mlflow.tracing.utils import encode_span_id, encode_trace_id
    otel_events = [
        OTelEvent(name="ev1", timestamp=1111111111, attributes={"a": "b"}),
    ]
    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("full-roundtrip-tid"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("CHAIN"),
        SpanAttributeKey.INPUTS: dump_span_attribute_value({"x": 1}),
        SpanAttributeKey.OUTPUTS: dump_span_attribute_value({"y": 2}),
        "custom_str": dump_span_attribute_value("hello"),
        "custom_int": dump_span_attribute_value(42),
        "custom_list": dump_span_attribute_value([1, 2, 3]),
    }
    otel_span = _make_otel_readable_span(
        name="roundtrip_span",
        attributes=attrs,
        events=otel_events,
        status_code=OTelStatusCode.ERROR,
    )
    span = Span(otel_span)
    d = span.to_dict()
    restored = Span.from_dict(d)

    # Basic fields
    assert restored.name == "roundtrip_span"
    assert restored.start_time_ns == 1000000000
    assert restored.end_time_ns == 2000000000
    # Status
    assert restored.status.status_code == SpanStatusCode.ERROR
    # Events
    assert len(restored.events) == 1
    assert restored.events[0].name == "ev1"
    # Complex attributes
    assert restored.attributes.get("custom_str") == "hello"
    assert restored.attributes.get("custom_int") == 42
    assert restored.attributes.get("custom_list") == [1, 2, 3]
    print("PASS: C15, C16 - Full round-trip with events, status, complex attributes")


# Contracts: C17 (strengthened per Finding 2) - to_otel_proto with parent and full fidelity
def check_to_otel_proto_with_parent():
    """C17: to_otel_proto includes parent_span_id, and has full
    attribute/status/event/timing fidelity:
    (a) name matches, (b) ID byte lengths, (c) status code,
    (d) attribute round-trip, (e) event count, (f) timing."""
    # Build a span with events and a parent to test full fidelity
    otel_events = [
        OTelEvent(name="ev1", timestamp=1500000000, attributes={"key": "val"}),
    ]
    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("fid-tid"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("TOOL"),
        "model_name": dump_span_attribute_value("test-model"),
        "custom.attribute": dump_span_attribute_value("test-value"),
    }
    otel_span = _make_otel_readable_span(
        name="fidelity_span",
        trace_id_int=0xABCDEF,
        span_id_int=0x12345678AB,
        parent_span_id=99,
        attributes=attrs,
        events=otel_events,
        status_code=OTelStatusCode.OK,
    )
    span = Span(otel_span)
    proto = span.to_otel_proto()

    # (a) name
    assert proto.name == "fidelity_span", f"Name mismatch: {proto.name}"

    # (b) ID byte lengths
    assert len(proto.trace_id) == 16, f"Trace ID should be 16 bytes, got {len(proto.trace_id)}"
    assert len(proto.span_id) == 8, f"Span ID should be 8 bytes, got {len(proto.span_id)}"
    if span.parent_id:
        assert len(proto.parent_span_id) == 8, \
            f"Parent span ID should be 8 bytes, got {len(proto.parent_span_id)}"

    # (c) status code
    assert proto.status.code == OTelProtoStatus.STATUS_CODE_OK, \
        f"Expected STATUS_CODE_OK, got {proto.status.code}"

    # (d) attribute round-trip: decode at least one attribute
    decoded_attrs = {}
    for attr in proto.attributes:
        decoded_attrs[attr.key] = _decode_otel_proto_anyvalue(attr.value)
    assert decoded_attrs.get("model_name") == "test-model", \
        f"model_name attribute mismatch: {decoded_attrs.get('model_name')}"
    assert decoded_attrs.get("custom.attribute") == "test-value", \
        f"custom.attribute mismatch: {decoded_attrs.get('custom.attribute')}"

    # (e) event count
    assert len(proto.events) == len(span.events), \
        f"Event count mismatch: {len(proto.events)} vs {len(span.events)}"

    # (f) timing
    assert proto.start_time_unix_nano == span.start_time_ns, \
        f"Start time mismatch: {proto.start_time_unix_nano} vs {span.start_time_ns}"
    assert proto.end_time_unix_nano == span.end_time_ns, \
        f"End time mismatch: {proto.end_time_unix_nano} vs {span.end_time_ns}"

    print("PASS: C17 - to_otel_proto with parent and full attribute/status/event/timing fidelity")


# Contracts: C18 - _CachedSpanAttributesRegistry immutability
def check_cached_registry_immutability():
    """C18: Cached registry rejects all mutation attempts."""
    otel_span = _make_otel_readable_span()
    reg = _CachedSpanAttributesRegistry(otel_span)

    try:
        reg.set("anything", "value")
        assert False, "Should raise"
    except MlflowException as e:
        from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
        assert e.error_code == INVALID_PARAMETER_VALUE
    print("PASS: C18 - Cached registry rejects mutations")


# Contracts: C19 - create_mlflow_span with falsy values
# NOTE: The reference implementation uses `if not otel_span` which catches all Python
# falsy values (None, 0, False, ""). The Interface Description 2 documents only None
# and NonRecordingSpan. This test matches the reference behavior, which is an
# implementation choice, not a documented contract.
def check_create_mlflow_span_boundaries():
    """C19: Empty string, 0, False all treated as falsy -> NoOpSpan.
    This matches the reference implementation's `if not otel_span` guard."""
    for falsy in [None, 0, False, ""]:
        result = create_mlflow_span(falsy, "tid")
        assert isinstance(result, NoOpSpan), \
            f"Expected NoOpSpan for {falsy!r}, got {type(result)}"
    print("PASS: C19 - create_mlflow_span handles falsy values (matching reference behavior)")


# Contracts: C20 - LiveSpan from create_mlflow_span has proper attributes
def check_create_mlflow_span_live_span_attrs():
    """C20: LiveSpan from factory has REQUEST_ID and SPAN_TYPE set."""
    from opentelemetry.sdk.trace import TracerProvider
    provider = TracerProvider()
    tracer = provider.get_tracer("test")
    otel_span = tracer.start_span("factory_test")

    span = create_mlflow_span(otel_span, "my-trace-id", "CHAIN")
    assert isinstance(span, LiveSpan)
    assert span.get_attribute(SpanAttributeKey.REQUEST_ID) == "my-trace-id"
    assert span.get_attribute(SpanAttributeKey.SPAN_TYPE) == "CHAIN"
    print("PASS: C20 - create_mlflow_span LiveSpan has proper attrs")


# Contracts: C22-C26 - _decode_otel_proto_anyvalue nested structures
def check_decode_otel_proto_nested():
    """C22-C26: Nested array/kvlist structures decode correctly."""
    # Nested array inside kvlist
    av = AnyValue()
    kv = av.kvlist_value.values.add()
    kv.key = "nested_array"
    inner_arr = kv.value.array_value
    item1 = inner_arr.values.add()
    item1.int_value = 1
    item2 = inner_arr.values.add()
    item2.string_value = "two"

    result = _decode_otel_proto_anyvalue(av)
    assert result == {"nested_array": [1, "two"]}

    # Empty array
    av = AnyValue()
    _ = av.array_value  # just access to create empty array
    result = _decode_otel_proto_anyvalue(av)
    assert result == []

    # Empty kvlist
    av = AnyValue()
    _ = av.kvlist_value  # access to create empty kvlist
    result = _decode_otel_proto_anyvalue(av)
    assert result == {}

    print("PASS: C22-C26 - Nested and empty structures decode correctly")


# Contracts: Trace state transitions
def check_trace_lifecycle_state_transitions():
    """Verify trace lifecycle: live spans added, then converted to immutable."""
    info = TraceInfo(
        trace_id="lifecycle-test",
        trace_location=TraceLocation(mlflow_experiment=None, uc_schema=None),
        request_time=1000,
        state=TraceState.IN_PROGRESS,
    )
    span = _make_live_span()
    internal = _Trace(info=info, span_dict={span.span_id: span})

    # Before conversion: span in span_dict is LiveSpan
    assert isinstance(internal.span_dict[span.span_id], LiveSpan)

    # After conversion: returned trace has immutable spans
    trace = internal.to_mlflow_trace()
    for s in trace.data.spans:
        assert not isinstance(s, LiveSpan)
        assert isinstance(s, Span)

    print("PASS: Trace lifecycle state transitions work")


# Contracts: Span.to_dict encoding scheme matches spec exactly
def check_to_dict_encoding_scheme():
    """C15: Verify exact encoding: int->bytes(big-endian)->base64."""
    otel_span = _make_otel_readable_span(trace_id_int=0xABCDEF, span_id_int=0x12345678AB)
    span = Span(otel_span)
    d = span.to_dict()

    # Decode trace_id: base64 -> bytes -> int
    trace_bytes = base64.b64decode(d["trace_id"])
    trace_int = int.from_bytes(trace_bytes, byteorder="big", signed=False)
    # Decode span_id: base64 -> bytes -> int
    span_bytes = base64.b64decode(d["span_id"])
    span_int = int.from_bytes(span_bytes, byteorder="big", signed=False)

    assert trace_int == 0xABCDEF, f"Trace ID mismatch: {trace_int}"
    assert span_int == 0x12345678AB, f"Span ID mismatch: {span_int}"
    print("PASS: C15 - Encoding scheme matches spec (int->bytes->base64)")


# Contracts: C28 - SpanStatus.to_otel_proto_status round-trip
def check_span_status_proto_roundtrip():
    """C28: SpanStatus.to_otel_proto_status() and from_otel_proto_status() round-trip."""
    # to_otel_proto_status -> from_otel_proto_status round-trip
    original = SpanStatus(SpanStatusCode.ERROR, "round-trip error")
    proto = original.to_otel_proto_status()
    restored = SpanStatus.from_otel_proto_status(proto)
    assert restored.status_code == original.status_code, \
        f"Status code mismatch: {restored.status_code} vs {original.status_code}"
    assert restored.description == original.description, \
        f"Description mismatch: {restored.description} vs {original.description}"

    # OK status
    original_ok = SpanStatus(SpanStatusCode.OK)
    proto_ok = original_ok.to_otel_proto_status()
    restored_ok = SpanStatus.from_otel_proto_status(proto_ok)
    assert restored_ok.status_code == SpanStatusCode.OK
    assert restored_ok.description == ""

    # UNSET status
    original_unset = SpanStatus(SpanStatusCode.UNSET)
    proto_unset = original_unset.to_otel_proto_status()
    restored_unset = SpanStatus.from_otel_proto_status(proto_unset)
    assert restored_unset.status_code == SpanStatusCode.UNSET

    print("PASS: C28 - SpanStatus.to_otel_proto_status round-trip works")


# Contracts: C29 - SpanStatus.to_otel_status and from_otel_status boundary cases
def check_span_status_otel_boundary():
    """C29: SpanStatus.to_otel_status/from_otel_status handle boundary cases."""
    import opentelemetry.trace as trace_api

    # UNSET status
    ss = SpanStatus(SpanStatusCode.UNSET)
    otel_s = ss.to_otel_status()
    assert otel_s.status_code == trace_api.StatusCode.UNSET
    assert otel_s.description == ""

    # from_otel_status with UNSET
    otel_s2 = trace_api.Status(trace_api.StatusCode.UNSET)
    ss2 = SpanStatus.from_otel_status(otel_s2)
    assert ss2.status_code == SpanStatusCode.UNSET

    # ERROR with empty description
    ss3 = SpanStatus(SpanStatusCode.ERROR)
    otel_s3 = ss3.to_otel_status()
    assert otel_s3.status_code == trace_api.StatusCode.ERROR
    assert otel_s3.description == ""

    # from_otel_status with None description
    otel_s4 = trace_api.Status(trace_api.StatusCode.OK)
    # OTel Status sets description to None by default
    ss4 = SpanStatus.from_otel_status(otel_s4)
    assert ss4.status_code == SpanStatusCode.OK
    # description should be "" not None (the from_otel_status converts None to "")
    assert ss4.description == ""

    print("PASS: C29 - SpanStatus.to_otel_status/from_otel_status handles boundary cases")


if __name__ == "__main__":
    check_to_mlflow_trace_multiple_spans()
    check_live_span_from_dict_error()
    check_live_span_set_span_type_override()
    check_to_immutable_span_preserves_data()
    check_noop_span_complete_interface()
    check_span_attributes_caching()
    check_span_events_with_data()
    check_from_otel_proto_with_location()
    check_request_id_backward_compat()
    check_span_type_edge_cases()
    check_to_dict_from_dict_full_roundtrip()
    check_to_otel_proto_with_parent()
    check_cached_registry_immutability()
    check_create_mlflow_span_boundaries()
    check_create_mlflow_span_live_span_attrs()
    check_decode_otel_proto_nested()
    check_trace_lifecycle_state_transitions()
    check_to_dict_encoding_scheme()
    check_span_status_proto_roundtrip()
    check_span_status_otel_boundary()
    print("\nAll behavior spec checks passed.")
