# Semantic IR: Assessment Source Management and Trace Search Tool

## L1. Requirement Obligations

### R1
- **Type**: Interface
- **Statement**: `SearchTracesTool` must extend `JudgeTool` and provide `name`, `get_definition`, and `invoke` methods with exact signatures.
- **Task Evidence**: Interface Description 1 — `SearchTracesTool(JudgeTool)` with three methods: `get_definition() -> ToolDefinition`, `invoke(trace, filter_string, order_by, max_results) -> list[JudgeToolTraceInfo]`, `name -> str`.
- **Acceptance**: The class is importable from `mlflow.genai.judges.tools.search_traces`, all three methods exist with correct signatures and return types.
- **Repository Evidence**: `/testbed/mlflow/genai/judges/tools/base.py` defines `JudgeTool(ABC)` with abstract `name`, `get_definition`, `invoke`. `/testbed/mlflow/genai/judges/tools/search_traces.py` L108-118 has the class skeleton. Other tools like `GetTraceInfoTool` (`/testbed/mlflow/genai/judges/tools/get_trace_info.py`) show the pattern.
- **Uncertainty**: None.

### R2
- **Type**: Interface
- **Statement**: `name` property must return `ToolNames._SEARCH_TRACES` (the string `"_search_traces"`).
- **Task Evidence**: Interface Description 1 — name property returns `ToolNames._SEARCH_TRACES`.
- **Acceptance**: `SearchTracesTool().name == "_search_traces"`.
- **Repository Evidence**: `/testbed/mlflow/genai/judges/tools/constants.py` L16: `_SEARCH_TRACES = "_search_traces"`. Pattern: `GetTraceInfoTool.name` returns `ToolNames.GET_TRACE_INFO` (`get_trace_info.py` L30).
- **Uncertainty**: None.

### R3
- **Type**: Interface
- **Statement**: `get_definition` must return a `ToolDefinition` with type `"function"`, function name `"_search_traces"`, and `ToolParamsSchema` containing three optional properties: `filter_string` (str), `order_by` (list[str]), `max_results` (int).
- **Task Evidence**: Interface Description 1 — `get_definition` returns `ToolDefinition` with `function: FunctionToolDefinition` (name, description, parameters), `type: "function"`. Parameters include `filter_string`, `order_by`, `max_results` all optional.
- **Acceptance**: The returned `ToolDefinition` has `type == "function"`, `function.name == "_search_traces"`, parameters with the three named properties, and empty `required` list.
- **Repository Evidence**: `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` L40-64 shows `get_definition` pattern with `FunctionToolDefinition`, `ToolParamsSchema`, properties dict.
- **Uncertainty**: Exact `description` text is not fully specified; must be comprehensive about SQL-like filter syntax.

### R4
- **Type**: Behavior
- **Statement**: `invoke` must extract the experiment ID from the trace, call `mlflow.search_traces` with the experiment ID and user-provided filter/order/max_results, and convert the returned traces into `list[JudgeToolTraceInfo]`.
- **Task Evidence**: Interface Description 1 — `invoke` searches traces within the same experiment, supports filtering/ordering/pagination, returns `JudgeToolTraceInfo` objects.
- **Acceptance**: When given a valid trace with experiment context, `invoke` returns a list of `JudgeToolTraceInfo` objects.
- **Repository Evidence**: `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` L85-104 shows `SearchTracesTool().invoke()` being called. `/testbed/mlflow/tracing/fluent.py` L664+ `search_traces()` accepts `experiment_ids`, `filter_string`, `max_results`, `order_by`.
- **Uncertainty**: Whether to use `mlflow.search_traces` (fluent) or `MlflowClient().search_traces` — both exist; fluent is simpler and used in the codebase.

### R5
- **Type**: Failure
- **Statement**: `_get_experiment_id` must raise `MlflowException` when the trace has no `trace_location`, when the location type is not `MLFLOW_EXPERIMENT`, or when there is no `experiment_id`.
- **Task Evidence**: Interface Description 1 — the helper raises `MlflowException` on missing trace_location, non-MLflow experiment type, missing experiment_id.
- **Acceptance**: Each of the three conditions raises `MlflowException`.
- **Repository Evidence**: `/testbed/mlflow/entities/trace_info.py` L210-214 `experiment_id` property. `/testbed/mlflow/entities/trace_location.py` defines `TraceLocation`, `MlflowExperimentLocation`, `TraceLocationType.MLFLOW_EXPERIMENT`.
- **Uncertainty**: The exact error code string is not constrained by task or native tests; acceptance only requires `MlflowException` with a descriptive message.

### R6
- **Type**: Behavior
- **Statement**: `_convert_assessments_to_tool_types` must convert MLflow `Expectation` → `JudgeToolExpectation` and `Feedback` → `JudgeToolFeedback`, handling error fields (set to None when absent) and preserving all core properties.
- **Task Evidence**: Interface Description 1 — converts Assessment objects to judge tool types, Expectation→JudgeToolExpectation, Feedback→JudgeToolFeedback with error fields (error_code, error_message, stack_trace) set to None if no error, plus overrides and valid properties.
- **Acceptance**: For an `Expectation`, returns `JudgeToolExpectation` with matching name, source, rationale, span_id, assessment_id, value. For a `Feedback`, returns `JudgeToolFeedback` with additional error_code/error_message/stack_trace/overrides/valid.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment.py` defines `Expectation(value, ...)`, `Feedback(value, error?, ...)`. `/testbed/mlflow/genai/judges/tools/types.py` defines `JudgeToolExpectation` and `JudgeToolFeedback`.
- **Uncertainty**: The `source` field in `JudgeToolExpectation`/`JudgeToolFeedback` is a `str`; how to convert `AssessmentSource` object to string — likely `source.source_type` or `str(source)`.

### R7
- **Type**: Behavior
- **Statement**: `AssessmentSourceType._standardize` must be a `@staticmethod` that normalizes case-insensitive input to uppercase, converts deprecated `"AI_JUDGE"` to `"LLM_JUDGE"` with a `FutureWarning` carrying the exact message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`, and raises `MlflowException` with message containing `"Invalid assessment source type"` for invalid types.
- **Task Evidence**: Interface Description 2 — static method handles case-insensitive input, deprecation warning for AI_JUDGE→LLM_JUDGE, validation. Native test `test_ai_judge_deprecation_warning` (`tests/entities/test_assessment_source.py:80-85`) uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` which requires exact regex match on the warning message.
- **Acceptance**: `_standardize("human") == "HUMAN"`, `_standardize("AI_JUDGE")` emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and returns `"LLM_JUDGE"`, `_standardize("ROBOT")` raises `MlflowException`.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` L78 calls `AssessmentSourceType._standardize(self.source_type)` in `__post_init__`. Native tests at `/testbed/tests/entities/test_assessment_source.py`.
- **Uncertainty**: None.

### R8
- **Type**: Failure
- **Statement**: `SearchTracesTool.invoke` must gracefully handle per-trace conversion failures: when `_convert_assessments_to_tool_types` raises for a specific trace, the failing trace is skipped, a warning is logged via `_logger.warning`, and the remaining successfully converted traces are returned.
- **Task Evidence**: Interface Description 1 — "Traces that fail to process during retrieval are logged as warnings and skipped."
- **Acceptance**: When given search results where one trace causes a conversion error, `invoke` returns only the successfully converted traces (cardinality decrease), does not raise, and a warning is emitted.
- **Repository Evidence**: `/testbed/mlflow/genai/judges/tools/search_traces.py` L31 defines `_logger = logging.getLogger(__name__)`.
- **Uncertainty**: The exact failure mode (what makes conversion fail) — we inject failure via mock to exercise the path.

### R9
- **Type**: Behavior
- **Statement**: `invoke` defaults: `filter_string=None` (no filter), `order_by=["timestamp ASC"]`, `max_results=20`.
- **Task Evidence**: Interface Description 1 — defaults for filter_string, order_by, max_results.
- **Acceptance**: Calling `invoke(trace)` without optional args passes `filter_string=None`, `order_by=["timestamp ASC"]`, `max_results=20` to `mlflow.search_traces`.
- **Repository Evidence**: `/testbed/mlflow/tracing/fluent.py` `search_traces()` signature accepts these parameters.
- **Uncertainty**: None.

### R10
- **Type**: State
- **Statement**: Each `JudgeToolTraceInfo` returned by `invoke` must have all 7 fields populated: `trace_id` (str), `request_time` (int), `state` (TraceState), `request` (str|None), `response` (str|None), `execution_duration` (int|None), `assessments` (list of JudgeToolExpectation|JudgeToolFeedback).
- **Task Evidence**: Interface Description 1 — JudgeToolTraceInfo structure with these fields.
- **Acceptance**: Each returned object is a `JudgeToolTraceInfo` with all fields present (even if some are None where data is missing).
- **Repository Evidence**: `/testbed/mlflow/genai/judges/tools/types.py` L80-88 defines `JudgeToolTraceInfo` dataclass.
- **Uncertainty**: Where `request`/`response` content comes from — likely `trace.data.request` and `trace.data.response`.

### R11
- **Type**: Behavior
- **Statement**: `AssessmentSource` must support value-based equality (`==`) and dictionary serialization round-trips (`to_dictionary` followed by `from_dictionary` reconstructs an equal object).
- **Task Evidence**: Native tests `test_assessment_source_equality` (L9-16) and `test_assessment_source_to_from_dictionary` (L25-39) in `/testbed/tests/entities/test_assessment_source.py`.
- **Acceptance**: Two `AssessmentSource` instances with same `source_type` and `source_id` compare equal. `AssessmentSource.from_dictionary(source.to_dictionary()) == source`.
- **Repository Evidence**: `AssessmentSource` is a `@dataclass` inheriting from `_MlflowObject`. Dataclass provides `__eq__` based on field values. `to_dictionary` calls `asdict(self)`. `from_dictionary` calls `cls(**source_dict)`, which triggers `__post_init__` and hence `_standardize`.
- **Uncertainty**: None — dataclass defaults satisfy both contracts; the risk is that a faulty `__post_init__` or `_standardize` could break them.

## L2. Functional Design Graph

### N1 (SearchTracesTool class)
- **Type**: Public entry
- **Description**: The `SearchTracesTool` class, importable from `mlflow.genai.judges.tools.search_traces`.

### N2 (name property)
- **Type**: Interface method
- **Description**: Returns constant `ToolNames._SEARCH_TRACES`.

### N3 (get_definition method)
- **Type**: Interface method
- **Description**: Returns `ToolDefinition` with function-calling schema.

### N4 (invoke method)
- **Type**: Core behavior
- **Description**: Searches traces in experiment, converts to JudgeToolTraceInfo list.

### N5 (_get_experiment_id helper)
- **Type**: Internal helper
- **Description**: Validates and extracts experiment ID from trace.

### N6 (_convert_assessments_to_tool_types helper)
- **Type**: Internal helper
- **Description**: Converts Assessment list to judge tool types.

### N7 (mlflow.search_traces)
- **Type**: External call
- **Description**: Fluent API for searching traces.

### N8 (AssessmentSourceType._standardize)
- **Type**: Public entry (static)
- **Description**: Normalizes case, handles deprecation, validates source type.

### N9 (AssessmentSource.__post_init__)
- **Type**: Lifecycle hook
- **Description**: Calls `_standardize` on source_type after construction.

### N10 (AssessmentSource.__eq__)
- **Type**: Dataclass operation
- **Description**: Value-based equality inherited from dataclass.

### N11 (AssessmentSource.to_dictionary / from_dictionary)
- **Type**: Serialization round-trip
- **Description**: `asdict`-based serialization and reconstruction.

### E1
- **Kind**: CALL
- **Source**: N4 (invoke)
- **Target**: N5 (_get_experiment_id)
- **Condition**: Always — first step in invoke.
- **Transfer**: Trace object.
- **Evidence**: Interface Description 1 — invoke extracts experiment ID.
- **Obligations**: R4, R5

### E2
- **Kind**: CALL
- **Source**: N4 (invoke)
- **Target**: N7 (mlflow.search_traces)
- **Condition**: After experiment ID is validated.
- **Transfer**: experiment_ids, filter_string, order_by, max_results.
- **Evidence**: Interface Description 1, get_traces_in_session.py L98-104.
- **Obligations**: R4, R9

### E3
- **Kind**: CALL
- **Source**: N4 (invoke)
- **Target**: N6 (_convert_assessments_to_tool_types)
- **Condition**: For each trace in search results; with per-trace try/except skip.
- **Transfer**: List of Assessment objects.
- **Evidence**: Interface Description 1 — "Traces that fail to process during retrieval are logged as warnings and skipped."
- **Obligations**: R4, R8, R10

### E4
- **Kind**: CONTROL
- **Source**: N5 (_get_experiment_id)
- **Target**: N4 (invoke)
- **Condition**: Success — experiment_id extracted.
- **Transfer**: experiment_id string.
- **Evidence**: Interface Description 1.
- **Obligations**: R4, R5

### E5
- **Kind**: CONTROL
- **Source**: N5 (_get_experiment_id)
- **Target**: N4 (invoke)
- **Condition**: Failure — raises MlflowException.
- **Transfer**: Exception propagated to caller.
- **Evidence**: Interface Description 1 — error cases.
- **Obligations**: R5

### E6
- **Kind**: DATA
- **Source**: N6 (_convert_assessments_to_tool_types)
- **Target**: N4 (invoke)
- **Condition**: Building JudgeToolTraceInfo from trace results.
- **Transfer**: Converted assessments for each trace.
- **Evidence**: Interface Description 1.
- **Obligations**: R6

### E7
- **Kind**: CALL
- **Source**: N9 (AssessmentSource.__post_init__)
- **Target**: N8 (_standardize)
- **Condition**: On every AssessmentSource construction.
- **Transfer**: Raw source_type string → normalized string.
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` L78.
- **Obligations**: R7

### E8
- **Kind**: CONTROL
- **Source**: N8 (_standardize)
- **Target**: N9 (__post_init__)
- **Condition**: Success — normalized string returned.
- **Transfer**: Uppercase normalized source type.
- **Evidence**: Interface Description 2.
- **Obligations**: R7

### E9
- **Kind**: CONTROL
- **Source**: N8 (_standardize)
- **Target**: N9 (__post_init__)
- **Condition**: Failure — invalid type raises MlflowException.
- **Transfer**: Exception propagated.
- **Evidence**: Interface Description 2, test_assessment_source.py L51-53.
- **Obligations**: R7

### E10
- **Kind**: DATA
- **Source**: Trace.info
- **Target**: N4 (invoke)
- **Condition**: Building JudgeToolTraceInfo from trace results.
- **Transfer**: `request_time`, `state`, `execution_duration`, `assessments`.
- **Evidence**: Interface Description 1 — JudgeToolTraceInfo fields include these.
- **Obligations**: R10

### E11
- **Kind**: DATA
- **Source**: Trace.data
- **Target**: N4 (invoke)
- **Condition**: Building JudgeToolTraceInfo from trace results.
- **Transfer**: `request`, `response` strings.
- **Evidence**: Interface Description 1 — JudgeToolTraceInfo includes request/response.
- **Obligations**: R10

### E12
- **Kind**: CALL
- **Source**: N3 (get_definition)
- **Target**: N2 (name)
- **Condition**: To set the function name in ToolDefinition.
- **Transfer**: `ToolNames._SEARCH_TRACES` string.
- **Evidence**: Pattern from `/testbed/mlflow/genai/judges/tools/get_trace_info.py` L35-36.
- **Obligations**: R2, R3

### E13
- **Kind**: DATA
- **Source**: N10 (AssessmentSource.__eq__)
- **Target**: N9 (__post_init__)
- **Condition**: Equality is evaluated after __post_init__ standardizes fields.
- **Transfer**: Normalized field values.
- **Evidence**: Native test `test_assessment_source_equality` (`/testbed/tests/entities/test_assessment_source.py:9-16`).
- **Obligations**: R11

### E14
- **Kind**: DATA
- **Source**: N11 (to_dictionary/from_dictionary)
- **Target**: N9 (__post_init__)
- **Condition**: `from_dictionary` calls constructor → `__post_init__` → `_standardize`.
- **Transfer**: Dictionary → normalized dataclass.
- **Evidence**: Native test `test_assessment_source_to_from_dictionary` (`/testbed/tests/entities/test_assessment_source.py:25-39`).
- **Obligations**: R11

## L3. Verifiable Contracts

### C1
- **Type**: Interface
- **Subject**: `SearchTracesTool.name`
- **Relation**: Returns constant string.
- **Expected**: `"_search_traces"`
- **Evidence**: Task R2, ToolNames constant.
- **Observe**: RETURN_VALUE
- **Target**: N2
- **Obligations**: R2
- **Graph**: E12

### C2
- **Type**: Interface
- **Subject**: `SearchTracesTool.get_definition()`
- **Relation**: Returns `ToolDefinition` matching the function-calling schema.
- **Expected**: `type == "function"`, `function.name == "_search_traces"`, parameters has `filter_string` (str), `order_by` (array of str), `max_results` (integer), all optional.
- **Evidence**: Task R3.
- **Observe**: RETURN_VALUE, FIELD_READ
- **Target**: N3
- **Obligations**: R3
- **Graph**: E12

### C3
- **Type**: Interface
- **Subject**: `SearchTracesTool.invoke(trace, filter_string, order_by, max_results)`
- **Relation**: Searches traces in the same experiment as the given trace.
- **Expected**: Returns `list[JudgeToolTraceInfo]` for valid trace with MLflow experiment context. Calls `_get_experiment_id`, `mlflow.search_traces`, and `_convert_assessments_to_tool_types`.
- **Evidence**: Task R4.
- **Observe**: RETURN_VALUE, RUNTIME_ARGUMENT_TRACE (args to mlflow.search_traces)
- **Target**: N4
- **Obligations**: R4, R9, R10
- **Graph**: E1, E2, E3

### C4
- **Type**: Failure
- **Subject**: `_get_experiment_id(trace)`
- **Relation**: Raises `MlflowException` when trace lacks experiment context.
- **Expected**: Three failure modes: (a) no `mlflow_experiment` on the trace_location, (b) location type != `MLFLOW_EXPERIMENT`, (c) no `experiment_id` (empty/missing).
- **Evidence**: Task R5.
- **Observe**: EXCEPTION
- **Target**: N5
- **Obligations**: R5
- **Graph**: E4, E5

### C5
- **Type**: Dataflow
- **Subject**: `_convert_assessments_to_tool_types(assessments)`
- **Relation**: Converts `Expectation`/`Feedback` → `JudgeToolExpectation`/`JudgeToolFeedback`.
- **Expected**: For `Expectation`: all core fields mapped (name, source, rationale, span_id, assessment_id, value). For `Feedback`: same + error_code/error_message/stack_trace/overrides/valid. Error fields are None when Feedback has no error.
- **Evidence**: Task R6.
- **Observe**: RETURN_VALUE, FIELD_READ
- **Target**: N6
- **Obligations**: R6
- **Graph**: E6

### C6
- **Type**: Behavior
- **Subject**: `AssessmentSourceType._standardize(source_type)`
- **Relation**: Normalizes case-insensitive input, handles deprecation with exact warning message, validates.
- **Expected**: (a) `"human"` → `"HUMAN"`, (b) `"AI_JUDGE"` → emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and returns `"LLM_JUDGE"`, (c) `"INVALID"` → `MlflowException` with message containing `"Invalid assessment source type"`, (d) `"llm_judge"` → `"LLM_JUDGE"`, (e) `"CODE"` → `"CODE"`.
- **Evidence**: Task R7, native test `test_ai_judge_deprecation_warning` (`/testbed/tests/entities/test_assessment_source.py:80-85`).
- **Observe**: RETURN_VALUE, SIDE_EFFECT (`warnings.warn` with exact message match via `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`)
- **Target**: N8
- **Obligations**: R7
- **Graph**: E8, E9

### C7
- **Type**: Behavior
- **Subject**: `SearchTracesTool.invoke` default parameters
- **Relation**: When called with only trace, uses defaults.
- **Expected**: `filter_string=None` (all traces), `order_by=["timestamp ASC"]`, `max_results=20`.
- **Evidence**: Task R9.
- **Observe**: RUNTIME_ARGUMENT_TRACE (arguments passed to mlflow.search_traces)
- **Target**: N4
- **Obligations**: R9
- **Graph**: E2

### C8
- **Type**: State
- **Subject**: `JudgeToolTraceInfo` fields
- **Relation**: Returned objects have all 7 required fields.
- **Expected**: Each object has non-None `trace_id` (str), `request_time` (int), `state` (TraceState), `request` (str|None), `response` (str|None), `execution_duration` (int|None), `assessments` (list).
- **Evidence**: Task R10.
- **Observe**: FIELD_READ
- **Target**: N4
- **Obligations**: R10
- **Graph**: E10, E11

### C9
- **Type**: Failure
- **Subject**: `SearchTracesTool.invoke` graceful error handling
- **Relation**: When `_convert_assessments_to_tool_types` raises for a specific trace, that trace is skipped, a warning is logged via `_logger.warning`, and remaining traces are returned.
- **Expected**: Result list length < input trace count (bad trace skipped). Warning logged containing the failed trace ID. Good trace still present in results. No exception propagates.
- **Evidence**: Task R8.
- **Observe**: RETURN_VALUE (cardinality decrease), SIDE_EFFECT (mock on `_logger.warning`)
- **Target**: N4
- **Obligations**: R8
- **Graph**: E3, E6

### C10
- **Type**: SideEffect
- **Subject**: `AssessmentSource.__post_init__` calls `_standardize`
- **Relation**: Source type standardization happens on construction.
- **Expected**: `AssessmentSource(source_type="human", ...)` has `source_type == "HUMAN"` after init.
- **Evidence**: Task R7, test_assessment_source.py L55-67.
- **Observe**: FIELD_READ
- **Target**: N9
- **Obligations**: R7
- **Graph**: E7

### C11
- **Type**: Interface
- **Subject**: `_get_experiment_id` returns experiment ID for valid trace
- **Relation**: Extracts experiment_id from MlflowExperimentLocation.
- **Expected**: Returns the string experiment_id when trace is from an MLflow experiment.
- **Evidence**: Task R5 positive case.
- **Observe**: RETURN_VALUE
- **Target**: N5
- **Obligations**: R5
- **Graph**: E4

### C12
- **Type**: Behavior
- **Subject**: Conversion of Assessment source to string for JudgeTool types
- **Relation**: `AssessmentSource` object → `str` for `JudgeToolExpectation.source` / `JudgeToolFeedback.source`.
- **Expected**: The `source_type` field of AssessmentSource is used as the string source.
- **Evidence**: Task R6; `JudgeToolExpectation.source` and `JudgeToolFeedback.source` are `str`.
- **Observe**: FIELD_READ
- **Target**: N6
- **Obligations**: R6
- **Graph**: E3

### C13
- **Type**: State
- **Subject**: `AssessmentSource` equality and serialization round-trip
- **Relation**: Dataclass-based value equality and `to_dictionary`/`from_dictionary` reconstruction.
- **Expected**: (a) Two `AssessmentSource` instances with same `source_type` and `source_id` compare equal (`==`). (b) `AssessmentSource.from_dictionary(source.to_dictionary()) == source`.
- **Evidence**: Native tests `test_assessment_source_equality` (L9-16) and `test_assessment_source_to_from_dictionary` (L25-39) in `/testbed/tests/entities/test_assessment_source.py`.
- **Observe**: RETURN_VALUE (bool from `==`), RETURN_VALUE (reconstructed object equality)
- **Target**: N10, N11
- **Obligations**: R11
- **Graph**: E13, E14
