"""
Executable behavior spec for Assessment Source Management and Trace Search Tool.

Exercises outcomes, state, failure, side effects, defaults, boundaries, and compatibility.
Contracts: C4, C6, C7, C8, C9
"""

import sys
import warnings

sys.path.insert(0, "/testbed")


def check_c4_get_experiment_id_failures():
    """C4: _get_experiment_id raises MlflowException for invalid trace contexts."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.exceptions import MlflowException
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    # (a) Location type is MLFLOW_EXPERIMENT but mlflow_experiment is None
    try:
        trace_info_bad = TraceInfo(
            trace_id="test-bad",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=None,
            ),
            request_time=1234567890,
            state=TraceState.OK,
            execution_duration=100,
        )
        trace_bad = Trace(info=trace_info_bad, data=TraceData(spans=[]))
        _get_experiment_id(trace_bad)
        assert False, "Should have raised MlflowException for missing experiment location"
    except MlflowException as e:
        assert "experiment" in str(e).lower() or "location" in str(e).lower(), (
            f"Unexpected error message: {e}"
        )

    # (b) Location type is not MLFLOW_EXPERIMENT
    try:
        trace_info_inf = TraceInfo(
            trace_id="test-inf",
            trace_location=TraceLocation(
                type=TraceLocationType.INFERENCE_TABLE,
                inference_table=InferenceTableLocation(
                    full_table_name="catalog.schema.table"
                ),
            ),
            request_time=1234567890,
            state=TraceState.OK,
            execution_duration=100,
        )
        trace_inf = Trace(info=trace_info_inf, data=TraceData(spans=[]))
        _get_experiment_id(trace_inf)
        assert False, (
            "Should have raised MlflowException for non-MLflow experiment location"
        )
    except MlflowException as e:
        assert "experiment" in str(e).lower(), f"Unexpected error message: {e}"

    # (c) Location type is MLFLOW_EXPERIMENT but no experiment_id (empty)
    try:
        trace_info_empty = TraceInfo(
            trace_id="test-empty",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=MlflowExperimentLocation(experiment_id=""),
            ),
            request_time=1234567890,
            state=TraceState.OK,
            execution_duration=100,
        )
        trace_empty = Trace(info=trace_info_empty, data=TraceData(spans=[]))
        exp_id = _get_experiment_id(trace_empty)
        # Empty string may or may not be treated as missing — the spec says
        # "no experiment_id". We check that either it raises or returns empty.
        if exp_id == "":
            print(
                "    Note: _get_experiment_id accepted empty experiment_id (boundary)"
            )
    except MlflowException:
        pass  # Also acceptable

    print("PASS: C4 — _get_experiment_id raises for invalid trace contexts")


def check_c6_standardize_behavior():
    """C6: AssessmentSourceType._standardize normalizes, warns with exact message, and validates."""
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    # (a) case-insensitive normalization
    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("Human") == "HUMAN"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("Llm_Judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("code") == "CODE"
    assert AssessmentSourceType._standardize("CODE") == "CODE"
    assert (
        AssessmentSourceType._standardize("source_type_unspecified")
        == "SOURCE_TYPE_UNSPECIFIED"
    )

    # (b) deprecated AI_JUDGE → LLM_JUDGE with exact FutureWarning message
    import re

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        assert result == "LLM_JUDGE", f"Expected 'LLM_JUDGE', got '{result}'"
        assert len(w) == 1, f"Expected 1 warning, got {len(w)}"
        assert issubclass(w[0].category, FutureWarning)
        # Exact message as required by native test:
        # pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")
        assert re.search(
            r"AI_JUDGE is deprecated\. Use LLM_JUDGE instead\.",
            str(w[0].message),
        ), f"Warning message did not match exact pattern. Got: {w[0].message}"

    # Also test lowercase ai_judge — same exact warning
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("ai_judge")
        assert result == "LLM_JUDGE", f"Expected 'LLM_JUDGE', got '{result}'"
        assert len(w) >= 1
        assert issubclass(w[0].category, FutureWarning)
        assert re.search(
            r"AI_JUDGE is deprecated\. Use LLM_JUDGE instead\.",
            str(w[0].message),
        ), f"Warning message did not match exact pattern. Got: {w[0].message}"

    # (c) invalid type raises MlflowException
    try:
        AssessmentSourceType._standardize("ROBOT")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e), f"Unexpected error: {e}"

    print(
        "PASS: C6 — _standardize normalizes, warns with exact message on deprecated, and rejects invalid"
    )


def check_c7_invoke_defaults():
    """C7: invoke uses correct defaults when optional args omitted."""
    from unittest.mock import patch

    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace_info = TraceInfo(
        trace_id="test-defaults",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-defaults"),
        ),
        request_time=1234567890,
        state=TraceState.OK,
        execution_duration=100,
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[]))

    with patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
        return_value=[],
    ) as mock_search:
        tool = SearchTracesTool()
        tool.invoke(trace)

        call_kwargs = mock_search.call_args.kwargs
        assert call_kwargs.get("filter_string") is None, (
            f"Expected filter_string=None, got {call_kwargs.get('filter_string')}"
        )
        assert call_kwargs.get("order_by") == ["timestamp ASC"], (
            f"Expected order_by=['timestamp ASC'], got {call_kwargs.get('order_by')}"
        )
        # max_results may be passed positionally or as kwarg; check either
        assert call_kwargs.get("max_results") == 20, (
            f"Expected max_results=20, got {call_kwargs.get('max_results')}"
        )

    print("PASS: C7 — invoke uses correct default parameters")


def check_c8_judge_tool_trace_info_fields():
    """C8: JudgeToolTraceInfo has all required fields populated."""
    from unittest.mock import patch

    from mlflow.entities.assessment import Expectation
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo

    trace_info = TraceInfo(
        trace_id="test-fields",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-fields"),
        ),
        request_time=1234567890,
        state=TraceState.OK,
        execution_duration=250,
        assessments=[
            Expectation(
                name="correctness",
                source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
                value=0.9,
                assessment_id="asmt-1",
            )
        ],
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[]))

    mock_result_trace = Trace(
        info=TraceInfo(
            trace_id="found-1",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-fields"),
            ),
            request_time=1234567800,
            state=TraceState.OK,
            execution_duration=150,
            assessments=[
                Expectation(
                    name="quality",
                    source=AssessmentSource(source_type="HUMAN", source_id="user-1"),
                    value=True,
                    assessment_id="asmt-2",
                )
            ],
        ),
        data=TraceData(spans=[]),
    )

    with patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
        return_value=[mock_result_trace],
    ):
        tool = SearchTracesTool()
        result = tool.invoke(trace)

        assert len(result) == 1
        ti = result[0]
        assert isinstance(ti, JudgeToolTraceInfo)
        assert ti.trace_id == "found-1"
        assert isinstance(ti.request_time, int)
        assert ti.request_time == 1234567800
        assert ti.state == TraceState.OK
        assert ti.execution_duration == 150
        assert isinstance(ti.assessments, list)
        assert len(ti.assessments) == 1

    print("PASS: C8 — JudgeToolTraceInfo has all required fields populated")


def check_c9_graceful_error_handling():
    """C9: invoke skips failed trace conversions, logs warnings, returns remaining.

    This injects a real conversion failure by mocking _convert_assessments_to_tool_types
    to raise on a specific trace. It then verifies:
    - The good trace is still in the result
    - The result list is shorter than the input (bad trace skipped)
    - A warning was logged
    """
    import logging
    from unittest.mock import patch

    from mlflow.entities.assessment import Expectation
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    # Build the input trace (the one whose experiment context we use)
    trace_info = TraceInfo(
        trace_id="test-graceful",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-graceful"),
        ),
        request_time=1234567890,
        state=TraceState.OK,
        execution_duration=100,
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[]))

    # Two result traces: one "good", one "bad"
    good_trace = Trace(
        info=TraceInfo(
            trace_id="good-trace",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-graceful"),
            ),
            request_time=1234567700,
            state=TraceState.OK,
            execution_duration=75,
            assessments=[
                Expectation(
                    name="good-assessment",
                    source=AssessmentSource(source_type="HUMAN", source_id="u1"),
                    value=True,
                )
            ],
        ),
        data=TraceData(spans=[]),
    )

    bad_trace = Trace(
        info=TraceInfo(
            trace_id="bad-trace",
            trace_location=TraceLocation(
                type=TraceLocationType.MLFLOW_EXPERIMENT,
                mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-graceful"),
            ),
            request_time=1234567800,
            state=TraceState.OK,
            execution_duration=50,
            assessments=[],  # Doesn't matter; mock will raise anyway
        ),
        data=TraceData(spans=[]),
    )

    mock_search_results = [bad_trace, good_trace]

    # Create a side-effect for _convert_assessments_to_tool_types:
    # it succeeds for good_trace but raises for bad_trace.
    original_convert = None

    def mock_convert_side_effect(assessments):
        # Determine which trace we're converting by looking at the assessments
        # (we use a sentinel-based approach: if assessments is empty and the
        #  mock was called for bad_trace, raise; otherwise, call real converter)
        # Simpler: use the trace's assessments list identity.
        # But we don't have trace reference here. We'll use a different strategy:
        # Call the real converter, but for bad_trace assessments raise.
        # Since we know bad_trace has empty assessments and good has non-empty,
        # we can key on that. But that's fragile. Better: mock at the invoke
        # level by patching the per-iteration loop.
        #
        # Alternative: patch the helper to raise on the FIRST call only.
        raise RuntimeError("Simulated conversion failure for bad-trace")

    call_count = [0]

    def mock_convert_with_failure(assessments):
        call_count[0] += 1
        if call_count[0] == 1:
            # First call = bad_trace → raise
            raise RuntimeError("Simulated conversion failure for bad-trace")
        else:
            # Subsequent calls = good_trace → use real converter
            return original_convert(assessments)

    with patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
        return_value=mock_search_results,
    ):
        # Import the real converter before patching
        from mlflow.genai.judges.tools.search_traces import (
            _convert_assessments_to_tool_types,
        )

        original_convert = _convert_assessments_to_tool_types

        with patch(
            "mlflow.genai.judges.tools.search_traces._convert_assessments_to_tool_types",
            side_effect=mock_convert_with_failure,
        ):
            with patch(
                "mlflow.genai.judges.tools.search_traces._logger.warning"
            ) as mock_log_warning:
                tool = SearchTracesTool()
                result = tool.invoke(trace)

                # Verify: no exception propagated
                assert isinstance(result, list)

                # The good trace should be in results, bad trace skipped
                trace_ids = [t.trace_id for t in result]
                assert "good-trace" in trace_ids, (
                    f"Expected 'good-trace' in results, got {trace_ids}"
                )
                assert "bad-trace" not in trace_ids, (
                    f"'bad-trace' should have been skipped, got {trace_ids}"
                )

                # Cardinality: result should have fewer items than input
                assert len(result) < len(mock_search_results), (
                    f"Expected result length < {len(mock_search_results)}, "
                    f"got {len(result)}"
                )

                # Warning should have been logged
                assert mock_log_warning.called, (
                    "Expected _logger.warning to be called for the failed trace"
                )

    print(
        "PASS: C9 — invoke gracefully handles per-trace conversion failures, "
        "skips bad traces, and logs warnings"
    )


def check_c6_deprecation_warning_via_assessment_source():
    """C6 extended: AssessmentSource construction with AI_JUDGE triggers exact FutureWarning via _standardize."""
    import re

    from mlflow.entities.assessment_source import AssessmentSource

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        source = AssessmentSource(source_type="AI_JUDGE", source_id="gpt-4")
        assert source.source_type == "LLM_JUDGE"
        assert len(w) >= 1
        assert issubclass(w[0].category, FutureWarning)
        # Exact message as required by native test:
        # pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")
        assert re.search(
            r"AI_JUDGE is deprecated\. Use LLM_JUDGE instead\.",
            str(w[0].message),
        ), f"Warning message did not match exact pattern. Got: {w[0].message}"

    print(
        "PASS: C6 extended — AssessmentSource construction triggers exact deprecation warning"
    )


if __name__ == "__main__":
    check_c4_get_experiment_id_failures()
    check_c6_standardize_behavior()
    check_c7_invoke_defaults()
    check_c8_judge_tool_trace_info_fields()
    check_c9_graceful_error_handling()
    check_c6_deprecation_warning_via_assessment_source()
    print("\nAll behavior spec checks passed.")
