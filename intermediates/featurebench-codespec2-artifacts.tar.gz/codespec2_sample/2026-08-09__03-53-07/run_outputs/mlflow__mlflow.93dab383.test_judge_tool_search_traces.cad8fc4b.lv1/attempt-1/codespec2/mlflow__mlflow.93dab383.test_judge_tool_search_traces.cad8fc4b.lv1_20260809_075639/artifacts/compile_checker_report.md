# Compile Checker Report

- Status: needs_revision

## Req-Test Evidence

### RT1: AssessmentSource deprecation warning exact message
- Test: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning`
- Location: `tests/entities/test_assessment_source.py:80-85`
- Key Code:
  ```python
  def test_ai_judge_deprecation_warning():
      with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
          source = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
      assert source.source_type == "LLM_JUDGE"
      assert source.source_id == "ai_1"
  ```
- Test Lens: Side-effect message semantics — the exact warning message string is a contract.
- Implied Requirement: `AssessmentSourceType._standardize("AI_JUDGE")` must emit a `FutureWarning` with the exact message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`.
- IR / Spec Mapping: `R7`, `C6`, `check_c6_standardize_behavior` and `check_c6_deprecation_warning_via_assessment_source`
- Verdict: weak — the spec checks only substring presence (`"AI_JUDGE" in str(w[0].message)`) not the exact `pytest.warns(match=...)` pattern.

### RT2: AssessmentSource type validation raises MlflowException
- Test: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`
- Location: `tests/entities/test_assessment_source.py:42-53`
- Key Code:
  ```python
  def test_assessment_source_type_validation():
      AssessmentSource(source_type="HUMAN", source_id="user_1")
      AssessmentSource(source_type="LLM_JUDGE", source_id="judge_1")
      source = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
      assert source.source_type == "LLM_JUDGE"
      with pytest.raises(MlflowException, match="Invalid assessment source type"):
          AssessmentSource(source_type="ROBOT", source_id="robot_1")
  ```
- Test Lens: Error semantics — invalid types raise `MlflowException` with specific message; deprecated `AI_JUDGE` silently converts (warning tested separately).
- Implied Requirement: `_standardize` must raise `MlflowException` with message containing `"Invalid assessment source type"` for unknown types; `AI_JUDGE` normalizes to `LLM_JUDGE`.
- IR / Spec Mapping: `R7`, `C6`, `check_c6_standardize_behavior`
- Verdict: covered

### RT3: AssessmentSource case-insensitive normalization
- Test: `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity`
- Location: `tests/entities/test_assessment_source.py:56-70`
- Key Code:
  ```python
  def test_assessment_source_case_insensitivity():
      source_1 = AssessmentSource(source_type="human", source_id="user_1")
      source_4 = AssessmentSource(source_type="llm_judge", source_id="judge_1")
      source_5 = AssessmentSource(source_type="Llm_Judge", source_id="judge_2")
      assert source_1.source_type == "HUMAN"
      assert source_4.source_type == "LLM_JUDGE"
      assert source_5.source_type == "LLM_JUDGE"
  ```
- Test Lens: Data normalization — case-insensitive input always becomes uppercase output on the `source_type` field.
- Implied Requirement: `_standardize` normalizes any case to uppercase; `AssessmentSource.__post_init__` calls it.
- IR / Spec Mapping: `R7`, `C6`, `C10`, `check_c6_standardize_behavior`, `check_c10_assessment_source_standardization`
- Verdict: covered

### RT4: AssessmentSource equality and serialization round-trip
- Test: `tests/entities/test_assessment_source.py::test_assessment_source_equality`
- Location: `tests/entities/test_assessment_source.py:9-16`
- Key Code:
  ```python
  def test_assessment_source_equality():
      source1 = AssessmentSource(source_type="HUMAN", source_id="user_1")
      source2 = AssessmentSource(source_type="HUMAN", source_id="user_1")
      source3 = AssessmentSource(source_type="LLM_JUDGE", source_id="ai_1")
      assert source1 == source2
      assert source1 != source3
  ```
- Test Lens: Object-model fidelity — dataclass-based equality on normalized fields; also `to_dictionary`/`from_dictionary` round-trip in `test_assessment_source_to_from_dictionary`.
- Implied Requirement: `AssessmentSource` supports equality comparison and dictionary serialization round-trips.
- IR / Spec Mapping: missing — no R, C, or check covers `AssessmentSource.__eq__` or `to_dictionary`/`from_dictionary`.
- Verdict: missing

### RT5: GetTracesInSession delegates to SearchTracesTool with correct arguments
- Test: `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_success`
- Location: `tests/genai/judges/test_judge_tool_get_traces_in_session.py:56-92`
- Key Code:
  ```python
  mock_search_tool.invoke.assert_called_once_with(
      trace=current_trace,
      filter_string=(
          f"metadata.`{TraceMetadataKey.TRACE_SESSION}` = 'session-123' "
          "AND trace.timestamp < 1234567890"
      ),
      order_by=None,
      max_results=20,
  )
  ```
- Test Lens: Argument forwarding/dataflow — `GetTracesInSession.invoke` constructs a filter_string and forwards all arguments to `SearchTracesTool.invoke`.
- Implied Requirement: `SearchTracesTool` must exist, be importable, and have an `invoke(trace, filter_string, order_by, max_results)` method accepting these keyword arguments.
- IR / Spec Mapping: `R1`, `R4`, `C3`, `check_c3_invoke_connectivity`
- Verdict: covered

### RT6: Builtin tools registration completeness
- Test: `tests/genai/judges/test_judge_tool_registry.py::test_builtin_tools_are_properly_registered`
- Location: `tests/genai/judges/test_judge_tool_registry.py:131-141`
- Key Code:
  ```python
  def test_builtin_tools_are_properly_registered():
      tools = list_judge_tools()
      registered_tool_names = {t.name for t in tools if not isinstance(t, MockTool)}
      all_tool_constants = {
          value
          for name, value in inspect.getmembers(ToolNames)
          if not name.startswith("_") and isinstance(value, str)
      }
      assert all_tool_constants == registered_tool_names
  ```
- Test Lens: Registration completeness — every non-underscore-prefixed ToolNames constant must have a registered tool.
- Implied Requirement: `_SEARCH_TRACES` (starts with `_`) is excluded from this check, so `SearchTracesTool` does not need to be registered. However, it must be importable since `GetTracesInSession` imports and uses it.
- IR / Spec Mapping: Not directly mapped (no R for registration). The IR correctly does not require registration.
- Verdict: covered (non-requirement correctly omitted)

## Findings

### Finding 1: Weak contract on deprecation warning message
- Category: weak_contract
- Subrequirements: R7
- Evidence: Native test `test_ai_judge_deprecation_warning` (RT1) uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` which requires an exact regex match. The generated spec `check_c6_standardize_behavior` only checks `"AI_JUDGE" in str(w[0].message)` and `"LLM_JUDGE" in str(w[0].message)` — substring presence, not exact wording.
- Cause: The spec author reduced the native test's precise `match=` string to loose substring assertions.
- Impact: A plausible wrong implementation emitting `"AI_JUDGE is an old term, please migrate to LLM_JUDGE"` would pass the spec check but fail the native test. The contract does not enforce the message contract that the repository already tests.
- Required Change: Update `check_c6_standardize_behavior` (and/or `check_c6_deprecation_warning_via_assessment_source`) to verify the warning message matches the exact pattern `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`, e.g., via `pytest.warns(FutureWarning, match=...)` or an equivalent `re.search`.
- Req-Test Evidence: RT1

### Finding 2: Unexecutable C9 — graceful error handling not triggered
- Category: unexecutable_spec
- Subrequirements: R8
- Evidence: The `check_c9_graceful_error_handling` function creates `bad_trace` and `good_trace`, both with empty `assessments=[]` and valid `TraceInfo`. Neither trace triggers a conversion error in `_convert_assessments_to_tool_types`. The comment says "Create a trace that will fail conversion" but the code does not construct any failure scenario. The check only asserts `"good-trace" in trace_ids` which would pass regardless of whether `bad_trace` was skipped or successfully converted.
- Cause: The spec attempts to exercise the per-trace error-skip path but does not inject a real conversion failure (e.g., a trace with an invalid assessment object or a mock that raises on specific traces).
- Impact: A wrong implementation that crashes on any conversion error (instead of skipping) would still pass this check. The R8 obligation (graceful skip + warning) is not verified. The spec cannot distinguish between "error was caught and skipped" and "both traces converted normally."
- Required Change: Construct a trace that actually fails `_convert_assessments_to_tool_types` (e.g., by mocking the helper to raise on a specific trace, or by creating a trace with a non-Assessment object in its assessments list). Then assert: (a) the result list contains only the good trace, (b) the result length is strictly less than the input trace count, and (c) a warning was logged via `assertLogs` or a mock on `_logger.warning`.
- Req-Test Evidence: None (no applicable native test for this path — the task description R8 is the sole source)

### Finding 3: AssessmentSource equality and serialization not covered
- Category: lost_obligation
- Subrequirements: None (implicit from native tests)
- Evidence: Native tests `test_assessment_source_equality` and `test_assessment_source_to_from_dictionary` (RT4) verify `AssessmentSource.__eq__` and `to_dictionary`/`from_dictionary` round-trips. These are dataclass-provided behaviors that must survive the `__post_init__` standardization without breaking equality or serialization.
- Cause: The IR focuses on the `_standardize` behavior but omits the object-model contracts (equality, serialization) that the native test suite already validates.
- Impact: An implementation that mutates a non-dataclass field or breaks the `asdict` representation during `__post_init__` could break equality or dictionary round-trips without being caught by any generated spec check.
- Required Change: Add a contract (e.g., C13) and spec check verifying that two `AssessmentSource` instances with the same inputs compare equal, and that `to_dictionary` followed by `from_dictionary` reconstructs an equal object. This is low-risk (dataclass default) but the native tests explicitly require it.
- Req-Test Evidence: RT4

## Coverage

| R | Contracts | Spec Checks |
|---|-----------|-------------|
| R1 | C1, C2, C3 | `check_c1_name_returns_constant`, `check_c2_get_definition_schema`, `check_c3_invoke_connectivity` |
| R2 | C1 | `check_c1_name_returns_constant` |
| R3 | C2 | `check_c2_get_definition_schema` |
| R4 | C3, C11 | `check_c3_invoke_connectivity`, `check_c11_get_experiment_id_valid` |
| R5 | C4, C11 | `check_c4_get_experiment_id_failures`, `check_c11_get_experiment_id_valid` |
| R6 | C5, C12 | `check_c5_convert_assessments`, `check_c12_assessment_source_to_string` |
| R7 | C6, C10 | `check_c6_standardize_behavior`, `check_c10_assessment_source_standardization`, `check_c6_deprecation_warning_via_assessment_source` |
| R8 | C9 | `check_c9_graceful_error_handling` (unexecutable) |
| R9 | C7 | `check_c7_invoke_defaults` |
| R10 | C8 | `check_c8_judge_tool_trace_info_fields` |
| (RT4) | missing | missing |

All C records are referenced by at least one check function. C9 has a check but the check is unexecutable. No C is unreachable, but the RT4 obligations have no C mapping.

## Judge Focus

1. **Deprecation message exactness** (Finding 1): Verify `_standardize` emits the exact string `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` as a `FutureWarning`. Use `pytest.warns(FutureWarning, match=...)` in the spec.
2. **Error-skip path** (Finding 2): Make C9's check actually trigger a conversion failure (mock `_convert_assessments_to_tool_types` to raise on one trace, or construct a trace with a non-Assessment in the assessments list). Assert cardinality decrease and warning side-effect.
3. **Object-model round-trips** (Finding 3): Add a lightweight check that `AssessmentSource` equality and `to_dictionary`/`from_dictionary` survive `__post_init__` standardization. Low effort, high native-test alignment.
4. **Error code on `_get_experiment_id`**: The IR R5 claims `INVALID_PARAMETER_VALUE` but neither the task nor the spec checks it. Either remove the claim from the IR or add the check to the spec for consistency.
