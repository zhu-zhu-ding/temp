# Compile Checker Agent Skill

This is a durable review rubric for judging IR-to-spec compilation. It is not
task evidence. Preserve the base rubric and append concise, generalizable
lessons after each checker run.

## Base Rubric

1. Requirement completeness: split explicit requirements and native-test
   implications into atomic, non-invented obligations.
2. Repository fidelity: each graph node/edge and fixture comes from a real
   public API, caller, constructor, field, or test-supported path.
3. Contract strength: every contract has a distinguishable wrong implementation
   that its check would fail, not only an import/type/symbol assertion.
4. Observation quality: validate actual arguments, returned fields, state,
   exception semantics, or side effects at the contract target.
5. Compatibility: inspect defaults, signatures, aliases, import/export paths,
   serialization round trips, lifecycle invariants, and existing callers.
6. Collection semantics: inspect cardinality, ordering, deduplication,
   aggregation, and partial-failure survival whenever collections/logs/results
   are involved.
7. Spec execution: each C is referenced, each check is called, and at least one
   check reaches a public entry and a real observer for every R.
8. Req-test synthesis: search for tests from task terms and every relevant
   public entry/module/graph symbol. For each material assertion, preserve a
   short exact code excerpt, its `path::test_name` location, the test lens, and
   the implied contract before judging generated IR/spec coverage. Never claim
   a native-test implication without a real test excerpt, unless explicitly
   marked as task/source-only evidence.
9. Test-lens coverage: classify native tests by API/default/signature,
   dataflow/argument forwarding, lifecycle/state, error/message, side-effect
   count/order, collection cardinality/order/partial success, compatibility/
   round trip, and fixture/object-model fidelity. Judge whether generated specs
   cover the material lenses, not just whether they mention the same symbols.
10. Counterfactual strength: for each important native-test lens, identify the
    smallest plausible regression (wrong default, dropped argument, changed
    branch, reordered/filtered item, altered exception, or fake fixture) and
    require an executable generated check that would fail it. Native tests'
    real construction paths take precedence over dynamically fabricated fields
    or mocks of repository dispatchers.

## Lessons

### L1: Exact warning/error messages are contracts
When a native test uses `pytest.warns(FutureWarning, match="exact string")` or
`pytest.raises(MlflowException, match="exact string")`, the exact message text
is a contract. Substring checks (`"keyword" in str(...)`) in generated specs
are insufficient — they would pass a plausible wrong message that differs in
wording. Always match the native test's precision: use the same `match=` regex
or an equivalent `re.search` with the exact pattern.
*Evidence: RT1 — `test_ai_judge_deprecation_warning` uses exact match; the
generated C6 check only used substring presence.*

### L2: Error-handling specs must inject real failures
A spec check for graceful error handling (skip-on-failure, warning logging) is
unexecutable unless it actually triggers a failure. Creating two valid traces
and calling it "bad" vs "good" does not exercise the error path. The spec must
either mock the internal converter to raise on a specific trace, or construct a
trace with an assessment that violates the expected type contract. The check
must then assert both that the good trace survived and that the bad trace was
omitted (cardinality decrease) plus the side-effect (log/warning).
*Evidence: RT2 (none — task-only R8) — the C9 check created two valid traces
and could not distinguish error-skip from normal conversion.*

### L3: Dataclass equality and serialization are implicit native-test obligations
Even when the task does not mention `__eq__` or `to_dictionary`/`from_dictionary`,
native tests that exercise them create implicit requirements. A generated spec
that never checks equality or round-trip serialization could miss a regression
introduced by `__post_init__` side-effects that corrupt the dataclass fields.
Add a lightweight contract covering the native-tested object-model invariants.
*Evidence: RT4 — `test_assessment_source_equality` and
`test_assessment_source_to_from_dictionary` have no corresponding R/C/check.*

### L4: Verify that "error path" specs actually diverge from the happy path
When a spec claims to test a failure mode, walk the concrete data construction:
if both the "bad" and "good" fixtures would produce identical behavior in the
implementation under test, the spec is unexecutable. Every failure-mode check
must construct at least one input that cannot succeed in the normal path.
*Evidence: Finding 2 — the C9 `bad_trace` had no assessments, identical
structure to `good_trace`; nothing would fail conversion.*
