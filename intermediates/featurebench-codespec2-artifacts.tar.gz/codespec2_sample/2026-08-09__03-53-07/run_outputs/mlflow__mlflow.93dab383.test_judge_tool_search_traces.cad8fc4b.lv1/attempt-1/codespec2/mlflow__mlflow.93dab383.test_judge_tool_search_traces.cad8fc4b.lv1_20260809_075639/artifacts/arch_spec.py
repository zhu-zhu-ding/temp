"""
Executable architecture spec for Assessment Source Management and Trace Search Tool.

Exercises public entry points and L2 CALL/CONTROL/DATA connectivity.
Contracts: C1, C2, C3, C5, C10, C11, C12, C13
"""

import sys

sys.path.insert(0, "/testbed")


def check_c1_name_returns_constant():
    """C1: SearchTracesTool.name returns '_search_traces'."""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tool = SearchTracesTool()
    assert tool.name == "_search_traces", f"Expected '_search_traces', got '{tool.name}'"
    print("PASS: C1 — SearchTracesTool.name returns '_search_traces'")


def check_c2_get_definition_schema():
    """C2: get_definition returns correct ToolDefinition schema."""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.types.llm import ToolDefinition

    tool = SearchTracesTool()
    definition = tool.get_definition()

    assert isinstance(definition, ToolDefinition), (
        f"Expected ToolDefinition, got {type(definition)}"
    )
    assert definition.type == "function", (
        f"Expected type 'function', got '{definition.type}'"
    )
    assert definition.function.name == "_search_traces", (
        f"Expected name '_search_traces', got '{definition.function.name}'"
    )
    assert definition.function.parameters.type == "object"
    assert (
        definition.function.parameters.required == []
        or definition.function.parameters.required is None
    )

    params = definition.function.parameters.properties
    assert "filter_string" in params, "Missing filter_string parameter"
    assert "order_by" in params, "Missing order_by parameter"
    assert "max_results" in params, "Missing max_results parameter"
    assert params["filter_string"].type == "string"
    assert params["order_by"].type == "array"
    assert params["max_results"].type == "integer"

    print("PASS: C2 — get_definition returns correct ToolDefinition schema")


def check_c3_invoke_connectivity():
    """C3: invoke calls _get_experiment_id, mlflow.search_traces, _convert_assessments_to_tool_types."""
    from unittest.mock import patch

    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo

    # Build a minimal valid trace with experiment context
    trace_info = TraceInfo(
        trace_id="test-trace-id",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-123"),
        ),
        request_time=1234567890,
        state=TraceState.OK,
        execution_duration=100,
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[]))

    # Mock search results
    mock_search_result = [
        Trace(
            info=TraceInfo(
                trace_id="found-trace-1",
                trace_location=TraceLocation(
                    type=TraceLocationType.MLFLOW_EXPERIMENT,
                    mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-123"),
                ),
                request_time=1234567800,
                state=TraceState.OK,
                execution_duration=50,
            ),
            data=TraceData(spans=[]),
        )
    ]

    with patch(
        "mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
        return_value=mock_search_result,
    ) as mock_search:
        tool = SearchTracesTool()
        result = tool.invoke(trace)

        # Verify search_traces was called
        assert mock_search.called, "mlflow.search_traces was not called"
        call_kwargs = mock_search.call_args.kwargs
        assert "exp-123" in call_kwargs.get("experiment_ids", []), (
            "experiment_id not passed to search_traces"
        )

        # Verify result type
        assert isinstance(result, list)
        if len(result) > 0:
            assert isinstance(result[0], JudgeToolTraceInfo)
            assert result[0].trace_id == "found-trace-1"
            assert result[0].state == TraceState.OK
            assert result[0].request_time == 1234567800
            assert result[0].execution_duration == 50

    print(
        "PASS: C3 — invoke calls search_traces and returns JudgeToolTraceInfo list"
    )


def check_c5_convert_assessments():
    """C5: _convert_assessments_to_tool_types converts Expectation/Feedback correctly."""
    from mlflow.entities.assessment import Expectation, Feedback
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import (
        _convert_assessments_to_tool_types,
    )
    from mlflow.genai.judges.tools.types import JudgeToolExpectation, JudgeToolFeedback

    # Create Expectation
    exp = Expectation(
        name="correctness",
        source=AssessmentSource(source_type="HUMAN", source_id="user-1"),
        value=0.95,
        rationale="Looks correct",
        span_id="span-1",
        assessment_id="asmt-1",
    )

    # Create Feedback (without error)
    fb = Feedback(
        name="quality",
        source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
        value=4,
        rationale="Good response",
        span_id="span-2",
        assessment_id="asmt-2",
    )

    result = _convert_assessments_to_tool_types([exp, fb])

    assert len(result) == 2

    # Check Expectation conversion
    assert isinstance(result[0], JudgeToolExpectation)
    assert result[0].name == "correctness"
    assert result[0].rationale == "Looks correct"
    assert result[0].span_id == "span-1"
    assert result[0].assessment_id == "asmt-1"
    assert result[0].value == 0.95

    # Check Feedback conversion
    assert isinstance(result[1], JudgeToolFeedback)
    assert result[1].name == "quality"
    assert result[1].rationale == "Good response"
    assert result[1].span_id == "span-2"
    assert result[1].assessment_id == "asmt-2"
    assert result[1].value == 4
    # Error fields should be None when no error
    assert result[1].error_code is None
    assert result[1].error_message is None
    assert result[1].stack_trace is None

    print(
        "PASS: C5 — _convert_assessments_to_tool_types converts Expectation and Feedback correctly"
    )


def check_c10_assessment_source_standardization():
    """C10: AssessmentSource.__post_init__ calls _standardize on construction."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="human", source_id="user-1")
    assert source.source_type == "HUMAN", (
        f"Expected 'HUMAN', got '{source.source_type}'"
    )
    assert source.source_id == "user-1"

    source2 = AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4")
    assert source2.source_type == "LLM_JUDGE"

    source3 = AssessmentSource(source_type="code", source_id="script.py")
    assert source3.source_type == "CODE"

    print("PASS: C10 — AssessmentSource standardizes source_type on construction")


def check_c11_get_experiment_id_valid():
    """C11: _get_experiment_id returns experiment_id for valid MLflow experiment trace."""
    from mlflow.entities.trace import Trace, TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    trace_info = TraceInfo(
        trace_id="test-trace-id",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-456"),
        ),
        request_time=1234567890,
        state=TraceState.OK,
        execution_duration=100,
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[]))

    exp_id = _get_experiment_id(trace)
    assert exp_id == "exp-456", f"Expected 'exp-456', got '{exp_id}'"

    print("PASS: C11 — _get_experiment_id returns experiment_id for valid trace")


def check_c12_assessment_source_to_string():
    """C12: Assessment source_type is used as string for JudgeTool types."""
    from mlflow.entities.assessment import Expectation
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import (
        _convert_assessments_to_tool_types,
    )

    exp = Expectation(
        name="test",
        source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
        value=True,
    )

    result = _convert_assessments_to_tool_types([exp])
    # The source field in JudgeToolExpectation should be the source_type string
    assert result[0].source == "LLM_JUDGE", (
        f"Expected 'LLM_JUDGE', got '{result[0].source}'"
    )

    print(
        "PASS: C12 — Assessment source_type is correctly mapped to JudgeTool type source field"
    )


def check_c13_assessment_source_equality():
    """C13a: AssessmentSource instances with same fields compare equal."""
    from mlflow.entities.assessment_source import AssessmentSource

    source1 = AssessmentSource(source_type="HUMAN", source_id="user_1")
    source2 = AssessmentSource(source_type="HUMAN", source_id="user_1")
    source3 = AssessmentSource(source_type="LLM_JUDGE", source_id="ai_1")
    source4 = AssessmentSource(source_type="HUMAN", source_id="user_2")

    # Same type and ID → equal
    assert source1 == source2, "Identical AssessmentSource instances should be equal"
    # Different type → not equal
    assert source1 != source3, "Different source_type should be unequal"
    # Same type, different ID → not equal
    assert source1 != source4, "Different source_id should be unequal"

    print("PASS: C13a — AssessmentSource equality works correctly")


def check_c13_assessment_source_serialization_roundtrip():
    """C13b: to_dictionary/from_dictionary round-trip reconstructs equal object."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="HUMAN", source_id="user_1")
    source_dict = source.to_dictionary()

    expected_dict = {
        "source_type": "HUMAN",
        "source_id": "user_1",
    }
    assert source_dict == expected_dict, (
        f"Expected {expected_dict}, got {source_dict}"
    )

    recreated_source = AssessmentSource.from_dictionary(source_dict)
    assert recreated_source == source, (
        "from_dictionary(to_dictionary()) should reconstruct an equal object"
    )

    # Verify the reconstructed object has correct normalized fields
    assert recreated_source.source_type == "HUMAN"
    assert recreated_source.source_id == "user_1"

    print("PASS: C13b — AssessmentSource to_dictionary/from_dictionary round-trip works")


if __name__ == "__main__":
    check_c1_name_returns_constant()
    check_c2_get_definition_schema()
    check_c3_invoke_connectivity()
    check_c5_convert_assessments()
    check_c10_assessment_source_standardization()
    check_c11_get_experiment_id_valid()
    check_c12_assessment_source_to_string()
    check_c13_assessment_source_equality()
    check_c13_assessment_source_serialization_roundtrip()
    print("\nAll architecture spec checks passed.")
