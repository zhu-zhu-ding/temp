# Requirement Compile Agent Skill

This is durable method guidance, not task evidence. Update it after compiling
each task with concise lessons about ambiguity, evidence gaps, and IR quality.

## Responsibilities

1. Treat the task as the authority for required behavior and use repository
   evidence only to locate compatible implementation paths and observers.
2. Lower prose into atomic L1 Requirement Obligations. Split independent
   behavior, failure, state, dataflow, and compatibility claims.
3. Build an L2 Functional Design Graph with only `CALL`, `CONTROL`, `DATA`,
   and `STATE` edges supported by source, callers, exports, or native tests.
4. Attach L3 Verifiable Contracts to graph nodes/edges. Every contract needs a
   typed relation, expected result, evidence, and explicit observation method.
5. Make observability first class: identify the public observer or runtime
   boundary where a future test can mechanically validate the contract.
6. Compile every contract into `arch_spec.py` or `behavior_spec.py`, preserving
   its contract ID and public-entry-to-observer path.

## Guardrails

- Write only the supplied executable spec artifacts; never production code or
  repository-native tests.
- Do not infer dataflow from symbol names or docstrings alone.
- Record unknowns explicitly rather than manufacturing exact defaults, errors,
  state values, or call arguments.
- Ensure each L1 obligation reaches at least one L3 contract through L2.

## Lessons

### L1: Interface Description stubs reveal implementation gaps
The interface descriptions in this task defined methods (e.g., `_standardize`)
that were called in the existing codebase (`AssessmentSource.__post_init__` L78)
but not yet implemented (blank lines L159-191). Always trace calls from existing
production code into described interfaces to detect holes. Evidence:
`/testbed/mlflow/entities/assessment_source.py` L78 calls `_standardize` but
the method body was empty.

### L2: Existing tool implementations are the best pattern reference
The `GetTracesInSession` tool (`get_traces_in_session.py`) already calls
`SearchTracesTool().invoke()`, establishing the expected signature and usage
pattern. Always look for existing callers of the target interface before
designing contracts. Evidence: `get_traces_in_session.py` L98-104.

### L3: Test files reveal expected behavior before implementation exists
`test_assessment_source.py` tests `AI_JUDGE` deprecation warnings and
case-insensitive normalization even though `_standardize` wasn't implemented.
Repository-native tests define the acceptance criteria; use them as the primary
evidence for behavior contracts. Evidence: `/testbed/tests/entities/test_assessment_source.py`.

### L4: Fluent vs client API — prefer the one already imported
`mlflow.search_traces` (fluent) is already imported in `search_traces.py` L11
(`import mlflow`). Avoid introducing `MlflowClient` when the fluent API is
already available and used by sibling tools like `GetTracesInSession`.
Evidence: `search_traces.py` L11.

### L5: Dataclass field types dictate conversion contracts
`JudgeToolExpectation.source` is typed as `str` but `Assessment.source` is an
`AssessmentSource` object. The converter must extract `source_type` from the
object to produce the string. Always check the target dataclass field types
before writing conversion contracts. Evidence: `types.py` L47 `source: str`
vs `assessment.py` `source: AssessmentSource`.

### L6: Graceful degradation requires logging verification
When the task states "logged as warnings and skipped," the observer for the
contract must include both RETURN_VALUE (incomplete list) and SIDE_EFFECT
(logger.warning). Mock the logger to verify both outcomes. Evidence: Task
statement "Traces that fail to process during retrieval are logged as
warnings and skipped."

### L7: Test exact string contracts, not substring presence
Native tests that use `pytest.warns(FutureWarning, match="...")` require exact
regex matches, not substring checks. When the repository already tests an exact
message, the spec must mirror that exactness. Using substring checks
(`"AI_JUDGE" in str(w[0].message)`) creates a weak contract that passes the
spec but fails the native test. Always read the native test's `match=` pattern
verbatim and replicate it in the spec observer. Evidence: RT1 /
`test_ai_judge_deprecation_warning` in
`/testbed/tests/entities/test_assessment_source.py:80-85`.

### L8: Unexecutable specs need real failure injection
When a spec check exercises an error-skip path but doesn't actually trigger
the error, the check is unexecutable — it passes regardless of whether the
skip logic works. Always inject a real failure (mock the helper to raise on
a specific input, or construct an input that genuinely fails the conversion)
and then assert both cardinality decrease AND side-effect (warning log).
Without real failure injection, the spec cannot distinguish "error was caught
and skipped" from "both items converted normally." Evidence: Finding 2 /
C9 original `check_c9_graceful_error_handling`.

### L9: Object-model contracts are obligations, not just dataclass defaults
Even when `__eq__` and `to_dictionary`/`from_dictionary` are inherited from
dataclass, native tests that verify them make them explicit requirements.
A faulty `__post_init__` or `_standardize` could break equality or
serialization. Include lightweight spec checks for these round-trips when the
native test suite already validates them. Evidence: RT4 / native tests
`test_assessment_source_equality` and `test_assessment_source_to_from_dictionary`.

### L10: Don't claim error codes that aren't verified
The IR originally claimed `INVALID_PARAMETER_VALUE` error code for
`_get_experiment_id` failures, but neither the task description nor any native
test verifies the error code. Only claim error codes when there is concrete
test evidence (e.g., a test checking `exc_info.value.error_code`). Otherwise,
keep the acceptance criterion at `MlflowException` with a descriptive message.
Evidence: Compile Checker Finding 4 note on R5.
<｜end▁of▁thinking｜>Now let me verify all three files were written correctly and check for consistency:

<｜｜DSML｜｜tool_calls>
<｜｜DSML｜｜invoke name="bash">
<｜｜DSML｜｜parameter name="command" string="true">cd /testbed && echo "=== IR checks ===" && grep -c '^### R' /agent-logs/codespec2/mlflow__mlflow.93dab383.test_judge_tool_search_traces.cad8fc4b.lv1_20260809_075639/artifacts/semantic_ir.md && grep -c '^### C' /agent-logs/codespec2/mlflow__mlflow.93dab383.test_judge_tool_search_traces.cad8fc4b.lv1_20260809_075639/artifacts/semantic_ir.md && echo "=== arch_spec checks ===" && grep -c 'def check_c' /agent-logs/codespec2/mlflow__mlflow.93dab383.test_judge_tool_search_traces.cad8fc4b.lv1_20260809_075639/artifacts/arch_spec.py && echo "=== behavior_spec checks ===" && grep -c 'def check_c' /agent-logs/codespec2/mlflow__mlflow.93dab383.test_judge_tool_search_traces.cad8fc4b.lv1_20260809_075639/artifacts/behavior_spec.py