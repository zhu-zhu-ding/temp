# Compile Checker Report

- Status: needs_revision

## Req-Test Evidence

### RT1: Assessment source type validation, case-insensitivity, and AI_JUDGE deprecation
- Test: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`
- Location: `tests/entities/test_assessment_source.py:37-47`
- Key Code:
  ```python
  def test_assessment_source_type_validation():
      # Valid source types
      AssessmentSource(source_type="HUMAN", source_id="user_1")
      AssessmentSource(source_type="LLM_JUDGE", source_id="judge_1")
      # Deprecated source type for backward compatibility
      source = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
      assert source.source_type == "LLM_JUDGE"
      # Invalid source type
      with pytest.raises(MlflowException, match="Invalid assessment source type"):
          AssessmentSource(source_type="ROBOT", source_id="robot_1")
  ```
- Test Lens: State validation — verifies valid types pass, AI_JUDGE is remapped to LLM_JUDGE, and invalid types raise MlflowException with a specific message pattern.
- Implied Requirement: `AssessmentSource.__post_init__` → `AssessmentSourceType._standardize` must (a) accept HUMAN/LLM_JUDGE, (b) remap AI_JUDGE → LLM_JUDGE, (c) raise `MlflowException` for unknown types with message containing "Invalid assessment source type".
- IR / Spec Mapping: R12, C19, C20, C21, C22. `check_C19`, `check_C20`, `check_C21`, `check_C22`.
- Verdict: weak — C21 checks for MlflowException and error_code but does not check that the exception message contains "Invalid assessment source type".

### RT2: AI_JUDGE deprecation warning exact message
- Test: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning`
- Location: `tests/entities/test_assessment_source.py:71-75`
- Key Code:
  ```python
  def test_ai_judge_deprecation_warning():
      with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
          source = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
      assert source.source_type == "LLM_JUDGE"
      assert source.source_id == "ai_1"
  ```
- Test Lens: Side-effect and message semantics — verifies that exactly a `FutureWarning` with the specific message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` is emitted, and the value is correctly remapped.
- Implied Requirement: The `_parse`/`_standardize` path must emit `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` when given "AI_JUDGE".
- IR / Spec Mapping: R12, C20. `check_C20_assessment_source_type_ai_judge_deprecation`.
- Verdict: weak — C20 only checks `issubclass(x.category, FutureWarning)` and does not verify the warning message matches the required string.

### RT3: Assessment source case-insensitivity normalization
- Test: `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity`
- Location: `tests/entities/test_assessment_source.py:49-66`
- Key Code:
  ```python
  def test_assessment_source_case_insensitivity():
      source_1 = AssessmentSource(source_type="human", source_id="user_1")
      source_2 = AssessmentSource(source_type="Human", source_id="user_2")
      source_3 = AssessmentSource(source_type="HUMAN", source_id="user_3")
      source_4 = AssessmentSource(source_type="llm_judge", source_id="judge_1")
      source_5 = AssessmentSource(source_type="Llm_Judge", source_id="judge_2")
      source_6 = AssessmentSource(source_type="LLM_JUDGE", source_id="judge_3")
      assert source_1.source_type == "HUMAN"
      assert source_2.source_type == "HUMAN"
      assert source_3.source_type == "HUMAN"
      assert source_4.source_type == "LLM_JUDGE"
      assert source_5.source_type == "LLM_JUDGE"
      assert source_6.source_type == "LLM_JUDGE"
  ```
- Test Lens: Data normalization — verifies case-insensitive inputs are normalized to uppercase. Tests six case variants across two source types.
- Implied Requirement: `_standardize`/`_parse` must uppercase inputs before validation.
- IR / Spec Mapping: R12, C19. `check_C19_assessment_source_type_init_str`.
- Verdict: covered — C19 tests "llm_judge"→"LLM_JUDGE", "HUMAN"→"HUMAN", "code"→"CODE", "source_type_unspecified"→"SOURCE_TYPE_UNSPECIFIED".

### RT4: Span inputs and outputs round-trip through serialization
- Test: `tests/entities/test_span.py::test_create_non_live_span`
- Location: `tests/entities/test_span.py:82-118`
- Key Code:
  ```python
  assert span.inputs == {"input": 1, "nested": {"foo": "bar"}}
  assert span.outputs == 2
  ```
- Test Lens: Data round-trip — verifies that inputs/outputs stored as JSON-serialized span attributes are correctly deserialized back to Python objects.
- Implied Requirement: `Span.inputs` and `Span.outputs` properties must deserialize values from `SpanAttributeKey.INPUTS`/`OUTPUTS` via `json.loads`.
- IR / Spec Mapping: R13, R14, C23, C24, C25, C26. `check_C23_span_inputs`, `check_C24_span_outputs`, `check_C25_span_inputs_none`, `check_C26_span_outputs_none`.
- Verdict: covered.

### RT5: assessment_to_proto integration through store layer
- Test: `tests/store/tracking/test_databricks_rest_store.py::test_create_assessment`
- Location: `tests/store/tracking/test_databricks_rest_store.py:1023-1082`
- Key Code:
  ```python
  res = store.create_assessment(assessment=feedback)
  _verify_requests(
      mock_http, creds,
      f"traces/catalog.schema/1234/assessments?sql_warehouse_id={sql_warehouse_id}",
      "POST",
      message_to_json(assessment_to_proto(feedback)),
      version="4.0",
  )
  assert isinstance(res, Feedback)
  ```
- Test Lens: Integration / serialization — verifies `assessment_to_proto` output is JSON-serializable via `message_to_json` and correctly embedded in an API request.
- Implied Requirement: `assessment_to_proto` must return a `pb.Assessment` (databricks_tracing_pb2) that is compatible with `message_to_json` for HTTP transmission.
- IR / Spec Mapping: R1, C1, C2. `check_C1_assessment_to_proto_full`, `check_C2_assessment_to_proto_minimal`.
- Verdict: covered — C1 checks proto fields in detail.

### RT6: trace_to_proto integration through store layer
- Test: `tests/store/tracking/test_databricks_rest_store.py::test_get_trace_info`
- Location: `tests/store/tracking/test_databricks_rest_store.py:205-239`
- Key Code:
  ```python
  mock_response = GetTraceInfo.Response(trace=trace_to_proto(trace))
  store = DatabricksTracingRestStore(lambda: MlflowHostCreds("https://test"))
  with mock.patch.object(store, "_call_endpoint", return_value=mock_response) as mock_call:
      result = store.get_trace_info(v4_trace_id)
      assert isinstance(result, TraceInfo)
  ```
- Test Lens: Integration / type compatibility — verifies `trace_to_proto` returns a proto that can construct `GetTraceInfo.Response` and round-trips through store.
- Implied Requirement: `trace_to_proto` must return `databricks_tracing_pb2.Trace` compatible with `GetTraceInfo.Response`.
- IR / Spec Mapping: R10, C15. `check_C15_trace_to_proto`.
- Verdict: covered.

## Findings

### Finding 1: C3 spec uses wrong protobuf type — unexecutable

- Category: unexecutable_spec
- Subrequirements: R2 (`get_trace_id_from_assessment_proto`)
- Evidence: The behavior spec at `/agent-logs/.../behavior_spec.py` function `check_C3_get_trace_id_from_assessment_proto_uc` (lines ~82-98) creates an `assessments_pb2.Assessment()` and sets `proto.trace_location.uc_schema.catalog_name = "mycat"`. But `assessments_pb2.Assessment` has no `trace_location` field (confirmed via `hasattr(assessments_pb2.Assessment(), 'trace_location')` → `False`). The `trace_location` field only exists on `databricks_tracing_pb2.Assessment` (aliased as `pb.Assessment`).
- Cause: The spec author used `assessments_pb2.Assessment()` instead of `pb.Assessment()` for a test case that requires the `trace_location` sub-message.
- Impact: `check_C3` will raise `AttributeError: 'Assessment' object has no attribute 'trace_location'` at execution time. The check is unexecutable, leaving R2's UC-schema path (the most critical path) without valid coverage.
- Required Change: In `check_C3_get_trace_id_from_assessment_proto_uc`, replace `assessments_pb2.Assessment()` with `pb.Assessment()` (i.e., `databricks_tracing_pb2.Assessment`). The corrected spec must exercise the UC-schema trace_id construction path end-to-end. A plausible wrong implementation that ignores `trace_location.uc_schema` and always returns `proto.trace_id` directly must be rejected by the corrected check.
- Req-Test Evidence: RT1 (the native test at `test_assessment_source.py:45` indirectly relies on `get_trace_id_from_assessment_proto` working correctly with UC schema protos, as called from `assessment.py:288,426`).

### Finding 2: C20 omits warning message match — weak_contract

- Category: weak_contract
- Subrequirements: R12 (`AssessmentSourceType` deprecation handling)
- Evidence: The native test `test_ai_judge_deprecation_warning` (`tests/entities/test_assessment_source.py:72`) uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`. The behavior spec's `check_C20_assessment_source_type_ai_judge_deprecation` only checks `issubclass(x.category, FutureWarning)` without verifying the message string.
- Cause: The contract check focuses on warning category but ignores message content, which the native test requires exactly.
- Impact: An implementation that emits `FutureWarning("AI_JUDGE is obsolete, switch to LLM_JUDGE")` would pass the generated spec but fail the native test. This creates a false sense of correctness.
- Required Change: In `check_C20_assessment_source_type_ai_judge_deprecation`, add an assertion that the captured warning message contains `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` (or match the exact string). The corrected check must reject an implementation that emits a differently-worded FutureWarning.
- Req-Test Evidence: RT2.

### Finding 3: C21 omits exception message check — weak_contract

- Category: weak_contract
- Subrequirements: R12 (`AssessmentSourceType` validation)
- Evidence: The native test `test_assessment_source_type_validation` (`tests/entities/test_assessment_source.py:46`) uses `pytest.raises(MlflowException, match="Invalid assessment source type")`. The behavior spec's `check_C21_assessment_source_type_invalid` only verifies `e.error_code == INVALID_PARAMETER_VALUE` but does not check the exception message.
- Cause: The contract check validates error code but not error message content.
- Impact: An implementation that raises `MlflowException("Bad type")` with the correct error code but wrong message would pass the spec but fail the native test.
- Required Change: In `check_C21_assessment_source_type_invalid`, add an assertion that `str(e)` or `e.message` contains `"Invalid assessment source type"`. The corrected check must reject an implementation with the right error code but wrong message text.
- Req-Test Evidence: RT1.

## Coverage

| R | Contracts | Spec Checks | Status |
|---|-----------|-------------|--------|
| R1 | C1, C2 | check_C1, check_C2 | covered |
| R2 | C3, C4 | check_C3 (broken), check_C4 | C3 needs fix |
| R3 | C5 | check_C5 | covered |
| R4 | C6 | check_C6 | covered |
| R5 | C7 | check_C7 | covered |
| R6 | C8, C9 | check_C8, check_C9 | covered |
| R7 | C10, C11 | check_C10, check_C11 | covered |
| R8 | C12, C13 | check_C12, check_C13 | covered |
| R9 | C14 | check_C14 | covered |
| R10 | C15 | check_C15 | covered |
| R11 | C16, C17 | check_C16, check_C17 | covered |
| R12 | C18, C19, C20, C21, C22 | check_C18, check_C19, check_C20 (weak), check_C21 (weak), check_C22 | C20/C21 need strengthening |
| R13 | C23, C25 | check_C23, check_C25 | covered |
| R14 | C24, C26 | check_C24, check_C26 | covered |

All 26 contracts have corresponding spec checks (15 in arch_spec, 11 in behavior_spec). No unreachable or unreferenced contracts.

## Judge Focus

Next-task check perspectives for revision:

1. **Proto type correctness in C3**: Verify that the test constructs `pb.Assessment()` (not `assessments_pb2.Assessment()`) when testing the UC-schema `trace_location` path. Run the check to confirm it doesn't AttributeError.

2. **Warning message precision in C20**: Strengthen the deprecation warning check to validate the exact message string `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`, matching the native test's `pytest.warns(..., match=...)` pattern.

3. **Exception message precision in C21**: Add message content assertion matching `"Invalid assessment source type"` as required by the native test.

4. **Round-trip confidence**: Verify C15 (`trace_to_proto`) can execute in the test environment (requires MLflow tracing infrastructure with a valid tracking URI). Consider whether `mlflow.set_tracking_uri` setup is needed.
