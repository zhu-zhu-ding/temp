# Requirement Compile Agent Skill

This is durable method guidance, not task evidence. Update it after compiling
each task with concise lessons about ambiguity, evidence gaps, and IR quality.

## Responsibilities

1. Treat the task as the authority for required behavior and use repository
   evidence only to locate compatible implementation paths and observers.
2. Lower prose into atomic L1 Requirement Obligations. Split independent
   behavior, failure, state, dataflow, and compatibility claims.
3. Build an L2 Functional Design Graph with only `CALL`, `CONTROL`, `DATA`,
   and `STATE` edges supported by source, callers, exports, or native tests.
4. Attach L3 Verifiable Contracts to graph nodes/edges. Every contract needs a
   typed relation, expected result, evidence, and explicit observation method.
5. Make observability first class: identify the public observer or runtime
   boundary where a future test can mechanically validate the contract.
6. Compile every contract into `arch_spec.py` or `behavior_spec.py`, preserving
   its contract ID and public-entry-to-observer path.

## Guardrails

- Write only the supplied executable spec artifacts; never production code or
  repository-native tests.
- Do not infer dataflow from symbol names or docstrings alone.
- Record unknowns explicitly rather than manufacturing exact defaults, errors,
  state values, or call arguments.
- Ensure each L1 obligation reaches at least one L3 contract through L2.

## Lessons

1. **Import-boundary tracing**: When a task describes functions that are
   already imported and called by repository code (e.g., in
   `databricks_rest_store.py`), grep for all call sites first. This reveals
   the exact function signatures expected, proto types used, and error
   handling patterns. Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py`
   calls `assessment_to_proto`, `trace_to_proto`, `trace_from_proto`, etc.
   without importing them — the import must be added or the functions must be
   importable from `mlflow.utils.databricks_tracing_utils`.

2. **Proto version disambiguation**: The codebase uses two proto systems: v3
   (`service_pb2`) and v4 (`databricks_tracing_pb2`). The task's interface
   descriptions reference `pb` as an alias for `databricks_tracing_pb2`. When
   functions like `trace_location_to_proto` are called, check which proto
   module the callers expect. Evidence: `databricks_rest_store.py` uses
   `databricks_tracing_pb2.TraceLocation` for v4 operations but
   `service_pb2.TraceLocation` for v3.

3. **Delegation patterns in existing code**: Functions like
   `TraceLocation.from_proto()` already delegate to `trace_location_from_proto`
   (imported from `databricks_tracing_utils`). Use this pattern to infer that
   the functions being specified are the v4-aware implementations that the
   existing entities delegate to. Evidence: `/testbed/mlflow/entities/trace_location.py:246`
   and `/testbed/mlflow/entities/trace_info.py:103`.

4. **Internal imports (deferred)**: The codebase uses deferred/lazy imports
   for `databricks_tracing_utils` functions (e.g., in `assessment.py:288`).
   The spec functions must be importable at module level but the
   implementation must handle circular import avoidance.

5. **Class with blank method bodies**: When a class like
   `AssessmentSourceType` has blank lines between class constants and
   existing methods, those blanks are placeholders for the methods described
   in the interface. Evidence: `/testbed/mlflow/entities/assessment_source.py`
   has `__init__`, `__str__`, `_parse`, and `_standardize` implicitly
   required by the interface description and by callers like
   `AssessmentSource.__post_init__`.

6. **Property gaps in entity classes**: The `Span` class has blank method
   bodies where `inputs` and `outputs` properties should be. These are
   described in Interface Description 3. Evidence:
   `/testbed/mlflow/entities/span.py` lines 155-167 (between `status` and
   `span_type` properties) and `TraceData.response` which accesses
   `SpanAttributeKey.OUTPUTS`.

7. **Test-driven signature discovery**: The test file
   `/testbed/tests/store/tracking/test_databricks_rest_store.py` imports
   `assessment_to_proto` and `trace_to_proto` directly from
   `mlflow.utils.databricks_tracing_utils`, confirming both the module path
   and the expected signatures. Always check test files for usage patterns.

8. **Proto type field availability varies between proto modules**:
   `assessments_pb2.Assessment` does NOT have a `trace_location` field,
   while `databricks_tracing_pb2.Assessment` (aliased as `pb.Assessment`)
   DOES. When writing spec checks that exercise UC-schema trace_location
   paths, you MUST construct `pb.Assessment()` (databricks_tracing_pb2),
   never `assessments_pb2.Assessment()`. The `get_trace_id_from_assessment_proto`
   function accepts both types, but the UC-schema path is only exercisable
   with the v4 proto type. Always verify field existence with `hasattr()`
   or `DESCRIPTOR.fields` before writing spec code. Evidence: Finding 1 in
   the Compile Checker report — C3 used `assessments_pb2.Assessment()` and
   would raise `AttributeError` at runtime.

9. **Warning message exactness matters**: When native tests use
   `pytest.warns(FutureWarning, match="exact string")`, the spec check MUST
   verify the warning message string, not just the warning category. A spec
   that only checks `issubclass(x.category, FutureWarning)` is too weak and
   would accept a differently-worded warning that the native test would
   reject. Always grep native tests for `match=` arguments in
   `pytest.warns` and `pytest.raises` and replicate those exact string
   constraints in spec assertions. Evidence: Finding 2 — C20 checked only
   the warning category, missing the required message
   `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`.

10. **Exception message content is part of the contract**: When native tests
    use `pytest.raises(MlflowException, match="pattern")`, the exception
    message is a verifiable contract obligation, not just the error code.
    Spec checks must assert `match_string in str(exception)` in addition to
    checking `error_code`. Evidence: Finding 3 — C21 checked only
    `error_code == INVALID_PARAMETER_VALUE` but not that the message
    contains `"Invalid assessment source type"`.

11. **Compile Checker feedback is diagnostic gold**: The Compile Checker
    cross-references native test assertions (RT evidence) against spec
    contract checks. Every `weak_contract` or `unexecutable_spec` finding
    identifies a concrete gap where the spec would pass an incorrect
    implementation. Prioritize these over self-review; they are grounded in
    actual test code that will run against the final implementation.
