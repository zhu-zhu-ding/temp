"""
Architecture spec: exercises public entry points and L2 CALL/CONTROL/DATA
connectivity. Validates that the function call graph is wired correctly:
delegation, dispatch, import boundaries, and data flow between layers.

Contracts: C1, C5, C6, C7, C8, C10, C12, C14, C15, C16, C18, C19, C22, C23, C24
"""

import sys
import os
import warnings

# Ensure /testbed is on path
sys.path.insert(0, "/testbed")

import mlflow
from mlflow.entities import (
    Assessment,
    AssessmentSource,
    AssessmentSourceType,
    Expectation,
    Feedback,
    Trace,
    TraceData,
    TraceInfo,
    TraceLocation,
    TraceLocationType,
    MlflowExperimentLocation,
    InferenceTableLocation,
    UCSchemaLocation,
    Span,
)
from mlflow.entities.trace_state import TraceState
from mlflow.protos import databricks_tracing_pb2 as pb
from mlflow.protos import assessments_pb2
from mlflow.tracing.constant import TRACE_ID_V4_PREFIX
from mlflow.tracing.utils import construct_trace_id_v4, parse_trace_id_v4
from mlflow.utils.databricks_tracing_utils import (
    assessment_to_proto,
    get_trace_id_from_assessment_proto,
    inference_table_location_to_proto,
    mlflow_experiment_location_to_proto,
    uc_schema_location_to_proto,
    uc_schema_location_from_proto,
    trace_location_to_proto,
    trace_location_from_proto,
    trace_to_proto,
    trace_from_proto,
    trace_info_to_v4_proto,
)


def check_C1_assessment_to_proto_full():
    """C1: Fully-populated Feedback Assessment → pb.Assessment with all fields."""
    source = AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="gpt-4")
    feedback = Feedback(
        name="test_assessment",
        source=source,
        trace_id="trace:/catalog.schema/tr-abc123",
        span_id="span-001",
        rationale="This is a rationale",
        metadata={"model": "gpt-4o-mini", "score": "0.95"},
        value="good",
    )
    feedback.assessment_id = "a-test123"
    feedback.create_time_ms = 1700000000000
    feedback.last_update_time_ms = 1700000001000

    proto = assessment_to_proto(feedback)

    # Basic fields
    assert proto.assessment_name == "test_assessment", f"name mismatch: {proto.assessment_name}"
    assert proto.source.source_type == assessments_pb2.AssessmentSource.LLM_JUDGE, \
        f"source_type mismatch: {proto.source.source_type}"
    assert proto.source.source_id == "gpt-4"

    # Timestamps
    assert proto.create_time.ToMilliseconds() == 1700000000000
    assert proto.last_update_time.ToMilliseconds() == 1700000001000

    # Optional fields
    assert proto.span_id == "span-001"
    assert proto.rationale == "This is a rationale"
    assert proto.assessment_id == "a-test123"

    # Trace location for UC schema
    assert proto.HasField("trace_location"), "trace_location should be set for UC schema trace_id"
    assert proto.trace_location.HasField("uc_schema"), \
        "uc_schema should be set in trace_location"
    assert proto.trace_location.uc_schema.catalog_name == "catalog"
    assert proto.trace_location.uc_schema.schema_name == "schema"

    # Feedback (oneof value)
    assert proto.HasField("feedback"), "feedback should be set"
    assert not proto.HasField("expectation"), "expectation should NOT be set"

    # Metadata as string key-value
    assert len(proto.metadata) == 2
    meta_dict = {m.key: m.value for m in proto.metadata}
    assert meta_dict["model"] == "gpt-4o-mini"
    assert meta_dict["score"] == "0.95"

    print("PASS: C1 — assessment_to_proto full Feedback conversion")


def check_C5_inference_table_location_to_proto():
    """C5: InferenceTableLocation → pb.InferenceTableLocation."""
    loc = InferenceTableLocation(full_table_name="my_catalog.my_schema.my_table")
    proto = inference_table_location_to_proto(loc)
    assert proto.full_table_name == "my_catalog.my_schema.my_table"
    print("PASS: C5 — inference_table_location_to_proto")


def check_C6_mlflow_experiment_location_to_proto():
    """C6: MlflowExperimentLocation → pb.MlflowExperimentLocation."""
    loc = MlflowExperimentLocation(experiment_id="exp-456")
    proto = mlflow_experiment_location_to_proto(loc)
    assert proto.experiment_id == "exp-456"
    print("PASS: C6 — mlflow_experiment_location_to_proto")


def check_C7_uc_schema_location_to_proto():
    """C7: UCSchemaLocation → pb.UCSchemaLocation."""
    loc = UCSchemaLocation(catalog_name="catalog", schema_name="schema")
    proto = uc_schema_location_to_proto(loc)
    assert proto.catalog_name == "catalog"
    assert proto.schema_name == "schema"
    assert proto.otel_spans_table_name
    assert proto.otel_logs_table_name
    print("PASS: C7 — uc_schema_location_to_proto")


def check_C8_uc_schema_location_from_proto():
    """C8: pb.UCSchemaLocation → UCSchemaLocation with full fields."""
    proto = pb.UCSchemaLocation(
        catalog_name="cat",
        schema_name="sch",
        otel_spans_table_name="custom_spans",
        otel_logs_table_name="custom_logs",
    )
    entity = uc_schema_location_from_proto(proto)
    assert entity.catalog_name == "cat"
    assert entity.schema_name == "sch"
    assert entity._otel_spans_table_name == "custom_spans"
    assert entity._otel_logs_table_name == "custom_logs"
    print("PASS: C8 — uc_schema_location_from_proto full")


def check_C10_trace_location_to_proto_dispatch():
    """C10: trace_location_to_proto dispatches correctly for each type."""
    # UC_SCHEMA
    tl_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    proto_uc = trace_location_to_proto(tl_uc)
    assert proto_uc.type == pb.TraceLocation.UC_SCHEMA
    assert proto_uc.HasField("uc_schema")
    assert proto_uc.uc_schema.catalog_name == "cat"

    # MLFLOW_EXPERIMENT
    tl_exp = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-1"),
    )
    proto_exp = trace_location_to_proto(tl_exp)
    assert proto_exp.type == pb.TraceLocation.MLFLOW_EXPERIMENT
    assert proto_exp.HasField("mlflow_experiment")
    assert proto_exp.mlflow_experiment.experiment_id == "exp-1"

    # INFERENCE_TABLE
    tl_inf = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="cat.sch.tbl"),
    )
    proto_inf = trace_location_to_proto(tl_inf)
    assert proto_inf.type == pb.TraceLocation.INFERENCE_TABLE
    assert proto_inf.HasField("inference_table")
    assert proto_inf.inference_table.full_table_name == "cat.sch.tbl"

    print("PASS: C10 — trace_location_to_proto dispatch for all types")


def check_C12_trace_location_from_proto_dispatch():
    """C12: trace_location_from_proto dispatches correctly for each type."""
    # MLFLOW_EXPERIMENT
    proto_exp = pb.TraceLocation(
        type=pb.TraceLocation.MLFLOW_EXPERIMENT,
        mlflow_experiment=pb.MlflowExperimentLocation(experiment_id="exp-1"),
    )
    entity_exp = trace_location_from_proto(proto_exp)
    assert entity_exp.type == TraceLocationType.MLFLOW_EXPERIMENT
    assert entity_exp.mlflow_experiment is not None
    assert entity_exp.mlflow_experiment.experiment_id == "exp-1"

    # INFERENCE_TABLE
    proto_inf = pb.TraceLocation(
        type=pb.TraceLocation.INFERENCE_TABLE,
        inference_table=pb.InferenceTableLocation(full_table_name="cat.sch.tbl"),
    )
    entity_inf = trace_location_from_proto(proto_inf)
    assert entity_inf.type == TraceLocationType.INFERENCE_TABLE
    assert entity_inf.inference_table is not None
    assert entity_inf.inference_table.full_table_name == "cat.sch.tbl"

    # UC_SCHEMA
    proto_uc = pb.TraceLocation(
        type=pb.TraceLocation.UC_SCHEMA,
        uc_schema=pb.UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    entity_uc = trace_location_from_proto(proto_uc)
    assert entity_uc.type == TraceLocationType.UC_SCHEMA
    assert entity_uc.uc_schema is not None
    assert entity_uc.uc_schema.catalog_name == "cat"
    assert entity_uc.uc_schema.schema_name == "sch"

    print("PASS: C12 — trace_location_from_proto dispatch for all types")


def check_C14_trace_from_proto():
    """C14: pb.Trace → MLflow Trace entity."""
    # Build a minimal pb.Trace
    trace_info_proto = pb.TraceInfo(
        trace_id="tr-test-123",
        request_time=pb.Timestamp(),
        state=pb.TraceInfo.OK,
        trace_location=pb.TraceLocation(
            type=pb.TraceLocation.MLFLOW_EXPERIMENT,
            mlflow_experiment=pb.MlflowExperimentLocation(experiment_id="0"),
        ),
    )
    trace_info_proto.request_time.FromMilliseconds(1700000000000)

    proto_trace = pb.Trace(trace_info=trace_info_proto, spans=[])

    trace = trace_from_proto(proto_trace, location_id="test-location")
    assert isinstance(trace, Trace)
    assert isinstance(trace.info, TraceInfo)
    assert isinstance(trace.data, TraceData)
    assert trace.info.trace_id == "tr-test-123"

    print("PASS: C14 — trace_from_proto")


def check_C15_trace_to_proto():
    """C15: MLflow Trace → pb.Trace."""
    with mlflow.start_span(name="test_span") as span:
        span.set_inputs({"x": 1})

    original_trace = mlflow.get_trace(span.trace_id)

    proto = trace_to_proto(original_trace)
    assert isinstance(proto, pb.Trace)
    assert proto.HasField("trace_info")
    assert len(proto.spans) > 0

    print("PASS: C15 — trace_to_proto")


def check_C16_trace_info_to_v4_proto_uc():
    """C16: TraceInfo with UC schema → pb.TraceInfo with parsed trace_id."""
    uc_loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    tl = TraceLocation(type=TraceLocationType.UC_SCHEMA, uc_schema=uc_loc)

    v4_trace_id = f"{TRACE_ID_V4_PREFIX}cat.sch/tr-inner-123"
    info = TraceInfo(
        trace_id=v4_trace_id,
        trace_location=tl,
        request_time=1700000000000,
        state=TraceState.OK,
    )

    proto = trace_info_to_v4_proto(info)
    # trace_id should be parsed — no v4 prefix
    assert TRACE_ID_V4_PREFIX not in proto.trace_id, \
        f"Expected parsed trace_id without v4 prefix, got: {proto.trace_id}"
    assert proto.trace_id == "tr-inner-123"
    assert proto.trace_location.HasField("uc_schema")
    assert proto.trace_location.uc_schema.catalog_name == "cat"

    print("PASS: C16 — trace_info_to_v4_proto with UC schema")


def check_C18_assessment_source_type_constants():
    """C18: AssessmentSourceType constants are plain strings."""
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"
    assert AssessmentSourceType.CODE == "CODE"
    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert isinstance(AssessmentSourceType.HUMAN, str)
    print("PASS: C18 — AssessmentSourceType constants are strings")


def check_C19_assessment_source_type_init_str():
    """C19: AssessmentSourceType instance creation and stringification."""
    assert str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"
    assert str(AssessmentSourceType("HUMAN")) == "HUMAN"
    assert str(AssessmentSourceType("code")) == "CODE"
    assert str(AssessmentSourceType("source_type_unspecified")) == "SOURCE_TYPE_UNSPECIFIED"
    print("PASS: C19 — AssessmentSourceType init and str")


def check_C22_assessment_source_type_standardize():
    """C22: _standardize static method."""
    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("code") == "CODE"

    # AI_JUDGE deprecation
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        assert result == "LLM_JUDGE"
        assert len(w) >= 1
        assert issubclass(w[0].category, FutureWarning)

    print("PASS: C22 — _standardize static method")


def check_C23_span_inputs():
    """C23: Span.inputs property returns deserialized inputs."""
    with mlflow.start_span(name="input_test") as span:
        span.set_inputs({"query": "hello", "temperature": 0.7})

    trace = mlflow.get_trace(span.trace_id)
    retrieved_span = trace.data.spans[0]
    inputs = retrieved_span.inputs
    assert inputs is not None
    assert inputs.get("query") == "hello"
    assert inputs.get("temperature") == 0.7
    print("PASS: C23 — Span.inputs property")


def check_C24_span_outputs():
    """C24: Span.outputs property returns deserialized outputs."""
    with mlflow.start_span(name="output_test") as span:
        span.set_outputs({"result": "success", "confidence": 0.99})

    trace = mlflow.get_trace(span.trace_id)
    retrieved_span = trace.data.spans[0]
    outputs = retrieved_span.outputs
    assert outputs is not None
    assert outputs.get("result") == "success"
    assert outputs.get("confidence") == 0.99
    print("PASS: C24 — Span.outputs property")


if __name__ == "__main__":
    check_C1_assessment_to_proto_full()
    check_C5_inference_table_location_to_proto()
    check_C6_mlflow_experiment_location_to_proto()
    check_C7_uc_schema_location_to_proto()
    check_C8_uc_schema_location_from_proto()
    check_C10_trace_location_to_proto_dispatch()
    check_C12_trace_location_from_proto_dispatch()
    check_C14_trace_from_proto()
    check_C15_trace_to_proto()
    check_C16_trace_info_to_v4_proto_uc()
    check_C18_assessment_source_type_constants()
    check_C19_assessment_source_type_init_str()
    check_C22_assessment_source_type_standardize()
    check_C23_span_inputs()
    check_C24_span_outputs()
