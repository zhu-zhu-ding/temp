"""
Behavior spec: exercises outcomes, state, failure, side effects, defaults,
boundaries, and compatibility. Focused on round-trip integrity, edge cases,
error paths, and backward compatibility.

Contracts: C2, C3, C4, C9, C11, C13, C17, C20, C21, C25, C26
"""

import sys
import os
import warnings
import time

sys.path.insert(0, "/testbed")

import mlflow
from mlflow.entities import (
    Assessment,
    AssessmentSource,
    AssessmentSourceType,
    Expectation,
    Feedback,
    Trace,
    TraceData,
    TraceInfo,
    TraceLocation,
    TraceLocationType,
    MlflowExperimentLocation,
    InferenceTableLocation,
    UCSchemaLocation,
    Span,
)
from mlflow.entities.trace_state import TraceState
from mlflow.exceptions import MlflowException
from mlflow.protos import databricks_tracing_pb2 as pb
from mlflow.protos import assessments_pb2
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.tracing.constant import TRACE_ID_V4_PREFIX
from mlflow.tracing.utils import construct_trace_id_v4
from mlflow.utils.databricks_tracing_utils import (
    assessment_to_proto,
    get_trace_id_from_assessment_proto,
    inference_table_location_to_proto,
    mlflow_experiment_location_to_proto,
    uc_schema_location_to_proto,
    uc_schema_location_from_proto,
    trace_location_to_proto,
    trace_location_from_proto,
    trace_to_proto,
    trace_from_proto,
    trace_info_to_v4_proto,
)


def check_C2_assessment_to_proto_minimal():
    """C2: Minimal Assessment → pb.Assessment with only required fields, optionals omitted."""
    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="user1")
    assessment = Assessment(
        name="minimal_assessment",
        source=source,
        trace_id="tr-minimal-123",
        create_time_ms=1700000000000,
        last_update_time_ms=1700000001000,
    )

    proto = assessment_to_proto(assessment)

    # Required fields present
    assert proto.assessment_name == "minimal_assessment"
    assert proto.source.source_type == assessments_pb2.AssessmentSource.HUMAN

    # Optional fields should be empty/not set
    assert proto.span_id == "" or not proto.HasField("span_id") or proto.span_id == ""
    assert proto.rationale == "" or not proto.HasField("rationale") or proto.rationale == ""
    assert not proto.HasField("feedback")
    assert not proto.HasField("expectation")

    # valid should default to True
    assert proto.valid is True or proto.valid is None  # proto3 defaults

    print("PASS: C2 — assessment_to_proto minimal assessment, optionals omitted")


def check_C3_get_trace_id_from_assessment_proto_uc():
    """C3: Assessment proto with UC schema → v4 trace ID.

    MUST use pb.Assessment (databricks_tracing_pb2), NOT assessments_pb2.Assessment,
    because only databricks_tracing_pb2.Assessment has the trace_location field.
    """
    proto = pb.Assessment()
    proto.trace_id = "tr-inner-456"
    proto.assessment_name = "test"
    proto.source.source_type = assessments_pb2.AssessmentSource.HUMAN
    proto.trace_location.uc_schema.catalog_name = "mycat"
    proto.trace_location.uc_schema.schema_name = "myschema"

    result = get_trace_id_from_assessment_proto(proto)
    assert result.startswith(TRACE_ID_V4_PREFIX), f"Expected v4 prefix, got: {result}"
    assert "mycat.myschema" in result
    assert "tr-inner-456" in result

    print("PASS: C3 — get_trace_id_from_assessment_proto with UC schema")


def check_C4_get_trace_id_from_assessment_proto_no_uc():
    """C4: Assessment proto without UC schema → raw trace_id."""
    proto = assessments_pb2.Assessment()
    proto.trace_id = "tr-raw-789"
    proto.assessment_name = "test"
    proto.source.source_type = assessments_pb2.AssessmentSource.HUMAN

    result = get_trace_id_from_assessment_proto(proto)
    assert result == "tr-raw-789", f"Expected raw trace_id, got: {result}"

    print("PASS: C4 — get_trace_id_from_assessment_proto without UC schema")


def check_C9_uc_schema_location_from_proto_minimal():
    """C9: pb.UCSchemaLocation with only catalog/schema → UCSchemaLocation with defaults."""
    proto = pb.UCSchemaLocation(
        catalog_name="cat2",
        schema_name="sch2",
    )
    # Don't set table names
    entity = uc_schema_location_from_proto(proto)
    assert entity.catalog_name == "cat2"
    assert entity.schema_name == "sch2"
    # Default table names should be present (from dataclass defaults)
    assert entity._otel_spans_table_name is not None
    assert entity._otel_logs_table_name is not None

    print("PASS: C9 — uc_schema_location_from_proto minimal")


def check_C11_trace_location_to_proto_value_error():
    """C11: trace_location_to_proto raises ValueError for unsupported type."""
    tl = TraceLocation(
        type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED,
    )
    try:
        trace_location_to_proto(tl)
        assert False, "Should have raised ValueError"
    except ValueError:
        pass  # Expected

    print("PASS: C11 — trace_location_to_proto ValueError for unsupported type")


def check_C13_trace_location_from_proto_unspecified():
    """C13: Proto with no identifier → TRACE_LOCATION_TYPE_UNSPECIFIED."""
    proto = pb.TraceLocation(
        type=pb.TraceLocation.TRACE_LOCATION_TYPE_UNSPECIFIED,
    )
    entity = trace_location_from_proto(proto)
    assert entity.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED

    print("PASS: C13 — trace_location_from_proto unspecified fallback")


def check_C17_trace_info_to_v4_proto_non_uc():
    """C17: TraceInfo with MLflow experiment → pb.TraceInfo with raw trace_id."""
    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-99"),
    )
    info = TraceInfo(
        trace_id="tr-raw-non-uc-001",
        trace_location=tl,
        request_time=1700000000000,
        state=TraceState.OK,
        request_preview='{"input": "hello"}',
        response_preview='{"output": "world"}',
    )

    proto = trace_info_to_v4_proto(info)
    # trace_id used as-is
    assert proto.trace_id == "tr-raw-non-uc-001"
    assert proto.trace_location.HasField("mlflow_experiment")
    assert proto.trace_location.mlflow_experiment.experiment_id == "exp-99"

    print("PASS: C17 — trace_info_to_v4_proto non-UC location")


def check_C20_assessment_source_type_ai_judge_deprecation():
    """C20: AI_JUDGE → LLM_JUDGE with FutureWarning when creating instance.

    The native test requires the exact warning message:
    "AI_JUDGE is deprecated. Use LLM_JUDGE instead."
    """
    expected_warning_msg = "AI_JUDGE is deprecated. Use LLM_JUDGE instead."

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        ast = AssessmentSourceType("AI_JUDGE")
        result = str(ast)
        assert result == "LLM_JUDGE", f"Expected LLM_JUDGE, got: {result}"
        # Should have at least one FutureWarning with exact message
        future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        assert len(future_warnings) >= 1, "Expected FutureWarning for AI_JUDGE"
        # Verify the exact deprecation message
        warning_messages = [str(x.message) for x in future_warnings]
        assert any(expected_warning_msg == msg for msg in warning_messages), \
            f"Expected warning message '{expected_warning_msg}', got: {warning_messages}"

    # Also check via _standardize
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        assert result == "LLM_JUDGE"
        future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        assert len(future_warnings) >= 1
        warning_messages = [str(x.message) for x in future_warnings]
        assert any(expected_warning_msg == msg for msg in warning_messages)

    print("PASS: C20 — AI_JUDGE deprecation with FutureWarning and exact message")


def check_C21_assessment_source_type_invalid():
    """C21: Invalid source type raises MlflowException with INVALID_PARAMETER_VALUE
    and message containing 'Invalid assessment source type'."""
    try:
        AssessmentSourceType("INVALID_TYPE")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert e.error_code == INVALID_PARAMETER_VALUE or "INVALID_PARAMETER_VALUE" in str(e.error_code), \
            f"Unexpected error code: {e.error_code}"
        assert "Invalid assessment source type" in str(e), \
            f"Expected message containing 'Invalid assessment source type', got: {e}"

    # Also check _standardize
    try:
        AssessmentSourceType._standardize("NONEXISTENT")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert e.error_code == INVALID_PARAMETER_VALUE or "INVALID_PARAMETER_VALUE" in str(e.error_code)
        assert "Invalid assessment source type" in str(e), \
            f"Expected message containing 'Invalid assessment source type', got: {e}"

    print("PASS: C21 — invalid source type raises MlflowException with correct message")


def check_C25_span_inputs_none():
    """C25: Span.inputs returns None when no inputs were set."""
    with mlflow.start_span(name="no_input_span") as span:
        pass  # Don't set inputs

    trace = mlflow.get_trace(span.trace_id)
    retrieved_span = trace.data.spans[0]
    result = retrieved_span.inputs
    assert result is None, f"Expected None, got: {result}"

    print("PASS: C25 — Span.inputs returns None when not set")


def check_C26_span_outputs_none():
    """C26: Span.outputs returns None when no outputs were set."""
    with mlflow.start_span(name="no_output_span") as span:
        pass  # Don't set outputs

    trace = mlflow.get_trace(span.trace_id)
    retrieved_span = trace.data.spans[0]
    result = retrieved_span.outputs
    assert result is None, f"Expected None, got: {result}"

    print("PASS: C26 — Span.outputs returns None when not set")


if __name__ == "__main__":
    check_C2_assessment_to_proto_minimal()
    check_C3_get_trace_id_from_assessment_proto_uc()
    check_C4_get_trace_id_from_assessment_proto_no_uc()
    check_C9_uc_schema_location_from_proto_minimal()
    check_C11_trace_location_to_proto_value_error()
    check_C13_trace_location_from_proto_unspecified()
    check_C17_trace_info_to_v4_proto_non_uc()
    check_C20_assessment_source_type_ai_judge_deprecation()
    check_C21_assessment_source_type_invalid()
    check_C25_span_inputs_none()
    check_C26_span_outputs_none()
