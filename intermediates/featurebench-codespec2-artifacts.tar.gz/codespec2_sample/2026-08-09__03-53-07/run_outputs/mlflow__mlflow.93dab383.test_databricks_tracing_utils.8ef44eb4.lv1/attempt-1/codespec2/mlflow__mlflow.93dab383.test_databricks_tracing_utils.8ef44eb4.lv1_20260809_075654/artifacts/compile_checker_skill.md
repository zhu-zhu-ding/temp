# Compile Checker Agent Skill

This is a durable review rubric for judging IR-to-spec compilation. It is not
task evidence. Preserve the base rubric and append concise, generalizable
lessons after each checker run.

## Base Rubric

1. Requirement completeness: split explicit requirements and native-test
   implications into atomic, non-invented obligations.
2. Repository fidelity: each graph node/edge and fixture comes from a real
   public API, caller, constructor, field, or test-supported path.
3. Contract strength: every contract has a distinguishable wrong implementation
   that its check would fail, not only an import/type/symbol assertion.
4. Observation quality: validate actual arguments, returned fields, state,
   exception semantics, or side effects at the contract target.
5. Compatibility: inspect defaults, signatures, aliases, import/export paths,
   serialization round trips, lifecycle invariants, and existing callers.
6. Collection semantics: inspect cardinality, ordering, deduplication,
   aggregation, and partial-failure survival whenever collections/logs/results
   are involved.
7. Spec execution: each C is referenced, each check is called, and at least one
   check reaches a public entry and a real observer for every R.
8. Req-test synthesis: search for tests from task terms and every relevant
   public entry/module/graph symbol. For each material assertion, preserve a
   short exact code excerpt, its `path::test_name` location, the test lens, and
   the implied contract before judging generated IR/spec coverage. Never claim
   a native-test implication without a real test excerpt, unless explicitly
   marked as task/source-only evidence.
9. Test-lens coverage: classify native tests by API/default/signature,
   dataflow/argument forwarding, lifecycle/state, error/message, side-effect
   count/order, collection cardinality/order/partial success, compatibility/
   round trip, and fixture/object-model fidelity. Judge whether generated specs
   cover the material lenses, not just whether they mention the same symbols.
10. Counterfactual strength: for each important native-test lens, identify the
    smallest plausible regression (wrong default, dropped argument, changed
    branch, reordered/filtered item, altered exception, or fake fixture) and
    require an executable generated check that would fail it. Native tests'
    real construction paths take precedence over dynamically fabricated fields
    or mocks of repository dispatchers.

## Lessons

Append short, evidence-linked rubric additions here.

## Lessons from this run

1. **Proto type compatibility**: When a function accepts multiple proto types (e.g., `pb.Assessment | assessments_pb2.Assessment`), spec checks must use the proto type that actually has the fields being tested. `assessments_pb2.Assessment` lacks `trace_location`; only `databricks_tracing_pb2.Assessment` carries it. Always verify field existence on the specific proto class before writing the check.

2. **Warning/exception message specificity**: Native tests often use `pytest.warns(FutureWarning, match="...")` or `pytest.raises(MlflowException, match="...")` with exact message strings. Generated specs must validate message content, not just exception/warning category, or they create a false-positive gap.

3. **Cross-module import verification**: Functions called in production code (e.g., `trace_info_to_v4_proto` in `trace_info.py`, `trace_location_from_proto` in `trace_location.py`) may lack their imports if the implementation module doesn't exist yet. The IR must note these missing imports as implementation prerequisites; the spec cannot test them directly but the checker should flag them as graph-edge prerequisites.
