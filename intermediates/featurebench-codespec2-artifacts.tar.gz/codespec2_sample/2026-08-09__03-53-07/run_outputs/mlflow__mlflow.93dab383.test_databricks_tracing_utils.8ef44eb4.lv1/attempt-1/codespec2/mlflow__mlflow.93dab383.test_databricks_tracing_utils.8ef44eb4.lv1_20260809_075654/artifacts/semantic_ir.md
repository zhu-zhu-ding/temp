# Semantic IR: MLflow Tracing and Assessment Data Management

## L1. Requirement Obligations

### R1
- **Type**: Behavior / Dataflow
- **Statement**: `assessment_to_proto` shall convert an `Assessment` entity into a `pb.Assessment` protobuf message, populating all fields including name, trace_id, source, timestamps (converted from ms to protobuf Timestamp via `FromMilliseconds`), span_id, rationale, assessment_id, expectation/feedback (mutually exclusive), metadata (values converted to string), overrides, and valid flag.
- **Task Evidence**: Interface Description 1, `assessment_to_proto` docstring: "Convert an Assessment entity to its corresponding protobuf representation… The function automatically parses the trace_id to extract location information and constructs the appropriate trace_location proto field for UC Schema locations… Timestamps are converted from milliseconds… Metadata values are converted to strings… Either expectation or feedback will be set…"
- **Acceptance**: For a valid Assessment with all optional fields set, the returned proto has every field correctly populated; for UC Schema trace_ids, the trace_location field is constructed; none fields are omitted.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment.py` defines `Assessment.to_proto()` which already does a similar conversion but using `assessments_pb2.Assessment`. The new function must use `databricks_tracing_pb2.Assessment` (aliased as `pb.Assessment`) and additionally handle trace_location extraction from trace_id. Caller: `/testbed/mlflow/store/tracking/databricks_rest_store.py:511`.
- **Uncertainty**: Whether `valid` defaults to `True` in proto when `assessment.valid` is None (as in `assessments_pb2` proto definition `:true` default). The interface doc says "handles None values gracefully by only setting proto fields when the corresponding assessment fields are not None".

### R2
- **Type**: Behavior / Dataflow
- **Statement**: `get_trace_id_from_assessment_proto` shall extract the trace ID from an assessment protobuf object, handling UC schema locations by constructing a v4 trace ID via `construct_trace_id_v4`, and returning raw trace_id for other location types.
- **Task Evidence**: Interface Description 1, `get_trace_id_from_assessment_proto` docstring: "For assessments with UC (Unity Catalog) schema locations, it constructs a v4 trace ID by combining the catalog/schema information with the trace ID. For other location types, it returns the trace ID directly."
- **Acceptance**: When proto has `trace_location.uc_schema` set, returns `construct_trace_id_v4(location, trace_id)`; otherwise returns `proto.trace_id` directly. The UC-schema path requires `databricks_tracing_pb2.Assessment` (aliased `pb.Assessment`) because only that proto type carries the `trace_location` sub-message; `assessments_pb2.Assessment` does NOT have `trace_location`.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment.py:288` and `:426` call this function via `from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto`. The companion `construct_trace_id_v4` is in `/testbed/mlflow/tracing/utils/__init__.py`.
- **Uncertainty**: Whether the `uc_schema` check uses `HasField` or direct attribute access; the proto is `databricks_tracing_pb2.Assessment` which has a `trace_location` field with a `uc_schema` oneof.

### R3
- **Type**: Behavior / Dataflow
- **Statement**: `inference_table_location_to_proto` shall convert an `InferenceTableLocation` entity to `pb.InferenceTableLocation` protobuf, mapping `full_table_name` directly.
- **Task Evidence**: Interface Description 1, docstring: "extracting the full_table_name attribute and setting it in the corresponding protobuf field."
- **Acceptance**: Returns `pb.InferenceTableLocation(full_table_name=entity.full_table_name)`.
- **Repository Evidence**: `/testbed/mlflow/entities/trace_location.py` defines `InferenceTableLocation` with `full_table_name: str`. Caller: `/testbed/mlflow/store/tracking/databricks_rest_store.py` uses `trace_location_to_proto` which delegates to this.
- **Uncertainty**: None. Straightforward mapping.

### R4
- **Type**: Behavior / Dataflow
- **Statement**: `mlflow_experiment_location_to_proto` shall convert an `MlflowExperimentLocation` entity to `pb.MlflowExperimentLocation` protobuf, mapping `experiment_id` directly.
- **Task Evidence**: Interface Description 1, docstring: "extracting the experiment_id from the input object and creating a corresponding protobuf message."
- **Acceptance**: Returns `pb.MlflowExperimentLocation(experiment_id=entity.experiment_id)`.
- **Repository Evidence**: `/testbed/mlflow/entities/trace_location.py` defines `MlflowExperimentLocation` with `experiment_id: str`. Caller: same pattern as R3.
- **Uncertainty**: None.

### R5
- **Type**: Behavior / Dataflow
- **Statement**: `uc_schema_location_to_proto` shall convert a `UCSchemaLocation` entity to `pb.UCSchemaLocation` protobuf, mapping `catalog_name`, `schema_name`, `_otel_spans_table_name`, and `_otel_logs_table_name`.
- **Task Evidence**: Interface Description 1, docstring: "mapping all the relevant fields including catalog name, schema name, and the optional OpenTelemetry table names for spans and logs… accesses private attributes _otel_spans_table_name and _otel_logs_table_name."
- **Acceptance**: Returns `pb.UCSchemaLocation(catalog_name=..., schema_name=..., otel_spans_table_name=..., otel_logs_table_name=...)`.
- **Repository Evidence**: `/testbed/mlflow/entities/trace_location.py` defines `UCSchemaLocation` with private attributes `_otel_spans_table_name` and `_otel_logs_table_name`. Caller: `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451`.
- **Uncertainty**: How to handle None table names — likely omit or set to empty string.

### R6
- **Type**: Behavior / Dataflow
- **Statement**: `uc_schema_location_from_proto` shall convert a `pb.UCSchemaLocation` protobuf to a `UCSchemaLocation` entity, extracting catalog_name, schema_name, and optionally setting `_otel_spans_table_name` and `_otel_logs_table_name` via `HasField`.
- **Task Evidence**: Interface Description 1, docstring: "extracts the catalog name and schema name from the protobuf message and optionally sets the OpenTelemetry table names if they are present in the protobuf message."
- **Acceptance**: Entity has catalog_name, schema_name from proto; `_otel_spans_table_name` and `_otel_logs_table_name` are set only when proto has those fields.
- **Repository Evidence**: `/testbed/mlflow/entities/trace_location.py` defines `UCSchemaLocation` dataclass with defaults for `_otel_spans_table_name` and `_otel_logs_table_name`.
- **Uncertainty**: Default table name values when proto omits them — the dataclass provides defaults.

### R7
- **Type**: Behavior / Dataflow
- **Statement**: `trace_location_to_proto` shall dispatch to the appropriate sub-converter based on `TraceLocation.type`, populating the correct oneof field in `pb.TraceLocation`; raises `ValueError` for unsupported types.
- **Task Evidence**: Interface Description 1, docstring: "Based on the location type… delegates to specific conversion functions… ValueError: If the trace_location.type is not one of the supported types."
- **Acceptance**: UC_SCHEMA → uc_schema set; MLFLOW_EXPERIMENT → mlflow_experiment set; INFERENCE_TABLE → inference_table set; TRACE_LOCATION_TYPE_UNSPECIFIED → ValueError.
- **Repository Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py` calls `trace_location_to_proto` in multiple places. `/testbed/mlflow/entities/trace_location.py` defines `TraceLocationType`.
- **Uncertainty**: None.

### R8
- **Type**: Behavior / Dataflow
- **Statement**: `trace_location_from_proto` shall dispatch based on `WhichOneof('identifier')` from a `pb.TraceLocation`, constructing the corresponding `TraceLocation` entity; falls back to `TRACE_LOCATION_TYPE_UNSPECIFIED` if no identifier is set.
- **Task Evidence**: Interface Description 1, docstring: "handles three types… Uses the WhichOneof method… Falls back to TRACE_LOCATION_TYPE_UNSPECIFIED if no recognized identifier is found."
- **Acceptance**: Correct entity construction for each type; unspecified fallback.
- **Repository Evidence**: `/testbed/mlflow/entities/trace_location.py:246` — `TraceLocation.from_proto()` delegates to this function.
- **Uncertainty**: None.

### R9
- **Type**: Behavior / Dataflow
- **Statement**: `trace_from_proto` shall convert a `pb.Trace` proto to an MLflow `Trace` entity, deserializing trace_info and spans.
- **Task Evidence**: Interface Description 1, docstring: "deserializes a protobuf representation of a trace back into MLflow's internal Trace object… relies on TraceInfo.from_proto() and Span.from_otel_proto()."
- **Acceptance**: Returns `Trace` with valid `info: TraceInfo` and `data: TraceData` containing `Span` objects.
- **Repository Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py:290` calls this function.
- **Uncertainty**: None.

### R10
- **Type**: Behavior / Dataflow
- **Statement**: `trace_to_proto` shall convert an MLflow `Trace` entity to a `pb.Trace` proto, serializing trace_info and spans.
- **Task Evidence**: Interface Description 1, docstring: "transforms an MLflow Trace entity into a protobuf Trace message, which includes both the trace information and associated span data."
- **Acceptance**: Returns `pb.Trace` with `trace_info` and `spans` fields populated.
- **Repository Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py:294` calls this function.
- **Uncertainty**: None.

### R11
- **Type**: Behavior / Dataflow
- **Statement**: `trace_info_to_v4_proto` shall convert a `TraceInfo` entity to `pb.TraceInfo` for the v4 protocol, parsing trace IDs for UC schema locations and using them as-is for other location types.
- **Task Evidence**: Interface Description 1, docstring: "For UC schema trace locations, the trace ID is parsed using parse_trace_id_v4() to extract the actual trace ID from the v4 format. For other trace locations, the trace ID is used as-is."
- **Acceptance**: UC location → parsed trace_id (no v4 prefix); non-UC → raw trace_id; includes request/response previews, tags, metadata, assessments.
- **Repository Evidence**: `/testbed/mlflow/entities/trace_info.py:103` — `TraceInfo.to_proto()` delegates to this function for v4. Uses `parse_trace_id_v4` from `/testbed/mlflow/tracing/utils/__init__.py`.
- **Uncertainty**: None.

### R12
- **Type**: Behavior / State / Failure
- **Statement**: `AssessmentSourceType` shall provide plain-string class constants (`HUMAN`, `LLM_JUDGE`, `AI_JUDGE`, `CODE`, `SOURCE_TYPE_UNSPECIFIED`), an `__init__` that delegates to a `_parse` static method for case-insensitive normalization and validation, a `__str__` returning the stored value, and a `_standardize` static method that wraps construction+stringification. The `_parse` method shall emit `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` when given `"AI_JUDGE"`, remap it to `"LLM_JUDGE"`, and raise `MlflowException` with `INVALID_PARAMETER_VALUE` error code and message containing `"Invalid assessment source type"` for unknown values.
- **Task Evidence**: Interface Description 2, all docstrings and Notes. Native tests `test_assessment_source_type_validation` (RT1), `test_ai_judge_deprecation_warning` (RT2), `test_assessment_source_case_insensitivity` (RT3) confirm case-insensitivity, exact deprecation warning message, and exception message format.
- **Acceptance**: Constants are plain strings. `AssessmentSourceType("llm_judge")` → `str()` returns `"LLM_JUDGE"`. `AssessmentSourceType("AI_JUDGE")` → `str()` returns `"LLM_JUDGE"` and emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`. `AssessmentSourceType("ROBOT")` → raises `MlflowException` with `error_code == INVALID_PARAMETER_VALUE` and message containing `"Invalid assessment source type"`. `_standardize` mirrors the same behavior.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` defines `AssessmentSourceType` and `AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize`.
- **Uncertainty**: None — native tests provide exact behavioral contracts.

### R13
- **Type**: Behavior / Dataflow
- **Statement**: `Span.inputs` property shall deserialize the value stored under `SpanAttributeKey.INPUTS` via `json.loads` and return the original Python object; returns `None` when no inputs were set.
- **Task Evidence**: Interface Description 3, `Span.inputs` docstring: "The inputs are automatically serialized to JSON when stored and deserialized when retrieved… Returns None if no inputs were set."
- **Acceptance**: `span.inputs` returns original Python object for set inputs; `None` for unset.
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` existing pattern: `get_attribute` retrieves from `_CachedSpanAttributesRegistry`. `LiveSpan.set_inputs` serializes via `json.dumps`.
- **Uncertainty**: None.

### R14
- **Type**: Behavior / Dataflow
- **Statement**: `Span.outputs` property shall deserialize the value stored under `SpanAttributeKey.OUTPUTS` via `json.loads` and return the original Python object; returns `None` when no outputs were set.
- **Task Evidence**: Interface Description 3, `Span.outputs` docstring: "This is a read-only property… Returns None if no outputs were set."
- **Acceptance**: `span.outputs` returns original Python object for set outputs; `None` for unset.
- **Repository Evidence**: Same as R13 pattern.
- **Uncertainty**: None.

## L2. Functional Design Graph

### N1 — Public Entry: `assessment_to_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.assessment_to_proto`
- Type: Function
- Imports: `pb` from `mlflow.protos.databricks_tracing_pb2`, `parse_trace_id_v4` from `mlflow.tracing.utils`
- Obligations: [R1]

### N2 — Public Entry: `get_trace_id_from_assessment_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.get_trace_id_from_assessment_proto`
- Type: Function
- Imports: `construct_trace_id_v4` from `mlflow.tracing.utils`
- Obligations: [R2]
- Note: Accepts both `pb.Assessment` (databricks_tracing_pb2, has `trace_location`) and `assessments_pb2.Assessment` (no `trace_location`). UC-schema path only exercisable with `pb.Assessment`.

### N3 — Public Entry: `inference_table_location_to_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.inference_table_location_to_proto`
- Type: Function
- Obligations: [R3]

### N4 — Public Entry: `mlflow_experiment_location_to_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.mlflow_experiment_location_to_proto`
- Type: Function
- Obligations: [R4]

### N5 — Public Entry: `uc_schema_location_to_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.uc_schema_location_to_proto`
- Type: Function
- Obligations: [R5]

### N6 — Public Entry: `uc_schema_location_from_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.uc_schema_location_from_proto`
- Type: Function
- Obligations: [R6]

### N7 — Public Entry: `trace_location_to_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.trace_location_to_proto`
- Type: Function
- Obligations: [R7]
- Calls: N3, N4, N5

### N8 — Public Entry: `trace_location_from_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.trace_location_from_proto`
- Type: Function
- Obligations: [R8]
- Calls: N6 (indirectly via UCSchemaLocation constructor), MlflowExperimentLocation.from_proto, InferenceTableLocation.from_proto

### N9 — Public Entry: `trace_from_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.trace_from_proto`
- Type: Function
- Obligations: [R9]

### N10 — Public Entry: `trace_to_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.trace_to_proto`
- Type: Function
- Obligations: [R10]

### N11 — Public Entry: `trace_info_to_v4_proto`
- Entity: `mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto`
- Type: Function
- Obligations: [R11]
- Calls: N1 (for assessments), `parse_trace_id_v4`, `_truncate_request_metadata`, `_truncate_tags`

### N12 — Public Entry: `AssessmentSourceType` (class)
- Entity: `mlflow.entities.assessment_source.AssessmentSourceType`
- Type: Class
- Obligations: [R12]
- Note: The `_parse` static method is the core validation/deprecation logic. `_standardize` is the public convenience wrapper.

### N13 — Public Entry: `Span.inputs` (property)
- Entity: `mlflow.entities.span.Span.inputs`
- Type: Property
- Obligations: [R13]

### N14 — Public Entry: `Span.outputs` (property)
- Entity: `mlflow.entities.span.Span.outputs`
- Type: Property
- Obligations: [R14]

### E1
- Kind: CALL
- Source: N7 (`trace_location_to_proto`)
- Target: N3, N4, N5
- Condition: On `trace_location.type == INFERENCE_TABLE` → N3; `MLFLOW_EXPERIMENT` → N4; `UC_SCHEMA` → N5
- Transfer: TraceLocation entity → pb.TraceLocation
- Evidence: Interface Description 1, `trace_location_to_proto` docstring
- Obligations: [R7]

### E2
- Kind: CALL
- Source: N8 (`trace_location_from_proto`)
- Target: N6 (UCSchemaLocation constructor directly), MlflowExperimentLocation.from_proto, InferenceTableLocation.from_proto
- Condition: On `WhichOneof('identifier')` result
- Transfer: pb.TraceLocation → TraceLocation entity
- Evidence: Interface Description 1, `trace_location_from_proto` docstring
- Obligations: [R8]

### E3
- Kind: CALL
- Source: N11 (`trace_info_to_v4_proto`)
- Target: N1 (`assessment_to_proto`)
- Condition: When trace_info has assessments
- Transfer: Each Assessment in trace_info.assessments → pb.Assessment via N1
- Evidence: Interface Description 1, `trace_info_to_v4_proto` docstring: "Associated assessments converted to protobuf format"
- Obligations: [R1, R11]

### E4
- Kind: CALL
- Source: `TraceInfo.to_proto()` (v4 path)
- Target: N11 (`trace_info_to_v4_proto`)
- Condition: When `self._is_v4()` returns True
- Transfer: TraceInfo self → pb.TraceInfo
- Evidence: `/testbed/mlflow/entities/trace_info.py:103`
- Obligations: [R11]

### E5
- Kind: CALL
- Source: `TraceLocation.from_proto()`
- Target: N8 (`trace_location_from_proto`)
- Condition: Always (delegates entirely)
- Transfer: pb.TraceLocation → TraceLocation
- Evidence: `/testbed/mlflow/entities/trace_location.py:246`
- Obligations: [R8]

### E6
- Kind: CALL
- Source: `Expectation.from_proto()`, `Feedback.from_proto()`
- Target: N2 (`get_trace_id_from_assessment_proto`)
- Condition: Always when deserializing assessment protos
- Transfer: pb.Assessment → trace_id string
- Evidence: `/testbed/mlflow/entities/assessment.py:288,426`
- Obligations: [R2]

### E7
- Kind: CALL
- Source: `DatabricksTracingRestStore`
- Target: N7, N9, N10, N1, N5, N6, N8
- Condition: Various store operations (search, get, create, link)
- Transfer: Entity ↔ Proto conversions
- Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:189,290,294,412,422,434,451,511,558`
- Obligations: [R1, R3, R4, R5, R6, R7, R8, R9, R10]

### E8
- Kind: DATA
- Source: N12 (`AssessmentSourceType._parse`)
- Target: `AssessmentSource.__post_init__`
- Condition: Via `_standardize` static method
- Transfer: Raw source_type string → standardized uppercase string
- Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`
- Obligations: [R12]

### E9
- Kind: DATA
- Source: N13 (`Span.inputs`)
- Target: `_CachedSpanAttributesRegistry.get`
- Condition: Read access
- Transfer: SpanAttributeKey.INPUTS → deserialized value
- Evidence: `/testbed/mlflow/entities/span.py` — existing `get_attribute` pattern
- Obligations: [R13]

### E10
- Kind: DATA
- Source: N14 (`Span.outputs`)
- Target: `_CachedSpanAttributesRegistry.get`
- Condition: Read access
- Transfer: SpanAttributeKey.OUTPUTS → deserialized value
- Evidence: `/testbed/mlflow/entities/span.py` — existing `get_attribute` pattern
- Obligations: [R14]

## L3. Verifiable Contracts

### C1
- **Type**: Interface
- **Subject**: `assessment_to_proto`
- **Relation**: Given a fully-populated Feedback Assessment, returns pb.Assessment with all fields correctly set.
- **Expected**: All proto fields populated: name, source, trace_id, timestamps (ms→Timestamp), span_id, rationale, assessment_id, trace_location (for UC schema trace_ids), feedback (oneof), metadata (string values).
- **Evidence**: Interface Description 1, R1
- **Observe**: RETURN_VALUE + FIELD_READ (HasField, attributes)
- **Target**: N1
- **Obligations**: [R1]
- **Graph**: E1, E3, E7

### C2
- **Type**: Behavior
- **Subject**: `assessment_to_proto` — minimal Assessment
- **Relation**: Given an Assessment with only required fields (no optional), returns proto with optional fields empty/not-set.
- **Expected**: Required fields populated; span_id, rationale, feedback, expectation not set; valid defaults to True.
- **Evidence**: Interface Description 1, R1: "handles None values gracefully"
- **Observe**: RETURN_VALUE — check HasField for each optional
- **Target**: N1
- **Obligations**: [R1]
- **Graph**: E1

### C3
- **Type**: Interface
- **Subject**: `get_trace_id_from_assessment_proto` — UC schema path
- **Relation**: Given a `pb.Assessment` (databricks_tracing_pb2, NOT assessments_pb2) with `trace_location.uc_schema` set to catalog "mycat" and schema "myschema" and `trace_id="tr-inner-456"`, returns a v4 trace ID.
- **Expected**: Result starts with `TRACE_ID_V4_PREFIX`, contains "mycat.myschema", and contains "tr-inner-456". The UC-schema path is only exercisable with `databricks_tracing_pb2.Assessment` because `assessments_pb2.Assessment` lacks the `trace_location` field.
- **Evidence**: Interface Description 1, R2. Native test RT1. Verified: `assessments_pb2.Assessment` has no `trace_location` attribute; `databricks_tracing_pb2.Assessment` does.
- **Observe**: RETURN_VALUE
- **Target**: N2
- **Obligations**: [R2]
- **Graph**: E6

### C4
- **Type**: Interface
- **Subject**: `get_trace_id_from_assessment_proto` — no UC schema
- **Relation**: Given an assessment proto without trace_location or without uc_schema, returns raw trace_id.
- **Expected**: Returns `proto.trace_id` unchanged.
- **Evidence**: Interface Description 1, R2
- **Observe**: RETURN_VALUE
- **Target**: N2
- **Obligations**: [R2]
- **Graph**: E6

### C5
- **Type**: Interface
- **Subject**: `inference_table_location_to_proto`
- **Relation**: Given `InferenceTableLocation(full_table_name="catalog.schema.table")`, returns proto with matching `full_table_name`.
- **Expected**: `proto.full_table_name == "catalog.schema.table"`
- **Evidence**: Interface Description 1, R3
- **Observe**: RETURN_VALUE
- **Target**: N3
- **Obligations**: [R3]
- **Graph**: E1

### C6
- **Type**: Interface
- **Subject**: `mlflow_experiment_location_to_proto`
- **Relation**: Given `MlflowExperimentLocation(experiment_id="123")`, returns proto with matching `experiment_id`.
- **Expected**: `proto.experiment_id == "123"`
- **Evidence**: Interface Description 1, R4
- **Observe**: RETURN_VALUE
- **Target**: N4
- **Obligations**: [R4]
- **Graph**: E1

### C7
- **Type**: Interface
- **Subject**: `uc_schema_location_to_proto`
- **Relation**: Given `UCSchemaLocation(catalog_name="cat", schema_name="sch")`, returns proto with matching catalog_name, schema_name, and default table names.
- **Expected**: `proto.catalog_name == "cat"`, `proto.schema_name == "sch"`, `proto.otel_spans_table_name` set, `proto.otel_logs_table_name` set.
- **Evidence**: Interface Description 1, R5
- **Observe**: RETURN_VALUE
- **Target**: N5
- **Obligations**: [R5]
- **Graph**: E1

### C8
- **Type**: Interface
- **Subject**: `uc_schema_location_from_proto`
- **Relation**: Given a proto with catalog_name, schema_name, and both table names, returns UCSchemaLocation with all fields set.
- **Expected**: Entity has correct catalog_name, schema_name, and private table name attributes.
- **Evidence**: Interface Description 1, R6
- **Observe**: RETURN_VALUE + FIELD_READ (private attrs)
- **Target**: N6
- **Obligations**: [R6]
- **Graph**: E2

### C9
- **Type**: Interface
- **Subject**: `uc_schema_location_from_proto` — minimal proto
- **Relation**: Given a proto with only catalog_name and schema_name (no table names), returns UCSchemaLocation without table names set.
- **Expected**: Entity's `_otel_spans_table_name` is default, `_otel_logs_table_name` is default (or None).
- **Evidence**: Interface Description 1 notes: "uses HasField() to check for optional fields"
- **Observe**: RETURN_VALUE + FIELD_READ
- **Target**: N6
- **Obligations**: [R6]
- **Graph**: E2

### C10
- **Type**: Behavior
- **Subject**: `trace_location_to_proto` dispatch
- **Relation**: For each TraceLocationType (UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE), correct sub-message is populated.
- **Expected**: Proto has correct type enum and correct oneof field.
- **Evidence**: Interface Description 1, R7
- **Observe**: RETURN_VALUE — check `WhichOneof('identifier')`
- **Target**: N7
- **Obligations**: [R7]
- **Graph**: E1

### C11
- **Type**: Failure
- **Subject**: `trace_location_to_proto` ValueError
- **Relation**: Given TraceLocation with type TRACE_LOCATION_TYPE_UNSPECIFIED, raises ValueError.
- **Expected**: ValueError raised.
- **Evidence**: Interface Description 1, R7
- **Observe**: EXCEPTION
- **Target**: N7
- **Obligations**: [R7]
- **Graph**: E1

### C12
- **Type**: Behavior
- **Subject**: `trace_location_from_proto` dispatch
- **Relation**: For each type of proto TraceLocation, returns correct entity type.
- **Expected**: MLFLOW_EXPERIMENT proto → TraceLocation with mlflow_experiment set; INFERENCE_TABLE → inference_table set; UC_SCHEMA → uc_schema set.
- **Evidence**: Interface Description 1, R8
- **Observe**: RETURN_VALUE + FIELD_READ
- **Target**: N8
- **Obligations**: [R8]
- **Graph**: E2, E5

### C13
- **Type**: Behavior
- **Subject**: `trace_location_from_proto` — unspecified fallback
- **Relation**: Given proto with no identifier, returns TraceLocation with TRACE_LOCATION_TYPE_UNSPECIFIED.
- **Expected**: `result.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED`
- **Evidence**: Interface Description 1, R8
- **Observe**: RETURN_VALUE
- **Target**: N8
- **Obligations**: [R8]
- **Graph**: E2

### C14
- **Type**: Interface
- **Subject**: `trace_from_proto`
- **Relation**: Given a `pb.Trace` proto with trace_info and spans, returns MLflow Trace entity.
- **Expected**: `result.info` is TraceInfo, `result.data.spans` is list of Span.
- **Evidence**: Interface Description 1, R9
- **Observe**: RETURN_VALUE
- **Target**: N9
- **Obligations**: [R9]
- **Graph**: E7

### C15
- **Type**: Interface
- **Subject**: `trace_to_proto`
- **Relation**: Given an MLflow Trace with info and data, returns `pb.Trace` with trace_info and spans.
- **Expected**: Proto contains trace_info and spans fields.
- **Evidence**: Interface Description 1, R10
- **Observe**: RETURN_VALUE
- **Target**: N10
- **Obligations**: [R10]
- **Graph**: E7

### C16
- **Type**: Interface
- **Subject**: `trace_info_to_v4_proto`
- **Relation**: Given TraceInfo with UC schema location, returns pb.TraceInfo with parsed trace_id (no v4 prefix).
- **Expected**: `proto.trace_id` does not contain TRACE_ID_V4_PREFIX; `proto.trace_location.uc_schema` is populated.
- **Evidence**: Interface Description 1, R11
- **Observe**: RETURN_VALUE
- **Target**: N11
- **Obligations**: [R11]
- **Graph**: E4

### C17
- **Type**: Interface
- **Subject**: `trace_info_to_v4_proto` — non-UC location
- **Relation**: Given TraceInfo with MLflow experiment location, returns proto with raw trace_id.
- **Expected**: `proto.trace_id == trace_info.trace_id` (no parsing).
- **Evidence**: Interface Description 1, R11: "For other trace locations, the trace ID is used as-is"
- **Observe**: RETURN_VALUE
- **Target**: N11
- **Obligations**: [R11]
- **Graph**: E4

### C18
- **Type**: Interface
- **Subject**: `AssessmentSourceType` constants
- **Relation**: Class-level constants are plain strings.
- **Expected**: `AssessmentSourceType.HUMAN == "HUMAN"`, `AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"`, `AssessmentSourceType.AI_JUDGE == "AI_JUDGE"`, `AssessmentSourceType.CODE == "CODE"`, `AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"`.
- **Evidence**: Interface Description 2, R12 Notes
- **Observe**: RETURN_VALUE (direct attribute access)
- **Target**: N12
- **Obligations**: [R12]
- **Graph**: N/A (class definition)

### C19
- **Type**: Behavior
- **Subject**: `AssessmentSourceType.__init__` and `__str__`
- **Relation**: Creating instance with "llm_judge" stores "LLM_JUDGE" and stringifies to "LLM_JUDGE".
- **Expected**: `str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"`, `str(AssessmentSourceType("HUMAN")) == "HUMAN"`, `str(AssessmentSourceType("code")) == "CODE"`, `str(AssessmentSourceType("source_type_unspecified")) == "SOURCE_TYPE_UNSPECIFIED"`.
- **Evidence**: Interface Description 2, R12: "case-insensitive string inputs (converts to uppercase)". Native test RT3.
- **Observe**: RETURN_VALUE
- **Target**: N12
- **Obligations**: [R12]
- **Graph**: E8

### C20
- **Type**: Behavior / SideEffect
- **Subject**: `AssessmentSourceType` deprecation warning
- **Relation**: Creating instance with "AI_JUDGE" issues `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and returns "LLM_JUDGE".
- **Expected**: `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"`; exactly one `FutureWarning` with message `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` is emitted. Both `__init__` and `_standardize` paths must emit the same warning with the same exact message.
- **Evidence**: Interface Description 2, R12. Native test RT2: `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
- **Observe**: SIDE_EFFECT (warnings) with exact message match + RETURN_VALUE
- **Target**: N12
- **Obligations**: [R12]
- **Graph**: E8

### C21
- **Type**: Failure
- **Subject**: `AssessmentSourceType` invalid type
- **Relation**: Creating instance with invalid type raises MlflowException with INVALID_PARAMETER_VALUE error code and message containing "Invalid assessment source type".
- **Expected**: `MlflowException` raised; `error_code == INVALID_PARAMETER_VALUE`; `str(exception)` contains `"Invalid assessment source type"`. Both `__init__` and `_standardize` paths must raise with the same error code and message.
- **Evidence**: Interface Description 2, R12. Native test RT1: `pytest.raises(MlflowException, match="Invalid assessment source type")`
- **Observe**: EXCEPTION with message content match
- **Target**: N12
- **Obligations**: [R12]
- **Graph**: E8

### C22
- **Type**: Interface
- **Subject**: `AssessmentSourceType._standardize`
- **Relation**: Static method normalizes and validates source type string.
- **Expected**: `AssessmentSourceType._standardize("human") == "HUMAN"`, `AssessmentSourceType._standardize("AI_JUDGE") == "LLM_JUDGE"` with FutureWarning, `AssessmentSourceType._standardize("INVALID")` raises MlflowException.
- **Evidence**: Interface Description 2, R12
- **Observe**: RETURN_VALUE + SIDE_EFFECT + EXCEPTION
- **Target**: N12
- **Obligations**: [R12]
- **Graph**: E8

### C23
- **Type**: Interface
- **Subject**: `Span.inputs`
- **Relation**: Given a Span with inputs set via `LiveSpan.set_inputs`, `span.inputs` returns the original value.
- **Expected**: Value round-trips through serialization. `{"input": 1, "nested": {"foo": "bar"}}` set → same dict retrieved.
- **Evidence**: Interface Description 3, R13. Native test RT4.
- **Observe**: RETURN_VALUE
- **Target**: N13
- **Obligations**: [R13]
- **Graph**: E9

### C24
- **Type**: Interface
- **Subject**: `Span.outputs`
- **Relation**: Given a Span with outputs set, `span.outputs` returns the original value.
- **Expected**: Value round-trips through serialization. Integer `2` set → integer `2` retrieved.
- **Evidence**: Interface Description 3, R14. Native test RT4.
- **Observe**: RETURN_VALUE
- **Target**: N14
- **Obligations**: [R14]
- **Graph**: E10

### C25
- **Type**: Behavior
- **Subject**: `Span.inputs` — default None
- **Relation**: When no inputs were set on a span, `span.inputs` returns None.
- **Expected**: Returns None.
- **Evidence**: Interface Description 3, R13: "Returns None if no inputs were set."
- **Observe**: RETURN_VALUE
- **Target**: N13
- **Obligations**: [R13]
- **Graph**: E9

### C26
- **Type**: Behavior
- **Subject**: `Span.outputs` — default None
- **Relation**: When no outputs were set on a span, `span.outputs` returns None.
- **Expected**: Returns None.
- **Evidence**: Interface Description 3, R14: "Returns None if no outputs were set."
- **Observe**: RETURN_VALUE
- **Target**: N14
- **Obligations**: [R14]
- **Graph**: E10
