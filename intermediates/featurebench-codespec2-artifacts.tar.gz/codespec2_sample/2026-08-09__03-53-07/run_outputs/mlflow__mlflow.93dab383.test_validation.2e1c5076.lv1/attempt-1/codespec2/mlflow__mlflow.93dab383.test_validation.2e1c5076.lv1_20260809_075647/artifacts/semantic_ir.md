## L1. Requirement Obligations

### R1
- **Type**: Interface Signature
- **Statement**: The `scorer` decorator in `/testbed/mlflow/genai/scorers/base.py` MUST accept an optional callable `func` and keyword arguments `name`, `description`, `aggregations`, produce a `Scorer` subclass instance whose `__call__` delegates to `func`, and support the parameter subset `{inputs, outputs, expectations, trace}`. The `run()` method MUST accept all documented return types (`bool`, `int`, `float`, `str`, `Feedback`, `list[Feedback]`) plus `None` as a valid return.
- **Task Evidence**: Interface Description 1 declares `def scorer(func = None)` with documented parameter table (inputs, outputs, expectations, trace), return types (bool, int, float, str, Feedback, list[Feedback]), and kwargs `name`, `description`, `aggregations`.
- **Acceptance**: A test decorates a function with `@scorer`, calls the resulting scorer with keyword arguments among `inputs`, `outputs`, `expectations`, `trace`, and receives one of the allowed return types (including `None`), a `Feedback`, or a `list[Feedback]`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py:847` defines `def scorer(func=None, *, name, description, aggregations)`. The reference implementation in `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999` defines inner `class CustomScorer(Scorer)` with `_original_func` private attr. The `run` method at line 372 dispatches to `self(**filtered)` and at line 395 includes `or result is None` in the type gate. Tests at `/testbed/tests/genai/scorers/test_scorer.py` use `@scorer` decorator extensively, including `test_custom_scorer_allow_none_return` at line 268.
- **Uncertainty**: None.

### R2
- **Type**: Interface Signature
- **Statement**: The `valid_data_for_builtin_scorers` function in `/testbed/mlflow/genai/scorers/validation.py` MUST accept a `pd.DataFrame`, a `list[BuiltInScorer]`, and an optional `predict_fn`, and validate that required columns exist, mapping legacy column names `request`→`inputs` and `response`→`outputs`, accounting for trace-inferred columns, and exploding `expectations` dict keys.
- **Task Evidence**: Interface Description 2 first function: `def valid_data_for_builtin_scorers(data: 'pd.DataFrame', builtin_scorers: list[BuiltInScorer], predict_fn: Callable[..., Any] | None = None) -> None`.
- **Acceptance**: Given a DataFrame with columns `['request', 'expectations']` and a `Correctness` scorer, the function logs the missing `outputs` column without raising; given a DataFrame where expectations column contains a non-dict value, it raises `MlflowException`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101` contains the full reference implementation. Caller at `/testbed/mlflow/genai/evaluation/base.py:248` calls `valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)`. The `BuiltInScorer.validate_columns` method at `/testbed/mlflow/genai/scorers/builtin_scorers.py:325` raises `MissingColumnsException` when columns are missing.
- **Uncertainty**: None.

### R3
- **Type**: Interface Signature
- **Statement**: The `validate_scorers` function in `/testbed/mlflow/genai/scorers/validation.py` MUST accept a `list[Any]`, validate each element is a `Scorer` instance (or legacy `databricks.rag_eval.evaluation.metrics.Metric`), return `list[Scorer]`, and raise `MlflowException` with contextual hints for common mistakes (passing class instead of instance, nesting `get_all_scorers()` result).
- **Task Evidence**: Interface Description 2 second function: `def validate_scorers(scorers: list[Any]) -> list[Scorer]`.
- **Acceptance**: Passing `[Correctness()]` returns the list unchanged; passing `[Correctness]` (class) raises `MlflowException` with hint about instantiation; passing `[get_all_scorers()]` (nested list) raises `MlflowException` with hint about unpacking; passing a non-list raises `MlflowException`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26` contains the full reference implementation. Caller at `/testbed/mlflow/genai/evaluation/base.py:243` calls `scorers = validate_scorers(scorers)`. Tests exist implicitly through `evaluate()` usage.
- **Uncertainty**: None.

### R4
- **Type**: Interface Signature
- **Statement**: The `get_all_scorers` function in `/testbed/mlflow/genai/scorers/builtin_scorers.py` MUST return a `list[BuiltInScorer]` containing instances of all available built-in scorers (6 for OSS: ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence; plus Safety and RetrievalRelevance for Databricks).
- **Task Evidence**: Interface Description 3: `def get_all_scorers() -> list[BuiltInScorer]`.
- **Acceptance**: On OSS tracking URI, returns 6 scorer instances all of type `BuiltInScorer`. On Databricks tracking URI, returns 8 instances including `Safety` and `RetrievalRelevance`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567` contains the reference implementation. Test at `/testbed/tests/genai/scorers/test_builtin_scorers.py:570` (`test_get_all_scorers_oss`) validates 6 scorers for OSS, 8 for Databricks. Callers at `/testbed/mlflow/genai/evaluation/base.py:361,385` and `/testbed/mlflow/cli/genai_eval_utils.py:121` import and use `get_all_scorers`.
- **Uncertainty**: None.

### R5
- **Type**: Behavior - Return Value Normalization
- **Statement**: The `Scorer.run` method MUST normalize the return value of a custom scorer: when a single `Feedback` is returned with the default name (`DEFAULT_FEEDBACK_NAME`), the name is overwritten to the scorer's name; when a list of `Feedback` is returned, names are preserved as-is.
- **Task Evidence**: Task mentions "Handle edge cases in naming patterns"; interface document shows `Feedback` return type. Native tests at `/testbed/tests/genai/scorers/test_scorer.py:295-331` (`test_custom_scorer_overwrites_default_feedback_name`, `test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list`).
- **Acceptance**: A `@scorer`-decorated function returning `Feedback(value=42)` (default name) gets its feedback name overwritten to the scorer name. Returning `Feedback(name="custom", value=42)` preserves "custom". Returning a list preserves all names.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py:405-422` contains the name-overwrite logic in `run()`. Tests at `/testbed/tests/genai/scorers/test_scorer.py` (e.g., `test_custom_scorer_overwrites_default_feedback_name` at line 295) validate this.
- **Uncertainty**: None.

### R6
- **Type**: Interface Signature
- **Statement**: The `validate_aggregations` function in `/testbed/mlflow/genai/scorers/validation.py` MUST accept a `list[str | AggregationFunc] | None`, validate each string is in `_AGGREGATE_FUNCTIONS` keys or each element is callable, and raise `MlflowException` for invalid entries.
- **Task Evidence**: Interface Description 1 documents `aggregations` parameter: "If a string, it must be one of `["min", "max", "mean", "median", "variance", "p90"]`. If a callable, it must take a list of values and return a single value."
- **Acceptance**: `validate_aggregations(["min", "max"])` passes; `validate_aggregations(["invalid"])` raises; `validate_aggregations([lambda x: sum(x)/len(x)])` passes; `validate_aggregations([42])` raises; `validate_aggregations(None)` passes (no-op).
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (current) contains `validate_aggregations` implementation. Tests at `/testbed/tests/genai/scorers/test_scorer_utils.py` may cover this. The `_AGGREGATE_FUNCTIONS` dict is at `/testbed/mlflow/genai/scorers/aggregation.py:22`.
- **Uncertainty**: None.

### R7
- **Type**: Dataflow - Column Name Mapping
- **Statement**: `valid_data_for_builtin_scorers` MUST map legacy column names: `request` → `inputs` and `response` → `outputs`, to bridge between the evaluation harness's `_convert_to_eval_set` output and scorer column requirements.
- **Task Evidence**: Interface Description 2 notes: "The function performs automatic column name mapping: 'request' -> 'inputs' and 'response' -> 'outputs' to handle legacy schema conversions."
- **Acceptance**: A DataFrame with columns `['request', 'response']` is treated as having `['inputs', 'outputs']` for scorer validation. The original columns are removed and mapped columns added.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:115-121` contains the mapping logic. The evaluation harness at `/testbed/mlflow/genai/evaluation/base.py` calls `_convert_to_eval_set` before `valid_data_for_builtin_scorers`.
- **Uncertainty**: None.

### R8
- **Type**: Dataflow - Expectations Explosion
- **Statement**: When the DataFrame contains an `expectations` column, `valid_data_for_builtin_scorers` MUST iterate its values, silently skip any `NaN` (pandas NA) values, verify each remaining value is a dict (raising `MlflowException` if not), and add `expectations/{key}` columns for each dict key to the available column set.
- **Task Evidence**: Interface Description 2 notes: "The 'expectations' column is treated specially - its dictionary values are exploded into individual expectation fields for validation." Interface Description 2 also states: "Raises: MlflowException: Raised if the 'expectations' column contains non-dictionary values when it should contain dictionaries mapping expectation names to values."
- **Acceptance**: DataFrame with `expectations` containing `{"expected_response": "Paris"}` adds `expectations/expected_response` to columns. Non-dict non-NaN value raises `MlflowException`. NaN values in the expectations column are silently skipped without raising.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:137-148` contains the explosion logic; line 140-141 contains `if pd.isna(value): continue` for NaN skip.
- **Uncertainty**: None.

### R9
- **Type**: Dataflow - Trace Column Inference
- **Statement**: When the DataFrame contains a `trace` column, `valid_data_for_builtin_scorers` MUST infer that `inputs` and `outputs` are available (since they can be extracted from traces).
- **Task Evidence**: Interface Description 2: "The presence of a 'trace' column implies that both 'inputs' and 'outputs' can be inferred from the trace data."
- **Acceptance**: DataFrame with only `['trace']` column is treated as also having `inputs` and `outputs` available.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:131-133` adds inputs/outputs when trace present.
- **Uncertainty**: None.

### R10
- **Type**: Dataflow - Predict Function Column Inference
- **Statement**: When `predict_fn` is provided, `valid_data_for_builtin_scorers` MUST treat the `outputs` column as available (since it can be generated) and also infer `trace` column availability.
- **Task Evidence**: Interface Description 2: "When provided, the data doesn't need to contain the 'outputs' column as it can be generated by the predict function."
- **Acceptance**: DataFrame with only `['inputs']` and a `predict_fn` is treated as having `outputs` and `trace` available.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:127-129` adds outputs when predict_fn provided; line 134 adds trace.
- **Uncertainty**: None.

### R11
- **Type**: Failure - Missing Column Logging
- **Statement**: When required columns are missing for some scorers, `valid_data_for_builtin_scorers` MUST log an informative message (via `_logger.info`) listing which scorers need which columns, but MUST NOT raise an exception, allowing evaluation to continue with null results.
- **Task Evidence**: Interface Description 2: "When required columns are missing, the function logs an informative message but doesn't raise an exception, allowing the evaluation to continue with null results for affected scorers."
- **Acceptance**: Missing columns produce a `_logger.info` call with the message format listing columns and affected scorers.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:150-163` constructs and logs the message.
- **Uncertainty**: None.

### R12
- **Type**: Behavior - Legacy Metric Support
- **Statement**: `validate_scorers` MUST support legacy `databricks.rag_eval.evaluation.metrics.Metric` instances (when `databricks.agents` is installed), adding them to valid scorers with a deprecation warning.
- **Task Evidence**: Interface Description 2: "Legacy databricks.rag_eval metrics are supported but deprecated, and will log warnings."
- **Acceptance**: When `databricks.agents` is installed, a `Metric` instance is accepted and a warning is logged.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:48-53` checks for legacy metrics and logs warning at line 65-70.
- **Uncertainty**: Whether `databricks.agents` is installed in the test environment.

### R13
- **Type**: Behavior - Empty Scorer List
- **Statement**: `validate_scorers` MUST return an empty list when given an empty list, and MUST raise `MlflowException` when given a non-list argument.
- **Task Evidence**: Interface Description 2: "Empty lists are valid and return an empty list" and "Raises: MlflowException: If scorers is not a list."
- **Acceptance**: `validate_scorers([])` returns `[]`; `validate_scorers("not_a_list")` raises.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:35-44` handles these cases.
- **Uncertainty**: None.

### R14
- **Type**: Behavior - None Return Acceptance
- **Statement**: `Scorer.run()` MUST accept `None` as a valid return value from a custom scorer function, pass it through without raising an exception, and return `None` to the caller.
- **Task Evidence**: Native test `test_custom_scorer_allow_none_return` at `/testbed/tests/genai/scorers/test_scorer.py:268-274` asserts that `dummy_scorer.run(...)` returns `None` without error. Reference implementation at `/testbed/mlflow/genai/scorers/base.py:395` includes `or result is None` in the return-type validation gate with the comment "Allow None to represent an empty assessment from the scorer."
- **Acceptance**: A `@scorer`-decorated function that returns `None` produces `None` from `.run()` without raising `MlflowException`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py:395` (`or result is None`); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:395` (same); `/testbed/tests/genai/scorers/test_scorer.py:268-274`.
- **Uncertainty**: None.

### R15
- **Type**: Behavior - NaN Expectations Skip
- **Statement**: `valid_data_for_builtin_scorers` MUST silently skip `NaN` (pandas NA / `pd.isna()`) values encountered in the `expectations` column, treating them as if no expectations were provided for that row, without raising `MlflowException`.
- **Task Evidence**: Interface Description 2 documents expectations column handling. Reference implementation at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:140-141` contains `if pd.isna(value): continue` before the `isinstance(value, dict)` check.
- **Acceptance**: A DataFrame with `expectations` column containing `[NaN, {"key": "val"}]` does not raise `MlflowException`; NaN row is silently skipped.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:140-141`.
- **Uncertainty**: None.

## L2. Functional Design Graph

### N1
- **ID**: PublicEntry_evaluate
- **Description**: `mlflow.genai.evaluate()` — the public entry point that orchestrates scorer validation and data validation before running evaluation.
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py` defines `evaluate()`.

### N2
- **ID**: validate_scorers_fn
- **Description**: `validate_scorers(scorers)` — validates a list of scorers, filtering to valid `Scorer` instances.
- **Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (to be implemented) and `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26`.

### N3
- **ID**: valid_data_for_builtin_scorers_fn
- **Description**: `valid_data_for_builtin_scorers(data, builtin_scorers, predict_fn)` — validates DataFrame columns against builtin scorer requirements.
- **Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (to be implemented) and `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101`.

### N4
- **ID**: get_all_scorers_fn
- **Description**: `get_all_scorers()` — returns all built-in scorer instances.
- **Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` (to be implemented) and `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567`.

### N5
- **ID**: scorer_decorator
- **Description**: `@scorer` decorator — creates a `CustomScorer` subclass wrapping a user function.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:847` (partial, missing CustomScorer) and `/testbed/libs/skinny/mlflow/genai/scorers/base.py:994`.

### N6
- **ID**: CustomScorer_class
- **Description**: Inner `CustomScorer(Scorer)` class created dynamically inside `scorer()` — stores `_original_func`, delegates `__call__` to it, and reports `kind=DECORATOR`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1015`.

### N7
- **ID**: BuiltInScorer_class
- **Description**: `BuiltInScorer(Judge)` — abstract base for all built-in scorers; provides `validate_columns`, `model_dump`, `model_validate`, `kind=BUILTIN`.
- **Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py:259`.

### N8
- **ID**: Scorer_base
- **Description**: `Scorer(BaseModel)` — base class with `name`, `description`, `aggregations`, `run()`, `kind`, `register()`, `model_dump()`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:108`.

### N9
- **ID**: validate_aggregations_fn
- **Description**: `validate_aggregations(aggregations)` — validates aggregation list strings/callables.
- **Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (partial, has this function).

### N10
- **ID**: MissingColumnsException
- **Description**: Exception raised by `BuiltInScorer.validate_columns` when required columns are absent.
- **Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py:1600`.

### N11
- **ID**: Scorer_run_method
- **Description**: `Scorer.run()` — dispatches to `__call__` with keyword-filtered arguments, validates return type (including `None`), normalizes default feedback name.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:372-422`.

### N12
- **ID**: evaluate_main
- **Description**: The `evaluate()` function at `/testbed/mlflow/genai/evaluation/base.py` which calls `validate_scorers` and `valid_data_for_builtin_scorers`.
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py:243,248`.

### N13
- **ID**: Individual_Builtin_Scorers
- **Description**: Concrete scorer classes: `Correctness`, `Equivalence`, `ExpectationsGuidelines`, `Guidelines`, `RelevanceToQuery`, `RetrievalGroundedness`, `RetrievalSufficiency`, `Safety`, `RetrievalRelevance`.
- **Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` classes from line 335 onward.

### E1
- **Kind**: CALL
- **Condition**: Unconditional
- **Transfer**: `evaluate()` → `validate_scorers(scorers)`
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py:243`
- **Obligations**: R3, R12, R13

### E2
- **Kind**: CALL
- **Condition**: Unconditional
- **Transfer**: `evaluate()` → `valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)`
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py:248`
- **Obligations**: R2, R7, R8, R9, R10, R11, R15

### E3
- **Kind**: CALL
- **Condition**: Unconditional
- **Transfer**: `get_all_scorers()` → instantiates each `BuiltInScorer` subclass
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1586-1598`
- **Obligations**: R4

### E4
- **Kind**: CALL
- **Condition**: `func is not None`
- **Transfer**: `scorer(func)` → defines `CustomScorer(Scorer)` class → instantiates `CustomScorer(name, description, aggregations)`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:994-1031`
- **Obligations**: R1, R5, R14

### E5
- **Kind**: CALL
- **Condition**: `func is None`
- **Transfer**: `scorer(name=..., description=..., aggregations=...)` → `functools.partial(scorer, ...)`
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:994-996`
- **Obligations**: R1

### E6
- **Kind**: CALL
- **Condition**: Unconditional
- **Transfer**: `validate_scorers()` → iterates scorers → checks `isinstance(scorer, Scorer)` → calls `get_all_scorers()` for nested-list detection
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:54-60`
- **Obligations**: R4, R12, R13

### E7
- **Kind**: CALL
- **Condition**: Unconditional
- **Transfer**: `valid_data_for_builtin_scorers()` → iterates builtin_scorers → calls `scorer.validate_columns(input_columns)`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:151-155`
- **Obligations**: R2, R7, R8, R9, R10, R11, R15

### E8
- **Kind**: DATA
- **Condition**: `"request" in input_columns` or `"response" in input_columns`
- **Transfer**: Column names `request`→`inputs`, `response`→`outputs` mapping
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:115-121`
- **Obligations**: R7

### E9
- **Kind**: DATA
- **Condition**: `"expectations" in input_columns`
- **Transfer**: Iterates expectations values; if `pd.isna(value)` skips (NaN skip); if non-dict, raises; otherwise each dict key `k` adds `expectations/{k}` to column set
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:137-148`
- **Obligations**: R8, R15

### E10
- **Kind**: CONTROL
- **Condition**: `predict_fn is not None`
- **Transfer**: Adds `"outputs"` and `"trace"` to available columns
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:127-134`
- **Obligations**: R10

### E11
- **Kind**: CONTROL
- **Condition**: `"trace" in input_columns`
- **Transfer**: Adds `"inputs"` and `"outputs"` to available columns
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:131-133`
- **Obligations**: R9

### E12
- **Kind**: CONTROL
- **Condition**: `is_databricks_uri(get_tracking_uri())`
- **Transfer**: Adds `Safety()` and `RetrievalRelevance()` to scorers list
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1597-1598`
- **Obligations**: R4

### E13
- **Kind**: CALL
- **Condition**: Scorer.run() called
- **Transfer**: `Scorer.run()` → filters kwargs to `__call__` signature → calls `self(**filtered)` → validates return type (bool, int, float, str, Feedback, list[Feedback], or None) → normalizes default feedback name
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:372-422`
- **Obligations**: R5, R14

### E14
- **Kind**: CONTROL
- **Condition**: `not isinstance(scorers, list)`
- **Transfer**: Raises `MlflowException` with guidance message
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:35-40`
- **Obligations**: R13

### E15
- **Kind**: CONTROL
- **Condition**: `isinstance(scorer, type) and issubclass(scorer, BuiltInScorer)`
- **Transfer**: Raises `MlflowException` with hint about instantiation
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:61-65`
- **Obligations**: R3

### E16
- **Kind**: CONTROL
- **Condition**: `isinstance(scorer, list) and scorer == get_all_scorers()`
- **Transfer**: Raises `MlflowException` with hint about unpacking. Relies on Pydantic BaseModel's field-value equality for scorer instances (assumption: `get_all_scorers() == get_all_scorers()` evaluates to `True`).
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:54-60`
- **Obligations**: R3

### E17
- **Kind**: CONTROL
- **Condition**: `pd.isna(value)` for an expectations row
- **Transfer**: Skips the row (continue) without adding any expectation keys and without raising
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:140-141`
- **Obligations**: R15

## L3. Verifiable Contracts

### C1
- **Type**: Interface
- **Subject**: `scorer` decorator
- **Relation**: `@scorer` decorator creates a `Scorer` instance with `kind == ScorerKind.DECORATOR`
- **Expected**: `isinstance(decorated, Scorer)` is True and `decorated.kind == ScorerKind.DECORATOR`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999,1016-1018`
- **Observe**: `RETURN_VALUE` — check type and kind attribute
- **Target**: `arch_spec.py`
- **Obligations**: R1
- **Graph**: E4, N5, N6

### C2
- **Type**: Interface
- **Subject**: `scorer` decorator name handling
- **Relation**: When `name` kwarg is provided, it takes precedence; otherwise function name is used
- **Expected**: `scorer(name="X")(func).name == "X"` and `scorer(func).name == func.__name__`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1020-1024`
- **Observe**: `FIELD_READ` — read `.name` attribute
- **Target**: `arch_spec.py`
- **Obligations**: R1
- **Graph**: E4, N5, N6

### C3
- **Type**: Interface
- **Subject**: `CustomScorer.__call__` signature
- **Relation**: `__call__` signature includes `self` as first parameter followed by original function parameters
- **Expected**: `inspect.signature(decorated.__call__)` has `self` as param[0] plus original params
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1026-1030`
- **Observe**: `RUNTIME_ARGUMENT_TRACE` — inspect signature
- **Target**: `arch_spec.py`
- **Obligations**: R1
- **Graph**: E4, N6

### C4
- **Type**: Interface
- **Subject**: `scorer` partial application
- **Relation**: `scorer(name="X")` without func returns `functools.partial` that can be applied later
- **Expected**: `scorer(name="late")` returns partial; applying to func produces Scorer with name "late"
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:994-996`
- **Observe**: `RETURN_VALUE` — check partial then apply
- **Target**: `arch_spec.py`
- **Obligations**: R1
- **Graph**: E5, N5

### C5
- **Type**: Behavior
- **Subject**: `Scorer.run()` keyword filtering
- **Relation**: `run()` filters kwarg dict to only those accepted by the original function signature
- **Expected**: A scorer taking only `outputs` does not raise when also passed `inputs`, `expectations`, `trace`
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:379-383`
- **Observe**: `RETURN_VALUE` — check invocation succeeds
- **Target**: `behavior_spec.py`
- **Obligations**: R1
- **Graph**: E13, N11

### C6
- **Type**: Behavior
- **Subject**: Default Feedback name overwrite
- **Relation**: `Feedback(value=X)` returned from scorer.run() has name overwritten to scorer.name
- **Expected**: `result.name == scorer.name` when the feedback was created without explicit name
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:406-422`; `/testbed/tests/genai/scorers/test_scorer.py:295-315`
- **Observe**: `RETURN_VALUE` — check Feedback.name
- **Target**: `behavior_spec.py`
- **Obligations**: R5
- **Graph**: E13, N11

### C7
- **Type**: Behavior
- **Subject**: Custom Feedback name preserved
- **Relation**: `Feedback(name="custom", value=X)` has its explicit name preserved
- **Expected**: `result.name == "custom"` — not overwritten
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:406-422` (only DEFAULT_FEEDBACK_NAME overwrites); `/testbed/tests/genai/scorers/test_scorer.py:295-315`
- **Observe**: `RETURN_VALUE` — check Feedback.name
- **Target**: `behavior_spec.py`
- **Obligations**: R5
- **Graph**: E13, N11

### C8
- **Type**: Behavior
- **Subject**: List Feedback names preserved
- **Relation**: `list[Feedback]` returned from scorer.run() preserves all names
- **Expected**: Each feedback in list retains its original name
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:406-422`; `/testbed/tests/genai/scorers/test_scorer.py:317-331`
- **Observe**: `RETURN_VALUE` — check each Feedback.name
- **Target**: `behavior_spec.py`
- **Obligations**: R5
- **Graph**: E13, N11

### C9
- **Type**: Interface
- **Subject**: `get_all_scorers` count and types (OSS)
- **Relation**: On OSS tracking URI, returns 6 `BuiltInScorer` instances (each also `Scorer`)
- **Expected**: `len(scorers) == 6` and all `isinstance(s, BuiltInScorer)` and `isinstance(s, Scorer)`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1598`; `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-577`
- **Observe**: `RETURN_VALUE` — check length and types
- **Target**: `arch_spec.py`
- **Obligations**: R4
- **Graph**: E3, E12, N4

### C10
- **Type**: Interface
- **Subject**: `get_all_scorers` expected names (OSS)
- **Relation**: OSS scorers have well-known names
- **Expected**: Names set equals `{expectations_guidelines, correctness, relevance_to_query, retrieval_sufficiency, retrieval_groundedness, equivalence}`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1586-1595`
- **Observe**: `FIELD_READ` — read `.name` attribute
- **Target**: `arch_spec.py`
- **Obligations**: R4
- **Graph**: E3, N4

### C11
- **Type**: Interface
- **Subject**: `validate_scorers` accepts valid instances
- **Relation**: A list of valid `Scorer` instances is returned unchanged
- **Expected**: `validate_scorers([Correctness(), RelevanceToQuery()]) == [Correctness(), RelevanceToQuery()]`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:47-49`
- **Observe**: `RETURN_VALUE` — check list equality
- **Target**: `arch_spec.py`
- **Obligations**: R3
- **Graph**: E1, N2

### C12
- **Type**: Failure
- **Subject**: `validate_scorers` rejects non-list
- **Relation**: Passing a non-list argument raises `MlflowException`
- **Expected**: `MlflowException` with message about scorers being a list
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:35-40`
- **Observe**: `EXCEPTION` — catch `MlflowException`
- **Target**: `behavior_spec.py`
- **Obligations**: R13
- **Graph**: E14, N2

### C13
- **Type**: Failure
- **Subject**: `validate_scorers` rejects class-not-instance
- **Relation**: Passing a scorer class instead of instance raises with hint
- **Expected**: `MlflowException` with hint about instantiation
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:61-65`
- **Observe**: `EXCEPTION` — catch `MlflowException`
- **Target**: `behavior_spec.py`
- **Obligations**: R3
- **Graph**: E15, N2

### C14
- **Type**: Failure
- **Subject**: `validate_scorers` rejects nested `get_all_scorers()`
- **Relation**: Passing `[get_all_scorers()]` raises with hint about unpacking. Relies on Pydantic equality for detection: `get_all_scorers() == get_all_scorers()` must be `True`.
- **Expected**: `MlflowException` with hint about using `get_all_scorers()` directly
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:54-60`
- **Observe**: `EXCEPTION` — catch `MlflowException`
- **Target**: `behavior_spec.py`
- **Obligations**: R3
- **Graph**: E16, N2
- **Note**: The nested-list detection uses `scorer == get_all_scorers()`. This depends on Pydantic `BaseModel.__eq__` comparing by field values. A boundary check verifying `get_all_scorers() == get_all_scorers()` is `True` is included in the behavior spec.

### C15
- **Type**: Behavior
- **Subject**: `validate_scorers` empty list
- **Relation**: Passing an empty list returns an empty list
- **Expected**: `validate_scorers([]) == []`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:42-43`
- **Observe**: `RETURN_VALUE` — check empty list
- **Target**: `behavior_spec.py`
- **Obligations**: R13
- **Graph**: E1, N2

### C16
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` legacy column mapping
- **Relation**: DataFrame with `request` and `response` columns maps to `inputs` and `outputs`
- **Expected**: Scorers requiring `inputs`/`outputs` do not log missing columns when `request`/`response` present
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:115-121`
- **Observe**: `SIDE_EFFECT` — check that inputs/outputs are not in missing-column logs
- **Target**: `arch_spec.py`
- **Obligations**: R7, R2
- **Graph**: E8, N3

### C17
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` expectations explosion
- **Relation**: DataFrame with `expectations` column containing `{"expected_response": "x", "my_guideline": "y"}` adds `expectations/expected_response` and `expectations/my_guideline` to available columns
- **Expected**: Scorers that need `expectations/expected_response` see it as available; scorers that need `expectations/my_guideline` see it as available
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:137-148`
- **Observe**: `SIDE_EFFECT` — check log messages (or lack thereof) for column requirements
- **Target**: `arch_spec.py`
- **Obligations**: R8, R2
- **Graph**: E9, N3

### C18
- **Type**: Failure
- **Subject**: `valid_data_for_builtin_scorers` rejects non-dict expectations
- **Relation**: DataFrame with `expectations` column containing a string (not dict) raises `MlflowException`
- **Expected**: `MlflowException` with message about expectations column must be a dictionary
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:141-146`
- **Observe**: `EXCEPTION` — catch `MlflowException`
- **Target**: `behavior_spec.py`
- **Obligations**: R8, R2
- **Graph**: E9, N3

### C19
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` trace inference
- **Relation**: DataFrame with only `trace` column makes `inputs` and `outputs` available for scorers
- **Expected**: No missing-column log for scorers requiring inputs/outputs when trace column exists
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:131-133`
- **Observe**: `SIDE_EFFECT` — check that `inputs`/`outputs` columns are not reported as missing
- **Target**: `behavior_spec.py`
- **Obligations**: R9, R2
- **Graph**: E11, N3

### C20
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` predict_fn inference
- **Relation**: DataFrame with only `inputs` and a `predict_fn` makes `outputs` and `trace` available
- **Expected**: Scorers requiring `outputs` or `trace` do not report missing columns
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:127-134`
- **Observe**: `SIDE_EFFECT` — check that outputs are not reported missing
- **Target**: `behavior_spec.py`
- **Obligations**: R10, R2
- **Graph**: E10, N3

### C21
- **Type**: Behavior
- **Subject**: `valid_data_for_builtin_scorers` missing column logging
- **Relation**: When a scorer requires a column not present in data, a log message is emitted but no exception raised
- **Expected**: `_logger.info` called with message about missing columns; function returns None
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:150-163`
- **Observe**: `SIDE_EFFECT` — intercept log output
- **Target**: `behavior_spec.py`
- **Obligations**: R11, R2
- **Graph**: E7, N3

### C22
- **Type**: Behavior
- **Subject**: `validate_aggregations` accepts valid strings
- **Relation**: `validate_aggregations(["min", "max", "mean", "median", "variance", "p90"])` returns None
- **Expected**: No exception raised
- **Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (existing `validate_aggregations`); `/testbed/mlflow/genai/scorers/aggregation.py:22`
- **Observe**: `RETURN_VALUE` — returns None without exception
- **Target**: `behavior_spec.py`
- **Obligations**: R6
- **Graph**: N9

### C23
- **Type**: Failure
- **Subject**: `validate_aggregations` rejects invalid string
- **Relation**: `validate_aggregations(["invalid_agg"])` raises `MlflowException`
- **Expected**: Exception with message "Invalid aggregation 'invalid_agg'"
- **Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (existing)
- **Observe**: `EXCEPTION` — catch `MlflowException`
- **Target**: `behavior_spec.py`
- **Obligations**: R6
- **Graph**: N9

### C24
- **Type**: Behavior
- **Subject**: `validate_aggregations` accepts callable
- **Relation**: `validate_aggregations([lambda x: sum(x)/len(x)])` returns None
- **Expected**: No exception; callable is accepted
- **Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (existing)
- **Observe**: `RETURN_VALUE` — returns None
- **Target**: `behavior_spec.py`
- **Obligations**: R6
- **Graph**: N9

### C25
- **Type**: Failure
- **Subject**: `validate_aggregations` rejects non-string non-callable
- **Relation**: `validate_aggregations([42])` raises `MlflowException`
- **Expected**: Exception with message about "Aggregation must be either a string"
- **Evidence**: `/testbed/mlflow/genai/scorers/validation.py` (existing)
- **Observe**: `EXCEPTION` — catch `MlflowException`
- **Target**: `behavior_spec.py`
- **Obligations**: R6
- **Graph**: N9

### C26
- **Type**: Interface
- **Subject**: `scorer` decorator preserves function behavior
- **Relation**: A decorated function that takes `outputs` and returns `bool` works correctly when called via `.run()`
- **Expected**: `decorated.run(outputs="test")` returns the bool result of the original function
- **Evidence**: `/testbed/tests/genai/scorers/test_scorer.py` multiple tests; `/testbed/mlflow/genai/scorers/base.py:372-384`
- **Observe**: `RETURN_VALUE` — check the output value
- **Target**: `behavior_spec.py`
- **Obligations**: R1
- **Graph**: E4, E13, N5, N6, N11

### C27
- **Type**: Behavior
- **Subject**: Legacy Metric support in `validate_scorers`
- **Relation**: When `databricks.agents` is installed and a `databricks.rag_eval.evaluation.metrics.Metric` instance is passed, it is accepted and a deprecation warning is logged
- **Expected**: `validate_scorers` accepts Metric instances alongside Scorer instances without raising
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:48-53,65-70`
- **Observe**: `RETURN_VALUE` — check that Metric instances pass validation; `SIDE_EFFECT` — check warning log
- **Target**: `behavior_spec.py`
- **Obligations**: R12
- **Graph**: E6, N2
- **Note**: This contract is conditional on `databricks.agents` being installed. When not installed, legacy Metric instances fall through to the invalid-item error path.

### C28
- **Type**: Behavior
- **Subject**: `Scorer.run` accepts None return
- **Relation**: A `@scorer`-decorated function returning `None` does not raise an exception and returns `None`
- **Expected**: `scorer_func.run(inputs={"q": "test"}, outputs="answer")` returns `None` without raising `MlflowException`
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py:395` (`or result is None`); `/testbed/tests/genai/scorers/test_scorer.py:268-274` (`test_custom_scorer_allow_none_return`)
- **Observe**: `RETURN_VALUE` — check that None is returned without exception
- **Target**: `behavior_spec.py`
- **Obligations**: R14, R1
- **Graph**: E13, N11

### C29
- **Type**: Behavior
- **Subject**: `valid_data_for_builtin_scorers` NaN expectations skip
- **Relation**: DataFrame with `expectations` column containing `NaN` values does not raise `MlflowException`; NaN values are silently skipped
- **Expected**: Function returns None without raising, even when `NaN` is present in the expectations column alongside valid dict values
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:140-141` (`if pd.isna(value): continue`)
- **Observe**: `RETURN_VALUE` — function returns None without raising `MlflowException`
- **Target**: `behavior_spec.py`
- **Obligations**: R15, R8
- **Graph**: E17, E9, N3
