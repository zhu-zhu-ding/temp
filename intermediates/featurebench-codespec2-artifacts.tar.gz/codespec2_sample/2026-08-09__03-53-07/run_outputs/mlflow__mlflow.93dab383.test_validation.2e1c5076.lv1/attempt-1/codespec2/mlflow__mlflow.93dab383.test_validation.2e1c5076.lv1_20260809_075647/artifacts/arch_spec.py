"""
Executable architecture spec for MLflow GenAI scorer validation system.

Exercises public entry points and verifies CALL/CONTROL/DATA connectivity
between the scorer decorator, validation functions, and builtin scorer
registration. Each check_* function validates architectural contracts
from semantic_ir.md.

Contracts: C1, C2, C3, C4, C9, C10, C11, C16, C17
"""

import inspect
import functools
import logging
import sys
import os

# Ensure /testbed is on path
sys.path.insert(0, "/testbed")

import mlflow
from mlflow.genai.scorers.base import Scorer, ScorerKind
from mlflow.genai.scorers import (
    Correctness,
    RelevanceToQuery,
    get_all_scorers,
)
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
from mlflow.genai.scorers.validation import (
    validate_scorers,
    valid_data_for_builtin_scorers,
)

import pandas as pd


def check_C1_scorer_decorator_creates_scorer_instance():
    """C1: @scorer produces a Scorer instance with kind == DECORATOR."""
    from mlflow.genai.scorers.base import scorer

    @scorer
    def my_scorer(outputs):
        return len(outputs) > 0

    assert isinstance(my_scorer, Scorer), (
        f"Expected Scorer instance, got {type(my_scorer)}"
    )
    assert my_scorer.kind == ScorerKind.DECORATOR, (
        f"Expected DECORATOR kind, got {my_scorer.kind}"
    )
    print("PASS: C1 - scorer decorator creates Scorer instance with DECORATOR kind")


def check_C2_scorer_name_explicit_and_fallback():
    """C2: scorer name parameter takes precedence; fallback to function name."""
    from mlflow.genai.scorers.base import scorer

    @scorer(name="explicit_name")
    def some_func(outputs):
        return True

    assert some_func.name == "explicit_name", (
        f"Expected 'explicit_name', got '{some_func.name}'"
    )

    @scorer
    def fallback_func(outputs):
        return True

    assert fallback_func.name == "fallback_func", (
        f"Expected 'fallback_func', got '{fallback_func.name}'"
    )
    print("PASS: C2 - scorer name explicit and fallback work correctly")


def check_C3_scorer_signature_includes_self():
    """C3: __call__ signature includes 'self' as first parameter."""
    from mlflow.genai.scorers.base import scorer

    @scorer
    def my_scorer(outputs, expectations):
        return outputs == expectations.get("expected")

    sig = inspect.signature(my_scorer.__call__)
    params = list(sig.parameters.keys())
    assert params[0] == "self", (
        f"Expected 'self' as first parameter, got '{params[0]}'"
    )
    assert "outputs" in params, "Expected 'outputs' in signature"
    assert "expectations" in params, "Expected 'expectations' in signature"
    print("PASS: C3 - scorer __call__ signature includes self + original params")


def check_C4_scorer_partial_application():
    """C4: scorer(name=...) without func returns a partial applicable later."""
    from mlflow.genai.scorers.base import scorer

    partial_scorer = scorer(name="late_bound", description="A late-bound scorer")

    assert isinstance(partial_scorer, functools.partial), (
        f"Expected functools.partial, got {type(partial_scorer)}"
    )

    # Apply the partial to a function
    @partial_scorer
    def late_func(outputs):
        return bool(outputs)

    assert late_func.name == "late_bound"
    assert late_func.description == "A late-bound scorer"
    assert isinstance(late_func, Scorer)
    print("PASS: C4 - scorer partial application works")


def check_C9_get_all_scorers_count_and_types_oss():
    """C9: get_all_scorers returns 6 BuiltInScorer instances on OSS URI."""
    # Ensure we're on a non-databricks URI
    mlflow.set_tracking_uri("")
    scorers = get_all_scorers()

    assert len(scorers) == 6, (
        f"Expected 6 scorers for OSS, got {len(scorers)}"
    )
    for s in scorers:
        assert isinstance(s, BuiltInScorer), (
            f"Expected BuiltInScorer, got {type(s)}"
        )
        assert isinstance(s, Scorer), (
            f"Expected Scorer, got {type(s)}"
        )
    print("PASS: C9 - get_all_scorers returns 6 BuiltInScorer instances on OSS")


def check_C10_get_all_scorers_names():
    """C10: get_all_scorers returns scorers with expected names."""
    mlflow.set_tracking_uri("")
    scorers = get_all_scorers()

    expected_names = {
        "expectations_guidelines",
        "correctness",
        "relevance_to_query",
        "retrieval_sufficiency",
        "retrieval_groundedness",
        "equivalence",
    }
    actual_names = {s.name for s in scorers}

    assert actual_names == expected_names, (
        f"Expected names {expected_names}, got {actual_names}"
    )
    print("PASS: C10 - get_all_scorers returns scorers with expected names")


def check_C11_validate_scorers_accepts_valid_instances():
    """C11: validate_scorers accepts and returns valid Scorer instances."""
    scorers_in = [Correctness(), RelevanceToQuery()]
    scorers_out = validate_scorers(scorers_in)

    assert scorers_out == scorers_in, (
        "Expected same list to be returned"
    )
    assert len(scorers_out) == 2
    assert all(isinstance(s, Scorer) for s in scorers_out)
    print("PASS: C11 - validate_scorers accepts valid Scorer instances")


def check_C16_legacy_column_mapping():
    """C16: valid_data_for_builtin_scorers maps request->inputs, response->outputs."""
    # Create a DataFrame with legacy column names
    df = pd.DataFrame({
        "request": ["test input"],
        "response": ["test output"],
        "expectations": [{"expected_response": "expected"}],
    })

    # Use a scorer that requires inputs, outputs, expectations/expected_response
    scorer = Correctness()
    # Should not raise; should not log missing columns for inputs/outputs
    # since request/response map to them
    with _catch_log(logging.INFO, "mlflow.genai.scorers.validation") as logs:
        valid_data_for_builtin_scorers(df, [scorer])

    # The function should NOT report inputs or outputs as missing
    for log_output in logs:
        assert "inputs" not in log_output, (
            f"Should not report inputs as missing after request->inputs mapping: {log_output}"
        )
        assert "outputs" not in log_output, (
            f"Should not report outputs as missing after response->outputs mapping: {log_output}"
        )
    print("PASS: C16 - valid_data_for_builtin_scorers maps legacy column names")


def check_C17_expectations_explosion():
    """C17: valid_data_for_builtin_scorers explodes expectations dict keys."""
    df = pd.DataFrame({
        "inputs": ["test input"],
        "outputs": ["test output"],
        "expectations": [
            {"expected_response": "expected", "my_guideline": "be helpful"}
        ],
    })

    # Equivalence scorer requires expectations/expected_response
    from mlflow.genai.scorers import Equivalence
    scorer = Equivalence()

    with _catch_log(logging.INFO, "mlflow.genai.scorers.validation") as logs:
        valid_data_for_builtin_scorers(df, [scorer])

    # The function should NOT report expectations/expected_response as missing
    for log_output in logs:
        assert "expected_response" not in log_output, (
            f"Should not report expected_response as missing: {log_output}"
        )
    print("PASS: C17 - valid_data_for_builtin_scorers explodes expectations keys")


# ---------------------------------------------------------------------------
# Helper: context manager to capture log records
# ---------------------------------------------------------------------------
import contextlib
import io


class _catch_log:
    """Context manager to capture log records from a specific logger."""

    def __init__(self, level, logger_name):
        self.level = level
        self.logger_name = logger_name
        self._handler = None
        self._stream = None
        self._logger = None
        self._old_level = None
        self.records = []

    def __enter__(self):
        self._logger = logging.getLogger(self.logger_name)
        self._old_level = self._logger.level
        self._logger.setLevel(self.level)
        self._stream = io.StringIO()
        self._handler = logging.StreamHandler(self._stream)
        self._handler.setLevel(self.level)
        self._logger.addHandler(self._handler)
        return self

    def __exit__(self, *args):
        if self._handler:
            self._logger.removeHandler(self._handler)
            self._handler.flush()
            self.records = self._stream.getvalue().splitlines()
            self._handler.close()
        if self._old_level is not None:
            self._logger.setLevel(self._old_level)

    def __iter__(self):
        return iter(self.records)

    def __contains__(self, item):
        return any(item in record for record in self.records)


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    check_C1_scorer_decorator_creates_scorer_instance()
    check_C2_scorer_name_explicit_and_fallback()
    check_C3_scorer_signature_includes_self()
    check_C4_scorer_partial_application()
    check_C9_get_all_scorers_count_and_types_oss()
    check_C10_get_all_scorers_names()
    check_C11_validate_scorers_accepts_valid_instances()
    check_C16_legacy_column_mapping()
    check_C17_expectations_explosion()
    print("\nAll architecture checks passed.")
