# Compile Checker Report

- Status: needs_revision

## Req-Test Evidence

### RT1: `test_get_all_scorers_oss` validates return count and types
- Test: `tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss`
- Location: `tests/genai/scorers/test_builtin_scorers.py:570-577`
- Key Code:
  ```python
  @pytest.mark.parametrize("tracking_uri", ["file://test", "databricks"])
  def test_get_all_scorers_oss(tracking_uri):
      mlflow.set_tracking_uri(tracking_uri)
      scorers = get_all_scorers()
      assert len(scorers) == (8 if tracking_uri == "databricks" else 6)
      assert all(isinstance(scorer, Scorer) for scorer in scorers)
  ```
- Test Lens: API/default/signature — validates the cardinality and type contract of `get_all_scorers()` under different tracking URIs.
- Implied Requirement: `get_all_scorers()` must return 6 `Scorer` instances on OSS URIs, 8 on Databricks URIs, with all elements being `Scorer` instances.
- IR / Spec Mapping: R4, C9, C10, `check_C9_get_all_scorers_count_and_types_oss`, `check_C10_get_all_scorers_names`.
- Verdict: covered.

### RT2: `test_custom_scorer_overwrites_default_feedback_name` validates feedback name normalization
- Test: `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name`
- Location: `tests/genai/scorers/test_scorer.py:295-315`
- Key Code:
  ```python
  @pytest.mark.parametrize(
      ("scorer_return", "expected_feedback_name"),
      [
          (Feedback(value=42, rationale="rationale"), "my_scorer"),
          (Feedback(name="custom_name", value=42, rationale="rationale"), "custom_name"),
      ],
  )
  def test_custom_scorer_overwrites_default_feedback_name(scorer_return, expected_feedback_name):
      @scorer
      def my_scorer(inputs, outputs):
          return scorer_return
      feedback = my_scorer.run(
          inputs={"question": "What is the capital of France?"},
          outputs="The capital of France is Paris.",
      )
      assert feedback.name == expected_feedback_name
      assert feedback.value == 42
  ```
- Test Lens: Dataflow/argument forwarding — validates that `run()` overwrites the default feedback name to the scorer name, but preserves explicit names.
- Implied Requirement: `Scorer.run()` must rewrite `Feedback.name` from `DEFAULT_FEEDBACK_NAME` (i.e. `"feedback"`) to the scorer's `.name`, but must not overwrite an explicitly set name.
- IR / Spec Mapping: R5, C6, C7, `check_C6_default_feedback_name_overwrite`, `check_C7_custom_feedback_name_preserved`.
- Verdict: covered.

### RT3: `test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list` validates list feedback name preservation
- Test: `tests/genai/scorers/test_scorer.py::test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list`
- Location: `tests/genai/scorers/test_scorer.py:317-331`
- Key Code:
  ```python
  def test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list():
      @scorer
      def my_scorer(inputs, outputs):
          return [
              Feedback(name="big_question", value=42, rationale="..."),
              Feedback(name="small_question", value=1, rationale="..."),
          ]
      feedbacks = my_scorer.run(
          inputs={"question": "What is the capital of France?"},
          outputs="The capital of France is Paris.",
      )
      assert feedbacks[0].name == "big_question"
      assert feedbacks[1].name == "small_question"
  ```
- Test Lens: Collection cardinality/order — validates that when a scorer returns a list of Feedback objects, all names are preserved and no overwrite occurs.
- Implied Requirement: For `list[Feedback]` return values, `Scorer.run()` must not modify any feedback names.
- IR / Spec Mapping: R5, C8, `check_C8_list_feedback_names_preserved`.
- Verdict: covered.

### RT4: `test_custom_scorer_allow_none_return` validates None return acceptance
- Test: `tests/genai/scorers/test_scorer.py::test_custom_scorer_allow_none_return`
- Location: `tests/genai/scorers/test_scorer.py:268-274`
- Key Code:
  ```python
  def test_custom_scorer_allow_none_return():
      @scorer
      def dummy_scorer(inputs, outputs):
          return None

      assert dummy_scorer.run(inputs={"question": "query"}, outputs="answer") is None
  ```
- Test Lens: API/signature — validates that `None` is an acceptable return value from `Scorer.run()`, distinct from the documented return types (bool, int, float, str, Feedback, list[Feedback]).
- Implied Requirement: `Scorer.run()` must accept `None` as a valid return and pass it through without raising.
- IR / Spec Mapping: **missing** — no explicit R, C, or `check_*` covers this. R1 lists allowed return types as `{bool, int, float, str, Feedback, list[Feedback]}` but omits `None`. The `run()` implementation at `base.py:395` has `or result is None` confirming this contract.
- Verdict: missing.

### RT5: `test_scorer_name_works` validates explicit scorer name via partial application
- Test: `tests/genai/scorers/test_scorer.py::test_scorer_name_works`
- Location: `tests/genai/scorers/test_scorer.py:70-74`
- Key Code:
  ```python
  @pytest.mark.parametrize(
      "dummy_scorer", [AlwaysYesScorer(name="always_no"), scorer(name="always_no")(always_yes)]
  )
  def test_scorer_name_works(sample_data, dummy_scorer, is_in_databricks):
      _SCORER_NAME = "always_no"
      result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])
      assert any(_SCORER_NAME in metric for metric in result.metrics.keys())
  ```
- Test Lens: API/default/signature — validates that `scorer(name="always_no")` partial application followed by decoration `(always_yes)` produces a scorer with the given name that appears in evaluation metrics.
- Implied Requirement: The `scorer` decorator must support both `@scorer` (name from function) and `@scorer(name="X")` (explicit name) patterns, and the resulting scorer name must propagate through `evaluate()` into result metrics.
- IR / Spec Mapping: R1, C2, C4, `check_C2_scorer_name_explicit_and_fallback`, `check_C4_scorer_partial_application`.
- Verdict: covered.

### RT6: `test_scorer_existence_in_metrics` validates decorator and subclass both produce evaluable scorers
- Test: `tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics`
- Location: `tests/genai/scorers/test_scorer.py:62-67`
- Key Code:
  ```python
  @pytest.mark.parametrize("dummy_scorer", [AlwaysYesScorer(name="always_yes"), scorer(always_yes)])
  def test_scorer_existence_in_metrics(sample_data, dummy_scorer, is_in_databricks):
      result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])
      assert any("always_yes" in metric for metric in result.metrics.keys())
  ```
- Test Lens: API/signature — validates that both `Scorer` subclass instances and `@scorer`-decorated functions produce scorers that participate in evaluation and appear in result metrics.
- Implied Requirement: `@scorer`-decorated functions must produce `Scorer` instances that are fully compatible with `mlflow.genai.evaluate()`, returning results indistinguishable from hand-subclassed `Scorer` instances.
- IR / Spec Mapping: R1, C26, `check_C26_scorer_preserves_function_behavior`.
- Verdict: covered.

## Findings

### Finding 1: Missing obligation — None return from scorer
- Category: lost_obligation
- Subrequirements: R1 (incomplete), missing R13a (None return acceptance)
- Evidence: Native test `test_custom_scorer_allow_none_return` (RT4) validates that `dummy_scorer.run(...)` returns `None` without error. The `Scorer.run()` implementation at `/testbed/mlflow/genai/scorers/base.py:395` explicitly includes `or result is None` in the return-type validation gate.
- Cause: The task's Interface Description 1 lists allowed return types as `{bool, int, float, str, Feedback, list[Feedback]}` but omits `None`. The IR's R1 mirrors this incomplete list. The native test RT4 establishes an implicit contract that `None` must be accepted.
- Impact: If an implementer only validates against the documented set `{bool, int, float, str, Feedback, list[Feedback]}`, a scorer returning `None` would raise an `MlflowException`, breaking the native test. The generated specs provide no check for this path.
- Required Change: Add an explicit requirement (e.g., R14) that `Scorer.run()` must accept `None` as a valid return. Add a corresponding contract C28 and `check_C28_scorer_accepts_none_return` to `behavior_spec.py`. The check should decorate a function returning `None`, call `.run()`, and assert no exception is raised and `None` is returned.
- Req-Test Evidence: RT4

### Finding 2: Weak contract — C14 nested `get_all_scorers()` detection is fragile
- Category: weak_contract
- Subrequirements: R3, C14
- Evidence: The reference implementation at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:54` uses `scorer == get_all_scorers()` to detect nested `[get_all_scorers()]`. This comparison relies on `get_all_scorers()` returning a new list of fresh scorer instances that are value-equal to a previously-returned list. If scorer instances implement `__eq__` by identity (as Pydantic models do by default), this check would fail and the helpful hint would not be shown.
- Cause: The IR (C14) faithfully copies the reference implementation's equality-based detection but does not flag the fragility. The Pydantic `BaseModel` instances used for scorers compare by field values, which should work, but this is an implicit dependency on Pydantic's equality semantics that the contract does not verify.
- Impact: If scorer `__eq__` semantics ever change (e.g., a custom `__eq__` on a scorer subclass), the nested-list detection would silently fail, and the user would get a generic "invalid item type: list" error instead of the helpful "use scorers=get_all_scorers()" hint.
- Required Change: C14 should additionally verify that `get_all_scorers().__eq__` semantics produce the expected comparison, or the spec should add a boundary check that `get_all_scorers() == get_all_scorers()` evaluates to `True`. Alternatively, the IR could note this design decision as an explicit assumption.
- Req-Test Evidence: None (no applicable native test for this specific error path).

### Finding 3: Unreachable graph — spec imports fail because target functions are not yet implemented
- Category: unexecutable_spec
- Subrequirements: R2, R3, R4 (all references to `get_all_scorers`, `validate_scorers`, `valid_data_for_builtin_scorers`)
- Evidence: Running `arch_spec.py` produces `ImportError: cannot import name 'get_all_scorers' from 'mlflow.genai.scorers'`. Running `behavior_spec.py` produces the same error. The functions `get_all_scorers` (builtin_scorers.py), `validate_scorers` (validation.py), and `valid_data_for_builtin_scorers` (validation.py) are referenced by the specs but do not exist in the current repository. Additionally, the `scorer` decorator in `base.py:847` is missing the inner `CustomScorer` class definition (lines 999-1015 in the reference), causing `NameError: name 'CustomScorer' is not defined` when `@scorer` is used.
- Cause: The IR correctly identifies these as "to be implemented" and provides reference evidence at `/testbed/libs/skinny/`. The specs are written against the reference behavior. However, the specs import these symbols unconditionally at module level, making them unexecutable until the implementations exist.
- Impact: None of the 27 contracts in the arch/behavior specs can be verified by execution. C22-C25 (`validate_aggregations`) are the only contracts whose target function exists and could theoretically be tested, but they are co-located in files that fail to import.
- Required Change: This is primarily an implementation sequencing issue rather than a spec defect. However, the specs should include a guard or note explaining the dependency on implementation completion. For the compile checker's purpose, the IR mapping is correct — the specs will become executable once R1-R4 are implemented.
- Req-Test Evidence: None (no applicable native test — this is a spec executability concern).

### Finding 4: Missing contract — `valid_data_for_builtin_scorers` NaN expectations handling
- Category: weak_contract
- Subrequirements: R8
- Evidence: The reference implementation at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:140-141` contains `if pd.isna(value): continue` to skip NaN values in the `expectations` column before the `isinstance(value, dict)` check. This means NaN expectations are silently tolerated rather than raising `MlflowException`.
- Cause: The IR's R8 says "verify each is a dict (raising MlflowException if not)" but does not account for the NaN-skip path. The spec's C18 and `check_C18_rejects_non_dict_expectations` only tests the non-dict string case, not the NaN case.
- Impact: An implementer who reads only the IR might raise `MlflowException` for NaN expectations values, which would be stricter than the reference behavior. While this is arguably acceptable, it diverges from the reference.
- Required Change: R8 should explicitly note that NaN/missing expectations values are silently skipped. Add a contract (C28) and check verifying that a DataFrame with `NaN` in the expectations column does not raise `MlflowException`.
- Req-Test Evidence: None (no applicable native test for NaN expectations).

## Coverage

| R# | C IDs | Spec check names | Status |
|----|-------|-----------------|--------|
| R1 | C1, C2, C3, C4, C5, C26 | `check_C1`, `check_C2`, `check_C3`, `check_C4`, `check_C5`, `check_C26` | Covered; missing None return |
| R2 | C11, C16, C17, C18, C19, C20, C21 | `check_C11`, `check_C16`, `check_C17`, `check_C18`, `check_C19`, `check_C20`, `check_C21` | Covered |
| R3 | C11, C12, C13, C14 | `check_C11`, `check_C12`, `check_C13`, `check_C14` | Covered; missing general-invalid-item contract |
| R4 | C9, C10 | `check_C9`, `check_C10` | Covered |
| R5 | C6, C7, C8 | `check_C6`, `check_C7`, `check_C8` | Covered |
| R6 | C22, C23, C24, C25 | `check_C22`, `check_C23`, `check_C24`, `check_C25` | Covered |
| R7 | C16 | `check_C16` | Covered |
| R8 | C17, C18 | `check_C17`, `check_C18` | Covered; missing NaN handling |
| R9 | C19 | `check_C19` | Covered |
| R10 | C20 | `check_C20` | Covered |
| R11 | C21 | `check_C21` | Covered |
| R12 | C27 | `check_C27` | Covered (conditional) |
| R13 | C12, C15 | `check_C12`, `check_C15` | Covered |
| — | — | None return (RT4) | **Uncovered** |

Unreferenced C: none — all 27 contracts map to at least one R and one `check_*`.

## Judge Focus

1. **Implement `CustomScorer` class** inside the `scorer()` function in `base.py` (lines ~999-1015 from reference), enabling the decorator to produce valid `Scorer` instances with `_original_func`, `__call__` delegation, and `kind=DECORATOR`.

2. **Implement `get_all_scorers()`** in `builtin_scorers.py` returning 6 OSS / 8 Databricks `BuiltInScorer` instances, enabling C9-C10 and the `__init__.py` lazy import.

3. **Implement `validate_scorers()`** in `validation.py` with the full error-hint structure (non-list, class-not-instance, nested-get_all_scorers, legacy Metric, general invalid), enabling C11-C15 and C27.

4. **Implement `valid_data_for_builtin_scorers()`** in `validation.py` with column mapping, trace/predict_fn inference, expectations explosion + NaN skip, and missing-column logging, enabling C16-C21.

5. **Add None-return coverage**: Extend R1 or add a new R to capture the `None` return acceptance tested by RT4, with a corresponding C and `check_*` in `behavior_spec.py`.

6. **Add NaN expectations coverage**: Extend R8 to cover the NaN-skip behavior, with a corresponding C and `check_*`.

7. **Verify Pydantic equality semantics** for C14's `get_all_scorers() == get_all_scorers()` assumption; add a boundary check if needed.

8. **Add import of `validate_scorers` and `valid_data_for_builtin_scorers`** in `/testbed/mlflow/genai/evaluation/base.py` — the functions are called at lines 243 and 248 but never imported.
