# Requirement Compile Agent Skill

This is durable method guidance, not task evidence. Update it after compiling
each task with concise lessons about ambiguity, evidence gaps, and IR quality.

## Responsibilities

1. Treat the task as the authority for required behavior and use repository
   evidence only to locate compatible implementation paths and observers.
2. Lower prose into atomic L1 Requirement Obligations. Split independent
   behavior, failure, state, dataflow, and compatibility claims.
3. Build an L2 Functional Design Graph with only `CALL`, `CONTROL`, `DATA`,
   and `STATE` edges supported by source, callers, exports, or native tests.
4. Attach L3 Verifiable Contracts to graph nodes/edges. Every contract needs a
   typed relation, expected result, evidence, and explicit observation method.
5. Make observability first class: identify the public observer or runtime
   boundary where a future test can mechanically validate the contract.
6. Compile every contract into `arch_spec.py` or `behavior_spec.py`, preserving
   its contract ID and public-entry-to-observer path.

## Guardrails

- Write only the supplied executable spec artifacts; never production code or
  repository-native tests.
- Do not infer dataflow from symbol names or docstrings alone.
- Record unknowns explicitly rather than manufacturing exact defaults, errors,
  state values, or call arguments.
- Ensure each L1 obligation reaches at least one L3 contract through L2.

## Lessons

### Lesson 1: Dual-source evidence (task + repo libs) resolves implementation ambiguity
When the task Interface Description declares a function signature but the main
source tree contains only a stub or partial implementation, look for reference
implementations in parallel library directories (`libs/skinny/`, `libs/tracing/`).
These often contain the canonical implementation that callers (e.g., `evaluate()`)
already import from. Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py`
contained full `validate_scorers` and `valid_data_for_builtin_scorers` while
`/testbed/mlflow/genai/scorers/validation.py` had only the helper
`validate_aggregations`. Similarly, `get_all_scorers` existed only in the libs
copies, not in the main `builtin_scorers.py`.

### Lesson 2: Test imports reveal expected module locations
When a function is declared in the task but not found in the target file, search
the test suite for import statements. `from mlflow.genai.scorers.builtin_scorers
import get_all_scorers` in `/testbed/tests/genai/scorers/test_builtin_scorers.py`
confirmed the expected location before the function existed there. This is a
reliable way to determine where each interface must be implemented.

### Lesson 3: Caller sites define the contract shape
The code at `/testbed/mlflow/genai/evaluation/base.py:243,248` shows the exact
call signatures used in production: `validate_scorers(scorers)` and
`valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)`. These caller
sites are the ground truth for argument names, types, and ordering — more
reliable than prose descriptions.

### Lesson 4: Trace DATA edges for column-name transformations
The `valid_data_for_builtin_scorers` function performs non-trivial column name
mapping (`request`→`inputs`, `response`→`outputs`) that bridges between the
evaluation harness (`_convert_to_eval_set`) and scorer requirements. These
transformations must be modeled as explicit DATA edges in the graph, separate
from CONTROL edges for conditional column inference (trace, predict_fn).

### Lesson 5: Split arch and behavior specs by observability
`arch_spec.py` tests should use RETURN_VALUE and FIELD_READ observers for
structural contracts (type checks, signatures, counts, naming). `behavior_spec.py`
should use EXCEPTION and SIDE_EFFECT observers for failure modes, logging,
data transformations, and boundary conditions. This separation prevents
architectural tests from depending on runtime state setup and vice versa.

### Lesson 6: Scorer.kind distinguishes decorator vs. builtin at architecture level
The `ScorerKind` enum (CLASS, BUILTIN, DECORATOR) creates a type-level
distinction that affects serialization, registration, and validation paths.
This is a CONTROL-relevant property that must appear in the graph because
`validate_scorers` and `Scorer.model_dump()` branch on it. The `CustomScorer`
inner class reports `DECORATOR` while `BuiltInScorer` reports `BUILTIN`.

### Lesson 7: Native tests reveal implicit contracts not in Interface Descriptions
The native test `test_custom_scorer_allow_none_return` at
`/testbed/tests/genai/scorers/test_scorer.py:268-274` validates that
`Scorer.run()` accepts `None` as a return value. However, the Interface
Description 1 only documents `{bool, int, float, str, Feedback, list[Feedback]}`
as allowed return types. The reference implementation at `base.py:395` confirms
this with `or result is None`. Always cross-reference the official test suite
for implicit contracts that the prose documentation may omit. Evidence: RT4
in the Compile Checker report.

### Lesson 8: NaN/missing-value bypass paths need explicit contracts
The reference implementation at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:140-141`
contains `if pd.isna(value): continue` which silently skips NaN values in the
`expectations` column before the `isinstance(value, dict)` check. This means
NaN expectations are tolerated rather than raising `MlflowException`. If this
bypass is not captured as an explicit requirement, an implementer reading only
the IR might raise for NaN values, creating a stricter-than-reference behavior.
Every conditional bypass of a validation check must have its own R and C.
Evidence: Finding 4 in the Compile Checker report.

### Lesson 9: Verify Pydantic equality semantics for value-based comparisons
The reference implementation at `validation.py:54` uses `scorer == get_all_scorers()`
to detect the common mistake `scorers=[get_all_scorers()]`. This comparison
relies on Pydantic `BaseModel.__eq__` comparing by field values rather than
identity. If scorer `__eq__` semantics change (e.g., a custom `__eq__` on a
subclass), the nested-list detection would silently fail. Add a boundary check
verifying `get_all_scorers() == get_all_scorers()` is `True` to guard this
implicit dependency. Evidence: Finding 2 in the Compile Checker report.
