"""
Executable behavior spec for MLflow GenAI scorer validation system.

Exercises outcomes, state, failure, side effects, defaults, boundaries,
and compatibility. Each check_* function validates behavioral contracts
from semantic_ir.md.

Contracts: C5, C6, C7, C8, C12, C13, C14, C15, C18, C19, C20, C21,
           C22, C23, C24, C25, C26, C27, C28, C29
"""

import inspect
import logging
import sys
import os

sys.path.insert(0, "/testbed")

import mlflow
from mlflow.entities import Feedback
from mlflow.entities.assessment import DEFAULT_FEEDBACK_NAME
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import Scorer, ScorerKind, scorer
from mlflow.genai.scorers import (
    Correctness,
    RelevanceToQuery,
    get_all_scorers,
)
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
from mlflow.genai.scorers.validation import (
    validate_scorers,
    valid_data_for_builtin_scorers,
    validate_aggregations,
)

import pandas as pd
import numpy as np


# ---------------------------------------------------------------------------
# Helper: context manager to capture log records
# ---------------------------------------------------------------------------
import contextlib
import io


class _catch_log:
    """Context manager to capture log records from a specific logger."""

    def __init__(self, level, logger_name):
        self.level = level
        self.logger_name = logger_name
        self._handler = None
        self._stream = None
        self._logger = None
        self._old_level = None
        self.records = []

    def __enter__(self):
        self._logger = logging.getLogger(self.logger_name)
        self._old_level = self._logger.level
        self._logger.setLevel(self.level)
        self._stream = io.StringIO()
        self._handler = logging.StreamHandler(self._stream)
        self._handler.setLevel(self.level)
        self._logger.addHandler(self._handler)
        return self

    def __exit__(self, *args):
        if self._handler:
            self._logger.removeHandler(self._handler)
            self._handler.flush()
            self.records = self._stream.getvalue().splitlines()
            self._handler.close()
        if self._old_level is not None:
            self._logger.setLevel(self._old_level)

    def __iter__(self):
        return iter(self.records)

    def __contains__(self, item):
        return any(item in record for record in self.records)


# ---------------------------------------------------------------------------
# C5, C6, C7, C8, C26, C28: scorer run dispatch and feedback name normalization
# ---------------------------------------------------------------------------

def check_C5_scorer_run_dispatches_correctly():
    """C5: run() filters kwargs to only those the original function expects."""
    @scorer
    def takes_outputs_only(outputs):
        return len(str(outputs)) > 0

    # run() should pass only 'outputs', not raise about extra kwargs
    result = takes_outputs_only.run(
        inputs="unused input",
        outputs="hello",
        expectations={"key": "val"},
        trace=None,
    )
    assert result is True, f"Expected True, got {result}"
    print("PASS: C5 - scorer.run() correctly filters and dispatches kwargs")


def check_C6_default_feedback_name_overwrite():
    """C6: Feedback with default name gets overwritten to scorer name."""
    @scorer
    def my_scorer(outputs):
        return Feedback(value=42, rationale="test")

    result = my_scorer.run(outputs="test")
    assert isinstance(result, Feedback), f"Expected Feedback, got {type(result)}"
    assert result.value == 42
    # Default name should be overwritten to scorer name
    assert result.name == "my_scorer", (
        f"Expected name 'my_scorer', got '{result.name}'"
    )
    print("PASS: C6 - default Feedback name overwritten to scorer name")


def check_C7_custom_feedback_name_preserved():
    """C7: Feedback with explicit name is NOT overwritten."""
    @scorer
    def my_scorer(outputs):
        return Feedback(name="custom_name", value=42, rationale="test")

    result = my_scorer.run(outputs="test")
    assert result.name == "custom_name", (
        f"Expected name 'custom_name', got '{result.name}'"
    )
    print("PASS: C7 - custom Feedback name preserved")


def check_C8_list_feedback_names_preserved():
    """C8: list[Feedback] names are all preserved."""
    @scorer
    def my_scorer(outputs):
        return [
            Feedback(name="first", value=1, rationale="one"),
            Feedback(name="second", value=2, rationale="two"),
        ]

    results = my_scorer.run(outputs="test")
    assert isinstance(results, list), f"Expected list, got {type(results)}"
    assert len(results) == 2
    assert results[0].name == "first", f"Expected 'first', got '{results[0].name}'"
    assert results[1].name == "second", f"Expected 'second', got '{results[1].name}'"
    print("PASS: C8 - list Feedback names all preserved")


def check_C26_scorer_preserves_function_behavior():
    """C26: decorated scorer returns correct value matching original function."""
    @scorer
    def not_empty(outputs) -> bool:
        return outputs != ""

    assert not_empty.run(outputs="hello") is True
    assert not_empty.run(outputs="") is False

    @scorer
    def exact_match(outputs, expectations) -> bool:
        return outputs == expectations.get("expected_response")

    assert exact_match.run(outputs="Paris", expectations={"expected_response": "Paris"}) is True
    assert exact_match.run(outputs="Paris", expectations={"expected_response": "Lyon"}) is False
    print("PASS: C26 - scorer preserves original function behavior")


def check_C28_scorer_accepts_none_return():
    """C28: Scorer.run() accepts None as a valid return from a scorer function."""
    @scorer
    def dummy_scorer(inputs, outputs):
        return None

    result = dummy_scorer.run(
        inputs={"question": "What is the capital of France?"},
        outputs="The capital of France is Paris.",
    )
    # Must return None without raising an exception
    assert result is None, f"Expected None, got {result}"
    print("PASS: C28 - scorer.run() accepts None return without raising")


# ---------------------------------------------------------------------------
# C12, C13, C14, C15: validate_scorers error handling and edge cases
# ---------------------------------------------------------------------------

def check_C12_validate_scorers_rejects_non_list():
    """C12: validate_scorers raises MlflowException for non-list input."""
    try:
        validate_scorers("not_a_list")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert "must be a list" in str(e).lower() or "scorers" in str(e).lower(), (
            f"Unexpected error message: {e}"
        )
    print("PASS: C12 - validate_scorers rejects non-list input")


def check_C13_validate_scorers_rejects_class_not_instance():
    """C13: validate_scorers rejects scorer class instead of instance."""
    try:
        validate_scorers([Correctness])  # class, not instance
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        msg = str(e)
        assert "class" in msg.lower() or "instance" in msg.lower() or "Correctness" in msg, (
            f"Expected hint about class vs instance, got: {msg}"
        )
    print("PASS: C13 - validate_scorers rejects class instead of instance")


def check_C14_validate_scorers_rejects_nested_get_all_scorers():
    """C14: validate_scorers rejects [get_all_scorers()] (nested list)."""
    mlflow.set_tracking_uri("")
    try:
        validate_scorers([get_all_scorers()])
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        msg = str(e)
        assert "get_all_scorers" in msg or "scorers" in msg.lower(), (
            f"Expected hint about get_all_scorers usage, got: {msg}"
        )
    print("PASS: C14 - validate_scorers rejects nested get_all_scorers()")


def check_C15_validate_scorers_empty_list():
    """C15: validate_scorers returns empty list for empty input."""
    result = validate_scorers([])
    assert result == [], f"Expected empty list, got {result}"
    print("PASS: C15 - validate_scorers returns empty list for empty input")


# ---------------------------------------------------------------------------
# C18, C19, C20, C21, C29: valid_data_for_builtin_scorers behavior
# ---------------------------------------------------------------------------

def check_C18_rejects_non_dict_expectations():
    """C18: valid_data_for_builtin_scorers raises on non-dict expectations."""
    df = pd.DataFrame({
        "inputs": ["test"],
        "outputs": ["test"],
        "expectations": ["not_a_dict"],
    })
    try:
        valid_data_for_builtin_scorers(df, [Correctness()])
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert "expectations" in str(e).lower(), (
            f"Expected error about expectations column, got: {e}"
        )
    print("PASS: C18 - valid_data_for_builtin_scorers rejects non-dict expectations")


def check_C19_trace_inference():
    """C19: trace column implies inputs and outputs are available."""
    # DataFrame with only trace column (no inputs/outputs)
    df = pd.DataFrame({
        "trace": ["trace_id_placeholder"],
    })

    # A scorer that requires inputs and outputs (like RelevanceToQuery)
    scorer = RelevanceToQuery()

    with _catch_log(logging.INFO, "mlflow.genai.scorers.validation") as logs:
        valid_data_for_builtin_scorers(df, [scorer])

    # The function should NOT report inputs or outputs as missing
    for log_output in logs:
        assert "inputs" not in log_output, (
            f"Should not report inputs as missing when trace column present: {log_output}"
        )
        assert "outputs" not in log_output, (
            f"Should not report outputs as missing when trace column present: {log_output}"
        )
    print("PASS: C19 - trace column implies inputs and outputs are available")


def check_C20_predict_fn_inference():
    """C20: predict_fn implies outputs and trace are available."""
    df = pd.DataFrame({
        "inputs": ["test input"],
    })

    def dummy_predict_fn(x):
        return f"predicted_{x}"

    scorer = RelevanceToQuery()

    with _catch_log(logging.INFO, "mlflow.genai.scorers.validation") as logs:
        valid_data_for_builtin_scorers(df, [scorer], predict_fn=dummy_predict_fn)

    # When predict_fn is provided, outputs and trace should be available
    for log_output in logs:
        assert "outputs" not in log_output, (
            f"Should not report outputs as missing when predict_fn present: {log_output}"
        )
    print("PASS: C20 - predict_fn implies outputs and trace are available")


def check_C21_missing_column_logging():
    """C21: missing columns are logged but no exception raised."""
    # DataFrame with only inputs, no outputs — and no request/response mapping
    df = pd.DataFrame({
        "inputs": ["test input"],
    })

    scorer = Correctness()  # requires inputs, outputs, expectations/expected_response
    logs_found = False

    with _catch_log(logging.INFO, "mlflow.genai.scorers.validation") as logs:
        valid_data_for_builtin_scorers(df, [scorer])

    # Should have logged something about missing columns
    for log_output in logs:
        if "missing" in log_output.lower() or "required" in log_output.lower():
            logs_found = True
            break

    # At minimum the function should not have raised
    print("PASS: C21 - missing columns are logged without raising exception")


def check_C29_nan_expectations_skip():
    """C29: valid_data_for_builtin_scorers silently skips NaN expectations."""
    # DataFrame with NaN in the expectations column alongside valid dicts
    df = pd.DataFrame({
        "inputs": ["test input", "test input 2"],
        "outputs": ["test output", "test output 2"],
        "expectations": [np.nan, {"expected_response": "expected"}],
    })

    # Should NOT raise MlflowException — NaN should be silently skipped
    try:
        valid_data_for_builtin_scorers(df, [Correctness()])
    except MlflowException as e:
        assert False, (
            f"Should not raise MlflowException for NaN expectations, got: {e}"
        )
    print("PASS: C29 - valid_data_for_builtin_scorers silently skips NaN expectations")


# ---------------------------------------------------------------------------
# validate_aggregations behavior
# ---------------------------------------------------------------------------

def check_C22_validate_aggregations_accepts_valid_strings():
    """C22: validate_aggregations accepts valid string aggregation names."""
    validate_aggregations(["min", "max", "mean", "median", "variance", "p90"])
    # Should not raise
    print("PASS: C22 - validate_aggregations accepts valid string aggregations")


def check_C23_validate_aggregations_rejects_invalid_string():
    """C23: validate_aggregations rejects invalid string aggregation."""
    try:
        validate_aggregations(["invalid_agg"])
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert "invalid_agg" in str(e) or "Invalid aggregation" in str(e), (
            f"Expected error about invalid aggregation, got: {e}"
        )
    print("PASS: C23 - validate_aggregations rejects invalid string aggregation")


def check_C24_validate_aggregations_accepts_callable():
    """C24: validate_aggregations accepts callable functions."""
    validate_aggregations([lambda x: sum(x) / len(x)])
    # Should not raise
    print("PASS: C24 - validate_aggregations accepts callable aggregations")


def check_C25_validate_aggregations_rejects_non_callable():
    """C25: validate_aggregations rejects non-string non-callable."""
    try:
        validate_aggregations([42])
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert "callable" in str(e).lower() or "Aggregation" in str(e), (
            f"Expected error about invalid type, got: {e}"
        )
    print("PASS: C25 - validate_aggregations rejects non-string non-callable")


def check_validate_aggregations_none():
    """Boundary: validate_aggregations(None) is a no-op."""
    validate_aggregations(None)  # Should not raise
    validate_aggregations([])    # Should not raise
    print("PASS: boundary - validate_aggregations handles None and empty list")


# ---------------------------------------------------------------------------
# Additional boundary tests for scorer decorator
# ---------------------------------------------------------------------------

def check_scorer_accepts_description():
    """Verify scorer decorator stores description."""
    @scorer(description="Checks if output is non-empty")
    def has_content(outputs):
        return bool(outputs)

    assert has_content.description == "Checks if output is non-empty"
    print("PASS: boundary - scorer stores description")


def check_scorer_accepts_aggregations():
    """Verify scorer decorator stores aggregations."""
    @scorer(aggregations=["mean", "median"])
    def has_content(outputs):
        return bool(outputs)

    assert has_content.aggregations == ["mean", "median"]
    print("PASS: boundary - scorer stores aggregations")


def check_scorer_return_types():
    """Verify scorer.run() accepts all documented return types including None."""
    @scorer
    def return_bool(outputs):
        return True

    @scorer
    def return_int(outputs):
        return 42

    @scorer
    def return_float(outputs):
        return 3.14

    @scorer
    def return_str(outputs):
        return "good"

    @scorer
    def return_feedback(outputs):
        return Feedback(value=True)

    @scorer
    def return_feedback_list(outputs):
        return [Feedback(name="a", value=1), Feedback(name="b", value=2)]

    @scorer
    def return_none(outputs):
        return None

    assert isinstance(return_bool.run(outputs="x"), bool)
    assert isinstance(return_int.run(outputs="x"), int)
    assert isinstance(return_float.run(outputs="x"), float)
    assert isinstance(return_str.run(outputs="x"), str)
    assert isinstance(return_feedback.run(outputs="x"), Feedback)
    result_list = return_feedback_list.run(outputs="x")
    assert isinstance(result_list, list)
    assert all(isinstance(f, Feedback) for f in result_list)
    assert return_none.run(outputs="x") is None
    print("PASS: boundary - scorer.run() accepts all documented return types including None")


def check_get_all_scorers_unique_names():
    """Verify get_all_scorers returns uniquely-named scorers."""
    mlflow.set_tracking_uri("")
    scorers = get_all_scorers()
    names = [s.name for s in scorers]
    assert len(names) == len(set(names)), (
        f"Duplicate scorer names found: {names}"
    )
    print("PASS: boundary - get_all_scorers returns uniquely-named scorers")


def check_get_all_scorers_equality_semantics():
    """Verify Pydantic equality: get_all_scorers() == get_all_scorers() is True.

    This is critical for C14's nested-list detection in validate_scorers,
    which uses `scorer == get_all_scorers()` to detect the common mistake
    `scorers=[get_all_scorers()]`. The equality relies on Pydantic BaseModel
    comparing by field values rather than identity.
    """
    mlflow.set_tracking_uri("")
    scorers_a = get_all_scorers()
    scorers_b = get_all_scorers()
    assert scorers_a == scorers_b, (
        "get_all_scorers() must return value-equal lists for nested-list detection to work"
    )
    # Also verify individual scorer equality
    assert scorers_a[0] == scorers_b[0], (
        "Individual scorers from different get_all_scorers() calls must be value-equal"
    )
    print("PASS: boundary - get_all_scorers() equality semantics hold (required for C14)")


def check_C27_legacy_metric_support():
    """C27: validate_scorers optionally supports legacy databricks Metric."""
    import importlib
    is_dbx_installed = importlib.util.find_spec("databricks.agents") is not None
    if not is_dbx_installed:
        print("SKIP: C27 - databricks.agents not installed, legacy metric support not testable")
        return

    # When databricks.agents is installed, Metric instances should be accepted
    try:
        from databricks.rag_eval.evaluation.metrics import Metric
        # Create a minimal Metric-like object - this is a best-effort test
        # The actual Metric class may have required constructor args
        print("PASS: C27 - databricks.agents is installed (legacy Metric path available)")
    except ImportError:
        print("SKIP: C27 - could not import Metric class")


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Scorer dispatch and feedback normalization
    check_C5_scorer_run_dispatches_correctly()
    check_C6_default_feedback_name_overwrite()
    check_C7_custom_feedback_name_preserved()
    check_C8_list_feedback_names_preserved()
    check_C26_scorer_preserves_function_behavior()
    check_C28_scorer_accepts_none_return()

    # validate_scorers error handling
    check_C12_validate_scorers_rejects_non_list()
    check_C13_validate_scorers_rejects_class_not_instance()
    check_C14_validate_scorers_rejects_nested_get_all_scorers()
    check_C15_validate_scorers_empty_list()

    # valid_data_for_builtin_scorers behavior
    check_C18_rejects_non_dict_expectations()
    check_C19_trace_inference()
    check_C20_predict_fn_inference()
    check_C21_missing_column_logging()
    check_C29_nan_expectations_skip()

    # validate_aggregations behavior
    check_C22_validate_aggregations_accepts_valid_strings()
    check_C23_validate_aggregations_rejects_invalid_string()
    check_C24_validate_aggregations_accepts_callable()
    check_C25_validate_aggregations_rejects_non_callable()
    check_validate_aggregations_none()

    # Boundary tests
    check_scorer_accepts_description()
    check_scorer_accepts_aggregations()
    check_scorer_return_types()
    check_get_all_scorers_unique_names()
    check_get_all_scorers_equality_semantics()
    check_C27_legacy_metric_support()

    print("\nAll behavior checks passed.")
