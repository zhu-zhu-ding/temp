# Compile Checker Agent Skill

This is a durable review rubric for judging IR-to-spec compilation. It is not
task evidence. Preserve the base rubric and append concise, generalizable
lessons after each checker run.

## Base Rubric

1. Requirement completeness: split explicit requirements and native-test
   implications into atomic, non-invented obligations.
2. Repository fidelity: each graph node/edge and fixture comes from a real
   public API, caller, constructor, field, or test-supported path.
3. Contract strength: every contract has a distinguishable wrong implementation
   that its check would fail, not only an import/type/symbol assertion.
4. Observation quality: validate actual arguments, returned fields, state,
   exception semantics, or side effects at the contract target.
5. Compatibility: inspect defaults, signatures, aliases, import/export paths,
   serialization round trips, lifecycle invariants, and existing callers.
6. Collection semantics: inspect cardinality, ordering, deduplication,
   aggregation, and partial-failure survival whenever collections/logs/results
   are involved.
7. Spec execution: each C is referenced, each check is called, and at least one
   check reaches a public entry and a real observer for every R.
8. Req-test synthesis: search for tests from task terms and every relevant
   public entry/module/graph symbol. For each material assertion, preserve a
   short exact code excerpt, its `path::test_name` location, the test lens, and
   the implied contract before judging generated IR/spec coverage. Never claim
   a native-test implication without a real test excerpt, unless explicitly
   marked as task/source-only evidence.
9. Test-lens coverage: classify native tests by API/default/signature,
   dataflow/argument forwarding, lifecycle/state, error/message, side-effect
   count/order, collection cardinality/order/partial success, compatibility/
   round trip, and fixture/object-model fidelity. Judge whether generated specs
   cover the material lenses, not just whether they mention the same symbols.
10. Counterfactual strength: for each important native-test lens, identify the
    smallest plausible regression (wrong default, dropped argument, changed
    branch, reordered/filtered item, altered exception, or fake fixture) and
    require an executable generated check that would fail it. Native tests'
    real construction paths take precedence over dynamically fabricated fields
    or mocks of repository dispatchers.

## Lessons

Append short, evidence-linked rubric additions here.

## Lessons from mlflow__mlflow.93dab383 (2026-08-09)

1. **None-return contracts from native tests**: When native tests assert `result is None` for a function whose documented return type excludes `None`, there is an implicit obligation. Always search for `return None` or `is None` assertions in tests and map them to explicit R records — do not rely solely on the task's documented return-type list. (Evidence: RT4 / test_custom_scorer_allow_none_return)

2. **NaN/data-quality skip paths**: Reference implementations often contain silent skip paths (e.g., `if pd.isna(value): continue`) that are not mentioned in task documents. Check reference code for early-return/continue branches that soften documented contracts, and verify they are captured in the IR as explicit behavioral R records. (Evidence: validation.py NaN expectations skip)

3. **Equality-based error detection fragility**: When the IR/ref uses `x == f()` to detect a user mistake (e.g., nested get_all_scorers), verify that the equality semantics of the returned objects are stable. Add a boundary check that `f() == f()` evaluates True, or require the IR to note the assumption. (Evidence: C14 / validate_scorers nested-list detection)

4. **Module-level import failures block all spec checks**: When target functions don't exist yet, module-level imports in spec files fail before any check runs. Specs should either use lazy/delayed imports or be structured so that checks for already-existing functions (e.g., `validate_aggregations`) can still be exercised independently. (Evidence: arch_spec.py / behavior_spec.py both fail on `from mlflow.genai.scorers import get_all_scorers`)

5. **Missing imports in callers**: Verify that every symbol used in a caller is actually imported. The IR's graph edges may reference calls that would fail at runtime because the symbol is never imported in the calling module. (Evidence: `validate_scorers` and `valid_data_for_builtin_scorers` used at base.py:243,248 but never imported)
