# Compile Checker Agent Skill

This is a durable review rubric for judging IR-to-spec compilation. It is not
task evidence. Preserve the base rubric and append concise, generalizable
lessons after each checker run.

## Base Rubric

1. Requirement completeness: split explicit requirements and native-test
   implications into atomic, non-invented obligations.
2. Repository fidelity: each graph node/edge and fixture comes from a real
   public API, caller, constructor, field, or test-supported path.
3. Contract strength: every contract has a distinguishable wrong implementation
   that its check would fail, not only an import/type/symbol assertion.
4. Observation quality: validate actual arguments, returned fields, state,
   exception semantics, or side effects at the contract target.
5. Compatibility: inspect defaults, signatures, aliases, import/export paths,
   serialization round trips, lifecycle invariants, and existing callers.
6. Collection semantics: inspect cardinality, ordering, deduplication,
   aggregation, and partial-failure survival whenever collections/logs/results
   are involved.
7. Spec execution: each C is referenced, each check is called, and at least one
   check reaches a public entry and a real observer for every R.
8. Req-test synthesis: search for tests from task terms and every relevant
   public entry/module/graph symbol. For each material assertion, preserve a
   short exact code excerpt, its `path::test_name` location, the test lens, and
   the implied contract before judging generated IR/spec coverage. Never claim
   a native-test implication without a real test excerpt, unless explicitly
   marked as task/source-only evidence.
9. Test-lens coverage: classify native tests by API/default/signature,
   dataflow/argument forwarding, lifecycle/state, error/message, side-effect
   count/order, collection cardinality/order/partial success, compatibility/
   round trip, and fixture/object-model fidelity. Judge whether generated specs
   cover the material lenses, not just whether they mention the same symbols.
10. Counterfactual strength: for each important native-test lens, identify the
    smallest plausible regression (wrong default, dropped argument, changed
    branch, reordered/filtered item, altered exception, or fake fixture) and
    require an executable generated check that would fail it. Native tests'
    real construction paths take precedence over dynamically fabricated fields
    or mocks of repository dispatchers.

## Lessons

Append short, evidence-linked rubric additions here.

## Lessons from 93dab383 (Assessment Source + Custom Scorer Framework)

1. **Utility-function coverage**: When the IR includes internal utility nodes
   (e.g., `recreate_function`, `extract_function_body`) that have dedicated
   native test files, EVERY such node must have at least one behavior contract.
   Do not rely on indirect coverage through higher-level contracts (e.g., C16
   depending on `recreate_function` but never testing it directly). If the
   native tests have 20+ test functions for a utility, the IR must lower them.

2. **Import boundary verification**: Check that every symbol listed in a public
   `__all__` is actually importable. The IR's N12 (import boundary) evidence
   must include both `__all__` membership AND actual import statement in the
   `__init__.py`. A symbol in `__all__` without a corresponding import is an
   invalid graph witness.

3. **Error code completeness**: When a native test or task description specifies
   an error code (e.g., `INVALID_PARAMETER_VALUE`), the corresponding contract
   must verify both message AND error code. Message-only contracts are weak.

4. **Lifecycle immutability**: When lifecycle methods (register/start/stop/
   update) are tested for immutability in native tests (is-not checks), the
   contracts must capture this. Error-path-only contracts that test "raises
   outside Databricks" are insufficient; the happy-path immutability must
   also be verified.

5. **Dataclass validation contracts**: If a dataclass has a `__post_init__` that
   validates field combinations (e.g., exactly one scorer field type), this
   must be captured as an explicit R and C — it is a real data-integrity
   requirement, not an implementation detail.

6. **Enum-kind gating**: When an enum value (e.g., `ScorerKind.CLASS`) gates
   access to registration, a dedicated failure contract must verify the
   rejection path. Listing allowed values in an R is not sufficient.
