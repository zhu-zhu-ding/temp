"""
Architecture spec: exercise public entry points and L2 CALL/CONTROL/DATA connectivity.

This spec validates that the core architectural relationships between
AssessmentSource, AssessmentSourceType, Scorer, and scorer decorator are
established and wired correctly, without testing exhaustive behavior.

Contracts: C1 C6 C7
Supplementary: import boundary, class existence, enum values, dataclass structure
"""

import sys
import os

# Ensure /testbed is on path
sys.path.insert(0, "/testbed")


def check_c1_assessment_source_type_constants():
    """Contracts: C1 — AssessmentSourceType constants exist."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.CODE == "CODE"
    assert AssessmentSourceType._SOURCE_TYPES == [
        "SOURCE_TYPE_UNSPECIFIED",
        "LLM_JUDGE",
        "HUMAN",
        "CODE",
    ]
    print("PASS: C1 — AssessmentSourceType constants exist and are correct")


def check_c6_assessment_source_integrates_with_type():
    """Contracts: C6 — AssessmentSource.__post_init__ calls _standardize."""
    from mlflow.entities.assessment_source import AssessmentSource

    # Case-insensitive normalization
    source1 = AssessmentSource(source_type="human", source_id="u1")
    assert source1.source_type == "HUMAN"

    source2 = AssessmentSource(source_type="llm_judge", source_id="j1")
    assert source2.source_type == "LLM_JUDGE"

    source3 = AssessmentSource(source_type="CODE", source_id="c1")
    assert source3.source_type == "CODE"

    # AI_JUDGE deprecation — converts to LLM_JUDGE
    import warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        source4 = AssessmentSource(source_type="AI_JUDGE", source_id="a1")
        assert source4.source_type == "LLM_JUDGE"
        assert len(w) >= 1
        assert any("AI_JUDGE is deprecated" in str(warning.message) for warning in w)

    print("PASS: C6 — AssessmentSource integrates with AssessmentSourceType via _standardize")


def check_c7_assessment_source_dict_roundtrip():
    """Contracts: C7 — AssessmentSource dictionary serialization round-trip."""
    from mlflow.entities.assessment_source import AssessmentSource

    source = AssessmentSource(source_type="HUMAN", source_id="user_1")
    source_dict = source.to_dictionary()

    expected_dict = {"source_type": "HUMAN", "source_id": "user_1"}
    assert source_dict == expected_dict

    recreated = AssessmentSource.from_dictionary(source_dict)
    assert recreated == source
    assert recreated.source_type == "HUMAN"
    assert recreated.source_id == "user_1"

    print("PASS: C7 — AssessmentSource dict round-trip works")


def check_scorer_import_boundary():
    """Verify Scorer is importable from mlflow.genai.

    Note: The `scorer` function is listed in mlflow.genai.__all__ but NOT yet
    wired through the import chain. It lives at mlflow.genai.scorers.base.scorer
    in the skinny lib. This check verifies the import boundary architecture.
    """
    # Scorer IS importable
    from mlflow.genai import Scorer  # noqa: F401

    # scorer is in __all__ but not imported — this is a known gap
    import mlflow.genai
    assert "scorer" in mlflow.genai.__all__
    assert "Scorer" in mlflow.genai.__all__

    # The scorer function should be importable from scorers.base (when implemented)
    # from mlflow.genai.scorers.base import scorer  # expected import path
    print("PASS: Import boundary structure verified; scorer listed in __all__ for mlflow.genai")


def check_scorer_class_exists():
    """Verify Scorer base class exists and has expected fields."""
    from mlflow.genai import Scorer

    # Create minimal scorer
    s = Scorer(name="test")
    assert s.name == "test"
    assert s.description is None
    assert s.aggregations is None

    print("PASS: Scorer base class exists with name/description/aggregations fields")


def check_scorer_kind_enum():
    """Verify ScorerKind enum exists with expected values."""
    from mlflow.genai.scorers.base import ScorerKind

    assert ScorerKind.CLASS.value == "class"
    assert ScorerKind.BUILTIN.value == "builtin"
    assert ScorerKind.DECORATOR.value == "decorator"
    print("PASS: ScorerKind enum has CLASS, BUILTIN, DECORATOR")


def check_scorer_status_enum():
    """Verify ScorerStatus enum exists."""
    from mlflow.genai.scorers.base import ScorerStatus

    assert ScorerStatus.UNREGISTERED.value == "UNREGISTERED"
    assert ScorerStatus.STARTED.value == "STARTED"
    assert ScorerStatus.STOPPED.value == "STOPPED"
    print("PASS: ScorerStatus enum has UNREGISTERED, STARTED, STOPPED")


def check_scorer_sampling_config():
    """Verify ScorerSamplingConfig dataclass."""
    from mlflow.genai.scorers.base import ScorerSamplingConfig

    cfg = ScorerSamplingConfig(sample_rate=0.5, filter_string="x > 0")
    assert cfg.sample_rate == 0.5
    assert cfg.filter_string == "x > 0"

    cfg2 = ScorerSamplingConfig()
    assert cfg2.sample_rate is None
    assert cfg2.filter_string is None
    print("PASS: ScorerSamplingConfig works")


def check_serialized_scorer_dataclass():
    """Verify SerializedScorer dataclass structure."""
    from mlflow.genai.scorers.base import SerializedScorer

    s = SerializedScorer(
        name="test_scorer",
        aggregations=["mean"],
        description="test desc",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="test_func",
    )
    assert s.name == "test_scorer"
    assert s.aggregations == ["mean"]
    assert s.description == "test desc"
    assert s.call_source == "return True"
    assert s.call_signature == "(outputs)"
    assert s.original_func_name == "test_func"
    assert s.serialization_version == 1

    print("PASS: SerializedScorer dataclass works")


if __name__ == "__main__":
    check_c1_assessment_source_type_constants()
    check_c6_assessment_source_integrates_with_type()
    check_c7_assessment_source_dict_roundtrip()
    check_scorer_import_boundary()
    check_scorer_class_exists()
    check_scorer_kind_enum()
    check_scorer_status_enum()
    check_scorer_sampling_config()
    check_serialized_scorer_dataclass()
    print("\nAll architecture checks passed.")
