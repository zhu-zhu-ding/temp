# Requirement Compile Agent Skill

This is durable method guidance, not task evidence. Update it after compiling
each task with concise lessons about ambiguity, evidence gaps, and IR quality.

## Responsibilities

1. Treat the task as the authority for required behavior and use repository
   evidence only to locate compatible implementation paths and observers.
2. Lower prose into atomic L1 Requirement Obligations. Split independent
   behavior, failure, state, dataflow, and compatibility claims.
3. Build an L2 Functional Design Graph with only `CALL`, `CONTROL`, `DATA`,
   and `STATE` edges supported by source, callers, exports, or native tests.
4. Attach L3 Verifiable Contracts to graph nodes/edges. Every contract needs a
   typed relation, expected result, evidence, and explicit observation method.
5. Make observability first class: identify the public observer or runtime
   boundary where a future test can mechanically validate the contract.
6. Compile every contract into `arch_spec.py` or `behavior_spec.py`, preserving
   its contract ID and public-entry-to-observer path.

## Guardrails

- Write only the supplied executable spec artifacts; never production code or
  repository-native tests.
- Do not infer dataflow from symbol names or docstrings alone.
- Record unknowns explicitly rather than manufacturing exact defaults, errors,
  state values, or call arguments.
- Ensure each L1 obligation reaches at least one L3 contract through L2.

## Lessons

### Lesson 1 (from task 93dab383): Cross-reference multiple lib directories
When a repository maintains multiple library copies (e.g., `/testbed/mlflow/`,
`/testbed/libs/skinny/`, `/testbed/libs/tracing/`), always check all three
before concluding a symbol is absent. The main `mlflow/` directory may have
stub/empty implementations that the `libs/*/` directories have completed. The
task may expect the main directory to match the complete version from libs.

**Evidence**: `AssessmentSourceType` in `/testbed/mlflow/entities/assessment_source.py`
had empty method bodies, while `/testbed/libs/skinny/mlflow/entities/assessment_source.py`
had the full `__init__`, `__str__`, `_parse`, `_standardize` implementations.
Similarly `scorer_utils.py` had empty `extract_function_body` and
`recreate_function` in the main dir but full implementations in libs.

### Lesson 2 (from task 93dab383): Import boundaries reveal missing implementations
When a test imports `from mlflow.genai import scorer` but the module's `__init__.py`
only lists it in `__all__` without a corresponding import statement, that's a
strong signal the function needs to be implemented at the expected location.
Follow the import chain: `mlflow.genai.__init__` → (expects) `mlflow.genai.scorers`
→ `mlflow.genai.scorers.base.scorer`.

**Evidence**: `/testbed/mlflow/genai/__init__.py` lists `"scorer"` in `__all__`
but only imports `Scorer` from scorers, not `scorer`. The test at
`/testbed/tests/genai/scorers/test_scorer.py` line 8 does
`from mlflow.genai import Scorer, scorer`.

### Lesson 3 (from task 93dab383): Contracts requiring constrained environments
Some contracts (e.g., C16 scorer deserialization, C20 scorer lifecycle in
Databricks) cannot be mechanically observed without Databricks runtime. Mark
these clearly in the IR's Uncertainty fields and acknowledge in the behavior
spec that they require a specific environment. Do not attempt to mock
Databricks-specific infrastructure for these contracts; instead note the
environment dependency.

**Evidence**: `_reconstruct_decorator_scorer` and `register` methods gate on
`is_in_databricks_runtime()` / `is_databricks_uri()`. Tests mock these via
`@patch` but the full end-to-end lifecycle requires actual Databricks backend.

### Lesson 4 (from task 93dab383): Serialization is a data contract
When a task requires serialization/deserialization, model it as both DATA edges
(L2) and Data/Behavior contracts (L3). The serialized format fields
(`call_source`, `call_signature`, `original_func_name`) are observable via
`model_dump()` return values, while reconstruction requires the full
deserialization path through `model_validate()`.

**Evidence**: `SerializedScorer` dataclass defines the schema; `model_dump()`
produces it; `model_validate()` consumes it. Both directions are independently
testable.

### Lesson 5 (from task 93dab383): Deprecation as SIDE_EFFECT + CONTROL
When implementing deprecation handling, model it as both a CONTROL edge (the
branch condition checking for the deprecated value) and a SIDE_EFFECT contract
(the warning emission). This ensures the IR captures both the control flow
decision and the observable side effect that tests check via `pytest.warns`.

**Evidence**: `AI_JUDGE → LLM_JUDGE` deprecation is tested as a warning +
conversion in `test_ai_judge_deprecation_warning` and `test_assessment_source_type_validation`.

### Lesson 6 (from task 93dab383, revision): Native tests are the ultimate authority for contracts
When the Compile Checker reveals that native tests exercise behaviors not
captured in the generated specs, those behaviors MUST be added as new
requirements (R), graph nodes/edges (N/E), and contracts (C). The native test
suite defines the acceptance criteria; the IR and specs are derived from them,
not the other way around.

**Evidence**: 23 native tests in `test_scorer_utils.py` exercise
`recreate_function` behavior (basic, syntax errors, signatures, namespace,
indentation, type hints) but zero contracts existed for them before revision.
Added R21, E19-E21, C27-C32. Similarly, native tests `test_all_methods_are_immutable`
and `test_class_scorer_cannot_be_registered` revealed missing immutability (E23,
C33) and CLASS rejection (E22, C34) contracts.

### Lesson 7 (from task 93dab383, revision): Weak contracts must be strengthened with all observable dimensions
When a contract checks only one dimension of an expected behavior (e.g., only
the exception message but not the error_code), it is a "weak contract." Every
observable dimension the skinny/reference implementation provides AND the native
test exercises must be included in the contract's Expected field and the
corresponding check function.

**Evidence**: C4 only verified `pytest.raises(MlflowException, match=...)` but
the skinny implementation also sets `error_code=INVALID_PARAMETER_VALUE`.
Strengthened C4 to assert `exc_info.value.error_code == INVALID_PARAMETER_VALUE`.
Similarly C20 only tested the error path but not immutability; extended with
identity assertions.

### Lesson 8 (from task 93dab383, revision): Spec checks must handle unimplemented symbols gracefully
When the repository's main codebase has stub/empty implementations while the
skinny lib has the full code, spec checks that import unimplemented symbols will
fail at import time. Two strategies: (a) use try/except ImportError to skip
checks gracefully with a "SKIPPED" message, or (b) import from the canonical
location and let the ImportError propagate as a test failure indicating the
implementation is missing. Strategy (a) is preferred for behavior_spec.py so the
spec suite remains executable and informative even on a partially-implemented
codebase.

**Evidence**: `scorer` function is only in skinny (`/testbed/libs/skinny/mlflow/genai/scorers/base.py`)
but not in main (`/testbed/mlflow/genai/scorers/base.py`). `recreate_function`
same situation. Spec checks now use try/except ImportError guards.

### Lesson 9 (from task 93dab383, revision): Import boundary gaps must be documented, not hidden
When `__all__` lists a symbol but the module doesn't import it, the IR must
accurately document this gap. Do not claim the import works when it doesn't.
Instead, document the intended import path and note the current gap. The spec
should verify the architectural intent (__all__ listing, expected location) even
when the runtime import isn't wired yet.

**Evidence**: `mlflow.genai.__init__.py` has `"scorer"` in `__all__` but no
corresponding import. N12 in IR was corrected to note this. `arch_spec.py` now
verifies the __all__ structure rather than attempting the broken import.
