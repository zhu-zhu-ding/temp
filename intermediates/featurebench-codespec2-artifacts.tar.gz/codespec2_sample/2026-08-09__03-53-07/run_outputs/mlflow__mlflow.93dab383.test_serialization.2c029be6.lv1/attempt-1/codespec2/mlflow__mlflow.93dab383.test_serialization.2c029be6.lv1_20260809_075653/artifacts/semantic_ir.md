# Semantic IR: Assessment Source Management & Custom Scorer Framework

## L1. Requirement Obligations

### R1 – AssessmentSourceType constant catalog
- **Type**: Data
- **Statement**: The `AssessmentSourceType` class SHALL expose five public class-level string constants: `SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `AI_JUDGE` (deprecated), `HUMAN`, `CODE`. An internal `_SOURCE_TYPES` list SHALL contain the four valid values excluding the deprecated alias.
- **Task Evidence**: Interface Description 2 lists available source types (`HUMAN`, `LLM_JUDGE`, `CODE`, `SOURCE_TYPE_UNSPECIFIED`) and notes `AI_JUDGE` is deprecated but kept for backward compatibility.
- **Acceptance**: `AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"`; `AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"`; `AssessmentSourceType.HUMAN == "HUMAN"`; `AssessmentSourceType.CODE == "CODE"`; `AssessmentSourceType.AI_JUDGE == "AI_JUDGE"`; `AssessmentSourceType._SOURCE_TYPES == ["SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "HUMAN", "CODE"]`.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 153-158 already define these constants. `/testbed/tests/entities/test_assessment_source.py` exercises them through `AssessmentSource` construction.
- **Uncertainty**: None.

### R2 – Case-insensitive string validation
- **Type**: Behavior
- **Statement**: `AssessmentSourceType` SHALL accept source type strings case-insensitively, converting them to uppercase and validating against `_SOURCE_TYPES`.
- **Task Evidence**: Interface Description 2 states "Case-insensitive string inputs (converts to uppercase)". Example shows `"llm_judge"` → `"LLM_JUDGE"`.
- **Acceptance**: `AssessmentSourceType("human")._source_type == "HUMAN"`; `AssessmentSourceType("Human")._source_type == "HUMAN"`; `AssessmentSourceType("LLM_JUDGE")._source_type == "LLM_JUDGE"`.
- **Repository Evidence**: `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_case_insensitivity` validates lowercase/mixed-case inputs normalize to uppercase. `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 148-149 show `_parse` performs `source_type.upper()`.
- **Uncertainty**: None.

### R3 – AI_JUDGE deprecation → LLM_JUDGE
- **Type**: Behavior / SideEffect
- **Statement**: When `"AI_JUDGE"` is provided as a source type, the system SHALL emit a `FutureWarning` containing the phrase "AI_JUDGE is deprecated. Use LLM_JUDGE instead." and transparently convert the value to `"LLM_JUDGE"`.
- **Task Evidence**: Interface Description 2 "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE' with a deprecation warning."
- **Acceptance**: `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated...")` fires; the resulting `AssessmentSourceType` instance yields `"LLM_JUDGE"` via `__str__`.
- **Repository Evidence**: `/testbed/tests/entities/test_assessment_source.py` `test_ai_judge_deprecation_warning` and `test_assessment_source_type_validation` confirm this behavior. `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 151-155 implement the check and `warnings.warn`.
- **Uncertainty**: None.

### R4 – Invalid source type rejection
- **Type**: Failure
- **Statement**: Providing an unrecognized source type string SHALL raise `MlflowException` with error code `INVALID_PARAMETER_VALUE` and a message containing "Invalid assessment source type".
- **Task Evidence**: Interface Description 2 `__init__` raises "MlflowException: If the provided source_type is not one of the valid source types."
- **Acceptance**: `AssessmentSourceType("ROBOT")` raises `MlflowException` with `error_code == INVALID_PARAMETER_VALUE` and message matching "Invalid assessment source type"; `AssessmentSourceType("AI_JUDGE")` does NOT raise (deprecated but valid).
- **Repository Evidence**: `/testbed/tests/entities/test_assessment_source.py` lines 42-43 test invalid source. `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 157-162 show the `MlflowException` raise with `error_code=INVALID_PARAMETER_VALUE`.
- **Uncertainty**: None.

### R5 – AssessmentSourceType.__init__ stores via _parse
- **Type**: Behavior
- **Statement**: `AssessmentSourceType.__init__(self, source_type: str)` SHALL call `_parse` and store the result in `self._source_type`.
- **Task Evidence**: Interface Description 2 `__init__` signature and description: "Initialize an AssessmentSourceType instance with validation and standardization."
- **Acceptance**: After `ast = AssessmentSourceType("human")`, `ast._source_type == "HUMAN"`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 146: `self._source_type = AssessmentSourceType._parse(source_type)`.
- **Uncertainty**: None.

### R6 – AssessmentSourceType.__str__ returns stored source type
- **Type**: Behavior
- **Statement**: `AssessmentSourceType.__str__(self)` SHALL return the standardized (uppercase, validated) source type string.
- **Task Evidence**: Interface Description 2 `__str__`: "Return the string representation of the assessment source type."
- **Acceptance**: `str(AssessmentSourceType("human")) == "HUMAN"`; `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 165: `return self._source_type`.
- **Uncertainty**: None.

### R7 – AssessmentSourceType._parse static validation
- **Type**: Behavior
- **Statement**: `AssessmentSourceType._parse(source_type: str) -> str` SHALL uppercase the input, check for `AI_JUDGE` deprecation, validate against `_SOURCE_TYPES`, and return the standardized string.
- **Task Evidence**: Interface Description 2 `_parse`: "Parse and validate an assessment source type string."
- **Acceptance**: `AssessmentSourceType._parse("human") == "HUMAN"`; `AssessmentSourceType._parse("AI_JUDGE") == "LLM_JUDGE"` with warning.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 148-163.
- **Uncertainty**: None.

### R8 – AssessmentSourceType._standardize static convenience
- **Type**: Behavior
- **Statement**: `AssessmentSourceType._standardize(source_type: str) -> str` SHALL create a temporary `AssessmentSourceType` instance and return its string representation, thereby reusing all validation and deprecation logic.
- **Task Evidence**: Interface Description 2 `_standardize`: "Standardize and validate an assessment source type string."
- **Acceptance**: `_standardize("human") == "HUMAN"`; `_standardize("AI_JUDGE") == "LLM_JUDGE"` with warning; `_standardize("invalid")` raises `MlflowException`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 168-169: `return str(AssessmentSourceType(source_type))`.
- **Uncertainty**: None.

### R9 – AssessmentSource integrates with AssessmentSourceType
- **Type**: Dataflow
- **Statement**: `AssessmentSource.__post_init__` SHALL call `AssessmentSourceType._standardize(self.source_type)` and store the result in `self.source_type`, ensuring all `AssessmentSource` instances carry normalized source type values.
- **Task Evidence**: Interface Description 1 reference; native test `test_assessment_source_properties` and `test_assessment_source_case_insensitivity`.
- **Acceptance**: `AssessmentSource(source_type="human").source_type == "HUMAN"`; `AssessmentSource(source_type="AI_JUDGE").source_type == "LLM_JUDGE"`.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` line 78: `self.source_type = AssessmentSourceType._standardize(self.source_type)`. Native tests in `/testbed/tests/entities/test_assessment_source.py`.
- **Uncertainty**: None.

### R10 – scorer decorator with parentheses
- **Type**: Interface
- **Statement**: When `scorer()` is called with keyword arguments (name, description, aggregations) but without `func`, it SHALL return a `functools.partial` that, when applied to a function, creates a `CustomScorer` with those metadata values.
- **Task Evidence**: Interface Description 1 shows `scorer(name="always_no")(always_yes)`. Native test `test_scorer_name_works` parametrizes with `scorer(name="always_no")(always_yes)`.
- **Acceptance**: `scorer(name="custom", description="desc")(my_func)` returns a `Scorer` with `kind == DECORATOR`, `name == "custom"`, `description == "desc"`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 968-972: `if func is None: return functools.partial(scorer, ...)`.
- **Uncertainty**: The `scorer` function is defined at `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 847 but NOT yet present in the main `/testbed/mlflow/genai/scorers/base.py`. The import path `mlflow.genai.scorers.base.scorer` is the expected location; `mlflow.genai.scorer` is the intended public re-export (listed in `__all__` but not yet wired).

### R11 – scorer decorator without parentheses
- **Type**: Interface
- **Statement**: When `@scorer` is applied directly to a function (without intermediate call), it SHALL wrap the function in a `CustomScorer(Scorer)` with `kind == ScorerKind.DECORATOR` and `name` derived from the function's `__name__`.
- **Task Evidence**: Interface Description 1 examples `@scorer\ndef not_empty(outputs) -> bool`. Native tests use `@scorer` extensively.
- **Acceptance**: `@scorer\ndef f(outputs): return True` → `isinstance(f, Scorer)`, `f.kind == ScorerKind.DECORATOR`, `f.name == "f"`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 985-1008: `CustomScorer` class constructed inside `scorer()` when `func is not None`.
- **Uncertainty**: Same import availability gap as R10.

### R12 – scorer run() delegates to user function with filtered kwargs
- **Type**: Behavior
- **Statement**: `Scorer.run()` SHALL accept keyword arguments (`inputs`, `outputs`, `expectations`, `trace`), filter them to match the user function's parameter names, and call the user function with only the matching kwargs.
- **Task Evidence**: Interface Description 1 documents the parameters. Native tests demonstrate `run()` delegation.
- **Acceptance**: `@scorer\ndef my_scorer(outputs): return len(outputs)` → `my_scorer.run(outputs="hello") == 5`; `my_scorer.run(inputs="ignored", outputs="hi") == 2` (inputs filtered out).
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 365-405 (run method signature and kwarg filtering).
- **Uncertainty**: Exact filtering mechanism depends on `inspect.signature` or equivalent; implementation detail.

### R13 – scorer Feedback name overwrite logic
- **Type**: Behavior
- **Statement**: When `run()` returns a single `Feedback` object whose `name` equals `DEFAULT_FEEDBACK_NAME`, the scorer SHALL overwrite it to the scorer's `name`. When the `Feedback` has an explicit custom name, it SHALL be preserved. When returning a `list[Feedback]`, names SHALL NOT be overwritten.
- **Task Evidence**: Native test `test_custom_scorer_overwrites_default_feedback_name` and `test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list`.
- **Acceptance**: (1) `Feedback(value=42)` → name becomes `"my_scorer"`; (2) `Feedback(name="explicit", value=42)` → name stays `"explicit"`; (3) `[Feedback(name="a", value=1), Feedback(name="b", value=2)]` → names preserved.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 391-403 (name overwrite logic in `run()`).
- **Uncertainty**: `DEFAULT_FEEDBACK_NAME` constant value; assumed to be the default used by `Feedback.__init__`.

### R14 – scorer serialization captures source code
- **Type**: Data
- **Statement**: `Scorer.model_dump()` for a DECORATOR scorer SHALL extract the original function's source code body, signature, and name into `SerializedScorer` fields `call_source`, `call_signature`, and `original_func_name`.
- **Task Evidence**: Interface Description 1 mentions serialization/deserialization. Native tests exercise serialization round-trips.
- **Acceptance**: After `@scorer\ndef check(outputs): return True`, calling `.model_dump()` yields a dict where `dump["call_signature"]` contains `"(outputs)"` and `dump["original_func_name"] == "check"`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 131-198 (`model_dump` and `_extract_source_code_info`).
- **Uncertainty**: Exact source extraction depends on `extract_function_body` from `scorer_utils.py`.

### R15 – scorer deserialization reconstructs function
- **Type**: Behavior
- **Statement**: `Scorer.model_validate()` with decorator scorer serialized data SHALL reconstruct a functional `Scorer` instance using `recreate_function` from the stored `call_source`, `call_signature`, and `original_func_name`, but ONLY when running in a Databricks runtime environment.
- **Task Evidence**: Interface Description 1 mentions serialization/deserialization. Native test `test_custom_scorer_loading_blocked_for_non_databricks_uri`.
- **Acceptance**: Under Databricks, `Scorer.model_validate(SerializedScorer(name="test", call_source="return x + y", call_signature="(x, y)", original_func_name="add"))` returns a Scorer whose `run(x=3, y=4)` returns 7.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 230-232 and 302-370 (`model_validate` → `_reconstruct_decorator_scorer`).
- **Uncertainty**: Full reconstruction requires Databricks runtime; non-Databricks raises security error (see R16).

### R16 – scorer deserialization & registration blocked outside Databricks
- **Type**: Failure / Security
- **Statement**: Outside a Databricks runtime, `Scorer._reconstruct_decorator_scorer` SHALL raise `MlflowException` with "not supported"; `Scorer.register()` for DECORATOR scorers SHALL raise `MlflowException` with "not supported outside of Databricks tracking". Error messages SHALL include a formatted code snippet showing the registered scorer source.
- **Task Evidence**: Native tests `test_custom_scorer_loading_blocked_for_non_databricks_uri`, `test_custom_scorer_registration_blocked_for_non_databricks_uri`, `test_custom_scorer_error_message_renders_code_snippet_legibly`.
- **Acceptance**: Error raised with security message; code snippet contains "Registered scorer code:", "from mlflow.genai import scorer", "@scorer", and the function definition.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 352-361 (security gate in `_reconstruct_decorator_scorer`), lines 795-812 (security gate in `register`).
- **Uncertainty**: Exact message text may vary but must include the key substrings.

### R17 – scorer lifecycle immutability
- **Type**: Behavior / State
- **Statement**: Scorer lifecycle methods `register()`, `start()`, `stop()`, `update()` SHALL each return a NEW `Scorer` instance (immutability). The original instance SHALL remain unchanged. Only `ScorerKind.BUILTIN` and `ScorerKind.DECORATOR` scorers may be registered; `ScorerKind.CLASS` scorers SHALL raise `MlflowException` with message containing "must be a builtin or decorator scorer".
- **Task Evidence**: Native tests `test_all_methods_are_immutable` and `test_class_scorer_cannot_be_registered`.
- **Acceptance**: `registered = scorer.register()` → `registered is not scorer`; `started = registered.start(...)` → `started is not registered`; `stopped = started.stop()` → `stopped is not started`; `Scorer(name="test").register()` raises `MlflowException` matching "must be a builtin or decorator scorer".
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` `_ALLOWED_SCORERS_FOR_REGISTRATION = [BUILTIN, DECORATOR]`; `_check_can_be_registered` validates kind; each lifecycle method calls `_create_copy()` or `DatabricksStore.update_registered_scorer` returning new instance.
- **Uncertainty**: Immutability under non-Databricks environments cannot be observed end-to-end; the contract verifies identity within the error-throwing path and structure of return values.

### R18 – scorer return type acceptance
- **Type**: Behavior
- **Statement**: `Scorer.run()` SHALL accept return values of types: `bool`, `int`, `float`, `str`, `Feedback`, `list[Feedback]`, and `None`. Any other return type SHALL raise `MlflowException` with message "must return one of".
- **Task Evidence**: Interface Description 1 states "The scorer function should return one of...". Native tests `test_custom_scorer_allow_none_return` and parametrized return-type tests.
- **Acceptance**: All valid types pass; `return {"score": 5}` raises `MlflowException`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 376-388.
- **Uncertainty**: None.

### R19 – scorer aggregation configuration
- **Type**: Data
- **Statement**: The `Scorer` class SHALL accept an `aggregations` parameter (list of strings or callables) and store it. Default is `None`.
- **Task Evidence**: Interface Description 1 documents `aggregations` parameter. Native tests verify aggregation configuration.
- **Acceptance**: `Scorer(name="x", aggregations=["mean", "variance"]).aggregations == ["mean", "variance"]`; default `aggregations is None`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` line 112.
- **Uncertainty**: None.

### R20 – scorer name and description metadata
- **Type**: Data
- **Statement**: The `scorer` decorator and `Scorer` class SHALL accept `name` and `description` parameters. When no name is provided for a decorator scorer, the function's `__name__` is used. `description` defaults to `None`.
- **Task Evidence**: Interface Description 1 documents name/description. Native tests verify both.
- **Acceptance**: `@scorer(name="custom", description="desc")` sets both; `@scorer` uses function name; `description is None` by default.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 112, 1003.
- **Uncertainty**: None.

### R21 – recreate_function behavior
- **Type**: Behavior
- **Statement**: `recreate_function(source: str, signature: str, func_name: str) -> Callable` SHALL:
  1. Compile and return a callable with `__name__ == func_name` that executes `source` with positional arguments matching `signature`.
  2. Propagate `SyntaxError` for malformed source code (e.g., missing colon).
  3. Raise `MlflowException` with `INVALID_PARAMETER_VALUE` for empty or invalid signature format (e.g., empty string `""`).
  4. Inject MLflow entity classes (`Feedback`, `Assessment`, `AssessmentSource`, `AssessmentSourceType`, `Trace`, `CategoricalRating`) into the execution namespace.
  5. Handle indentation correctly: non-indented source lines SHALL be indented under the generated `def` block.
  6. Accept type hints in the signature string (e.g., `(trace: mlflow.entities.Trace) -> mlflow.entities.Feedback`).
- **Task Evidence**: 23 native tests in `/testbed/tests/genai/scorers/test_scorer_utils.py` including `test_simple_function_recreation`, `test_function_with_syntax_error`, `test_empty_signature_string`, `test_mlflow_imports_available`, `test_indentation_handling`, `test_function_with_mlflow_trace_type_hint`.
- **Acceptance**: See C27–C32.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 77-110 (full `recreate_function` implementation). NOT yet present in main `/testbed/mlflow/genai/scorers/scorer_utils.py`.
- **Uncertainty**: Full namespace injection list; inferred to include at minimum `Feedback`, `Assessment`, `AssessmentSource`, `AssessmentSourceType`, `Trace`, `CategoricalRating`, `json`, `re`.

### R22 – SerializedScorer __post_init__ validation
- **Type**: Failure / Data
- **Statement**: `SerializedScorer.__post_init__` SHALL validate that exactly one type of scorer field is present (builtin, decorator, or instructions judge). Zero or multiple field types SHALL raise `ValueError`.
- **Task Evidence**: Skinny implementation at `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 87-107.
- **Acceptance**: `SerializedScorer(name="x", call_source="return True", call_signature="()", original_func_name="f")` passes; `SerializedScorer(name="x")` with no scorer type fields raises `ValueError`.
- **Repository Evidence**: Skinny `SerializedScorer.__post_init__` validates field-type exclusivity.
- **Uncertainty**: Exact error message text; the validator must ensure data integrity.

## L2. Functional Design Graph

### N1 – AssessmentSourceType class
- Role: Enumeration and validator for assessment source types
- Evidence: `/testbed/mlflow/entities/assessment_source.py` lines 102-194; `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 102-194
- Properties: Constants + instance validation via `__init__`, `_parse`, `_standardize`, `__str__`, `from_proto`

### N2 – AssessmentSource dataclass
- Role: Data object carrying source_type and source_id
- Evidence: `/testbed/mlflow/entities/assessment_source.py` lines 12-99
- Properties: `__post_init__` delegates to `AssessmentSourceType._standardize`; `to_dictionary`/`from_dictionary` for serialization

### N3 – scorer function (entry point)
- Role: Public decorator/partial for creating custom scorers
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 847-1008
- Properties: When `func is None` returns `functools.partial`; when `func` is provided returns `CustomScorer(Scorer)`

### N4 – Scorer base class
- Role: Base model for all scorer types
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 111-846
- Properties: Pydantic BaseModel; fields: name, description, aggregations, kind, status; methods: run, register, start, stop, update, model_dump, model_validate

### N5 – CustomScorer (inner class)
- Role: Concrete scorer for decorator-based user functions
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 999-1008
- Properties: `_original_func` private attr; overrides `run` to delegate to user function

### N6 – extract_function_body (utility)
- Role: Extract source code body and indentation from a callable
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 61-75
- Properties: Uses AST; returns (body_string, indent_unit)

### N7 – recreate_function (utility)
- Role: Reconstruct a callable from source code string, signature, and name
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 77-110; `/testbed/tests/genai/scorers/test_scorer_utils.py` (23 tests)
- Properties: Uses `exec()` in controlled namespace; injects MLflow entity classes; returns callable

### N8 – SerializedScorer dataclass
- Role: Serialization schema for scorer data
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 62-85
- Properties: name, aggregations, description, mlflow_version, serialization_version, builtin_scorer_class, call_source, call_signature, original_func_name, instructions_judge_pydantic_data; `__post_init__` validates field exclusivity

### N9 – ScorerKind enum
- Role: Enumerate scorer kinds
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 29-32
- Properties: CLASS, BUILTIN, DECORATOR

### N10 – ScorerStatus enum
- Role: Track scorer lifecycle status
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 38-47
- Properties: UNREGISTERED, STARTED, STOPPED

### N11 – ScorerSamplingConfig dataclass
- Role: Sampling configuration for registered scorers
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 51-55
- Properties: sample_rate, filter_string

### N12 – Public import boundary (mlflow.genai)
- Role: Expose `scorer` and `Scorer` to users
- Evidence: `/testbed/mlflow/genai/__init__.py`; `__all__` includes "scorer" but the import statement is missing — only `Scorer` is imported from `mlflow.genai.scorers`; `scorer` is listed in `__all__` but NOT bound. The `scorer` function exists at `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 847 and needs to be wired into the main `__init__.py` chain.
- Properties: Intended: `from mlflow.genai import scorer, Scorer`. Currently: only `Scorer` is importable from `mlflow.genai`.

### N13 – Public import boundary (mlflow.entities)
- Role: Expose `AssessmentSourceType` and `AssessmentSource` to users
- Evidence: `/testbed/mlflow/entities/__init__.py` line 9
- Properties: `from mlflow.entities import AssessmentSourceType, AssessmentSource`

### E1 – CALL: AssessmentSource.__post_init__ → AssessmentSourceType._standardize
- Kind: CALL
- Condition: Always on AssessmentSource initialization
- Transfer: `self.source_type` string → `_standardize(source_type)` → validated string
- Evidence: `/testbed/mlflow/entities/assessment_source.py` line 78
- Obligations: R8, R9

### E2 – CALL: AssessmentSourceType._standardize → AssessmentSourceType.__init__
- Kind: CALL
- Condition: Always
- Transfer: source_type string → AssessmentSourceType(source_type) instance → str()
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 168-169
- Obligations: R5, R8

### E3 – CALL: AssessmentSourceType.__init__ → AssessmentSourceType._parse
- Kind: CALL
- Condition: Always
- Transfer: source_type string → _parse(source_type) → validated uppercase string → stored in self._source_type
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 146
- Obligations: R5, R7

### E4 – CONTROL: _parse AI_JUDGE branch
- Kind: CONTROL
- Condition: `source_type.upper() == "AI_JUDGE"`
- Transfer: Issues FutureWarning, returns "LLM_JUDGE"
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 151-155
- Obligations: R3

### E5 – CONTROL: _parse invalid branch
- Kind: CONTROL
- Condition: `source_type.upper() not in _SOURCE_TYPES`
- Transfer: Raises MlflowException with INVALID_PARAMETER_VALUE
- Evidence: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 157-162
- Obligations: R4

### E6 – CALL: scorer(func) → CustomScorer construction
- Kind: CALL
- Condition: `func is not None`
- Transfer: Wraps func in CustomScorer(Scorer) with DECORATOR kind
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 970-1008
- Obligations: R11, R12

### E7 – CONTROL: scorer partial branch
- Kind: CONTROL
- Condition: `func is None`
- Transfer: Returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 968-972
- Obligations: R10

### E8 – CALL: Scorer.run → CustomScorer.__call__ → user function
- Kind: CALL
- Condition: Always during evaluation
- Transfer: Filters kwargs by function signature, calls user function, validates return type
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 365-405
- Obligations: R12, R18

### E9 – CALL: Scorer.model_dump → _extract_source_code_info
- Kind: CALL
- Condition: Decorator scorer serialization
- Transfer: _original_func → extract_function_body → call_source, call_signature, original_func_name
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 131-170
- Obligations: R14

### E10 – CALL: _extract_source_code_info → extract_function_body
- Kind: CALL
- Condition: During serialization
- Transfer: Callable → (body_string, indent_unit)
- Evidence: `/testbed/mlflow/genai/scorers/base.py` line 193; `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 61-75
- Obligations: R14

### E11 – CALL: Scorer.model_validate → _reconstruct_decorator_scorer
- Kind: CALL
- Condition: SerializedScorer with call_source present
- Transfer: SerializedScorer → recreate_function → scorer() → CustomScorer
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 230-232
- Obligations: R15

### E12 – CALL: _reconstruct_decorator_scorer → recreate_function
- Kind: CALL
- Condition: Running in Databricks runtime (post security gate)
- Transfer: (source, signature, func_name) → callable
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 346-348
- Obligations: R15, R21

### E13 – CONTROL: _reconstruct_decorator_scorer security gate
- Kind: CONTROL
- Condition: `not is_in_databricks_runtime()`
- Transfer: Raises MlflowException with "not supported" message; includes code snippet
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 352-361
- Obligations: R16

### E14 – CONTROL: Scorer.register security gate
- Kind: CONTROL
- Condition: `self.kind == ScorerKind.DECORATOR and not is_databricks_uri(...)`
- Transfer: Raises MlflowException with "not supported outside of Databricks tracking"
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 795-812
- Obligations: R16

### E15 – STATE: Scorer status transitions
- Kind: STATE
- Condition: Based on _registered_backend and sample_rate
- Transfer: UNREGISTERED (no backend) ↔ STARTED (rate > 0) ↔ STOPPED (rate == 0)
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 125-129 (status property)
- Obligations: R17

### E16 – DATA: scorer name flow
- Kind: DATA
- Condition: During CustomScorer construction
- Transfer: `name or func.__name__` → self.name → run() Feedback name overwrite logic
- Evidence: `/testbed/mlflow/genai/scorers/base.py` line 1003; lines 391-403
- Obligations: R13

### E17 – CALL: mlflow.genai.__init__ → scorer (intended)
- Kind: CALL (import boundary)
- Condition: `from mlflow.genai import scorer` (currently broken — symbol in `__all__` but not imported)
- Transfer: Imports scorer function from scorers module
- Evidence: `/testbed/mlflow/genai/__init__.py` `__all__` includes "scorer"; native tests import from here
- Obligations: R10, R11

### E18 – CALL: AssessmentSourceType.from_proto → protobuf
- Kind: CALL
- Condition: During proto deserialization
- Transfer: ProtoAssessmentSource.SourceType → Name() → string
- Evidence: `/testbed/mlflow/entities/assessment_source.py` lines 193-194
- Obligations: R1

### E19 – CONTROL: recreate_function syntax error propagation
- Kind: CONTROL
- Condition: Source code has Python syntax error
- Transfer: SyntaxError raised to caller
- Evidence: `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_function_with_syntax_error`
- Obligations: R21

### E20 – CONTROL: recreate_function invalid signature
- Kind: CONTROL
- Condition: Empty or malformed signature string
- Transfer: MlflowException with INVALID_PARAMETER_VALUE
- Evidence: `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_empty_signature_string`
- Obligations: R21

### E21 – DATA: recreate_function namespace injection
- Kind: DATA
- Condition: Always during recreation
- Transfer: MLflow entity classes injected into exec() globals
- Evidence: `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_mlflow_imports_available`
- Obligations: R21

### E22 – CONTROL: _check_can_be_registered CLASS rejection
- Kind: CONTROL
- Condition: `self.kind not in _ALLOWED_SCORERS_FOR_REGISTRATION`
- Transfer: Raises MlflowException "must be a builtin or decorator scorer"
- Evidence: `/testbed/mlflow/genai/scorers/base.py` lines 806-812; `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_class_scorer_cannot_be_registered`
- Obligations: R17

### E23 – STATE: scorer lifecycle immutability
- Kind: STATE
- Condition: Each lifecycle method call
- Transfer: Returns NEW instance; original unchanged (identity check: `result is not self`)
- Evidence: `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_all_methods_are_immutable`
- Obligations: R17

## L3. Verifiable Contracts

### C1 – AssessmentSourceType constants exist
- Type: Interface
- Subject: `AssessmentSourceType` class
- Relation: Class-level string constants
- Expected: `SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"`, `LLM_JUDGE == "LLM_JUDGE"`, `HUMAN == "HUMAN"`, `CODE == "CODE"`, `AI_JUDGE == "AI_JUDGE"`, `_SOURCE_TYPES == ["SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "HUMAN", "CODE"]`
- Evidence: R1; `/testbed/mlflow/entities/assessment_source.py` lines 153-158
- Observe: `FIELD_READ` – direct attribute access on `AssessmentSourceType`
- Target: `arch_spec.py`
- Obligations: R1
- Graph: N1

### C2 – Case-insensitive validation normalizes to uppercase
- Type: Behavior
- Subject: `AssessmentSourceType.__init__` → `_parse`
- Relation: Input string → uppercase validation
- Expected: `str(AssessmentSourceType("human")) == "HUMAN"`; `str(AssessmentSourceType("Human")) == "HUMAN"`; `str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"`; `str(AssessmentSourceType("code")) == "CODE"`; `str(AssessmentSourceType("source_type_unspecified")) == "SOURCE_TYPE_UNSPECIFIED"`
- Evidence: R2; `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_case_insensitivity`
- Observe: `RETURN_VALUE` – `str(AssessmentSourceType(input))` returns uppercase
- Target: `behavior_spec.py`
- Obligations: R2, R5, R7
- Graph: N1, E3

### C3 – AI_JUDGE deprecation warning and conversion
- Type: SideEffect
- Subject: `AssessmentSourceType._parse`
- Relation: "AI_JUDGE" input → FutureWarning + "LLM_JUDGE" output
- Expected: `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` fires; `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"`; `str(AssessmentSourceType("ai_judge")) == "LLM_JUDGE"`
- Evidence: R3; `/testbed/tests/entities/test_assessment_source.py` `test_ai_judge_deprecation_warning`
- Observe: `SIDE_EFFECT` – `warnings.warn` call + `RETURN_VALUE`
- Target: `behavior_spec.py`
- Obligations: R3
- Graph: N1, E4

### C4 – Invalid source type raises MlflowException with error_code
- Type: Failure
- Subject: `AssessmentSourceType._parse`
- Relation: Unrecognized input → MlflowException with INVALID_PARAMETER_VALUE
- Expected: `AssessmentSourceType("ROBOT")` raises `MlflowException` with message containing "Invalid assessment source type" AND `error_code == INVALID_PARAMETER_VALUE`; `AssessmentSourceType("INVALID")` same; boundary: empty string `""` should raise
- Evidence: R4; `/testbed/tests/entities/test_assessment_source.py` lines 42-43; `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 157-162
- Observe: `EXCEPTION` – `MlflowException` raised; inspect `exc_info.value.error_code`
- Target: `behavior_spec.py`
- Obligations: R4
- Graph: N1, E5

### C5 – _standardize returns correct string
- Type: Behavior
- Subject: `AssessmentSourceType._standardize`
- Relation: Any valid string → standardized uppercase string
- Expected: `_standardize("human") == "HUMAN"`; `_standardize("LLM_JUDGE") == "LLM_JUDGE"`; `_standardize("AI_JUDGE") == "LLM_JUDGE"`; `_standardize("invalid")` raises
- Evidence: R8; `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 168-169
- Observe: `RETURN_VALUE` – string equality check
- Target: `behavior_spec.py`
- Obligations: R5, R8
- Graph: N1, E2

### C6 – AssessmentSource integrates with AssessmentSourceType
- Type: Dataflow
- Subject: `AssessmentSource.__post_init__`
- Relation: source_type input → standardized via `_standardize`
- Expected: `AssessmentSource(source_type="human").source_type == "HUMAN"`; `AssessmentSource(source_type="AI_JUDGE", source_id="x").source_type == "LLM_JUDGE"`; `AssessmentSource(source_type="LLM_JUDGE").source_type == "LLM_JUDGE"`
- Evidence: R9; `/testbed/mlflow/entities/assessment_source.py` lines 76-78; `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_properties`
- Observe: `FIELD_READ` – `.source_type` after construction
- Target: `arch_spec.py`
- Obligations: R9
- Graph: N2, E1

### C7 – AssessmentSource dictionary serialization round-trip
- Type: Dataflow
- Subject: `AssessmentSource.to_dictionary` / `from_dictionary`
- Relation: Object → dict → object equality
- Expected: `source = AssessmentSource(source_type="HUMAN", source_id="user_1")`; `source_dict = source.to_dictionary()`; `source_dict == {"source_type": "HUMAN", "source_id": "user_1"}`; `AssessmentSource.from_dictionary(source_dict) == source`
- Evidence: R9; `/testbed/tests/entities/test_assessment_source.py` `test_assessment_source_to_from_dictionary`
- Observe: `RETURN_VALUE` – dict equality + object equality
- Target: `arch_spec.py`
- Obligations: R9
- Graph: N2

### C8 – scorer decorator: no-parens usage creates CustomScorer
- Type: Interface
- Subject: `scorer(func)` where func is a function
- Relation: Decorate function → returns Scorer with DECORATOR kind
- Expected: `@scorer\ndef f(outputs) -> bool:\n    return len(outputs) > 0` yields `isinstance(f, Scorer)`, `f.kind == ScorerKind.DECORATOR`, `f.name == "f"`, `f.description is None`
- Evidence: R11, R12, R13; `/testbed/tests/genai/scorers/test_scorer.py` uses `@scorer` extensively
- Observe: `RETURN_VALUE` – isinstance check, attribute reads
- Target: `behavior_spec.py`
- Obligations: R11, R12, R13
- Graph: N3, N4, E6, E16

### C9 – scorer decorator: with-parens usage
- Type: Interface
- Subject: `scorer(name="custom", description="desc")` returning partial
- Relation: Partial applied to function → named CustomScorer
- Expected: `scorer(name="custom_name", description="desc")(always_yes)` returns `Scorer` with `name == "custom_name"`, `description == "desc"`
- Evidence: R10, R20; `/testbed/tests/genai/scorers/test_scorer.py` `test_scorer_name_works` uses `scorer(name="always_no")(always_yes)`
- Observe: `RETURN_VALUE` – attribute reads
- Target: `behavior_spec.py`
- Obligations: R10, R20
- Graph: N3, E7

### C10 – scorer run() delegates to user function with filtered kwargs
- Type: Behavior
- Subject: `Scorer.run()`
- Relation: kwargs → filtered by function signature → user function → validated return
- Expected: `@scorer\ndef my_scorer(outputs):\n    return len(outputs)`; `my_scorer.run(outputs="hello") == 5`; `my_scorer.run(inputs="ignored", outputs="hi") == 2` (inputs filtered out)
- Evidence: R12, R18; `/testbed/mlflow/genai/scorers/base.py` lines 365-405
- Observe: `RETURN_VALUE` – function return value
- Target: `behavior_spec.py`
- Obligations: R12, R18
- Graph: N5, E8

### C11 – scorer run() return type validation
- Type: Failure
- Subject: `Scorer.run()`
- Relation: Invalid return → MlflowException
- Expected: `@scorer\ndef bad_scorer(outputs):\n    return {"score": 5}`; `bad_scorer.run(outputs="x")` raises `MlflowException` with message containing "must return one of"
- Evidence: R18; `/testbed/mlflow/genai/scorers/base.py` lines 376-388
- Observe: `EXCEPTION` – MlflowException raised
- Target: `behavior_spec.py`
- Obligations: R18
- Graph: N5, E8

### C12 – scorer Feedback name overwrite for default name
- Type: Behavior
- Subject: `Scorer.run()` Feedback-handling logic
- Relation: Single Feedback with DEFAULT_FEEDBACK_NAME → name overwritten to scorer name
- Expected: `@scorer\ndef my_scorer():\n    return Feedback(value=42)`; `result = my_scorer.run()`; `result.name == "my_scorer"`; `result.value == 42`
- Evidence: R13; `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_overwrites_default_feedback_name`
- Observe: `RETURN_VALUE` – Feedback.name attribute
- Target: `behavior_spec.py`
- Obligations: R13
- Graph: N5, E16

### C13 – scorer custom Feedback name not overwritten
- Type: Behavior
- Subject: `Scorer.run()` Feedback-handling logic
- Relation: Single Feedback with explicit name → name preserved
- Expected: `@scorer\ndef my_scorer():\n    return Feedback(name="explicit", value=42)`; `result = my_scorer.run()`; `result.name == "explicit"`
- Evidence: R13; `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_overwrites_default_feedback_name` (second parametrize case)
- Observe: `RETURN_VALUE` – Feedback.name preserved
- Target: `behavior_spec.py`
- Obligations: R13
- Graph: N5, E16

### C14 – scorer list[Feedback] names not overwritten
- Type: Behavior
- Subject: `Scorer.run()` returning list
- Relation: List of Feedback → names preserved as-is
- Expected: `@scorer\ndef my_scorer():\n    return [Feedback(name="a", value=1), Feedback(name="b", value=2)]`; `results = my_scorer.run()`; `results[0].name == "a"`; `results[1].name == "b"`
- Evidence: R13; `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list`
- Observe: `RETURN_VALUE` – list element names
- Target: `behavior_spec.py`
- Obligations: R13
- Graph: N5, E16

### C15 – scorer model_dump produces source code fields
- Type: Dataflow
- Subject: `Scorer.model_dump()` for DECORATOR scorer
- Relation: Decorator scorer → dict with call_source, call_signature, original_func_name
- Expected: After `@scorer\ndef check(outputs):\n    return True`, `dump["call_signature"]` contains `"(outputs)"`; `dump["original_func_name"] == "check"`
- Evidence: R14; `/testbed/mlflow/genai/scorers/base.py` lines 131-198
- Observe: `RETURN_VALUE` – dict key existence and content
- Target: `behavior_spec.py`
- Obligations: R14
- Graph: N5, N8, E9, E10

### C16 – scorer deserialization reconstructs function
- Type: Behavior
- Subject: `Scorer.model_validate()` with decorator scorer data
- Relation: SerializedScorer dict → functional Scorer instance
- Expected: Under Databricks runtime, `Scorer.model_validate(SerializedScorer(name="test", call_source="return x + y", call_signature="(x, y)", original_func_name="add"))` returns a Scorer whose `run(x=3, y=4)` returns 7
- Evidence: R15; `/testbed/tests/genai/scorers/test_scorer_utils.py`
- Observe: `RETURN_VALUE` – functional scorer reconstructed
- Target: `behavior_spec.py`
- Obligations: R15
- Graph: N5, N7, E11, E12

### C17 – scorer loading blocked outside Databricks
- Type: Failure / Security
- Subject: `Scorer._reconstruct_decorator_scorer`
- Relation: Non-Databricks environment → MlflowException
- Expected: Outside Databricks runtime, `Scorer._reconstruct_decorator_scorer(serialized)` raises `MlflowException` with "not supported"
- Evidence: R16; `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_loading_blocked_for_non_databricks_uri`
- Observe: `EXCEPTION` – MlflowException with security message
- Target: `behavior_spec.py`
- Obligations: R16
- Graph: N5, E13

### C18 – scorer registration blocked outside Databricks
- Type: Failure / Security
- Subject: `Scorer.register()` for DECORATOR scorer
- Relation: Non-Databricks tracking URI → MlflowException
- Expected: `@scorer\ndef my_scorer(outputs):\n    return True`; `my_scorer.register()` raises `MlflowException` matching "not supported outside of Databricks tracking"
- Evidence: R16; `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_registration_blocked_for_non_databricks_uri`
- Observe: `EXCEPTION` – MlflowException with security message
- Target: `behavior_spec.py`
- Obligations: R16
- Graph: N5, E14

### C19 – scorer status reflects lifecycle
- Type: State
- Subject: `Scorer.status` property
- Relation: `_registered_backend` + `sample_rate` → status enum
- Expected: Unregistered scorer → `ScorerStatus.UNREGISTERED`; registered with sample_rate=0 → `ScorerStatus.STOPPED`; registered with sample_rate>0 → `ScorerStatus.STARTED`
- Evidence: R17; `/testbed/mlflow/genai/scorers/base.py` lines 125-129
- Observe: `STATE_READ` – `.status` returns correct enum
- Target: `behavior_spec.py`
- Obligations: R17
- Graph: N5, N10, E15

### C20 – scorer start/stop lifecycle with immutability
- Type: Behavior / State
- Subject: `Scorer.start()` / `Scorer.stop()` / `Scorer.update()` / `Scorer.register()`
- Relation: Lifecycle method call → new instance returned, original unchanged
- Expected: Each method returns a new `Scorer` instance (`result is not self`). Outside Databricks, methods raise appropriate errors. Under mocked Databricks, immutability is verifiable.
- Evidence: R17; `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_all_methods_are_immutable`
- Observe: `RETURN_VALUE` – identity check `result is not caller`
- Target: `behavior_spec.py`
- Obligations: R17
- Graph: N5, N11, E15, E23

### C21 – scorer aggregation configuration
- Type: Data
- Subject: `Scorer.aggregations` field
- Relation: Constructor parameter → stored field
- Expected: `Scorer(name="x", aggregations=["mean", "variance"]).aggregations == ["mean", "variance"]`; default is `None`
- Evidence: R19; `/testbed/mlflow/genai/scorers/base.py` line 112
- Observe: `FIELD_READ` – `.aggregations` equals input
- Target: `behavior_spec.py`
- Obligations: R19
- Graph: N5

### C22 – scorer accepts all valid return types
- Type: Behavior
- Subject: `Scorer.run()` return type acceptance
- Relation: int/float/bool/str/Feedback/list[Feedback]/None → accepted
- Expected: All of `True`, `42`, `3.14`, `"ok"`, `Feedback(value=True)`, `[Feedback(value=1)]`, `None` pass validation
- Evidence: R18; `/testbed/mlflow/genai/scorers/base.py` lines 376-388
- Observe: `RETURN_VALUE` – no exception raised
- Target: `behavior_spec.py`
- Obligations: R18
- Graph: N5, E8

### C23 – scorer allows None return
- Type: Behavior
- Subject: `Scorer.run()` nil return handling
- Relation: Return None → accepted without error
- Expected: `@scorer\ndef f(): return None`; `f.run()` returns `None`
- Evidence: R18; `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_allow_none_return`
- Observe: `RETURN_VALUE` – None returned
- Target: `behavior_spec.py`
- Obligations: R18
- Graph: N5, E8

### C24 – AssessmentSourceType __str__ returns stored type
- Type: Behavior
- Subject: `AssessmentSourceType.__str__`
- Relation: Instance → standardized string
- Expected: `str(AssessmentSourceType("human")) == "HUMAN"`; `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"`
- Evidence: R6; `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 165
- Observe: `RETURN_VALUE` – string equals expected
- Target: `behavior_spec.py`
- Obligations: R6
- Graph: N1

### C25 – _parse rejects empty string
- Type: Failure / Boundary
- Subject: `AssessmentSourceType._parse`
- Relation: Empty string → MlflowException
- Expected: `AssessmentSourceType._parse("")` raises `MlflowException`
- Evidence: R4; validation logic should reject `""` as it won't match any _SOURCE_TYPES entry
- Observe: `EXCEPTION` – MlflowException raised
- Target: `behavior_spec.py`
- Obligations: R4
- Graph: N1, E5

### C26 – reconstruct_decorator_scorer error message includes code snippet
- Type: Failure / SideEffect
- Subject: `Scorer._reconstruct_decorator_scorer`
- Relation: Blocked loading → error message with formatted code
- Expected: Error message contains "Registered scorer code:", "from mlflow.genai import scorer", "@scorer", "def <name><signature>:" with indented source
- Evidence: R16; `/testbed/tests/genai/scorers/test_scorer.py` `test_custom_scorer_error_message_renders_code_snippet_legibly`
- Observe: `EXCEPTION` – exception message contains code snippet
- Target: `behavior_spec.py`
- Obligations: R16
- Graph: N5, E13

### C27 – recreate_function: basic arithmetic function recreation
- Type: Behavior
- Subject: `recreate_function`
- Relation: (source, signature, func_name) → callable with correct behavior and __name__
- Expected: `recreate_function("return x + y", "(x, y)", "add_func")` returns callable `f` where `f.__name__ == "add_func"`, `f(3, 4) == 7`, `f(10, -5) == 5`
- Evidence: R21; `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_simple_function_recreation`
- Observe: `RETURN_VALUE` – callable with correct __name__ and arithmetic
- Target: `behavior_spec.py`
- Obligations: R21
- Graph: N7

### C28 – recreate_function: SyntaxError propagation
- Type: Failure
- Subject: `recreate_function`
- Relation: Malformed source code → SyntaxError raised
- Expected: `recreate_function("if x > 0\n    return True", "(x)", "bad")` raises `SyntaxError` matching "expected ':'"
- Evidence: R21; `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_function_with_syntax_error`
- Observe: `EXCEPTION` – SyntaxError raised
- Target: `behavior_spec.py`
- Obligations: R21
- Graph: N7, E19

### C29 – recreate_function: empty/invalid signature raises MlflowException
- Type: Failure / Boundary
- Subject: `recreate_function`
- Relation: Empty signature string → MlflowException with INVALID_PARAMETER_VALUE
- Expected: `recreate_function("return 1", "", "empty_sig")` raises `MlflowException` with message matching "Invalid signature format" and `error_code == INVALID_PARAMETER_VALUE`
- Evidence: R21; `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_empty_signature_string`
- Observe: `EXCEPTION` – MlflowException raised; inspect error_code
- Target: `behavior_spec.py`
- Obligations: R21
- Graph: N7, E20

### C30 – recreate_function: MLflow imports available in namespace
- Type: Behavior
- Subject: `recreate_function`
- Relation: Execution namespace injected with MLflow entities
- Expected: Recreated function can use `Feedback`, `AssessmentSourceType`, `Trace` without explicit imports. `Feedback(value=True, rationale="test")` creates valid Feedback; `AssessmentSourceType.CODE` returns `"CODE"`; `Trace` objects are instantiable.
- Evidence: R21; `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_mlflow_imports_available`
- Observe: `RETURN_VALUE` – function executes with MLflow types
- Target: `behavior_spec.py`
- Obligations: R21
- Graph: N7, E21

### C31 – recreate_function: __name__ fidelity
- Type: Behavior
- Subject: `recreate_function`
- Relation: func_name parameter → `__name__` attribute
- Expected: `recreate_function("return 'success'", "()", "test_name_func").__name__ == "test_name_func"`
- Evidence: R21; `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_function_name_in_namespace`
- Observe: `RETURN_VALUE` – `__name__` attribute
- Target: `behavior_spec.py`
- Obligations: R21
- Graph: N7

### C32 – recreate_function: indentation handling
- Type: Behavior
- Subject: `recreate_function`
- Relation: Non-indented source → correctly indented under generated `def`
- Expected: `recreate_function("x = 1\ny = 2\nreturn x + y", "()", "indent_test")()` returns `3`
- Evidence: R21; `/testbed/tests/genai/scorers/test_scorer_utils.py` `test_indentation_handling`
- Observe: `RETURN_VALUE` – correct execution result
- Target: `behavior_spec.py`
- Obligations: R21
- Graph: N7

### C33 – lifecycle methods are immutable (return new instances)
- Type: Behavior / State
- Subject: `Scorer.register()` / `start()` / `stop()` / `update()`
- Relation: Method call → NEW instance, original unchanged
- Expected: For decorator scorers under mocked Databricks: `registered = scorer.register(...)` → `registered is not scorer`; `started = registered.start(...)` → `started is not registered`; `stopped = started.stop()` → `stopped is not started`; `updated = stopped.update(...)` → `updated is not stopped`
- Evidence: R17; `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_all_methods_are_immutable`
- Observe: `RETURN_VALUE` – identity check (`is not`)
- Target: `behavior_spec.py`
- Obligations: R17
- Graph: N5, E23

### C34 – CLASS scorer registration rejected
- Type: Failure
- Subject: `Scorer.register()` for CLASS-kind scorer
- Relation: ScorerKind.CLASS → MlflowException
- Expected: `Scorer(name="test").register()` raises `MlflowException` with message matching "must be a builtin or decorator scorer"
- Evidence: R17; `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` `test_class_scorer_cannot_be_registered`
- Observe: `EXCEPTION` – MlflowException raised
- Target: `behavior_spec.py`
- Obligations: R17
- Graph: N5, E22

### C35 – SerializedScorer validates field exclusivity
- Type: Failure / Data
- Subject: `SerializedScorer.__post_init__`
- Relation: Exactly one scorer-type field required
- Expected: `SerializedScorer(name="x", call_source="return True", call_signature="()", original_func_name="f")` succeeds; `SerializedScorer(name="x")` (no scorer-type fields) raises `ValueError`; `SerializedScorer(name="x", call_source="...", builtin_scorer_class="...")` (multiple types) raises `ValueError`
- Evidence: R22; `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 87-107
- Observe: `EXCEPTION` – ValueError for 0 or >1 field types
- Target: `behavior_spec.py`
- Obligations: R22
- Graph: N8
