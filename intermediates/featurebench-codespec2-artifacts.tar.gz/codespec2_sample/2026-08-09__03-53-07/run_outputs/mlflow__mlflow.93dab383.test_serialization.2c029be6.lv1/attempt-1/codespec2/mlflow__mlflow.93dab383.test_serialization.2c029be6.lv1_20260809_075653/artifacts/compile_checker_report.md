# Compile Checker Report

- Status: needs_revision

## Req-Test Evidence

### RT1: AssessmentSourceType case-insensitive normalization through AssessmentSource
- Test: `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity`
- Location: `tests/entities/test_assessment_source.py:53-69`
- Key Code:
  ```python
  source_1 = AssessmentSource(source_type="human", source_id="user_1")
  source_4 = AssessmentSource(source_type="llm_judge", source_id="judge_1")
  source_5 = AssessmentSource(source_type="Llm_Judge", source_id="judge_2")
  assert source_1.source_type == "HUMAN"
  assert source_4.source_type == "LLM_JUDGE"
  assert source_5.source_type == "LLM_JUDGE"
  ```
- Test Lens: API/dataflow — verifies that `AssessmentSource.__post_init__` → `_standardize` normalizes case-insensitive input to uppercase on the actual `source_type` field.
- Implied Requirement: `AssessmentSourceType._standardize` must be callable from `AssessmentSource.__post_init__` and produce uppercase output; `AssessmentSource.source_type` must reflect the normalized value.
- IR / Spec Mapping: R2, R8, R9; C2, C5, C6; `check_c2_case_insensitive_validation`, `check_c6_assessment_source_integrates_with_type`
- Verdict: covered

### RT2: AI_JUDGE deprecation warning fires with exact message
- Test: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning`
- Location: `tests/entities/test_assessment_source.py:71-76`
- Key Code:
  ```python
  with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
      source = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
  assert source.source_type == "LLM_JUDGE"
  assert source.source_id == "ai_1"
  ```
- Test Lens: Side-effect/message — verifies the exact deprecation message, the warning category (`FutureWarning`), and that the field value is converted to `"LLM_JUDGE"` while other fields (`source_id`) are preserved.
- Implied Requirement: `_parse` must emit `FutureWarning` (not `DeprecationWarning`) with the exact substring; conversion must not drop or modify unrelated fields.
- IR / Spec Mapping: R3; C3; `check_c3_ai_judge_deprecation`
- Verdict: covered

### RT3: Invalid source type raises MlflowException with specific message
- Test: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`
- Location: `tests/entities/test_assessment_source.py:39-50`
- Key Code:
  ```python
  with pytest.raises(MlflowException, match="Invalid assessment source type"):
      AssessmentSource(source_type="ROBOT", source_id="robot_1")
  ```
- Test Lens: Error/message — verifies exception type (`MlflowException`), message pattern, and that the error propagates through `AssessmentSource.__post_init__`.
- Implied Requirement: The `MlflowException` must carry `INVALID_PARAMETER_VALUE` error code in addition to the message.
- IR / Spec Mapping: R4; C4; `check_c4_invalid_source_type_raises`
- Verdict: weak — C4 checks message but not `error_code=INVALID_PARAMETER_VALUE`

### RT4: scorer decorator with parentheses creates named CustomScorer
- Test: `tests/genai/scorers/test_scorer.py::test_scorer_name_works`
- Location: `tests/genai/scorers/test_scorer.py:70-75`
- Key Code:
  ```python
  @pytest.mark.parametrize("dummy_scorer", [
      AlwaysYesScorer(name="always_no"),
      scorer(name="always_no")(always_yes)
  ])
  def test_scorer_name_works(sample_data, dummy_scorer, is_in_databricks):
      result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])
      assert any("always_no" in metric for metric in result.metrics.keys())
  ```
- Test Lens: API/default/signature — verifies that `scorer(name=...)` partial application followed by `(func)` produces a scorer whose name appears in evaluation metrics.
- Implied Requirement: `scorer(name="X")(func)` must create a `Scorer` instance with `name="X"` that integrates into the evaluation pipeline.
- IR / Spec Mapping: R10, R13; C9; `check_c9_scorer_decorator_with_parens`
- Verdict: covered

### RT5: scorer Feedback default name overwritten to scorer name
- Test: `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name`
- Location: `tests/genai/scorers/test_scorer.py:304-316`
- Key Code:
  ```python
  @pytest.mark.parametrize(("scorer_return", "expected_feedback_name"), [
      (Feedback(value=42, rationale="rationale"), "my_scorer"),
      (Feedback(name="custom_name", value=42, rationale="rationale"), "custom_name"),
  ])
  def test_custom_scorer_overwrites_default_feedback_name(scorer_return, expected_feedback_name):
      @scorer
      def my_scorer(inputs, outputs):
          return scorer_return
      feedback = my_scorer.run(inputs={...}, outputs=...)
      assert feedback.name == expected_feedback_name
  ```
- Test Lens: Dataflow/argument forwarding — verifies the `run()` method's name-overwrite logic: default `DEFAULT_FEEDBACK_NAME` → scorer name; custom name preserved.
- Implied Requirement: `Scorer.run()` must check `result.name == DEFAULT_FEEDBACK_NAME` and overwrite only when the user did not set a custom name; must NOT overwrite list[Feedback] items.
- IR / Spec Mapping: R18; C12, C13, C14; `check_c12`, `check_c13`, `check_c14`
- Verdict: covered

### RT6: scorer None return accepted without error
- Test: `tests/genai/scorers/test_scorer.py::test_custom_scorer_allow_none_return`
- Location: `tests/genai/scorers/test_scorer.py:268-274`
- Key Code:
  ```python
  def test_custom_scorer_allow_none_return():
      @scorer
      def dummy_scorer(inputs, outputs):
          return None
      assert dummy_scorer.run(inputs={"question": "query"}, outputs="answer") is None
  ```
- Test Lens: API/default — verifies that `None` is an allowed return value and passes through `run()` without exception.
- IR / Spec Mapping: R18; C23; `check_c23_scorer_allows_none_return`
- Verdict: covered

### RT7: scorer reconstruction blocked outside Databricks
- Test: `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri`
- Location: `tests/genai/scorers/test_scorer.py:349-361`
- Key Code:
  ```python
  serialized = SerializedScorer(
      name="malicious_scorer",
      call_source="import os\nos.system('echo hacked')\nreturn True",
      call_signature="(outputs)",
      original_func_name="malicious_scorer",
  )
  with pytest.raises(mlflow.exceptions.MlflowException, match="Loading custom scorer.*not supported"):
      Scorer._reconstruct_decorator_scorer(serialized)
  ```
- Test Lens: Error/message — verifies that deserialization is blocked outside Databricks with a "not supported" message.
- IR / Spec Mapping: R16; C17; `check_c17_scorer_loading_blocked_outside_databricks`
- Verdict: covered

### RT8: scorer error message renders code snippet legibly
- Test: `tests/genai/scorers/test_scorer.py::test_custom_scorer_error_message_renders_code_snippet_legibly`
- Location: `tests/genai/scorers/test_scorer.py:381-427`
- Key Code:
  ```python
  error_msg = str(exc_info.value)
  assert "Registered scorer code:" in error_msg
  assert "from mlflow.genai import scorer" in error_msg
  assert "@scorer" in error_msg
  assert "def complex_scorer(outputs):" in error_msg
  ```
- Test Lens: Error/message format — verifies the error message contains a formatted, indented code snippet with proper import, decorator, and function definition lines.
- IR / Spec Mapping: R16; C26; `check_c26_reconstruction_error_code_snippet`
- Verdict: covered

### RT9: recreate_function with simple arithmetic
- Test: `tests/genai/scorers/test_scorer_utils.py::test_simple_function_recreation`
- Location: `tests/genai/scorers/test_scorer_utils.py:13-25`
- Key Code:
  ```python
  source = "return x + y"
  signature = "(x, y)"
  func_name = "add_func"
  recreated = recreate_function(source, signature, func_name)
  assert recreated.__name__ == func_name
  assert recreated(3, 4) == 7
  assert recreated(10, -5) == 5
  ```
- Test Lens: API/round-trip — verifies that `recreate_function` produces a callable with correct `__name__` and correct arithmetic behavior.
- Implied Requirement: `recreate_function` must accept source, signature, func_name and return a callable that executes the source code with positional arguments matching the signature.
- IR / Spec Mapping: R15; C16 (indirect); **missing** direct `recreate_function` contract in behavior_spec
- Verdict: missing — IR has N7 node but no C; behavior_spec has zero `recreate_function` checks

### RT10: recreate_function with syntax error raises
- Test: `tests/genai/scorers/test_scorer_utils.py::test_function_with_syntax_error`
- Location: `tests/genai/scorers/test_scorer_utils.py:253-260`
- Key Code:
  ```python
  source = "if x > 0\n    return True"  # Missing colon
  signature = "(x)"
  func_name = "syntax_error_func"
  with pytest.raises(SyntaxError, match="expected ':'"):
      recreate_function(source, signature, func_name)
  ```
- Test Lens: Error — verifies that malformed source code raises `SyntaxError` (not a generic exception).
- Implied Requirement: `recreate_function` must propagate Python syntax errors to the caller.
- IR / Spec Mapping: missing
- Verdict: missing

### RT11: recreate_function with empty signature raises MlflowException
- Test: `tests/genai/scorers/test_scorer_utils.py::test_empty_signature_string`
- Location: `tests/genai/scorers/test_scorer_utils.py:202-210`
- Key Code:
  ```python
  source = "return 1"
  signature = ""
  func_name = "empty_sig"
  with pytest.raises(MlflowException, match="Invalid signature format"):
      recreate_function(source, signature, func_name)
  ```
- Test Lens: Error/message — verifies that an empty signature string is rejected with a specific MlflowException.
- Implied Requirement: `recreate_function` must validate the signature format and raise `MlflowException` with `INVALID_PARAMETER_VALUE` for empty/malformed signatures.
- IR / Spec Mapping: missing
- Verdict: missing

### RT12: MLflow imports available in recreate_function namespace
- Test: `tests/genai/scorers/test_scorer_utils.py::test_mlflow_imports_available`
- Location: `tests/genai/scorers/test_scorer_utils.py:281-323`
- Key Code:
  ```python
  source = """...
  feedback = Feedback(value=True, rationale="test")
  from mlflow.entities.assessment_source import AssessmentSourceType
  source_obj = AssessmentSourceType.CODE
  ..."""
  recreated = recreate_function(source, signature, func_name)
  result = recreated()
  assert isinstance(result["feedback"], Feedback)
  assert result["source"] == "CODE"
  assert isinstance(result["trace"], Trace)
  ```
- Test Lens: Fixture/object-model — verifies the execution namespace includes `Feedback`, `Assessment`, `AssessmentSource`, `AssessmentSourceType`, `Trace`, and `CategoricalRating`.
- Implied Requirement: `recreate_function` must inject MLflow entity classes into the execution namespace so reconstructed scorer functions can use them.
- IR / Spec Mapping: missing
- Verdict: missing

### RT13: scorer register/start/stop/update are immutable
- Test: `tests/genai/scorers/test_registered_scorers_scheduling.py::test_all_methods_are_immutable`
- Location: `tests/genai/scorers/test_registered_scorers_scheduling.py:299-342`
- Key Code:
  ```python
  def test_all_methods_are_immutable():
      scorer = length_check
      registered = scorer.register(name="my_scorer")
      assert registered is not scorer
      started = registered.start(sampling_config=ScorerSamplingConfig(sample_rate=0.5))
      assert started is not registered
      stopped = started.stop()
      assert stopped is not started
  ```
- Test Lens: Lifecycle/state — verifies that `register()`, `start()`, `stop()`, `update()` each return a NEW instance (immutability), not mutate in-place.
- Implied Requirement: Lifecycle methods must return new `Scorer` instances with updated `_sampling_config` while preserving the original.
- IR / Spec Mapping: R17; C20 (partial — only tests error outside Databricks, not immutability)
- Verdict: weak — C20 does not verify immutability

### RT14: class scorer (kind=CLASS) cannot be registered
- Test: `tests/genai/scorers/test_registered_scorers_scheduling.py::test_class_scorer_cannot_be_registered`
- Location: `tests/genai/scorers/test_registered_scorers_scheduling.py:344-367`
- Key Code:
  ```python
  class_scorer = Scorer(name="test")
  with pytest.raises(MlflowException, match="must be a builtin or decorator scorer"):
      class_scorer.register()
  ```
- Test Lens: Error/message — verifies that base `Scorer` (kind=CLASS) is rejected from registration.
- Implied Requirement: `_check_can_be_registered` must reject `ScorerKind.CLASS` with a specific error message.
- IR / Spec Mapping: R17; not covered by a dedicated C
- Verdict: missing

## Findings

### Finding 1: Lost obligation — recreate_function contract coverage

- Category: lost_obligation
- Subrequirements: `recreate_function` (N7) and `extract_function_body` (N6) are nodes in the IR graph but have **zero dedicated contracts (C)** in the behavior spec. The native test suite (`tests/genai/scorers/test_scorer_utils.py`) contains 23 test functions exercising signature parsing, namespace injection, syntax errors, empty/malformed inputs, indentation handling, type hints, and edge cases. None of these are reflected in the generated specs.
- Evidence:
  - Native tests: `test_simple_function_recreation`, `test_function_with_control_flow`, `test_function_with_loop`, `test_function_with_multiple_parameters`, `test_function_creating_feedback_object`, `test_function_creating_assessment_object`, `test_complex_logic_function`, `test_empty_signature`, `test_single_parameter_signature`, `test_signature_with_whitespace`, `test_signature_with_defaults`, `test_complex_signature`, `test_empty_signature_string`, `test_function_with_unavailable_import`, `test_function_with_undefined_variable`, `test_function_with_syntax_error`, `test_function_using_builtin_modules`, `test_mlflow_imports_available`, `test_function_name_in_namespace`, `test_indentation_handling`, `test_empty_source_code`, `test_function_with_import_error_at_runtime`, `test_function_with_mlflow_trace_type_hint`
  - IR: N6, N7 nodes exist; C16 depends on `recreate_function` indirectly but does not validate its behavior.
  - Behavior spec: Zero direct checks for `recreate_function` or `extract_function_body`.
- Cause: The Requirement Compile Agent included `recreate_function` as graph nodes but did not lower any of the native tests' 23 test lenses into concrete contracts.
- Impact: A plausible wrong implementation (e.g., `recreate_function` that silently drops the `mlflow` namespace, mangles indentation, or swallows `SyntaxError`) would pass all generated spec checks because none validate `recreate_function` behavior directly.
- Required Change: Add at minimum C27–C32 contracts covering: (a) basic function recreation with arithmetic, (b) `SyntaxError` propagation for malformed source, (c) `MlflowException` for empty/invalid signature format, (d) MLflow imports available in namespace, (e) `__name__` correctly set, (f) indentation handling. Then add corresponding `check_c27`–`check_c32` functions in `behavior_spec.py`.
- Req-Test Evidence: RT9, RT10, RT11, RT12

### Finding 2: Invalid graph witness — N12 import boundary claims `scorer` is importable

- Category: invalid_graph
- Subrequirements: N12 (Public import boundary)
- Evidence:
  - `/testbed/mlflow/genai/__init__.py` line 38: `from mlflow.genai.scorers import Scorer` — imports only `Scorer`, not `scorer`
  - `/testbed/mlflow/genai/__init__.py` line 42: `"scorer"` is listed in `__all__` but never bound to an actual object
  - `/testbed/mlflow/genai/scorers/__init__.py` line 93: `"scorer"` is listed in `__all__` but `scorer` is never imported from `.base`
  - `python -c "from mlflow.genai import scorer"` → `ImportError: cannot import name 'scorer' from 'mlflow.genai'`
- Cause: The IR claims `from mlflow.genai import scorer, Scorer` works based on `__all__` inclusion, but the actual `__init__.py` files do not import the `scorer` symbol. The skinny version defines `scorer` in `base.py` but the main repo's `__init__.py` files don't wire it.
- Impact: The behavior spec (`check_c8`, `check_c9`, `check_c18`, etc.) does `from mlflow.genai import scorer` which fails at import time, making all scorer-related specs unexecutable.
- Required Change: The IR's N12 evidence must either be corrected to note that the import path needs to be added (the `__init__.py` files need `from mlflow.genai.scorers.base import scorer` and re-export), or the spec checks must import from `mlflow.genai.scorers.base` directly until the public boundary is wired.
- Req-Test Evidence: RT4, RT5, RT6, RT7, RT8 (all require `scorer` to be importable)

### Finding 3: Weak contract — C4 does not verify error_code

- Category: weak_contract
- Subrequirements: R4 states the `MlflowException` SHALL carry `INVALID_PARAMETER_VALUE` error code. C4 only checks `pytest.raises(MlflowException, match="Invalid assessment source type")`.
- Evidence:
  - IR R4: "raise `MlflowException` with error code `INVALID_PARAMETER_VALUE` and a message containing 'Invalid assessment source type'"
  - Skinny implementation (`/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 161): `error_code=INVALID_PARAMETER_VALUE`
  - Generated check (`check_c4_invalid_source_type_raises`): only asserts `pytest.raises(MlflowException, match=...)` — never inspects `exc_info.value.error_code`
- Cause: The contract omitted the error_code dimension from the expected relation, making it a message-only check.
- Impact: A wrong implementation that raises `MlflowException` with the right message but wrong error code (e.g., `INTERNAL_ERROR`) would pass C4.
- Required Change: Update C4 to include `error_code` verification and update `check_c4_invalid_source_type_raises` to assert `exc_info.value.error_code == INVALID_PARAMETER_VALUE` (or the string equivalent).
- Req-Test Evidence: RT3

### Finding 4: Weak contract — C20 does not verify immutability of lifecycle methods

- Category: weak_contract
- Subrequirements: R17 states scorer lifecycle methods (start/stop/update/register). Native test `test_all_methods_are_immutable` verifies that each method returns a NEW instance.
- Evidence:
  - Native test (`tests/genai/scorers/test_registered_scorers_scheduling.py:299-342`): `assert registered is not scorer`, `assert started is not registered`, `assert stopped is not started`
  - Generated check (`check_c20_scorer_start_stop_lifecycle`): only verifies that methods raise `MlflowException` outside Databricks, never verifies immutability.
- Cause: The contract focuses on the error path (non-Databricks) but omits the happy-path immutability requirement.
- Impact: A wrong implementation that mutates `self._sampling_config` in-place and returns `self` would pass C20.
- Required Change: Add a new contract (or extend C20) that, under mocked Databricks, verifies `register()`/`start()`/`stop()`/`update()` return new instances distinct from the caller.
- Req-Test Evidence: RT13

### Finding 5: Lost obligation — class scorer (kind=CLASS) registration rejection

- Category: lost_obligation
- Subrequirements: R17 covers scorer lifecycle but does not explicitly capture the requirement that `ScorerKind.CLASS` scorers cannot be registered. Native test `test_class_scorer_cannot_be_registered` verifies this.
- Evidence:
  - Native test (`tests/genai/scorers/test_registered_scorers_scheduling.py:344`): `class_scorer = Scorer(name="test"); class_scorer.register()` raises `MlflowException` with "must be a builtin or decorator scorer"
  - IR: R17 mentions `_ALLOWED_SCORERS_FOR_REGISTRATION = [BUILTIN, DECORATOR]` but no contract verifies CLASS rejection
  - Behavior spec: no check for CLASS registration rejection
- Cause: The IR captured the allowed list but did not create a failure contract for the CLASS rejection path.
- Impact: A wrong implementation that allows CLASS scorers to register would pass all generated checks.
- Required Change: Add a contract (e.g., C27) verifying that `Scorer(name="test").register()` raises `MlflowException` with "must be a builtin or decorator scorer".
- Req-Test Evidence: RT14

### Finding 6: Lost obligation — SerializedScorer.__post_init__ validation

- Category: lost_obligation
- Subrequirements: The skinny `SerializedScorer` has a `__post_init__` that validates exactly one type of scorer field is present (builtin, decorator, or instructions judge). This is not captured in any R or C.
- Evidence:
  - Skinny (`/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 87-107): `__post_init__` raises `ValueError` if 0 or >1 field types present
  - Main (`/testbed/mlflow/genai/scorers/base.py`): `SerializedScorer` has no `__post_init__`
  - IR: N8 mentions `SerializedScorer` fields but no R/C for validation
- Cause: The IR describes `SerializedScorer` as a data schema but does not capture the validation logic that ensures data integrity.
- Impact: A wrong implementation could create a `SerializedScorer` with both `call_source` and `builtin_scorer_class` populated, causing ambiguous deserialization.
- Required Change: Add R21 for `SerializedScorer` field-type validation and a corresponding C contract.
- Req-Test Evidence: None (no native test directly tests this; it's inferred from the skinny implementation)

## Coverage

| R | C IDs | Spec Check Names | Notes |
|---|-------|------------------|-------|
| R1 | C1 | `check_c1_assessment_source_type_constants` | Covered |
| R2 | C2 | `check_c2_case_insensitive_validation` | Covered |
| R3 | C3 | `check_c3_ai_judge_deprecation` | Covered |
| R4 | C4, C25 | `check_c4_invalid_source_type_raises`, `check_c25_parse_rejects_empty` | C4 weak (missing error_code) |
| R5 | C5 (via E2/E3) | `check_c5_standardize_returns_correct` (indirect) | Covered indirectly |
| R6 | C24 | `check_c24_str_method` | Covered |
| R7 | C2, C3, C4, C25 | (tested through `__init__` → `_parse`) | Covered indirectly |
| R8 | C5, C6 | `check_c5`, `check_c6` | Covered |
| R9 | C6, C7 | `check_c6`, `check_c7` | Covered |
| R10 | C9 | `check_c9_scorer_decorator_with_parens` | Covered |
| R11 | C8 | `check_c8_scorer_decorator_no_parens` | Covered |
| R12 | C10 | `check_c10_scorer_run_filtered_kwargs` | Covered |
| R13 | C8, C9 | `check_c8`, `check_c9` | Covered |
| R14 | C15 | `check_c15_scorer_serialization` | Covered |
| R15 | C16 | `check_c16_scorer_deserialization_reconstructs` | C16 depends on missing `scorer` + `recreate_function`; weak |
| R16 | C17, C18, C26 | `check_c17`, `check_c18`, `check_c26` | Covered |
| R17 | C19, C20 | `check_c19`, `check_c20` | C20 weak (no immutability); missing CLASS rejection |
| R18 | C10, C11, C12, C13, C14, C22, C23 | `check_c10`–`check_c14`, `check_c22`, `check_c23` | Covered |
| R19 | C21 | `check_c21_scorer_aggregations_config` | Covered |
| R20 | C8, C9, C15 | `check_c8`, `check_c9`, `check_scorer_docstring_description`, `check_c15` | Covered |
| — | — | `check_scorer_import_boundary`, `check_scorer_class_exists`, `check_scorer_kind_enum`, `check_scorer_status_enum`, `check_scorer_sampling_config`, `check_serialized_scorer_dataclass`, `check_scorer_from_proto`, `check_scorer_docstring_description` | Supplementary; not mapped to R |

**Unreachable / unreferenced C**: None. All C1–C26 are called from at least one spec file.

**Missing R**: `recreate_function` behavior (R needed), `SerializedScorer.__post_init__` (R needed), `ScorerKind.CLASS` registration rejection (R needed).

## Judge Focus

1. **Add `recreate_function` contracts**: The highest-priority gap — 23 native tests exercise `recreate_function` with zero spec coverage. Add contracts for: basic recreation, `SyntaxError` propagation, empty/invalid signature `MlflowException`, namespace availability, `__name__` fidelity, indentation handling, and type-hint support.

2. **Fix N12 import boundary**: The `scorer` symbol must be importable from `mlflow.genai` for any scorer-related spec to execute. Either update the `__init__.py` files or adjust the spec import paths.

3. **Strengthen C4**: Add `error_code == INVALID_PARAMETER_VALUE` assertion to the invalid-source-type check.

4. **Add immutability contract for lifecycle methods**: Extend C20 (or add new contract) to verify that `register()`, `start()`, `stop()`, `update()` return new instances.

5. **Add CLASS registration rejection contract**: Verify that `Scorer(name="x").register()` raises with message about "builtin or decorator scorer".

6. **Add SerializedScorer validation contract**: Verify `__post_init__` rejects zero or multiple scorer field types.
