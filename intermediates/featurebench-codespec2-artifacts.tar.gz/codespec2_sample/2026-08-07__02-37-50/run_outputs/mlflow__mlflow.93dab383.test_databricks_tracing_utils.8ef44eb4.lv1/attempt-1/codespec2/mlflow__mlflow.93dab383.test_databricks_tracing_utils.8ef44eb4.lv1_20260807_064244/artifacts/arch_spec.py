#!/usr/bin/env python3
"""
Architecture spec for MLflow Tracing and Assessment Data Management.

Exercises real public input -> caller/import -> helper/dispatcher -> observable result paths.
Evaluates integration paths: module imports, function dispatch, cross-module delegation.

Usage: python arch_spec.py
Exit 0 on all checks pass; non-zero on failure.
"""

import os
import sys
import warnings

# Ensure /testbed is on path
sys.path.insert(0, "/testbed")

# ============================================================
# Helper: run all checks and report
# ============================================================

_passed = 0
_failed = 0
_errors = []


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
        print(f"PASS: {name}")
    else:
        _failed += 1
        msg = f"FAIL: {name}" + (f" ({detail})" if detail else "")
        print(msg)
        _errors.append(msg)


# ============================================================
# SR1: assessment_to_proto
# ============================================================

def check_sr1_assessment_to_proto():
    """
    Verify assessment_to_proto converts Assessment -> proto.
    Exercises: import path, basic serialization, UC schema trace_id parsing,
    optional fields, metadata, timestamp conversion, expectation/feedback.
    """
    from mlflow.entities.assessment import Assessment, AssessmentSource
    from mlflow.entities.assessment import ExpectationValue, FeedbackValue
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.protos.databricks_tracing_pb2 import Assessment as ProtoAssessment

    # --- Basic assessment with MLflow experiment location (non-UC) ---
    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="user123")
    assessment = Assessment(
        name="test_assessment",
        trace_id="tr-abc123",
        source=source,
        create_time_ms=1000000,
        last_update_time_ms=2000000,
        span_id="span-001",
        rationale="Good answer",
        metadata={"k1": "v1", "k2": 42},
    )
    proto = assessment_to_proto(assessment)
    check("SR1: proto is ProtoAssessment", isinstance(proto, ProtoAssessment))
    check("SR1: assessment_name", proto.assessment_name == "test_assessment")
    check("SR1: trace_id (non-UC)", proto.trace_id == "tr-abc123")
    check("SR1: span_id", proto.span_id == "span-001")
    check("SR1: rationale", proto.rationale == "Good answer")
    check("SR1: metadata k1", proto.metadata["k1"] == "v1")
    check("SR1: metadata k2 stringified", proto.metadata["k2"] == "42")
    check("SR1: create_time", proto.create_time.ToMilliseconds() == 1000000)
    check("SR1: last_update_time", proto.last_update_time.ToMilliseconds() == 2000000)
    check("SR1: source type", proto.source.source_type == 1)  # HUMAN
    check("SR1: source id", proto.source.source_id == "user123")

    # --- Assessment with expectation ---
    assessment_exp = Assessment(
        name="exp_test",
        trace_id="tr-def456",
        source=source,
        create_time_ms=3000000,
        last_update_time_ms=4000000,
        expectation=ExpectationValue(value="expected"),
    )
    proto_exp = assessment_to_proto(assessment_exp)
    check("SR1: expectation set", proto_exp.HasField("expectation"))
    check("SR1: feedback not set", not proto_exp.HasField("feedback"))

    # --- Assessment with feedback ---
    assessment_fb = Assessment(
        name="fb_test",
        trace_id="tr-ghi789",
        source=source,
        create_time_ms=5000000,
        last_update_time_ms=6000000,
        feedback=FeedbackValue(value=4.5),
    )
    proto_fb = assessment_to_proto(assessment_fb)
    check("SR1: feedback set", proto_fb.HasField("feedback"))
    check("SR1: expectation not set", not proto_fb.HasField("expectation"))

    # --- Assessment with overrides=None (not set) ---
    assessment_no_ov = Assessment(
        name="no_override",
        trace_id="tr-1",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        overrides=None,
    )
    proto_no_ov = assessment_to_proto(assessment_no_ov)
    check("SR1: overrides unset when None", not proto_no_ov.HasField("overrides"))

    # --- Assessment with valid field ---
    assessment_valid = Assessment(
        name="valid_test",
        trace_id="tr-2",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        valid=True,
    )
    proto_valid = assessment_to_proto(assessment_valid)
    check("SR1: valid=True set", proto_valid.HasField("valid") and proto_valid.valid is True)

    # --- Assessment with UC schema trace_id ---
    from mlflow.tracing.utils import construct_trace_id_v4
    uc_trace_id = construct_trace_id_v4("my_catalog.my_schema", "trace-uc-1")
    assessment_uc = Assessment(
        name="uc_test",
        trace_id=uc_trace_id,
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
    )
    proto_uc = assessment_to_proto(assessment_uc)
    check("SR1: UC trace_id parsed", proto_uc.trace_id == "trace-uc-1")
    check("SR1: UC trace_location set",
          proto_uc.HasField("trace_location") and
          proto_uc.trace_location.HasField("uc_schema"))
    check("SR1: UC catalog",
          proto_uc.trace_location.uc_schema.catalog_name == "my_catalog")
    check("SR1: UC schema",
          proto_uc.trace_location.uc_schema.schema_name == "my_schema")

    # --- Assessment with overrides="" (empty string) ---
    # Per F2 review: truthiness check may drop empty string
    assessment_empty_ov = Assessment(
        name="empty_override",
        trace_id="tr-3",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        overrides="",
    )
    proto_empty_ov = assessment_to_proto(assessment_empty_ov)
    check("SR1: overrides='' preserved (F2 fix)",
          proto_empty_ov.HasField("overrides") and proto_empty_ov.overrides == "",
          "F2: empty string overrides should be serialized, not dropped")


# ============================================================
# SR2: get_trace_id_from_assessment_proto
# ============================================================

def check_sr2_get_trace_id_from_assessment_proto():
    """
    Verify get_trace_id_from_assessment_proto handles both assessments_pb2
    and databricks_tracing_pb2 Assessment protos.
    """
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos.assessments_pb2 import Assessment as AssessmentsProtoAssessment
    from mlflow.protos.databricks_tracing_pb2 import Assessment as DatabricksProtoAssessment
    from mlflow.protos.databricks_tracing_pb2 import (
        TraceLocation, UCSchemaLocation,
    )

    # --- assessments_pb2.Assessment (no trace_location field) ---
    proto_plain = AssessmentsProtoAssessment()
    proto_plain.trace_id = "plain-trace-id"
    tid = get_trace_id_from_assessment_proto(proto_plain)
    check("SR2: plain proto trace_id", tid == "plain-trace-id")

    # --- databricks_tracing_pb2.Assessment with UC schema trace_location ---
    proto_uc = DatabricksProtoAssessment()
    proto_uc.trace_id = "inner-trace-id"
    tl = TraceLocation()
    tl.type = TraceLocation.TraceLocationType.UC_SCHEMA
    tl.uc_schema.CopyFrom(UCSchemaLocation(catalog_name="cat", schema_name="sch"))
    proto_uc.trace_location.CopyFrom(tl)
    tid_uc = get_trace_id_from_assessment_proto(proto_uc)
    check("SR2: UC proto has v4 prefix", tid_uc.startswith("trace:/"))
    check("SR2: UC proto contains location", "cat.sch" in tid_uc)
    check("SR2: UC proto contains trace_id", "inner-trace-id" in tid_uc)

    # --- databricks_tracing_pb2.Assessment with non-UC trace_location ---
    proto_non_uc = DatabricksProtoAssessment()
    proto_non_uc.trace_id = "non-uc-id"
    tl2 = TraceLocation()
    tl2.type = TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto_non_uc.trace_location.CopyFrom(tl2)
    tid_non_uc = get_trace_id_from_assessment_proto(proto_non_uc)
    check("SR2: non-UC trace_location returns raw trace_id", tid_non_uc == "non-uc-id")


# ============================================================
# SR3: inference_table_location_to_proto
# ============================================================

def check_sr3_inference_table_location_to_proto():
    """Verify inference_table_location_to_proto maps full_table_name."""
    from mlflow.entities.trace_location import InferenceTableLocation
    from mlflow.utils.databricks_tracing_utils import inference_table_location_to_proto
    from mlflow.protos.databricks_tracing_pb2 import InferenceTableLocation as ProtoITL

    loc = InferenceTableLocation(full_table_name="catalog.schema.table")
    proto = inference_table_location_to_proto(loc)
    check("SR3: proto type", isinstance(proto, ProtoITL))
    check("SR3: full_table_name", proto.full_table_name == "catalog.schema.table")


# ============================================================
# SR4: mlflow_experiment_location_to_proto
# ============================================================

def check_sr4_mlflow_experiment_location_to_proto():
    """Verify mlflow_experiment_location_to_proto maps experiment_id."""
    from mlflow.entities.trace_location import MlflowExperimentLocation
    from mlflow.utils.databricks_tracing_utils import mlflow_experiment_location_to_proto
    from mlflow.protos.databricks_tracing_pb2 import (
        MlflowExperimentLocation as ProtoMEL,
    )

    loc = MlflowExperimentLocation(experiment_id="exp-42")
    proto = mlflow_experiment_location_to_proto(loc)
    check("SR4: proto type", isinstance(proto, ProtoMEL))
    check("SR4: experiment_id", proto.experiment_id == "exp-42")


# ============================================================
# SR5: trace_from_proto
# ============================================================

def check_sr5_trace_from_proto():
    """
    Verify trace_from_proto deserializes proto Trace -> Trace entity.
    Exercises the full path through TraceInfo.from_proto.
    """
    from mlflow.entities import Trace
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.utils.databricks_tracing_utils import trace_from_proto
    from mlflow.protos.databricks_tracing_pb2 import Trace as ProtoTrace
    from mlflow.protos.databricks_tracing_pb2 import (
        TraceInfo as ProtoTraceInfo,
        TraceLocation as ProtoTraceLocation,
    )
    from google.protobuf.timestamp_pb2 import Timestamp

    # Build a minimal proto Trace
    ts = Timestamp()
    ts.FromMilliseconds(1000000)

    proto_tl = ProtoTraceLocation()
    proto_tl.type = ProtoTraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto_tl.mlflow_experiment.experiment_id = "exp-1"

    proto_ti = ProtoTraceInfo()
    proto_ti.trace_id = "trace-001"
    proto_ti.trace_location.CopyFrom(proto_tl)
    proto_ti.request_time.CopyFrom(ts)
    proto_ti.state = ProtoTraceInfo.STATE_UNSPECIFIED

    proto_trace = ProtoTrace()
    proto_trace.trace_info.CopyFrom(proto_ti)
    # No spans — should still work

    trace = trace_from_proto(proto_trace, "location-1")
    check("SR5: trace is Trace", isinstance(trace, Trace))
    check("SR5: trace.info exists", trace.info is not None)
    check("SR5: trace.info.trace_id", trace.info.trace_id == "trace-001")
    check("SR5: trace.data exists", trace.data is not None)
    check("SR5: trace.data.spans is list", isinstance(trace.data.spans, list))
    check("SR5: empty spans", len(trace.data.spans) == 0)


# ============================================================
# SR6: trace_info_to_v4_proto
# ============================================================

def check_sr6_trace_info_to_v4_proto():
    """
    Verify trace_info_to_v4_proto converts TraceInfo -> v4 proto.
    Also verify TraceInfo.to_proto() works for UC_SCHEMA (F4 fix).
    """
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.protos.databricks_tracing_pb2 import TraceInfo as ProtoTraceInfo

    # --- Non-UC location ---
    from mlflow.entities.trace_location import MlflowExperimentLocation
    tl_exp = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-42"),
    )

    ti = TraceInfo(
        trace_id="trace-xyz",
        trace_location=tl_exp,
        request_time=1000000,
        state=TraceState.OK,
        client_request_id="cli-1",
        trace_metadata={"meta_k": "meta_v"},
        tags={"tag_k": "tag_v"},
    )
    proto = trace_info_to_v4_proto(ti)
    check("SR6: proto type", isinstance(proto, ProtoTraceInfo))
    check("SR6: trace_id", proto.trace_id == "trace-xyz")
    check("SR6: client_request_id", proto.client_request_id == "cli-1")
    check("SR6: request_time", proto.request_time.ToMilliseconds() == 1000000)
    check("SR6: state", proto.state == ProtoTraceInfo.OK)
    check("SR6: no execution_duration", not proto.HasField("execution_duration"),
          "execution_duration should be unset when None")

    # --- With execution_duration ---
    ti_with_dur = TraceInfo(
        trace_id="trace-dur",
        trace_location=tl_exp,
        request_time=2000000,
        state=TraceState.ERROR,
        execution_duration=500,
    )
    proto_dur = trace_info_to_v4_proto(ti_with_dur)
    check("SR6: execution_duration set",
          proto_dur.HasField("execution_duration") and
          proto_dur.execution_duration.ToMilliseconds() == 500)

    # --- UC_SCHEMA location (v4 trace_id parsing) ---
    from mlflow.tracing.utils import construct_trace_id_v4
    v4_trace_id = construct_trace_id_v4("cat.sch", "inner-tid")
    tl_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    ti_uc = TraceInfo(
        trace_id=v4_trace_id,
        trace_location=tl_uc,
        request_time=3000000,
        state=TraceState.IN_PROGRESS,
    )
    proto_uc = trace_info_to_v4_proto(ti_uc)
    check("SR6: UC v4 trace_id parsed", proto_uc.trace_id == "inner-tid")

    # --- F4: TraceInfo.to_proto() must work for UC_SCHEMA without NameError ---
    try:
        proto_from_method = ti_uc.to_proto()
        check("SR6/F4: TraceInfo.to_proto() for UC_SCHEMA succeeds",
              isinstance(proto_from_method, ProtoTraceInfo))
        check("SR6/F4: to_proto trace_id matches",
              proto_from_method.trace_id == "inner-tid")
    except NameError as e:
        check("SR6/F4: TraceInfo.to_proto() for UC_SCHEMA (NameError)", False,
              f"F4 regression: NameError {e}")
    except Exception as e:
        check("SR6/F4: TraceInfo.to_proto() for UC_SCHEMA (exception)", False,
              f"Unexpected error: {type(e).__name__}: {e}")


# ============================================================
# SR7: trace_location_from_proto
# ============================================================

def check_sr7_trace_location_from_proto():
    """Verify trace_location_from_proto handles all three location types + unspecified."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.entities.trace_location import TraceLocation, TraceLocationType
    from mlflow.protos.databricks_tracing_pb2 import (
        TraceLocation as ProtoTraceLocation,
        UCSchemaLocation as ProtoUCSL,
        MlflowExperimentLocation as ProtoMEL,
        InferenceTableLocation as ProtoITL,
    )

    # --- UC_SCHEMA ---
    ptl_uc = ProtoTraceLocation()
    ptl_uc.type = ProtoTraceLocation.TraceLocationType.UC_SCHEMA
    ptl_uc.uc_schema.CopyFrom(ProtoUCSL(catalog_name="uc_cat", schema_name="uc_sch"))
    loc_uc = trace_location_from_proto(ptl_uc)
    check("SR7: UC type", loc_uc.type == TraceLocationType.UC_SCHEMA)
    check("SR7: UC catalog", loc_uc.uc_schema.catalog_name == "uc_cat")
    check("SR7: UC schema", loc_uc.uc_schema.schema_name == "uc_sch")

    # --- MLFLOW_EXPERIMENT ---
    ptl_exp = ProtoTraceLocation()
    ptl_exp.type = ProtoTraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    ptl_exp.mlflow_experiment.CopyFrom(ProtoMEL(experiment_id="exp-5"))
    loc_exp = trace_location_from_proto(ptl_exp)
    check("SR7: MLFLOW_EXPERIMENT type", loc_exp.type == TraceLocationType.MLFLOW_EXPERIMENT)
    check("SR7: MLFLOW_EXPERIMENT id", loc_exp.mlflow_experiment.experiment_id == "exp-5")

    # --- INFERENCE_TABLE ---
    ptl_it = ProtoTraceLocation()
    ptl_it.type = ProtoTraceLocation.TraceLocationType.INFERENCE_TABLE
    ptl_it.inference_table.CopyFrom(ProtoITL(full_table_name="cat.sch.tbl"))
    loc_it = trace_location_from_proto(ptl_it)
    check("SR7: INFERENCE_TABLE type", loc_it.type == TraceLocationType.INFERENCE_TABLE)
    check("SR7: INFERENCE_TABLE name", loc_it.inference_table.full_table_name == "cat.sch.tbl")

    # --- Unspecified ---
    ptl_unspec = ProtoTraceLocation()
    ptl_unspec.type = ProtoTraceLocation.TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED
    loc_unspec = trace_location_from_proto(ptl_unspec)
    check("SR7: unspecified type",
          loc_unspec.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)


# ============================================================
# SR8: trace_location_to_proto
# ============================================================

def check_sr8_trace_location_to_proto():
    """Verify trace_location_to_proto handles all three types and raises on unspecified."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as ProtoTraceLocation

    # --- UC_SCHEMA ---
    loc_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    ptl_uc = trace_location_to_proto(loc_uc)
    check("SR8: UC proto type enum",
          ptl_uc.type == ProtoTraceLocation.TraceLocationType.UC_SCHEMA)
    check("SR8: UC proto has uc_schema", ptl_uc.HasField("uc_schema"))
    check("SR8: UC catalog", ptl_uc.uc_schema.catalog_name == "cat")

    # --- MLFLOW_EXPERIMENT ---
    loc_exp = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-99"),
    )
    ptl_exp = trace_location_to_proto(loc_exp)
    check("SR8: MLFLOW_EXPERIMENT proto type",
          ptl_exp.type == ProtoTraceLocation.TraceLocationType.MLFLOW_EXPERIMENT)
    check("SR8: MLFLOW_EXPERIMENT proto has mlflow_experiment",
          ptl_exp.HasField("mlflow_experiment"))
    check("SR8: experiment_id", ptl_exp.mlflow_experiment.experiment_id == "exp-99")

    # --- INFERENCE_TABLE ---
    loc_it = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="c.s.t"),
    )
    ptl_it = trace_location_to_proto(loc_it)
    check("SR8: INFERENCE_TABLE proto type",
          ptl_it.type == ProtoTraceLocation.TraceLocationType.INFERENCE_TABLE)
    check("SR8: INFERENCE_TABLE proto has inference_table",
          ptl_it.HasField("inference_table"))
    check("SR8: full_table_name", ptl_it.inference_table.full_table_name == "c.s.t")

    # --- ValueError on unspecified ---
    loc_bad = TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    try:
        trace_location_to_proto(loc_bad)
        check("SR8: ValueError on unspecified", False, "Should have raised ValueError")
    except ValueError:
        check("SR8: ValueError on unspecified", True)


# ============================================================
# SR9: trace_to_proto
# ============================================================

def check_sr9_trace_to_proto():
    """
    Verify trace_to_proto converts Trace -> proto Trace.
    F1 review: verify that trace_to_proto uses trace.info.to_proto() delegation.
    """
    from mlflow.entities import Trace, TraceData, TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    from mlflow.protos.databricks_tracing_pb2 import Trace as ProtoTrace

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-42"),
    )
    ti = TraceInfo(
        trace_id="trace-to-proto",
        trace_location=tl,
        request_time=1000000,
        state=TraceState.OK,
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))
    proto = trace_to_proto(trace)

    check("SR9: proto is ProtoTrace", isinstance(proto, ProtoTrace))
    check("SR9: trace_info exists", proto.HasField("trace_info"))
    check("SR9: trace_id", proto.trace_info.trace_id == "trace-to-proto")
    check("SR9: spans is list", len(proto.spans) == 0)

    # F1: Verify that trace_to_proto delegates through trace.info.to_proto().
    # We test by constructing a UC_SCHEMA trace where trace.info.to_proto()
    # must parse v4 trace IDs. If trace_to_proto calls trace_info_to_v4_proto
    # directly it would also work, but the interface says "uses the trace's
    # built-in to_proto()". Both paths converge, so we verify correctness
    # of the output for a UC_SCHEMA trace.
    from mlflow.entities.trace_location import UCSchemaLocation
    from mlflow.tracing.utils import construct_trace_id_v4

    v4_tid = construct_trace_id_v4("c.d", "inner-id")
    tl_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="c", schema_name="d"),
    )
    ti_uc = TraceInfo(
        trace_id=v4_tid,
        trace_location=tl_uc,
        request_time=2000000,
        state=TraceState.OK,
    )
    trace_uc = Trace(info=ti_uc, data=TraceData(spans=[]))
    proto_uc = trace_to_proto(trace_uc)
    check("SR9/F1: UC trace_id parsed correctly",
          proto_uc.trace_info.trace_id == "inner-id",
          "F1: UC v4 trace ID should be parsed to inner id")


# ============================================================
# SR10: uc_schema_location_from_proto
# ============================================================

def check_sr10_uc_schema_location_from_proto():
    """Verify uc_schema_location_from_proto with and without OTel table names."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import UCSchemaLocation as ProtoUCSL

    # --- With OTel table names ---
    proto_full = ProtoUCSL(
        catalog_name="cat1",
        schema_name="sch1",
        otel_spans_table_name="spans_tbl",
        otel_logs_table_name="logs_tbl",
    )
    loc_full = uc_schema_location_from_proto(proto_full)
    check("SR10: catalog_name", loc_full.catalog_name == "cat1")
    check("SR10: schema_name", loc_full.schema_name == "sch1")
    check("SR10: _otel_spans_table_name", loc_full._otel_spans_table_name == "spans_tbl")
    check("SR10: _otel_logs_table_name", loc_full._otel_logs_table_name == "logs_tbl")

    # --- Without OTel table names ---
    proto_min = ProtoUCSL(catalog_name="cat2", schema_name="sch2")
    loc_min = uc_schema_location_from_proto(proto_min)
    check("SR10: min catalog", loc_min.catalog_name == "cat2")
    check("SR10: min schema", loc_min.schema_name == "sch2")
    # When not set in proto, _otel_spans_table_name should retain default
    check("SR10: min has default spans table", loc_min._otel_spans_table_name is not None)
    check("SR10: min has default logs table", loc_min._otel_logs_table_name is not None)


# ============================================================
# SR11: uc_schema_location_to_proto
# ============================================================

def check_sr11_uc_schema_location_to_proto():
    """Verify uc_schema_location_to_proto with explicit and default table names."""
    from mlflow.entities.trace_location import UCSchemaLocation
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto
    from mlflow.protos.databricks_tracing_pb2 import UCSchemaLocation as ProtoUCSL

    # --- With explicit table names ---
    loc = UCSchemaLocation(
        catalog_name="cat",
        schema_name="sch",
    )
    loc._otel_spans_table_name = "custom_spans"
    loc._otel_logs_table_name = "custom_logs"
    proto = uc_schema_location_to_proto(loc)
    check("SR11: proto type", isinstance(proto, ProtoUCSL))
    check("SR11: catalog", proto.catalog_name == "cat")
    check("SR11: schema", proto.schema_name == "sch")
    check("SR11: spans table", proto.otel_spans_table_name == "custom_spans")
    check("SR11: logs table", proto.otel_logs_table_name == "custom_logs")

    # --- With default table names ---
    loc_default = UCSchemaLocation(catalog_name="def_cat", schema_name="def_sch")
    proto_def = uc_schema_location_to_proto(loc_default)
    check("SR11: default spans table set",
          proto_def.otel_spans_table_name != "")
    check("SR11: default logs table set",
          proto_def.otel_logs_table_name != "")


# ============================================================
# SR12: AssessmentSourceType
# ============================================================

def check_sr12_assessment_source_type():
    """
    Verify AssessmentSourceType: constants, _standardize, _parse, __init__, __str__,
    deprecation handling, validation, _SOURCE_TYPES.
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    # --- Constants are strings ---
    check("SR12: HUMAN is str", isinstance(AssessmentSourceType.HUMAN, str))
    check("SR12: LLM_JUDGE is str", isinstance(AssessmentSourceType.LLM_JUDGE, str))
    check("SR12: AI_JUDGE is str", isinstance(AssessmentSourceType.AI_JUDGE, str))
    check("SR12: CODE is str", isinstance(AssessmentSourceType.CODE, str))
    check("SR12: SOURCE_TYPE_UNSPECIFIED is str",
          isinstance(AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED, str))

    # --- _SOURCE_TYPES excludes deprecated AI_JUDGE ---
    check("SR12: AI_JUDGE not in _SOURCE_TYPES",
          "AI_JUDGE" not in AssessmentSourceType._SOURCE_TYPES,
          f"Got {AssessmentSourceType._SOURCE_TYPES}")
    check("SR12: LLM_JUDGE in _SOURCE_TYPES",
          "LLM_JUDGE" in AssessmentSourceType._SOURCE_TYPES)
    check("SR12: HUMAN in _SOURCE_TYPES",
          "HUMAN" in AssessmentSourceType._SOURCE_TYPES)
    check("SR12: CODE in _SOURCE_TYPES",
          "CODE" in AssessmentSourceType._SOURCE_TYPES)
    check("SR12: SOURCE_TYPE_UNSPECIFIED in _SOURCE_TYPES",
          "SOURCE_TYPE_UNSPECIFIED" in AssessmentSourceType._SOURCE_TYPES)

    # --- Constructor and __str__ ---
    t = AssessmentSourceType("human")
    check("SR12: __init__ case-insensitive", str(t) == "HUMAN")
    t2 = AssessmentSourceType("LLM_JUDGE")
    check("SR12: __init__ preserves valid", str(t2) == "LLM_JUDGE")

    # --- _standardize ---
    check("SR12: _standardize lowercase",
          AssessmentSourceType._standardize("code") == "CODE")
    check("SR12: _standardize mixed",
          AssessmentSourceType._standardize("Human") == "HUMAN")

    # --- Deprecation: AI_JUDGE -> LLM_JUDGE with warning ---
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        check("SR12: AI_JUDGE standardizes to LLM_JUDGE", result == "LLM_JUDGE")
        check("SR12: AI_JUDGE emits FutureWarning",
              len(w) == 1 and issubclass(w[0].category, FutureWarning))

    # --- Validation: invalid type raises MlflowException ---
    try:
        AssessmentSourceType._standardize("INVALID_TYPE_XYZ")
        check("SR12: invalid type raises MlflowException", False)
    except MlflowException as e:
        check("SR12: invalid type raises MlflowException", True,
              f"Got: {e.message}")
        check("SR12: error code INVALID_PARAMETER_VALUE",
              "INVALID_PARAMETER_VALUE" in str(e.error_code))


# ============================================================
# SR13: Span.inputs/outputs — functional round-trip
# ============================================================

def check_sr13_span_inputs_outputs():
    """
    Verify Span.inputs and Span.outputs as functional properties,
    not just structural existence (F3 fix).
    """
    from mlflow.entities.span import Span, LiveSpan, NoOpSpan
    from mlflow.tracing.constant import SpanAttributeKey
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan

    # --- Structural existence ---
    check("SR13: Span has inputs property",
          hasattr(Span, 'inputs') and isinstance(Span.inputs, property))
    check("SR13: Span has outputs property",
          hasattr(Span, 'outputs') and isinstance(Span.outputs, property))
    check("SR13: LiveSpan has inputs property",
          hasattr(LiveSpan, 'inputs'))
    check("SR13: LiveSpan has outputs property",
          hasattr(LiveSpan, 'outputs'))
    check("SR13: NoOpSpan has inputs property",
          hasattr(NoOpSpan, 'inputs'))
    check("SR13: NoOpSpan has outputs property",
          hasattr(NoOpSpan, 'outputs'))

    # --- Functional round-trip via LiveSpan ---
    # Create a LiveSpan, set inputs/outputs, end it, and verify Span retrieval
    import json
    from opentelemetry import trace as trace_api
    from opentelemetry.sdk.trace import TracerProvider, SpanProcessor
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    processor = SimpleSpanProcessor(exporter)
    provider.add_span_processor(processor)

    tracer = provider.get_tracer("test")
    # We can't easily end-to-end test LiveSpan -> Span because it requires
    # the MLflow trace manager. Instead, test the attribute persistence path
    # by directly verifying the attribute key access pattern.

    # Create a span via OTel and wrap it
    otel_span = tracer.start_span("test_span")
    # Set attributes in the OTel span
    from mlflow.tracing.utils import dump_span_attribute_value
    otel_span.set_attribute(SpanAttributeKey.INPUTS,
                            dump_span_attribute_value({"query": "hello", "temp": 0.7}))
    otel_span.set_attribute(SpanAttributeKey.OUTPUTS,
                            dump_span_attribute_value(["result1", "result2"]))
    otel_span.end()

    # Force flush
    provider.force_flush()

    # Get the ReadableSpan from exporter
    finished_spans = exporter.get_finished_spans()
    if finished_spans:
        readable_span = finished_spans[0]
        span = Span(readable_span)

        # Verify inputs and outputs are retrieved correctly
        inp = span.inputs
        out = span.outputs
        check("SR13: inputs retrieved", inp == {"query": "hello", "temp": 0.7},
              f"Got {inp}")
        check("SR13: outputs retrieved", out == ["result1", "result2"],
              f"Got {out}")

    # --- None for unset inputs/outputs ---
    otel_span2 = tracer.start_span("empty_span")
    otel_span2.end()
    provider.force_flush()
    finished_spans2 = exporter.get_finished_spans()
    if len(finished_spans2) >= 2:
        span_empty = Span(finished_spans2[1])
        check("SR13: inputs None when unset", span_empty.inputs is None)
        check("SR13: outputs None when unset", span_empty.outputs is None)

    # --- NoOpSpan inputs/outputs ---
    noop = NoOpSpan()
    check("SR13: NoOpSpan.inputs returns None", noop.inputs is None)
    check("SR13: NoOpSpan.outputs returns None", noop.outputs is None)


# ============================================================
# Run all checks
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("ARCHITECTURE SPEC for MLflow Tracing Utils")
    print("=" * 60)

    check_sr1_assessment_to_proto()
    check_sr2_get_trace_id_from_assessment_proto()
    check_sr3_inference_table_location_to_proto()
    check_sr4_mlflow_experiment_location_to_proto()
    check_sr5_trace_from_proto()
    check_sr6_trace_info_to_v4_proto()
    check_sr7_trace_location_from_proto()
    check_sr8_trace_location_to_proto()
    check_sr9_trace_to_proto()
    check_sr10_uc_schema_location_from_proto()
    check_sr11_uc_schema_location_to_proto()
    check_sr12_assessment_source_type()
    check_sr13_span_inputs_outputs()

    print("=" * 60)
    print(f"RESULTS: {_passed} passed, {_failed} failed")
    print("=" * 60)
    sys.exit(0 if _failed == 0 else 1)
