#!/usr/bin/env python3
"""
Behavior spec for MLflow Tracing and Assessment Data Management.

Tests state transitions, input/output boundaries, error handling, conversion
compatibility, deprecation behavior, and repeated-call invariants.

Usage: python behavior_spec.py
Exit 0 on all checks pass; non-zero on failure.
"""

import os
import sys
import warnings

sys.path.insert(0, "/testbed")

_passed = 0
_failed = 0
_errors = []


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
        print(f"PASS: {name}")
    else:
        _failed += 1
        msg = f"FAIL: {name}" + (f" ({detail})" if detail else "")
        print(msg)
        _errors.append(msg)


# ============================================================
# SR1: assessment_to_proto — state transitions & boundary
# ============================================================

def check_sr1_assessment_to_proto():
    """
    Behavior: Verify conversion correctness, optional fields, boundary cases
    including empty string overrides (F2), None-optional fields, metadata
    type conversion, timestamp precision, expectation/feedback mutual exclusion.
    """
    from mlflow.entities.assessment import (
        Assessment, AssessmentSource, ExpectationValue, FeedbackValue,
    )
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    source = AssessmentSource(source_type=AssessmentSourceType.CODE, source_id="code-1")

    # --- All optional fields None ---
    a_min = Assessment(
        name="min",
        trace_id="tr-min",
        source=source,
        create_time_ms=1000,
        last_update_time_ms=2000,
    )
    p = assessment_to_proto(a_min)
    check("SR1-B: name", p.assessment_name == "min")
    check("SR1-B: trace_id", p.trace_id == "tr-min")
    check("SR1-B: span_id unset", not p.HasField("span_id"))
    check("SR1-B: rationale unset", not p.HasField("rationale"))
    check("SR1-B: assessment_id unset", not p.HasField("assessment_id"))
    check("SR1-B: overrides unset (None)", not p.HasField("overrides"))
    check("SR1-B: valid unset", not p.HasField("valid"))

    # --- Overrides = "" (empty string, F2) ---
    a_empty_ov = Assessment(
        name="empty_ov",
        trace_id="tr-eov",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        overrides="",
    )
    p_empty = assessment_to_proto(a_empty_ov)
    check("SR1-B: overrides='' is set (F2)", p_empty.HasField("overrides"),
          "F2: empty string overrides must not be dropped")
    check("SR1-B: overrides='' value is empty", p_empty.overrides == "")

    # --- Overrides = "parent_id" (non-empty) ---
    a_ov = Assessment(
        name="ov",
        trace_id="tr-ov",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        overrides="parent_assess_id",
    )
    p_ov = assessment_to_proto(a_ov)
    check("SR1-B: overrides non-empty set", p_ov.HasField("overrides"))
    check("SR1-B: overrides value", p_ov.overrides == "parent_assess_id")

    # --- valid = False ---
    a_valid_false = Assessment(
        name="vf",
        trace_id="tr-vf",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        valid=False,
    )
    p_vf = assessment_to_proto(a_valid_false)
    check("SR1-B: valid=False set", p_vf.HasField("valid") and p_vf.valid is False)

    # --- Metadata with non-string values ---
    a_meta = Assessment(
        name="meta",
        trace_id="tr-meta",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        metadata={"int_key": 123, "float_key": 3.14, "bool_key": True},
    )
    p_meta = assessment_to_proto(a_meta)
    check("SR1-B: int metadata stringified", p_meta.metadata["int_key"] == "123")
    check("SR1-B: float metadata stringified", p_meta.metadata["float_key"] == "3.14")
    check("SR1-B: bool metadata stringified", p_meta.metadata["bool_key"] == "True")

    # --- Timestamp precision ---
    a_ts = Assessment(
        name="ts",
        trace_id="tr-ts",
        source=source,
        create_time_ms=1700000000000,
        last_update_time_ms=1700000001000,
    )
    p_ts = assessment_to_proto(a_ts)
    check("SR1-B: create_time_ms roundtrip",
          p_ts.create_time.ToMilliseconds() == 1700000000000)
    check("SR1-B: last_update_time_ms roundtrip",
          p_ts.last_update_time.ToMilliseconds() == 1700000001000)

    # --- Expectation (no feedback) ---
    a_exp = Assessment(
        name="exp",
        trace_id="tr-exp",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        expectation=ExpectationValue(value={"nested": "data"}),
    )
    p_exp = assessment_to_proto(a_exp)
    check("SR1-B: expectation set, feedback not", p_exp.HasField("expectation") and
          not p_exp.HasField("feedback"))

    # --- Feedback (no expectation) ---
    a_fb = Assessment(
        name="fb",
        trace_id="tr-fb",
        source=source,
        create_time_ms=1,
        last_update_time_ms=2,
        feedback=FeedbackValue(value=42),
    )
    p_fb = assessment_to_proto(a_fb)
    check("SR1-B: feedback set, expectation not", p_fb.HasField("feedback") and
          not p_fb.HasField("expectation"))


# ============================================================
# SR2: get_trace_id_from_assessment_proto — compatibility
# ============================================================

def check_sr2_get_trace_id_from_assessment_proto():
    """
    Behavior: Verify extract trace ID from both proto types, UC/non-UC
    trace_location handling, and plain proto compatibility.
    """
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos.assessments_pb2 import Assessment as PlainAssessment
    from mlflow.protos.databricks_tracing_pb2 import (
        Assessment as DBAssessment,
        TraceLocation, UCSchemaLocation,
    )

    # --- Repeated calls produce same result (idempotency) ---
    proto = PlainAssessment()
    proto.trace_id = "stable-id"
    tid1 = get_trace_id_from_assessment_proto(proto)
    tid2 = get_trace_id_from_assessment_proto(proto)
    check("SR2-B: idempotent", tid1 == tid2 == "stable-id")

    # --- UC proto: trace_id is transformed to v4 format ---
    db_uc = DBAssessment()
    db_uc.trace_id = "inner"
    tl = TraceLocation()
    tl.type = TraceLocation.TraceLocationType.UC_SCHEMA
    tl.uc_schema.CopyFrom(UCSchemaLocation(catalog_name="a", schema_name="b"))
    db_uc.trace_location.CopyFrom(tl)
    tid_uc = get_trace_id_from_assessment_proto(db_uc)
    check("SR2-B: UC returns v4 prefix", tid_uc.startswith("trace:/"))

    # --- Non-UC trace_location returns raw trace_id ---
    db_non_uc = DBAssessment()
    db_non_uc.trace_id = "raw-trace"
    tl2 = TraceLocation()
    tl2.type = TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    db_non_uc.trace_location.CopyFrom(tl2)
    tid_non = get_trace_id_from_assessment_proto(db_non_uc)
    check("SR2-B: non-UC returns raw", tid_non == "raw-trace")


# ============================================================
# SR3: inference_table_location_to_proto — boundary
# ============================================================

def check_sr3_inference_table_location_to_proto():
    """Behavior: Verify empty, special chars, repeated calls."""
    from mlflow.entities.trace_location import InferenceTableLocation
    from mlflow.utils.databricks_tracing_utils import inference_table_location_to_proto

    # Repeated calls produce same result
    loc = InferenceTableLocation(full_table_name="catalog.schema.table")
    p1 = inference_table_location_to_proto(loc)
    p2 = inference_table_location_to_proto(loc)
    check("SR3-B: idempotent", p1.full_table_name == p2.full_table_name)

    # Empty string (valid input)
    loc_empty = InferenceTableLocation(full_table_name="")
    p_empty = inference_table_location_to_proto(loc_empty)
    check("SR3-B: empty full_table_name", p_empty.full_table_name == "")

    # Special characters
    loc_special = InferenceTableLocation(full_table_name="cat.sch.tbl-1_v2")
    p_special = inference_table_location_to_proto(loc_special)
    check("SR3-B: special chars", p_special.full_table_name == "cat.sch.tbl-1_v2")


# ============================================================
# SR4: mlflow_experiment_location_to_proto — boundary
# ============================================================

def check_sr4_mlflow_experiment_location_to_proto():
    """Behavior: Verify experiment_id mapping with various values."""
    from mlflow.entities.trace_location import MlflowExperimentLocation
    from mlflow.utils.databricks_tracing_utils import mlflow_experiment_location_to_proto

    # Numeric experiment ID
    loc_num = MlflowExperimentLocation(experiment_id="42")
    p_num = mlflow_experiment_location_to_proto(loc_num)
    check("SR4-B: numeric id", p_num.experiment_id == "42")

    # UUID experiment ID
    loc_uuid = MlflowExperimentLocation(experiment_id="550e8400-e29b-41d4-a716-446655440000")
    p_uuid = mlflow_experiment_location_to_proto(loc_uuid)
    check("SR4-B: uuid id", p_uuid.experiment_id == "550e8400-e29b-41d4-a716-446655440000")

    # Idempotent
    p1 = mlflow_experiment_location_to_proto(loc_num)
    p2 = mlflow_experiment_location_to_proto(loc_num)
    check("SR4-B: idempotent", p1.experiment_id == p2.experiment_id)


# ============================================================
# SR5: trace_from_proto — state transitions
# ============================================================

def check_sr5_trace_from_proto():
    """
    Behavior: Verify trace_from_proto returns correct entity with
    varying proto inputs: single span, empty spans, metadata, tags.
    """
    from mlflow.entities import Trace
    from mlflow.utils.databricks_tracing_utils import trace_from_proto
    from mlflow.protos.databricks_tracing_pb2 import (
        Trace as ProtoTrace, TraceInfo as ProtoTraceInfo,
        TraceLocation as ProtoTraceLocation,
    )
    from google.protobuf.timestamp_pb2 import Timestamp

    ts = Timestamp()
    ts.FromMilliseconds(5000000)

    # --- Empty spans, minimal metadata ---
    ptl = ProtoTraceLocation()
    ptl.type = ProtoTraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    ptl.mlflow_experiment.experiment_id = "e1"

    pti = ProtoTraceInfo()
    pti.trace_id = "tid-1"
    pti.trace_location.CopyFrom(ptl)
    pti.request_time.CopyFrom(ts)
    pti.state = ProtoTraceInfo.OK
    pti.trace_metadata["meta1"] = "val1"
    pti.tags["tag1"] = "tval1"

    pt = ProtoTrace()
    pt.trace_info.CopyFrom(pti)

    trace = trace_from_proto(pt, "loc-1")
    check("SR5-B: trace_id", trace.info.trace_id == "tid-1")
    check("SR5-B: metadata", trace.info.trace_metadata["meta1"] == "val1")
    check("SR5-B: tags", trace.info.tags["tag1"] == "tval1")
    check("SR5-B: request_time", trace.info.request_time == 5000000)
    check("SR5-B: state OK", trace.info.state.name == "OK")

    # --- Repeated deserialization is consistent ---
    trace2 = trace_from_proto(pt, "loc-1")
    check("SR5-B: consistent trace_id", trace.info.trace_id == trace2.info.trace_id)


# ============================================================
# SR6: trace_info_to_v4_proto — boundary & F4 path
# ============================================================

def check_sr6_trace_info_to_v4_proto():
    """
    Behavior: Verify None duration, assessments list, UC v4 parsing,
    and F4: TraceInfo.to_proto() works for UC_SCHEMA.
    """
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation, TraceLocation, TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.entities.assessment import Assessment, AssessmentSource
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="u1")
    assessment = Assessment(
        name="a1", trace_id="t1", source=source,
        create_time_ms=1000, last_update_time_ms=2000,
    )

    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="e1"),
    )
    ti = TraceInfo(
        trace_id="tid-1", trace_location=tl, request_time=1000,
        state=TraceState.IN_PROGRESS, assessments=[assessment],
    )
    p = trace_info_to_v4_proto(ti)
    check("SR6-B: assessments count", len(p.assessments) == 1)
    check("SR6-B: assessment name", p.assessments[0].assessment_name == "a1")

    # --- None execution_duration => proto field unset ---
    check("SR6-B: None duration unset", not p.HasField("execution_duration"))

    # --- UC_SCHEMA with v4 trace ID ---
    from mlflow.tracing.utils import construct_trace_id_v4
    v4_tid = construct_trace_id_v4("mycat.mysch", "inner")
    tl_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="mycat", schema_name="mysch"),
    )
    ti_uc = TraceInfo(
        trace_id=v4_tid, trace_location=tl_uc,
        request_time=3000, state=TraceState.OK,
    )
    p_uc = trace_info_to_v4_proto(ti_uc)
    check("SR6-B: UC v4 parsed trace_id", p_uc.trace_id == "inner")

    # --- F4: TraceInfo.to_proto() must work for UC_SCHEMA ---
    try:
        p_method = ti_uc.to_proto()
        check("SR6-B/F4: TraceInfo.to_proto() UC_SCHEMA success", True)
        check("SR6-B/F4: to_proto trace_id", p_method.trace_id == "inner")
    except NameError:
        check("SR6-B/F4: TraceInfo.to_proto() UC_SCHEMA", False,
              "F4: NameError — missing import of trace_info_to_v4_proto")
    except Exception as e:
        check("SR6-B/F4: TraceInfo.to_proto() UC_SCHEMA", False,
              f"Unexpected: {e}")

    # --- Non-UC TraceInfo.to_proto() also works ---
    p_non_uc = ti.to_proto()
    check("SR6-B: to_proto non-UC truthy", p_non_uc.trace_id == "tid-1")


# ============================================================
# SR7: trace_location_from_proto — boundary & error
# ============================================================

def check_sr7_trace_location_from_proto():
    """
    Behavior: Verify unspecified fallback, missing fields, UC with/without
    optional otel table names.
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.entities.trace_location import TraceLocationType
    from mlflow.protos.databricks_tracing_pb2 import (
        TraceLocation as ProtoTL, UCSchemaLocation as ProtoUCSL,
    )

    # --- Unspecified produces TRACE_LOCATION_TYPE_UNSPECIFIED ---
    ptl = ProtoTL()
    ptl.type = ProtoTL.TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED
    loc = trace_location_from_proto(ptl)
    check("SR7-B: unspecified type",
          loc.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    check("SR7-B: unspecified has no uc_schema", loc.uc_schema is None)
    check("SR7-B: unspecified has no mlflow_experiment", loc.mlflow_experiment is None)
    check("SR7-B: unspecified has no inference_table", loc.inference_table is None)

    # --- UC schema with only required fields ---
    ptl_uc = ProtoTL()
    ptl_uc.type = ProtoTL.TraceLocationType.UC_SCHEMA
    ptl_uc.uc_schema.CopyFrom(ProtoUCSL(catalog_name="c", schema_name="s"))
    loc_uc = trace_location_from_proto(ptl_uc)
    check("SR7-B: UC basic catalog", loc_uc.uc_schema.catalog_name == "c")
    check("SR7-B: UC basic schema", loc_uc.uc_schema.schema_name == "s")


# ============================================================
# SR8: trace_location_to_proto — error & boundary
# ============================================================

def check_sr8_trace_location_to_proto():
    """
    Behavior: Verify ValueError on unsupported type, round-tripping
    for all three supported types.
    """
    from mlflow.utils.databricks_tracing_utils import (
        trace_location_to_proto, trace_location_from_proto,
    )
    from mlflow.entities.trace_location import (
        InferenceTableLocation, MlflowExperimentLocation,
        TraceLocation, TraceLocationType, UCSchemaLocation,
    )

    # --- ValueError on unspecified ---
    loc_unspec = TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    try:
        trace_location_to_proto(loc_unspec)
        check("SR8-B: ValueError on unspecified", False)
    except ValueError as e:
        check("SR8-B: ValueError on unspecified", "Unsupported" in str(e))

    # --- Round-trip: UC_SCHEMA ---
    loc_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="rt_cat", schema_name="rt_sch"),
    )
    proto = trace_location_to_proto(loc_uc)
    back = trace_location_from_proto(proto)
    check("SR8-B: UC round-trip type", back.type == TraceLocationType.UC_SCHEMA)
    check("SR8-B: UC round-trip catalog", back.uc_schema.catalog_name == "rt_cat")

    # --- Round-trip: MLFLOW_EXPERIMENT ---
    loc_exp = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="rt_exp"),
    )
    proto_exp = trace_location_to_proto(loc_exp)
    back_exp = trace_location_from_proto(proto_exp)
    check("SR8-B: EXP round-trip type", back_exp.type == TraceLocationType.MLFLOW_EXPERIMENT)
    check("SR8-B: EXP round-trip id",
          back_exp.mlflow_experiment.experiment_id == "rt_exp")

    # --- Round-trip: INFERENCE_TABLE ---
    loc_it = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="rt.cat.sch.tbl"),
    )
    proto_it = trace_location_to_proto(loc_it)
    back_it = trace_location_from_proto(proto_it)
    check("SR8-B: IT round-trip type", back_it.type == TraceLocationType.INFERENCE_TABLE)
    check("SR8-B: IT round-trip name",
          back_it.inference_table.full_table_name == "rt.cat.sch.tbl")


# ============================================================
# SR9: trace_to_proto — conversion
# ============================================================

def check_sr9_trace_to_proto():
    """
    Behavior: Verify trace_to_proto output shape, span list, and
    UC_SCHEMA trace ID parsing path (F1).
    """
    from mlflow.entities import Trace, TraceData, TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation, TraceLocation, TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    from mlflow.tracing.utils import construct_trace_id_v4

    # --- MLFLOW_EXPERIMENT trace with spans list ---
    tl = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="e1"),
    )
    ti = TraceInfo(
        trace_id="trace-9", trace_location=tl,
        request_time=5000, state=TraceState.ERROR,
        trace_metadata={"m1": "v1"}, tags={"t1": "tv1"},
    )
    trace = Trace(info=ti, data=TraceData(spans=[]))
    p = trace_to_proto(trace)
    check("SR9-B: trace_info present", p.HasField("trace_info"))
    check("SR9-B: trace_id", p.trace_info.trace_id == "trace-9")
    check("SR9-B: state ERROR",
          p.trace_info.state == 2)  # ERROR = 2 in proto enum
    check("SR9-B: spans empty", len(p.spans) == 0)

    # --- UC_SCHEMA trace: verify v4 trace ID parsing (F1 path) ---
    v4_tid = construct_trace_id_v4("loc.cat.loc_sch", "deep-id")
    tl_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="loc_cat", schema_name="loc_sch"),
    )
    ti_uc = TraceInfo(
        trace_id=v4_tid, trace_location=tl_uc,
        request_time=6000, state=TraceState.OK,
    )
    trace_uc = Trace(info=ti_uc, data=TraceData(spans=[]))
    p_uc = trace_to_proto(trace_uc)
    check("SR9-B/F1: UC trace_id parsed", p_uc.trace_info.trace_id == "deep-id",
          "F1: UC v4 trace ID must be parsed to inner id")


# ============================================================
# SR10: uc_schema_location_from_proto — boundary
# ============================================================

def check_sr10_uc_schema_location_from_proto():
    """
    Behavior: Verify default table names when proto omits them,
    explicit table names when proto includes them.
    """
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import UCSchemaLocation as ProtoUCSL

    # --- Proto with all fields ---
    proto = ProtoUCSL(
        catalog_name="full_cat", schema_name="full_sch",
        otel_spans_table_name="s_tbl", otel_logs_table_name="l_tbl",
    )
    loc = uc_schema_location_from_proto(proto)
    check("SR10-B: explicit spans", loc._otel_spans_table_name == "s_tbl")
    check("SR10-B: explicit logs", loc._otel_logs_table_name == "l_tbl")

    # --- Proto with only required fields ---
    proto_min = ProtoUCSL(catalog_name="min_cat", schema_name="min_sch")
    loc_min = uc_schema_location_from_proto(proto_min)
    check("SR10-B: min has default spans", loc_min._otel_spans_table_name is not None)
    check("SR10-B: min has default logs", loc_min._otel_logs_table_name is not None)
    check("SR10-B: min spans table is default",
          "mlflow_experiment_trace_otel_spans" in loc_min._otel_spans_table_name)
    check("SR10-B: min logs table is default",
          "mlflow_experiment_trace_otel_logs" in loc_min._otel_logs_table_name)


# ============================================================
# SR11: uc_schema_location_to_proto — conversion
# ============================================================

def check_sr11_uc_schema_location_to_proto():
    """
    Behavior: Verify explicit and default table name handling.
    """
    from mlflow.entities.trace_location import UCSchemaLocation
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto

    # --- Default table names ---
    loc_def = UCSchemaLocation(catalog_name="d_cat", schema_name="d_sch")
    proto_def = uc_schema_location_to_proto(loc_def)
    check("SR11-B: default spans table not empty",
          len(proto_def.otel_spans_table_name) > 0)
    check("SR11-B: default logs table not empty",
          len(proto_def.otel_logs_table_name) > 0)

    # --- Explicit table names ---
    loc_exp = UCSchemaLocation(catalog_name="e_cat", schema_name="e_sch")
    loc_exp._otel_spans_table_name = "my_spans"
    loc_exp._otel_logs_table_name = "my_logs"
    proto_exp = uc_schema_location_to_proto(loc_exp)
    check("SR11-B: explicit spans", proto_exp.otel_spans_table_name == "my_spans")
    check("SR11-B: explicit logs", proto_exp.otel_logs_table_name == "my_logs")

    # --- Round-trip ---
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    back = uc_schema_location_from_proto(proto_exp)
    check("SR11-B: round-trip catalog", back.catalog_name == "e_cat")
    check("SR11-B: round-trip schema", back.schema_name == "e_sch")
    check("SR11-B: round-trip spans", back._otel_spans_table_name == "my_spans")


# ============================================================
# SR12: AssessmentSourceType — deprecation, validation, boundary
# ============================================================

def check_sr12_assessment_source_type():
    """
    Behavior: Verify case normalization, deprecation warnings, validation
    errors, _standardize behavior, and all valid types.
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    # --- All valid types standardize correctly ---
    for inp, expected in [
        ("human", "HUMAN"),
        ("HUMAN", "HUMAN"),
        ("Human", "HUMAN"),
        ("llm_judge", "LLM_JUDGE"),
        ("LLM_JUDGE", "LLM_JUDGE"),
        ("code", "CODE"),
        ("CODE", "CODE"),
        ("source_type_unspecified", "SOURCE_TYPE_UNSPECIFIED"),
        ("SOURCE_TYPE_UNSPECIFIED", "SOURCE_TYPE_UNSPECIFIED"),
    ]:
        result = AssessmentSourceType._standardize(inp)
        check(f"SR12-B: _standardize('{inp}') -> '{expected}'",
              result == expected, f"Got: {result}")

    # --- Deprecation: AI_JUDGE -> LLM_JUDGE ---
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        check("SR12-B: AI_JUDGE -> LLM_JUDGE", result == "LLM_JUDGE")
        check("SR12-B: FutureWarning emitted", len(w) == 1)
        check("SR12-B: warning category", issubclass(w[0].category, FutureWarning))
        check("SR12-B: warning message mentions deprecation",
              "deprecated" in str(w[0].message).lower())

    # --- Also lowercase deprecation ---
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("ai_judge")
        check("SR12-B: ai_judge -> LLM_JUDGE", result == "LLM_JUDGE")
        check("SR12-B: ai_judge emits warning", len(w) == 1)

    # --- Invalid types raise MlflowException ---
    for invalid in ["INVALID", "UNKNOWN", "", "123"]:
        try:
            AssessmentSourceType._standardize(invalid)
            check(f"SR12-B: '{invalid}' raises MlflowException", False)
        except MlflowException as e:
            check(f"SR12-B: '{invalid}' raises MlflowException", True)
            check(f"SR12-B: '{invalid}' error has INVALID_PARAMETER_VALUE",
                  "INVALID_PARAMETER_VALUE" in str(e.error_code))

    # --- Constructor also validates ---
    try:
        AssessmentSourceType("bad_type")
        check("SR12-B: constructor validation", False)
    except MlflowException:
        check("SR12-B: constructor validation", True)

    # --- __str__ returns standardized value ---
    t = AssessmentSourceType("llm_judge")
    check("SR12-B: __str__ returns standardized", str(t) == "LLM_JUDGE")

    # --- Direct constant usage ---
    check("SR12-B: HUMAN constant", AssessmentSourceType.HUMAN == "HUMAN")
    check("SR12-B: LLM_JUDGE constant", AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE")
    check("SR12-B: CODE constant", AssessmentSourceType.CODE == "CODE")
    check("SR12-B: AI_JUDGE constant still exists",
          AssessmentSourceType.AI_JUDGE == "AI_JUDGE")


# ============================================================
# SR13: Span.inputs/outputs — functional behavior (F3)
# ============================================================

def check_sr13_span_inputs_outputs():
    """
    Behavior: Verify functional round-trip of inputs/outputs through
    the full span lifecycle: create -> set -> end -> retrieve.
    Also verify None return for unset values and NoOpSpan behavior.
    """
    from mlflow.entities.span import Span, LiveSpan, NoOpSpan
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

    # --- Setup: OTel tracer with in-memory exporter ---
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    processor = SimpleSpanProcessor(exporter)
    provider.add_span_processor(processor)
    tracer = provider.get_tracer("behavior_test")

    # --- Test 1: Set and retrieve complex inputs/outputs ---
    otel_span = tracer.start_span("complex_span")
    otel_span.set_attribute(
        SpanAttributeKey.INPUTS,
        dump_span_attribute_value({"query": "What is ML?", "params": {"temp": 0.7, "max": 100}}),
    )
    otel_span.set_attribute(
        SpanAttributeKey.OUTPUTS,
        dump_span_attribute_value({"answer": "Machine Learning is...", "tokens": 42}),
    )
    otel_span.end()
    provider.force_flush()

    finished = exporter.get_finished_spans()
    check("SR13-B: span finished", len(finished) >= 1)
    if finished:
        span = Span(finished[-1])
        check("SR13-B: inputs dict", span.inputs == {"query": "What is ML?",
                                                     "params": {"temp": 0.7, "max": 100}})
        check("SR13-B: outputs dict", span.outputs == {"answer": "Machine Learning is...",
                                                       "tokens": 42})

    # --- Test 2: List inputs/outputs ---
    otel_span2 = tracer.start_span("list_span")
    otel_span2.set_attribute(
        SpanAttributeKey.INPUTS, dump_span_attribute_value([1, 2, 3]))
    otel_span2.set_attribute(
        SpanAttributeKey.OUTPUTS, dump_span_attribute_value(["a", "b", "c"]))
    otel_span2.end()
    provider.force_flush()

    finished2 = exporter.get_finished_spans()
    if len(finished2) >= 2:
        span2 = Span(finished2[1])
        check("SR13-B: inputs list", span2.inputs == [1, 2, 3])
        check("SR13-B: outputs list", span2.outputs == ["a", "b", "c"])

    # --- Test 3: None when inputs/outputs not set ---
    otel_span3 = tracer.start_span("empty_span")
    otel_span3.end()
    provider.force_flush()

    finished3 = exporter.get_finished_spans()
    if len(finished3) >= 3:
        span3 = Span(finished3[2])
        check("SR13-B: inputs None when unset", span3.inputs is None)
        check("SR13-B: outputs None when unset", span3.outputs is None)

    # --- Test 4: Scalar values ---
    otel_span4 = tracer.start_span("scalar_span")
    otel_span4.set_attribute(
        SpanAttributeKey.INPUTS, dump_span_attribute_value("simple string input"))
    otel_span4.set_attribute(
        SpanAttributeKey.OUTPUTS, dump_span_attribute_value(42))
    otel_span4.end()
    provider.force_flush()

    finished4 = exporter.get_finished_spans()
    if len(finished4) >= 4:
        span4 = Span(finished4[3])
        check("SR13-B: scalar input", span4.inputs == "simple string input")
        check("SR13-B: scalar output", span4.outputs == 42)

    # --- Test 5: NoOpSpan inputs/outputs ---
    noop = NoOpSpan()
    check("SR13-B: NoOpSpan.inputs", noop.inputs is None)
    check("SR13-B: NoOpSpan.outputs", noop.outputs is None)

    # --- Test 6: Repeated access is consistent (caching) ---
    if finished:
        span = Span(finished[0])
        inp1 = span.inputs
        inp2 = span.inputs
        check("SR13-B: inputs idempotent", inp1 == inp2)


# ============================================================
# Run all checks
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("BEHAVIOR SPEC for MLflow Tracing Utils")
    print("=" * 60)

    check_sr1_assessment_to_proto()
    check_sr2_get_trace_id_from_assessment_proto()
    check_sr3_inference_table_location_to_proto()
    check_sr4_mlflow_experiment_location_to_proto()
    check_sr5_trace_from_proto()
    check_sr6_trace_info_to_v4_proto()
    check_sr7_trace_location_from_proto()
    check_sr8_trace_location_to_proto()
    check_sr9_trace_to_proto()
    check_sr10_uc_schema_location_from_proto()
    check_sr11_uc_schema_location_to_proto()
    check_sr12_assessment_source_type()
    check_sr13_span_inputs_outputs()

    print("=" * 60)
    print(f"RESULTS: {_passed} passed, {_failed} failed")
    print("=" * 60)
    sys.exit(0 if _failed == 0 else 1)
