## static issue

- **`mlflow/entities/trace_info.py`** (1):
  - ? 'trace_info_to_v4_proto' is used but not defined or imported in this file
- **`mlflow/entities/trace_location.py`** (1):
  - ? 'trace_location_from_proto' is used but not defined or imported in this file
- **`mlflow/store/tracking/databricks_rest_store.py`** (5):
  - ? 'assessment_to_proto' is used but not defined or imported in this file
  - ? 'trace_from_proto' is used but not defined or imported in this file
  - ? 'trace_location_to_proto' is used but not defined or imported in this file
  - ? 'uc_schema_location_from_proto' is used but not defined or imported in this file
  - ? 'uc_schema_location_to_proto' is used but not defined or imported in this file
