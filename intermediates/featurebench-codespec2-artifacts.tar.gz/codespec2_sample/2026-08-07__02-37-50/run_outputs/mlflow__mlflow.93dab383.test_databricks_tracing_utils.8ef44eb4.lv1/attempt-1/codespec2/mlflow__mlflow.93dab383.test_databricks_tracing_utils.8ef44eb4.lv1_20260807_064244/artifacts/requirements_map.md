# Subrequirement Map

## SR1
- **Requirement**: `assessment_to_proto` — Convert an Assessment entity to protobuf
- **Task Evidence**: Interface Description 1: `assessment_to_proto(assessment: Assessment) -> pb.Assessment`
- **Architecture Spec**: `check_sr1_assessment_to_proto` — Tests import path, basic serialization, UC schema trace_id parsing, optional fields (span_id, rationale, assessment_id, overrides, valid), metadata stringification, timestamp conversion, expectation vs feedback mutual exclusion, empty-string overrides (F2)
- **Behavior Spec**: `check_sr1_assessment_to_proto` — Tests all-optional-None, overrides="" vs overrides=None (F2), valid=True/False, metadata non-string type conversion, timestamp precision round-trip, expectation/feedback mutual exclusivity
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.assessment_to_proto` → `parse_trace_id_v4` → pb.Assessment construction
- **Expected Intermediate State**: Assessment fields extracted and validated
- **Expected Final Output**: pb.Assessment with all fields mapped, UC schema trace_location when applicable, metadata values stringified
- **Observability**: Direct proto field inspection (assessment_name, trace_id, span_id, create_time, last_update_time, source, expectation, feedback, metadata, overrides, valid, trace_location)
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:164` `assessment_to_proto`; `/testbed/mlflow/entities/assessment.py:117` `Assessment.to_proto`; `/testbed/mlflow/tracing/utils/__init__.py` `parse_trace_id_v4`
- **Architecture Check**: `check_sr1_assessment_to_proto`
- **Behavior Check**: `check_sr1_assessment_to_proto`

## SR2
- **Requirement**: `get_trace_id_from_assessment_proto` — Extract trace ID from assessment proto
- **Task Evidence**: Interface Description 1: `get_trace_id_from_assessment_proto(proto: pb.Assessment | assessments_pb2.Assessment) -> str`
- **Architecture Spec**: `check_sr2_get_trace_id_from_assessment_proto` — Tests plain assessments_pb2 (no trace_location), databricks_tracing_pb2 with UC schema, databricks_tracing_pb2 with non-UC trace_location
- **Behavior Spec**: `check_sr2_get_trace_id_from_assessment_proto` — Tests idempotency, UC v4 prefix construction, non-UC raw trace_id return
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.get_trace_id_from_assessment_proto` → `trace_location` field check → `construct_trace_id_v4` (for UC) or raw `proto.trace_id`
- **Expected Intermediate State**: Proto type and trace_location field detected
- **Expected Final Output**: v4 trace_id string for UC schema; raw trace_id otherwise
- **Observability**: Returned trace_id string, v4 prefix presence
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:201` `get_trace_id_from_assessment_proto`; `/testbed/mlflow/entities/assessment.py:288,426` caller usage in `from_proto`
- **Architecture Check**: `check_sr2_get_trace_id_from_assessment_proto`
- **Behavior Check**: `check_sr2_get_trace_id_from_assessment_proto`

## SR3
- **Requirement**: `inference_table_location_to_proto` — Convert InferenceTableLocation to proto
- **Task Evidence**: Interface Description 1: `inference_table_location_to_proto(inference_table_location: InferenceTableLocation) -> pb.InferenceTableLocation`
- **Architecture Spec**: `check_sr3_inference_table_location_to_proto` — Tests full_table_name mapping, proto type verification
- **Behavior Spec**: `check_sr3_inference_table_location_to_proto` — Tests idempotency, empty string, special characters
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.inference_table_location_to_proto` → `pb.InferenceTableLocation(full_table_name=...)`
- **Expected Intermediate State**: InferenceTableLocation attribute extraction
- **Expected Final Output**: pb.InferenceTableLocation with full_table_name
- **Observability**: Proto full_table_name field
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:55`; `/testbed/mlflow/entities/trace_location.py:63` `InferenceTableLocation.to_proto`
- **Architecture Check**: `check_sr3_inference_table_location_to_proto`
- **Behavior Check**: `check_sr3_inference_table_location_to_proto`

## SR4
- **Requirement**: `mlflow_experiment_location_to_proto` — Convert MlflowExperimentLocation to proto
- **Task Evidence**: Interface Description 1: `mlflow_experiment_location_to_proto(mlflow_experiment_location: MlflowExperimentLocation) -> pb.MlflowExperimentLocation`
- **Architecture Spec**: `check_sr4_mlflow_experiment_location_to_proto` — Tests experiment_id mapping, proto type
- **Behavior Spec**: `check_sr4_mlflow_experiment_location_to_proto` — Tests numeric id, UUID id, idempotency
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.mlflow_experiment_location_to_proto` → `pb.MlflowExperimentLocation(experiment_id=...)`
- **Expected Intermediate State**: MlflowExperimentLocation attribute extraction
- **Expected Final Output**: pb.MlflowExperimentLocation with experiment_id
- **Observability**: Proto experiment_id field
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:61`; `/testbed/mlflow/entities/trace_location.py:47` `MlflowExperimentLocation.to_proto`
- **Architecture Check**: `check_sr4_mlflow_experiment_location_to_proto`
- **Behavior Check**: `check_sr4_mlflow_experiment_location_to_proto`

## SR5
- **Requirement**: `trace_from_proto` — Convert proto Trace to Trace entity
- **Task Evidence**: Interface Description 1: `trace_from_proto(proto: pb.Trace, location_id: str) -> Trace`
- **Architecture Spec**: `check_sr5_trace_from_proto` — Tests import path through TraceInfo.from_proto, empty spans, metadata, tags, state propagation
- **Behavior Spec**: `check_sr5_trace_from_proto` — Tests trace_id, metadata, tags, request_time, state, repeated deserialization consistency
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.trace_from_proto` → `TraceInfo.from_proto` → `Span.from_otel_proto`
- **Expected Intermediate State**: Proto fields deserialized into TraceInfo and Span list
- **Expected Final Output**: Trace entity with info and data (spans)
- **Observability**: Trace.info fields (trace_id, metadata, tags, state, request_time), Trace.data.spans list
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:139` `trace_from_proto`; `/testbed/mlflow/entities/trace_info.py:124` `TraceInfo.from_proto`
- **Architecture Check**: `check_sr5_trace_from_proto`
- **Behavior Check**: `check_sr5_trace_from_proto`

## SR6
- **Requirement**: `trace_info_to_v4_proto` — Convert TraceInfo to v4 proto
- **Task Evidence**: Interface Description 1: `trace_info_to_v4_proto(trace_info: TraceInfo) -> pb.TraceInfo`
- **Architecture Spec**: `check_sr6_trace_info_to_v4_proto` — Tests non-UC and UC_SCHEMA locations, v4 trace_id parsing, None duration, timestamps, UC_SCHEMA TraceInfo.to_proto() delegation (F4)
- **Behavior Spec**: `check_sr6_trace_info_to_v4_proto` — Tests assessments list, None duration proto field, v4 parsing, TraceInfo.to_proto() for UC_SCHEMA (F4), non-UC to_proto()
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.trace_info_to_v4_proto` → `trace_location_to_proto` → `assessment_to_proto` → `parse_trace_id_v4`; also `TraceInfo.to_proto()` lazy import path (F4)
- **Expected Intermediate State**: TraceInfo fields mapped, trace_id parsed for UC_SCHEMA
- **Expected Final Output**: pb.TraceInfo with all fields, v4-parsed trace_id, assessments as proto
- **Observability**: Proto trace_id (parsed for UC), timestamps, state, assessments count, execution_duration field presence
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:99` `trace_info_to_v4_proto`; `/testbed/mlflow/entities/trace_info.py:97` `TraceInfo.to_proto` (lazy import of trace_info_to_v4_proto)
- **Architecture Check**: `check_sr6_trace_info_to_v4_proto`
- **Behavior Check**: `check_sr6_trace_info_to_v4_proto`

## SR7
- **Requirement**: `trace_location_from_proto` — Convert proto TraceLocation to entity
- **Task Evidence**: Interface Description 1: `trace_location_from_proto(proto: pb.TraceLocation) -> TraceLocation`
- **Architecture Spec**: `check_sr7_trace_location_from_proto` — Tests UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE, and unspecified fallback
- **Behavior Spec**: `check_sr7_trace_location_from_proto` — Tests unspecified returns TRACE_LOCATION_TYPE_UNSPECIFIED with all sub-locations None, UC schema with only required fields
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.trace_location_from_proto` → `WhichOneof("identifier")` dispatch → `uc_schema_location_from_proto` or `MlflowExperimentLocation.from_proto` or `InferenceTableLocation.from_proto`
- **Expected Intermediate State**: Proto type and identifier field identified
- **Expected Final Output**: TraceLocation entity with correct type and sub-location
- **Observability**: TraceLocation type, sub-location attributes (catalog_name, experiment_id, full_table_name)
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:81` `trace_location_from_proto`; `/testbed/mlflow/entities/trace_location.py:244` `TraceLocation.from_proto` (lazy import)
- **Architecture Check**: `check_sr7_trace_location_from_proto`
- **Behavior Check**: `check_sr7_trace_location_from_proto`

## SR8
- **Requirement**: `trace_location_to_proto` — Convert TraceLocation to proto
- **Task Evidence**: Interface Description 1: `trace_location_to_proto(trace_location: TraceLocation) -> pb.TraceLocation`
- **Architecture Spec**: `check_sr8_trace_location_to_proto` — Tests UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE, ValueError on unspecified
- **Behavior Spec**: `check_sr8_trace_location_to_proto` — Tests ValueError on unspecified with message, round-trip for all three types
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.trace_location_to_proto` → type dispatch → `uc_schema_location_to_proto` / `mlflow_experiment_location_to_proto` / `inference_table_location_to_proto`
- **Expected Intermediate State**: TraceLocation type determined
- **Expected Final Output**: pb.TraceLocation with correct type enum and sub-location proto
- **Observability**: Proto type enum, HasField checks for sub-locations, sub-location field values
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:65` `trace_location_to_proto`; `/testbed/mlflow/entities/trace_location.py:228` `TraceLocation.to_proto`
- **Architecture Check**: `check_sr8_trace_location_to_proto`
- **Behavior Check**: `check_sr8_trace_location_to_proto`

## SR9
- **Requirement**: `trace_to_proto` — Convert Trace to proto
- **Task Evidence**: Interface Description 1: `trace_to_proto(trace: Trace) -> pb.Trace`
- **Architecture Spec**: `check_sr9_trace_to_proto` — Tests MLFLOW_EXPERIMENT trace, UC_SCHEMA trace with v4 trace_id parsing (F1 path verification)
- **Behavior Spec**: `check_sr9_trace_to_proto` — Tests trace_info presence, state numeric value, empty spans, UC v4 trace_id parsing (F1)
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.trace_to_proto` → `trace_info_to_v4_proto(trace.info)` or `trace.info.to_proto()` → span `to_otel_proto()`
- **Expected Intermediate State**: TraceInfo and spans converted
- **Expected Final Output**: pb.Trace with trace_info and spans list
- **Observability**: Proto trace_info.trace_id (parsed for UC), state proto enum value, spans count
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:128` `trace_to_proto`; `/testbed/mlflow/entities/trace_info.py:97` `TraceInfo.to_proto`
- **Architecture Check**: `check_sr9_trace_to_proto`
- **Behavior Check**: `check_sr9_trace_to_proto`
- **Uncertainties**: F1 — interface spec says "The trace info is converted using the trace's built-in to_proto() method" but current implementation calls `trace_info_to_v4_proto` directly. Both paths converge; spec tests verify output correctness for UC_SCHEMA trace.

## SR10
- **Requirement**: `uc_schema_location_from_proto` — Convert proto UCSchemaLocation to entity
- **Task Evidence**: Interface Description 1: `uc_schema_location_from_proto(proto: pb.UCSchemaLocation) -> UCSchemaLocation`
- **Architecture Spec**: `check_sr10_uc_schema_location_from_proto` — Tests with and without OTel table names in proto
- **Behavior Spec**: `check_sr10_uc_schema_location_from_proto` — Tests explicit table names, default table names when omitted, default table name content
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.uc_schema_location_from_proto` → `UCSchemaLocation(catalog_name, schema_name)` → `HasField` checks for otel table names
- **Expected Intermediate State**: Proto fields read, HasField checks performed
- **Expected Final Output**: UCSchemaLocation entity with catalog_name, schema_name, optional _otel_spans_table_name, _otel_logs_table_name
- **Observability**: Entity catalog_name, schema_name, _otel_spans_table_name, _otel_logs_table_name
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:37` `uc_schema_location_from_proto`; `/testbed/mlflow/entities/trace_location.py:87` `UCSchemaLocation`
- **Architecture Check**: `check_sr10_uc_schema_location_from_proto`
- **Behavior Check**: `check_sr10_uc_schema_location_from_proto`

## SR11
- **Requirement**: `uc_schema_location_to_proto` — Convert UCSchemaLocation to proto
- **Task Evidence**: Interface Description 1: `uc_schema_location_to_proto(uc_schema_location: UCSchemaLocation) -> pb.UCSchemaLocation`
- **Architecture Spec**: `check_sr11_uc_schema_location_to_proto` — Tests explicit table names, default table names
- **Behavior Spec**: `check_sr11_uc_schema_location_to_proto` — Tests default table names are non-empty, explicit table names, round-trip with from_proto
- **Critical Path**: `mlflow.utils.databricks_tracing_utils.uc_schema_location_to_proto` → `pb.UCSchemaLocation(catalog_name, schema_name, otel_spans_table_name, otel_logs_table_name)`
- **Expected Intermediate State**: UCSchemaLocation private attributes accessed
- **Expected Final Output**: pb.UCSchemaLocation with all four fields
- **Observability**: Proto catalog_name, schema_name, otel_spans_table_name, otel_logs_table_name
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py:28` `uc_schema_location_to_proto`
- **Architecture Check**: `check_sr11_uc_schema_location_to_proto`
- **Behavior Check**: `check_sr11_uc_schema_location_to_proto`

## SR12
- **Requirement**: `AssessmentSourceType` — Enumeration and validator for assessment source types
- **Task Evidence**: Interface Description 2: `AssessmentSourceType` class with `_standardize`, constants, deprecation handling
- **Architecture Spec**: `check_sr12_assessment_source_type` — Tests constants are strings, _SOURCE_TYPES excludes AI_JUDGE, __init__ case-insensitive, _standardize, deprecation warning, invalid type MlflowException
- **Behavior Spec**: `check_sr12_assessment_source_type` — Tests all valid input normalizations, deprecation (AI_JUDGE + ai_judge), invalid types (INVALID, UNKNOWN, "", "123"), constructor validation, __str__, direct constant access
- **Critical Path**: `mlflow.entities.assessment_source.AssessmentSourceType._standardize` → `AssessmentSourceType(source_type)` → `_parse` → case normalization → deprecation mapping → validation → `__str__`
- **Expected Intermediate State**: Input normalized to uppercase, deprecated value mapped
- **Expected Final Output**: Standardized uppercase string; MlflowException for invalid types
- **Observability**: Returned string values, warning emission, exception type and error code
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py:118` `AssessmentSourceType` class; `/testbed/mlflow/entities/assessment_source.py:70` `AssessmentSource.__post_init__` caller
- **Architecture Check**: `check_sr12_assessment_source_type`
- **Behavior Check**: `check_sr12_assessment_source_type`

## SR13
- **Requirement**: `Span.inputs` and `Span.outputs` — Property access for span input/output values
- **Task Evidence**: Interface Description 3: `Span.inputs -> Any`, `Span.outputs -> Any` with "Returns None if no inputs/outputs were set"
- **Architecture Spec**: `check_sr13_span_inputs_outputs` — Tests structural existence (hasattr, is property), functional round-trip via OTel span (set attribute → end → Span → retrieve), None when unset, NoOpSpan
- **Behavior Spec**: `check_sr13_span_inputs_outputs` — Tests complex dict inputs/outputs, list inputs/outputs, None when unset, scalar values (string, int), NoOpSpan None, idempotent repeated access
- **Critical Path**: `Span.inputs` → `get_attribute(SpanAttributeKey.INPUTS)` → `_CachedSpanAttributesRegistry.get` → JSON deserialization; `Span.outputs` → `get_attribute(SpanAttributeKey.OUTPUTS)` → JSON deserialization
- **Expected Intermediate State**: OTel span attribute read and JSON-deserialized
- **Expected Final Output**: Original Python value (dict, list, scalar) or None if unset
- **Observability**: Returned values match original input, None for unset attributes
- **Repository Evidence**: `/testbed/mlflow/entities/span.py:179-187` `Span.inputs` and `Span.outputs` properties; `/testbed/mlflow/entities/span.py:529-535` `LiveSpan.set_inputs`/`set_outputs`; `/testbed/mlflow/tracing/constant.py:59-60` `SpanAttributeKey.INPUTS`/`OUTPUTS`
- **Architecture Check**: `check_sr13_span_inputs_outputs`
- **Behavior Check**: `check_sr13_span_inputs_outputs`

## Static Issues (out of scope but noted)

- `/testbed/mlflow/entities/trace_info.py:103`: `trace_info_to_v4_proto` used but not imported — **Addressed by SR6 spec test** exercising `TraceInfo.to_proto()` for UC_SCHEMA
- `/testbed/mlflow/entities/trace_location.py:244`: `trace_location_from_proto` used but not imported — Already has lazy import in `TraceLocation.from_proto`
- `/testbed/mlflow/store/tracking/databricks_rest_store.py`: Five functions used without imports — **Out of scope** for this spec; caller module not part of interface descriptions
