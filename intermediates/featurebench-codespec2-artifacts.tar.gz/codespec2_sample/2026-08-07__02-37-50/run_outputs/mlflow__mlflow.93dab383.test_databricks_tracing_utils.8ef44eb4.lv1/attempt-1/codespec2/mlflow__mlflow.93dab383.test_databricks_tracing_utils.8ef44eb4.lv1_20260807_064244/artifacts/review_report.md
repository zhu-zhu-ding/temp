# Review Report

- Status: approved

## Findings

- None

## Coverage

| Subrequirement | Arch Check | Behavior Check | Observable | Notes |
|---|---|---|---|---|
| SR1 (`assessment_to_proto`) | PASS | PASS | Yes | F2 fixed: `is not None` check for overrides, empty-string test added. Timestamps, metadata stringification, UC schema parsing, expectation/feedback mutual exclusion all verified. |
| SR2 (`get_trace_id_from_assessment_proto`) | PASS | PASS | Yes | Plain proto, UC schema proto (v4 prefix), non-UC trace_location all tested. Idempotency verified. |
| SR3 (`inference_table_location_to_proto`) | PASS | PASS | Yes | full_table_name mapping, empty string, special characters all tested. |
| SR4 (`mlflow_experiment_location_to_proto`) | PASS | PASS | Yes | experiment_id mapping, numeric/UUID ids, idempotency all tested. |
| SR5 (`trace_from_proto`) | PASS | PASS | Yes | Empty spans, metadata, tags, state, request_time all verified. Repeated deserialization consistency tested. |
| SR6 (`trace_info_to_v4_proto`) | PASS | PASS | Yes | F4 fixed: lazy import in `trace_info.py`. UC v4 parsing, timestamps, None/Some duration, assessments all verified. `TraceInfo.to_proto()` UC_SCHEMA path tested and passes. |
| SR7 (`trace_location_from_proto`) | PASS | PASS | Yes | All three location types, unspecified fallback, no extraneous fields verified. |
| SR8 (`trace_location_to_proto`) | PASS | PASS | Yes | All three types, ValueError on unspecified, round-trip all types verified. |
| SR9 (`trace_to_proto`) | PASS | PASS | Yes | Output shape, span list, UC_SCHEMA trace ID parsing all verified. F1 note: `trace_to_proto` calls `trace_info_to_v4_proto` directly rather than `trace.info.to_proto()`. Both paths converge on equivalent output; the interface doc note about "built-in to_proto()" is advisory, not a functional requirement. |
| SR10 (`uc_schema_location_from_proto`) | PASS | PASS | Yes | With and without OTel table names tested. Default table name content verified. |
| SR11 (`uc_schema_location_to_proto`) | PASS | PASS | Yes | Explicit and default table names, round-trip with from_proto all verified. |
| SR12 (`AssessmentSourceType`) | PASS | PASS | Yes | String constants confirmed (not dicts). Case-insensitive validation, AI_JUDGE deprecation with FutureWarning, invalid type MlflowException with INVALID_PARAMETER_VALUE, _SOURCE_TYPES excludes AI_JUDGE, __str__ returns standardized value, constructor validation all tested. |
| SR13 (`Span.inputs/outputs`) | PASS | PASS | Yes | F3 fixed: functional round-trip tests now verify create → set → end → retrieve for complex dicts, lists, scalars. None for unset, NoOpSpan None, idempotent access all tested. |

## Risk Focus

1. **`databricks_rest_store.py` missing imports** (static issue, out of scope): Five functions (`trace_from_proto`, `trace_location_to_proto`, `uc_schema_location_to_proto`, `uc_schema_location_from_proto`, `assessment_to_proto`) are used at lines 189, 290, 294, 412, 422, 434, 451, 511, 558 without being imported. Any runtime code path through these methods will raise `NameError`. This is outside the current interface descriptions' scope but flagged in static analysis. It should be addressed by adding proper imports.

2. **Pre-existing test `test_assessment_value_validation` fails**: The test in `tests/entities/test_assessment.py` expects `Assessment(**common_args)` (with neither expectation nor feedback) to raise `MlflowException`, but the current `Assessment.__post_init__` only validates the mutual-exclusion case (`> 1`), not the neither-specified case (`< 1`). This is outside the interface descriptions' scope (Assessment entity validation, not tracing utils, assessment source type, or span properties).

3. **`trace_to_proto` delegation path**: The function calls `trace_info_to_v4_proto(trace.info)` directly rather than `trace.info.to_proto()`. Both paths produce equivalent output for all tested scenarios (UC_SCHEMA v4 and MLFLOW_EXPERIMENT with assessments). The divergence is cosmetic as long as both paths remain synchronized. Verified with cross-comparison of output protos.

## Spec Actions

None required. All 13 subrequirements have passing architecture and behavior checks. The three previously-identified issues (F2 overrides truthiness, F3 span functional tests, F4 missing lazy import) have been resolved in the current implementation and verified by updated specs.

For out-of-scope concerns:
- `databricks_rest_store.py` should add `from mlflow.utils.databricks_tracing_utils import (trace_from_proto, trace_location_to_proto, uc_schema_location_to_proto, uc_schema_location_from_proto, assessment_to_proto)` at the top of the file.
- `test_assessment_value_validation` should be investigated to determine whether the test or the `Assessment.__post_init__` needs updating to match the intended specification for the neither-expectation-nor-feedback case.
