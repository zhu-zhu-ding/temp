#!/usr/bin/env python3
"""
Architecture spec for MLflow Data Validation System.

Exercises real public input -> caller/import -> helper/dispatcher -> observable
result paths for all four subrequirements.

Usage: python arch_spec.py
Exits 0 on success, nonzero on failure.
"""

import inspect
import os
import sys
import warnings

# Ensure /testbed is on sys.path
sys.path.insert(0, "/testbed")

import mlflow
import pandas as pd
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers import scorer
from mlflow.genai.scorers.base import Scorer, ScorerKind
from mlflow.genai.scorers.builtin_scorers import (
    BuiltInScorer,
    Correctness,
    Equivalence,
    ExpectationsGuidelines,
    MissingColumnsException,
    RelevanceToQuery,
    RetrievalGroundedness,
    RetrievalRelevance,
    RetrievalSufficiency,
    Safety,
    get_all_scorers,
)
from mlflow.genai.scorers.validation import (
    valid_data_for_builtin_scorers,
    validate_scorers,
)


def check_sr1_arch():
    """SR-1: scorer decorator — architecture integration path."""
    print("--- check_sr1_arch ---")

    # --- Test 1: bare @scorer decorator ---
    @scorer
    def my_scorer(inputs, outputs):
        return len(outputs) > 0

    # Verify returned object is a Scorer instance
    assert isinstance(my_scorer, Scorer), "Decorated function should be a Scorer instance"
    assert my_scorer.name == "my_scorer", f"Expected 'my_scorer', got {my_scorer.name!r}"
    assert my_scorer.kind == ScorerKind.DECORATOR, f"Expected DECORATOR, got {my_scorer.kind}"

    # Inspect the unbound __call__ on the class (not the bound instance method)
    # Lesson L-1: bound methods strip 'self' in CPython 3.11
    call_sig = inspect.signature(type(my_scorer).__call__)
    param_names = list(call_sig.parameters.keys())
    assert param_names[0] == "self", f"First param should be 'self', got {param_names}"
    assert "inputs" in param_names, f"'inputs' should be in signature, got {param_names}"
    assert "outputs" in param_names, f"'outputs' should be in signature, got {param_names}"
    assert "expectations" not in param_names, f"'expectations' should not be in signature"
    assert "trace" not in param_names, f"'trace' should not be in signature"

    # Test calling the scorer
    result = my_scorer(inputs="hello", outputs="world")
    assert result is True, f"Expected True, got {result!r}"

    # Extra kwargs should be silently ignored
    result2 = my_scorer(inputs="hello", outputs="world", extra_thing=42, trace=None)
    assert result2 is True, f"Expected True with extra kwargs, got {result2!r}"

    # --- Test 2: @scorer with name and description ---
    @scorer(name="custom_name", description="A test scorer")
    def another_scorer(outputs):
        return float(len(outputs))

    assert isinstance(another_scorer, Scorer)
    assert another_scorer.name == "custom_name"
    assert another_scorer.description == "A test scorer"
    assert another_scorer.kind == ScorerKind.DECORATOR

    call_sig2 = inspect.signature(type(another_scorer).__call__)
    param_names2 = list(call_sig2.parameters.keys())
    assert param_names2[0] == "self"
    assert "outputs" in param_names2
    assert "inputs" not in param_names2

    result3 = another_scorer(outputs="hello world")
    assert result3 == 11.0, f"Expected 11.0, got {result3!r}"

    # --- Test 3: @scorer with aggregations ---
    @scorer(aggregations=["min", "max"])
    def third_scorer(inputs):
        return len(str(inputs))

    assert third_scorer.aggregations == ["min", "max"]

    # --- Test 4: scorer used as function call (not decorator) ---
    def plain_func(inputs, outputs, expectations, trace):
        return "yes"

    wrapped = scorer(plain_func)
    assert isinstance(wrapped, Scorer)
    assert wrapped.name == "plain_func"
    assert wrapped.kind == ScorerKind.DECORATOR

    call_sig3 = inspect.signature(type(wrapped).__call__)
    param_names3 = list(call_sig3.parameters.keys())
    assert param_names3[0] == "self"
    assert "inputs" in param_names3
    assert "outputs" in param_names3
    assert "expectations" in param_names3
    assert "trace" in param_names3

    result4 = wrapped(inputs="q", outputs="a", expectations={}, trace=None)
    assert result4 == "yes"

    # --- Test 5: _original_func is stored ---
    assert hasattr(wrapped, "_original_func")
    assert wrapped._original_func is plain_func

    print("PASS: check_sr1_arch")


def check_sr2_arch():
    """SR-2: valid_data_for_builtin_scorers — architecture integration path."""
    print("--- check_sr2_arch ---")

    # --- Test 1: Valid data with inputs/outputs ---
    df = pd.DataFrame({
        "inputs": ["What is MLflow?"],
        "outputs": ["MLflow is an open-source platform for ML"],
    })
    scorers_list = [Correctness(name="correctness")]
    # Should not raise
    valid_data_for_builtin_scorers(df, scorers_list)
    print("  Test 1 (valid data) passed")

    # --- Test 2: Empty scorers list ---
    valid_data_for_builtin_scorers(df, [])
    print("  Test 2 (empty scorers) passed")

    # --- Test 3: Column mapping request -> inputs ---
    df2 = pd.DataFrame({
        "request": ["What is MLflow?"],
        "outputs": ["MLflow is an open-source platform"],
    })
    # Should not raise (request maps to inputs)
    valid_data_for_builtin_scorers(df2, scorers_list)
    print("  Test 3 (request->inputs mapping) passed")

    # --- Test 4: Column mapping response -> outputs ---
    df3 = pd.DataFrame({
        "inputs": ["What is MLflow?"],
        "response": ["MLflow is an open-source platform"],
    })
    valid_data_for_builtin_scorers(df3, scorers_list)
    print("  Test 4 (response->outputs mapping) passed")

    # --- Test 5: predict_fn suppresses need for outputs ---
    df4 = pd.DataFrame({
        "inputs": ["What is MLflow?"],
    })
    valid_data_for_builtin_scorers(df4, scorers_list, predict_fn=lambda x: "prediction")
    print("  Test 5 (predict_fn) passed")

    # --- Test 6: trace column implies inputs+outputs ---
    with mlflow.start_span(name="test") as span:
        span.set_inputs({"q": "test"})
        span.set_outputs({"a": "answer"})
    trace = mlflow.get_trace(span.trace_id)
    df5 = pd.DataFrame({"trace": [trace]})
    # trace should imply inputs+outputs
    valid_data_for_builtin_scorers(df5, scorers_list)
    print("  Test 6 (trace inference) passed")

    # --- Test 7: expectations explosion ---
    from mlflow.genai.scorers.builtin_scorers import ExpectationsGuidelines
    df6 = pd.DataFrame({
        "inputs": ["What is MLflow?"],
        "outputs": ["MLflow platform"],
        "expectations": [{"guidelines": ["Be concise"]}],
    })
    # ExpectationsGuidelines requires expectations/guidelines
    valid_data_for_builtin_scorers(df6, [ExpectationsGuidelines(name="exp_guide")])
    print("  Test 7 (expectations explosion) passed")

    # --- Test 8: Missing columns are logged (not raised) ---
    df7 = pd.DataFrame({"inputs": ["test"]})
    # Correctness requires outputs — should log info, not raise
    valid_data_for_builtin_scorers(df7, [Correctness(name="correctness")])
    print("  Test 8 (missing columns logged) passed")

    # --- Test 9: Non-dict expectations raises MlflowException ---
    df8 = pd.DataFrame({
        "inputs": ["test"],
        "outputs": ["test"],
        "expectations": ["not a dict"],
    })
    try:
        valid_data_for_builtin_scorers(df8, [ExpectationsGuidelines(name="exp_guide")])
        assert False, "Should have raised MlflowException"
    except MlflowException:
        print("  Test 9 (non-dict expectations raises) passed")

    print("PASS: check_sr2_arch")


def check_sr3_arch():
    """SR-3: validate_scorers — architecture integration path."""
    print("--- check_sr3_arch ---")

    # --- Test 1: Valid scorers pass through ---
    scorers = [
        Correctness(name="c1"),
        RelevanceToQuery(name="rq1"),
    ]
    result = validate_scorers(scorers)
    assert len(result) == 2
    assert all(isinstance(s, Scorer) for s in result)
    assert result[0].name == "c1"
    assert result[1].name == "rq1"
    print("  Test 1 (valid scorers) passed")

    # --- Test 2: Empty list ---
    result2 = validate_scorers([])
    assert result2 == []
    print("  Test 2 (empty list) passed")

    # --- Test 3: Class instead of instance raises with hint ---
    try:
        validate_scorers([Correctness])
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        msg = str(e)
        assert "Expected an instance" in msg, f"Wrong message: {msg}"
        assert "Correctness()" in msg or "Correctness" in msg
        print(f"  Test 3 (class-instead-of-instance) passed: {msg[:80]}...")

    # --- Test 4: Nested list raises with hint ---
    try:
        validate_scorers([[Correctness(name="c1")]])
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        msg = str(e)
        assert "nested list" in msg.lower() or "get_all_scorers" in msg, f"Wrong message: {msg}"
        print(f"  Test 4 (nested list) passed: {msg[:80]}...")

    # --- Test 5: Non-list raises ---
    try:
        validate_scorers(Correctness(name="c1"))
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        msg = str(e)
        assert "list" in msg.lower(), f"Wrong message: {msg}"
        print(f"  Test 5 (non-list) passed: {msg[:80]}...")

    # --- Test 6: @scorer decorator instances ---
    @scorer
    def custom_s(inputs, outputs):
        return True

    result3 = validate_scorers([custom_s])
    assert len(result3) == 1
    assert result3[0] is custom_s
    print("  Test 6 (decorator scorer) passed")

    print("PASS: check_sr3_arch")


def check_sr4_arch():
    """SR-4: get_all_scorers — architecture integration path."""
    print("--- check_sr4_arch ---")

    # Save current URI
    old_uri = mlflow.get_tracking_uri()

    # --- Test 1: OSS URI — 6 scorers ---
    mlflow.set_tracking_uri("")
    scorers = get_all_scorers()
    assert len(scorers) == 6, f"Expected 6 OSS scorers, got {len(scorers)}"
    assert all(isinstance(s, Scorer) for s in scorers)
    assert all(isinstance(s, BuiltInScorer) for s in scorers)

    expected_names = {
        "ExpectationsGuidelines",
        "Correctness",
        "RelevanceToQuery",
        "RetrievalSufficiency",
        "RetrievalGroundedness",
        "Equivalence",
    }
    actual_names = {s.name for s in scorers}
    assert expected_names == actual_names, f"Names mismatch: {actual_names}"
    print("  Test 1 (OSS 6 scorers) passed")

    # --- Test 2: No Safety or RetrievalRelevance under OSS ---
    for s in scorers:
        assert not isinstance(s, Safety), f"Safety should not be in OSS scorers"
        assert not isinstance(s, RetrievalRelevance), f"RetrievalRelevance should not be in OSS"
    print("  Test 2 (no Databricks-only scorers) passed")

    # --- Test 3: Databricks URI — 8 scorers ---
    mlflow.set_tracking_uri("databricks")
    scorers_db = get_all_scorers()
    assert len(scorers_db) == 8, f"Expected 8 Databricks scorers, got {len(scorers_db)}"
    assert all(isinstance(s, Scorer) for s in scorers_db)
    has_safety = any(isinstance(s, Safety) for s in scorers_db)
    has_retrieval_relevance = any(isinstance(s, RetrievalRelevance) for s in scorers_db)
    assert has_safety, "Safety should be in Databricks scorers"
    assert has_retrieval_relevance, "RetrievalRelevance should be in Databricks scorers"
    print("  Test 3 (Databricks 8 scorers) passed")

    # --- Test 4: Fresh instances per call ---
    scorers2 = get_all_scorers()
    # Different instances (not the same objects)
    for s1, s2 in zip(scorers_db, scorers2):
        assert s1 is not s2, f"Scorer {s1.name} should be a fresh instance, got same object"
    print("  Test 4 (fresh instances) passed")

    # --- Test 5: Idempotent count ---
    scorers3 = get_all_scorers()
    assert len(scorers3) == len(scorers_db)
    print("  Test 5 (idempotent count) passed")

    # Restore URI
    mlflow.set_tracking_uri(old_uri)
    print("PASS: check_sr4_arch")


def main():
    check_sr1_arch()
    check_sr2_arch()
    check_sr3_arch()
    check_sr4_arch()
    print("\nAll architecture checks passed.")


if __name__ == "__main__":
    main()
