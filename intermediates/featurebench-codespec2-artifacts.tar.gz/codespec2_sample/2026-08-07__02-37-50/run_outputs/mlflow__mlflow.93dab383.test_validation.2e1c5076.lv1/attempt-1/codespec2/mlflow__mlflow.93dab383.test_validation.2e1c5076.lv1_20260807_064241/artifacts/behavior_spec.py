#!/usr/bin/env python3
"""
Behavior spec for MLflow Data Validation System.

Tests state transitions, input/output, boundary/error, conversion,
compatibility, and repeated-call behavior for all four subrequirements.

Usage: python behavior_spec.py
Exits 0 on success, nonzero on failure.
"""

import inspect
import logging
import os
import sys
import warnings

sys.path.insert(0, "/testbed")

import mlflow
import pandas as pd
from mlflow.entities import AssessmentSource, Feedback
from mlflow.entities.assessment import DEFAULT_FEEDBACK_NAME
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers import scorer
from mlflow.genai.scorers.base import Scorer, ScorerKind
from mlflow.genai.scorers.builtin_scorers import (
    BuiltInScorer,
    Correctness,
    Equivalence,
    ExpectationsGuidelines,
    MissingColumnsException,
    RelevanceToQuery,
    RetrievalGroundedness,
    RetrievalRelevance,
    RetrievalSufficiency,
    Safety,
    get_all_scorers,
)
from mlflow.genai.scorers.validation import (
    valid_data_for_builtin_scorers,
    validate_aggregations,
    validate_scorers,
)


# ── SR-1: scorer decorator ──────────────────────────────────────────────

def check_sr1_behavior():
    """SR-1: scorer decorator — behavior / state / boundary tests."""
    print("--- check_sr1_behavior ---")

    # ── 1.1: Bare decorator produces Scorer with correct name ──
    @scorer
    def bare_scorer(outputs):
        return bool(outputs)

    assert isinstance(bare_scorer, Scorer)
    assert bare_scorer.name == "bare_scorer"
    assert bare_scorer.kind == ScorerKind.DECORATOR
    assert bare_scorer.description is None
    assert bare_scorer.aggregations is None
    print("  1.1: bare decorator metadata — PASS")

    # ── 1.2: Parameterized decorator ──
    @scorer(name="param_name", description="desc", aggregations=["min", "median"])
    def param_scorer(inputs, outputs, expectations, trace):
        return 42

    assert param_scorer.name == "param_name"
    assert param_scorer.description == "desc"
    assert param_scorer.aggregations == ["min", "median"]
    print("  1.2: parameterized decorator — PASS")

    # ── 1.3: __signature__ has self + original params ──
    # Lesson L-1: inspect unbound call, not bound
    sig = inspect.signature(type(bare_scorer).__call__)
    params = list(sig.parameters.keys())
    assert params[0] == "self", f"Expected 'self' first, got {params}"
    assert "outputs" in params
    print("  1.3: __signature__ structure — PASS")

    # ── 1.4: __call__ filtering — extra kwargs ignored ──
    @scorer
    def filter_test(outputs):
        return outputs.upper()

    result = filter_test(outputs="hello", inputs="ignored", expectations={"x": 1}, trace=None)
    assert result == "HELLO"
    print("  1.4: __call__ extra kwargs filtering — PASS")

    # ── 1.5: __call__ with only the subset of params ──
    @scorer
    def subset_test(inputs):
        return f"got: {inputs}"

    result2 = subset_test(inputs="hello", outputs="world")
    assert result2 == "got: hello"
    print("  1.5: __call__ param subset — PASS")

    # ── 1.6: Return types: bool ──
    @scorer
    def bool_scorer(outputs):
        return len(outputs) > 0

    assert bool_scorer(outputs="test") is True
    assert bool_scorer(outputs="") is False
    print("  1.6: bool return — PASS")

    # ── 1.7: Return types: int ──
    @scorer
    def int_scorer(outputs):
        return len(outputs)

    assert int_scorer(outputs="test") == 4
    print("  1.7: int return — PASS")

    # ── 1.8: Return types: float ──
    @scorer
    def float_scorer(outputs):
        return float(len(outputs)) / 2.0

    assert float_scorer(outputs="test") == 2.0
    print("  1.8: float return — PASS")

    # ── 1.9: Return types: string ──
    @scorer
    def str_scorer(outputs):
        return f"len={len(outputs)}"

    assert str_scorer(outputs="test") == "len=4"
    print("  1.9: string return — PASS")

    # ── 1.10: Return types: Feedback ──
    @scorer
    def feedback_scorer(outputs):
        return Feedback(
            value="yes",
            rationale="good output",
            source=AssessmentSource(source_type="HUMAN", source_id="user1"),
        )

    fb = feedback_scorer(outputs="test")
    assert isinstance(fb, Feedback)
    assert fb.value == "yes"
    assert fb.rationale == "good output"
    print("  1.10: Feedback return — PASS")

    # ── 1.11: Return types: list[Feedback] ──
    @scorer
    def multi_fb_scorer(outputs):
        return [
            Feedback(name="fb1", value=1.0, rationale="first"),
            Feedback(name="fb2", value=0.5, rationale="second"),
        ]

    fb_list = multi_fb_scorer(outputs="test")
    assert isinstance(fb_list, list)
    assert len(fb_list) == 2
    assert all(isinstance(f, Feedback) for f in fb_list)
    assert fb_list[0].name == "fb1"
    assert fb_list[1].name == "fb2"
    print("  1.11: list[Feedback] return — PASS")

    # ── 1.12: _original_func preserved ──
    @scorer
    def orig_test(outputs):
        return True

    assert hasattr(orig_test, "_original_func")
    assert orig_test._original_func.__name__ == "orig_test"
    # Call the original function through the stored reference
    assert orig_test._original_func(outputs="x") is True
    print("  1.12: _original_func preserved — PASS")

    # ── 1.13: scorer as function call (not decorator) ──
    def plain_func(outputs):
        return outputs

    wrapped = scorer(plain_func)
    assert isinstance(wrapped, Scorer)
    assert wrapped.name == "plain_func"
    sig2 = inspect.signature(type(wrapped).__call__)
    param_names2 = list(sig2.parameters.keys())
    assert param_names2[0] == "self"
    assert "outputs" in param_names2
    assert wrapped(outputs="hello") == "hello"
    print("  1.13: scorer(func) call pattern — PASS")

    # ── 1.14: scorer with partial application ──
    partial = scorer(name="partial_test", description="partial desc")
    assert callable(partial)

    @partial
    def partial_func(inputs):
        return inputs

    assert partial_func.name == "partial_test"
    assert partial_func.description == "partial desc"
    print("  1.14: scorer partial application — PASS")

    # ── 1.15: Decorated function is callable as a Scorer ──
    @scorer
    def callable_test(inputs, outputs, expectations, trace):
        return {
            "inputs": inputs,
            "outputs": outputs,
            "expectations": expectations,
            "trace": trace,
        }

    result3 = callable_test(
        inputs="in", outputs="out", expectations={"key": "val"}, trace=None
    )
    assert result3["inputs"] == "in"
    assert result3["outputs"] == "out"
    assert result3["expectations"] == {"key": "val"}
    assert result3["trace"] is None
    print("  1.15: full callable interface — PASS")

    print("PASS: check_sr1_behavior")


# ── SR-2: valid_data_for_builtin_scorers ────────────────────────────────

def check_sr2_behavior():
    """SR-2: valid_data_for_builtin_scorers — state / boundary / error tests."""
    print("--- check_sr2_behavior ---")

    # ── 2.1: Empty scorers — no-op ──
    df = pd.DataFrame({"inputs": ["test"]})
    valid_data_for_builtin_scorers(df, [])
    print("  2.1: empty scorers no-op — PASS")

    # ── 2.2: Valid data with all columns ──
    df2 = pd.DataFrame({
        "inputs": ["What is MLflow?"],
        "outputs": ["MLflow is an open-source platform"],
    })
    valid_data_for_builtin_scorers(df2, [Correctness(name="correctness")])
    print("  2.2: valid data — PASS")

    # ── 2.3: Missing columns logged (not raised) ──
    df3 = pd.DataFrame({"inputs": ["test"]})
    # Correctness needs outputs — should log, not raise
    valid_data_for_builtin_scorers(df3, [Correctness(name="correctness")])
    print("  2.3: missing columns logged — PASS")

    # ── 2.4: request -> inputs mapping ──
    df4 = pd.DataFrame({
        "request": ["What is MLflow?"],
        "outputs": ["Answer"],
    })
    valid_data_for_builtin_scorers(df4, [Correctness(name="correctness")])
    print("  2.4: request -> inputs mapping — PASS")

    # ── 2.5: response -> outputs mapping ──
    df5 = pd.DataFrame({
        "inputs": ["What is MLflow?"],
        "response": ["Answer"],
    })
    valid_data_for_builtin_scorers(df5, [Correctness(name="correctness")])
    print("  2.5: response -> outputs mapping — PASS")

    # ── 2.6: predict_fn makes outputs available ──
    df6 = pd.DataFrame({"inputs": ["test"]})
    valid_data_for_builtin_scorers(
        df6,
        [Correctness(name="correctness")],
        predict_fn=lambda x: "prediction",
    )
    print("  2.6: predict_fn adds outputs — PASS")

    # ── 2.7: trace column infers inputs+outputs ──
    with mlflow.start_span(name="test_trace") as span:
        span.set_inputs({"q": "test"})
        span.set_outputs({"a": "resp"})
    trace = mlflow.get_trace(span.trace_id)
    df7 = pd.DataFrame({"trace": [trace]})
    valid_data_for_builtin_scorers(df7, [Correctness(name="correctness")])
    print("  2.7: trace inference — PASS")

    # ── 2.8: expectations explosion ──
    df8 = pd.DataFrame({
        "inputs": ["test"],
        "outputs": ["test"],
        "expectations": [{"guidelines": ["Be concise"], "expected_response": "answer"}],
    })
    valid_data_for_builtin_scorers(df8, [ExpectationsGuidelines(name="exp_guide")])
    print("  2.8: expectations explosion — PASS")

    # ── 2.9: Non-dict expectations raises MlflowException ──
    df9 = pd.DataFrame({
        "inputs": ["test"],
        "outputs": ["test"],
        "expectations": ["not a dict"],
    })
    try:
        valid_data_for_builtin_scorers(df9, [ExpectationsGuidelines(name="exp_guide")])
        assert False, "Should have raised MlflowException"
    except MlflowException:
        pass
    print("  2.9: non-dict expectations raises — PASS")

    print("PASS: check_sr2_behavior")


# ── SR-3: validate_scorers ──────────────────────────────────────────────

def check_sr3_behavior():
    """SR-3: validate_scorers — state / boundary / error tests."""
    print("--- check_sr3_behavior ---")

    # ── 3.1: Empty list returns empty list ──
    result = validate_scorers([])
    assert result == []
    print("  3.1: empty list — PASS")

    # ── 3.2: Valid Scorer instances pass through ──
    scorers = [
        Correctness(name="c1"),
        RelevanceToQuery(name="rq1"),
    ]
    result2 = validate_scorers(scorers)
    assert len(result2) == 2
    assert all(isinstance(s, Scorer) for s in result2)
    assert result2[0].name == "c1"
    print("  3.2: valid Scorer instances — PASS")

    # ── 3.3: Non-list raises ──
    try:
        validate_scorers(Correctness(name="c1"))
        assert False, "Should raise"
    except MlflowException as e:
        assert "list" in str(e).lower()
    print("  3.3: non-list raises — PASS")

    # ── 3.4: Class instead of instance raises with hint ──
    try:
        validate_scorers([Correctness])
        assert False, "Should raise"
    except MlflowException as e:
        msg = str(e)
        assert "instance" in msg.lower() or "class" in msg.lower() or "Correctness()" in msg
    print("  3.4: class-instead-of-instance raises — PASS")

    # ── 3.5: Nested list raises with hint ──
    try:
        validate_scorers([[Correctness(name="c1")]])
        assert False, "Should raise"
    except MlflowException as e:
        msg = str(e)
        assert "nested list" in msg.lower() or "wrapping" in msg.lower() or "get_all_scorers" in msg
    print("  3.5: nested list raises — PASS")

    # ── 3.6: None raises ──
    try:
        validate_scorers(None)
        assert False, "Should raise"
    except MlflowException:
        pass
    print("  3.6: None raises — PASS")

    # ── 3.7: Invalid object raises ──
    try:
        validate_scorers([42, "string", object()])
        assert False, "Should raise"
    except MlflowException:
        pass
    print("  3.7: invalid objects raise — PASS")

    print("PASS: check_sr3_behavior")


# ── SR-4: get_all_scorers ───────────────────────────────────────────────

def check_sr4_behavior():
    """SR-4: get_all_scorers — state / boundary tests."""
    print("--- check_sr4_behavior ---")

    old_uri = mlflow.get_tracking_uri()

    # ── 4.1: OSS count is 6 ──
    mlflow.set_tracking_uri("")
    scorers = get_all_scorers()
    assert len(scorers) == 6, f"Expected 6, got {len(scorers)}"
    print("  4.1: OSS count 6 — PASS")

    # ── 4.2: All are Scorer instances ──
    assert all(isinstance(s, Scorer) for s in scorers)
    assert all(isinstance(s, BuiltInScorer) for s in scorers)
    print("  4.2: all Scorer instances — PASS")

    # ── 4.3: Expected names present ──
    expected = {
        "ExpectationsGuidelines",
        "Correctness",
        "RelevanceToQuery",
        "RetrievalSufficiency",
        "RetrievalGroundedness",
        "Equivalence",
    }
    actual = {s.name for s in scorers}
    assert expected == actual, f"Missing: {expected - actual}, Extra: {actual - expected}"
    print("  4.3: expected names — PASS")

    # ── 4.4: No Databricks-only scorers under OSS ──
    for s in scorers:
        assert not isinstance(s, Safety)
        assert not isinstance(s, RetrievalRelevance)
    print("  4.4: no Databricks-only scorers — PASS")

    # ── 4.5: Idempotent — same count every call ──
    for _ in range(3):
        assert len(get_all_scorers()) == 6
    print("  4.5: idempotent count — PASS")

    # ── 4.6: Fresh instances each call ──
    s1 = get_all_scorers()
    s2 = get_all_scorers()
    for a, b in zip(s1, s2):
        assert a is not b, f"Scorer {a.name} should be fresh instance"
    print("  4.6: fresh instances each call — PASS")

    # ── 4.7: Databricks URI yields 8 including Safety + RetrievalRelevance ──
    mlflow.set_tracking_uri("databricks")
    scorers_db = get_all_scorers()
    assert len(scorers_db) == 8, f"Expected 8, got {len(scorers_db)}"
    has_safety = any(isinstance(s, Safety) for s in scorers_db)
    has_rr = any(isinstance(s, RetrievalRelevance) for s in scorers_db)
    assert has_safety, "Safety is missing"
    assert has_rr, "RetrievalRelevance is missing"
    print("  4.7: Databricks URI 8 scorers — PASS")

    mlflow.set_tracking_uri(old_uri)
    print("PASS: check_sr4_behavior")


# ── validate_aggregations behavior ──────────────────────────────────────

def check_validate_aggregations():
    """Additional: validate_aggregations behavior tests."""
    print("--- check_validate_aggregations ---")

    # Valid strings
    from mlflow.genai.scorers.validation import validate_aggregations
    validate_aggregations(["min", "max", "mean", "median", "variance", "p90"])
    print("  1: valid string aggregations — PASS")

    # Valid callable
    validate_aggregations([lambda x: sum(x) / len(x)])
    print("  2: valid callable aggregation — PASS")

    # Mixed valid
    validate_aggregations(["min", lambda x: max(x)])
    print("  3: mixed valid — PASS")

    # None / empty
    validate_aggregations(None)
    validate_aggregations([])
    print("  4: None/empty — PASS")

    # Invalid string
    try:
        validate_aggregations(["not_a_valid_agg"])
        assert False, "Should raise"
    except MlflowException:
        pass
    print("  5: invalid string raises — PASS")

    # Non-string, non-callable
    try:
        validate_aggregations([42])
        assert False, "Should raise"
    except MlflowException:
        pass
    print("  6: non-callable, non-string raises — PASS")

    print("PASS: check_validate_aggregations")


def main():
    check_sr1_behavior()
    check_sr2_behavior()
    check_sr3_behavior()
    check_sr4_behavior()
    check_validate_aggregations()
    print("\nAll behavior checks passed.")


if __name__ == "__main__":
    main()
