# Review Report

- Status: approved

## Findings

- None

## Coverage

| Map ID | Status | Evidence |
|--------|--------|----------|
| SR-1 | Observable | Both `check_sr1_arch` and `check_sr1_behavior` pass all assertions. The arch spec verifies: `Scorer` instance returned for bare and parameterized decorator usage, `__signature__` includes `self` plus original params on unbound `__call__`, extra kwargs silently ignored, `_original_func` stored, `kind == DECORATOR`, `name`/`description`/`aggregations` propagated correctly, and function-call pattern `scorer(func)` works. The behavior spec adds 15 boundary tests including all return types (bool, int, float, str, Feedback, list[Feedback]), partial application, and full callable interface. Native tests: 19 passed, 16 skipped (Databricks-only). |
| SR-2 | Observable | Both `check_sr2_arch` and `check_sr2_behavior` pass all assertions. The arch spec verifies 9 integration paths: valid data, empty scorers, request→inputs mapping, response→outputs mapping, predict_fn suppresses outputs requirement, trace inference of inputs+outputs, expectations dictionary explosion, missing columns logged (not raised), and non-dict expectations raises `MlflowException`. The behavior spec adds additional edge cases for each scenario. Native `test_builtin_scorers.py`: 58 passed, 4 skipped. |
| SR-3 | Observable | Both `check_sr3_arch` and `check_sr3_behavior` pass all assertions. The arch spec verifies: valid Scorer instances pass through, empty list returns empty list, class-instead-of-instance raises with hint, nested list raises with hint, non-list raises, and decorator-created scorers work. The behavior spec adds 7 boundary tests including None rejection and mixed invalid objects. Integration verified via real callers (`mlflow.genai.evaluate` and `mlflow.genai.optimize.util`). |
| SR-4 | Observable | Both `check_sr4_arch` and `check_sr4_behavior` pass all assertions. Verified: 6 OSS scorers returned, all are `BuiltInScorer`/`Scorer` instances, expected names match exactly (`ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, `Equivalence`), no `Safety` or `RetrievalRelevance` under OSS URI, 8 scorers under Databricks URI including both Databricks-only scorers, fresh instances per call (not singletons), and idempotent count. Native `test_get_all_scorers_oss`: passes for both OSS and Databricks URIs. |

All four subrequirements are fully implemented and observable through the architecture and behavior specs. Both spec harnesses complete without error. All 180 native tests in `tests/genai/scorers/` pass (20 Databricks-specific tests correctly skipped). The caller-side integrations in `mlflow/genai/evaluation/base.py` and `mlflow/genai/optimize/util.py` import and invoke the correct functions.

### Auxiliary coverage note

The function `validate_aggregations` in `validation.py` is tested by the behavior spec but is not referenced by any subrequirement. It exists as a utility and is correctly implemented with validation for valid string names, callables, and error cases. No production code currently calls it; its coverage is provided by the behavior spec alone.

## Risk Focus

No implementation-level risks. The highest residual risk is integration-side:

1. **Column name normalization in evaluate pipeline**: The `_convert_to_eval_set` function produces the DataFrame consumed by `valid_data_for_builtin_scorers`. If that function changes column naming conventions, the validation could silently pass with wrong column names. This is mitigated by the architecture spec testing the full request→inputs and response→outputs mapping.

2. **Databricks URI detection**: `get_all_scorers` and the `Safety`/`RetrievalRelevance` scorers depend on `is_databricks_uri(get_tracking_uri())`. If the URI detection logic changes, the scorer count could silently shift. Both specs test this explicitly under OSS and Databricks URIs.

3. **Expectations column null handling**: The implementation allows `None` values in the expectations column (skips them) but raises for non-dict, non-None values. If the upstream data pipeline produces `float('nan')` in expectations, it would trigger an unexpected `MlflowException`. This is an edge case unlikely in normal use but worth noting.

## Spec Actions

No spec changes needed. All four subrequirements pass their architecture and behavior checks. The prior-cycle spec errors (F-1: bound method signature inspection, F-2: Pydantic field annotation) have been corrected and both specs now pass cleanly.

- **No action required** on `arch_spec.py` or `behavior_spec.py`.
- **No action required** on any production code.
