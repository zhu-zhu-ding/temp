## static issue

- **`mlflow/genai/evaluation/base.py`** (2):
  - ? 'valid_data_for_builtin_scorers' is used but not defined or imported in this file
  - ? 'validate_scorers' is used but not defined or imported in this file
- **`mlflow/genai/optimize/util.py`** (1):
  - ? 'valid_data_for_builtin_scorers' is used but not defined or imported in this file
- **`mlflow/genai/scorers/base.py`** (1):
  - ? 'CustomScorer' is used but not defined or imported in this file
