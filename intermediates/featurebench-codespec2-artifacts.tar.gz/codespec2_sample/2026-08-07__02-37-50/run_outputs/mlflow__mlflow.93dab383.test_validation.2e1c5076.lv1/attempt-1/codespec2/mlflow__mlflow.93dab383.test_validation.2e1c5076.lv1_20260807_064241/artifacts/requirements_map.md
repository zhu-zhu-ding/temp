# Subrequirement Map

## SR-1
- **Requirement**: Implement the `scorer` decorator at `/testbed/mlflow/genai/scorers/base.py` that wraps a user-defined function into a `Scorer` instance callable by `mlflow.genai.evaluate()`. The decorator must accept `func`, `name`, `description`, and `aggregations` as arguments; create a `CustomScorer` subclass; set `__signature__` on `CustomScorer.__call__` with `self` prepended to the original function's parameters; and return a `Scorer` instance whose `__call__` filters kwargs to only those the original function accepts.
- **Task Evidence**: Interface Description 1 specifies the `scorer` function signature, docstring, and behavior. The task states "Support both strict validation and graceful degradation (truncation) modes" and "Balance strict validation with user-friendly error messages".
- **Architecture Spec**: `check_sr1_arch` — Exercise the decorator with `@scorer` and `@scorer(name=...)` patterns, verify the returned object is a `Scorer` instance, that `CustomScorer.__call__.__signature__` includes `self` as first param, that `kind` is `DECORATOR`, and that `__call__` correctly filters and delegates to `_original_func`.
- **Behavior Spec**: `check_sr1_behavior` — Test state transitions: bare decorator usage, parameterized decorator usage (name/description/aggregations), `__call__` filtering (extra kwargs ignored, missing kwargs allowed), return type acceptance (bool, int, float, str, Feedback, list[Feedback]), `kind` property, `_original_func` storage, idempotency, and error on invalid input.
- **Critical Path**: `@scorer` → `scorer()` → `CustomScorer` class creation → `__signature__` setting → `instance.__call__(**kwargs)` → filtered `_original_func(**filtered)` → return value.
- **Expected Intermediate State**: After decoration, the decorated function is replaced by a `CustomScorer` instance with `kind == ScorerKind.DECORATOR`, `_original_func` set, and `__call__.__signature__` having `self` plus original params.
- **Expected Final Output**: Calling the scorer instance with kwargs matching the original function's parameters invokes the original function and returns its result. Extra kwargs are silently ignored.
- **Observability**: The `__signature__` on `type(instance).__call__` is inspectable. The `kind` property returns `DECORATOR`. The returned value matches the original function's output. Native tests at `tests/genai/scorers/test_scorer.py` confirm the decorator works in evaluation pipelines.
- **Repository Evidence**: `mlflow/genai/scorers/base.py:scorer` (line ~850), `mlflow/genai/scorers/__init__.py:scorer` (export), `tests/genai/scorers/test_scorer.py` (native tests), `mlflow/genai/evaluation/base.py` (caller via `validate_scorers`).
- **Architecture Check**: `check_sr1_arch`
- **Behavior Check**: `check_sr1_behavior`

## SR-2
- **Requirement**: Implement `valid_data_for_builtin_scorers` at `/testbed/mlflow/genai/scorers/validation.py` that validates a pandas DataFrame contains required columns for builtin scorers. Must handle column name mapping (request→inputs, response→outputs), predict_fn inference, trace inference, expectations dictionary explosion, and log (not raise) missing columns.
- **Task Evidence**: Interface Description 2 specifies the function signature, docstring, and behavior. The task states "Validate complex data structures like datasets, input tags, and batch operations" and "Handle different validation rules across entity types".
- **Architecture Spec**: `check_sr2_arch` — Exercise the full integration path from `validate_scorers` → `valid_data_for_builtin_scorers` with real BuiltInScorer subclasses, verify column mapping, predict_fn effect, trace inference, expectations explosion, and missing column logging.
- **Behavior Spec**: `check_sr2_behavior` — Test edge cases: empty scorers, valid data, missing columns (logged), request→inputs mapping, response→outputs mapping, predict_fn suppressing outputs requirement, trace inference of inputs+outputs, expectations explosion, non-dict expectations raises MlflowException.
- **Critical Path**: `valid_data_for_builtin_scorers(data, builtin_scorers, predict_fn)` → build available_columns from data.columns → apply request→inputs / response→outputs mapping → add "outputs" if predict_fn → add "inputs","outputs" if trace → explode expectations dict keys → for each scorer, call `scorer.validate_columns(available_columns)` → log MissingColumnsException.
- **Expected Intermediate State**: After column mapping and inference, `available_columns` includes derived column names. Each scorer's `validate_columns` is called.
- **Expected Final Output**: Returns `None`. Missing columns cause info-level log messages. Non-dict expectations raise `MlflowException`.
- **Observability**: Log output for missing columns. Exception for invalid expectations. Native tests at `tests/genai/scorers/test_builtin_scorers.py` cover `get_all_scorers` but validation is exercised indirectly through `evaluate`.
- **Repository Evidence**: `mlflow/genai/scorers/validation.py:valid_data_for_builtin_scorers` (line 27), `mlflow/genai/evaluation/base.py` (line 252 caller), `mlflow/genai/optimize/util.py` (line 92 caller), `mlflow/genai/scorers/builtin_scorers.py:BuiltInScorer.validate_columns` (line 324), `mlflow/genai/scorers/builtin_scorers.py:BuiltInScorer.required_columns` (line 266).
- **Architecture Check**: `check_sr2_arch`
- **Behavior Check**: `check_sr2_behavior`

## SR-3
- **Requirement**: Implement `validate_scorers` at `/testbed/mlflow/genai/scorers/validation.py` that validates a list of potential scorers. Must accept `Scorer` instances, reject non-lists, reject classes instead of instances (with hint), reject nested lists (with hint), and support legacy `databricks.rag_eval` metrics if installed.
- **Task Evidence**: Interface Description 2 specifies the function signature, docstring, and behavior. The task states "Balance strict validation with user-friendly error messages" and "Handle edge cases in naming patterns and reserved keywords".
- **Architecture Spec**: `check_sr3_arch` — Exercise the function through its real caller `mlflow.genai.evaluate()` path: import from validation, call with valid scorers (BuiltInScorer instances, @scorer decorator instances), verify returned list contains Scorer instances, verify class-instead-of-instance raises with hint, verify nested list raises with hint.
- **Behavior Spec**: `check_sr3_behavior` — Test boundaries: empty list returns empty list, valid Scorer instances pass through, non-list raises, class-instead-of-instance raises with hint message, nested list raises with hint message, None/invalid objects raise, legacy Metric support (if databricks.agents installed), scorers passed as single item (not a list) raises.
- **Critical Path**: `validate_scorers(scorers)` → isinstance check for list → iterate items → isinstance(Scorer) → append, isinstance(type) + issubclass(Scorer) → raise with class hint, isinstance(list) → raise with nesting hint, else (IS_DBX_AGENTS_INSTALLED) → check Metric → else raise.
- **Expected Intermediate State**: Each item is classified as valid (Scorer instance), class-error, list-error, or invalid.
- **Expected Final Output**: Returns `list[Scorer]` of validated instances. Raises `MlflowException` for invalid inputs with helpful hints.
- **Observability**: Return value is a list of Scorer instances. Exception messages contain hints for common mistakes. Native tests exercise this through `mlflow.genai.evaluate()`.
- **Repository Evidence**: `mlflow/genai/scorers/validation.py:validate_scorers` (line 129), `mlflow/genai/evaluation/base.py` (line 247 caller), `mlflow/genai/scorers/base.py:Scorer` (base class).
- **Architecture Check**: `check_sr3_arch`
- **Behavior Check**: `check_sr3_behavior`

## SR-4
- **Requirement**: Implement `get_all_scorers` at `/testbed/mlflow/genai/scorers/builtin_scorers.py` that returns all available built-in scorers. Must include 6 OSS scorers (ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence) and 2 Databricks-only scorers (Safety, RetrievalRelevance) conditional on tracking URI.
- **Task Evidence**: Interface Description 3 specifies the function signature, docstring, and behavior. The task states "Support cross-platform compatibility (Windows vs. other systems) with different character restrictions" (general extensibility requirement).
- **Architecture Spec**: `check_sr4_arch` — Call `get_all_scorers()` under OSS tracking URI, verify 6 scorers returned, all are Scorer instances, expected names present, no Safety/RetrievalRelevance. Then under Databricks URI, verify 8 scorers including Safety and RetrievalRelevance.
- **Behavior Spec**: `check_sr4_behavior` — Test: correct count under OSS URI (6), all instances are Scorer, expected scorer names present, Databricks-only scorers absent under OSS URI, idempotent calls return same count, fresh instances each call (not singletons), Databricks URI yields 8 scorers with Safety+RetrievalRelevance.
- **Critical Path**: `get_all_scorers()` → create list of 6 OSS scorer instances → check `is_databricks_uri(get_tracking_uri())` → conditionally append Safety() and RetrievalRelevance() → return list.
- **Expected Intermediate State**: 6 instances created unconditionally, 2 more conditionally.
- **Expected Final Output**: `list[BuiltInScorer]` with 6 or 8 instances depending on tracking URI.
- **Observability**: Return list length and content. Fresh instances per call. Native test `test_get_all_scorers_oss` at `tests/genai/scorers/test_builtin_scorers.py:570`.
- **Repository Evidence**: `mlflow/genai/scorers/builtin_scorers.py:get_all_scorers` (end of file), `mlflow/genai/scorers/__init__.py` (lazy export), `tests/genai/scorers/test_builtin_scorers.py:test_get_all_scorers_oss` (line 570).
- **Architecture Check**: `check_sr4_arch`
- **Behavior Check**: `check_sr4_behavior`
