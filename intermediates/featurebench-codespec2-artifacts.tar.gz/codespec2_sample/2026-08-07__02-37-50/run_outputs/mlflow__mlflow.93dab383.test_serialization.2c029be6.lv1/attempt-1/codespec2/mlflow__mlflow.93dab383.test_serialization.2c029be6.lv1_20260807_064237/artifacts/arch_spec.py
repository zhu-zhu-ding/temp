#!/usr/bin/env python3
"""
Architecture Spec for Assessment Source Management and Custom Scorer Framework.

This spec exercises real public input -> caller/import -> helper/dispatcher ->
observable result paths. It does NOT modify /testbed; it imports the existing
code and validates integration contracts.

Subrequirements:
  SR-01: AssessmentSourceType validation and standardization
  SR-02: scorer decorator for custom evaluation functions
  SR-03: extract_function_body - AST-based source code extraction
  SR-04: recreate_function - dynamic function reconstruction
  SR-05: Scorer serialization/deserialization lifecycle
  SR-06: Scorer return type validation
"""

import sys
import os
import warnings

# Ensure /testbed is on path
sys.path.insert(0, "/testbed")


# ===========================================================================
# SR-01: AssessmentSourceType validation and standardization
# ===========================================================================
def check_sr01_assessmentsourcetype_validation():
    """Exercise the AssessmentSourceType public API path:
    AssessmentSource.__post_init__ -> AssessmentSourceType._standardize ->
    AssessmentSourceType.__init__ -> AssessmentSourceType._parse -> str()
    """
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
    from mlflow.exceptions import MlflowException

    # -- Path 1: Direct constant access (class attributes)
    assert AssessmentSourceType.HUMAN == "HUMAN", "Constant HUMAN should be 'HUMAN'"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE", "Constant LLM_JUDGE should be 'LLM_JUDGE'"
    assert AssessmentSourceType.CODE == "CODE", "Constant CODE should be 'CODE'"
    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE", "AI_JUDGE constant should exist as deprecated"

    # -- Path 2: Instance creation with __init__
    inst = AssessmentSourceType("HUMAN")
    assert str(inst) == "HUMAN", f"str(AssessmentSourceType('HUMAN')) should be 'HUMAN', got {str(inst)}"

    inst2 = AssessmentSourceType("llm_judge")
    assert str(inst2) == "LLM_JUDGE", "Case-insensitive: 'llm_judge' -> 'LLM_JUDGE'"

    # -- Path 3: _parse static method
    result = AssessmentSourceType._parse("CODE")
    assert result == "CODE", f"_parse('CODE') should return 'CODE', got {result}"

    result2 = AssessmentSourceType._parse("human")
    assert result2 == "HUMAN", f"_parse('human') should return 'HUMAN', got {result2}"

    # -- Path 4: _standardize static method
    result3 = AssessmentSourceType._standardize("code")
    assert result3 == "CODE", f"_standardize('code') should return 'CODE', got {result3}"

    result4 = AssessmentSourceType._standardize("SOURCE_TYPE_UNSPECIFIED")
    assert result4 == "SOURCE_TYPE_UNSPECIFIED"

    # -- Path 5: AI_JUDGE deprecation
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result5 = AssessmentSourceType._standardize("AI_JUDGE")
        assert result5 == "LLM_JUDGE", f"AI_JUDGE should map to LLM_JUDGE, got {result5}"
        assert len(w) >= 1, "Should emit FutureWarning for AI_JUDGE"
        assert issubclass(w[0].category, FutureWarning)

    # -- Path 6: Invalid type
    try:
        AssessmentSourceType._standardize("INVALID_TYPE")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e), f"Expected 'Invalid assessment source type' in error, got: {e}"

    # -- Path 7: AssessmentSource integration (__post_init__ calls _standardize)
    source = AssessmentSource(source_type="human", source_id="user_1")
    assert source.source_type == "HUMAN", f"AssessmentSource should standardize type, got {source.source_type}"

    source2 = AssessmentSource(source_type="LLM_JUDGE", source_id="judge_1")
    assert source2.source_type == "LLM_JUDGE"

    # -- Path 8: Invalid source via AssessmentSource
    try:
        AssessmentSource(source_type="ROBOT", source_id="r1")
        assert False, "Should have raised"
    except MlflowException:
        pass

    print("PASS: check_sr01_assessmentsourcetype_validation")


# ===========================================================================
# SR-02: scorer decorator
# ===========================================================================
def check_sr02_scorer_decorator():
    """Exercise the @scorer decorator public API path:
    @scorer -> creates Scorer instance -> run() -> returns validated result
    """
    from mlflow.genai.scorers.base import Scorer, ScorerKind, SerializedScorer
    from mlflow.entities import Feedback, AssessmentSource, AssessmentSourceType

    # Verify scorer is importable from the public API
    from mlflow.genai.scorers import scorer
    assert callable(scorer) or hasattr(scorer, '__call__'), "scorer should be importable and callable"

    # -- Path 1: Basic decorator without arguments
    @scorer
    def not_empty(outputs) -> bool:
        return outputs != ""

    assert isinstance(not_empty, Scorer), "@scorer should return a Scorer instance"
    assert not_empty.name == "not_empty", f"Name should default to function name, got {not_empty.name}"
    assert not_empty.kind == ScorerKind.DECORATOR, f"Kind should be DECORATOR, got {not_empty.kind}"
    assert not_empty.description is None, "Default description should be None"

    # -- Path 2: run() with matching parameters
    result = not_empty.run(outputs="hello")
    assert result is True, f"not_empty('hello') should be True, got {result}"

    result2 = not_empty.run(outputs="")
    assert result2 is False, f"not_empty('') should be False, got {result2}"

    # -- Path 3: Decorator with custom name
    @scorer(name="custom_name")
    def some_func(outputs) -> bool:
        return True

    assert some_func.name == "custom_name", f"Custom name should be 'custom_name', got {some_func.name}"

    # -- Path 4: Decorator with description
    @scorer(description="Checks if output is non-empty")
    def check_empty(outputs) -> bool:
        return bool(outputs)

    assert check_empty.description == "Checks if output is non-empty"

    # -- Path 5: Decorator returning Feedback object
    @scorer
    def feedback_scorer(outputs) -> Feedback:
        return Feedback(
            value=True,
            rationale="test rationale",
            source=AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="test"),
        )

    fb = feedback_scorer.run(outputs="test")
    assert isinstance(fb, Feedback), f"Should return Feedback, got {type(fb)}"
    assert fb.value is True

    # -- Path 6: Decorator returning list of Feedback
    @scorer
    def multi_feedback(outputs):
        return [
            Feedback(value=1.0, rationale="first"),
            Feedback(value=0.5, rationale="second"),
        ]

    results = multi_feedback.run(outputs="test")
    assert isinstance(results, list)
    assert len(results) == 2
    assert all(isinstance(r, Feedback) for r in results)

    # -- Path 7: model_dump() serialization
    dumped = not_empty.model_dump()
    assert isinstance(dumped, dict)
    assert dumped["name"] == "not_empty"
    assert "call_source" in dumped
    assert "call_signature" in dumped
    assert "original_func_name" in dumped
    assert dumped["call_source"] is not None and len(dumped["call_source"]) > 0

    # -- Path 8: SerializedScorer creation from dumped data
    serialized = SerializedScorer(**dumped)
    assert serialized.name == "not_empty"
    assert serialized.original_func_name == "not_empty"

    print("PASS: check_sr02_scorer_decorator")


# ===========================================================================
# SR-03: extract_function_body
# ===========================================================================
def check_sr03_extract_function_body():
    """Exercise extract_function_body:
    import -> call with real function -> get source body string.
    """
    from mlflow.genai.scorers.scorer_utils import extract_function_body

    # -- Path 1: Simple function
    def simple_add(x, y):
        return x + y

    body, deps = extract_function_body(simple_add)
    assert isinstance(body, str), f"Body should be str, got {type(body)}"
    assert "return x + y" in body, f"Body should contain 'return x + y', got: {body}"
    assert "def " not in body, "Body should NOT contain 'def' line"

    # -- Path 2: Multi-line function
    def multi_line(x):
        if x > 0:
            return "positive"
        else:
            return "non-positive"

    body2, deps2 = extract_function_body(multi_line)
    assert "if x > 0" in body2
    assert "positive" in body2
    assert "non-positive" in body2

    # -- Path 3: Function with docstring
    def with_docstring(x):
        """This is a docstring."""
        return x * 2

    body3, deps3 = extract_function_body(with_docstring)
    assert "return x * 2" in body3

    print("PASS: check_sr03_extract_function_body")


# ===========================================================================
# SR-04: recreate_function
# ===========================================================================
def check_sr04_recreate_function():
    """Exercise recreate_function:
    import -> call with source/signature/name -> get callable.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    # -- Path 1: Simple function recreation
    add_fn = recreate_function("return x + y", "(x, y)", "add_func")
    assert callable(add_fn), "Should return a callable"
    assert add_fn.__name__ == "add_func"
    assert add_fn(3, 4) == 7
    assert add_fn(-1, 5) == 4

    # -- Path 2: Function with control flow
    classify = recreate_function(
        'if x > 0:\n    return "positive"\nelse:\n    return "non-positive"',
        "(x)",
        "classify_number"
    )
    assert classify(5) == "positive"
    assert classify(-3) == "non-positive"

    # -- Path 3: Function with default args
    power_fn = recreate_function("return base ** exponent", "(base, exponent=2)", "power")
    assert power_fn(3) == 9
    assert power_fn(2, 3) == 8

    # -- Path 4: Function with empty signature
    answer_fn = recreate_function("return 42", "()", "get_answer")
    assert answer_fn() == 42

    # -- Path 5: Function with loops
    sum_fn = recreate_function(
        "total = 0\nfor i in range(n):\n    total += i\nreturn total",
        "(n)",
        "sum_range"
    )
    assert sum_fn(5) == 10  # 0+1+2+3+4

    # -- Path 6: recreate_function with mlflow imports available
    complex_fn = recreate_function(
        "return Feedback(value=True, rationale='test')",
        "()",
        "create_feedback"
    )
    from mlflow.entities import Feedback
    result = complex_fn()
    assert isinstance(result, Feedback)
    assert result.value is True

    print("PASS: check_sr04_recreate_function")


# ===========================================================================
# SR-05: Scorer serialization/deserialization lifecycle
# ===========================================================================
def check_sr05_scorer_serialization():
    """Exercise full round-trip: scorer -> model_dump -> model_validate -> run."""
    from mlflow.genai.scorers.base import Scorer, SerializedScorer
    from mlflow.genai.scorers import scorer

    # -- Path 1: Simple round-trip via model_dump/model_validate
    @scorer
    def length_check(outputs) -> bool:
        return len(outputs) > 5

    # Serialize
    dumped = length_check.model_dump()
    assert isinstance(dumped, dict)
    assert dumped["name"] == "length_check"
    assert dumped["call_source"] is not None

    # Validate structural completeness
    required_fields = ["name", "call_source", "call_signature", "original_func_name",
                       "mlflow_version", "serialization_version"]
    for field in required_fields:
        assert field in dumped, f"Missing field '{field}' in serialized dict"

    # -- Path 2: SerializedScorer dataclass construction
    serialized = SerializedScorer(**dumped)
    assert serialized.name == "length_check"
    assert serialized.original_func_name == "length_check"

    # -- Path 3: model_validate from dict
    # Note: deserialization of decorator scorers is restricted to Databricks runtime.
    # We verify the validation path works structurally.
    try:
        deserialized = Scorer.model_validate(dumped)
        # If we reach here (e.g., in Databricks), verify correctness
        assert deserialized.name == "length_check"
        assert deserialized.run(outputs="hello world") is True
        assert deserialized.run(outputs="hi") is False
    except Exception as e:
        # Outside Databricks, expect security exception
        assert "not supported" in str(e) or "security" in str(e).lower(), \
            f"Expected security restriction error, got: {e}"

    # -- Path 4: model_validate from SerializedScorer object
    try:
        deserialized2 = Scorer.model_validate(serialized)
        assert deserialized2.name == "length_check"
    except Exception as e:
        assert "not supported" in str(e) or "security" in str(e).lower()

    # -- Path 5: _reconstruct_decorator_scorer directly (should fail outside Databricks)
    try:
        Scorer._reconstruct_decorator_scorer(serialized)
        # If in Databricks runtime, this succeeds
    except Exception as e:
        assert "not supported" in str(e) or "security" in str(e).lower()

    print("PASS: check_sr05_scorer_serialization")


# ===========================================================================
# SR-06: Scorer return type validation
# ===========================================================================
def check_sr06_return_type_validation():
    """Exercise Scorer.run() return type validation path."""
    from mlflow.genai.scorers import scorer
    from mlflow.entities import Feedback, AssessmentSource
    from mlflow.exceptions import MlflowException

    # -- Path 1: Valid returns - primitives
    @scorer
    def bool_scorer(outputs) -> bool:
        return True

    assert bool_scorer.run(outputs="x") is True

    @scorer
    def int_scorer(outputs) -> int:
        return 42

    assert int_scorer.run(outputs="x") == 42

    @scorer
    def float_scorer(outputs) -> float:
        return 3.14

    assert float_scorer.run(outputs="x") == 3.14

    @scorer
    def str_scorer(outputs) -> str:
        return "hello"

    assert str_scorer.run(outputs="x") == "hello"

    # -- Path 2: Valid returns - Feedback
    @scorer
    def fb_scorer(outputs) -> Feedback:
        return Feedback(value=True, rationale="ok")

    result = fb_scorer.run(outputs="x")
    assert isinstance(result, Feedback)
    assert result.value is True

    # -- Path 3: Valid returns - list[Feedback]
    @scorer
    def list_fb_scorer(outputs):
        return [Feedback(value=1.0), Feedback(value=0.5)]

    result = list_fb_scorer.run(outputs="x")
    assert isinstance(result, list)
    assert len(result) == 2

    # -- Path 4: Valid return - None
    @scorer
    def none_scorer(outputs):
        return None

    result = none_scorer.run(outputs="x")
    assert result is None

    # -- Path 5: Invalid return type (dict)
    @scorer
    def dict_scorer(outputs):
        return {"key": "value"}

    try:
        dict_scorer.run(outputs="x")
        assert False, "Should have raised MlflowException for dict return"
    except MlflowException as e:
        assert "must return one of" in str(e).lower() or "dict" in str(e).lower(), \
            f"Expected return type error, got: {e}"

    # -- Path 6: Feedback name overwrite for default name
    @scorer
    def my_scorer(outputs):
        return Feedback(value=42, rationale="test")

    fb = my_scorer.run(outputs="x")
    assert fb.name == "my_scorer", f"Default feedback name should be overwritten to scorer name, got {fb.name}"

    # -- Path 7: Feedback with explicit name NOT overwritten
    @scorer
    def named_scorer(outputs):
        return Feedback(name="custom_name", value=42, rationale="test")

    fb2 = named_scorer.run(outputs="x")
    assert fb2.name == "custom_name", f"Explicit feedback name should be preserved, got {fb2.name}"

    print("PASS: check_sr06_return_type_validation")


# ===========================================================================
# Main runner
# ===========================================================================
if __name__ == "__main__":
    all_checks = [
        ("SR-01", check_sr01_assessmentsourcetype_validation),
        ("SR-02", check_sr02_scorer_decorator),
        ("SR-03", check_sr03_extract_function_body),
        ("SR-04", check_sr04_recreate_function),
        ("SR-05", check_sr05_scorer_serialization),
        ("SR-06", check_sr06_return_type_validation),
    ]

    failed = 0
    for name, check_fn in all_checks:
        try:
            check_fn()
        except Exception as e:
            print(f"FAIL: {name} - {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    if failed:
        print(f"\n{failed} check(s) FAILED")
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} checks PASSED")
        sys.exit(0)
