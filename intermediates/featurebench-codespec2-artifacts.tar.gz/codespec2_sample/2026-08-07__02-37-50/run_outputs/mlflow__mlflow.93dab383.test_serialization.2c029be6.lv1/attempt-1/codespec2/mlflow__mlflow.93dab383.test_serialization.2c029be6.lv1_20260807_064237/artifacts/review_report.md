# Review Report

- Status: approved

## Findings

- None

## Coverage

| Map ID | Requirement | Architecture Spec | Behavior Spec | Native Tests | Observable? |
|--------|-------------|-------------------|---------------|-------------|-------------|
| SR-01 | AssessmentSourceType validation/standardization | PASS | PASS | 6/6 pass | Yes — all public APIs checked: constants, __init__, __str__, _parse, _standardize, deprecation, error paths |
| SR-02 | scorer decorator | PASS | PASS | 19 pass + desc tests | Yes — bare decorator, with name/description/aggregations, run() with all param combos, Feedback return, list[Feedback] return, serialization |
| SR-03 | extract_function_body | PASS | PASS | Covered in utils tests | Yes — simple, multi-line, docstring, nested, import-containing functions; body excludes def line and decorators |
| SR-04 | recreate_function | PASS (F-01 fixed) | PASS (F-01 fixed) | 23/23 pass | Yes — simple, control flow, loops, default args, type hints, regex, round-trip extract→recreate; F-01 regex escaping fixed in behavior spec |
| SR-05 | Scorer serialization lifecycle | PASS | PASS | 14/14 pass | Yes — model_dump produces SerializedScorer fields; model_validate from dict and SerializedScorer; security gate (Databricks-only) tested; error cases for non-decorator scorers |
| SR-06 | Scorer return type validation | PASS | PASS | Covered in scorer tests | Yes — bool/int/float/str/Feedback/list[Feedback]/None all accepted; dict/tuple/set/custom objects raise MlflowException; Feedback name overwrite logic verified |

**Summary**: All 6 architecture checks pass. All 6 behavior checks pass. All 62 native tests pass (16 skipped for Databricks-only paths). No findings remain. The prior F-01 (regex escaping in behavior spec SR-04) has been resolved — the behavior spec now uses correct single-backslash escaping in the `call_source` string, and the round-trip extract→recreate test for regex functions passes correctly.

**Evidence of sufficiency**: Every subrequirement has:
1. An architecture-spec check that exercises the public API call chain end-to-end
2. A behavior-spec check that tests state transitions, boundary conditions, error paths, compatibility, and repeated calls
3. Native pytest tests covering integration scenarios (e.g., `@scorer` used within `mlflow.genai.evaluate()`)
4. Observable outputs (return values, exceptions, warnings) validated against expected values derived from the task document

**Remaining uncertainty**: 
- Databricks-only deserialization path (`_reconstruct_decorator_scorer`) cannot be exercised in CI; the specs and native tests both correctly verify that security exceptions are raised outside Databricks, and the code path inside Databricks is structurally covered by `recreate_function` unit tests
- The `AssessmentSourceType` interface description uses pseudo-code notation (`{'_type': 'literal', '_value': '...'}`) for class constants, but the actual implementation uses plain Python strings — this is not a mismatch in behavior, as all tests assert `== "HUMAN"` successfully

## Risk Focus

1. **Regex/escape correctness in serialization round-trip**: The `extract_function_body` → `recreate_function` path preserves source text from the AST level. Functions with complex string escaping (regex, multi-line f-strings) rely on this preservation. The behavior spec now includes a round-trip test with a regex function, and the native `test_scorer_utils.py` suite covers 23 cases. This path should remain a regression-test focus as it is the most subtle serialization mechanism.

2. **Databricks-only security gate**: `_reconstruct_decorator_scorer` and `_check_can_be_registered` raise security errors outside Databricks environments. Any change to `is_in_databricks_runtime()` or `is_databricks_uri()` could silently change the contract. The native tests and specs correctly verify error messages contain "not supported" or "security" outside Databricks.

3. **AssessmentSourceType instance vs string duality**: Class constants are plain strings (`AssessmentSourceType.HUMAN == "HUMAN"`). Code that passes `AssessmentSourceType` instances where plain strings are expected works because `__str__` returns the string value, but `isinstance` checks would differ. The `_standardize` method always returns a plain string, not an instance, so callers receive strings.

4. **Decorator parameter filtering**: `_DecoratorScorer.__call__` and `Scorer.run()` both filter keyword arguments to match the original function's signature. If the evaluation framework adds new parameter names in the future, existing scorers will silently ignore them (no error), which is the correct behavior but could mask integration issues.

## Spec Actions

No spec changes needed. All subrequirements have adequate observable checks in both architecture and behavior specs, and the prior F-01 spec_error has been resolved. The next Spec Agent may optionally:

1. Add a behavior check for `recreate_function` with escaped characters beyond regex (e.g., newlines in string literals, backslash-heavy format strings) to further harden SR-04.
2. Add an architecture check verifying that `model_dump` preserves all `SerializedScorer` fields through a full `asdict` round-trip without data loss.
