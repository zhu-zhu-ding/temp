#!/usr/bin/env python3
"""
Behavior Spec for Assessment Source Management and Custom Scorer Framework.

Tests state transitions, input/output, boundary/error, conversion,
compatibility, and repeated-call behavior.

Subrequirements:
  SR-01: AssessmentSourceType behavior (boundary, error, deprecation, compatibility)
  SR-02: scorer decorator behavior (state transitions, edge cases)
  SR-03: extract_function_body behavior (boundary, error cases)
  SR-04: recreate_function behavior (boundary, error, type hints, indentation)
  SR-05: Scorer serialization behavior (security, round-trip, error cases)
  SR-06: Scorer return type behavior (all valid types, invalid types, edge cases)
"""

import sys
import os
import warnings

sys.path.insert(0, "/testbed")


# ===========================================================================
# SR-01: AssessmentSourceType behavior
# ===========================================================================
def check_sr01_assessmentsourcetype_behavior():
    """Test state transitions, boundaries, errors, compatibility, repeated calls."""
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
    from mlflow.exceptions import MlflowException

    # -- Boundary: case insensitivity for all valid types
    cases = [
        ("human", "HUMAN"),
        ("Human", "HUMAN"),
        ("HUMAN", "HUMAN"),
        ("llm_judge", "LLM_JUDGE"),
        ("Llm_Judge", "LLM_JUDGE"),
        ("LLM_JUDGE", "LLM_JUDGE"),
        ("code", "CODE"),
        ("Code", "CODE"),
        ("CODE", "CODE"),
        ("source_type_unspecified", "SOURCE_TYPE_UNSPECIFIED"),
        ("SOURCE_TYPE_UNSPECIFIED", "SOURCE_TYPE_UNSPECIFIED"),
    ]
    for input_val, expected in cases:
        result = AssessmentSourceType._standardize(input_val)
        assert result == expected, f"_standardize('{input_val}') should be '{expected}', got '{result}'"

    # -- Compatibility: AI_JUDGE deprecation
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        assert result == "LLM_JUDGE"
        assert len(w) == 1
        assert issubclass(w[0].category, FutureWarning)
        assert "AI_JUDGE" in str(w[0].message)
        assert "LLM_JUDGE" in str(w[0].message)

    # Also test lowercase ai_judge
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("ai_judge")
        assert result == "LLM_JUDGE"
        assert len(w) == 1
        assert issubclass(w[0].category, FutureWarning)

    # -- Error: completely invalid type
    try:
        AssessmentSourceType._standardize("NONEXISTENT_TYPE")
        assert False, "Should raise"
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e)

    # -- Error: None input
    try:
        AssessmentSourceType._standardize(None)
        assert False, "Should raise for None"
    except (MlflowException, AttributeError, TypeError):
        pass  # Should fail somehow

    # -- Repeated calls: idempotent standardization
    for _ in range(3):
        result = AssessmentSourceType._standardize("HUMAN")
        assert result == "HUMAN"

    # -- str() method
    inst = AssessmentSourceType("LLM_JUDGE")
    assert str(inst) == "LLM_JUDGE"

    # -- _parse method
    assert AssessmentSourceType._parse("HUMAN") == "HUMAN"
    assert AssessmentSourceType._parse("human") == "HUMAN"

    # -- AssessmentSource integration: source_id default
    source = AssessmentSource(source_type="CODE")
    assert source.source_type == "CODE"
    assert source.source_id == "default"

    # -- AssessmentSource equality
    s1 = AssessmentSource(source_type="HUMAN", source_id="user_1")
    s2 = AssessmentSource(source_type="HUMAN", source_id="user_1")
    s3 = AssessmentSource(source_type="LLM_JUDGE", source_id="ai_1")
    assert s1 == s2
    assert s1 != s3

    # -- to/from dictionary round-trip
    d = s1.to_dictionary()
    assert d == {"source_type": "HUMAN", "source_id": "user_1"}
    s1_restored = AssessmentSource.from_dictionary(d)
    assert s1_restored == s1

    # -- _SOURCE_TYPES list excludes AI_JUDGE
    assert "AI_JUDGE" not in AssessmentSourceType._SOURCE_TYPES

    print("PASS: check_sr01_assessmentsourcetype_behavior")


# ===========================================================================
# SR-02: scorer decorator behavior
# ===========================================================================
def check_sr02_scorer_behavior():
    """Test state transitions, edge cases for the scorer decorator."""
    from mlflow.genai.scorers import scorer
    from mlflow.genai.scorers.base import Scorer, ScorerKind, ScorerStatus, ScorerSamplingConfig
    from mlflow.entities import Feedback

    # -- Edge: scorer with no arguments (bare decorator)
    @scorer
    def bare_scorer(outputs) -> bool:
        return True

    assert isinstance(bare_scorer, Scorer)
    assert bare_scorer.name == "bare_scorer"
    assert bare_scorer.kind == ScorerKind.DECORATOR

    # -- Edge: scorer with only name
    @scorer(name="explicit_name")
    def fn1(outputs):
        return False

    assert fn1.name == "explicit_name"

    # -- Edge: scorer with aggregations
    @scorer(aggregations=["min", "max", "mean"])
    def fn2(outputs) -> float:
        return 1.0

    assert fn2.aggregations == ["min", "max", "mean"]

    # -- Edge: scorer with custom aggregation function
    def custom_agg(values):
        return sum(values) / len(values) if values else 0

    @scorer(aggregations=["mean", custom_agg])
    def fn3(outputs) -> float:
        return 1.0

    assert "mean" in fn3.aggregations
    assert custom_agg in fn3.aggregations

    # -- Edge: scorer that only takes inputs parameter
    @scorer
    def input_only(inputs):
        return len(str(inputs)) > 0

    result = input_only.run(inputs="hello")
    assert result is True

    # -- Edge: scorer returns bool
    @scorer
    def bool_return(outputs) -> bool:
        return len(outputs) > 3

    assert bool_return.run(outputs="hello") is True
    assert bool_return.run(outputs="hi") is False

    # -- Edge: scorer returns int
    @scorer
    def int_return(outputs) -> int:
        return len(outputs)

    assert int_return.run(outputs="hello") == 5

    # -- Edge: scorer returns float
    @scorer
    def float_return(outputs) -> float:
        return 0.99

    assert float_return.run(outputs="x") == 0.99

    # -- Edge: scorer returns str
    @scorer
    def str_return(outputs) -> str:
        return "good"

    assert str_return.run(outputs="x") == "good"

    # -- Repeated calls: decorator is idempotent
    for _ in range(5):
        assert bare_scorer.run(outputs="x") is True

    print("PASS: check_sr02_scorer_behavior")


# ===========================================================================
# SR-03: extract_function_body behavior
# ===========================================================================
def check_sr03_extract_behavior():
    """Test boundary/error behavior for extract_function_body."""
    from mlflow.genai.scorers.scorer_utils import extract_function_body

    # -- Boundary: function with no body (just pass)
    def empty_func():
        pass

    body, deps = extract_function_body(empty_func)
    assert isinstance(body, str)

    # -- Boundary: function with only a docstring
    def doc_only():
        """Just docs."""

    body, deps = extract_function_body(doc_only)
    assert isinstance(body, str)

    # -- Boundary: nested function (should extract top-level body)
    def outer():
        def inner():
            return 1
        return inner()

    body, deps = extract_function_body(outer)
    assert isinstance(body, str)
    assert "inner" in body

    # -- Behavior: function body does NOT include decorator or def line
    def decorated_style(x):
        # comment
        return x + 1

    body, deps = extract_function_body(decorated_style)
    assert "def " not in body
    assert "return x + 1" in body

    # -- Repeated calls: same result
    body1, _ = extract_function_body(decorated_style)
    body2, _ = extract_function_body(decorated_style)
    assert body1 == body2

    # -- function with imports inside
    def with_import(x):
        import math
        return math.sqrt(x)

    body, deps = extract_function_body(with_import)
    assert "import math" in body
    assert "math.sqrt" in body

    print("PASS: check_sr03_extract_behavior")


# ===========================================================================
# SR-04: recreate_function behavior
# ===========================================================================
def check_sr04_recreate_behavior():
    """Test boundary, error, compatibility for recreate_function."""
    from mlflow.genai.scorers.scorer_utils import recreate_function

    # -- Boundary: empty source code
    try:
        recreate_function("", "()", "empty_func")
        assert False, "Empty source should cause error"
    except (SyntaxError, IndentationError):
        pass

    # -- Boundary: source with only whitespace
    try:
        recreate_function("   \n   ", "()", "whitespace_func")
        assert False, "Whitespace-only source should cause error"
    except (SyntaxError, IndentationError):
        pass

    # -- Boundary: signature with extra whitespace
    fn = recreate_function("return a + b", "( a , b )", "add_spaces")
    assert fn(3, 7) == 10

    # -- Boundary: very long function name
    fn = recreate_function("return 1", "()", "a" * 100)
    assert fn.__name__ == "a" * 100

    # -- Error: syntax error in source
    try:
        recreate_function("if x > 0\n    return True", "(x)", "bad_syntax")
        assert False, "Should raise SyntaxError"
    except SyntaxError:
        pass

    # -- Error: undefined variable at runtime
    fn = recreate_function("return undefined_var", "()", "bad_runtime")
    try:
        fn()
        assert False, "Should raise NameError"
    except NameError:
        pass

    # -- Compatibility: function with type hints in signature
    fn = recreate_function("return x + 1", "(x: int) -> int", "typed_func")
    assert fn(5) == 6

    # -- Compatibility: function with complex signature
    fn = recreate_function(
        'if data is None:\n    data = []\nreturn f"{prefix}: {len(data)} items"',
        "(data=None, prefix='Result', suffix=None)",
        "format_result"
    )
    assert fn() == "Result: 0 items"
    assert fn([1, 2, 3], "Count") == "Count: 3 items"

    # -- Indentation handling: multi-line source
    fn = recreate_function(
        "x = 1\ny = 2\nreturn x + y",
        "()",
        "indented"
    )
    assert fn() == 3

    # -- Repeated calls: recreate same function twice
    fn1 = recreate_function("return 42", "()", "same")
    fn2 = recreate_function("return 42", "()", "same")
    assert fn1() == fn2() == 42

    # -- Using builtin modules
    fn = recreate_function(
        "import json\ndata = {'key': 'value'}\nreturn json.dumps(data)",
        "()",
        "json_test"
    )
    import json
    result = fn()
    assert json.loads(result) == {"key": "value"}

    # -- Function with regex (F-01 fix: single backslash in call_source)
    fn = recreate_function(
        "import re\nreturn len(re.findall(r'\\w+', text))",
        "(text)",
        "word_count"
    )
    assert fn("hello world") == 2

    # -- Integration round-trip: extract_function_body + recreate_function with regex
    from mlflow.genai.scorers.scorer_utils import extract_function_body

    def regex_counter(text):
        import re
        return len(re.findall(r'\w+', text))

    body, start_line = extract_function_body(regex_counter)
    assert isinstance(body, str)
    assert "re.findall" in body

    recreated = recreate_function(body, "(text)", "regex_counter")
    assert recreated("hello world") == 2
    assert recreated("one two three four") == 4
    assert recreated("") == 0

    print("PASS: check_sr04_recreate_behavior")


# ===========================================================================
# SR-05: Scorer serialization behavior
# ===========================================================================
def check_sr05_serialization_behavior():
    """Test serialization state transitions, security, error cases."""
    from mlflow.genai.scorers import scorer
    from mlflow.genai.scorers.base import Scorer, SerializedScorer
    from mlflow.entities import Feedback

    # -- State: model_dump caches result
    @scorer
    def cache_test(outputs) -> bool:
        return len(outputs) > 0

    dump1 = cache_test.model_dump()
    dump2 = cache_test.model_dump()
    assert dump1 == dump2, "model_dump should return cached result"

    # -- State: model_dump is idempotent
    assert dump1 is dump2 or dump1 == dump2

    # -- Security: reconstruction blocked outside Databricks
    serialized = SerializedScorer(
        name="test_scorer",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="test_scorer",
    )

    try:
        Scorer._reconstruct_decorator_scorer(serialized)
        # If this succeeds, we're in Databricks runtime - that's ok
    except Exception as e:
        assert "not supported" in str(e) or "security" in str(e).lower(), \
            f"Expected security restriction, got: {e}"

    # -- Error: model_validate with invalid dict
    from mlflow.exceptions import MlflowException
    try:
        Scorer.model_validate({"invalid": "data"})
        assert False, "Should raise for invalid data"
    except MlflowException:
        pass

    # -- Error: model_validate with wrong type
    try:
        Scorer.model_validate(12345)
        assert False, "Should raise for non-dict/non-SerializedScorer"
    except MlflowException:
        pass

    # -- SerializedScorer fields validation
    s = SerializedScorer(
        name="test",
        call_source="return x",
        call_signature="(x)",
        original_func_name="test_func",
    )
    assert s.name == "test"
    assert s.call_source == "return x"
    assert s.call_signature == "(x)"
    assert s.original_func_name == "test_func"
    assert s.builtin_scorer_class is None
    assert s.instructions_judge_pydantic_data is None
    # default values
    assert s.aggregations is None
    assert s.description is None
    assert s.mlflow_version is not None
    assert s.serialization_version is not None

    # -- model_dump for non-decorator scorer (base Scorer class) should error
    base_scorer = Scorer(name="base_test")
    try:
        base_scorer.model_dump()
        assert False, "Base Scorer without _original_func should fail model_dump"
    except MlflowException as e:
        assert "Unsupported scorer type" in str(e)

    print("PASS: check_sr05_serialization_behavior")


# ===========================================================================
# SR-06: Scorer return type behavior
# ===========================================================================
def check_sr06_return_behavior():
    """Test all valid/invalid return types, boundaries, edge cases."""
    from mlflow.genai.scorers import scorer
    from mlflow.entities import Feedback, AssessmentSource, AssessmentSourceType
    from mlflow.exceptions import MlflowException

    # -- Valid: bool True
    @scorer
    def return_true(outputs) -> bool:
        return True
    assert return_true.run(outputs="x") is True

    # -- Valid: bool False
    @scorer
    def return_false(outputs) -> bool:
        return False
    assert return_false.run(outputs="x") is False

    # -- Valid: int 0
    @scorer
    def return_zero(outputs) -> int:
        return 0
    assert return_zero.run(outputs="x") == 0

    # -- Valid: negative int
    @scorer
    def return_negative(outputs) -> int:
        return -1
    assert return_negative.run(outputs="x") == -1

    # -- Valid: float 0.0
    @scorer
    def return_zero_float(outputs) -> float:
        return 0.0
    assert return_zero_float.run(outputs="x") == 0.0

    # -- Valid: empty string
    @scorer
    def return_empty_str(outputs) -> str:
        return ""
    assert return_empty_str.run(outputs="x") == ""

    # -- Valid: single Feedback
    @scorer
    def single_fb(outputs):
        return Feedback(value=0.8, rationale="good")

    fb = single_fb.run(outputs="x")
    assert isinstance(fb, Feedback)
    assert fb.value == 0.8

    # -- Valid: list with single Feedback
    @scorer
    def list_one_fb(outputs):
        return [Feedback(value=1.0)]

    result = list_one_fb.run(outputs="x")
    assert isinstance(result, list)
    assert len(result) == 1

    # -- Valid: empty list (edge case - should this be allowed?)
    @scorer
    def empty_list(outputs):
        return []

    result = empty_list.run(outputs="x")
    # Empty list is a list of Feedback (vacuously true)
    assert isinstance(result, list)
    assert len(result) == 0

    # -- Invalid: tuple
    @scorer
    def return_tuple(outputs):
        return (1, 2)

    try:
        return_tuple.run(outputs="x")
        assert False, "Should raise for tuple return"
    except MlflowException:
        pass

    # -- Invalid: set
    @scorer
    def return_set(outputs):
        return {1, 2}

    try:
        return_set.run(outputs="x")
        assert False, "Should raise for set return"
    except MlflowException:
        pass

    # -- Invalid: custom object
    class CustomObj:
        pass

    @scorer
    def return_custom(outputs):
        return CustomObj()

    try:
        return_custom.run(outputs="x")
        assert False, "Should raise for custom object return"
    except MlflowException:
        pass

    # -- Feedback name override: only for default name
    @scorer
    def name_test_scorer(outputs):
        return Feedback(value=True)

    fb = name_test_scorer.run(outputs="x")
    assert fb.name == "name_test_scorer"

    # -- Feedback name NOT overridden for list
    @scorer
    def list_name_scorer(outputs):
        return [Feedback(value=True), Feedback(value=False)]

    result = list_name_scorer.run(outputs="x")
    assert result[0].name != "list_name_scorer"  # Default name "feedback" preserved

    # -- None return
    @scorer
    def none_return(outputs):
        return None

    assert none_return.run(outputs="x") is None

    # -- Return type error message contains the type name
    @scorer
    def bad_return(outputs):
        return {"a": 1}

    try:
        bad_return.run(outputs="x")
        assert False
    except MlflowException as e:
        assert "dict" in str(e).lower()

    print("PASS: check_sr06_return_behavior")


# ===========================================================================
# Main runner
# ===========================================================================
if __name__ == "__main__":
    all_checks = [
        ("SR-01", check_sr01_assessmentsourcetype_behavior),
        ("SR-02", check_sr02_scorer_behavior),
        ("SR-03", check_sr03_extract_behavior),
        ("SR-04", check_sr04_recreate_behavior),
        ("SR-05", check_sr05_serialization_behavior),
        ("SR-06", check_sr06_return_behavior),
    ]

    failed = 0
    for name, check_fn in all_checks:
        try:
            check_fn()
        except Exception as e:
            print(f"FAIL: {name} - {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    if failed:
        print(f"\n{failed} check(s) FAILED")
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} checks PASSED")
        sys.exit(0)
