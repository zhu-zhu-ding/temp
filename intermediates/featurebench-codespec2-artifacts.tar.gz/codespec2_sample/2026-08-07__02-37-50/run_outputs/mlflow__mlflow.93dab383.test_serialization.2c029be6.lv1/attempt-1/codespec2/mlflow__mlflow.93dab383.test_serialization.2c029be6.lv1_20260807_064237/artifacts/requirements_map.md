# Subrequirement Map

## SR-01: AssessmentSourceType string validation and standardization

- **Requirement**: Parse, validate, and standardize assessment source type strings with case-insensitive input, uppercase output, deprecation of AI_JUDGE, and error for invalid types.

- **Task Evidence**: "Parse, validate, and standardize assessment source types with backward compatibility for deprecated values" and Interface Description 2 describing `__init__`, `__str__`, `_parse`, `_standardize`.

- **Architecture Spec**: `check_sr01_assessmentsourcetype_validation`

- **Behavior Spec**: `check_sr01_assessmentsourcetype_behavior`

- **Critical Path**: `AssessmentSource.__post_init__` → `AssessmentSourceType._standardize(str)` → `AssessmentSourceType(str)` → `AssessmentSourceType._parse(str)` → returns standardized uppercase string.

- **Expected Intermediate State**: Input string uppercased; AI_JUDGE triggers FutureWarning and is remapped to LLM_JUDGE before validation; invalid values raise MlflowException.

- **Expected Final Output**: `str(AssessmentSourceType("human"))` returns `"HUMAN"`; `AssessmentSourceType._standardize("ai_judge")` returns `"LLM_JUDGE"` with FutureWarning; `AssessmentSourceType("INVALID")` raises MlflowException.

- **Observability**: Public APIs return predictable strings; warnings are emitted via `warnings.warn`; exceptions carry descriptive messages listing valid types.

- **Repository Evidence**: `mlflow/entities/assessment_source.py:AssessmentSourceType` (existing constants but missing methods); `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `_standardize`; `mlflow/genai/utils/trace_utils.py:196` calls `_standardize`; `tests/entities/test_assessment_source.py` tests case insensitivity, deprecation, validation.

- **Architecture Check**: `check_sr01_assessmentsourcetype_validation`

- **Behavior Check**: `check_sr01_assessmentsourcetype_behavior`

- **Uncertainties**: None. The test file `tests/entities/test_assessment_source.py` precisely defines the expected behavior including the exact FutureWarning message pattern.

---

## SR-02: scorer decorator for custom evaluation functions

- **Requirement**: Implement a `@scorer` decorator that wraps a function into a `Scorer` instance with customizable name, description, and aggregations. The decorated scorer must support serialization/deserialization and be usable in `mlflow.genai.evaluate()`.

- **Task Evidence**: "Create a flexible scorer framework supporting custom evaluation functions with serialization/deserialization capabilities" and Interface Description 1 describing the `scorer` function decorator.

- **Architecture Spec**: `check_sr02_scorer_decorator`

- **Behavior Spec**: `check_sr02_scorer_behavior`

- **Critical Path**: `@scorer` decorator → creates a `Scorer` subclass wrapping the function → `run()` method filters parameters by signature and calls function → validates return type → returns primitive/Feedback/list[Feedback].

- **Expected Intermediate State**: Decorated function becomes a `Scorer` instance; `scorer_instance.name` defaults to function name or custom name; `scorer_instance.description` is set; `scorer_instance.aggregations` is set; `scorer_instance._original_func` holds the original function; `scorer_instance.kind` is `ScorerKind.DECORATOR`.

- **Expected Final Output**: `@scorer\ndef f(outputs): return True` produces a `Scorer` where `f.run(outputs="x")` returns `True`; `f.model_dump()` returns a dict with call_source, call_signature, original_func_name; `Scorer.model_validate(dumped)` reconstructs the scorer.

- **Observability**: `model_dump()` serializes; `model_validate()` deserializes; `run()` validates return types; `__call__` raises NotImplementedError (enforced by Scorer base class).

- **Repository Evidence**: `mlflow/genai/scorers/base.py:Scorer` (base class with `model_dump`, `model_validate`, `run`, `_reconstruct_decorator_scorer`); `mlflow/genai/scorers/__init__.py` exports `scorer` in `__all__`; `tests/genai/scorers/test_scorer.py` uses `@scorer` extensively; `tests/genai/scorers/test_scorer_description.py` tests name/description/aggregations.

- **Architecture Check**: `check_sr02_scorer_decorator`

- **Behavior Check**: `check_sr02_scorer_behavior`

- **Uncertainties**: The `@scorer` decorator must produce instances whose `_original_func` attribute is correctly set for `model_dump()` to work. The exact CustomScorer class internals depend on whether it's created via `type()` dynamic class or a predefined `CustomScorer` subclass.

---

## SR-03: extract_function_body - AST-based source code extraction

- **Requirement**: Extract the body of a Python function as a source code string using AST analysis, for secure serialization of scorer functions.

- **Task Evidence**: "Provide secure serialization that handles source code extraction and reconstruction" and static analysis showing `extract_function_body` is used but not defined.

- **Architecture Spec**: `check_sr03_extract_function_body`

- **Behavior Spec**: `check_sr03_extract_behavior`

- **Critical Path**: `Scorer._extract_source_code_info()` → `extract_function_body(func)` → AST parsing → returns `(source_body_str, start_line)`.

- **Expected Intermediate State**: Function source is parsed into AST; body nodes are converted back to source text; blank lines and decorators are stripped.

- **Expected Final Output**: For `def f(x):\n    return x + 1`, `extract_function_body(f)` returns `("return x + 1", ...)`.

- **Observability**: Returned source string is valid Python that can be executed with `exec()`; function body is correctly extracted without the `def` line or decorators; round-trip with `recreate_function` preserves behavior (verified in SR-04 behavior spec integration test).

- **Repository Evidence**: `mlflow/genai/scorers/scorer_utils.py:FunctionBodyExtractor` (AST node visitor); `mlflow/genai/scorers/base.py:_extract_source_code_info` calls `extract_function_body(self._original_func)`.

- **Architecture Check**: `check_sr03_extract_function_body`

- **Behavior Check**: `check_sr03_extract_behavior`

- **Uncertainties**: The second return value is a start line number, not dependency information. The variable name `deps` in some callers is misleading.

---

## SR-04: recreate_function - dynamic function reconstruction from source

- **Requirement**: Reconstruct a callable Python function from serialized source code, signature, and function name, using `exec()` for dynamic creation.

- **Task Evidence**: "Handle dynamic function reconstruction from serialized source code" and static analysis showing `recreate_function` is used but not defined.

- **Architecture Spec**: `check_sr04_recreate_function`

- **Behavior Spec**: `check_sr04_recreate_behavior`

- **Critical Path**: `Scorer._reconstruct_decorator_scorer()` → `recreate_function(source, signature, func_name)` → `exec()` builds function → returns callable.

- **Expected Intermediate State**: Source code is properly indented; signature is parsed; function is assembled as `def {func_name}{signature}:\n{indented_source}`; `exec()` creates it in a local namespace; the function is extracted and returned.

- **Expected Final Output**: `recreate_function("return x + y", "(x, y)", "add")` returns a callable `add` where `add(3, 4) == 7` and `add.__name__ == "add"`; recreated functions with regex (`\w+`) produce correct results; round-trip through `extract_function_body` → `recreate_function` preserves behavior.

- **Observability**: Recreated function is callable; has correct `__name__`; accepts parameters matching the signature; raises SyntaxError for invalid source; raises NameError for undefined variables at call time.

- **Repository Evidence**: `mlflow/genai/scorers/scorer_utils.py:recreate_function`; `mlflow/genai/scorers/base.py:_reconstruct_decorator_scorer` calls `recreate_function(serialized.call_source, serialized.call_signature, serialized.original_func_name)`; `tests/genai/scorers/test_scorer_utils.py` extensively tests `recreate_function` with 23 tests.

- **Architecture Check**: `check_sr04_recreate_function`

- **Behavior Check**: `check_sr04_recreate_behavior`

- **Uncertainties**: The exact namespace setup during `exec()` (which imports are pre-available). The production code provides `mlflow`, `Feedback`, `AssessmentSource`, `AssessmentSourceType` in the namespace. Regex escaping in `call_source` strings requires exactly one level of backslash escaping (see L-01 in spec_skill.md).

---

## SR-05: Scorer serialization/deserialization lifecycle

- **Requirement**: Support full round-trip serialization of decorator scorers via `model_dump()` and `model_validate()`, including source code extraction and reconstruction with security checks.

- **Task Evidence**: "Enable scorer registration, lifecycle management (start/stop/update), and sampling configuration" and "Provide secure serialization that handles source code extraction and reconstruction."

- **Architecture Spec**: `check_sr05_scorer_serialization`

- **Behavior Spec**: `check_sr05_serialization_behavior`

- **Critical Path**: `scorer_instance.model_dump()` → extracts source via `_extract_source_code_info()` → returns `SerializedScorer` as dict → `Scorer.model_validate(dict)` → detects decorator scorer → `_reconstruct_decorator_scorer()` → `recreate_function()` → applies `@scorer` decorator → returns Scorer instance.

- **Expected Intermediate State**: Serialized dict contains `call_source`, `call_signature`, `original_func_name`; deserialization security check passes only in Databricks runtime; recreated function matches original behavior.

- **Expected Final Output**: Round-trip: original scorer `f(x)` returns same value as `Scorer.model_validate(f.model_dump()).run(...)`.

- **Observability**: `model_dump()` produces dict; `model_validate()` returns Scorer; security errors raised outside Databricks; original function behavior preserved.

- **Repository Evidence**: `mlflow/genai/scorers/base.py:Scorer.model_dump`, `Scorer.model_validate`, `Scorer._reconstruct_decorator_scorer`; `tests/genai/scorers/test_scorer.py` tests loading blocked for non-Databricks; `tests/genai/scorers/test_scorer_description.py` tests round-trip.

- **Architecture Check**: `check_sr05_scorer_serialization`

- **Behavior Check**: `check_sr05_serialization_behavior`

- **Uncertainties**: The exact Databricks runtime check uses `is_in_databricks_runtime()` which returns False in test; tests must account for this.

---

## SR-06: Scorer return type validation

- **Requirement**: Validate that scorer functions return one of the allowed types: bool, int, float, str, Feedback, list[Feedback], or None.

- **Task Evidence**: "Support various return types (primitives, Feedback objects, lists) from scorer functions" and "Raises: MlflowException: If the scorer function returns an unsupported type."

- **Architecture Spec**: `check_sr06_return_type_validation`

- **Behavior Spec**: `check_sr06_return_behavior`

- **Critical Path**: `scorer.run()` → calls `self(**filtered)` → checks `isinstance(result, (int, float, bool, str, Assessment, LegacyAssessment))` or list of such → raises MlflowException for unsupported types.

- **Expected Intermediate State**: Valid types pass through; Feedback with default name gets renamed to scorer name; lists of Feedback are accepted as-is.

- **Expected Final Output**: `scorer.run()` with valid return type returns the value; invalid return type raises MlflowException with descriptive message.

- **Observability**: Exception message includes the invalid type name; valid returns are unwrapped correctly; Feedback name overwrite only applies to default-named Feedback.

- **Repository Evidence**: `mlflow/genai/scorers/base.py:Scorer.run()` (existing implementation validates return types); `tests/genai/scorers/test_scorer.py` tests various return types.

- **Architecture Check**: `check_sr06_return_type_validation`

- **Behavior Check**: `check_sr06_return_behavior`

- **Uncertainties**: None. The `run()` method is already implemented in the existing code.
