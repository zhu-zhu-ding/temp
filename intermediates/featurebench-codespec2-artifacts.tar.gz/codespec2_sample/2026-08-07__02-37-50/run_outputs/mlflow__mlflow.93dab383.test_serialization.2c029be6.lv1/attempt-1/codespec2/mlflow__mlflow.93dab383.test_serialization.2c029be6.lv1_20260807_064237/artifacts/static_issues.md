## static issue

- **`mlflow/genai/scorers/base.py`** (3):
  - ? 'extract_function_body' is used but not defined or imported in this file
  - ? 'recreate_function' is used but not defined or imported in this file
  - ? 'scorer' is used but not defined or imported in this file
