# Subrequirement Map

## SR1
- **Requirement**: Standardize and validate assessment source type strings with case-insensitive handling and deprecated value migration. The `AssessmentSourceType._standardize` static method must accept any case string, convert it to uppercase, issue a `FutureWarning` when the deprecated "AI_JUDGE" value is received (converting it to "LLM_JUDGE"), validate against valid types, and raise `MlflowException` for invalid values.
- **Task Evidence**: "Handle case-insensitive input standardization and deprecated value migration with warnings" (Task → Key Challenges); Interface Description 2 requires `_standardize` with case-insensitive input, deprecation warning for AI_JUDGE → LLM_JUDGE, and validation against `_SOURCE_TYPES`.
- **Architecture Spec**: `check_sr1_assessment_source_type_standardize`
- **Behavior Spec**: `check_sr1_assessment_source_type_standardize`
- **Critical Path**: `AssessmentSourceType._standardize("ai_judge")` → uppercase "AI_JUDGE" → FutureWarning → return "LLM_JUDGE"; `AssessmentSourceType._standardize("human")` → uppercase "HUMAN" → return "HUMAN"; `AssessmentSourceType._standardize("invalid")` → raise MlflowException.
- **Expected Intermediate State**: Input string uppercased; deprecated value detected and warned.
- **Expected Final Output**: Valid uppercase source type string or raised MlflowException.
- **Observability**: Deprecation warning emitted via `warnings.warn`; returned string matches expected; exception raised for invalid input.
- **Repository Evidence**: `mlflow/entities/assessment_source.py:AssessmentSourceType` — class has `_SOURCE_TYPES`, `AI_JUDGE`, `LLM_JUDGE`, `HUMAN`, `CODE`, `SOURCE_TYPE_UNSPECIFIED` constants. `AssessmentSource.__post_init__` at line 78 calls `AssessmentSourceType._standardize(self.source_type)`. The `_standardize` method body is implemented at `mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`.
- **Architecture Check**: `check_sr1_assessment_source_type_standardize`
- **Behavior Check**: `check_sr1_assessment_source_type_standardize`

## SR2
- **Requirement**: Extract and validate experiment ID from a trace object. The `_get_experiment_id` function must check that the trace has a `trace_location`, that the location type is `MLFLOW_EXPERIMENT`, and that an `experiment_id` is present, raising `MlflowException` with appropriate messages for each failure case.
- **Task Evidence**: "Implement robust trace location validation to ensure experiment context availability" (Task → Key Challenges); Interface Description 1 specifies `_get_experiment_id(trace: Trace) -> str` with three failure modes: no trace_location, not MLFLOW_EXPERIMENT type, no experiment_id.
- **Architecture Spec**: `check_sr2_get_experiment_id`
- **Behavior Spec**: `check_sr2_get_experiment_id`
- **Critical Path**: `_get_experiment_id(trace)` → `trace.info.trace_location` → check `.type == MLFLOW_EXPERIMENT` → check `.mlflow_experiment.experiment_id` → return experiment_id str.
- **Expected Intermediate State**: Trace location type validated as MLFLOW_EXPERIMENT.
- **Expected Final Output**: Experiment ID string or raised MlflowException.
- **Observability**: Return value is experiment_id string; MlflowException raised with INVALID_PARAMETER_VALUE error code on failure.
- **Repository Evidence**: `mlflow/entities/trace.py:Trace.info: TraceInfo`; `mlflow/entities/trace_info.py:TraceInfo.trace_location: TraceLocation` and `TraceInfo.experiment_id` property; `mlflow/entities/trace_location.py:TraceLocation`, `TraceLocationType`, `MlflowExperimentLocation`; `mlflow/genai/judges/tools/get_traces_in_session.py` which delegates to `SearchTracesTool`.
- **Architecture Check**: `check_sr2_get_experiment_id`
- **Behavior Check**: `check_sr2_get_experiment_id`

## SR3
- **Requirement**: Convert MLflow Assessment objects (Expectation and Feedback) to their corresponding judge tool types (JudgeToolExpectation and JudgeToolFeedback). The `_convert_assessments_to_tool_types` function must handle both types, extract all relevant fields including error information for Feedback, and set error fields to None when absent.
- **Task Evidence**: "Convert assessment data between internal formats and tool-compatible types" (Task → Core Functionalities); "Gracefully handle conversion errors while processing multiple trace objects" (Task → Key Challenges); Interface Description 1 specifies `_convert_assessments_to_tool_types(assessments: list[Assessment]) -> list[JudgeToolExpectation | JudgeToolFeedback]`.
- **Architecture Spec**: `check_sr3_convert_assessments_to_tool_types`
- **Behavior Spec**: `check_sr3_convert_assessments_to_tool_types`
- **Critical Path**: `_convert_assessments_to_tool_types([Expectation(...), Feedback(...)])` → for Expectation: create `JudgeToolExpectation(name, source, rationale, span_id, assessment_id, value)`; for Feedback: create `JudgeToolFeedback(name, source, rationale, span_id, assessment_id, value, error_code, error_message, stack_trace, overrides, valid)`.
- **Expected Intermediate State**: Each Assessment classified as Expectation or Feedback by isinstance check.
- **Expected Final Output**: List of JudgeToolExpectation/JudgeToolFeedback with all fields populated.
- **Observability**: Output list matches input length and order; Feedback error fields are None when source Feedback has no error.
- **Repository Evidence**: `mlflow/entities/assessment.py:Expectation`, `Feedback`, `FeedbackValue`, `Assessment`; `mlflow/entities/assessment_error.py:AssessmentError`; `mlflow/entities/assessment_source.py:AssessmentSource`; `mlflow/genai/judges/tools/types.py:JudgeToolExpectation`, `JudgeToolFeedback`.
- **Architecture Check**: `check_sr3_convert_assessments_to_tool_types`
- **Behavior Check**: `check_sr3_convert_assessments_to_tool_types`

## SR4
- **Requirement**: Provide the tool definition for `SearchTracesTool` with proper JSON schema for parameters. The `get_definition` method must return a `ToolDefinition` with `FunctionToolDefinition` containing name `_search_traces`, a comprehensive description, and `ToolParamsSchema` with three optional parameters: `filter_string` (string), `order_by` (array of strings, default `['timestamp ASC']`), `max_results` (integer, default 20).
- **Task Evidence**: "Provide trace search capabilities within MLflow experiments with filtering, ordering, and result pagination" (Task → Core Functionalities); "Enable SQL-like filtering on trace attributes, tags, and metadata" (Task → Main Features); Interface Description 1 specifies `get_definition() -> ToolDefinition` with detailed parameter schema.
- **Architecture Spec**: `check_sr4_search_traces_tool_definition`
- **Behavior Spec**: `check_sr4_search_traces_tool_definition`
- **Critical Path**: `SearchTracesTool().get_definition()` → `ToolDefinition(function=FunctionToolDefinition(name=ToolNames._SEARCH_TRACES, description=..., parameters=ToolParamsSchema(...)), type="function")`.
- **Expected Intermediate State**: ToolDefinition object created with correct function name, type, and description.
- **Expected Final Output**: ToolDefinition with all parameters defined as optional, correct types, and descriptive help text.
- **Observability**: Returned ToolDefinition has function name `_search_traces`, type `function`, parameters of type `object` with three properties.
- **Repository Evidence**: `mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`, `ParamProperty`; `mlflow/genai/judges/tools/base.py:JudgeTool.get_definition` abstract method.
- **Architecture Check**: `check_sr4_search_traces_tool_definition`
- **Behavior Check**: `check_sr4_search_traces_tool_definition`

## SR5
- **Requirement**: Return the tool name identifier for `SearchTracesTool`. The `name` property must return `ToolNames._SEARCH_TRACES` (`"_search_traces"`).
- **Task Evidence**: Interface Description 1 specifies `name` property returning the tool name constant from `ToolNames._SEARCH_TRACES`.
- **Architecture Spec**: `check_sr5_search_traces_tool_name`
- **Behavior Spec**: `check_sr5_search_traces_tool_name`
- **Critical Path**: `SearchTracesTool().name` → `"_search_traces"`.
- **Expected Intermediate State**: Property access returns string.
- **Expected Final Output**: String `"_search_traces"`.
- **Observability**: Return value equals `ToolNames._SEARCH_TRACES`.
- **Repository Evidence**: `mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `mlflow/genai/judges/tools/base.py:JudgeTool.name` abstract property.
- **Architecture Check**: `check_sr5_search_traces_tool_name`
- **Behavior Check**: `check_sr5_search_traces_tool_name`

## SR6
- **Requirement**: Search for traces within the same experiment as the current trace. The `invoke` method must extract the experiment ID, call `mlflow.search_traces` with the experiment filter, convert results to `JudgeToolTraceInfo` objects, handle conversion errors gracefully, and respect `filter_string`, `order_by`, and `max_results` parameters.
- **Task Evidence**: "Provide trace search capabilities within MLflow experiments with filtering, ordering, and result pagination" (Task → Core Functionalities); "Return structured trace information including request/response data, execution metrics, and assessments" (Task → Main Features); "Gracefully handle conversion errors while processing multiple trace objects" (Task → Key Challenges); Interface Description 1 specifies `invoke(trace, filter_string, order_by, max_results) -> list[JudgeToolTraceInfo]`.
- **Architecture Spec**: `check_sr6_search_traces_invoke`
- **Behavior Spec**: `check_sr6_search_traces_invoke`
- **Critical Path**: `SearchTracesTool().invoke(trace, filter_string, order_by, max_results)` → `_get_experiment_id(trace)` → `mlflow.search_traces(experiment_ids=[exp_id], filter_string=..., max_results=..., order_by=...)` → for each Trace: extract info fields → `_convert_assessments_to_tool_types(trace.info.assessments)` → `JudgeToolTraceInfo(...)`.
- **Expected Intermediate State**: Experiment ID extracted; MLflow search_traces API called with correct parameters; results converted.
- **Expected Final Output**: List of JudgeToolTraceInfo objects; None filter_string returns all traces; errors in conversion logged and skipped.
- **Observability**: List of JudgeToolTraceInfo with correct fields; MlflowException raised for invalid trace location; conversion errors logged as warnings.
- **Repository Evidence**: `mlflow/tracing/fluent.py:search_traces()` — default `return_type=None` resolves to `"pandas"` when pandas is installed; callers that expect `list[Trace]` must pass `return_type="list"` explicitly. `mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`; `mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke()` which delegates to `SearchTracesTool().invoke()`.
- **Architecture Check**: `check_sr6_search_traces_invoke`
- **Behavior Check**: `check_sr6_search_traces_invoke`
- **Uncertainties**: The `mlflow.search_traces` default return type is `"pandas"` (DataFrame) when pandas is available. The spec mocks this call, so it cannot detect whether the production code passes `return_type="list"` explicitly. This is a known limitation of mock-based architecture testing; the integration contract must be verified separately. See skill lesson L4.
