#!/usr/bin/env python3
"""
Behavior spec for Assessment Source Management and Trace Search Tool.

Tests state transitions, input/output, boundary/error, conversion,
compatibility, and repeated-call behavior.  Uses direct assertions;
prints PASS: on success and exits nonzero when an obligation fails.
"""

import sys
import warnings


def _fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    sys.exit(1)


# ===========================================================================
# SR1 – AssessmentSourceType._standardize behavior
# ===========================================================================
def check_sr1_assessment_source_type_standardize() -> None:
    """Test all behaviors of _standardize."""
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    method = AssessmentSourceType._standardize

    # --- Case-insensitive handling ---
    assert method("human") == "HUMAN", "lowercase human"
    assert method("HUMAN") == "HUMAN", "uppercase HUMAN"
    assert method("Human") == "HUMAN", "mixed-case Human"
    assert method("llm_judge") == "LLM_JUDGE", "lowercase llm_judge"
    assert method("LLM_JUDGE") == "LLM_JUDGE", "uppercase LLM_JUDGE"
    assert method("Llm_Judge") == "LLM_JUDGE", "mixed-case Llm_Judge"
    assert method("code") == "CODE", "lowercase code"
    assert method("CODE") == "CODE", "uppercase CODE"
    assert method("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED", "lowercase unspecified"
    assert method("SOURCE_TYPE_UNSPECIFIED") == "SOURCE_TYPE_UNSPECIFIED", "uppercase unspecified"

    # --- Deprecated AI_JUDGE handling ---
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = method("AI_JUDGE")
        assert result == "LLM_JUDGE", f"AI_JUDGE should become LLM_JUDGE, got {result}"
        assert len(w) >= 1, "should emit at least one warning"
        # Check that at least one warning is a FutureWarning about deprecation
        deprecation_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        assert len(deprecation_warnings) >= 1, "should emit a FutureWarning for AI_JUDGE"

    # Lowercase ai_judge should also trigger deprecation
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = method("ai_judge")
        assert result == "LLM_JUDGE", f"ai_judge should become LLM_JUDGE, got {result}"
        assert len(w) >= 1, "should emit warning for lowercase ai_judge too"

    # --- Invalid values ---
    for invalid in ("INVALID", "RANDOM", "", "123", "nonexistent"):
        try:
            method(invalid)
            _fail(f"_standardize({invalid!r}) should have raised MlflowException")
        except MlflowException:
            pass  # expected

    # --- Repeated calls (idempotency) ---
    for _ in range(5):
        assert method("HUMAN") == "HUMAN"
        assert method("code") == "CODE"

    print("PASS: SR1 – AssessmentSourceType._standardize behavior")


# ===========================================================================
# SR2 – _get_experiment_id behavior
# ===========================================================================
def check_sr2_get_experiment_id() -> None:
    """Test all behaviors of _get_experiment_id."""
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.exceptions import MlflowException

    # --- Valid trace with MLFLOW_EXPERIMENT ---
    loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="my-exp-123"),
    )
    ti = TraceInfo(trace_id="t1", trace_location=loc, request_time=1000, state=TraceState.OK)
    t = Trace(info=ti, data=TraceData())
    assert _get_experiment_id(t) == "my-exp-123"

    # --- Different experiment IDs ---
    loc2 = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="another-exp"),
    )
    ti2 = TraceInfo(trace_id="t2", trace_location=loc2, request_time=2000, state=TraceState.OK)
    t2 = Trace(info=ti2, data=TraceData())
    assert _get_experiment_id(t2) == "another-exp"

    # --- Non-MLFLOW_EXPERIMENT type: INFERENCE_TABLE ---
    it_loc = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="cat.schema.table"),
    )
    ti_it = TraceInfo(trace_id="t3", trace_location=it_loc, request_time=3000, state=TraceState.OK)
    t_it = Trace(info=ti_it, data=TraceData())
    try:
        _get_experiment_id(t_it)
        _fail("Should raise for INFERENCE_TABLE location")
    except MlflowException:
        pass

    # --- Non-MLFLOW_EXPERIMENT type: UC_SCHEMA ---
    uc_loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    ti_uc = TraceInfo(trace_id="t4", trace_location=uc_loc, request_time=4000, state=TraceState.OK)
    t_uc = Trace(info=ti_uc, data=TraceData())
    try:
        _get_experiment_id(t_uc)
        _fail("Should raise for UC_SCHEMA location")
    except MlflowException:
        pass

    # --- TRACE_LOCATION_TYPE_UNSPECIFIED ---
    us_loc = TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    ti_us = TraceInfo(trace_id="t5", trace_location=us_loc, request_time=5000, state=TraceState.OK)
    t_us = Trace(info=ti_us, data=TraceData())
    try:
        _get_experiment_id(t_us)
        _fail("Should raise for TRACE_LOCATION_TYPE_UNSPECIFIED location")
    except MlflowException:
        pass

    # --- MLFLOW_EXPERIMENT type but mlflow_experiment is None ---
    none_exp_loc = TraceLocation(type=TraceLocationType.MLFLOW_EXPERIMENT, mlflow_experiment=None)
    ti_ne = TraceInfo(trace_id="t6", trace_location=none_exp_loc, request_time=6000,
                      state=TraceState.OK)
    t_ne = Trace(info=ti_ne, data=TraceData())
    try:
        _get_experiment_id(t_ne)
        _fail("Should raise when mlflow_experiment is None")
    except MlflowException:
        pass

    # --- Repeated calls (idempotency) ---
    for _ in range(3):
        assert _get_experiment_id(t) == "my-exp-123"

    print("PASS: SR2 – _get_experiment_id behavior")


# ===========================================================================
# SR3 – _convert_assessments_to_tool_types behavior
# ===========================================================================
def check_sr3_convert_assessments_to_tool_types() -> None:
    """Test all conversion behaviors."""
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.entities.assessment import Expectation, Feedback, AssessmentError
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
    from mlflow.genai.judges.tools.types import JudgeToolExpectation, JudgeToolFeedback

    source = AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="gpt-4")

    # --- Convert Expectation ---
    exp = Expectation(
        name="accuracy",
        source=source,
        value="high",
        rationale="Correct answer",
        span_id="s1",
    )
    exp.assessment_id = "a1"
    results = _convert_assessments_to_tool_types([exp])
    assert len(results) == 1
    je = results[0]
    assert isinstance(je, JudgeToolExpectation)
    assert je.name == "accuracy"
    assert je.source == "gpt-4"
    assert je.rationale == "Correct answer"
    assert je.span_id == "s1"
    assert je.assessment_id == "a1"
    assert je.value == "high"

    # --- Convert Feedback (without error) ---
    fb = Feedback(
        name="quality",
        source=source,
        value=4,
        rationale="Good work",
        span_id="s2",
    )
    fb.assessment_id = "a2"
    results2 = _convert_assessments_to_tool_types([fb])
    assert len(results2) == 1
    jf = results2[0]
    assert isinstance(jf, JudgeToolFeedback)
    assert jf.name == "quality"
    assert jf.source == "gpt-4"
    assert jf.rationale == "Good work"
    assert jf.span_id == "s2"
    assert jf.assessment_id == "a2"
    assert jf.value == 4
    # Error fields should be None when no error
    assert jf.error_code is None
    assert jf.error_message is None
    assert jf.stack_trace is None
    # overrides and valid
    assert jf.overrides is None
    assert jf.valid is None

    # --- Convert Feedback WITH error ---
    err = AssessmentError(error_code="E001", error_message="bad", stack_trace="line 1")
    fb_err = Feedback(name="safety", source=source, value=None, rationale="failed",
                      span_id="s3", error=err)
    fb_err.assessment_id = "a3"
    results3 = _convert_assessments_to_tool_types([fb_err])
    assert len(results3) == 1
    jf2 = results3[0]
    assert isinstance(jf2, JudgeToolFeedback)
    assert jf2.error_code == "E001"
    assert jf2.error_message == "bad"
    assert jf2.stack_trace == "line 1"

    # --- Convert mixed list, preserving order ---
    results4 = _convert_assessments_to_tool_types([exp, fb, fb_err])
    assert len(results4) == 3
    assert isinstance(results4[0], JudgeToolExpectation)
    assert isinstance(results4[1], JudgeToolFeedback)
    assert isinstance(results4[2], JudgeToolFeedback)
    assert results4[0].name == "accuracy"
    assert results4[1].name == "quality"
    assert results4[2].name == "safety"

    # --- Empty list ---
    assert _convert_assessments_to_tool_types([]) == []

    # --- Expectation with None rationale and span_id ---
    exp2 = Expectation(name="bare", source=source, value=True)
    results5 = _convert_assessments_to_tool_types([exp2])
    assert len(results5) == 1
    je2 = results5[0]
    assert je2.rationale is None
    assert je2.span_id is None
    assert je2.assessment_id is None
    assert je2.value is True

    # --- Feedback with overrides ---
    fb_override = Feedback(name="final", source=source, value=3)
    fb_override.overrides = "a1"
    fb_override.valid = True
    results6 = _convert_assessments_to_tool_types([fb_override])
    assert results6[0].overrides == "a1"
    assert results6[0].valid is True

    print("PASS: SR3 – _convert_assessments_to_tool_types behavior")


# ===========================================================================
# SR4 – SearchTracesTool.get_definition behavior
# ===========================================================================
def check_sr4_search_traces_tool_definition() -> None:
    """Test get_definition returns a correctly shaped definition."""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.constants import ToolNames
    from mlflow.types.llm import ToolDefinition, FunctionToolDefinition, ToolParamsSchema

    tool = SearchTracesTool()
    d = tool.get_definition()

    # --- Top-level shape ---
    assert isinstance(d, ToolDefinition)
    assert d.type == "function"

    # --- Function definition ---
    fd = d.function
    assert isinstance(fd, FunctionToolDefinition)
    assert fd.name == ToolNames._SEARCH_TRACES
    assert fd.name == "_search_traces"
    # Description must mention the tool's capabilities
    assert len(fd.description) > 20, "description too short"
    assert "search" in fd.description.lower() or "trace" in fd.description.lower()

    # --- Parameters ---
    params = fd.parameters
    assert isinstance(params, ToolParamsSchema)
    assert params.type == "object"
    # All parameters should be optional
    assert not params.required or len(params.required) == 0

    # --- Parameter properties ---
    props = params.properties
    assert "filter_string" in props
    assert "order_by" in props
    assert "max_results" in props

    # filter_string
    fs = props["filter_string"]
    assert fs.type == "string"
    assert len(fs.description) > 10, "filter_string description too short"

    # order_by
    ob = props["order_by"]
    assert ob.type == "array"
    assert ob.items is not None
    assert ob.items.type == "string"

    # max_results
    mr = props["max_results"]
    assert mr.type == "integer"

    # --- Repeated calls produce identical structure ---
    d2 = tool.get_definition()
    assert d2.function.name == d.function.name
    assert d2.type == d.type

    print("PASS: SR4 – SearchTracesTool.get_definition behavior")


# ===========================================================================
# SR5 – SearchTracesTool.name behavior
# ===========================================================================
def check_sr5_search_traces_tool_name() -> None:
    """Test the name property behavior."""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.constants import ToolNames

    tool = SearchTracesTool()
    assert tool.name == "_search_traces"
    assert tool.name == ToolNames._SEARCH_TRACES
    assert isinstance(tool.name, str)

    # Repeated access returns same value
    for _ in range(5):
        assert tool.name == "_search_traces"

    # Different instances return same name
    tool2 = SearchTracesTool()
    assert tool2.name == tool.name

    print("PASS: SR5 – SearchTracesTool.name behavior")


# ===========================================================================
# SR6 – SearchTracesTool.invoke behavior
# ===========================================================================
def check_sr6_search_traces_invoke() -> None:
    """Test invoke behavior: parameter forwarding, result conversion, errors."""
    from unittest.mock import patch, MagicMock

    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.entities.trace import Trace
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo
    from mlflow.exceptions import MlflowException

    # Build trace with experiment context
    location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-test"),
    )
    trace_info = TraceInfo(
        trace_id="current-trace",
        trace_location=location,
        request_time=9999,
        state=TraceState.OK,
        execution_duration=500,
    )
    trace = Trace(info=trace_info, data=TraceData())

    tool = SearchTracesTool()

    # --- Helper to build mock search results ---
    def _make_mock_trace(trace_id, request_time, state, request, response,
                         execution_duration, assessments):
        mt = MagicMock()
        mt.info.trace_id = trace_id
        mt.info.request_time = request_time
        mt.info.state = state
        mt.data.request = request
        mt.data.response = response
        mt.info.execution_duration = execution_duration
        mt.info.assessments = assessments
        return mt

    # --- Successful search with results ---
    mock_t1 = _make_mock_trace("t-a", 1000, TraceState.OK, '{"in":1}', '{"out":2}', 50, [])
    mock_t2 = _make_mock_trace("t-b", 2000, TraceState.ERROR, '{"in":3}', '{"out":4}', 75, [])

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[mock_t1, mock_t2]) as mock_search:
        results = tool.invoke(trace, max_results=10)

        assert len(results) == 2
        assert isinstance(results[0], JudgeToolTraceInfo)
        assert isinstance(results[1], JudgeToolTraceInfo)

        r0, r1 = results[0], results[1]
        assert r0.trace_id == "t-a"
        assert r0.request_time == 1000
        assert r0.state == TraceState.OK
        assert r0.request == '{"in":1}'
        assert r0.response == '{"out":2}'
        assert r0.execution_duration == 50
        assert r0.assessments == []

        assert r1.trace_id == "t-b"
        assert r1.state == TraceState.ERROR
        assert r1.execution_duration == 75

        # Verify search args
        mock_search.assert_called_once()
        kwargs = mock_search.call_args.kwargs
        assert kwargs["experiment_ids"] == ["exp-test"]
        assert kwargs["max_results"] == 10
        assert kwargs["order_by"] == ["timestamp ASC"]
        assert kwargs["filter_string"] is None

    # --- filter_string passed through ---
    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[]) as mock_search2:
        tool.invoke(trace, filter_string='status = "OK" AND execution_time_ms > 100')
        assert mock_search2.call_args.kwargs["filter_string"] == 'status = "OK" AND execution_time_ms > 100'

    # --- order_by passed through ---
    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[]) as mock_search3:
        tool.invoke(trace, order_by=["execution_time_ms DESC", "timestamp ASC"])
        assert mock_search3.call_args.kwargs["order_by"] == ["execution_time_ms DESC", "timestamp ASC"]

    # --- Empty results ---
    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[]) as mock_search4:
        results = tool.invoke(trace)
        assert results == []

    # --- Error on invalid trace (non-experiment) ---
    bad_location = TraceLocation(type=TraceLocationType.UC_SCHEMA)
    bad_ti = TraceInfo(trace_id="bad", trace_location=bad_location, request_time=0, state=TraceState.OK)
    bad_trace = Trace(info=bad_ti, data=TraceData())
    try:
        tool.invoke(bad_trace)
        _fail("Should raise MlflowException for non-MLFLOW_EXPERIMENT trace")
    except MlflowException:
        pass

    # --- Graceful handling of conversion errors ---
    # A trace whose info.assessments raises during conversion should be skipped
    mock_bad = _make_mock_trace("bad-trace", 3000, TraceState.OK, '{}', '{}', 0, [])
    # Make assessments contain a non-Assessment object that will cause
    # AttributeError when _convert_assessments_to_tool_types tries to access .source
    mock_bad.info.assessments = ['not_an_assessment']

    import logging
    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[mock_bad]):
        # Should log warning and skip the bad trace, not crash
        with patch.object(logging.getLogger("mlflow.genai.judges.tools.search_traces"),
                          "warning") as mock_warn:
            results = tool.invoke(trace)
            # The bad trace should have been skipped
            assert results == []
            mock_warn.assert_called()

    # --- Default parameters ---
    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[]) as mock_search5:
        tool.invoke(trace)
        kwargs = mock_search5.call_args.kwargs
        assert kwargs["filter_string"] is None
        assert kwargs["order_by"] == ["timestamp ASC"]
        assert kwargs["max_results"] == 20

    # --- max_results boundary: 0 should be allowed (returns empty) ---
    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[]) as mock_search6:
        results = tool.invoke(trace, max_results=0)
        assert results == []

    # --- max_results large value ---
    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=[]) as mock_search7:
        tool.invoke(trace, max_results=1000)
        assert mock_search7.call_args.kwargs["max_results"] == 1000

    print("PASS: SR6 – SearchTracesTool.invoke behavior")


# ===========================================================================
# Runner
# ===========================================================================
if __name__ == "__main__":
    check_sr1_assessment_source_type_standardize()
    check_sr2_get_experiment_id()
    check_sr3_convert_assessments_to_tool_types()
    check_sr4_search_traces_tool_definition()
    check_sr5_search_traces_tool_name()
    check_sr6_search_traces_invoke()
    print("All behavior checks passed.")
