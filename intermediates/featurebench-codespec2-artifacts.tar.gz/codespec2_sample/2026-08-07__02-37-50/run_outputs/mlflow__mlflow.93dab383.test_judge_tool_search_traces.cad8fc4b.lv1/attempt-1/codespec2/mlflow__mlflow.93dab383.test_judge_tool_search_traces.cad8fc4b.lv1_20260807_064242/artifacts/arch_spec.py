#!/usr/bin/env python3
"""
Architecture spec for Assessment Source Management and Trace Search Tool.

Exercises the real integration paths: imports, call chains, helper/dispatcher
patterns, and observable results.  This spec only verifies that the required
interfaces exist, are callable, and connect the public surface to the expected
internal helpers.  It does **not** test correctness of business logic — that
is the behavior spec's job.
"""

import sys
import warnings


def _fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    sys.exit(1)


# ---------------------------------------------------------------------------
# SR1 – AssessmentSourceType._standardize integration path
# ---------------------------------------------------------------------------
def check_sr1_assessment_source_type_standardize() -> None:
    """Verify that _standardize exists on AssessmentSourceType and is callable."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    # 1. Symbol must exist
    if not hasattr(AssessmentSourceType, "_standardize"):
        _fail("SR1: AssessmentSourceType._standardize is missing")

    method = AssessmentSourceType._standardize

    # 2. It must be a staticmethod (decorated or descriptor)
    #    We check by calling via the class without an instance.
    try:
        result = method("human")
    except Exception:
        _fail("SR1: _standardize('human') raised unexpectedly")

    if not isinstance(result, str):
        _fail(f"SR1: _standardize returned {type(result)} instead of str")

    # 3. Case-insensitive → uppercase
    if result != "HUMAN":
        _fail(f"SR1: _standardize('human') returned {result!r}, expected 'HUMAN'")

    # 4. Valid value
    try:
        result2 = method("code")
    except Exception:
        _fail("SR1: _standardize('code') raised unexpectedly")
    if result2 != "CODE":
        _fail(f"SR1: _standardize('code') returned {result2!r}, expected 'CODE'")

    # 5. Deprecated AI_JUDGE path (must issue warning and return LLM_JUDGE)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result3 = method("AI_JUDGE")
        if result3 != "LLM_JUDGE":
            _fail(f"SR1: _standardize('AI_JUDGE') returned {result3!r}, expected 'LLM_JUDGE'")
        if not any("deprecated" in str(warning.message).lower() or "ai_judge" in str(warning.message).lower()
                   for warning in w):
            _fail("SR1: _standardize('AI_JUDGE') did not emit a deprecation warning")

    # 6. Invalid value must raise
    from mlflow.exceptions import MlflowException
    try:
        method("INVALID_TYPE_XYZ")
        _fail("SR1: _standardize('INVALID_TYPE_XYZ') did not raise")
    except MlflowException:
        pass  # expected

    print("PASS: SR1 – AssessmentSourceType._standardize integration")


# ---------------------------------------------------------------------------
# SR2 – _get_experiment_id integration path
# ---------------------------------------------------------------------------
def check_sr2_get_experiment_id() -> None:
    """Verify _get_experiment_id exists and raises/returns as expected."""
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    # 1. Symbol must exist
    if _get_experiment_id is None:
        _fail("SR2: _get_experiment_id is not defined")
    if not callable(_get_experiment_id):
        _fail("SR2: _get_experiment_id is not callable")

    # 2. Build a valid trace and verify it returns the experiment_id
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState

    location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-42"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=location,
        request_time=1000,
        state=TraceState.OK,
    )
    trace = Trace(info=trace_info, data=TraceData())

    exp_id = _get_experiment_id(trace)
    if exp_id != "exp-42":
        _fail(f"SR2: _get_experiment_id returned {exp_id!r}, expected 'exp-42'")

    # 3. Verify that a trace without experiment raises
    from mlflow.exceptions import MlflowException

    # UC_SCHEMA location (not MLFLOW_EXPERIMENT)
    uc_location = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
    )
    bad_info = TraceInfo(
        trace_id="tr-2",
        trace_location=uc_location,
        request_time=1000,
        state=TraceState.OK,
    )
    bad_trace = Trace(info=bad_info, data=TraceData())
    try:
        _get_experiment_id(bad_trace)
        _fail("SR2: _get_experiment_id did not raise for non-MLFLOW_EXPERIMENT trace")
    except MlflowException:
        pass  # expected

    print("PASS: SR2 – _get_experiment_id integration")


# ---------------------------------------------------------------------------
# SR3 – _convert_assessments_to_tool_types integration path
# ---------------------------------------------------------------------------
def check_sr3_convert_assessments_to_tool_types() -> None:
    """Verify _convert_assessments_to_tool_types exists and is callable."""
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types

    if _convert_assessments_to_tool_types is None:
        _fail("SR3: _convert_assessments_to_tool_types is not defined")
    if not callable(_convert_assessments_to_tool_types):
        _fail("SR3: _convert_assessments_to_tool_types is not callable")

    # Create a real Expectation and verify conversion
    from mlflow.entities.assessment import Expectation, Feedback
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
    from mlflow.genai.judges.tools.types import JudgeToolExpectation, JudgeToolFeedback

    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="user1")
    exp = Expectation(
        name="correctness",
        source=source,
        value="yes",
        rationale="Looks good",
        span_id="span-1",
    )

    result = _convert_assessments_to_tool_types([exp])
    if not isinstance(result, list):
        _fail(f"SR3: result is not a list, got {type(result)}")
    if len(result) != 1:
        _fail(f"SR3: expected 1 result, got {len(result)}")
    if not isinstance(result[0], JudgeToolExpectation):
        _fail(f"SR3: expected JudgeToolExpectation, got {type(result[0])}")

    # Create a Feedback and verify conversion
    fb = Feedback(
        name="quality",
        source=source,
        value=4,
        rationale="Decent",
    )
    result2 = _convert_assessments_to_tool_types([fb])
    if len(result2) != 1:
        _fail(f"SR3: expected 1 result, got {len(result2)}")
    if not isinstance(result2[0], JudgeToolFeedback):
        _fail(f"SR3: expected JudgeToolFeedback, got {type(result2[0])}")
    # Error fields should be None
    jf = result2[0]
    if jf.error_code is not None or jf.error_message is not None or jf.stack_trace is not None:
        _fail("SR3: Feedback error fields should be None when no error")

    # Both types together
    result3 = _convert_assessments_to_tool_types([exp, fb])
    if len(result3) != 2:
        _fail(f"SR3: expected 2 results, got {len(result3)}")
    if not isinstance(result3[0], JudgeToolExpectation):
        _fail(f"SR3: first should be JudgeToolExpectation, got {type(result3[0])}")
    if not isinstance(result3[1], JudgeToolFeedback):
        _fail(f"SR3: second should be JudgeToolFeedback, got {type(result3[1])}")

    # Empty list
    result4 = _convert_assessments_to_tool_types([])
    if result4 != []:
        _fail(f"SR3: empty list should return empty list, got {result4}")

    print("PASS: SR3 – _convert_assessments_to_tool_types integration")


# ---------------------------------------------------------------------------
# SR4 – SearchTracesTool.get_definition integration path
# ---------------------------------------------------------------------------
def check_sr4_search_traces_tool_definition() -> None:
    """Verify get_definition returns a valid ToolDefinition."""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.constants import ToolNames
    from mlflow.types.llm import ToolDefinition, FunctionToolDefinition, ToolParamsSchema

    tool = SearchTracesTool()
    definition = tool.get_definition()

    if not isinstance(definition, ToolDefinition):
        _fail(f"SR4: definition is {type(definition)}, expected ToolDefinition")
    if definition.type != "function":
        _fail(f"SR4: definition type is {definition.type!r}, expected 'function'")

    fd = definition.function
    if not isinstance(fd, FunctionToolDefinition):
        _fail(f"SR4: function is {type(fd)}, expected FunctionToolDefinition")
    if fd.name != ToolNames._SEARCH_TRACES:
        _fail(f"SR4: function name is {fd.name!r}, expected {ToolNames._SEARCH_TRACES!r}")

    params = fd.parameters
    if not isinstance(params, ToolParamsSchema):
        _fail(f"SR4: parameters is {type(params)}, expected ToolParamsSchema")
    if params.type != "object":
        _fail(f"SR4: parameters type is {params.type!r}, expected 'object'")

    # All three parameters should be present and optional (not in required)
    props = params.properties
    required_set = set(params.required or [])
    for name in ("filter_string", "order_by", "max_results"):
        if name not in props:
            _fail(f"SR4: missing parameter '{name}' in properties")
        if name in required_set:
            _fail(f"SR4: '{name}' should NOT be required")

    print("PASS: SR4 – SearchTracesTool.get_definition integration")


# ---------------------------------------------------------------------------
# SR5 – SearchTracesTool.name integration path
# ---------------------------------------------------------------------------
def check_sr5_search_traces_tool_name() -> None:
    """Verify the name property returns the correct constant."""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.constants import ToolNames

    tool = SearchTracesTool()
    n = tool.name
    if n != ToolNames._SEARCH_TRACES:
        _fail(f"SR5: name returned {n!r}, expected {ToolNames._SEARCH_TRACES!r}")
    if not isinstance(n, str):
        _fail(f"SR5: name is {type(n)}, expected str")

    print("PASS: SR5 – SearchTracesTool.name integration")


# ---------------------------------------------------------------------------
# SR6 – SearchTracesTool.invoke integration path
# ---------------------------------------------------------------------------
def check_sr6_search_traces_invoke() -> None:
    """Verify invoke exists, extracts experiment_id, and calls search_traces."""
    from unittest.mock import patch, MagicMock

    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.entities.trace import Trace
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo

    # Build trace with experiment context
    location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=location,
        request_time=1000,
        state=TraceState.OK,
    )
    trace = Trace(info=trace_info, data=TraceData())

    tool = SearchTracesTool()

    # Mock mlflow.search_traces to return a list with one trace.
    # NOTE: Use plain MagicMock() rather than MagicMock(spec=Trace) because
    # Trace is a dataclass whose fields (info, data) are descriptor-based and
    # not discoverable via dir(), causing MagicMock(spec=Trace) to block all
    # attribute access.
    mock_result_trace = MagicMock()
    mock_result_trace.info.trace_id = "found-tr-1"
    mock_result_trace.info.request_time = 2000
    mock_result_trace.info.state = TraceState.OK
    mock_result_trace.data.request = '{"q": "hello"}'
    mock_result_trace.data.response = '{"a": "hi"}'
    mock_result_trace.info.execution_duration = 100
    mock_result_trace.info.assessments = []

    mock_paged_list = [mock_result_trace]

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces",
               return_value=mock_paged_list) as mock_search:
        results = tool.invoke(trace, filter_string='status = "OK"',
                              order_by=["timestamp DESC"], max_results=5)

        # Verify search_traces was called with correct args
        mock_search.assert_called_once()
        call_kwargs = mock_search.call_args.kwargs
        if call_kwargs.get("experiment_ids") != ["exp-1"]:
            _fail(f"SR6: experiment_ids not passed correctly: {call_kwargs}")
        if call_kwargs.get("filter_string") != 'status = "OK"':
            _fail(f"SR6: filter_string not passed correctly: {call_kwargs}")
        if call_kwargs.get("order_by") != ["timestamp DESC"]:
            _fail(f"SR6: order_by not passed correctly: {call_kwargs}")
        if call_kwargs.get("max_results") != 5:
            _fail(f"SR6: max_results not passed correctly: {call_kwargs}")

        # Verify return type
        if not isinstance(results, list):
            _fail(f"SR6: invoke returned {type(results)}, expected list")
        if len(results) != 1:
            _fail(f"SR6: expected 1 result, got {len(results)}")
        if not isinstance(results[0], JudgeToolTraceInfo):
            _fail(f"SR6: result[0] is {type(results[0])}, expected JudgeToolTraceInfo")

        # Verify default values for optional params
        mock_search.reset_mock()
        mock_search.return_value = []
        results2 = tool.invoke(trace)
        call_kwargs2 = mock_search.call_args.kwargs
        if call_kwargs2.get("filter_string") is not None:
            _fail("SR6: filter_string should be None by default")
        if call_kwargs2.get("order_by") != ["timestamp ASC"]:
            _fail(f"SR6: default order_by should be ['timestamp ASC'], got {call_kwargs2.get('order_by')}")
        if call_kwargs2.get("max_results") != 20:
            _fail(f"SR6: default max_results should be 20, got {call_kwargs2.get('max_results')}")

    print("PASS: SR6 – SearchTracesTool.invoke integration")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    check_sr1_assessment_source_type_standardize()
    check_sr2_get_experiment_id()
    check_sr3_convert_assessments_to_tool_types()
    check_sr4_search_traces_tool_definition()
    check_sr5_search_traces_tool_name()
    check_sr6_search_traces_invoke()
    print("All architecture checks passed.")
