# Review Report

- Status: approved

## Findings

### F-01: Behavior spec SR-13 has import-order bug (spec_error, not code defect)

- Category: spec_error
- Subrequirements: SR-13
- Evidence: Running `behavior_spec.py::check_sr13_behavior` raises `UnboundLocalError: cannot access local variable 'dump_span_attribute_value' where it is not associated with a value` at line 509. The spec imports `from mlflow.tracing.utils import dump_span_attribute_value` *inside* the function body *after* the variable is used at line 509, causing Python to treat it as a local variable before assignment.
- Cause: The behavior spec has a local import statement placed after the first usage site, which creates a compile-time local-variable binding that shadows the module-level import. This is a pure spec defect—the production code at `/testbed/mlflow/entities/span.py:906-909` correctly implements `_CachedSpanAttributesRegistry.set()` raising `MlflowException`. The architecture spec `check_sr13_arch` passes, and manual testing confirms the behavior.
- Impact: The behavior spec cannot validate SR-13 as written, though the architecture spec and manual testing confirm the implementation is correct.
- Recommended Spec Change: Move the `from mlflow.tracing.utils import dump_span_attribute_value` import to the top of `check_sr13_behavior` (before line 509 where it is first used), or add it alongside the existing function-level import at line 506.

### F-02: Static analysis false positives (not real defects)

- Category: incomplete_spec
- Subrequirements: SR-11, SR-14
- Evidence: `static_issues.md` reports 5 undefined symbols: `_decode_id_from_byte`, `_is_base64_encoded`, `apply_span_processors` (all in span.py), `_get_truncated_preview`, and `create_mlflow_span`. All five are actually defined or imported—the first two are defined at lines 470/476 in the same file (span.py), `apply_span_processors` is imported at line 41, and `_get_truncated_preview` and `create_mlflow_span` are properly defined/imported elsewhere. These are false positives from a static analyzer that does not resolve forward references within the same module or follow re-exports.
- Cause: The static analyzer used to generate `static_issues.md` does not see function definitions that appear later in the same file, nor does it follow imports in other modules.
- Impact: None—these are not actual code defects. All functions resolve correctly at runtime, as confirmed by spec execution and pytest results.
- Recommended Spec Change: None required for production code. The static issue list can be ignored or the analysis tool configured to handle same-file forward references.

## Coverage

### SR-01: `_Trace.to_mlflow_trace()` conversion
- Observable: Yes. arch_spec `check_sr01_arch` passes; behavior_spec `check_sr01_behavior` passes. pytest `test_add_spans` verifies `not isinstance(trace.data.spans[0], LiveSpan)`. Manual testing confirms root span inputs/outputs propagate to previews.

### SR-02: `LiveSpan.from_dict()` raises NotImplementedError
- Observable: Yes. arch_spec `check_sr02_arch` passes; behavior_spec `check_sr02_behavior` passes. The method raises for all inputs (empty dict, populated dict).

### SR-03: `LiveSpan.set_span_type()` sets span type attribute
- Observable: Yes. arch_spec `check_sr03_arch` passes; behavior_spec `check_sr03_behavior` passes. Verified transitions: UNKNOWN → LLM → CUSTOM_OPERATION → CHAIN.

### SR-04: `LiveSpan.to_immutable_span()` conversion
- Observable: Yes. arch_spec `check_sr04_arch` passes; behavior_spec `check_sr04_behavior` passes. Verified type, span_id, name, inputs, outputs preservation; multiple calls produce distinct Span objects.

### SR-05: `NoOpSpan` interface completeness
- Observable: Yes. arch_spec `check_sr05_arch` passes; behavior_spec `check_sr05_behavior` passes. All 14 required properties/methods verified: trace_id returns `"MLFLOW_NO_OP_SPAN_TRACE_ID"`, `_trace_id` returns None, all setters and `end()`/`add_event()` are no-ops.

### SR-06: `Span.attributes` returns deserialized dict
- Observable: Yes. arch_spec `check_sr06_arch` passes; behavior_spec `check_sr06_behavior` passes. Verified string, int, list, dict, bool deserialization and caching on second access.

### SR-07: `Span.events` returns list of SpanEvent
- Observable: Yes. arch_spec `check_sr07_arch` passes; behavior_spec `check_sr07_behavior` passes. Verified empty-list default, correct SpanEvent wrapping with name/timestamp.

### SR-08: `Span.from_otel_proto()` creates Span from protobuf
- Observable: Yes. arch_spec `check_sr08_arch` passes; behavior_spec `check_sr08_behavior` passes. Verified name, span_type, trace_id, start/end times, inputs, and events extraction.

### SR-09: `Span.request_id` is alias for `trace_id`
- Observable: Yes. arch_spec `check_sr09_arch` passes; behavior_spec `check_sr09_behavior` passes. Verified `request_id == trace_id` and `isinstance(request_id, str)`.

### SR-10: `Span.span_type` returns span type from attributes
- Observable: Yes. arch_spec `check_sr10_arch` passes; behavior_spec `check_sr10_behavior` passes. Verified set case returns type, unset case returns None.

### SR-11: `Span.to_dict()` serializes to dict with base64-encoded IDs
- Observable: Yes. arch_spec `check_sr11_arch` passes; behavior_spec `check_sr11_behavior` passes. Verified base64-encoded trace_id (16 bytes), span_id (8 bytes), parent_span_id (8 bytes), status code/message, events, and attributes.

### SR-12: `Span.to_otel_proto()` converts to OTelProtoSpan
- Observable: Yes. arch_spec `check_sr12_arch` passes; behavior_spec `check_sr12_behavior` passes. Verified trace_id/span_id byte lengths, name, start/end times, events, and attributes.

### SR-13: `_CachedSpanAttributesRegistry.set()` raises error
- Observable: Yes (arch spec) / Spec-broken (behavior spec). arch_spec `check_sr13_arch` passes. behavior_spec `check_sr13_behavior` fails due to spec-level import-order bug (see F-01). Manual testing confirms `MlflowException` is raised and `get()` + caching works correctly.

### SR-14: `create_mlflow_span()` factory function
- Observable: Yes. arch_spec `check_sr14_arch` passes; behavior_spec `check_sr14_behavior` passes. Verified NonRecordingSpan→NoOpSpan, None→NoOpSpan, OTelSpan→LiveSpan with explicit and default span_type, invalid type raises MlflowException.

### SR-15: `_decode_otel_proto_anyvalue()` utility
- Observable: Yes. arch_spec `check_sr15_arch` passes; behavior_spec `check_sr15_behavior` passes. Verified round-trip for None, bool, str, int, float, bytes, list, dict, nested structures, and unset AnyValue returns None.

### Uncertainties
- `Span.from_dict` internally references v2 schema handling (`_is_span_v2_schema`, `from_dict_v2`) which the interface descriptions do not explicitly exercise. These code paths exist in the production codebase but were not part of the task spec. They are not required for interface description compliance.
- `LiveSpan.end()` calls `apply_span_processors` which is imported and defined; the static analysis flag is a false positive.
- The behavior spec for SR-13 cannot validate due to its own import-order bug (F-01), but the architecture spec and manual testing provide sufficient evidence.

## Risk Focus

### High-confidence areas
- **Span lifecycle**: Span creation, attribute management, and serialization are well-covered by both specs and native pytest tests.
- **NoOpSpan**: All interface methods verified as no-ops; thread-safe by design (no shared state).
- **OTLP interoperability**: `to_otel_proto` and `from_otel_proto` round-trips are tested and consistent.

### Moderate-uncertainty areas
- **`_Trace.to_mlflow_trace()` edge case with empty span_dict**: Neither spec tests the zero-span case. Current code would produce a Trace with empty TraceData.spans, which is arguably correct but unverified.
- **`NoOpSpan` attribute storage**: NoOpSpan stores attributes in a plain dict (`self._attributes = {}`) rather than using the registry pattern. The `attributes` property inherited from `Span` calls `_CachedSpanAttributesRegistry` methods that expect an OTel span. If `NoOpSpan.attributes` is accessed, it may fail because the parent's `_attributes` expects an OTel span. However, the interface description does not require `NoOpSpan.attributes` to be callable (it's not listed in the interface description). **This is not a task requirement gap but a latent risk if users call `.attributes` on NoOpSpan.**
- **`to_otel_proto` trace_id encoding**: Uses `bytes.fromhex(self._trace_id)` which requires the hex-encoded OTel trace ID. The interface description requires 16-byte trace_id in the protobuf. This is tested and correct for the main path.

### Low-uncertainty areas
- **Attribute serialization**: JSON-based `dump_span_attribute_value` / `json.loads` pattern is consistent across the codebase.
- **ID encoding**: `int → bytes(length=N, byteorder="big") → base64.b64encode → str` pattern is consistent and verified by both specs.

## Spec Actions

1. **Fix `check_sr13_behavior` in behavior_spec.py** (F-01): Move the `from mlflow.tracing.utils import dump_span_attribute_value` import to the top of the function body, before line 509 where it is first used. The import on line 506 (`from mlflow.entities.span import _CachedSpanAttributesRegistry, _SpanAttributesRegistry`) is fine; just add the `dump_span_attribute_value` import alongside it.

2. **Ignore static_issues.md false positives** (F-02): The five reported undefined symbols are all false positives—three are same-file forward references, two are external imports. No code changes needed. If the static analyzer is used in CI, configure it to handle same-file forward references and follow re-exports.

3. **Optional: add zero-span test for `to_mlflow_trace`**: The behavior spec could add a test case with an empty `span_dict` to verify `to_mlflow_trace()` returns a valid Trace with empty `data.spans`. Not required for task compliance.

4. **Optional: verify NoOpSpan.attributes behavior**: If the interface description is later expanded to require `attributes` access on NoOpSpan, the current `self._attributes = {}` plain dict will need to be wrapped or the parent property overridden. Currently not required.
