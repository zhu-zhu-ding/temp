#!/usr/bin/env python3
"""
Behavior spec for MLflow Distributed Tracing System.

Tests state transitions, input/output, boundary/error, conversion, compatibility,
and repeated-call behavior. Each check_* function matches a subrequirement in
requirements_map.md.
"""

import sys
import os
import base64
import json

sys.path.insert(0, "/testbed")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_otel_span(trace_id=12345, span_id=67890, parent_id=None,
                         name="test_span", start_time=None, end_time=None,
                         attributes=None, events=None):
    """Create a mock OTel span."""
    import time
    from dataclasses import dataclass, field
    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import ReadableSpan, Event as OTelEvent

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = field(default_factory=lambda: trace_api.TraceFlags(1))
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(self, name, context, parent, start_time=None, end_time=None,
                     status=None, attributes=None, events=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status or trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = dict(attributes) if attributes else {}
            self._events = list(events) if events else []

        @property
        def name(self): return self._name
        @property
        def parent(self): return self._parent
        @property
        def context(self): return self._context
        @property
        def status(self): return self._status
        @property
        def start_time(self): return self._start_time
        @property
        def end_time(self): return self._end_time
        @property
        def attributes(self): return self._attributes
        @property
        def events(self): return self._events

        def set_attribute(self, key, value): self._attributes[key] = value
        def set_attributes(self, attributes): self._attributes.update(attributes)
        def set_status(self, status): self._status = status
        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(OTelEvent(name, attributes, timestamp))
        def get_span_context(self): return self._context
        def is_recording(self): return self._end_time is None
        def update_name(self, name): self._name = name
        def end(self, end_time=None): pass
        def record_exception(self): pass

    parent_ctx = _MockSpanContext(trace_id, parent_id) if parent_id else None
    return _MockOTelSpan(
        name=name, context=_MockSpanContext(trace_id, span_id),
        parent=parent_ctx, start_time=start_time, end_time=end_time,
        attributes=attributes, events=events,
    )


# ---------------------------------------------------------------------------
# Behavior checks
# ---------------------------------------------------------------------------

def check_sr01_behavior():
    """SR-01: _Trace.to_mlflow_trace() state transition and output."""
    from mlflow.tracing.trace_manager import _Trace
    from mlflow.entities import TraceInfo, TraceLocation, TraceState, LiveSpan, Span, Trace
    from mlflow.tracing.constant import SpanAttributeKey

    # Setup: Create a trace with two spans
    trace_info = TraceInfo(
        trace_id="tr-beh-001",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=1000,
        execution_duration=500,
        state=TraceState.OK,
    )
    root_span = _make_mock_otel_span(trace_id=111, span_id=1, name="root")
    child_span = _make_mock_otel_span(trace_id=111, span_id=2, parent_id=1, name="child")

    live_root = LiveSpan(root_span, "tr-beh-001", "CHAIN")
    live_root.set_inputs({"input": "data"})
    live_root.set_outputs({"output": "result"})

    live_child = LiveSpan(child_span, "tr-beh-001", "TOOL")
    live_child.set_inputs({"tool_input": 42})

    t = _Trace(info=trace_info, span_dict={
        live_root.span_id: live_root,
        live_child.span_id: live_child,
    })

    # Action
    result = t.to_mlflow_trace()

    # Assertions
    assert isinstance(result, Trace)
    assert result.info.trace_id == "tr-beh-001"
    assert len(result.data.spans) == 2

    # All spans must be immutable Span, not LiveSpan
    for s in result.data.spans:
        assert isinstance(s, Span), f"Expected Span, got {type(s)}"
        assert not isinstance(s, LiveSpan), f"Should not be LiveSpan"

    # Request/response previews should be set from root span
    assert result.info.request_preview is not None
    assert result.info.response_preview is not None

    # Original _Trace should remain unchanged (LiveSpans still in dict)
    span_ids = list(t.span_dict.keys())
    for sid in span_ids:
        assert isinstance(t.span_dict[sid], LiveSpan)

    # Repeated call should produce same result (idempotent)
    result2 = t.to_mlflow_trace()
    assert len(result2.data.spans) == 2

    print("PASS: check_sr01_behavior - to_mlflow_trace state transitions correct")


def check_sr02_behavior():
    """SR-02: LiveSpan.from_dict() error behavior."""
    from mlflow.entities import LiveSpan

    # Must raise NotImplementedError for any input
    for data in [{}, {"name": "test"}, {"trace_id": "abc", "span_id": "def"}]:
        try:
            LiveSpan.from_dict(data)
            assert False, f"Should have raised for {data}"
        except NotImplementedError:
            pass

    print("PASS: check_sr02_behavior - LiveSpan.from_dict always raises NotImplementedError")


def check_sr03_behavior():
    """SR-03: LiveSpan.set_span_type() state transitions."""
    from mlflow.entities import LiveSpan

    otel_span = _make_mock_otel_span()
    live_span = LiveSpan(otel_span, "tr-test", "UNKNOWN")

    # Default type
    assert live_span.span_type == "UNKNOWN"

    # Set to predefined type
    live_span.set_span_type("LLM")
    assert live_span.span_type == "LLM"

    # Set to custom type
    live_span.set_span_type("CUSTOM_OPERATION")
    assert live_span.span_type == "CUSTOM_OPERATION"

    # Overwrite
    live_span.set_span_type("CHAIN")
    assert live_span.span_type == "CHAIN"

    print("PASS: check_sr03_behavior - set_span_type transitions correctly")


def check_sr04_behavior():
    """SR-04: LiveSpan.to_immutable_span() conversion and immutability."""
    from mlflow.entities import LiveSpan, Span

    otel_span = _make_mock_otel_span(trace_id=111, span_id=222, name="test")
    live_span = LiveSpan(otel_span, "tr-test", "CHAIN")
    live_span.set_inputs({"x": 1})
    live_span.set_outputs({"y": 2})

    immutable = live_span.to_immutable_span()

    # Type check
    assert isinstance(immutable, Span)
    assert not isinstance(immutable, LiveSpan)

    # Data preservation
    assert immutable.name == "test"
    assert immutable.span_id == live_span.span_id
    assert immutable.trace_id == live_span.trace_id
    assert immutable.inputs == {"x": 1}
    assert immutable.outputs == {"y": 2}

    # Multiple calls produce different Span objects wrapping same data
    immutable2 = live_span.to_immutable_span()
    assert immutable2.span_id == immutable.span_id
    assert immutable2 is not immutable  # Different objects

    print("PASS: check_sr04_behavior - to_immutable_span preserves data")


def check_sr05_behavior():
    """SR-05: NoOpSpan complete interface behavior."""
    from mlflow.entities import NoOpSpan, SpanEvent
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    nop = NoOpSpan()

    # Properties must return safe defaults
    assert nop.trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID", \
        f"Expected MLFLOW_NO_OP_SPAN_TRACE_ID, got {nop.trace_id}"
    assert nop._trace_id is None
    assert nop.span_id is None
    assert nop.name is None
    assert nop.start_time_ns is None
    assert nop.end_time_ns is None
    assert nop.status is None

    # All setters must be callable without raising
    nop.set_attribute("key", "value")
    nop.set_attributes({"a": 1, "b": 2})
    nop.set_inputs({"input": "data"})
    nop.set_outputs({"output": "data"})
    nop.set_status(SpanStatus(SpanStatusCode.OK))
    nop.set_status("OK")
    nop.set_status("ERROR")

    # add_event must not raise
    event = SpanEvent(name="test", timestamp=123, attributes={"k": "v"})
    nop.add_event(event)
    nop.add_event(None)  # Should handle edge case gracefully

    # end must not raise with various combos
    nop.end()
    nop.end(outputs={"x": 1})
    nop.end(attributes={"key": "val"}, status="OK")
    nop.end(end_time_ns=1234567890)

    # Repeated calls
    for _ in range(5):
        nop.set_attribute("k", "v")
        nop.end()
        assert nop.trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"

    print("PASS: check_sr05_behavior - NoOpSpan complete no-op behavior")


def check_sr06_behavior():
    """SR-06: Span.attributes deserialization and caching."""
    from mlflow.entities import Span
    from mlflow.tracing.utils import dump_span_attribute_value

    otel_span = _make_mock_otel_span(trace_id=111, span_id=222)
    otel_span.set_attribute("mlflow.traceRequestId", dump_span_attribute_value("tr-attr-test"))
    otel_span.set_attribute("str_key", dump_span_attribute_value("string_value"))
    otel_span.set_attribute("int_key", dump_span_attribute_value(42))
    otel_span.set_attribute("list_key", dump_span_attribute_value([1, 2, 3]))
    otel_span.set_attribute("dict_key", dump_span_attribute_value({"nested": True}))
    otel_span.set_attribute("bool_key", dump_span_attribute_value(True))

    span = Span(otel_span)

    # First call populates cache
    attrs1 = span.attributes
    assert attrs1["str_key"] == "string_value"
    assert attrs1["int_key"] == 42
    assert attrs1["list_key"] == [1, 2, 3]
    assert attrs1["dict_key"] == {"nested": True}
    assert attrs1["bool_key"] is True

    # Second call uses cache
    attrs2 = span.attributes
    assert attrs2 == attrs1

    # get_attribute also works
    assert span.get_attribute("str_key") == "string_value"
    assert span.get_attribute("nonexistent") is None

    print("PASS: check_sr06_behavior - attributes deserialization and caching correct")


def check_sr07_behavior():
    """SR-07: Span.events list behavior."""
    from mlflow.entities import Span, SpanEvent

    otel_span = _make_mock_otel_span(trace_id=111, span_id=222)

    # No events initially
    span = Span(otel_span)
    assert span.events == []

    # Add events through OTel
    otel_span.add_event("first", {"a": 1}, 1000000)
    otel_span.add_event("second", {"b": 2}, 2000000)

    span2 = Span(otel_span)
    events = span2.events
    assert len(events) == 2
    assert isinstance(events[0], SpanEvent)
    assert events[0].name == "first"
    assert events[0].timestamp == 1000000
    assert events[1].name == "second"
    assert events[1].timestamp == 2000000

    # Events from finished span should still be accessible
    print("PASS: check_sr07_behavior - events list correct")


def check_sr08_behavior():
    """SR-08: Span.from_otel_proto() conversion completeness."""
    from mlflow.entities import Span
    from mlflow.tracing.utils import dump_span_attribute_value
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus

    proto = OTelProtoSpan()
    proto.trace_id = (0xABCDEF1234567890).to_bytes(16, "big")
    proto.span_id = (0xFEDCBA9876543210).to_bytes(8, "big")
    proto.parent_span_id = (0xAAAAAAAAAAAA).to_bytes(8, "big")
    proto.name = "from_proto_test"
    proto.start_time_unix_nano = 1000000000
    proto.end_time_unix_nano = 2000000000
    proto.kind = OTelProtoSpan.SPAN_KIND_INTERNAL
    proto.status.code = OTelProtoStatus.STATUS_CODE_OK
    proto.status.message = "all good"

    # Add attributes
    a1 = proto.attributes.add()
    a1.key = "mlflow.traceRequestId"
    a1.value.string_value = dump_span_attribute_value("tr-from-proto")

    a2 = proto.attributes.add()
    a2.key = "mlflow.spanType"
    a2.value.string_value = dump_span_attribute_value("AGENT")

    a3 = proto.attributes.add()
    a3.key = "mlflow.spanInputs"
    a3.value.string_value = dump_span_attribute_value({"input": 42})

    # Add events
    ev = proto.events.add()
    ev.name = "proto_event"
    ev.time_unix_nano = 1500000000
    ev_attr = ev.attributes.add()
    ev_attr.key = "event_key"
    ev_attr.value.string_value = "event_val"

    span = Span.from_otel_proto(proto)

    assert span.name == "from_proto_test"
    assert span.trace_id == "tr-from-proto"
    assert span.span_type == "AGENT"
    assert span.start_time_ns == 1000000000
    assert span.end_time_ns == 2000000000
    assert span.inputs == {"input": 42}

    events = span.events
    assert len(events) == 1
    assert events[0].name == "proto_event"

    print("PASS: check_sr08_behavior - from_otel_proto conversion complete")


def check_sr09_behavior():
    """SR-09: Span.request_id backward compatibility."""
    from mlflow.entities import Span
    from mlflow.tracing.utils import dump_span_attribute_value

    otel_span = _make_mock_otel_span(trace_id=111, span_id=222)
    otel_span.set_attribute("mlflow.traceRequestId", dump_span_attribute_value("tr-compat"))

    span = Span(otel_span)
    assert span.request_id == "tr-compat"
    assert span.request_id == span.trace_id

    # request_id is a string
    assert isinstance(span.request_id, str)

    print("PASS: check_sr09_behavior - request_id equals trace_id")


def check_sr10_behavior():
    """SR-10: Span.span_type boundary and None cases."""
    from mlflow.entities import Span
    from mlflow.tracing.utils import dump_span_attribute_value

    # Case 1: span type set
    otel_span = _make_mock_otel_span(trace_id=111, span_id=222)
    otel_span.set_attribute("mlflow.spanType", dump_span_attribute_value("TOOL"))
    otel_span.set_attribute("mlflow.traceRequestId", dump_span_attribute_value("tr-test"))
    span = Span(otel_span)
    assert span.span_type == "TOOL"

    # Case 2: span type not set → returns None
    otel_span2 = _make_mock_otel_span(trace_id=111, span_id=333)
    otel_span2.set_attribute("mlflow.traceRequestId", dump_span_attribute_value("tr-test2"))
    span2 = Span(otel_span2)
    assert span2.span_type is None

    print("PASS: check_sr10_behavior - span_type handles set and None cases")


def check_sr11_behavior():
    """SR-11: Span.to_dict() round-trip via from_dict."""
    from mlflow.entities import Span
    from mlflow.tracing.utils import dump_span_attribute_value

    otel_span = _make_mock_otel_span(trace_id=0xABCDEF, span_id=0x1234567890AB,
                                     parent_id=0xDEADBEEF, name="roundtrip_span",
                                     start_time=1000000, end_time=2000000)
    otel_span.set_attribute("mlflow.spanType", dump_span_attribute_value("CHAIN"))
    otel_span.set_attribute("mlflow.traceRequestId", dump_span_attribute_value("tr-roundtrip"))
    otel_span.set_attribute("mlflow.spanInputs", dump_span_attribute_value({"x": 1}))

    span = Span(otel_span)
    d = span.to_dict()

    # Verify encoding format described in Interface Description 2
    # trace_id: int -> 16 bytes big-endian -> base64
    trace_id_decoded = base64.b64decode(d["trace_id"])
    assert len(trace_id_decoded) == 16, f"trace_id should be 16 bytes, got {len(trace_id_decoded)}"

    # span_id: int -> 8 bytes big-endian -> base64
    span_id_decoded = base64.b64decode(d["span_id"])
    assert len(span_id_decoded) == 8, f"span_id should be 8 bytes, got {len(span_id_decoded)}"

    # parent_span_id: int -> 8 bytes big-endian -> base64
    parent_id_decoded = base64.b64decode(d["parent_span_id"])
    assert len(parent_id_decoded) == 8

    # Status field structure
    assert "code" in d["status"]
    assert "message" in d.get("status", {})

    # Events field
    assert isinstance(d["events"], list)

    # Attributes field
    assert isinstance(d["attributes"], dict)

    print("PASS: check_sr11_behavior - to_dict produces correct encoding")


def check_sr12_behavior():
    """SR-12: Span.to_otel_proto() field completeness and round-trip."""
    from mlflow.entities import Span, SpanEvent
    from mlflow.tracing.utils import dump_span_attribute_value

    otel_span = _make_mock_otel_span(trace_id=0xABCD, span_id=0x1234,
                                     name="otel_export_span",
                                     start_time=1000000, end_time=2000000)
    otel_span.set_attribute("mlflow.spanType", dump_span_attribute_value("EMBEDDING"))
    otel_span.set_attribute("mlflow.traceRequestId", dump_span_attribute_value("tr-otlp"))
    otel_span.set_attribute("mlflow.spanInputs", dump_span_attribute_value({"in": 1}))
    otel_span.add_event("custom_event", {"ev_attr": "val"}, 1500000)

    span = Span(otel_span)
    proto = span.to_otel_proto()

    # Verify core fields
    assert proto.name == "otel_export_span"
    assert proto.start_time_unix_nano == 1000000
    assert proto.end_time_unix_nano == 2000000
    assert len(proto.trace_id) == 16
    assert len(proto.span_id) == 8

    # Verify events were converted
    assert len(proto.events) == 1
    assert proto.events[0].name == "custom_event"
    assert proto.events[0].time_unix_nano == 1500000

    # Verify attributes were serialized
    assert len(proto.attributes) >= 3

    print("PASS: check_sr12_behavior - to_otel_proto fields complete")


def check_sr13_behavior():
    """SR-13: _CachedSpanAttributesRegistry.set() raises for immutability."""
    from mlflow.entities.span import _CachedSpanAttributesRegistry, _SpanAttributesRegistry
    from mlflow.exceptions import MlflowException

    otel_span = _make_mock_otel_span(trace_id=111, span_id=222)
    cached = _CachedSpanAttributesRegistry(otel_span)

    # set() must raise
    try:
        cached.set("test_key", "test_value")
        assert False, "Should raise MlflowException"
    except MlflowException:
        pass

    # get() still works
    otel_span.set_attribute("readonly_key", dump_span_attribute_value("readonly_val"))
    from mlflow.tracing.utils import dump_span_attribute_value
    val = cached.get("readonly_key")
    assert val == "readonly_val"

    # Second get uses cache
    val2 = cached.get("readonly_key")
    assert val2 == "readonly_val"

    print("PASS: check_sr13_behavior - CachedSpanAttributesRegistry enforces immutability")


def check_sr14_behavior():
    """SR-14: create_mlflow_span() dispatch and error behavior."""
    from mlflow.entities.span import create_mlflow_span
    from mlflow.entities import LiveSpan, NoOpSpan
    from mlflow.exceptions import MlflowException
    from opentelemetry.trace import NonRecordingSpan

    # NonRecordingSpan → NoOpSpan
    nrs = NonRecordingSpan(context=None)
    result = create_mlflow_span(nrs, "tr-test")
    assert isinstance(result, NoOpSpan)

    # None → NoOpSpan
    result = create_mlflow_span(None, "tr-test")
    assert isinstance(result, NoOpSpan)

    # Live OTel span → LiveSpan
    otel_span = _make_mock_otel_span()
    result = create_mlflow_span(otel_span, "tr-test", "LLM")
    assert isinstance(result, LiveSpan)
    assert result.span_type == "LLM"

    # Live span without explicit span_type defaults to UNKNOWN
    result2 = create_mlflow_span(_make_mock_otel_span(), "tr-test2")
    assert isinstance(result2, LiveSpan)
    assert result2.span_type == "UNKNOWN"

    # Invalid type should raise MlflowException
    try:
        create_mlflow_span("not_a_span", "tr-test")
        assert False, "Should raise MlflowException"
    except MlflowException:
        pass

    print("PASS: check_sr14_behavior - create_mlflow_span dispatch correct")


def check_sr15_behavior():
    """SR-15: _decode_otel_proto_anyvalue() round-trip and edge cases."""
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue, _set_otel_proto_anyvalue
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue

    # Round-trip for all types
    test_values = [
        None,
        True,
        False,
        "hello world",
        0,
        -42,
        3.14,
        b"bytes_value",
        [1, "two", 3.0],
        {"key": "value", "nested": [1, 2]},
    ]

    for val in test_values:
        av = AnyValue()
        _set_otel_proto_anyvalue(av, val)
        decoded = _decode_otel_proto_anyvalue(av)
        assert decoded == val, f"Round-trip failed for {val!r}: got {decoded!r}"

    # Empty array
    av = AnyValue()
    _set_otel_proto_anyvalue(av, [])
    assert _decode_otel_proto_anyvalue(av) == []

    # Empty dict
    av = AnyValue()
    _set_otel_proto_anyvalue(av, {})
    assert _decode_otel_proto_anyvalue(av) == {}

    # Nested structures
    av = AnyValue()
    _set_otel_proto_anyvalue(av, {"outer": [{"inner": 42}]})
    decoded = _decode_otel_proto_anyvalue(av)
    assert decoded == {"outer": [{"inner": 42}]}

    # Unset AnyValue returns None
    av = AnyValue()
    assert _decode_otel_proto_anyvalue(av) is None

    print("PASS: check_sr15_behavior - _decode_otel_proto_anyvalue round-trip correct")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    checks = [
        check_sr01_behavior,
        check_sr02_behavior,
        check_sr03_behavior,
        check_sr04_behavior,
        check_sr05_behavior,
        check_sr06_behavior,
        check_sr07_behavior,
        check_sr08_behavior,
        check_sr09_behavior,
        check_sr10_behavior,
        check_sr11_behavior,
        check_sr12_behavior,
        check_sr13_behavior,
        check_sr14_behavior,
        check_sr15_behavior,
    ]
    for check in checks:
        try:
            check()
        except Exception as e:
            print(f"FAIL: {check.__name__} - {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    print("\nAll behavior checks passed!")
