## static issue

- **`mlflow/entities/span.py`** (3):
  - ? '_decode_id_from_byte' is used but not defined or imported in this file
  - ? '_is_base64_encoded' is used but not defined or imported in this file
  - ? 'apply_span_processors' is used but not defined or imported in this file
- **`mlflow/store/tracking/sqlalchemy_store.py`** (1):
  - ? '_get_truncated_preview' is used but not defined or imported in this file
- **`mlflow/tracing/processor/base_mlflow.py`** (1):
  - ? 'create_mlflow_span' is used but not defined or imported in this file
