# Subrequirement Map

## SR-01: `_Trace.to_mlflow_trace()` conversion
- **Requirement**: Convert internal `_Trace` (with mutable `LiveSpan` dict) into an immutable `Trace` object with `TraceData` and populate request/response previews via `set_request_response_preview`.
- **Task Evidence**: Interface Description 1 specifies `_Trace.to_mlflow_trace(self) -> Trace` on path `/testbed/mlflow/tracing/trace_manager.py`.
- **Architecture Spec**: `check_sr01_arch`
- **Behavior Spec**: `check_sr01_behavior`
- **Critical Path**: `_Trace.to_mlflow_trace()` → iterates `span_dict.values()` calling `LiveSpan.to_immutable_span()` on each → constructs `TraceData(spans=[...])` → calls `set_request_response_preview` on `TraceInfo` → returns `Trace(info, data)`.
- **Expected Intermediate State**: All `LiveSpan` objects converted to immutable `Span` objects; `TraceData` populated with immutable spans.
- **Expected Final Output**: `Trace` object with `info.request_preview`, `info.response_preview` set, and `data.spans` containing only `Span` (not `LiveSpan`) instances.
- **Observability**: `to_mlflow_trace()` returns a `Trace`; `trace.data.spans[0]` is `Span` not `LiveSpan`; `trace.info.request_preview` is non-empty when spans have inputs.
- **Repository Evidence**: `mlflow/tracing/trace_manager.py:_Trace` dataclass with `info: TraceInfo`, `span_dict: dict[str, LiveSpan]`; `InMemoryTraceManager.pop_trace` calls `internal_trace.to_mlflow_trace()` at line ~174; `tests/tracing/test_trace_manager.py:test_add_spans` verifies `not isinstance(trace.data.spans[0], LiveSpan)`.
- **Architecture Check**: `check_sr01_arch`
- **Behavior Check**: `check_sr01_behavior`

## SR-02: `LiveSpan.from_dict()` raises NotImplementedError
- **Requirement**: `LiveSpan.from_dict(cls, data)` always raises `NotImplementedError` because `LiveSpan` objects require an active OTel span context and cannot be reconstructed from serialized data.
- **Task Evidence**: Interface Description 2 specifies `LiveSpan.from_dict(cls, data: dict[str, Any]) -> 'Span'` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr02_arch`
- **Behavior Spec**: `check_sr02_behavior`
- **Critical Path**: `LiveSpan.from_dict(data)` → raises `NotImplementedError`.
- **Expected Intermediate State**: N/A (method raises immediately).
- **Expected Final Output**: `NotImplementedError` with a message directing users to `Span.from_dict()`.
- **Observability**: Call raises `NotImplementedError`.
- **Repository Evidence**: Interface Description 2 docstring says "NotImplementedError: Always raised since LiveSpan objects cannot be created from dictionary data."
- **Architecture Check**: `check_sr02_arch`
- **Behavior Check**: `check_sr02_behavior`

## SR-03: `LiveSpan.set_span_type()` sets span type attribute
- **Requirement**: `LiveSpan.set_span_type(span_type: str)` sets the span type on the live span via `SpanAttributeKey.SPAN_TYPE`.
- **Task Evidence**: Interface Description 2 specifies `LiveSpan.set_span_type(self, span_type: str)` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr03_arch`
- **Behavior Spec**: `check_sr03_behavior`
- **Critical Path**: `LiveSpan.set_span_type(span_type)` → `self.set_attribute(SpanAttributeKey.SPAN_TYPE, span_type)`.
- **Expected Intermediate State**: Span's attribute registry contains the span type key with the given value.
- **Expected Final Output**: The `span_type` property returns the set value.
- **Observability**: After calling `set_span_type("LLM")`, `span.span_type` returns `"LLM"`.
- **Repository Evidence**: `mlflow/entities/span.py:LiveSpan.__init__` already sets `self._attributes.set(SpanAttributeKey.SPAN_TYPE, span_type)`; `SpanAttributeKey.SPAN_TYPE = "mlflow.spanType"` in `mlflow/tracing/constant.py`.
- **Architecture Check**: `check_sr03_arch`
- **Behavior Check**: `check_sr03_behavior`

## SR-04: `LiveSpan.to_immutable_span()` conversion
- **Requirement**: `LiveSpan.to_immutable_span()` returns an immutable `Span` wrapping the same underlying OTel span.
- **Task Evidence**: Interface Description 2 specifies `LiveSpan.to_immutable_span(self) -> 'Span'` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr04_arch`
- **Behavior Spec**: `check_sr04_behavior`
- **Critical Path**: `LiveSpan.to_immutable_span()` → `Span(self._span)`.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: `Span` instance with same `span_id`, `trace_id`, attributes as the original `LiveSpan`.
- **Observability**: `isinstance(result, Span)` is `True`; `isinstance(result, LiveSpan)` is `False`; `result.span_id == live_span.span_id`.
- **Repository Evidence**: `Span.__init__` accepts `OTelReadableSpan`; `LiveSpan._span` is an `OTelSpan` which extends `OTelReadableSpan`; `tests/tracing/test_trace_manager.py` verifies conversion.
- **Architecture Check**: `check_sr04_arch`
- **Behavior Check**: `check_sr04_behavior`

## SR-05: `NoOpSpan` interface completeness
- **Requirement**: `NoOpSpan` must implement all Span interface properties/methods as no-ops: `_trace_id`, `add_event`, `end`, `end_time_ns`, `name`, `set_attribute`, `set_attributes`, `set_inputs`, `set_outputs`, `set_status`, `span_id`, `start_time_ns`, `status`, `trace_id`.
- **Task Evidence**: Interface Description 2 specifies all NoOpSpan stubs on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr05_arch`
- **Behavior Spec**: `check_sr05_behavior`
- **Critical Path**: Call each NoOpSpan method → no-op returns expected sentinel (`None`, `"MLFLOW_NO_OP_SPAN_TRACE_ID"`).
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: All property accesses return safe defaults; all setter calls complete without error.
- **Observability**: `NoOpSpan().trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"`; `NoOpSpan()._trace_id is None`; `NoOpSpan().span_id is None`; all setter methods and `add_event`/`end` complete without raising.
- **Repository Evidence**: `NO_OP_SPAN_TRACE_ID = "MLFLOW_NO_OP_SPAN_TRACE_ID"` in `mlflow/entities/span.py`; `NoOpSpan.__init__` sets `self._span = NonRecordingSpan(context=None)`; existing `NoOpSpan` has `context`, `parent_id`, `record_exception`.
- **Architecture Check**: `check_sr05_arch`
- **Behavior Check**: `check_sr05_behavior`

## SR-06: `Span.attributes` property with deserialization
- **Requirement**: `Span.attributes` returns all span attributes deserialized from JSON via `_CachedSpanAttributesRegistry`.
- **Task Evidence**: Interface Description 2 specifies `Span.attributes(self) -> dict[str, Any]` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr06_arch`
- **Behavior Spec**: `check_sr06_behavior`
- **Critical Path**: `Span.attributes` → iterates `self._span.attributes` dict → deserializes each JSON value → returns `dict[str, Any]`.
- **Expected Intermediate State**: Cache is populated on first call.
- **Expected Final Output**: `dict` where each key's value is deserialized from JSON.
- **Observability**: For a span with `{"x": 1}` stored as `'"{"x": 1}"'`, `span.attributes` returns `{"x": 1}`.
- **Repository Evidence**: `_SpanAttributesRegistry.get(key)` deserializes via `json.loads`; `_CachedSpanAttributesRegistry.get(key)` is cached; span attributes are stored as JSON strings via `dump_span_attribute_value`.
- **Architecture Check**: `check_sr06_arch`
- **Behavior Check**: `check_sr06_behavior`

## SR-07: `Span.events` property
- **Requirement**: `Span.events` returns all span events as `list[SpanEvent]`, converting OTel events with attributes from BoundedAttributes to simple dicts.
- **Task Evidence**: Interface Description 2 specifies `Span.events(self) -> list[SpanEvent]` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr07_arch`
- **Behavior Spec**: `check_sr07_behavior`
- **Critical Path**: `Span.events` → iterates `self._span.events` → converts each OTel event to `SpanEvent` with `dict(attributes)`.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: `list[SpanEvent]` with `name`, `timestamp`, and `attributes` (as plain dict).
- **Observability**: Events have accessible `name`, `timestamp`, `attributes` fields.
- **Repository Evidence**: `OTelEvent` stored in `self._span.events`; `SpanEvent` dataclass with `name`, `timestamp`, `attributes` fields; `mlflow/entities/span_event.py`.
- **Architecture Check**: `check_sr07_arch`
- **Behavior Check**: `check_sr07_behavior`

## SR-08: `Span.from_otel_proto()` classmethod
- **Requirement**: Create `Span` from OpenTelemetry protobuf span message, extracting trace/span IDs, timing, attributes, events, status with proper encoding.
- **Task Evidence**: Interface Description 2 specifies `Span.from_otel_proto(cls, otel_proto_span, location_id: str | None = None) -> 'Span'` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr08_arch`
- **Behavior Spec**: `check_sr08_behavior`
- **Critical Path**: `Span.from_otel_proto(proto, location_id)` → extracts fields from `OTelProtoSpan` → converts trace_id/span_id from bytes to int → builds `OTelReadableSpan` via `build_otel_context` → returns `Span(otel_span)`.
- **Expected Intermediate State**: All fields extracted from protobuf.
- **Expected Final Output**: Immutable `Span` with correctly populated trace_id, span_id, name, start/end times, attributes, events, status.
- **Observability**: Round-trip `span.to_otel_proto() -> Span.from_otel_proto()` preserves key fields.
- **Repository Evidence**: `mlflow/tracing/utils:build_otel_context`, `decode_id`, `encode_trace_id`, `encode_span_id`; `OTelProtoSpan` from `opentelemetry.proto.trace.v1.trace_pb2`; `SpanStatus.from_otel_proto_status`; `generate_mlflow_trace_id_from_otel_trace_id`, `generate_trace_id_v4_from_otel_trace_id`.
- **Architecture Check**: `check_sr08_arch`
- **Behavior Check**: `check_sr08_behavior`

## SR-09: `Span.request_id` property (alias for trace_id)
- **Requirement**: `Span.request_id` returns the same value as `trace_id` for backward compatibility.
- **Task Evidence**: Interface Description 2 specifies `Span.request_id(self) -> str` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr09_arch`
- **Behavior Spec**: `check_sr09_behavior`
- **Critical Path**: `Span.request_id` → returns `self.trace_id`.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: Same string as `trace_id`.
- **Observability**: `span.request_id == span.trace_id`.
- **Repository Evidence**: `Span.trace_id` returns `self.get_attribute(SpanAttributeKey.REQUEST_ID)`; `TraceInfo.request_id` is already defined as alias for `trace_id`.
- **Architecture Check**: `check_sr09_arch`
- **Behavior Check**: `check_sr09_behavior`

## SR-10: `Span.span_type` property
- **Requirement**: `Span.span_type` returns the span type string from attributes.
- **Task Evidence**: Interface Description 2 specifies `Span.span_type(self) -> str` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr10_arch`
- **Behavior Spec**: `check_sr10_behavior`
- **Critical Path**: `Span.span_type` → `self.get_attribute(SpanAttributeKey.SPAN_TYPE)`.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: String like `"LLM"`, `"UNKNOWN"`, or a custom type.
- **Observability**: After `LiveSpan.set_span_type("LLM")` and conversion, `immutable_span.span_type == "LLM"`.
- **Repository Evidence**: `SpanAttributeKey.SPAN_TYPE = "mlflow.spanType"`; `LiveSpan.__init__` sets it; `Span.get_attribute` retrieves it.
- **Architecture Check**: `check_sr10_arch`
- **Behavior Check**: `check_sr10_behavior`

## SR-11: `Span.to_dict()` serialization
- **Requirement**: Serialize span to dictionary with base64-encoded trace_id/span_id/parent_span_id using specific encoding (int → big-endian bytes → base64).
- **Task Evidence**: Interface Description 2 specifies `Span.to_dict(self) -> dict[str, Any]` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr11_arch`
- **Behavior Spec**: `check_sr11_behavior`
- **Critical Path**: `Span.to_dict()` → converts `_trace_id` int to 16 bytes big-endian then base64 → converts `span_id` int to 8 bytes big-endian then base64 → returns dict with all fields.
- **Expected Intermediate State**: All IDs encoded as base64 strings.
- **Expected Final Output**: Dict with keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`.
- **Observability**: `to_dict()` returns a dict; `from_dict(to_dict())` round-trips correctly.
- **Repository Evidence**: `Span._trace_id` returns `encode_trace_id(self._span.context.trace_id)`; `encode_trace_id` uses `trace_api.format_trace_id`; `encode_span_id` uses `trace_api.format_span_id`; `decode_id` does `int(id, 16)`; `base64` module imported; Interface Description 2 notes specify exact encoding.
- **Architecture Check**: `check_sr11_arch`
- **Behavior Check**: `check_sr11_behavior`

## SR-12: `Span.to_otel_proto()` conversion
- **Requirement**: Convert MLflow `Span` to `OTelProtoSpan` for OTLP export, encoding trace_id/span_id as bytes, mapping status, attributes, events.
- **Task Evidence**: Interface Description 2 specifies `Span.to_otel_proto(self) -> OTelProtoSpan` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr12_arch`
- **Behavior Spec**: `check_sr12_behavior`
- **Critical Path**: `Span.to_otel_proto()` → creates `OTelProtoSpan` → sets trace_id/span_id from hex string to bytes → maps status, attributes via `_set_otel_proto_anyvalue` → converts events via `SpanEvent.to_otel_proto()` → sets parent_span_id if applicable.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: `OTelProtoSpan` protobuf message with all fields populated.
- **Observability**: `to_otel_proto()` produces a valid `OTelProtoSpan` with correct `trace_id` (16 bytes), `span_id` (8 bytes), `name`, `start_time_unix_nano`, `end_time_unix_nano`.
- **Repository Evidence**: `_set_otel_proto_anyvalue` in `mlflow/tracing/utils/otlp.py`; `SpanEvent.to_otel_proto()`; `OTelProtoSpan` imported; `OTelProtoStatus` imported; `SpanStatus.to_otel_status()`.
- **Architecture Check**: `check_sr12_arch`
- **Behavior Check**: `check_sr12_behavior`

## SR-13: `_CachedSpanAttributesRegistry.set()` raises error
- **Requirement**: `_CachedSpanAttributesRegistry.set()` raises `MlflowException` since cached registry is for immutable spans only.
- **Task Evidence**: Interface Description 2 specifies `_CachedSpanAttributesRegistry.set(self, key, value)` raises `MlflowException` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr13_arch`
- **Behavior Spec**: `check_sr13_behavior`
- **Critical Path**: `_CachedSpanAttributesRegistry.set(key, value)` → raises `MlflowException`.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: `MlflowException` raised.
- **Observability**: Calling `.set(...)` on cached registry raises.
- **Repository Evidence**: `_CachedSpanAttributesRegistry` docstring: "should only be used for the persisted spans that are immutable".
- **Architecture Check**: `check_sr13_arch`
- **Behavior Check**: `check_sr13_behavior`

## SR-14: `create_mlflow_span()` factory function
- **Requirement**: Create appropriate MLflow span (`LiveSpan`, `Span`, or `NoOpSpan`) based on OTel span type.
- **Task Evidence**: Interface Description 2 specifies `create_mlflow_span(otel_span, trace_id, span_type=None) -> Union['Span', 'LiveSpan', 'NoOpSpan']` on path `/testbed/mlflow/entities/span.py`.
- **Architecture Spec**: `check_sr14_arch`
- **Behavior Spec**: `check_sr14_behavior`
- **Critical Path**: `create_mlflow_span(otel_span, trace_id)` → type-dispatch: `OTelSpan` → `LiveSpan`; `OTelReadableSpan` (not OTelSpan) → `Span`; `NonRecordingSpan` or `None` → `NoOpSpan`.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: Correct subclass instance.
- **Observability**: `create_mlflow_span(NonRecordingSpan(context=None), "tr-test")` returns `NoOpSpan`; `create_mlflow_span(mock_otel_span, "tr-test")` returns `LiveSpan`.
- **Repository Evidence**: `mlflow/tracing/processor/otel.py:53` imports and calls `create_mlflow_span`; `mlflow/tracing/processor/inference_table.py:114` imports and calls it; `mlflow/tracing/processor/base_mlflow.py:87` imports and calls it; `mlflow/semantic_kernel/autolog.py:15,91` and others import it.
- **Architecture Check**: `check_sr14_arch`
- **Behavior Check**: `check_sr14_behavior`

## SR-15: `_decode_otel_proto_anyvalue()` utility
- **Requirement**: Decode `AnyValue` protobuf message into Python object, recursively handling arrays and kv-lists.
- **Task Evidence**: Interface Description 3 specifies `_decode_otel_proto_anyvalue(pb_any_value: AnyValue) -> Any` on path `/testbed/mlflow/tracing/utils/otlp.py`.
- **Architecture Spec**: `check_sr15_arch`
- **Behavior Spec**: `check_sr15_behavior`
- **Critical Path**: `_decode_otel_proto_anyvalue(any_value)` → uses `WhichOneof("value")` to determine type → returns matching Python type; recursively handles array_value and kvlist_value.
- **Expected Intermediate State**: N/A.
- **Expected Final Output**: Python `None`, `bool`, `str`, `int`, `float`, `bytes`, `list`, or `dict`.
- **Observability**: Round-trip `_set_otel_proto_anyvalue` then `_decode_otel_proto_anyvalue` returns original value.
- **Repository Evidence**: `_set_otel_proto_anyvalue` already exists in `mlflow/tracing/utils/otlp.py`; `tests/entities/test_span_event.py:test_span_event_to_otel_proto_conversion` imports and uses `_decode_otel_proto_anyvalue`; `AnyValue` imported from `opentelemetry.proto.common.v1.common_pb2`.
- **Architecture Check**: `check_sr15_arch`
- **Behavior Check**: `check_sr15_behavior`

## Uncertainties
- `Span.from_dict` internally references `_is_base64_encoded`, `_decode_id_from_byte`, `_is_span_v2_schema`, and `from_dict_v2` which are not defined in the repository. These are static analysis issues and must be defined for `from_dict` to work. They are referenced from existing code but not part of the interface descriptions.
- `LiveSpan.end` references `apply_span_processors` which is not defined or imported. This must be resolved for `end()` to work.
- `_Trace.to_mlflow_trace` references `set_request_response_preview` which is not defined. Must be resolved.
