"""
Behavior specification: L3 State, Behavior, Failure, SideEffect, defaults,
boundaries, and compatibility contracts.

Every contract ID appears in a ``# Contracts: C<n>, ...`` comment above the
corresponding assertion.
"""

import sys
import warnings

sys.path.insert(0, "/testbed")


def _skip(*reason: str) -> None:
    """Report a skipped contract because an implementation component is missing."""
    print(f"  SKIP ({' '.join(reason)})")


# ═══════════════════════════════════════════════════════════════════════════════
# C1 – AssessmentSourceType initializes with valid string
# ═══════════════════════════════════════════════════════════════════════════════
def check_C1() -> None:
    """Contracts: C1"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not hasattr(AssessmentSourceType, "_parse"):
        _skip("AssessmentSourceType._parse not implemented")
        return

    from mlflow.entities.assessment_source import AssessmentSource

    src = AssessmentSource(source_type="HUMAN")
    assert src.source_type == "HUMAN", f"Expected 'HUMAN', got '{src.source_type}'"
    print("PASS: C1 – AssessmentSourceType initialization produces correct str()")


# ═══════════════════════════════════════════════════════════════════════════════
# C2 – AssessmentSourceType normalizes case-insensitive input
# ═══════════════════════════════════════════════════════════════════════════════
def check_C2() -> None:
    """Contracts: C2"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not hasattr(AssessmentSourceType, "_parse"):
        _skip("AssessmentSourceType._parse not implemented")
        return

    assert AssessmentSourceType._parse("human") == "HUMAN"
    assert AssessmentSourceType._parse("LlM_jUdGe") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("CODE") == "CODE"
    print("PASS: C2 – _parse normalizes case-insensitive input to uppercase")


# ═══════════════════════════════════════════════════════════════════════════════
# C3 – AssessmentSourceType raises on invalid source type
# ═══════════════════════════════════════════════════════════════════════════════
def check_C3() -> None:
    """Contracts: C3"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not hasattr(AssessmentSourceType, "_parse"):
        _skip("AssessmentSourceType._parse not implemented")
        return

    from mlflow.exceptions import MlflowException
    from mlflow.entities.assessment_source import AssessmentSource

    try:
        AssessmentSource(source_type="ROBOT")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e), (
            f"Wrong message: {e}"
        )
    print("PASS: C3 – raises MlflowException on invalid source type")


# ═══════════════════════════════════════════════════════════════════════════════
# C4 – AssessmentSourceType converts AI_JUDGE with deprecation warning
# ═══════════════════════════════════════════════════════════════════════════════
def check_C4() -> None:
    """Contracts: C4"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not hasattr(AssessmentSourceType, "_parse"):
        _skip("AssessmentSourceType._parse not implemented")
        return

    from mlflow.entities.assessment_source import AssessmentSource

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        src = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
        future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        assert len(future_warnings) >= 1, "No FutureWarning emitted for AI_JUDGE"
        msg = str(future_warnings[0].message)
        assert "AI_JUDGE is deprecated" in msg, f"Wrong warning message: {msg}"
        assert "LLM_JUDGE" in msg, f"LLM_JUDGE not mentioned in warning: {msg}"
        assert src.source_type == "LLM_JUDGE", (
            f"Expected 'LLM_JUDGE', got '{src.source_type}'"
        )
    print("PASS: C4 – AI_JUDGE emits FutureWarning and returns LLM_JUDGE")


# ═══════════════════════════════════════════════════════════════════════════════
# C5 – AssessmentSourceType._standardize returns standardized string
# ═══════════════════════════════════════════════════════════════════════════════
def check_C5() -> None:
    """Contracts: C5"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not hasattr(AssessmentSourceType, "_standardize"):
        _skip("AssessmentSourceType._standardize not implemented")
        return

    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("code") == "CODE"
    assert AssessmentSourceType._standardize("SOURCE_TYPE_UNSPECIFIED") == "SOURCE_TYPE_UNSPECIFIED"
    print("PASS: C5 – _standardize returns uppercase string via instance construction")


# ═══════════════════════════════════════════════════════════════════════════════
# C8 – CustomScorer delegates __call__ to original function
# ═══════════════════════════════════════════════════════════════════════════════
def check_C8() -> None:
    """Contracts: C8"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    @scorer
    def _len_test(inputs, outputs) -> int:
        return len(str(outputs))

    result = _len_test.run(inputs="in", outputs="hello")
    assert result == 5, f"Expected 5, got {result}"

    result2 = _len_test(inputs="in", outputs="world!")
    assert result2 == 6, f"Expected 6, got {result2}"
    print("PASS: C8 – CustomScorer delegates __call__ to original function")


# ═══════════════════════════════════════════════════════════════════════════════
# C12 – model_validate reconstructs decorator scorer from serialized dict
# ═══════════════════════════════════════════════════════════════════════════════
def check_C12() -> None:
    """Contracts: C12"""
    from unittest.mock import patch

    from mlflow.genai.scorers.base import Scorer, ScorerKind, SerializedScorer

    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented (needed for model_validate reconstruction)")
        return

    serialized = SerializedScorer(
        name="test_C12",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="test_C12",
    )

    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        reconstructed = Scorer.model_validate(serialized)
        assert reconstructed is not None
        assert reconstructed.name == "test_C12"
        assert reconstructed.kind == ScorerKind.DECORATOR
        result = reconstructed.run(outputs="anything")
        assert result is True
    print("PASS: C12 – model_validate reconstructs decorator scorer from serialized dict")


# ═══════════════════════════════════════════════════════════════════════════════
# C13 – _reconstruct_decorator_scorer blocks outside Databricks
# ═══════════════════════════════════════════════════════════════════════════════
def check_C13() -> None:
    """Contracts: C13"""
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer, SerializedScorer

    serialized = SerializedScorer(
        name="blocked_C13",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="blocked_C13",
    )

    try:
        Scorer._reconstruct_decorator_scorer(serialized)
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        msg = str(e)
        assert "Loading custom scorer" in msg or "not supported" in msg, (
            f"Wrong error message: {msg}"
        )
    print("PASS: C13 – _reconstruct_decorator_scorer blocks outside Databricks runtime")


# ═══════════════════════════════════════════════════════════════════════════════
# C14 – _reconstruct_decorator_scorer blocks Databricks remote access
# ═══════════════════════════════════════════════════════════════════════════════
def check_C14() -> None:
    """Contracts: C14"""
    from unittest.mock import patch

    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer, SerializedScorer

    serialized = SerializedScorer(
        name="blocked_C14",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="blocked_C14",
    )

    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=False):
        with patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True):
            try:
                Scorer._reconstruct_decorator_scorer(serialized)
                assert False, "Should have raised MlflowException"
            except MlflowException as e:
                msg = str(e)
                assert "remote access" in msg or "not supported" in msg, (
                    f"Wrong error message: {msg}"
                )
    print("PASS: C14 – _reconstruct_decorator_scorer blocks remote Databricks access")


# ═══════════════════════════════════════════════════════════════════════════════
# C16 – recreate_function builds working callable
# ═══════════════════════════════════════════════════════════════════════════════
def check_C16() -> None:
    """Contracts: C16"""
    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented")
        return

    f = recreate_function("return x + y", "(x, y)", "add_C16")
    assert f is not None
    assert f.__name__ == "add_C16"
    assert f(3, 4) == 7
    print("PASS: C16 – recreate_function builds working callable with correct name")


# ═══════════════════════════════════════════════════════════════════════════════
# C17 – recreate_function raises SyntaxError on bad source
# ═══════════════════════════════════════════════════════════════════════════════
def check_C17() -> None:
    """Contracts: C17"""
    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented")
        return

    try:
        recreate_function("if x > 0\n    return True", "(x)", "bad_C17")
        assert False, "Should have raised SyntaxError"
    except SyntaxError:
        pass
    print("PASS: C17 – recreate_function raises SyntaxError on invalid source")


# ═══════════════════════════════════════════════════════════════════════════════
# C18 – recreate_function raises MlflowException on invalid signature
# ═══════════════════════════════════════════════════════════════════════════════
def check_C18() -> None:
    """Contracts: C18"""
    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented")
        return

    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    try:
        recreate_function("return 1", "not a sig", "bad_C18")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        assert e.error_code == INVALID_PARAMETER_VALUE, (
            f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}"
        )
    print("PASS: C18 – recreate_function raises MlflowException on invalid signature")


# ═══════════════════════════════════════════════════════════════════════════════
# C20 – FunctionBodyExtractor extracts body without docstring
# ═══════════════════════════════════════════════════════════════════════════════
def check_C20() -> None:
    """Contracts: C20"""
    try:
        from mlflow.genai.scorers.scorer_utils import extract_function_body
    except ImportError:
        _skip("extract_function_body not implemented")
        return

    def _func_with_doc(x):
        """This is a docstring."""
        return x

    body_str, indent_unit = extract_function_body(_func_with_doc)
    assert "return x" in body_str, f"Body should contain 'return x', got: {body_str!r}"
    assert "This is a docstring" not in body_str, "Docstring should be excluded"
    assert isinstance(indent_unit, int), f"indent_unit should be int, got {type(indent_unit)}"
    print("PASS: C20 – extract_function_body excludes docstring, returns body with indent")


# ═══════════════════════════════════════════════════════════════════════════════
# C21 – Scorer.run validates return types strictly
# ═══════════════════════════════════════════════════════════════════════════════
def check_C21() -> None:
    """Contracts: C21"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    from mlflow.exceptions import MlflowException

    @scorer
    def _bad_return(inputs, outputs) -> dict:
        return {"key": "value"}

    try:
        _bad_return.run(inputs="in", outputs="out")
        assert False, "Should have raised MlflowException"
    except MlflowException as e:
        msg = str(e)
        valid_patterns = [
            "must return one of",
            "int, float, bool, str, Feedback",
            "list[Feedback]",
        ]
        assert any(p in msg for p in valid_patterns), (
            f"Error message doesn't mention valid types: {msg}"
        )
    print("PASS: C21 – Scorer.run raises MlflowException for invalid return types")


# ═══════════════════════════════════════════════════════════════════════════════
# C22 – Scorer.run overwrites default Feedback name
# ═══════════════════════════════════════════════════════════════════════════════
def check_C22() -> None:
    """Contracts: C22"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    from mlflow.entities import Feedback

    @scorer
    def my_scorer_C22(inputs, outputs) -> Feedback:
        return Feedback(value=42, rationale="test")

    feedback = my_scorer_C22.run(
        inputs={"question": "q"}, outputs="answer"
    )
    assert isinstance(feedback, Feedback)
    assert feedback.name == "my_scorer_C22", (
        f"Expected name 'my_scorer_C22', got '{feedback.name}'"
    )
    assert feedback.value == 42
    print("PASS: C22 – Scorer.run overwrites default Feedback name with scorer name")


# ═══════════════════════════════════════════════════════════════════════════════
# C23 – Scorer.run does not overwrite custom Feedback name
# ═══════════════════════════════════════════════════════════════════════════════
def check_C23() -> None:
    """Contracts: C23"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    from mlflow.entities import Feedback

    @scorer
    def my_scorer_C23(inputs, outputs) -> Feedback:
        return Feedback(name="custom_name_C23", value=99)

    feedback = my_scorer_C23.run(
        inputs={"question": "q"}, outputs="answer"
    )
    assert feedback.name == "custom_name_C23", (
        f"Expected 'custom_name_C23', got '{feedback.name}'"
    )
    assert feedback.value == 99
    print("PASS: C23 – Scorer.run preserves explicit Feedback name")


# ═══════════════════════════════════════════════════════════════════════════════
# C24 – Scorer.run does not overwrite names in Feedback list
# ═══════════════════════════════════════════════════════════════════════════════
def check_C24() -> None:
    """Contracts: C24"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    from mlflow.entities import Feedback

    @scorer
    def my_scorer_C24(inputs, outputs) -> list:
        return [
            Feedback(name="first_C24", value=1),
            Feedback(name="second_C24", value=2),
        ]

    feedbacks = my_scorer_C24.run(
        inputs={"question": "q"}, outputs="answer"
    )
    assert isinstance(feedbacks, list), f"Expected list, got {type(feedbacks)}"
    assert len(feedbacks) == 2
    assert feedbacks[0].name == "first_C24", f"Expected 'first_C24', got '{feedbacks[0].name}'"
    assert feedbacks[0].value == 1
    assert feedbacks[1].name == "second_C24", f"Expected 'second_C24', got '{feedbacks[1].name}'"
    assert feedbacks[1].value == 2
    print("PASS: C24 – Scorer.run preserves names in Feedback list")


# ═══════════════════════════════════════════════════════════════════════════════
# Additional boundary checks
# ═══════════════════════════════════════════════════════════════════════════════

def check_C9_boundary_signature_preserves_kwargs() -> None:
    """Verify __call__ signature includes keyword-only params from original."""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    import inspect as _inspect

    @scorer
    def _kwarg_test(inputs, *, extra=None) -> str:
        return str(extra or "default")

    sig = _inspect.signature(_kwarg_test.__call__)
    bound = sig.bind("self", inputs="hello", extra="custom")
    assert bound.arguments["extra"] == "custom"
    print("PASS: C9-boundary – CustomScorer signature preserves keyword-only params")


def check_dump_roundtrip_decorator_scorer() -> None:
    """Verify model_dump -> model_validate roundtrip preserves name and behavior."""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented (needed for roundtrip)")
        return

    from unittest.mock import patch

    from mlflow.genai.scorers.base import Scorer, ScorerKind

    @scorer
    def _roundtrip_test(outputs) -> bool:
        return len(str(outputs)) > 3

    dumped = _roundtrip_test.model_dump()

    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        reconstructed = Scorer.model_validate(dumped)
        assert reconstructed.name == "_roundtrip_test"
        assert reconstructed.kind == ScorerKind.DECORATOR
        result = reconstructed.run(outputs="hello!")
        assert result is True
        result2 = reconstructed.run(outputs="hi")
        assert result2 is False
    print("PASS: dump-roundtrip – model_dump->model_validate preserves name and behavior")


def check_AssessmentSourceType_direct_instance() -> None:
    """Verify AssessmentSourceType can be instantiated directly."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not (hasattr(AssessmentSourceType, "_parse") and
            hasattr(AssessmentSourceType, "__str__") and
            callable(getattr(AssessmentSourceType, "__init__", None))):
        _skip("AssessmentSourceType instance methods not implemented")
        return

    inst = AssessmentSourceType("code")
    assert str(inst) == "CODE"
    print("PASS: AssessmentSourceType direct instantiation returns correct str()")


def check_scorer_none_return() -> None:
    """Verify scorer can return None (C21 boundary)."""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    @scorer
    def _none_scorer(inputs, outputs):
        return None

    result = _none_scorer.run(inputs="in", outputs="out")
    assert result is None
    print("PASS: scorer – None return from scorer is allowed")


def check_recreate_function_complex() -> None:
    """Verify recreate_function handles control flow and multi-line source."""
    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented")
        return

    source = """if x > 0:
    return "positive"
else:
    return "non-positive" """
    f = recreate_function(source, "(x)", "classify")
    assert f(5) == "positive"
    assert f(-3) == "non-positive"
    assert f(0) == "non-positive"
    print("PASS: recreate_function handles control flow")


def check_recreate_function_signature_with_defaults() -> None:
    """Verify recreate_function handles default parameter values."""
    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented")
        return

    f = recreate_function("return base ** exponent", "(base, exponent=2)", "power")
    assert f(3) == 9
    assert f(2, 3) == 8
    print("PASS: recreate_function handles signature defaults")


def check_model_dump_rejects_direct_subclass() -> None:
    """Contracts: C10 boundary
    Verify model_dump raises for direct Scorer subclass (not decorator/builtin).
    """
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer

    class DirectSubclass(Scorer):
        def __call__(self, inputs, outputs):
            return "ok"

    inst = DirectSubclass(name="direct_sub")
    try:
        inst.model_dump()
        assert False, "Should have raised"
    except MlflowException as e:
        assert "Unsupported scorer type" in str(e) or "not supported" in str(e)
    print("PASS: model_dump rejects direct Scorer subclass")


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    checks = [
        check_C1,
        check_C2,
        check_C3,
        check_C4,
        check_C5,
        check_C8,
        check_C12,
        check_C13,
        check_C14,
        check_C16,
        check_C17,
        check_C18,
        check_C20,
        check_C21,
        check_C22,
        check_C23,
        check_C24,
        check_C9_boundary_signature_preserves_kwargs,
        check_dump_roundtrip_decorator_scorer,
        check_AssessmentSourceType_direct_instance,
        check_scorer_none_return,
        check_recreate_function_complex,
        check_recreate_function_signature_with_defaults,
        check_model_dump_rejects_direct_subclass,
    ]
    for check in checks:
        check()
    print("\nbehavior_spec.py complete.")
