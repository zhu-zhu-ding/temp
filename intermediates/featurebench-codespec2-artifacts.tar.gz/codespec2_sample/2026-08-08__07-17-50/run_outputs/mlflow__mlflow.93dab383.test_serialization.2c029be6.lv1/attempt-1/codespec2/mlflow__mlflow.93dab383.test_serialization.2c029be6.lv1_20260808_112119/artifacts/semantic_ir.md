# Semantic IR

## L1. Requirement Obligations

### R1: Assessment source type validation and standardization
- **Type:** Behavior
- **Statement:** The system must accept a string source_type, convert it case-insensitively to uppercase, validate it against a known set (`SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `HUMAN`, `CODE`), and raise `MlflowException` for invalid values.
- **Task Evidence:** "Parse, validate, and standardize assessment source types" and "Case-insensitive string inputs (converts to uppercase)" and `Raises: MlflowException: If the provided source_type is not one of the valid source types.`
- **Acceptance:** `AssessmentSourceType("human")` yields instance whose `__str__()` is `"HUMAN"`; `AssessmentSourceType("ROBOT")` raises `MlflowException` matching `"Invalid assessment source type"`.
- **Repository Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` (line 52-65), `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_type_validation` (line 42-49), `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` (calls `_standardize`).
- **Uncertainty:** None.

### R2: Backward compatibility for deprecated AI_JUDGE
- **Type:** Compatibility
- **Statement:** The legacy value `"AI_JUDGE"` must be automatically converted to `"LLM_JUDGE"` with a `FutureWarning` issued to the caller.
- **Task Evidence:** "Maintain backward compatibility while deprecating legacy source types" and "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE' with a deprecation warning."
- **Acceptance:** `AssessmentSourceType("AI_JUDGE")` emits `FutureWarning(match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and `__str__()` returns `"LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` (line 68-73), `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_type_validation` (line 46-48).
- **Uncertainty:** None.

### R3: AssessmentSourceType instance construction and string representation
- **Type:** Interface
- **Statement:** `AssessmentSourceType(source_type)` must store the parsed/validated result and `__str__` must return the standardized uppercase string.
- **Task Evidence:** `__init__`: "Initialize an AssessmentSourceType instance with validation and standardization." and `__str__`: "Return the string representation of the assessment source type."
- **Acceptance:** `str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` (line 52-65).
- **Uncertainty:** None.

### R4: Static _parse method for validation
- **Type:** Behavior
- **Statement:** `AssessmentSourceType._parse(source_type)` must accept a string, uppercase it, check for the deprecated `AI_JUDGE` value (warn + remap), validate membership in `_SOURCE_TYPES`, and return the standardized string.
- **Task Evidence:** `_parse`: "Parse and validate an assessment source type string." with listed returns, raises, and warnings.
- **Acceptance:** `AssessmentSourceType._parse("human") == "HUMAN"`; `AssessmentSourceType._parse("AI_JUDGE")` emits `FutureWarning` and returns `"LLM_JUDGE"`; `AssessmentSourceType._parse("INVALID")` raises `MlflowException`.
- **Repository Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_type_validation` (line 42-49), `/testbed/tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` (line 68-73).
- **Uncertainty:** None.

### R5: Static _standardize method as convenience wrapper
- **Type:** Interface
- **Statement:** `AssessmentSourceType._standardize(source_type)` must create an `AssessmentSourceType` instance from the string and return `str()` of it, providing a single-call validation-and-normalization path.
- **Task Evidence:** `_standardize`: "Standardize and validate an assessment source type string... by creating a temporary AssessmentSourceType instance and converting it to its string representation."
- **Acceptance:** `AssessmentSourceType._standardize("human") == "HUMAN"`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` (line 78 calls `AssessmentSourceType._standardize(self.source_type)`).
- **Uncertainty:** None.

### R6: scorer decorator with optional arguments
- **Type:** Interface
- **Statement:** A `scorer` function must work both as a bare decorator (`@scorer`) and as a parameterized decorator (`@scorer(name="...", description="...", aggregations=[...])`). When called with `func=None`, it returns a `functools.partial` binding the keyword arguments for later application.
- **Task Evidence:** "Args: func: The scorer function to be decorated. name: The name of the scorer..." and example shows both `@scorer` (bare) and implied `@scorer(name=...)` usage.
- **Acceptance:** `scorer` called with no positional argument returns a callable partial; `scorer(some_func)` returns a `CustomScorer` instance; `scorer(name="x")(some_func)` also returns a `CustomScorer` with `name="x"`.
- **Repository Evidence:** `/testbed/tests/genai/scorers/test_scorer.py` lines 153, 199, 248, 269, 277, 305, 318, 336 use both `@scorer` bare and `scorer(name="...")(func)`; `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 847-1038 (complete reference implementation).
- **Uncertainty:** None.

### R7: CustomScorer wraps user function with Scorer interface
- **Type:** Behavior
- **Statement:** The decorator must create a `CustomScorer` subclass of `Scorer` that delegates `__call__` to the original user function, stores the original function reference in `_original_func`, sets `kind` to `ScorerKind.DECORATOR`, and preserves the function's call signature on `__call__`.
- **Task Evidence:** "Returns: A CustomScorer instance that can be used in MLflow evaluation functions." and the decorator pattern implies wrapping.
- **Acceptance:** A `@scorer`-decorated function produces an object where `isinstance(result, Scorer)` is True, `result.kind == ScorerKind.DECORATOR`, and calling `result(inputs=..., outputs=...)` invokes the original function.
- **Repository Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` (line 62), `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 1004-1036 (CustomScorer inner class).
- **Uncertainty:** None.

### R8: Scorer name derivation from function or explicit parameter
- **Type:** Behavior
- **Statement:** When `name` is not provided, the scorer's name defaults to `func.__name__`. When `name` is explicitly provided, it overrides the function name.
- **Task Evidence:** "The metric name will be determined by the scorer function's name or a custom name specified in the `name` parameter for the scorer."
- **Acceptance:** `@scorer \n def my_func(...): ...` yields `scorer.name == "my_func"`; `@scorer(name="custom") \n def my_func(...): ...` yields `scorer.name == "custom"`.
- **Repository Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_scorer_name_works` (line 67-71).
- **Uncertainty:** None.

### R9: Scorer serialization via model_dump with source code extraction
- **Type:** Dataflow
- **Statement:** For decorator scorers, `model_dump()` must extract the original function's source body and signature via `_extract_source_code_info()`, populate a `SerializedScorer` dataclass with `call_source`, `call_signature`, and `original_func_name` fields, and cache the result.
- **Task Evidence:** "Provide secure serialization that handles source code extraction and reconstruction."
- **Acceptance:** Calling `.model_dump()` on a decorator scorer returns a dict containing keys `call_source`, `call_signature`, `original_func_name` with non-None values.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:Scorer.model_dump` (lines 149-184), `/testbed/mlflow/genai/scorers/base.py:Scorer._extract_source_code_info` (lines 186-200).
- **Uncertainty:** None.

### R10: Scorer deserialization via model_validate reconstructing from source
- **Type:** Dataflow
- **Statement:** `Scorer.model_validate()` must accept a `SerializedScorer` or dict, detect decorator scorers by presence of `call_source`/`call_signature`/`original_func_name`, and delegate to `_reconstruct_decorator_scorer` which uses `recreate_function` to rebuild the callable and re-applies the `scorer` decorator.
- **Task Evidence:** "Provide secure serialization that handles source code extraction and reconstruction."
- **Acceptance:** A serialized scorer dict with `call_source`, `call_signature`, `original_func_name` deserializes to a working `Scorer` instance.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:Scorer.model_validate` (lines 203-300), `/testbed/mlflow/genai/scorers/base.py:Scorer._reconstruct_decorator_scorer` (lines 302-373).
- **Uncertainty:** None.

### R11: Secure deserialization restricted to Databricks runtime
- **Type:** Failure
- **Statement:** `_reconstruct_decorator_scorer` must raise `MlflowException` when `is_in_databricks_runtime()` returns False, preventing arbitrary code execution outside controlled environments. Different error messages apply for Databricks remote vs. non-Databricks URIs.
- **Task Evidence:** "Secure code execution during scorer deserialization (restricted to controlled environments)" and "registration is only supported in Databricks environments due to security considerations around code execution during deserialization."
- **Acceptance:** Calling `Scorer._reconstruct_decorator_scorer(serialized)` outside Databricks raises `MlflowException` matching `"Loading custom scorer.*not supported"`.
- **Repository Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` (lines 275-285), `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_databricks_remote_access` (lines 288-303).
- **Uncertainty:** None.

### R12: Scorer run method validates return types
- **Type:** Failure
- **Statement:** `Scorer.run()` must accept only `int`, `float`, `bool`, `str`, `Feedback`/`Assessment`, `list[Feedback]`/`list[Assessment]`, or `None` as return values from the scorer function, raising `MlflowException` for any other type.
- **Task Evidence:** "Support various return types (primitives, Feedback objects, lists) from scorer functions" and "Raises: MlflowException: If the scorer function returns an unsupported type."
- **Acceptance:** A scorer returning a `dict` causes `MlflowException` matching `"must return one of int, float, bool, str, Feedback, or list[Feedback]"`.
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:Scorer.run` (lines 374-426).
- **Uncertainty:** None.

### R13: Feedback name overwrite for default-named single Feedback returns
- **Type:** Behavior
- **Statement:** When `run()` receives a single `Feedback` object with the default name (`DEFAULT_FEEDBACK_NAME` = `"feedback"`), it must overwrite the name to the scorer's name. When the Feedback has an explicit custom name or a list is returned, no overwrite occurs.
- **Task Evidence:** The `run()` method docstring and the interface description note about metric name determination.
- **Acceptance:** `@scorer \n def f(...): return Feedback(value=42)` → `run()` returns Feedback with `name == "f"`; `@scorer \n def f(...): return Feedback(name="custom", value=42)` → `run()` returns Feedback with `name == "custom"`.
- **Repository Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` (lines 227-247), `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list` (lines 250-262).
- **Uncertainty:** None.

### R14: extract_function_body utility for source code extraction
- **Type:** Behavior
- **Statement:** `extract_function_body(func)` must use `inspect.getsourcelines` and AST parsing via `FunctionBodyExtractor` to extract the body of a function (excluding signature and docstring) as a dedented string, returning `(body_str, indent_unit)`.
- **Task Evidence:** "Provide secure serialization that handles source code extraction and reconstruction."
- **Acceptance:** Given a function `def f(x):\n    return x + 1`, `extract_function_body(f)` returns `("return x + 1", 4)`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 15-72 (reference implementation), `/testbed/mlflow/genai/scorers/base.py` line 193 (caller).
- **Uncertainty:** None.

### R15: recreate_function for dynamic function reconstruction
- **Type:** Behavior
- **Statement:** `recreate_function(source, signature, func_name)` must parse the signature string, build a complete function definition string with `from __future__ import annotations`, execute it via `exec()` in a namespace containing `mlflow` and common entity imports, and return the resulting callable.
- **Task Evidence:** "Handle dynamic function reconstruction from serialized source code."
- **Acceptance:** `recreate_function("return x + y", "(x, y)", "add")` returns a callable `add` where `add(2, 3) == 5`; invalid source raises `SyntaxError`; invalid signature raises `MlflowException`.
- **Repository Evidence:** `/testbed/tests/genai/scorers/test_scorer_utils.py` (full test suite), `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 77-139 (reference implementation).
- **Uncertainty:** None.

### R16: FunctionBodyExtractor AST visitor class
- **Type:** Behavior
- **Statement:** `FunctionBodyExtractor` is an `ast.NodeVisitor` that locates a function definition by name in parsed source, extracts its body lines (skipping docstring), dedents them, and stores the result in `function_body` and `indent_unit` attributes.
- **Task Evidence:** Part of source code extraction infrastructure for serialization.
- **Acceptance:** The class correctly extracts function bodies with proper dedenting and indentation detection.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 22-55 (reference implementation).
- **Uncertainty:** None.

---

## L2. Functional Design Graph

### N1: AssessmentSourceType
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py` line 87

### N2: AssessmentSourceType.__init__
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py` (gap; reference: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 139)

### N3: AssessmentSourceType._parse
- **Kind:** Method (static)
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py` (gap; reference: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 142)

### N4: AssessmentSourceType.__str__
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py` (gap; reference: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 160)

### N5: AssessmentSourceType._standardize
- **Kind:** Method (static)
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py` (gap; reference: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 163)

### N6: AssessmentSource.__post_init__
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py` line 77

### N7: MlflowException
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/exceptions.py`

### N8: FutureWarning
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py` (called in `_parse`)

### N9: scorer (decorator function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` (gap at end of file; reference: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 847)

### N10: CustomScorer (inner class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` (gap; reference: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 1004)

### N11: Scorer (base class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 111

### N12: Scorer.model_dump
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 149

### N13: Scorer._extract_source_code_info
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 186

### N14: Scorer.model_validate
- **Kind:** Method (classmethod)
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 203

### N15: Scorer._reconstruct_decorator_scorer
- **Kind:** Method (classmethod)
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 302

### N16: Scorer.run
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 374

### N17: Scorer.__call__
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 427

### N18: SerializedScorer
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 62

### N19: extract_function_body
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/scorer_utils.py` (gap; reference: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` line 61)

### N20: FunctionBodyExtractor
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/scorer_utils.py` (gap; reference: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` line 22)

### N21: recreate_function
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/scorer_utils.py` (gap; reference: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` line 77)

### N22: ScorerKind.DECORATOR
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 29-36

### N23: DEFAULT_FEEDBACK_NAME
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py`

### N24: is_in_databricks_runtime
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/utils/databricks_utils.py`

### N25: is_databricks_uri
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/utils/uri.py`

### N26: functools.partial
- **Kind:** External
- **Repository Evidence:** Python standard library

### N27: inspect.signature / inspect.getsourcelines
- **Kind:** External
- **Repository Evidence:** Python standard library

### N28: exec (builtin)
- **Kind:** External
- **Repository Evidence:** Python builtin

---

### E1: scorer -> CustomScorer (when func provided)
- **Kind:** CONTROL
- **Condition:** `func is not None`
- **Transfer:** Creates inner `CustomScorer` class, instantiates it with `name=name or func.__name__`, `description`, `aggregations`, wires `_original_func` to `func`, patches `__call__.__signature__`.
- **Evidence:** Task doc "Returns: A CustomScorer instance"; `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 1001-1036.
- **Obligations:** R6, R7, R8

### E2: scorer -> functools.partial (when func is None)
- **Kind:** CONTROL
- **Condition:** `func is None`
- **Transfer:** Returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)` for deferred decoration.
- **Evidence:** Task doc implies `@scorer(name="...")` usage; `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 998-1000.
- **Obligations:** R6

### E3: CustomScorer.__call__ -> user func
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Delegates `*args, **kwargs` to the stored `_original_func`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 1019.
- **Obligations:** R7

### E4: CustomScorer.kind -> ScorerKind.DECORATOR
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns `ScorerKind.DECORATOR` constant.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 1022.
- **Obligations:** R7

### E5: Scorer.model_dump -> Scorer._extract_source_code_info
- **Kind:** CALL
- **Condition:** `getattr(self, "_original_func", None)` is truthy
- **Transfer:** Calls `_extract_source_code_info()` to get `call_source`, `call_signature`, `original_func_name`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 157-184.
- **Obligations:** R9

### E6: Scorer._extract_source_code_info -> extract_function_body
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Passes `self._original_func` to `extract_function_body`, receives `(call_body, indent_unit)`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` line 193; `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 188 (local import).
- **Obligations:** R9, R14

### E7: extract_function_body -> FunctionBodyExtractor
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Creates `FunctionBodyExtractor(func_name, dedented_source)`, calls `extractor.visit(parsed_source)`, returns `(extractor.function_body, extractor.indent_unit)`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 61-72.
- **Obligations:** R14, R16

### E8: FunctionBodyExtractor -> AST
- **Kind:** CALL
- **Condition:** Node matches `func_name`
- **Transfer:** Visits AST nodes, extracts body lines skipping docstring, dedents, computes `indent_unit`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 22-55.
- **Obligations:** R16

### E9: Scorer.model_validate -> Scorer._reconstruct_decorator_scorer
- **Kind:** CALL
- **Condition:** `serialized.call_source` and `serialized.call_signature` and `serialized.original_func_name` are all truthy
- **Transfer:** Passes `SerializedScorer` instance to `_reconstruct_decorator_scorer`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 248-250.
- **Obligations:** R10

### E10: Scorer._reconstruct_decorator_scorer -> is_in_databricks_runtime
- **Kind:** CONTROL
- **Condition:** Always (guard check)
- **Transfer:** If `is_in_databricks_runtime()` is False, raises `MlflowException`; otherwise proceeds.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 305-335.
- **Obligations:** R11

### E11: Scorer._reconstruct_decorator_scorer -> recreate_function
- **Kind:** CALL
- **Condition:** `is_in_databricks_runtime()` is True
- **Transfer:** Passes `(serialized.call_source, serialized.call_signature, serialized.original_func_name)` to `recreate_function`, receives recreated callable.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 346-348; `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 303 (local import).
- **Obligations:** R10, R15

### E12: Scorer._reconstruct_decorator_scorer -> scorer (re-apply decorator)
- **Kind:** CALL
- **Condition:** `recreate_function` succeeds
- **Transfer:** Calls `scorer(recreated_func, name=..., description=..., aggregations=...)` to produce a new `CustomScorer` with cached serialized data.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 356-363.
- **Obligations:** R10

### E13: recreate_function -> exec
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Builds function definition string with `from __future__ import annotations`, indented source, namespace with `mlflow` and entity imports; calls `exec(func_def, import_namespace, local_namespace)`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 77-139.
- **Obligations:** R15

### E14: Scorer.run -> Scorer.__call__
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Filters kwargs to match `__call__` signature parameters (`inputs`, `outputs`, `expectations`, `trace`), invokes `self(**filtered)`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 374-390.
- **Obligations:** R12

### E15: Scorer.run -> return type validation
- **Kind:** CONTROL
- **Condition:** Result is not `int|float|bool|str|Assessment|Feedback|list[Assessment|Feedback]|None`
- **Transfer:** Raises `MlflowException` with message listing valid return types.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 390-403.
- **Obligations:** R12

### E16: Scorer.run -> DEFAULT_FEEDBACK_NAME overwrite
- **Kind:** DATA
- **Condition:** Result is single `Feedback` with `name == DEFAULT_FEEDBACK_NAME`
- **Transfer:** Sets `result.name = self.name`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py` lines 404-420.
- **Obligations:** R13

### E17: AssessmentSourceType.__init__ -> AssessmentSourceType._parse
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Passes `source_type` string to `_parse`, stores result as `self._source_type`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 139-140.
- **Obligations:** R1, R3

### E18: AssessmentSourceType._parse -> FutureWarning (AI_JUDGE)
- **Kind:** CONTROL
- **Condition:** `source_type == "AI_JUDGE"`
- **Transfer:** Issues `warnings.warn("AI_JUDGE is deprecated. Use LLM_JUDGE instead.", FutureWarning)`, remaps to `"LLM_JUDGE"`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 146-151.
- **Obligations:** R2

### E19: AssessmentSourceType._parse -> MlflowException (invalid)
- **Kind:** CONTROL
- **Condition:** `source_type not in _SOURCE_TYPES`
- **Transfer:** Raises `MlflowException` with `"Invalid assessment source type: {source_type}. Valid source types: {_SOURCE_TYPES}"`.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 153-159.
- **Obligations:** R1

### E20: AssessmentSourceType.__str__ -> self._source_type
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns `self._source_type` (the stored standardized string).
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 160-161.
- **Obligations:** R3

### E21: AssessmentSourceType._standardize -> AssessmentSourceType.__init__ + __str__
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Creates `AssessmentSourceType(source_type)` instance and returns `str()` of it.
- **Evidence:** `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 163-164.
- **Obligations:** R5

### E22: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
- **Kind:** CALL
- **Condition:** Always (during `__post_init__`)
- **Transfer:** Passes `self.source_type` to `_standardize`, assigns result back to `self.source_type`.
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py` line 78.
- **Obligations:** R5

---

## L3. Verifiable Contracts

### C1: AssessmentSourceType initializes with valid string
- **Type:** State
- **Subject:** `AssessmentSourceType.__init__`
- **Relation:** EQ
- **Expected:** `str(AssessmentSourceType("HUMAN")) == "HUMAN"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` (line 52-65) asserts `source_1.source_type == "HUMAN"` after `AssessmentSource(source_type="human")`.
- **Observe:** RETURN_VALUE (via `str()` or `.source_type` on `AssessmentSource`)
- **Target:** `AssessmentSource(source_type="human").source_type`
- **Obligations:** R1, R3
- **Graph:** N1, N2, N17, E17, E20

### C2: AssessmentSourceType normalizes case-insensitive input
- **Type:** Behavior
- **Subject:** `AssessmentSourceType._parse`
- **Relation:** EQ
- **Expected:** `AssessmentSourceType._parse("human") == "HUMAN"` and `AssessmentSourceType._parse("LlM_jUdGe") == "LLM_JUDGE"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` (line 52-65) tests "human", "Human", "HUMAN", "llm_judge", "Llm_Judge", "LLM_JUDGE".
- **Observe:** RETURN_VALUE
- **Target:** `AssessmentSourceType._parse("human")`
- **Obligations:** R1, R4
- **Graph:** N3, E17

### C3: AssessmentSourceType raises on invalid source type
- **Type:** Failure
- **Subject:** `AssessmentSourceType._parse`
- **Relation:** RAISES
- **Expected:** `MlflowException` with message matching `"Invalid assessment source type"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_type_validation` (line 49) `pytest.raises(MlflowException, match="Invalid assessment source type")`.
- **Observe:** EXCEPTION
- **Target:** `AssessmentSource(source_type="ROBOT")` → triggers `__post_init__` → `_standardize` → `_parse`
- **Obligations:** R1, R4
- **Graph:** N3, N7, E19

### C4: AssessmentSourceType converts AI_JUDGE with deprecation warning
- **Type:** SideEffect
- **Subject:** `AssessmentSourceType._parse` for `"AI_JUDGE"` input
- **Relation:** EQ (result) + SideEffect (warning)
- **Expected:** Returns `"LLM_JUDGE"` AND emits `FutureWarning(match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` (line 68-73) `pytest.warns(FutureWarning, match=...)` and `assert source.source_type == "LLM_JUDGE"`.
- **Observe:** RETURN_VALUE + SIDE_EFFECT (warnings)
- **Target:** `AssessmentSource(source_type="AI_JUDGE").source_type`
- **Obligations:** R2, R4
- **Graph:** N3, N8, E18

### C5: AssessmentSourceType._standardize returns standardized string
- **Type:** Behavior
- **Subject:** `AssessmentSourceType._standardize`
- **Relation:** EQ
- **Expected:** `AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"`
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` (line 78) calls `_standardize`; `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` (line 52-65).
- **Observe:** RETURN_VALUE
- **Target:** `AssessmentSourceType._standardize("llm_judge")`
- **Obligations:** R5
- **Graph:** N5, E21

### C6: scorer decorator works bare (@scorer without arguments)
- **Type:** Interface
- **Subject:** `scorer(func)` when called with a function
- **Relation:** TYPE_IS
- **Expected:** Returns instance that `isinstance(..., Scorer)` is True and `result.kind == ScorerKind.DECORATOR`
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` (line 62) uses `scorer(always_yes)`.
- **Observe:** RETURN_VALUE
- **Target:** `scorer(lambda outputs: True)`
- **Obligations:** R6, R7
- **Graph:** N9, N10, N11, N22, E1

### C7: scorer decorator works with arguments (@scorer(name="..."))
- **Type:** Interface
- **Subject:** `scorer(name="custom_name")` returning a partial
- **Relation:** TYPE_IS
- **Expected:** Returns `functools.partial`; applying it to a function produces `Scorer` with `name == "custom_name"`
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_scorer_name_works` (line 67-71) uses `scorer(name="always_no")(always_yes)`.
- **Observe:** RETURN_VALUE
- **Target:** `scorer(name="test")(some_func).name`
- **Obligations:** R6, R8
- **Graph:** N9, N26, E2

### C8: CustomScorer delegates __call__ to original function
- **Type:** Behavior
- **Subject:** `CustomScorer.__call__`
- **Relation:** EQ
- **Expected:** For `@scorer \n def f(outputs): return len(outputs)`, calling `f(outputs="hello")` returns `5`.
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics` (line 62-64) verifies scorer produces metrics in evaluation.
- **Observe:** RETURN_VALUE
- **Target:** `scorer(lambda outputs: len(outputs)).run(outputs="hello")`
- **Obligations:** R7
- **Graph:** N10, N17, E3

### C9: CustomScorer preserves original function signature
- **Type:** Interface
- **Subject:** `CustomScorer.__call__.__signature__`
- **Relation:** PRESERVE
- **Expected:** `inspect.signature(custom_scorer.__call__)` has parameters matching the original function (with `self` prepended).
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 1026-1031 (signature patching).
- **Observe:** FIELD_READ
- **Target:** `inspect.signature(scorer_instance.__call__)`
- **Obligations:** R7
- **Graph:** N10, N17, N27, E1

### C10: Scorer.model_dump includes source code for decorator scorers
- **Type:** Dataflow
- **Subject:** `Scorer.model_dump()` on decorator scorer
- **Relation:** CONTAINS
- **Expected:** Result dict has keys `"call_source"`, `"call_signature"`, `"original_func_name"` all with non-None string values.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:Scorer.model_dump` (lines 149-184) populates `SerializedScorer`.
- **Observe:** RETURN_VALUE
- **Target:** `scorer(lambda outputs: True).model_dump()`
- **Obligations:** R9
- **Graph:** N12, N13, N18, N19, E5, E6

### C11: _extract_source_code_info imports extract_function_body locally
- **Type:** Dataflow
- **Subject:** `Scorer._extract_source_code_info`
- **Relation:** CALLS
- **Expected:** Contains `from mlflow.genai.scorers.scorer_utils import extract_function_body` and invokes it.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 188 (local import present).
- **Observe:** RUNTIME_ARGUMENT_TRACE (code review: import exists in method body)
- **Target:** `/testbed/mlflow/genai/scorers/base.py` line in `_extract_source_code_info`
- **Obligations:** R9, R14
- **Graph:** N13, N19, E6

### C12: model_validate reconstructs decorator scorer from serialized dict
- **Type:** Behavior
- **Subject:** `Scorer.model_validate` with decorator scorer dict
- **Relation:** TYPE_IS
- **Expected:** Returns `Scorer` instance with correct `name` and `kind == ScorerKind.DECORATOR`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:Scorer.model_validate` (lines 203-300) routes to `_reconstruct_decorator_scorer`.
- **Observe:** RETURN_VALUE
- **Target:** `Scorer.model_validate({"name": "x", "call_source": "return True", "call_signature": "()", "original_func_name": "x"})`
- **Obligations:** R10
- **Graph:** N14, N15, N18, E9

### C13: _reconstruct_decorator_scorer blocks outside Databricks
- **Type:** Failure
- **Subject:** `Scorer._reconstruct_decorator_scorer` when `is_in_databricks_runtime()` is False
- **Relation:** RAISES
- **Expected:** `MlflowException` with message matching `"Loading custom scorer.*not supported"`
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` (lines 275-285).
- **Observe:** EXCEPTION
- **Target:** `Scorer._reconstruct_decorator_scorer(SerializedScorer(...))`
- **Obligations:** R11
- **Graph:** N15, N24, E10

### C14: _reconstruct_decorator_scorer blocks Databricks remote access
- **Type:** Failure
- **Subject:** `Scorer._reconstruct_decorator_scorer` when `is_in_databricks_runtime()` is False but `is_databricks_uri` is True
- **Relation:** RAISES
- **Expected:** `MlflowException` with message matching `"via remote access is not supported"`
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_databricks_remote_access` (lines 288-303).
- **Observe:** EXCEPTION
- **Target:** `Scorer._reconstruct_decorator_scorer(SerializedScorer(...))`
- **Obligations:** R11
- **Graph:** N15, N24, N25, E10

### C15: _reconstruct_decorator_scorer imports recreate_function locally
- **Type:** Dataflow
- **Subject:** `Scorer._reconstruct_decorator_scorer`
- **Relation:** CALLS
- **Expected:** Contains `from mlflow.genai.scorers.scorer_utils import recreate_function` and invokes it.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py` line 303 (local import present).
- **Observe:** RUNTIME_ARGUMENT_TRACE (code review: import exists in method body)
- **Target:** `/testbed/mlflow/genai/scorers/base.py` line in `_reconstruct_decorator_scorer`
- **Obligations:** R10, R15
- **Graph:** N15, N21, E11

### C16: recreate_function builds working callable
- **Type:** Behavior
- **Subject:** `recreate_function("return x + y", "(x, y)", "add")`
- **Relation:** EQ
- **Expected:** Returns callable `add` where `add(3, 4) == 7` and `add.__name__ == "add"`.
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer_utils.py::test_simple_function_recreation` (lines 12-23).
- **Observe:** RETURN_VALUE
- **Target:** `recreate_function("return x + y", "(x, y)", "add")(3, 4)`
- **Obligations:** R15
- **Graph:** N21, N28, E13

### C17: recreate_function raises SyntaxError on bad source
- **Type:** Failure
- **Subject:** `recreate_function` with syntax error in source
- **Relation:** RAISES
- **Expected:** `SyntaxError` (from `exec` of invalid Python)
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer_utils.py::test_function_with_syntax_error` (lines 55-62).
- **Observe:** EXCEPTION
- **Target:** `recreate_function("if x > 0\n    return True", "(x)", "bad")`
- **Obligations:** R15
- **Graph:** N21, N28, E13

### C18: recreate_function raises MlflowException on invalid signature
- **Type:** Failure
- **Subject:** `recreate_function` with unparseable signature
- **Relation:** RAISES
- **Expected:** `MlflowException` with `error_code=INVALID_PARAMETER_VALUE`
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer_utils.py::test_invalid_signature_format` (implicit in test patterns).
- **Observe:** EXCEPTION
- **Target:** `recreate_function("return 1", "not a sig", "f")`
- **Obligations:** R15
- **Graph:** N21, E13

### C19: recreate_function provides MLflow imports in namespace
- **Type:** Dataflow
- **Subject:** `recreate_function` namespace
- **Relation:** CONTAINS
- **Expected:** The `exec` namespace contains `Feedback`, `Assessment`, `AssessmentSource`, `AssessmentSourceType`, `Trace`, `CategoricalRating`, `mlflow`.
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer_utils.py::test_mlflow_imports_available` (lines 116-149) and `test_function_creating_feedback_object` (lines 85-97).
- **Observe:** SIDE_EFFECT (function can use `Feedback(...)` without import)
- **Target:** `recreate_function("return Feedback(value=True)", "()", "f")()`
- **Obligations:** R15
- **Graph:** N21, N28, E13

### C20: FunctionBodyExtractor extracts body without docstring
- **Type:** Behavior
- **Subject:** `extract_function_body` output
- **Relation:** EQ
- **Expected:** For `def f(x):\n    """doc"""\n    return x`, returns `("return x", 4)` — body string without docstring.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 38-41 (docstring skip logic).
- **Observe:** RETURN_VALUE
- **Target:** `extract_function_body(some_func_with_docstring)`
- **Obligations:** R14, R16
- **Graph:** N19, N20, E7, E8

### C21: Scorer.run validates return types strictly
- **Type:** Failure
- **Subject:** `Scorer.run` with unexpected return type
- **Relation:** RAISES
- **Expected:** `MlflowException` with message matching `"must return one of int, float, bool, str, Feedback, or list[Feedback]"`
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:Scorer.run` (lines 390-403).
- **Observe:** EXCEPTION
- **Target:** Scorer whose `__call__` returns `{"key": "value"}` → `run()`
- **Obligations:** R12
- **Graph:** N16, E14, E15

### C22: Scorer.run overwrites default Feedback name
- **Type:** State
- **Subject:** Single `Feedback` return with `name == DEFAULT_FEEDBACK_NAME`
- **Relation:** EQ
- **Expected:** After `run()`, the returned `Feedback.name == scorer.name`
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` (lines 227-247).
- **Observe:** FIELD_READ
- **Target:** `scorer_instance.run(...) .name`
- **Obligations:** R13
- **Graph:** N16, N23, E16

### C23: Scorer.run does not overwrite custom Feedback name
- **Type:** State
- **Subject:** Single `Feedback` return with explicit `name`
- **Relation:** EQ
- **Expected:** After `run()`, the returned `Feedback.name` equals the explicitly provided name, not the scorer name.
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` (line 236: `"custom_name"` stays).
- **Observe:** FIELD_READ
- **Target:** `scorer_instance.run(...) .name`
- **Obligations:** R13
- **Graph:** N16, E16

### C24: Scorer.run does not overwrite names in Feedback list
- **Type:** State
- **Subject:** `list[Feedback]` return
- **Relation:** UNCHANGED
- **Expected:** Each `Feedback` in the list retains its original `name`.
- **Evidence:** `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list` (lines 250-262).
- **Observe:** FIELD_READ
- **Target:** `scorer_instance.run(...)[0].name`
- **Obligations:** R13
- **Graph:** N16, E16

### C25: extract_function_body returns tuple of (body_str, indent_unit)
- **Type:** Interface
- **Subject:** `extract_function_body` return type
- **Relation:** TYPE_IS
- **Expected:** Returns `tuple[str, int]` where first element is the function body string and second is the indentation unit.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` line 61 (signature: `-> tuple[str, int]`).
- **Observe:** RETURN_VALUE
- **Target:** `type(extract_function_body(func))`
- **Obligations:** R14
- **Graph:** N19, E7

### C26: _parse static method validates and returns string
- **Type:** Interface
- **Subject:** `AssessmentSourceType._parse` signature
- **Relation:** TYPE_IS
- **Expected:** Is a `@staticmethod` accepting `str` and returning `str`.
- **Evidence:** Interface Description 2: `@staticmethod \n def _parse(source_type: str) -> str:`.
- **Observe:** IMPORT_BOUNDARY
- **Target:** `inspect.signature(AssessmentSourceType._parse)`
- **Obligations:** R4
- **Graph:** N3, E17

### C27: _standardize static method returns string
- **Type:** Interface
- **Subject:** `AssessmentSourceType._standardize` signature
- **Relation:** TYPE_IS
- **Expected:** Is a `@staticmethod` accepting `str` and returning `str`.
- **Evidence:** Interface Description 2: `@staticmethod \n def _standardize(source_type: str) -> str:`.
- **Observe:** IMPORT_BOUNDARY
- **Target:** `inspect.signature(AssessmentSourceType._standardize)`
- **Obligations:** R5
- **Graph:** N5, E21

### C28: scorer function appears in scorers __init__ module
- **Type:** Interface
- **Subject:** `mlflow.genai.scorers.scorer`
- **Relation:** TYPE_IS
- **Expected:** `scorer` is importable from `mlflow.genai.scorers` and listed in `__all__`.
- **Evidence:** `/testbed/mlflow/genai/scorers/__init__.py` line 48 lists `"scorer"` in `__all__`.
- **Observe:** IMPORT_BOUNDARY
- **Target:** `from mlflow.genai.scorers import scorer`
- **Obligations:** R6
- **Graph:** N9
