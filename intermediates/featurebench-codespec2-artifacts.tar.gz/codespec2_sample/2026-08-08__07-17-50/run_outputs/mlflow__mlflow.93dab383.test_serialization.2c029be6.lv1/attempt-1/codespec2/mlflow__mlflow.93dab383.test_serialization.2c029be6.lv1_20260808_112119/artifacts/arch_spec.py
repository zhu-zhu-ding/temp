"""
Architecture specification: L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.

Verifies public interface connectivity, import paths, call routing, signature
preservation, and dataflow injection points.  Every contract ID appears in a
``# Contracts: C<n>, ...`` comment above the corresponding assertion.
"""

import functools
import inspect
import sys
import warnings

sys.path.insert(0, "/testbed")


def _skip(*reason: str) -> None:
    """Report a skipped contract because an implementation component is missing."""
    print(f"  SKIP ({' '.join(reason)})")


# ═══════════════════════════════════════════════════════════════════════════════
# C26 – _parse static method validates and returns string
# ═══════════════════════════════════════════════════════════════════════════════
def check_C26() -> None:
    """Contracts: C26"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not hasattr(AssessmentSourceType, "_parse"):
        _skip("AssessmentSourceType._parse not implemented")
        return

    parse = AssessmentSourceType._parse
    sig = inspect.signature(parse)
    params = list(sig.parameters.values())
    assert len(params) == 1, f"Expected 1 param, got {len(params)}"
    assert params[0].name == "source_type", f"Expected 'source_type', got {params[0].name}"
    result = parse("HUMAN")
    assert isinstance(result, str), f"Expected str, got {type(result)}"
    assert result == "HUMAN"
    print("PASS: C26 – _parse static method signature and behavior verified")


# ═══════════════════════════════════════════════════════════════════════════════
# C27 – _standardize static method returns string
# ═══════════════════════════════════════════════════════════════════════════════
def check_C27() -> None:
    """Contracts: C27"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    if not hasattr(AssessmentSourceType, "_standardize"):
        _skip("AssessmentSourceType._standardize not implemented")
        return

    std = AssessmentSourceType._standardize
    sig = inspect.signature(std)
    params = list(sig.parameters.values())
    assert len(params) == 1, f"Expected 1 param, got {len(params)}"
    assert params[0].name == "source_type"
    result = std("human")
    assert isinstance(result, str), f"Expected str, got {type(result)}"
    assert result == "HUMAN"
    print("PASS: C27 – _standardize static method signature and behavior verified")


# ═══════════════════════════════════════════════════════════════════════════════
# C28 – scorer function appears in scorers __init__ module
# ═══════════════════════════════════════════════════════════════════════════════
def check_C28() -> None:
    """Contracts: C28"""
    import mlflow.genai.scorers as scorers_pkg

    assert "scorer" in scorers_pkg.__all__, "scorer not in mlflow.genai.scorers.__all__"

    try:
        from mlflow.genai.scorers import scorer  # noqa: F811

        assert callable(scorer), "scorer is not callable"
        print("PASS: C28 – scorer importable from mlflow.genai.scorers and in __all__")
    except ImportError:
        _skip("scorer not importable from mlflow.genai.scorers (decorator not wired)")


# ═══════════════════════════════════════════════════════════════════════════════
# C6 – scorer decorator works bare (@scorer without arguments)
# ═══════════════════════════════════════════════════════════════════════════════
def check_C6() -> None:
    """Contracts: C6"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    from mlflow.genai.scorers.base import Scorer, ScorerKind

    @scorer
    def _test_scorer_C6(outputs) -> bool:
        return bool(outputs)

    assert isinstance(_test_scorer_C6, Scorer), (
        f"Expected Scorer instance, got {type(_test_scorer_C6)}"
    )
    assert _test_scorer_C6.kind == ScorerKind.DECORATOR, (
        f"Expected DECORATOR kind, got {_test_scorer_C6.kind}"
    )
    result = _test_scorer_C6.run(outputs="hello")
    assert result is True
    print("PASS: C6 – scorer decorator works bare, returns Scorer with DECORATOR kind")


# ═══════════════════════════════════════════════════════════════════════════════
# C7 – scorer decorator works with arguments (@scorer(name="..."))
# ═══════════════════════════════════════════════════════════════════════════════
def check_C7() -> None:
    """Contracts: C7"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    from mlflow.genai.scorers.base import Scorer

    partial_or_callable = scorer(name="custom_name_C7")
    assert callable(partial_or_callable), (
        f"Expected callable partial, got {type(partial_or_callable)}"
    )
    decorated = partial_or_callable(lambda outputs: len(outputs))
    assert isinstance(decorated, Scorer)
    assert decorated.name == "custom_name_C7"
    print("PASS: C7 – scorer(name=...) returns callable that produces Scorer with custom name")


# ═══════════════════════════════════════════════════════════════════════════════
# C9 – CustomScorer preserves original function signature
# ═══════════════════════════════════════════════════════════════════════════════
def check_C9() -> None:
    """Contracts: C9"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    @scorer
    def _sig_test(inputs, outputs, expectations=None, trace=None) -> str:
        return str(len(str(outputs)))

    sig = inspect.signature(_sig_test.__call__)
    param_names = list(sig.parameters.keys())
    assert "self" in param_names, f"No 'self' in signature: {param_names}"
    assert "inputs" in param_names, f"No 'inputs' in signature: {param_names}"
    assert "outputs" in param_names, f"No 'outputs' in signature: {param_names}"
    assert "expectations" in param_names, f"No 'expectations' in signature: {param_names}"
    assert "trace" in param_names, f"No 'trace' in signature: {param_names}"
    print("PASS: C9 – CustomScorer.__call__ preserves original function signature with self")


# ═══════════════════════════════════════════════════════════════════════════════
# C10 – Scorer.model_dump includes source code for decorator scorers
# ═══════════════════════════════════════════════════════════════════════════════
def check_C10() -> None:
    """Contracts: C10"""
    try:
        from mlflow.genai.scorers import scorer
    except ImportError:
        _skip("scorer decorator not implemented")
        return

    @scorer
    def _dump_test(outputs) -> bool:
        return bool(outputs)

    dumped = _dump_test.model_dump()
    assert isinstance(dumped, dict)
    for key in ("call_source", "call_signature", "original_func_name"):
        assert key in dumped, f"Missing key '{key}' in model_dump result"
        assert dumped[key] is not None, f"Key '{key}' is None"
        assert isinstance(dumped[key], str), f"Key '{key}' is not str: {type(dumped[key])}"
    print("PASS: C10 – model_dump includes call_source, call_signature, original_func_name")


# ═══════════════════════════════════════════════════════════════════════════════
# C11 – _extract_source_code_info references extract_function_body
# ═══════════════════════════════════════════════════════════════════════════════
def check_C11() -> None:
    """Contracts: C11
    Verify that _extract_source_code_info invokes extract_function_body to
    extract the source of the original decorated function.
    """
    import inspect as _inspect

    from mlflow.genai.scorers.base import Scorer

    src = _inspect.getsource(Scorer._extract_source_code_info)
    assert "extract_function_body" in src, (
        "_extract_source_code_info does not reference extract_function_body"
    )
    print("PASS: C11 – _extract_source_code_info references extract_function_body")


# ═══════════════════════════════════════════════════════════════════════════════
# C15 – _reconstruct_decorator_scorer references recreate_function
# ═══════════════════════════════════════════════════════════════════════════════
def check_C15() -> None:
    """Contracts: C15
    Verify that _reconstruct_decorator_scorer invokes recreate_function to
    rebuild a callable from serialized source code.
    """
    import inspect as _inspect

    from mlflow.genai.scorers.base import Scorer

    src = _inspect.getsource(Scorer._reconstruct_decorator_scorer)
    assert "recreate_function" in src, (
        "_reconstruct_decorator_scorer does not reference recreate_function"
    )
    print("PASS: C15 – _reconstruct_decorator_scorer references recreate_function")


# ═══════════════════════════════════════════════════════════════════════════════
# C19 – recreate_function provides MLflow imports in namespace
# ═══════════════════════════════════════════════════════════════════════════════
def check_C19() -> None:
    """Contracts: C19"""
    try:
        from mlflow.genai.scorers.scorer_utils import recreate_function
    except ImportError:
        _skip("recreate_function not implemented")
        return

    from mlflow.entities import Feedback

    f = recreate_function("return Feedback(value=True)", "()", "f_C19")
    result = f()
    assert isinstance(result, Feedback), f"Expected Feedback, got {type(result)}"
    assert result.value is True
    print("PASS: C19 – recreate_function namespace contains Feedback and MLflow imports")


# ═══════════════════════════════════════════════════════════════════════════════
# C25 – extract_function_body returns tuple of (body_str, indent_unit)
# ═══════════════════════════════════════════════════════════════════════════════
def check_C25() -> None:
    """Contracts: C25"""
    try:
        from mlflow.genai.scorers.scorer_utils import extract_function_body
    except ImportError:
        _skip("extract_function_body not implemented")
        return

    def _sample_func(x):
        return x + 1

    result = extract_function_body(_sample_func)
    assert isinstance(result, tuple), f"Expected tuple, got {type(result)}"
    assert len(result) == 2, f"Expected 2 elements, got {len(result)}"
    body_str, indent_unit = result
    assert isinstance(body_str, str), f"body_str: expected str, got {type(body_str)}"
    assert isinstance(indent_unit, int), f"indent_unit: expected int, got {type(indent_unit)}"
    assert "return x + 1" in body_str
    print("PASS: C25 – extract_function_body returns tuple[str, int]")


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    checks = [
        check_C26,
        check_C27,
        check_C28,
        check_C6,
        check_C7,
        check_C9,
        check_C10,
        check_C11,
        check_C15,
        check_C19,
        check_C25,
    ]
    for check in checks:
        check()
    print("\narch_spec.py complete.")
