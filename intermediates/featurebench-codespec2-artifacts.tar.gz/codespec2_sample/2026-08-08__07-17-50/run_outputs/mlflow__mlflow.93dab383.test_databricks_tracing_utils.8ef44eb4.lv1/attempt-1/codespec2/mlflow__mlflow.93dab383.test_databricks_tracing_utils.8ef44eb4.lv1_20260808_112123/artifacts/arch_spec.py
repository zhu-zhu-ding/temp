"""
Executable architecture spec for MLflow tracing and assessment data management.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check function maps to one or more contract IDs from the semantic IR.
"""

import inspect
import sys
import warnings

# ---------------------------------------------------------------------------
# Import helpers – the target functions live in mlflow.utils.databricks_tracing_utils
# ---------------------------------------------------------------------------
def _ensure(condition, msg):
    if not condition:
        print(f"FAIL: {msg}")
        sys.exit(1)

_IMPORT_ERRORS = []

def _try_import_databricks_tracing_utils():
    """Try to import all required functions from databricks_tracing_utils."""
    funcs = {}
    try:
        from mlflow.utils.databricks_tracing_utils import (
            assessment_to_proto,
            get_trace_id_from_assessment_proto,
            inference_table_location_to_proto,
            mlflow_experiment_location_to_proto,
            trace_from_proto,
            trace_info_to_v4_proto,
            trace_location_from_proto,
            trace_location_to_proto,
            trace_to_proto,
            uc_schema_location_from_proto,
            uc_schema_location_to_proto,
        )
        funcs.update({
            'assessment_to_proto': assessment_to_proto,
            'get_trace_id_from_assessment_proto': get_trace_id_from_assessment_proto,
            'inference_table_location_to_proto': inference_table_location_to_proto,
            'mlflow_experiment_location_to_proto': mlflow_experiment_location_to_proto,
            'trace_from_proto': trace_from_proto,
            'trace_info_to_v4_proto': trace_info_to_v4_proto,
            'trace_location_from_proto': trace_location_from_proto,
            'trace_location_to_proto': trace_location_to_proto,
            'trace_to_proto': trace_to_proto,
            'uc_schema_location_from_proto': uc_schema_location_from_proto,
            'uc_schema_location_to_proto': uc_schema_location_to_proto,
        })
    except ImportError as e:
        _IMPORT_ERRORS.append(f"databricks_tracing_utils: {e}")
    return funcs

_FUNCS = _try_import_databricks_tracing_utils()

# ---------------------------------------------------------------------------
# Pre-import supporting entities
# ---------------------------------------------------------------------------
from mlflow.entities import Assessment, Span, Trace, TraceData, TraceInfo
from mlflow.entities.trace_location import (
    InferenceTableLocation,
    MlflowExperimentLocation,
    TraceLocation,
    TraceLocationType,
    UCSchemaLocation,
)
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.protos import databricks_tracing_pb2 as pb
from mlflow.protos import assessments_pb2
from mlflow.tracing.utils import construct_trace_id_v4, parse_trace_id_v4
from mlflow.entities.assessment import Feedback, Expectation
from mlflow.entities.trace_state import TraceState

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _req_func(name):
    """Return a required function or skip gracefully."""
    if name not in _FUNCS:
        print(f"SKIP: {name} not available in databricks_tracing_utils (import errors: {_IMPORT_ERRORS})")
        return None
    return _FUNCS[name]

def _make_assessment(name="test_assessment", trace_id="tr-123", source_type="HUMAN",
                     source_id="user1", create_time_ms=1000, last_update_time_ms=2000,
                     span_id=None, rationale=None, assessment_id=None,
                     expectation=None, feedback=None, metadata=None,
                     overrides=None, valid=None):
    """Create an Assessment entity with sensible defaults."""
    source = AssessmentSource(source_type=source_type, source_id=source_id)
    return Assessment(
        name=name,
        source=source,
        trace_id=trace_id,
        create_time_ms=create_time_ms,
        last_update_time_ms=last_update_time_ms,
        span_id=span_id,
        rationale=rationale,
        assessment_id=assessment_id,
        expectation=expectation,
        feedback=feedback,
        metadata=metadata,
        overrides=overrides,
        valid=valid,
    )

# ===========================================================================
# check_* functions
# ===========================================================================

def check_C1_assessment_to_proto_return_type():
    """Contracts: C1 – assessment_to_proto returns pb.Assessment"""
    f = _req_func('assessment_to_proto')
    if f is None:
        return
    assessment = _make_assessment()
    result = f(assessment)
    _ensure(isinstance(result, pb.Assessment),
            f"C1: Expected pb.Assessment, got {type(result)}")
    print("PASS: C1 – assessment_to_proto returns pb.Assessment")


def check_C2_assessment_to_proto_name():
    """Contracts: C2 – assessment_to_proto sets assessment_name"""
    f = _req_func('assessment_to_proto')
    if f is None:
        return
    assessment = _make_assessment(name="my_name")
    result = f(assessment)
    _ensure(result.assessment_name == "my_name",
            f"C2: Expected assessment_name='my_name', got '{result.assessment_name}'")
    print("PASS: C2 – assessment_to_proto sets assessment_name")


def check_C3_assessment_to_proto_timestamps():
    """Contracts: C3 – assessment_to_proto converts timestamps via FromMilliseconds"""
    f = _req_func('assessment_to_proto')
    if f is None:
        return
    assessment = _make_assessment(create_time_ms=5000, last_update_time_ms=10000)
    result = f(assessment)
    _ensure(result.create_time.ToMilliseconds() == 5000,
            f"C3: Expected create_time=5000ms, got {result.create_time.ToMilliseconds()}")
    _ensure(result.last_update_time.ToMilliseconds() == 10000,
            f"C3: Expected last_update_time=10000ms, got {result.last_update_time.ToMilliseconds()}")
    print("PASS: C3 – assessment_to_proto converts timestamps via FromMilliseconds")


def check_C4_assessment_to_proto_metadata_strings():
    """Contracts: C4 – assessment_to_proto sets metadata as string key-value pairs"""
    f = _req_func('assessment_to_proto')
    if f is None:
        return
    assessment = _make_assessment(metadata={"key1": 123, "key2": True, "key3": "strval"})
    result = f(assessment)
    _ensure(len(result.metadata) == 3, f"C4: Expected 3 metadata entries, got {len(result.metadata)}")
    for k in ["key1", "key2", "key3"]:
        _ensure(k in result.metadata, f"C4: Missing metadata key '{k}'")
        _ensure(isinstance(result.metadata[k], str),
                f"C4: Expected str for metadata['{k}'], got {type(result.metadata[k])}")
    _ensure(result.metadata["key1"] == "123", f"C4: Expected '123', got '{result.metadata['key1']}'")
    _ensure(result.metadata["key2"] == "True", f"C4: Expected 'True', got '{result.metadata['key2']}'")
    print("PASS: C4 – assessment_to_proto metadata values are strings")


def check_C6_assessment_to_proto_trace_location_uc():
    """Contracts: C6 – assessment_to_proto sets trace_location for UC Schema locations"""
    f = _req_func('assessment_to_proto')
    if f is None:
        return
    # Create a v4 trace ID that will parse to a UC Schema location
    v4_trace_id = construct_trace_id_v4("my_catalog.my_schema", "inner-trace-id")
    assessment = _make_assessment(trace_id=v4_trace_id)
    result = f(assessment)
    _ensure(result.HasField("trace_location"),
            "C6: Expected trace_location to be set for v4 trace ID")
    _ensure(result.trace_location.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA,
            f"C6: Expected UC_SCHEMA type, got {result.trace_location.type}")
    _ensure(result.trace_location.HasField("uc_schema"),
            "C6: Expected uc_schema to be set")
    _ensure(result.trace_location.uc_schema.catalog_name == "my_catalog",
            f"C6: Expected catalog_name='my_catalog', got '{result.trace_location.uc_schema.catalog_name}'")
    _ensure(result.trace_location.uc_schema.schema_name == "my_schema",
            f"C6: Expected schema_name='my_schema', got '{result.trace_location.uc_schema.schema_name}'")
    # trace_id should be extracted to inner id
    _ensure(result.trace_id == "inner-trace-id",
            f"C6: Expected trace_id='inner-trace-id', got '{result.trace_id}'")
    print("PASS: C6 – assessment_to_proto sets trace_location for UC Schema locations")


def check_C7_get_trace_id_from_assessment_proto_non_uc():
    """Contracts: C7 – get_trace_id_from_assessment_proto returns raw trace_id for non-UC"""
    f = _req_func('get_trace_id_from_assessment_proto')
    if f is None:
        return
    proto = pb.Assessment()
    proto.trace_id = "raw-trace-id-123"
    result = f(proto)
    _ensure(result == "raw-trace-id-123",
            f"C7: Expected 'raw-trace-id-123', got '{result}'")
    print("PASS: C7 – get_trace_id_from_assessment_proto returns raw trace_id for non-UC")


def check_C8_get_trace_id_from_assessment_proto_uc():
    """Contracts: C8 – get_trace_id_from_assessment_proto returns v4 trace ID for UC proto"""
    f = _req_func('get_trace_id_from_assessment_proto')
    if f is None:
        return
    proto = pb.Assessment()
    proto.trace_id = "inner-id"
    proto.trace_location.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto.trace_location.uc_schema.catalog_name = "cat"
    proto.trace_location.uc_schema.schema_name = "sch"
    result = f(proto)
    expected = construct_trace_id_v4("cat.sch", "inner-id")
    _ensure(result == expected,
            f"C8: Expected '{expected}', got '{result}'")
    print("PASS: C8 – get_trace_id_from_assessment_proto returns v4 trace ID for UC")


def check_C9_get_trace_id_from_assessment_proto_both_proto_types():
    """Contracts: C9 – get_trace_id_from_assessment_proto handles both proto types"""
    f = _req_func('get_trace_id_from_assessment_proto')
    if f is None:
        return
    # Test with assessments_pb2.Assessment (no trace_location field)
    a2 = assessments_pb2.Assessment()
    a2.trace_id = "from-assessments-pb2"
    result = f(a2)
    _ensure(result == "from-assessments-pb2",
            f"C9: Expected 'from-assessments-pb2', got '{result}'")

    # Test with pb.Assessment (has trace_location field)
    a1 = pb.Assessment()
    a1.trace_id = "from-databricks-pb2"
    result = f(a1)
    _ensure(result == "from-databricks-pb2",
            f"C9: Expected 'from-databricks-pb2', got '{result}'")
    print("PASS: C9 – get_trace_id_from_assessment_proto handles both proto types")


def check_C10_inference_table_location_to_proto():
    """Contracts: C10 – inference_table_location_to_proto returns correct proto"""
    f = _req_func('inference_table_location_to_proto')
    if f is None:
        return
    entity = InferenceTableLocation("cat.schema.table")
    result = f(entity)
    _ensure(isinstance(result, pb.InferenceTableLocation),
            f"C10: Expected pb.InferenceTableLocation, got {type(result)}")
    _ensure(result.full_table_name == "cat.schema.table",
            f"C10: Expected 'cat.schema.table', got '{result.full_table_name}'")
    print("PASS: C10 – inference_table_location_to_proto returns correct proto")


def check_C11_mlflow_experiment_location_to_proto():
    """Contracts: C11 – mlflow_experiment_location_to_proto returns correct proto"""
    f = _req_func('mlflow_experiment_location_to_proto')
    if f is None:
        return
    entity = MlflowExperimentLocation("exp123")
    result = f(entity)
    _ensure(isinstance(result, pb.MlflowExperimentLocation),
            f"C11: Expected pb.MlflowExperimentLocation, got {type(result)}")
    _ensure(result.experiment_id == "exp123",
            f"C11: Expected 'exp123', got '{result.experiment_id}'")
    print("PASS: C11 – mlflow_experiment_location_to_proto returns correct proto")


def check_C12_trace_from_proto_info():
    """Contracts: C12 – trace_from_proto returns Trace with correct info"""
    f = _req_func('trace_from_proto')
    if f is None:
        return
    # Build a minimal pb.Trace
    from google.protobuf.timestamp_pb2 import Timestamp
    ts = Timestamp()
    ts.FromMilliseconds(1000000)

    trace_proto = pb.Trace()
    trace_proto.trace_info.trace_id = "test-trace-id"
    trace_proto.trace_info.request_time.CopyFrom(ts)
    trace_proto.trace_info.state = pb.TraceInfo.State.OK
    trace_proto.trace_info.trace_location.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    trace_proto.trace_info.trace_location.mlflow_experiment.experiment_id = "exp-1"

    result = f(trace_proto, "loc-id")
    _ensure(isinstance(result, Trace),
            f"C12: Expected Trace, got {type(result)}")
    _ensure(result.info.trace_id is not None,
            "C12: Expected trace info to have a trace_id")
    print("PASS: C12 – trace_from_proto returns Trace with correct info")


def check_C13_trace_from_proto_spans_with_location():
    """Contracts: C13 – trace_from_proto converts spans with location_id"""
    f = _req_func('trace_from_proto')
    if f is None:
        return
    from google.protobuf.timestamp_pb2 import Timestamp
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    ts = Timestamp()
    ts.FromMilliseconds(1000000)

    otel_span = OTelProtoSpan()
    otel_span.trace_id = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    otel_span.span_id = b'\x10\x11\x12\x13\x14\x15\x16\x17'
    otel_span.name = "test-span"
    otel_span.start_time_unix_nano = 1000000000
    otel_span.end_time_unix_nano = 2000000000

    trace_proto = pb.Trace()
    trace_proto.trace_info.trace_id = "test-trace-id"
    trace_proto.trace_info.request_time.CopyFrom(ts)
    trace_proto.trace_info.state = pb.TraceInfo.State.OK
    trace_proto.trace_info.trace_location.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    trace_proto.trace_info.trace_location.mlflow_experiment.experiment_id = "exp-1"
    trace_proto.spans.append(otel_span)

    result = f(trace_proto, "loc-id")
    _ensure(len(result.data.spans) == 1,
            f"C13: Expected 1 span, got {len(result.data.spans)}")
    _ensure(result.data.spans[0].name == "test-span",
            f"C13: Expected span name 'test-span', got '{result.data.spans[0].name}'")
    print("PASS: C13 – trace_from_proto converts spans with location_id")


def check_C14_trace_info_to_v4_proto_parses_v4():
    """Contracts: C14 – trace_info_to_v4_proto parses v4 trace_id for UC Schema"""
    f = _req_func('trace_info_to_v4_proto')
    if f is None:
        return
    v4_trace_id = construct_trace_id_v4("cat.sch", "inner-id")
    trace_location = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    trace_info = TraceInfo(
        trace_id=v4_trace_id,
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
    )
    result = f(trace_info)
    _ensure(result.trace_id == "inner-id",
            f"C14: Expected trace_id='inner-id', got '{result.trace_id}'")
    print("PASS: C14 – trace_info_to_v4_proto parses v4 trace_id for UC Schema")


def check_C15_trace_info_to_v4_proto_trace_location():
    """Contracts: C15 – trace_info_to_v4_proto sets trace_location as protobuf"""
    f = _req_func('trace_info_to_v4_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
    )
    result = f(trace_info)
    _ensure(result.HasField("trace_location"),
            "C15: Expected trace_location to be set")
    _ensure(result.trace_location.type == pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT,
            f"C15: Expected MLFLOW_EXPERIMENT type")
    print("PASS: C15 – trace_info_to_v4_proto sets trace_location")


def check_C16_trace_info_to_v4_proto_request_time():
    """Contracts: C16 – trace_info_to_v4_proto converts request_time to Timestamp"""
    f = _req_func('trace_info_to_v4_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=12345678,
        state=TraceState.OK,
    )
    result = f(trace_info)
    _ensure(result.request_time.ToMilliseconds() == 12345678,
            f"C16: Expected request_time=12345678ms, got {result.request_time.ToMilliseconds()}")
    print("PASS: C16 – trace_info_to_v4_proto converts request_time to Timestamp")


def check_C18_trace_info_to_v4_proto_assessments():
    """Contracts: C18 – trace_info_to_v4_proto converts assessments via assessment_to_proto"""
    f = _req_func('trace_info_to_v4_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    feedback = Feedback(
        name="test-feedback",
        source=AssessmentSource(source_type="HUMAN", source_id="u1"),
        trace_id="tr-1",
        value=4.5,
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
        assessments=[feedback],
    )
    result = f(trace_info)
    _ensure(len(result.assessments) == 1,
            f"C18: Expected 1 assessment, got {len(result.assessments)}")
    _ensure(isinstance(result.assessments[0], pb.Assessment),
            f"C18: Expected pb.Assessment, got {type(result.assessments[0])}")
    print("PASS: C18 – trace_info_to_v4_proto converts assessments")


def check_C19_trace_info_to_v4_proto_truncated_metadata():
    """Contracts: C19 – trace_info_to_v4_proto uses truncated metadata and tags"""
    f = _req_func('trace_info_to_v4_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
        trace_metadata={"key1": "val1"},
        tags={"tag1": "val2"},
    )
    result = f(trace_info)
    # Verify metadata and tags are present (they may be truncated but should exist)
    _ensure(len(result.trace_metadata) >= 0,
            "C19: trace_metadata should be present")
    _ensure(len(result.tags) >= 0,
            "C19: tags should be present")
    print("PASS: C19 – trace_info_to_v4_proto uses truncated metadata and tags")


def check_C20_trace_location_from_proto_uc_schema():
    """Contracts: C20 – trace_location_from_proto returns TraceLocation with UC_SCHEMA"""
    f = _req_func('trace_location_from_proto')
    if f is None:
        return
    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto.uc_schema.catalog_name = "my_cat"
    proto.uc_schema.schema_name = "my_sch"
    result = f(proto)
    _ensure(result.type == TraceLocationType.UC_SCHEMA,
            f"C20: Expected UC_SCHEMA type, got {result.type}")
    _ensure(result.uc_schema is not None,
            "C20: Expected uc_schema to be set")
    _ensure(result.uc_schema.catalog_name == "my_cat",
            f"C20: Expected catalog_name='my_cat', got '{result.uc_schema.catalog_name}'")
    _ensure(result.uc_schema.schema_name == "my_sch",
            f"C20: Expected schema_name='my_sch', got '{result.uc_schema.schema_name}'")
    print("PASS: C20 – trace_location_from_proto returns TraceLocation with UC_SCHEMA")


def check_C21_trace_location_from_proto_mlflow_experiment():
    """Contracts: C21 – trace_location_from_proto returns TraceLocation with MLFLOW_EXPERIMENT"""
    f = _req_func('trace_location_from_proto')
    if f is None:
        return
    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto.mlflow_experiment.experiment_id = "exp-42"
    result = f(proto)
    _ensure(result.type == TraceLocationType.MLFLOW_EXPERIMENT,
            f"C21: Expected MLFLOW_EXPERIMENT type, got {result.type}")
    _ensure(result.mlflow_experiment is not None,
            "C21: Expected mlflow_experiment to be set")
    _ensure(result.mlflow_experiment.experiment_id == "exp-42",
            f"C21: Expected experiment_id='exp-42', got '{result.mlflow_experiment.experiment_id}'")
    print("PASS: C21 – trace_location_from_proto returns MLFLOW_EXPERIMENT")


def check_C25_trace_to_proto_return_type():
    """Contracts: C25 – trace_to_proto returns pb.Trace"""
    f = _req_func('trace_to_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
    )
    trace_data = TraceData(spans=[])
    trace = Trace(info=trace_info, data=trace_data)
    result = f(trace)
    _ensure(isinstance(result, pb.Trace),
            f"C25: Expected pb.Trace, got {type(result)}")
    print("PASS: C25 – trace_to_proto returns pb.Trace")


def check_C26_trace_to_proto_trace_info():
    """Contracts: C26 – trace_to_proto has trace_info from trace.info.to_proto()"""
    f = _req_func('trace_to_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
    )
    trace_data = TraceData(spans=[])
    trace = Trace(info=trace_info, data=trace_data)
    result = f(trace)
    _ensure(result.HasField("trace_info"),
            "C26: Expected trace_info to be set")
    _ensure(result.trace_info.trace_id == "tr-1",
            f"C26: Expected trace_id='tr-1', got '{result.trace_info.trace_id}'")
    print("PASS: C26 – trace_to_proto has trace_info")


def check_C27_trace_to_proto_spans():
    """Contracts: C27 – trace_to_proto has spans from span.to_otel_proto()"""
    f = _req_func('trace_to_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
    )
    trace_data = TraceData(spans=[])
    trace = Trace(info=trace_info, data=trace_data)
    result = f(trace)
    _ensure(len(result.spans) == 0,
            f"C27: Expected 0 spans, got {len(result.spans)}")
    print("PASS: C27 – trace_to_proto has spans")


def check_C28_uc_schema_location_from_proto():
    """Contracts: C28 – uc_schema_location_from_proto returns UCSchemaLocation with catalog/schema"""
    f = _req_func('uc_schema_location_from_proto')
    if f is None:
        return
    proto = pb.UCSchemaLocation()
    proto.catalog_name = "test_catalog"
    proto.schema_name = "test_schema"
    result = f(proto)
    _ensure(isinstance(result, UCSchemaLocation),
            f"C28: Expected UCSchemaLocation, got {type(result)}")
    _ensure(result.catalog_name == "test_catalog",
            f"C28: Expected catalog_name='test_catalog', got '{result.catalog_name}'")
    _ensure(result.schema_name == "test_schema",
            f"C28: Expected schema_name='test_schema', got '{result.schema_name}'")
    print("PASS: C28 – uc_schema_location_from_proto returns catalog/schema")


def check_C29_uc_schema_location_from_proto_otel_tables():
    """Contracts: C29 – uc_schema_location_from_proto sets optional otel table names"""
    f = _req_func('uc_schema_location_from_proto')
    if f is None:
        return
    proto = pb.UCSchemaLocation()
    proto.catalog_name = "c"
    proto.schema_name = "s"
    proto.otel_spans_table_name = "spans_table"
    proto.otel_logs_table_name = "logs_table"
    result = f(proto)
    _ensure(result._otel_spans_table_name == "spans_table",
            f"C29: Expected _otel_spans_table_name='spans_table', got '{result._otel_spans_table_name}'")
    _ensure(result._otel_logs_table_name == "logs_table",
            f"C29: Expected _otel_logs_table_name='logs_table', got '{result._otel_logs_table_name}'")

    # Test without optional fields
    proto2 = pb.UCSchemaLocation()
    proto2.catalog_name = "c"
    proto2.schema_name = "s"
    result2 = f(proto2)
    _ensure(result2.catalog_name == "c", "C29: catalog_name should be set")
    _ensure(result2.schema_name == "s", "C29: schema_name should be set")
    print("PASS: C29 – uc_schema_location_from_proto sets optional otel table names")


def check_C30_uc_schema_location_to_proto():
    """Contracts: C30 – uc_schema_location_to_proto returns pb.UCSchemaLocation with all fields"""
    f = _req_func('uc_schema_location_to_proto')
    if f is None:
        return
    entity = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    entity._otel_spans_table_name = "spans_tbl"
    entity._otel_logs_table_name = "logs_tbl"
    result = f(entity)
    _ensure(isinstance(result, pb.UCSchemaLocation),
            f"C30: Expected pb.UCSchemaLocation, got {type(result)}")
    _ensure(result.catalog_name == "cat",
            f"C30: Expected catalog_name='cat', got '{result.catalog_name}'")
    _ensure(result.schema_name == "sch",
            f"C30: Expected schema_name='sch', got '{result.schema_name}'")
    _ensure(result.otel_spans_table_name == "spans_tbl",
            f"C30: Expected otel_spans_table_name='spans_tbl'")
    _ensure(result.otel_logs_table_name == "logs_tbl",
            f"C30: Expected otel_logs_table_name='logs_tbl'")
    print("PASS: C30 – uc_schema_location_to_proto returns pb.UCSchemaLocation")


def check_C31_AssessmentSourceType_standardize_uppercase():
    """Contracts: C31 – AssessmentSourceType._standardize returns uppercase string"""
    _ensure(hasattr(AssessmentSourceType, '_standardize'),
            "C31: _standardize method must exist on AssessmentSourceType")
    result = AssessmentSourceType._standardize("human")
    _ensure(result == "HUMAN",
            f"C31: Expected 'HUMAN', got '{result}'")
    print("PASS: C31 – _standardize returns uppercase")


def check_C36_AssessmentSourceType_parse_uppercases():
    """Contracts: C36 – AssessmentSourceType._parse uppercases input"""
    _ensure(hasattr(AssessmentSourceType, '_parse'),
            "C36: _parse method must exist on AssessmentSourceType")
    result = AssessmentSourceType._parse("human")
    _ensure(result == "HUMAN",
            f"C36: Expected 'HUMAN', got '{result}'")
    print("PASS: C36 – _parse uppercases input")


def check_C38_span_inputs():
    """Contracts: C38 – Span.inputs returns deserialized input attribute"""
    _ensure(hasattr(Span, 'inputs'),
            "C38: Span.inputs property must exist")
    # Span.inputs is a property, we test that it exists and callable
    prop = inspect.getattr_static(Span, 'inputs')
    _ensure(isinstance(prop, property),
            f"C38: Span.inputs should be a property, got {type(prop)}")
    print("PASS: C38 – Span.inputs property exists")


def check_C40_span_outputs():
    """Contracts: C40 – Span.outputs returns deserialized output attribute"""
    _ensure(hasattr(Span, 'outputs'),
            "C40: Span.outputs property must exist")
    prop = inspect.getattr_static(Span, 'outputs')
    _ensure(isinstance(prop, property),
            f"C40: Span.outputs should be a property, got {type(prop)}")
    print("PASS: C40 – Span.outputs property exists")


def check_C42_trace_location_to_proto_uc_schema():
    """Contracts: C42 – trace_location_to_proto sets type and oneof for UC_SCHEMA"""
    f = _req_func('trace_location_to_proto')
    if f is None:
        return
    entity = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    result = f(entity)
    _ensure(result.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA,
            f"C42: Expected UC_SCHEMA type")
    _ensure(result.HasField("uc_schema"),
            "C42: Expected uc_schema oneof to be set")
    _ensure(result.uc_schema.catalog_name == "cat",
            f"C42: Expected catalog_name='cat'")
    print("PASS: C42 – trace_location_to_proto sets type and oneof for UC_SCHEMA")


def check_C43_trace_info_to_v4_proto_client_request_id():
    """Contracts: C43 – trace_info_to_v4_proto sets client_request_id"""
    f = _req_func('trace_info_to_v4_proto')
    if f is None:
        return
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation("exp-1"),
    )
    trace_info = TraceInfo(
        trace_id="tr-1",
        trace_location=trace_location,
        request_time=1000000,
        state=TraceState.OK,
        client_request_id="client-req-abc",
    )
    result = f(trace_info)
    _ensure(result.client_request_id == "client-req-abc",
            f"C43: Expected client_request_id='client-req-abc', got '{result.client_request_id}'")
    print("PASS: C43 – trace_info_to_v4_proto sets client_request_id")


def check_C45_trace_location_from_proto_inference_table():
    """Contracts: C45 – trace_location_from_proto returns INFERENCE_TABLE"""
    f = _req_func('trace_location_from_proto')
    if f is None:
        return
    proto = pb.TraceLocation()
    proto.type = pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    proto.inference_table.full_table_name = "cat.sch.tbl"
    result = f(proto)
    _ensure(result.type == TraceLocationType.INFERENCE_TABLE,
            f"C45: Expected INFERENCE_TABLE type, got {result.type}")
    _ensure(result.inference_table is not None,
            "C45: Expected inference_table to be set")
    _ensure(result.inference_table.full_table_name == "cat.sch.tbl",
            f"C45: Expected full_table_name='cat.sch.tbl', got '{result.inference_table.full_table_name}'")
    print("PASS: C45 – trace_location_from_proto returns INFERENCE_TABLE")


def check_C46_AssessmentSourceType_constants_are_strings():
    """Contracts: C46 – AssessmentSourceType constants are plain strings"""
    for attr_name in ['SOURCE_TYPE_UNSPECIFIED', 'LLM_JUDGE', 'AI_JUDGE', 'HUMAN', 'CODE']:
        val = getattr(AssessmentSourceType, attr_name, None)
        _ensure(val is not None,
                f"C46: AssessmentSourceType.{attr_name} must exist")
        _ensure(isinstance(val, str),
                f"C46: AssessmentSourceType.{attr_name} should be str, got {type(val)}: {val!r}")
    print("PASS: C46 – AssessmentSourceType constants are plain strings")


# ===========================================================================
# Main
# ===========================================================================
if __name__ == '__main__':
    if _IMPORT_ERRORS:
        print(f"WARNING: Some imports failed: {_IMPORT_ERRORS}")
        print("Tests will be skipped for missing functions.")
    check_C1_assessment_to_proto_return_type()
    check_C2_assessment_to_proto_name()
    check_C3_assessment_to_proto_timestamps()
    check_C4_assessment_to_proto_metadata_strings()
    check_C6_assessment_to_proto_trace_location_uc()
    check_C7_get_trace_id_from_assessment_proto_non_uc()
    check_C8_get_trace_id_from_assessment_proto_uc()
    check_C9_get_trace_id_from_assessment_proto_both_proto_types()
    check_C10_inference_table_location_to_proto()
    check_C11_mlflow_experiment_location_to_proto()
    check_C12_trace_from_proto_info()
    check_C13_trace_from_proto_spans_with_location()
    check_C14_trace_info_to_v4_proto_parses_v4()
    check_C15_trace_info_to_v4_proto_trace_location()
    check_C16_trace_info_to_v4_proto_request_time()
    check_C18_trace_info_to_v4_proto_assessments()
    check_C19_trace_info_to_v4_proto_truncated_metadata()
    check_C20_trace_location_from_proto_uc_schema()
    check_C21_trace_location_from_proto_mlflow_experiment()
    check_C25_trace_to_proto_return_type()
    check_C26_trace_to_proto_trace_info()
    check_C27_trace_to_proto_spans()
    check_C28_uc_schema_location_from_proto()
    check_C29_uc_schema_location_from_proto_otel_tables()
    check_C30_uc_schema_location_to_proto()
    check_C31_AssessmentSourceType_standardize_uppercase()
    check_C36_AssessmentSourceType_parse_uppercases()
    check_C38_span_inputs()
    check_C40_span_outputs()
    check_C42_trace_location_to_proto_uc_schema()
    check_C43_trace_info_to_v4_proto_client_request_id()
    check_C45_trace_location_from_proto_inference_table()
    check_C46_AssessmentSourceType_constants_are_strings()
    print("\nAll arch_spec checks passed.")
