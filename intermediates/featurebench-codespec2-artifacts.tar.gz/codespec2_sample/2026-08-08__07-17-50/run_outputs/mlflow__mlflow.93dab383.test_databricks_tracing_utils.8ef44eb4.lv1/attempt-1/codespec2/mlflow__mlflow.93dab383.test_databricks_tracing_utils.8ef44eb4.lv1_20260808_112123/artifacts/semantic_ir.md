# Semantic IR

## L1. Requirement Obligations

### R1: assessment_to_proto — Convert MLflow Assessment to pb.Assessment
- Type: Dataflow
- Statement: An MLflow Assessment entity MUST be convertible to a databricks_tracing_pb2.Assessment protobuf message with all fields mapped, timestamps converted from milliseconds to protobuf Timestamp, trace_location extracted from trace_id for UC Schema locations, metadata values stringified, and either expectation or feedback set (not both).
- Task Evidence: "Convert an Assessment entity to its corresponding protobuf representation... transform an MLflow Assessment object into a protobuf Assessment message, handling the conversion of all assessment fields... including nested objects like source, expectation, and feedback."
- Acceptance: Calling `assessment_to_proto(assessment)` returns a `pb.Assessment` with assessment_name, trace_id, source, create_time/last_update_time as protobuf Timestamps, trace_location populated for UC Schema locations, optional fields (span_id, rationale, assessment_id, overrides, valid) set when non-None, metadata as string key-value pairs, and exactly one of expectation or feedback set.
- Repository Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:511` calls `assessment_to_proto(assessment)`; `/testbed/mlflow/entities/assessment.py:117-146` shows Assessment.to_proto() creating assessments_pb2.Assessment.
- Uncertainty: None

### R2: get_trace_id_from_assessment_proto — Extract trace ID from assessment proto
- Type: Dataflow
- Statement: Given a protobuf Assessment (either pb.Assessment or assessments_pb2.Assessment), the function MUST return the trace_id string, constructing a v4 trace ID from catalog/schema location data when a trace_location with UC Schema is present, or returning the raw trace_id otherwise.
- Task Evidence: "Extract the trace ID from an assessment protocol buffer object... For assessments with UC (Unity Catalog) schema locations, it constructs a v4 trace ID by combining the catalog/schema information with the trace ID."
- Acceptance: For a proto with UC Schema trace_location (catalog_name="cat", schema_name="sch"), returns construct_trace_id_v4("cat.sch", proto.trace_id). For proto without trace_location or non-UC location, returns proto.trace_id.
- Repository Evidence: `/testbed/mlflow/entities/assessment.py:288,426` call `get_trace_id_from_assessment_proto(proto)`; `/testbed/mlflow/tracing/utils/__init__.py:649` defines `construct_trace_id_v4`.
- Uncertainty: None

### R3: inference_table_location_to_proto — Convert InferenceTableLocation to proto
- Type: Dataflow
- Statement: An InferenceTableLocation entity with a full_table_name MUST be convertible to a pb.InferenceTableLocation protobuf with the same full_table_name.
- Task Evidence: "Convert an InferenceTableLocation object to its corresponding protobuf representation... mapping from the MLflow entity to the protobuf message format, extracting the full_table_name attribute and setting it in the corresponding protobuf field."
- Acceptance: `inference_table_location_to_proto(InferenceTableLocation("cat.schema.table"))` returns `pb.InferenceTableLocation(full_table_name="cat.schema.table")`.
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:61-72` defines InferenceTableLocation with to_proto() method; `/testbed/mlflow/protos/databricks_tracing_pb2.py` defines pb.InferenceTableLocation.
- Uncertainty: None

### R4: mlflow_experiment_location_to_proto — Convert MlflowExperimentLocation to proto
- Type: Dataflow
- Statement: An MlflowExperimentLocation entity with an experiment_id MUST be convertible to a pb.MlflowExperimentLocation protobuf with the same experiment_id.
- Task Evidence: "Convert an MlflowExperimentLocation object to its corresponding protobuf representation... extracting the experiment_id from the input object and creating a corresponding protobuf message."
- Acceptance: `mlflow_experiment_location_to_proto(MlflowExperimentLocation("exp123"))` returns `pb.MlflowExperimentLocation(experiment_id="exp123")`.
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:39-51` defines MlflowExperimentLocation with to_proto(); `/testbed/mlflow/protos/databricks_tracing_pb2.py` defines pb.MlflowExperimentLocation.
- Uncertainty: None

### R5: trace_from_proto — Convert pb.Trace to MLflow Trace entity
- Type: Dataflow
- Statement: A pb.Trace protobuf message with trace_info and spans MUST be deserialized into an MLflow Trace entity, using TraceInfo.from_proto() for metadata and Span.from_otel_proto() with the location_id for each span.
- Task Evidence: "Convert a protobuf Trace message to an MLflow Trace entity... deserializes a protobuf representation of a trace back into MLflow's internal Trace object... relies on TraceInfo.from_proto() to deserialize trace metadata... Individual spans are converted using Span.from_otel_proto() with the provided location_id."
- Acceptance: `trace_from_proto(proto, location_id)` returns a `Trace` with `info` from `TraceInfo.from_proto(proto.trace_info)` and `data.spans` from `[Span.from_otel_proto(s, location_id) for s in proto.spans]`.
- Repository Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:189` calls `trace_from_proto(proto, location)`; `/testbed/mlflow/entities/trace.py:328-331` shows Trace.from_proto(); `/testbed/mlflow/entities/span.py:366` defines Span.from_otel_proto().
- Uncertainty: None

### R6: trace_info_to_v4_proto — Convert TraceInfo to v4 pb.TraceInfo
- Type: Dataflow
- Statement: A TraceInfo entity MUST be convertible to a v4 pb.TraceInfo protobuf, with trace_id parsed via parse_trace_id_v4 for UC Schema locations, timestamps converted from milliseconds to protobuf format, execution_duration set as Duration when non-None, metadata/tags truncated, and assessments converted via assessment_to_proto.
- Task Evidence: "Convert a TraceInfo object to its v4 protocol buffer representation... handles timestamp conversions, duration formatting, trace ID parsing for UC schema locations, and includes all trace metadata, tags, and assessments."
- Acceptance: For UC Schema location, trace_id is parsed using parse_trace_id_v4 to extract the inner trace ID. All timestamps converted via FromMilliseconds. Assessments converted via assessment_to_proto. Metadata and tags truncated. Returns pb.TraceInfo.
- Repository Evidence: `/testbed/mlflow/entities/trace_info.py:103` calls `trace_info_to_v4_proto(self)`; `/testbed/mlflow/entities/trace_info_v2.py` defines `_truncate_request_metadata` and `_truncate_tags`; `/testbed/mlflow/tracing/utils/__init__.py:631` defines `parse_trace_id_v4`.
- Uncertainty: None

### R7: trace_location_from_proto — Convert pb.TraceLocation to TraceLocation entity
- Type: Dataflow
- Statement: A pb.TraceLocation protobuf MUST be deserialized into an MLflow TraceLocation entity by inspecting the WhichOneof('identifier') result and constructing the appropriate location subtype (UCSchemaLocation, MlflowExperimentLocation, or InferenceTableLocation).
- Task Evidence: "Convert a protobuf TraceLocation message to a TraceLocation entity object... handles three types of trace locations: UC_SCHEMA, MLFLOW_EXPERIMENT, and INFERENCE_TABLE... Uses the WhichOneof method to determine which identifier field is set in the proto."
- Acceptance: For UC Schema proto, returns TraceLocation with type=UC_SCHEMA and uc_schema=UCSchemaLocation from proto. For MLflow experiment proto, returns TraceLocation with type=MLFLOW_EXPERIMENT and mlflow_experiment from proto. For inference table proto, returns TraceLocation with type=INFERENCE_TABLE and inference_table from proto. Falls back to TRACE_LOCATION_TYPE_UNSPECIFIED if no identifier found.
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:246` calls `trace_location_from_proto(proto)`; UCSchemaLocation, MlflowExperimentLocation, InferenceTableLocation classes all exist with from_proto class methods.
- Uncertainty: None

### R8: trace_location_to_proto — Convert TraceLocation to pb.TraceLocation
- Type: Dataflow
- Statement: A TraceLocation entity MUST be convertible to a pb.TraceLocation protobuf, dispatching to uc_schema_location_to_proto, mlflow_experiment_location_to_proto, or inference_table_location_to_proto based on the location type, or raising ValueError for unsupported types.
- Task Evidence: "Convert a TraceLocation object to its corresponding protobuf representation... delegates to specific conversion functions for each location type... Raises ValueError if the trace_location.type is not one of the supported types."
- Acceptance: For UC_SCHEMA type, delegates to uc_schema_location_to_proto and sets type and uc_schema on pb.TraceLocation. For MLFLOW_EXPERIMENT, delegates to mlflow_experiment_location_to_proto. For INFERENCE_TABLE, delegates to inference_table_location_to_proto. Raises ValueError for other types.
- Repository Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:290,294` call `trace_location_to_proto(...)`; `/testbed/mlflow/entities/trace_location.py` defines TraceLocation with type, mlflow_experiment, inference_table, uc_schema fields.
- Uncertainty: None

### R9: trace_to_proto — Convert Trace to pb.Trace
- Type: Dataflow
- Statement: An MLflow Trace entity MUST be convertible to a pb.Trace protobuf, converting trace_info via the trace's to_proto() method and spans via each span's to_otel_proto() method.
- Task Evidence: "Convert a Trace object to its corresponding protobuf representation... trace info is converted using the trace's built-in to_proto() method... All spans in the trace data are converted to OpenTelemetry protobuf format."
- Acceptance: `trace_to_proto(trace)` returns `pb.Trace(trace_info=trace.info.to_proto(), spans=[s.to_otel_proto() for s in trace.data.spans])`.
- Repository Evidence: `/testbed/mlflow/entities/trace.py:317-325` shows Trace.to_proto() returning ProtoTrace with trace_info.to_proto() and spans converted via to_otel_proto(); `/testbed/tests/store/tracking/test_databricks_rest_store.py:212,451` call `trace_to_proto(trace)`.
- Uncertainty: None

### R10: uc_schema_location_from_proto — Convert pb.UCSchemaLocation to UCSchemaLocation entity
- Type: Dataflow
- Statement: A pb.UCSchemaLocation protobuf with catalog_name and schema_name MUST be deserialized into a UCSchemaLocation entity, with optional otel_spans_table_name and otel_logs_table_name set as private attributes when present.
- Task Evidence: "Convert a protobuf UCSchemaLocation message to a UCSchemaLocation entity object... extracts the catalog name and schema name from the protobuf message and optionally sets the OpenTelemetry table names if they are present."
- Acceptance: `uc_schema_location_from_proto(proto)` returns UCSchemaLocation(catalog_name, schema_name) with _otel_spans_table_name and _otel_logs_table_name set from proto when HasField indicates they are present.
- Repository Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:422` calls `uc_schema_location_from_proto(response.uc_schema)`; `/testbed/mlflow/entities/trace_location.py:86-123` defines UCSchemaLocation with catalog_name, schema_name, _otel_spans_table_name, _otel_logs_table_name.
- Uncertainty: None

### R11: uc_schema_location_to_proto — Convert UCSchemaLocation to pb.UCSchemaLocation
- Type: Dataflow
- Statement: A UCSchemaLocation entity MUST be convertible to a pb.UCSchemaLocation protobuf, mapping catalog_name, schema_name, and private _otel_spans_table_name / _otel_logs_table_name attributes.
- Task Evidence: "Convert a UCSchemaLocation entity to its corresponding protobuf representation... mapping all the relevant fields including catalog name, schema name, and the optional OpenTelemetry table names."
- Acceptance: `uc_schema_location_to_proto(uc_schema_location)` returns pb.UCSchemaLocation with catalog_name, schema_name, otel_spans_table_name, and otel_logs_table_name populated.
- Repository Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451` calls `uc_schema_location_to_proto(location)`; `/testbed/mlflow/entities/trace_location.py:86-123` defines UCSchemaLocation.
- Uncertainty: None

### R12: AssessmentSourceType._standardize — Validate and normalize source type string
- Type: Behavior
- Statement: The _standardize static method MUST accept a source type string, create an AssessmentSourceType instance via its constructor, convert to string, and return the standardized uppercase value, handling AI_JUDGE→LLM_JUDGE deprecation and raising MlflowException for invalid types.
- Task Evidence: "Standardize and validate an assessment source type string... creates a temporary AssessmentSourceType instance and converting it to its string representation... handles case normalization, deprecation warnings, and validation in a single operation."
- Acceptance: Input "human" returns "HUMAN"; "AI_JUDGE" returns "LLM_JUDGE" with FutureWarning; "INVALID" raises MlflowException with INVALID_PARAMETER_VALUE.
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:75` calls `AssessmentSourceType._standardize(self.source_type)` in AssessmentSource.__post_init__; `/testbed/tests/tracing/test_assessment.py:619-635` tests AI_JUDGE deprecation.
- Uncertainty: None

### R13: AssessmentSourceType.__init__ and __str__ — Instance construction and string conversion
- Type: Interface
- Statement: AssessmentSourceType MUST implement __init__(source_type: str) that delegates to _parse() to store the validated source type, and __str__() that returns the stored string.
- Task Evidence: "The _standardize method must instantiate an AssessmentSourceType object by calling the constructor AssessmentSourceType(source_type), then convert the instance to a string representation... The AssessmentSourceType class must implement an __init__(source_type: str) method... and a __str__() method."
- Acceptance: `str(AssessmentSourceType("human"))` returns "HUMAN"; `AssessmentSourceType("AI_JUDGE")` emits FutureWarning and stores "LLM_JUDGE".
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py` shows AssessmentSourceType class with constants already defined but missing __init__, __str__, _parse, _standardize.
- Uncertainty: None

### R14: AssessmentSourceType._parse — Parse, warn, and validate source type
- Type: Behavior
- Statement: The _parse static method MUST uppercase the input, replace "AI_JUDGE" with "LLM_JUDGE" while issuing FutureWarning, validate against _SOURCE_TYPES, and raise MlflowException(INVALID_PARAMETER_VALUE) for unrecognized types.
- Task Evidence: "The constructor must delegate validation and transformation logic to a _parse(source_type: str) static method that performs case-insensitive normalization (converting to uppercase), handles the AI_JUDGE to LLM_JUDGE deprecation mapping with a FutureWarning, and validates against the _SOURCE_TYPES list."
- Acceptance: "_parse('human')" returns "HUMAN"; "_parse('AI_JUDGE')" issues FutureWarning and returns "LLM_JUDGE"; "_parse('bad')" raises MlflowException.
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py` defines _SOURCE_TYPES = [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]; `/testbed/mlflow/exceptions.py` defines MlflowException.
- Uncertainty: None

### R15: Span.inputs — Property returning span input data
- Type: Interface
- Statement: The Span class MUST expose an `inputs` property that retrieves the deserialized value stored under the SpanAttributeKey.INPUTS attribute, returning None if not set.
- Task Evidence: "The input values of the span... retrieves the input data that was passed to the operation represented by this span... stored as a span attribute... Returns None if no inputs were set."
- Acceptance: After `span.set_inputs({"query": "test"})`, `span.inputs` returns `{"query": "test"}`. When no inputs set, returns None.
- Repository Evidence: `/testbed/mlflow/entities/span.py` Span class stores attributes via `_CachedSpanAttributesRegistry`; LiveSpan.set_inputs() at line 529 sets SpanAttributeKey.INPUTS; `/testbed/mlflow/tracing/constant.py:60` defines SpanAttributeKey.INPUTS = "mlflow.spanInputs"; `/testbed/tests/tracing/opentelemetry/test_integration.py:112` tests `spans[0].inputs`.
- Uncertainty: None

### R16: Span.outputs — Property returning span output data
- Type: Interface
- Statement: The Span class MUST expose an `outputs` property that retrieves the deserialized value stored under the SpanAttributeKey.OUTPUTS attribute, returning None if not set.
- Task Evidence: "The output values of the span... retrieves the output values that were produced by the operation... stored as span attributes... Returns None if no outputs were set."
- Acceptance: After `span.set_outputs("result")`, `span.outputs` returns `"result"`. When no outputs set, returns None.
- Repository Evidence: `/testbed/mlflow/entities/span.py` Span class; LiveSpan.set_outputs() at line 533 sets SpanAttributeKey.OUTPUTS; `/testbed/mlflow/tracing/constant.py:61` defines SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"; `/testbed/tests/tracing/opentelemetry/test_integration.py:113` tests `spans[0].outputs`.
- Uncertainty: None

## L2. Functional Design Graph

### N1: databricks_tracing_utils module
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (file exists with imports, empty body)

### N2: assessment_to_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/store/tracking/databricks_rest_store.py:511` imports and calls it

### N3: get_trace_id_from_assessment_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/entities/assessment.py:288,426` calls it

### N4: inference_table_location_to_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/entities/trace_location.py:61-72` has InferenceTableLocation

### N5: mlflow_experiment_location_to_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/entities/trace_location.py:39-51` has MlflowExperimentLocation

### N6: trace_from_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/store/tracking/databricks_rest_store.py:189` calls it

### N7: trace_info_to_v4_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/entities/trace_info.py:103` calls it

### N8: trace_location_from_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/entities/trace_location.py:246` calls it

### N9: trace_location_to_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/store/tracking/databricks_rest_store.py:290,294` calls it

### N10: trace_to_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/tests/store/tracking/test_databricks_rest_store.py:46,212,451` imports and calls it

### N11: uc_schema_location_from_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/store/tracking/databricks_rest_store.py:422` calls it

### N12: uc_schema_location_to_proto
- Kind: Function
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (declared in interface); `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451` calls it

### N13: Assessment entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/assessment.py` — dataclass with name, source, trace_id, span_id, create_time_ms, last_update_time_ms, assessment_id, rationale, expectation, feedback, metadata, overrides, valid, error fields; has to_proto() returning assessments_pb2.Assessment

### N14: AssessmentSourceType class
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py` — constants defined, missing __init__, __str__, _parse, _standardize

### N15: TraceInfo entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_info.py` — dataclass with trace_id, trace_location, request_time, state, request_preview, response_preview, client_request_id, execution_duration, trace_metadata, tags, assessments; to_proto() dispatches to trace_info_to_v4_proto for v4; from_proto() reconstructs.

### N16: Span entity
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py` — class with _span (OTelReadableSpan), _attributes (_CachedSpanAttributesRegistry), get_attribute(), to_otel_proto(), from_otel_proto(); missing inputs and outputs properties

### N17: Trace entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace.py` — dataclass with info (TraceInfo) and data (TraceData); to_proto() returns ProtoTrace

### N18: TraceLocation entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py` — dataclass with type (TraceLocationType), mlflow_experiment, inference_table, uc_schema

### N19: UCSchemaLocation entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:86-123` — dataclass with catalog_name, schema_name, _otel_spans_table_name, _otel_logs_table_name

### N20: MlflowExperimentLocation entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:30-57` — dataclass with experiment_id

### N21: InferenceTableLocation entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:60-76` — dataclass with full_table_name

### N22: pb (databricks_tracing_pb2 protos)
- Kind: External
- Repository Evidence: `/testbed/mlflow/protos/databricks_tracing_pb2.py` — protobuf definitions for Assessment, Trace, TraceInfo, TraceLocation, UCSchemaLocation, MlflowExperimentLocation, InferenceTableLocation

### N23: assessments_pb2 protos
- Kind: External
- Repository Evidence: `/testbed/mlflow/protos/assessments_pb2.py` — protobuf Assessment (without trace_location)

### N24: parse_trace_id_v4 / construct_trace_id_v4
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py:631,649`

### N25: _truncate_request_metadata / _truncate_tags
- Kind: Function
- Repository Evidence: `/testbed/mlflow/entities/trace_info_v2.py`

### N26: TraceData entity
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_data.py` — dataclass with spans list

### N27: Span.from_otel_proto / Span.to_otel_proto
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/span.py:366,430`

### N28: TraceLocationType enum
- Kind: State
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:126-147` — UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE, TRACE_LOCATION_TYPE_UNSPECIFIED

### N29: LiveSpan
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/span.py:484` — subclass of Span with set_inputs/set_outputs

---

### E1: databricks_rest_store -> assessment_to_proto
- Kind: CALL
- Condition: When creating/updating an assessment with v4 UC Schema location
- Transfer: MLflow Assessment entity → pb.Assessment proto
- Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:511` calls `assessment_to_proto(assessment)`
- Obligations: R1

### E2: assessment_to_proto -> Assessment entity fields
- Kind: DATA
- Condition: Always
- Transfer: Reads name, trace_id, source, span_id, create_time_ms, last_update_time_ms, assessment_id, rationale, expectation, feedback, metadata, overrides, valid from Assessment entity
- Evidence: `/testbed/mlflow/entities/assessment.py:117-146` Assessment.to_proto() reads these fields
- Obligations: R1

### E3: assessment_to_proto -> pb.Assessment
- Kind: DATA
- Condition: Always
- Transfer: Writes all fields to pb.Assessment, sets trace_location when UC Schema parsed from trace_id
- Evidence: Task document description of assessment_to_proto output
- Obligations: R1

### E4: assessment_to_proto -> parse_trace_id_v4
- Kind: CALL
- Condition: When constructing trace_location for assessment proto
- Transfer: assessment.trace_id → parse_trace_id_v4 → (location, inner_trace_id)
- Evidence: Task document: "parses the trace_id to extract location information"; `/testbed/mlflow/tracing/utils/__init__.py:631`
- Obligations: R1

### E5: assessment_to_proto -> construct_trace_id_v4
- Kind: CALL
- Condition: When building trace_location for UC Schema
- Transfer: (catalog_name + "." + schema_name, inner_trace_id) → v4 trace ID stored in trace_location.uc_schema
- Evidence: Task document mentions UC Schema locations; `/testbed/mlflow/tracing/utils/__init__.py:649`
- Obligations: R1

### E6: assessment_to_proto -> Timestamp.FromMilliseconds
- Kind: CALL
- Condition: Always (for create_time_ms and last_update_time_ms)
- Transfer: Milliseconds int → protobuf Timestamp
- Evidence: Task document: "Timestamps are converted from milliseconds (Assessment format) to protobuf Timestamp format using FromMilliseconds()"
- Obligations: R1

### E7: get_trace_id_from_assessment_proto -> proto fields
- Kind: DATA
- Condition: Always
- Transfer: Reads trace_id and trace_location (if present) from proto
- Evidence: Task document: "checks if the proto has a 'trace_location' field and if it contains UC schema information"
- Obligations: R2

### E8: get_trace_id_from_assessment_proto -> construct_trace_id_v4
- Kind: CALL
- Condition: When proto has trace_location with uc_schema
- Transfer: (catalog.schema, trace_id) → v4 trace ID string
- Evidence: Task document: "constructs a v4 trace ID by combining the catalog/schema information with the trace ID"
- Obligations: R2

### E9: inference_table_location_to_proto -> pb.InferenceTableLocation
- Kind: DATA
- Condition: Always
- Transfer: entity.full_table_name → proto.full_table_name
- Evidence: Task document description; `/testbed/mlflow/entities/trace_location.py:60-76`
- Obligations: R3

### E10: mlflow_experiment_location_to_proto -> pb.MlflowExperimentLocation
- Kind: DATA
- Condition: Always
- Transfer: entity.experiment_id → proto.experiment_id
- Evidence: Task document description; `/testbed/mlflow/entities/trace_location.py:30-57`
- Obligations: R4

### E11: trace_from_proto -> TraceInfo.from_proto
- Kind: CALL
- Condition: Always
- Transfer: pb.TraceInfo → TraceInfo entity
- Evidence: Task document: "relies on TraceInfo.from_proto()"; `/testbed/mlflow/entities/trace_info.py:129-160`
- Obligations: R5

### E12: trace_from_proto -> Span.from_otel_proto
- Kind: CALL
- Condition: For each span in proto.spans
- Transfer: OTel proto Span + location_id → Span entity
- Evidence: Task document: "Individual spans are converted using Span.from_otel_proto() with the provided location_id"; `/testbed/mlflow/entities/span.py:366`
- Obligations: R5

### E13: trace_from_proto -> TraceData
- Kind: DATA
- Condition: Always
- Transfer: List of converted Span entities → TraceData(spans=[...])
- Evidence: `/testbed/mlflow/entities/trace_data.py`
- Obligations: R5

### E14: trace_from_proto -> Trace
- Kind: DATA
- Condition: Always
- Transfer: TraceInfo + TraceData → Trace(info=..., data=...)
- Evidence: `/testbed/mlflow/entities/trace.py:26-32`
- Obligations: R5

### E15: trace_info_to_v4_proto -> parse_trace_id_v4
- Kind: CALL
- Condition: When trace_info has UC Schema location (trace_info.trace_location.uc_schema is not None)
- Transfer: trace_info.trace_id → (location, inner_trace_id)
- Evidence: Task document: "For UC schema trace locations, the trace ID is parsed using parse_trace_id_v4()"
- Obligations: R6

### E16: trace_info_to_v4_proto -> assessment_to_proto
- Kind: CALL
- Condition: For each assessment in trace_info.assessments
- Transfer: Assessment entity → pb.Assessment
- Evidence: Task document describes assessments converted to protobuf format; `N2` assessment_to_proto
- Obligations: R6, R1

### E17: trace_info_to_v4_proto -> _truncate_request_metadata / _truncate_tags
- Kind: CALL
- Condition: Always
- Transfer: trace_metadata dict → truncated dict; tags dict → truncated dict
- Evidence: Task document: "Request metadata and tags are truncated using utility functions"; `/testbed/mlflow/entities/trace_info_v2.py`
- Obligations: R6

### E18: trace_info_to_v4_proto -> pb.TraceInfo
- Kind: DATA
- Condition: Always
- Transfer: All converted fields → pb.TraceInfo with timestamp/duration conversions
- Evidence: Task document: "Returns pb.TraceInfo: A protobuf TraceInfo message containing all the converted trace information"
- Obligations: R6

### E19: trace_location_from_proto -> WhichOneof('identifier')
- Kind: CONTROL
- Condition: Always (to determine location type)
- Transfer: Determines which of uc_schema, mlflow_experiment, inference_table is set
- Evidence: Task document: "Uses the WhichOneof method to determine which identifier field is set in the proto"
- Obligations: R7

### E20: trace_location_from_proto -> UCSchemaLocation.from_proto / MlflowExperimentLocation.from_proto / InferenceTableLocation.from_proto
- Kind: CALL
- Condition: Based on WhichOneof result
- Transfer: Proto subtype → entity subtype
- Evidence: Task document: "For mlflow_experiment and inference_table types, delegates to their respective from_proto class methods"
- Obligations: R7, R10

### E21: trace_location_from_proto -> TraceLocation constructor
- Kind: DATA
- Condition: Always
- Transfer: TraceLocationType + location subtype → TraceLocation entity
- Evidence: `/testbed/mlflow/entities/trace_location.py:171-175`
- Obligations: R7

### E22: trace_location_to_proto -> TraceLocationType checks
- Kind: CONTROL
- Condition: Branch on trace_location.type
- Transfer: Dispatches to uc_schema_location_to_proto (UC_SCHEMA), mlflow_experiment_location_to_proto (MLFLOW_EXPERIMENT), or inference_table_location_to_proto (INFERENCE_TABLE); raises ValueError otherwise
- Evidence: Task document: "delegates to specific conversion functions for each location type"; "Raises ValueError if not one of supported types"
- Obligations: R8

### E23: trace_location_to_proto -> uc_schema_location_to_proto / mlflow_experiment_location_to_proto / inference_table_location_to_proto
- Kind: CALL
- Condition: Based on trace_location.type
- Transfer: Location subtype entity → proto subtype
- Evidence: Task document; `E22`
- Obligations: R8, R11, R4, R3

### E24: trace_location_to_proto -> pb.TraceLocation
- Kind: DATA
- Condition: Always
- Transfer: Sets type enum + appropriate location oneof field
- Evidence: Task document; `/testbed/mlflow/protos/databricks_tracing_pb2.py` TraceLocation message
- Obligations: R8

### E25: trace_to_proto -> Trace.to_proto / trace_info_to_v4_proto
- Kind: CALL
- Condition: Always (via trace.info.to_proto())
- Transfer: Trace.info → pb.TraceInfo (delegates to trace_info_to_v4_proto for v4)
- Evidence: `/testbed/mlflow/entities/trace.py:317-325`; `/testbed/mlflow/entities/trace_info.py:103` calls trace_info_to_v4_proto
- Obligations: R9, R6

### E26: trace_to_proto -> Span.to_otel_proto
- Kind: CALL
- Condition: For each span in trace.data.spans
- Transfer: Span entity → OTel proto Span
- Evidence: Task document: "All spans in the trace data are converted to OpenTelemetry protobuf format"; `/testbed/mlflow/entities/span.py:430`
- Obligations: R9

### E27: trace_to_proto -> pb.Trace
- Kind: DATA
- Condition: Always
- Transfer: pb.TraceInfo + list of OTel proto spans → pb.Trace
- Evidence: Task document; `/testbed/mlflow/protos/databricks_tracing_pb2.py` Trace message
- Obligations: R9

### E28: uc_schema_location_from_proto -> pb.UCSchemaLocation fields
- Kind: DATA
- Condition: Always
- Transfer: Reads catalog_name, schema_name, otel_spans_table_name (if HasField), otel_logs_table_name (if HasField)
- Evidence: Task document: "Must contain catalog_name and schema_name fields. May optionally contain otel_spans_table_name and otel_logs_table_name fields"; `/testbed/mlflow/protos/databricks_tracing_pb2.py`
- Obligations: R10

### E29: uc_schema_location_from_proto -> UCSchemaLocation constructor
- Kind: DATA
- Condition: Always
- Transfer: catalog_name, schema_name → UCSchemaLocation; sets _otel_spans_table_name, _otel_logs_table_name when present
- Evidence: Task document: "Uses HasField() to check for optional fields before setting them"; `/testbed/mlflow/entities/trace_location.py:86-123`
- Obligations: R10

### E30: uc_schema_location_to_proto -> UCSchemaLocation entity fields
- Kind: DATA
- Condition: Always
- Transfer: Reads catalog_name, schema_name, _otel_spans_table_name, _otel_logs_table_name from entity
- Evidence: Task document: "accesses private attributes (_otel_spans_table_name and _otel_logs_table_name)"; `/testbed/mlflow/entities/trace_location.py:86-123`
- Obligations: R11

### E31: uc_schema_location_to_proto -> pb.UCSchemaLocation
- Kind: DATA
- Condition: Always
- Transfer: Sets catalog_name, schema_name, otel_spans_table_name, otel_logs_table_name on proto
- Evidence: Task document; `/testbed/mlflow/protos/databricks_tracing_pb2.py`
- Obligations: R11

### E32: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
- Kind: CALL
- Condition: Always during AssessmentSource initialization
- Transfer: self.source_type string → standardized uppercase string
- Evidence: `/testbed/mlflow/entities/assessment_source.py:75` calls `AssessmentSourceType._standardize(self.source_type)`
- Obligations: R12

### E33: AssessmentSourceType._standardize -> AssessmentSourceType.__init__
- Kind: CALL
- Condition: Always
- Transfer: source_type string → AssessmentSourceType instance
- Evidence: Task document: "must instantiate an AssessmentSourceType object by calling the constructor AssessmentSourceType(source_type)"
- Obligations: R12, R13

### E34: AssessmentSourceType.__init__ -> AssessmentSourceType._parse
- Kind: CALL
- Condition: Always
- Transfer: source_type string → validated/standardized string
- Evidence: Task document: "The constructor must delegate validation and transformation logic to a _parse(source_type: str) static method"
- Obligations: R13, R14

### E35: AssessmentSourceType._parse -> Validation & Deprecation
- Kind: CONTROL
- Condition: Input is "AI_JUDGE" (case-insensitive) → FutureWarning + return "LLM_JUDGE"; input matches _SOURCE_TYPES → return uppercased; otherwise → raise MlflowException
- Transfer: Input string → validated output or exception
- Evidence: Task document: "case-insensitive normalization (converting to uppercase), handles the AI_JUDGE to LLM_JUDGE deprecation mapping with a FutureWarning, and validates against the _SOURCE_TYPES list"
- Obligations: R14

### E36: AssessmentSourceType._standardize -> AssessmentSourceType.__str__
- Kind: CALL
- Condition: Always (after constructing instance)
- Transfer: AssessmentSourceType instance → standardized string
- Evidence: Task document: "convert the instance to a string representation to obtain the standardized value"
- Obligations: R12, R13

### E37: Span.inputs -> _CachedSpanAttributesRegistry.get
- Kind: CALL
- Condition: Always when accessing inputs property
- Transfer: SpanAttributeKey.INPUTS → deserialized attribute value
- Evidence: `/testbed/mlflow/entities/span.py:215` get_attribute calls self._attributes.get(key); SpanAttributeKey.INPUTS = "mlflow.spanInputs"
- Obligations: R15

### E38: Span.outputs -> _CachedSpanAttributesRegistry.get
- Kind: CALL
- Condition: Always when accessing outputs property
- Transfer: SpanAttributeKey.OUTPUTS → deserialized attribute value
- Evidence: `/testbed/mlflow/entities/span.py:215` get_attribute calls self._attributes.get(key); SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"
- Obligations: R16

### E39: LiveSpan.set_inputs -> _SpanAttributesRegistry.set
- Kind: DATA
- Condition: When user calls set_inputs on LiveSpan
- Transfer: (SpanAttributeKey.INPUTS, value) → stored as serialized attribute
- Evidence: `/testbed/mlflow/entities/span.py:529-531`; `/testbed/mlflow/entities/span.py:529`
- Obligations: R15

### E40: LiveSpan.set_outputs -> _SpanAttributesRegistry.set
- Kind: DATA
- Condition: When user calls set_outputs on LiveSpan
- Transfer: (SpanAttributeKey.OUTPUTS, value) → stored as serialized attribute
- Evidence: `/testbed/mlflow/entities/span.py:533-535`
- Obligations: R16

## L3. Verifiable Contracts

### C1: assessment_to_proto returns pb.Assessment with required fields
- Type: Interface
- Subject: assessment_to_proto function return type
- Relation: TYPE_IS
- Expected: `pb.Assessment` (databricks_tracing_pb2.Assessment)
- Evidence: Task doc "Convert an Assessment entity to its corresponding protobuf representation... Returns: pb.Assessment"; `/testbed/mlflow/store/tracking/databricks_rest_store.py:511` calls it
- Observe: RETURN_VALUE
- Target: `assessment_to_proto(assessment)` return type
- Obligations: R1
- Graph: N2, E1

### C2: assessment_to_proto sets assessment_name field
- Type: Dataflow
- Subject: pb.Assessment.assessment_name
- Relation: EQ
- Expected: assessment.name
- Evidence: Task doc "Basic assessment information (name)"; `/testbed/mlflow/entities/assessment.py:119` sets assessment.assessment_name = self.name
- Observe: FIELD_READ
- Target: result.assessment_name after assessment_to_proto(assessment)
- Obligations: R1
- Graph: N2, E2, E3

### C3: assessment_to_proto converts timestamps via FromMilliseconds
- Type: Dataflow
- Subject: pb.Assessment.create_time and last_update_time
- Relation: EQ
- Expected: Timestamp created from assessment.create_time_ms / last_update_time_ms via FromMilliseconds()
- Evidence: Task doc "Timestamps are converted from milliseconds (Assessment format) to protobuf Timestamp format using FromMilliseconds()"
- Observe: FIELD_READ
- Target: result.create_time.ToMilliseconds() equals assessment.create_time_ms
- Obligations: R1
- Graph: N2, E6

### C4: assessment_to_proto sets metadata as string key-value pairs
- Type: Dataflow
- Subject: pb.Assessment.metadata entries
- Relation: EQ
- Expected: All values converted to str type regardless of original type
- Evidence: Task doc "Metadata values are converted to strings regardless of their original type"
- Observe: FIELD_READ
- Target: result.metadata["key"] is str type
- Obligations: R1
- Graph: N2, E2, E3

### C5: assessment_to_proto sets exactly one of expectation or feedback
- Type: State
- Subject: pb.Assessment oneof 'value'
- Relation: EQ
- Expected: If assessment.expectation is not None, proto.expectation is set; elif assessment.feedback is not None, proto.feedback is set; never both.
- Evidence: Task doc "Either expectation or feedback will be set in the proto, but not both"; `/testbed/mlflow/entities/assessment.py:139-142`
- Observe: FIELD_READ
- Target: result.WhichOneof("value") returns "expectation" or "feedback" depending on input
- Obligations: R1
- Graph: N2, E2, E3

### C6: assessment_to_proto sets trace_location for UC Schema locations
- Type: Dataflow
- Subject: pb.Assessment.trace_location
- Relation: EQ
- Expected: When parse_trace_id_v4 returns a non-None location, trace_location is set with type=UC_SCHEMA and uc_schema populated
- Evidence: Task doc "The function automatically parses the trace_id to extract location information and constructs the appropriate trace_location proto field for UC Schema locations"
- Observe: FIELD_READ
- Target: result.HasField("trace_location") is True when assessment.trace_id contains v4 prefix
- Obligations: R1
- Graph: N2, E4, E5

### C7: get_trace_id_from_assessment_proto returns trace_id for non-UC proto
- Type: Dataflow
- Subject: Return value when no trace_location or non-UC location
- Relation: EQ
- Expected: proto.trace_id (raw)
- Evidence: Task doc "For other location types, it returns the trace ID directly"
- Observe: RETURN_VALUE
- Target: get_trace_id_from_assessment_proto(proto_without_trace_location)
- Obligations: R2
- Graph: N3, E7

### C8: get_trace_id_from_assessment_proto returns v4 trace ID for UC proto
- Type: Dataflow
- Subject: Return value when proto has trace_location with uc_schema
- Relation: EQ
- Expected: construct_trace_id_v4(catalog + "." + schema, proto.trace_id)
- Evidence: Task doc "For UC schema locations, the v4 trace ID format combines location information (catalog.schema) with the actual trace ID using construct_trace_id_v4()"
- Observe: RETURN_VALUE
- Target: get_trace_id_from_assessment_proto(proto_with_uc_trace_location)
- Obligations: R2
- Graph: N3, E7, E8

### C9: get_trace_id_from_assessment_proto handles both pb.Assessment and assessments_pb2.Assessment
- Type: Interface
- Subject: Function parameter type acceptance
- Relation: TYPE_IS
- Expected: Accepts both pb.Assessment (databricks_tracing_pb2) and assessments_pb2.Assessment without error
- Evidence: Task doc signature: "pb.Assessment | assessments_pb2.Assessment"; `/testbed/mlflow/entities/assessment.py:288` passes assessments_pb2.Assessment proto
- Observe: RETURN_VALUE
- Target: get_trace_id_from_assessment_proto(assessments_pb2.Assessment()) returns without AttributeError
- Obligations: R2
- Graph: N3

### C10: inference_table_location_to_proto returns correct proto
- Type: Dataflow
- Subject: pb.InferenceTableLocation.full_table_name
- Relation: EQ
- Expected: entity.full_table_name
- Evidence: Task doc "extracting the full_table_name attribute and setting it in the corresponding protobuf field"
- Observe: FIELD_READ
- Target: result.full_table_name equals input.full_table_name
- Obligations: R3
- Graph: N4, E9

### C11: mlflow_experiment_location_to_proto returns correct proto
- Type: Dataflow
- Subject: pb.MlflowExperimentLocation.experiment_id
- Relation: EQ
- Expected: entity.experiment_id
- Evidence: Task doc "extracting the experiment_id from the input object and creating a corresponding protobuf message"
- Observe: FIELD_READ
- Target: result.experiment_id equals input.experiment_id
- Obligations: R4
- Graph: N5, E10

### C12: trace_from_proto returns Trace with correct info
- Type: Dataflow
- Subject: Trace.info
- Relation: EQ
- Expected: TraceInfo.from_proto(proto.trace_info)
- Evidence: Task doc "relies on TraceInfo.from_proto() to deserialize trace metadata"
- Observe: FIELD_READ
- Target: result.info equals TraceInfo.from_proto(proto.trace_info)
- Obligations: R5
- Graph: N6, E11, E14

### C13: trace_from_proto converts spans with location_id
- Type: Dataflow
- Subject: Trace.data.spans
- Relation: EQ
- Expected: [Span.from_otel_proto(s, location_id) for s in proto.spans]
- Evidence: Task doc "Individual spans are converted using Span.from_otel_proto() with the provided location_id"
- Observe: FIELD_READ
- Target: result.data.spans[i].trace_id reflects location_id
- Obligations: R5
- Graph: N6, E12, E13

### C14: trace_info_to_v4_proto parses v4 trace_id for UC Schema
- Type: Dataflow
- Subject: pb.TraceInfo.trace_id when trace_location is UC Schema
- Relation: EQ
- Expected: Inner trace ID extracted via parse_trace_id_v4(trace_info.trace_id)[1]
- Evidence: Task doc "For UC schema trace locations, the trace ID is parsed using parse_trace_id_v4() to extract the actual trace ID from the v4 format"
- Observe: FIELD_READ
- Target: result.trace_id is the inner ID (not the full v4-prefixed string) for UC Schema
- Obligations: R6
- Graph: N7, E15, E18

### C15: trace_info_to_v4_proto sets trace_location as protobuf
- Type: Dataflow
- Subject: pb.TraceInfo.trace_location
- Relation: EQ
- Expected: trace_location_to_proto(trace_info.trace_location)
- Evidence: Task doc "Trace location as protobuf"; `/testbed/mlflow/entities/trace_info.py:48` has trace_location field
- Observe: FIELD_READ
- Target: result.trace_location is set
- Obligations: R6
- Graph: N7, E18, E22

### C16: trace_info_to_v4_proto converts request_time to Timestamp
- Type: Dataflow
- Subject: pb.TraceInfo.request_time
- Relation: EQ
- Expected: Timestamp created via FromMilliseconds(trace_info.request_time)
- Evidence: Task doc "Timestamps are converted from milliseconds to protobuf Timestamp format"; `/testbed/mlflow/entities/trace_info.py:48-59`
- Observe: FIELD_READ
- Target: result.request_time.ToMilliseconds() equals trace_info.request_time
- Obligations: R6
- Graph: N7, E18

### C17: trace_info_to_v4_proto sets execution_duration only when not None
- Type: State
- Subject: pb.TraceInfo.execution_duration
- Relation: DEFAULTS_TO
- Expected: Set via FromMilliseconds(trace_info.execution_duration) when non-None; not set (HasField False) when None
- Evidence: Task doc "Execution duration is only set in the protobuf if it's not None in the input"
- Observe: FIELD_READ
- Target: result.HasField("execution_duration") is True iff trace_info.execution_duration is not None
- Obligations: R6
- Graph: N7, E18

### C18: trace_info_to_v4_proto converts assessments via assessment_to_proto
- Type: Dataflow
- Subject: pb.TraceInfo.assessments entries
- Relation: EQ
- Expected: [assessment_to_proto(a) for a in trace_info.assessments]
- Evidence: Task doc "Associated assessments converted to protobuf format"
- Observe: FIELD_READ
- Target: len(result.assessments) equals len(trace_info.assessments) and each is pb.Assessment
- Obligations: R6, R1
- Graph: N7, E16, E18

### C19: trace_info_to_v4_proto uses truncated metadata and tags
- Type: Dataflow
- Subject: pb.TraceInfo.trace_metadata and tags
- Relation: EQ
- Expected: _truncate_request_metadata(trace_info.trace_metadata) and _truncate_tags(trace_info.tags)
- Evidence: Task doc "Request metadata and tags are truncated using utility functions"; `/testbed/mlflow/entities/trace_info_v2.py`
- Observe: FIELD_READ
- Target: result.trace_metadata and result.tags reflect truncated values
- Obligations: R6
- Graph: N7, E17, E18

### C20: trace_location_from_proto returns TraceLocation with UC_SCHEMA
- Type: Dataflow
- Subject: TraceLocation when proto has uc_schema set
- Relation: EQ
- Expected: TraceLocation(type=UC_SCHEMA, uc_schema=UCSchemaLocation from proto)
- Evidence: Task doc "Handles three types... UC_SCHEMA"; `/testbed/mlflow/entities/trace_location.py:171-200`
- Observe: FIELD_READ
- Target: result.type == TraceLocationType.UC_SCHEMA and result.uc_schema is not None
- Obligations: R7, R10
- Graph: N8, E19, E20, E21

### C21: trace_location_from_proto returns TraceLocation with MLFLOW_EXPERIMENT
- Type: Dataflow
- Subject: TraceLocation when proto has mlflow_experiment set
- Relation: EQ
- Expected: TraceLocation(type=MLFLOW_EXPERIMENT, mlflow_experiment=MlflowExperimentLocation.from_proto(proto.mlflow_experiment))
- Evidence: Task doc "delegates to their respective from_proto class methods"; `/testbed/mlflow/entities/trace_location.py:39-51`
- Observe: FIELD_READ
- Target: result.type == TraceLocationType.MLFLOW_EXPERIMENT
- Obligations: R7
- Graph: N8, E19, E20, E21

### C22: trace_location_from_proto returns unspecified for no identifier
- Type: State
- Subject: TraceLocation when no identifier field is set
- Relation: DEFAULTS_TO
- Expected: TraceLocation(type=TRACE_LOCATION_TYPE_UNSPECIFIED)
- Evidence: Task doc "Falls back to TRACE_LOCATION_TYPE_UNSPECIFIED if no recognized identifier is found"
- Observe: FIELD_READ
- Target: result.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED
- Obligations: R7
- Graph: N8, E19, E21

### C23: trace_location_to_proto dispatches by type to correct converter
- Type: Behavior
- Subject: Function dispatch based on trace_location.type
- Relation: CALLS
- Expected: UC_SCHEMA → uc_schema_location_to_proto; MLFLOW_EXPERIMENT → mlflow_experiment_location_to_proto; INFERENCE_TABLE → inference_table_location_to_proto
- Evidence: Task doc "delegates to specific conversion functions for each location type"
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: Each converter called with appropriate entity
- Obligations: R8
- Graph: N9, E22, E23

### C24: trace_location_to_proto raises ValueError for unsupported type
- Type: Failure
- Subject: Function behavior when trace_location.type is unsupported
- Relation: RAISES
- Expected: ValueError
- Evidence: Task doc "Raises ValueError if the trace_location.type is not one of the supported types"
- Observe: EXCEPTION
- Target: trace_location_to_proto(TraceLocation(type="BAD")) raises ValueError
- Obligations: R8
- Graph: N9, E22

### C25: trace_to_proto returns pb.Trace
- Type: Interface
- Subject: Function return type
- Relation: TYPE_IS
- Expected: pb.Trace (databricks_tracing_pb2.Trace)
- Evidence: Task doc "Returns pb.Trace"; `/testbed/tests/store/tracking/test_databricks_rest_store.py:212` uses result with GetTraceInfo.Response(trace=...)
- Observe: RETURN_VALUE
- Target: type(result) is pb.Trace
- Obligations: R9
- Graph: N10, E27

### C26: trace_to_proto has trace_info from trace.info.to_proto()
- Type: Dataflow
- Subject: pb.Trace.trace_info
- Relation: EQ
- Expected: trace.info.to_proto() result
- Evidence: Task doc "trace info is converted using the trace's built-in to_proto() method"
- Observe: FIELD_READ
- Target: result.trace_info equals trace.info.to_proto()
- Obligations: R9
- Graph: N10, E25, E27

### C27: trace_to_proto has spans from span.to_otel_proto()
- Type: Dataflow
- Subject: pb.Trace.spans
- Relation: EQ
- Expected: [s.to_otel_proto() for s in trace.data.spans]
- Evidence: Task doc "All spans in the trace data are converted to OpenTelemetry protobuf format"
- Observe: FIELD_READ
- Target: len(result.spans) equals len(trace.data.spans)
- Obligations: R9
- Graph: N10, E26, E27

### C28: uc_schema_location_from_proto returns UCSchemaLocation with catalog/schema
- Type: Dataflow
- Subject: UCSchemaLocation.catalog_name and schema_name
- Relation: EQ
- Expected: proto.catalog_name, proto.schema_name
- Evidence: Task doc "extracts the catalog name and schema name from the protobuf message"
- Observe: FIELD_READ
- Target: result.catalog_name equals proto.catalog_name and result.schema_name equals proto.schema_name
- Obligations: R10
- Graph: N11, E28, E29

### C29: uc_schema_location_from_proto sets optional otel table names
- Type: Dataflow
- Subject: UCSchemaLocation._otel_spans_table_name and _otel_logs_table_name
- Relation: EQ
- Expected: proto.otel_spans_table_name when HasField, proto.otel_logs_table_name when HasField
- Evidence: Task doc "If the protobuf message contains otel_spans_table_name or otel_logs_table_name fields, these will be set as private attributes on the returned object"
- Observe: FIELD_READ
- Target: result._otel_spans_table_name equals proto.otel_spans_table_name when HasField
- Obligations: R10
- Graph: N11, E28, E29

### C30: uc_schema_location_to_proto returns pb.UCSchemaLocation with all fields
- Type: Dataflow
- Subject: pb.UCSchemaLocation fields
- Relation: EQ
- Expected: catalog_name, schema_name, otel_spans_table_name, otel_logs_table_name from entity
- Evidence: Task doc "mapping all the relevant fields including catalog name, schema name, and the optional OpenTelemetry table names"
- Observe: FIELD_READ
- Target: result.catalog_name equals entity.catalog_name
- Obligations: R11
- Graph: N12, E30, E31

### C31: AssessmentSourceType._standardize returns uppercase string
- Type: Dataflow
- Subject: _standardize return value for lowercase input
- Relation: EQ
- Expected: For input "human", returns "HUMAN"
- Evidence: Task doc "Input is case-insensitive but output is always uppercase"
- Observe: RETURN_VALUE
- Target: AssessmentSourceType._standardize("human") equals "HUMAN"
- Obligations: R12, R13
- Graph: N14, E32, E33, E36

### C32: AssessmentSourceType._standardize handles AI_JUDGE deprecation
- Type: SideEffect
- Subject: FutureWarning emission and return value for "AI_JUDGE" input
- Relation: EQ
- Expected: Issues FutureWarning containing "AI_JUDGE is deprecated. Use LLM_JUDGE instead" and returns "LLM_JUDGE"
- Evidence: Task doc "automatically handles the deprecated 'AI_JUDGE' value by converting it to 'LLM_JUDGE' and issuing a FutureWarning"; `/testbed/tests/tracing/test_assessment.py:619-635`
- Observe: SIDE_EFFECT
- Target: pytest.warns(FutureWarning) when calling _standardize("AI_JUDGE")
- Obligations: R12, R14
- Graph: N14, E35

### C33: AssessmentSourceType._standardize raises MlflowException for invalid type
- Type: Failure
- Subject: Exception when source_type is not valid
- Relation: RAISES
- Expected: MlflowException with error_code=INVALID_PARAMETER_VALUE
- Evidence: Task doc "Raises MlflowException if the provided source_type is not a valid assessment source type"; `/testbed/mlflow/protos/databricks_pb2.py` INVALID_PARAMETER_VALUE
- Observe: EXCEPTION
- Target: AssessmentSourceType._standardize("INVALID") raises MlflowException
- Obligations: R12, R14
- Graph: N14, E35

### C34: AssessmentSourceType.__init__ stores normalized value
- Type: State
- Subject: Internal state after __init__("human")
- Relation: EQ
- Expected: Stores "HUMAN" internally
- Evidence: Task doc "__init__(source_type: str) method that stores the parsed source type value"
- Observe: STATE_READ
- Target: str(AssessmentSourceType("human")) returns "HUMAN"
- Obligations: R13, R14
- Graph: N14, E34

### C35: AssessmentSourceType.__str__ returns stored value
- Type: Interface
- Subject: __str__ method return
- Relation: EQ
- Expected: The stored source type string
- Evidence: Task doc "__str__() method that returns the stored source type string"
- Observe: RETURN_VALUE
- Target: str(AssessmentSourceType("CODE")) returns "CODE"
- Obligations: R13
- Graph: N14, E36

### C36: AssessmentSourceType._parse uppercases input
- Type: Dataflow
- Subject: _parse return for lowercase input
- Relation: EQ
- Expected: "human" → "HUMAN"
- Evidence: Task doc "case-insensitive normalization (converting to uppercase)"
- Observe: RETURN_VALUE
- Target: AssessmentSourceType._parse("human") returns "HUMAN"
- Obligations: R14
- Graph: N14, E35

### C37: AssessmentSourceType._parse validates against _SOURCE_TYPES
- Type: Failure
- Subject: Exception for invalid type
- Relation: RAISES
- Expected: MlflowException for types not in _SOURCE_TYPES list
- Evidence: Task doc "raises MlflowException with INVALID_PARAMETER_VALUE error code for invalid types"; _SOURCE_TYPES = [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]
- Observe: EXCEPTION
- Target: AssessmentSourceType._parse("BAD_TYPE") raises MlflowException
- Obligations: R14
- Graph: N14, E35

### C38: Span.inputs returns deserialized input attribute
- Type: Dataflow
- Subject: Span.inputs property when inputs were set
- Relation: EQ
- Expected: Deserialized value of SpanAttributeKey.INPUTS attribute
- Evidence: Task doc "The input values of the span... retrieves the input data... stored as a span attribute"; `/testbed/tests/tracing/opentelemetry/test_integration.py:112` tests spans[0].inputs
- Observe: RETURN_VALUE
- Target: span.inputs returns the same value that was set via set_inputs
- Obligations: R15
- Graph: N16, E37, E39

### C39: Span.inputs returns None when not set
- Type: State
- Subject: Span.inputs property when no inputs were set
- Relation: DEFAULTS_TO
- Expected: None
- Evidence: Task doc "Returns None if no inputs were set"
- Observe: RETURN_VALUE
- Target: span.inputs is None for a span without inputs
- Obligations: R15
- Graph: N16, E37

### C40: Span.outputs returns deserialized output attribute
- Type: Dataflow
- Subject: Span.outputs property when outputs were set
- Relation: EQ
- Expected: Deserialized value of SpanAttributeKey.OUTPUTS attribute
- Evidence: Task doc "The output values of the span... retrieves the output values... stored as span attributes"; `/testbed/tests/tracing/opentelemetry/test_integration.py:113` tests spans[0].outputs
- Observe: RETURN_VALUE
- Target: span.outputs returns the same value that was set via set_outputs
- Obligations: R16
- Graph: N16, E38, E40

### C41: Span.outputs returns None when not set
- Type: State
- Subject: Span.outputs property when no outputs were set
- Relation: DEFAULTS_TO
- Expected: None
- Evidence: Task doc "Returns None if no outputs were set"
- Observe: RETURN_VALUE
- Target: span.outputs is None for a span without outputs
- Obligations: R16
- Graph: N16, E38

### C42: trace_location_to_proto sets type and oneof for UC_SCHEMA
- Type: Dataflow
- Subject: pb.TraceLocation when type is UC_SCHEMA
- Relation: EQ
- Expected: type=UC_SCHEMA enum, uc_schema=uc_schema_location_to_proto(entity.uc_schema)
- Evidence: Task doc; `/testbed/mlflow/protos/databricks_tracing_pb2.py` TraceLocation has type + uc_schema oneof
- Observe: FIELD_READ
- Target: result.type and result.uc_schema are set correctly
- Obligations: R8, R11
- Graph: N9, E22, E23, E24

### C43: trace_info_to_v4_proto sets client_request_id
- Type: Dataflow
- Subject: pb.TraceInfo.client_request_id
- Relation: EQ
- Expected: trace_info.client_request_id (when not None)
- Evidence: Task doc "Client request ID"; `/testbed/mlflow/entities/trace_info.py:48`
- Observe: FIELD_READ
- Target: result.client_request_id equals trace_info.client_request_id
- Obligations: R6
- Graph: N7, E18

### C44: assessment_to_proto handles None optional fields gracefully
- Type: State
- Subject: pb.Assessment optional fields when None in entity
- Relation: UNCHANGED
- Expected: span_id, rationale, assessment_id, overrides, valid fields not set on proto when None in entity
- Evidence: Task doc "The function handles None values gracefully by only setting proto fields when the corresponding assessment fields are not None"
- Observe: FIELD_READ
- Target: HasField("span_id") is False when assessment.span_id is None
- Obligations: R1
- Graph: N2, E3

### C45: trace_location_from_proto returns TraceLocation with INFERENCE_TABLE
- Type: Dataflow
- Subject: TraceLocation when proto has inference_table set
- Relation: EQ
- Expected: TraceLocation(type=INFERENCE_TABLE, inference_table=InferenceTableLocation.from_proto(proto.inference_table))
- Evidence: Task doc "delegates to their respective from_proto class methods"
- Observe: FIELD_READ
- Target: result.type == TraceLocationType.INFERENCE_TABLE
- Obligations: R7
- Graph: N8, E19, E20, E21

### C46: AssessmentSourceType constants are plain strings
- Type: Interface
- Subject: Class constants (SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, AI_JUDGE, HUMAN, CODE)
- Relation: TYPE_IS
- Expected: Each is a str (not dict)
- Evidence: Task doc "The class constants (SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, AI_JUDGE, HUMAN, CODE) should be defined as simple string values, not dictionary structures"
- Observe: IMPORT_BOUNDARY
- Target: isinstance(AssessmentSourceType.HUMAN, str) is True
- Obligations: R13
- Graph: N14

### C47: AssessmentSourceType._SOURCE_TYPES excludes AI_JUDGE
- Type: State
- Subject: _SOURCE_TYPES list content
- Relation: EQ
- Expected: [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE] (AI_JUDGE not in list)
- Evidence: Task doc "The _SOURCE_TYPES list should contain [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE] (excluding the deprecated AI_JUDGE)"
- Observe: IMPORT_BOUNDARY
- Target: AssessmentSourceType.AI_JUDGE not in AssessmentSourceType._SOURCE_TYPES
- Obligations: R14
- Graph: N14
