#!/usr/bin/env python3
"""
Executable architecture spec: interface types, dataflow assertions, L2 connectivity.

Covers contracts: C3, C4, C6, C8, C9, C10, C11, C12, C17, C18, C19,
                  C20, C21, C22, C23, C24, C25
"""

import sys
import traceback

_FAILURES = []


def _record_failure(contract_id: str, msg: str) -> None:
    _FAILURES.append(f"[{contract_id}] {msg}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_active_mock_otel_span(trace_id=1, span_id=1, name="test_span",
                                parent_id=None, start_time=None,
                                status=None):
    """
    Create a mock OpenTelemetry span that is BOTH a trace_api.Span and a
    ReadableSpan. This simulates an active SDK span. The factory should
    return a LiveSpan for this.
    """
    import time as _time
    from dataclasses import dataclass, field
    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import Event, ReadableSpan

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)
        is_remote: bool = False

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(self, name, context, parent, start_time=None,
                     status=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(_time.time() * 1e9)
            self._end_time = None  # active = not ended
            self._status = status if status is not None else trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = {}
            self._events = []

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(Event(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self.name = name

        def end(self, end_time_ns=None):
            self._end_time = end_time_ns

        def record_exception(self):
            pass

    if status is None:
        status = trace_api.Status(trace_api.StatusCode.UNSET)

    return _MockOTelSpan(
        name=name,
        context=_MockSpanContext(trace_id, span_id),
        parent=_MockSpanContext(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        status=status,
    )


def _make_finished_mock_otel_span(trace_id=1, span_id=1, name="test_span",
                                  parent_id=None, start_time=None,
                                  end_time=None, status=None):
    """
    Create a mock OpenTelemetry span that is ONLY a ReadableSpan (not
    trace_api.Span). This simulates a finished/exported span. The factory
    should return an immutable Span for this.
    """
    import time as _time
    from dataclasses import dataclass, field
    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import Event, ReadableSpan

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)
        is_remote: bool = False

    class _MockReadableSpan(ReadableSpan):
        """ReadableSpan only - NOT trace_api.Span"""
        def __init__(self, name, context, parent, start_time=None,
                     end_time=None, status=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(_time.time() * 1e9)
            self._end_time = end_time
            self._status = status if status is not None else trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = {}
            self._events = []

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return False

        @property
        def name(self):
            return self._name

        @property
        def parent(self):
            return self._parent

    if status is None:
        status = trace_api.Status(trace_api.StatusCode.UNSET)

    return _MockReadableSpan(
        name=name,
        context=_MockSpanContext(trace_id, span_id),
        parent=_MockSpanContext(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        end_time=end_time if end_time is not None else int(_time.time() * 1e9),
        status=status,
    )


# ===========================================================================
# Contract check functions
# ===========================================================================

# --- C17: create_mlflow_span NonRecordingSpan -> NoOpSpan -------------------
# Contracts: C17

def check_C17_create_mlflow_span_nonrecording() -> None:
    """Contracts: C17"""
    from opentelemetry.trace import NonRecordingSpan

    try:
        from mlflow.entities.span import create_mlflow_span
    except ImportError as e:
        _record_failure("C17", f"create_mlflow_span not importable: {e}")
        return

    from mlflow.entities.span import NoOpSpan

    result = create_mlflow_span(NonRecordingSpan(context=None), "tr-123")
    if not isinstance(result, NoOpSpan):
        _record_failure("C17", f"Expected NoOpSpan, got {type(result).__name__}")
        return
    print("PASS: C17 - create_mlflow_span(NonRecordingSpan) returns NoOpSpan")


# --- C18: create_mlflow_span active OTelSpan -> LiveSpan --------------------
# Contracts: C18

def check_C18_create_mlflow_span_active_span() -> None:
    """Contracts: C18"""
    try:
        from mlflow.entities.span import create_mlflow_span
    except ImportError as e:
        _record_failure("C18", f"create_mlflow_span not importable: {e}")
        return

    from mlflow.entities.span import LiveSpan

    otel_span = _make_active_mock_otel_span(
        trace_id=999, span_id=42, name="active_span",
    )
    # This mock extends trace_api.Span, so isinstance(otel_span, OTelSpan) is True.
    result = create_mlflow_span(otel_span, "tr-123", "LLM")
    if not isinstance(result, LiveSpan):
        _record_failure("C18", f"Expected LiveSpan, got {type(result).__name__}")
        return
    print("PASS: C18 - create_mlflow_span(active OTelSpan) returns LiveSpan")


# --- C19: create_mlflow_span finished OTelReadableSpan -> Span --------------
# Contracts: C19

def check_C19_create_mlflow_span_readable_span() -> None:
    """Contracts: C19"""
    try:
        from mlflow.entities.span import create_mlflow_span
    except ImportError as e:
        _record_failure("C19", f"create_mlflow_span not importable: {e}")
        return

    from mlflow.entities.span import Span

    otel_span = _make_finished_mock_otel_span(
        trace_id=777, span_id=99, name="finished_span",
    )
    # This mock extends ONLY ReadableSpan, not trace_api.Span.
    # So isinstance(otel_span, OTelSpan) is False,
    # and isinstance(otel_span, OTelReadableSpan) is True.
    result = create_mlflow_span(otel_span, "tr-123")
    if not isinstance(result, Span):
        _record_failure("C19", f"Expected Span, got {type(result).__name__}")
        return
    print("PASS: C19 - create_mlflow_span(finished OTelReadableSpan) returns Span")


# --- C6: NoOpSpan.trace_id is sentinel constant -----------------------------
# Contracts: C6

def check_C6_noop_span_trace_id() -> None:
    """Contracts: C6"""
    from mlflow.entities.span import NoOpSpan, NO_OP_SPAN_TRACE_ID

    noop = NoOpSpan()
    if noop.trace_id != NO_OP_SPAN_TRACE_ID:
        _record_failure("C6",
                        f"Expected {NO_OP_SPAN_TRACE_ID!r}, got {noop.trace_id!r}")
        return
    if noop.trace_id != "MLFLOW_NO_OP_SPAN_TRACE_ID":
        _record_failure("C6",
                        f"Expected 'MLFLOW_NO_OP_SPAN_TRACE_ID', got {noop.trace_id!r}")
        return
    print("PASS: C6 - NoOpSpan.trace_id returns MLFLOW_NO_OP_SPAN_TRACE_ID")


# --- C8: NoOpSpan properties return None (except trace_id) ------------------
# Contracts: C8

def check_C8_noop_span_properties() -> None:
    """Contracts: C8"""
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()

    # These should all return None
    checks = [
        ("span_id", noop.span_id),
        ("name", noop.name),
        ("start_time_ns", noop.start_time_ns),
        ("end_time_ns", noop.end_time_ns),
        ("status", noop.status),
        ("_trace_id", noop._trace_id),
    ]

    for prop_name, value in checks:
        if value is not None:
            _record_failure("C8",
                            f"NoOpSpan.{prop_name} expected None, got {value!r}")

    if not _FAILURES or not any("C8" in f for f in _FAILURES):
        print("PASS: C8 - NoOpSpan properties return None (except trace_id)")


# --- C3: LiveSpan.to_immutable_span returns Span instance -------------------
# Contracts: C3

def check_C3_to_immutable_span_type() -> None:
    """Contracts: C3"""
    from mlflow.entities.span import LiveSpan, Span

    otel_span = _make_active_mock_otel_span(
        trace_id=111, span_id=222, name="test_live",
    )
    live = LiveSpan(otel_span, "tr-test")

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C3", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()
    if not isinstance(immutable, Span):
        _record_failure("C3",
                        f"Expected Span, got {type(immutable).__name__}")
        return
    if isinstance(immutable, LiveSpan):
        _record_failure("C3",
                        "to_immutable_span() returned LiveSpan, expected Span")
        return
    print("PASS: C3 - LiveSpan.to_immutable_span() returns Span (not LiveSpan)")


# --- C4: LiveSpan.to_immutable_span preserves trace_id ----------------------
# Contracts: C4

def check_C4_to_immutable_span_preserves_trace_id() -> None:
    """Contracts: C4"""
    from mlflow.entities.span import LiveSpan

    otel_span = _make_active_mock_otel_span(
        trace_id=333, span_id=444, name="test_trace_id_preserve",
    )
    live = LiveSpan(otel_span, "tr-preserve-test")

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C4", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()
    if immutable.trace_id != live.trace_id:
        _record_failure("C4",
                        f"trace_id mismatch: {immutable.trace_id!r} != {live.trace_id!r}")
        return
    print("PASS: C4 - to_immutable_span preserves trace_id")


# --- C9: Span.attributes returns deserialized dict --------------------------
# Contracts: C9

def check_C9_span_attributes_deserialized() -> None:
    """Contracts: C9"""
    from mlflow.entities.span import LiveSpan

    otel_span = _make_active_mock_otel_span(
        trace_id=555, span_id=666, name="attrs_test",
    )
    live = LiveSpan(otel_span, "tr-attrs")
    live.set_attribute("key", {"nested": 1})

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C9", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()

    if not hasattr(type(immutable), "attributes"):
        _record_failure("C9", "Span.attributes property not found")
        return

    attrs = immutable.attributes
    if not isinstance(attrs, dict):
        _record_failure("C9", f"Expected dict, got {type(attrs).__name__}")
        return

    val = attrs.get("key")
    if val != {"nested": 1}:
        _record_failure("C9",
                        f"Expected {{'nested': 1}}, got {val!r}")
        return
    print("PASS: C9 - Span.attributes returns deserialized Python dict")


# --- C10: Span.events returns list[SpanEvent] -------------------------------
# Contracts: C10

def check_C10_span_events_type() -> None:
    """Contracts: C10"""
    from mlflow.entities.span import LiveSpan
    from mlflow.entities.span_event import SpanEvent

    otel_span = _make_active_mock_otel_span(
        trace_id=777, span_id=888, name="events_test",
    )
    live = LiveSpan(otel_span, "tr-events")
    evt = SpanEvent(name="test_event", timestamp=1000, attributes={"a": 1})
    live.add_event(evt)

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C10", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()

    if not hasattr(type(immutable), "events"):
        _record_failure("C10", "Span.events property not found")
        return

    events = immutable.events
    if not isinstance(events, list):
        _record_failure("C10", f"Expected list, got {type(events).__name__}")
        return
    if len(events) == 0:
        _record_failure("C10", "events list is empty, expected at least 1 event")
        return
    if not isinstance(events[0], SpanEvent):
        _record_failure("C10",
                        f"Expected SpanEvent, got {type(events[0]).__name__}")
        return
    print("PASS: C10 - Span.events returns list[SpanEvent]")


# --- C11: Span.request_id equals trace_id -----------------------------------
# Contracts: C11

def check_C11_span_request_id() -> None:
    """Contracts: C11"""
    from mlflow.entities.span import LiveSpan

    otel_span = _make_active_mock_otel_span(
        trace_id=999, span_id=111, name="req_id_test",
    )
    live = LiveSpan(otel_span, "tr-request-id")

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C11", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()

    if not hasattr(type(immutable), "request_id"):
        _record_failure("C11", "Span.request_id property not found")
        return

    if immutable.request_id != immutable.trace_id:
        _record_failure("C11",
                        f"request_id {immutable.request_id!r} != trace_id {immutable.trace_id!r}")
        return
    print("PASS: C11 - Span.request_id equals Span.trace_id")


# --- C12: Span.span_type returns stored type --------------------------------
# Contracts: C12

def check_C12_span_span_type() -> None:
    """Contracts: C12"""
    from mlflow.entities.span import LiveSpan, SpanType

    otel_span = _make_active_mock_otel_span(
        trace_id=222, span_id=333, name="span_type_test",
    )
    # Use the constructor's span_type parameter
    live = LiveSpan(otel_span, "tr-span-type", span_type="LLM")

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C12", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()

    if not hasattr(type(immutable), "span_type"):
        _record_failure("C12", "Span.span_type property not found")
        return

    if immutable.span_type != "LLM":
        _record_failure("C12",
                        f"Expected 'LLM', got {immutable.span_type!r}")
        return
    print("PASS: C12 - Span.span_type returns stored span type")


# --- C20: _Trace.to_mlflow_trace returns Trace with immutable spans ---------
# Contracts: C20

def check_C20_trace_to_mlflow_trace() -> None:
    """Contracts: C20"""
    from mlflow.entities.span import LiveSpan
    from mlflow.tracing.trace_manager import _Trace
    from mlflow.entities import TraceInfo, Trace, Span
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState

    if not hasattr(_Trace, "to_mlflow_trace"):
        _record_failure("C20", "_Trace.to_mlflow_trace method not found")
        return

    info = TraceInfo(
        trace_id="tr-c20",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
        trace_metadata={},
        tags={},
    )

    otel_span = _make_active_mock_otel_span(
        trace_id=1, span_id=1, name="c20_test",
    )
    live_span = LiveSpan(otel_span, "tr-c20")

    internal_trace = _Trace(info=info, span_dict={live_span.span_id: live_span})

    try:
        mlflow_trace = internal_trace.to_mlflow_trace()
    except Exception as e:
        _record_failure("C20", f"to_mlflow_trace raised: {e}")
        return

    if not isinstance(mlflow_trace, Trace):
        _record_failure("C20",
                        f"Expected Trace, got {type(mlflow_trace).__name__}")
        return

    for span in mlflow_trace.data.spans:
        if not isinstance(span, Span):
            _record_failure("C20",
                            f"Span in trace data is {type(span).__name__}, not Span")
            return
        if isinstance(span, LiveSpan):
            _record_failure("C20",
                            "Trace contains LiveSpan, expected all immutable Span")
            return

    print("PASS: C20 - _Trace.to_mlflow_trace returns Trace with immutable spans")


# --- C21-C25: _decode_otel_proto_anyvalue -----------------------------------
# Contracts: C21, C22, C23, C24, C25

def check_C21_to_C25_decode_otel_proto_anyvalue() -> None:
    """Contracts: C21, C22, C23, C24, C25"""
    try:
        from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue
    except ImportError as e:
        _record_failure("C21-C25", f"_decode_otel_proto_anyvalue not importable: {e}")
        return

    from opentelemetry.proto.common.v1.common_pb2 import AnyValue

    # C21: string_value
    av_str = AnyValue(string_value="hello")
    result = _decode_otel_proto_anyvalue(av_str)
    if result != "hello":
        _record_failure("C21", f"Expected 'hello', got {result!r}")
    else:
        print("PASS: C21 - _decode_otel_proto_anyvalue decodes string_value")

    # C22: int_value
    av_int = AnyValue(int_value=42)
    result = _decode_otel_proto_anyvalue(av_int)
    if result != 42:
        _record_failure("C22", f"Expected 42, got {result!r}")
    else:
        print("PASS: C22 - _decode_otel_proto_anyvalue decodes int_value")

    # C23: unset -> None
    av_empty = AnyValue()
    result = _decode_otel_proto_anyvalue(av_empty)
    if result is not None:
        _record_failure("C23", f"Expected None, got {result!r}")
    else:
        print("PASS: C23 - _decode_otel_proto_anyvalue returns None for unset")

    # C24: array_value
    av_arr = AnyValue()
    av_arr.array_value.values.add().string_value = "a"
    av_arr.array_value.values.add().int_value = 1
    result = _decode_otel_proto_anyvalue(av_arr)
    if result != ["a", 1]:
        _record_failure("C24", f"Expected ['a', 1], got {result!r}")
    else:
        print("PASS: C24 - _decode_otel_proto_anyvalue recursively decodes array")

    # C25: kvlist_value
    av_kv = AnyValue()
    kv = av_kv.kvlist_value.values.add()
    kv.key = "k"
    kv.value.string_value = "v"
    result = _decode_otel_proto_anyvalue(av_kv)
    if result != {"k": "v"}:
        _record_failure("C25", f"Expected {{'k': 'v'}}, got {result!r}")
    else:
        print("PASS: C25 - _decode_otel_proto_anyvalue recursively decodes kvlist")


# ===========================================================================
# Runner
# ===========================================================================

def main() -> None:
    checks = [
        ("C17", check_C17_create_mlflow_span_nonrecording),
        ("C18", check_C18_create_mlflow_span_active_span),
        ("C19", check_C19_create_mlflow_span_readable_span),
        ("C6",  check_C6_noop_span_trace_id),
        ("C8",  check_C8_noop_span_properties),
        ("C3",  check_C3_to_immutable_span_type),
        ("C4",  check_C4_to_immutable_span_preserves_trace_id),
        ("C9",  check_C9_span_attributes_deserialized),
        ("C10", check_C10_span_events_type),
        ("C11", check_C11_span_request_id),
        ("C12", check_C12_span_span_type),
        ("C20", check_C20_trace_to_mlflow_trace),
        ("C21-C25", check_C21_to_C25_decode_otel_proto_anyvalue),
    ]

    for cid, fn in checks:
        try:
            fn()
        except Exception:
            _record_failure(cid, traceback.format_exc().strip().split('\n')[-1])

    if _FAILURES:
        print(f"\n{len(_FAILURES)} FAILURE(S):")
        for f in _FAILURES:
            print(f"  {f}")
        sys.exit(1)
    else:
        print("\nAll architecture spec checks passed.")


if __name__ == "__main__":
    main()
