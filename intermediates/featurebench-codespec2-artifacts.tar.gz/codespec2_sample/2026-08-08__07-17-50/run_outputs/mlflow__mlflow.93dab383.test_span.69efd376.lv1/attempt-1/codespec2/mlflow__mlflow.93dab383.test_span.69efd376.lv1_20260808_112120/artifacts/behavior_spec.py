#!/usr/bin/env python3
"""
Executable behavior spec: state transitions, behavior outcomes, failure modes,
side effects, defaults, boundaries, and compatibility.

Covers contracts: C1, C2, C5, C7, C13, C14, C15, C16, C20
"""

import sys
import traceback

_FAILURES = []


def _record_failure(contract_id: str, msg: str) -> None:
    _FAILURES.append(f"[{contract_id}] {msg}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_active_mock_otel_span(trace_id=1, span_id=1, name="test_span",
                                parent_id=None, start_time=None,
                                status=None):
    """
    Create a mock OpenTelemetry span that is BOTH a trace_api.Span and a
    ReadableSpan (simulates an active SDK span).
    """
    import time as _time
    from dataclasses import dataclass, field
    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import Event, ReadableSpan

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)
        is_remote: bool = False

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(self, name, context, parent, start_time=None,
                     status=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(_time.time() * 1e9)
            self._end_time = None
            self._status = status if status is not None else trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = {}
            self._events = []

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(Event(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self.name = name

        def end(self, end_time_ns=None):
            self._end_time = end_time_ns

        def record_exception(self):
            pass

    if status is None:
        status = trace_api.Status(trace_api.StatusCode.UNSET)

    return _MockOTelSpan(
        name=name,
        context=_MockSpanContext(trace_id, span_id),
        parent=_MockSpanContext(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        status=status,
    )


# ===========================================================================
# Contract check functions
# ===========================================================================

# --- C1: LiveSpan.set_span_type stores attribute ----------------------------
# Contracts: C1

def check_C1_set_span_type_stores_attribute() -> None:
    """Contracts: C1"""
    from mlflow.entities.span import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    otel_span = _make_active_mock_otel_span(
        trace_id=1, span_id=1, name="c1_test",
    )
    live = LiveSpan(otel_span, "tr-c1")

    if not hasattr(live, "set_span_type"):
        _record_failure("C1", "LiveSpan.set_span_type method not found")
        return

    live.set_span_type("LLM")
    result = live.get_attribute(SpanAttributeKey.SPAN_TYPE)
    if result != "LLM":
        _record_failure("C1",
                        f"Expected 'LLM', got {result!r}")
        return
    print("PASS: C1 - LiveSpan.set_span_type('LLM') stores attribute correctly")


# --- C2: LiveSpan.set_span_type overwrites previous -------------------------
# Contracts: C2

def check_C2_set_span_type_overwrites() -> None:
    """Contracts: C2"""
    from mlflow.entities.span import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    otel_span = _make_active_mock_otel_span(
        trace_id=2, span_id=2, name="c2_test",
    )
    live = LiveSpan(otel_span, "tr-c2")

    if not hasattr(live, "set_span_type"):
        _record_failure("C2", "LiveSpan.set_span_type method not found")
        return

    live.set_span_type("LLM")
    live.set_span_type("CHAIN")
    result = live.get_attribute(SpanAttributeKey.SPAN_TYPE)
    if result != "CHAIN":
        _record_failure("C2",
                        f"Expected 'CHAIN' (last value), got {result!r}")
        return
    print("PASS: C2 - LiveSpan.set_span_type overwrites previous value")


# --- C5: LiveSpan.from_dict raises NotImplementedError ----------------------
# Contracts: C5

def check_C5_live_span_from_dict_raises() -> None:
    """Contracts: C5"""
    from mlflow.entities.span import LiveSpan

    try:
        LiveSpan.from_dict({})
        _record_failure("C5",
                        "LiveSpan.from_dict({}) did not raise NotImplementedError")
    except NotImplementedError:
        print("PASS: C5 - LiveSpan.from_dict raises NotImplementedError")
    except Exception as e:
        _record_failure("C5",
                        f"Expected NotImplementedError, got {type(e).__name__}: {e}")


# --- C7: NoOpSpan setters do not raise --------------------------------------
# Contracts: C7

def check_C7_noop_span_setters_no_raise() -> None:
    """Contracts: C7"""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_event import SpanEvent
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    noop = NoOpSpan()

    setters_to_test = []

    # set_attribute
    if hasattr(noop, "set_attribute"):
        setters_to_test.append(("set_attribute", lambda: noop.set_attribute("k", "v")))
    else:
        _record_failure("C7", "NoOpSpan.set_attribute method not found")

    # set_attributes
    if hasattr(noop, "set_attributes"):
        setters_to_test.append(("set_attributes", lambda: noop.set_attributes({"k": "v"})))
    else:
        _record_failure("C7", "NoOpSpan.set_attributes method not found")

    # set_inputs
    if hasattr(noop, "set_inputs"):
        setters_to_test.append(("set_inputs", lambda: noop.set_inputs({"x": 1})))
    else:
        _record_failure("C7", "NoOpSpan.set_inputs method not found")

    # set_outputs
    if hasattr(noop, "set_outputs"):
        setters_to_test.append(("set_outputs", lambda: noop.set_outputs({"y": 2})))
    else:
        _record_failure("C7", "NoOpSpan.set_outputs method not found")

    # set_status
    if hasattr(noop, "set_status"):
        setters_to_test.append(("set_status",
                                lambda: noop.set_status(SpanStatus(SpanStatusCode.OK))))
    else:
        _record_failure("C7", "NoOpSpan.set_status method not found")

    # add_event
    if hasattr(noop, "add_event"):
        setters_to_test.append(("add_event",
                                lambda: noop.add_event(SpanEvent("evt", 0, {}))))
    else:
        _record_failure("C7", "NoOpSpan.add_event method not found")

    # end
    if hasattr(noop, "end"):
        setters_to_test.append(("end",
                                lambda: noop.end(outputs={"z": 3})))
    else:
        _record_failure("C7", "NoOpSpan.end method not found")

    # Execute all setters and check they don't raise
    for name, fn in setters_to_test:
        try:
            result = fn()
        except Exception as e:
            _record_failure("C7",
                            f"NoOpSpan.{name} raised {type(e).__name__}: {e}")

    # Check if there were any failures specifically for C7
    c7_failures = [f for f in _FAILURES if "C7" in f]
    if not c7_failures:
        print("PASS: C7 - NoOpSpan setters complete without raising")


# --- C13: Span.to_dict round-trip via Span.from_dict ------------------------
# Contracts: C13

def check_C13_span_to_dict_roundtrip() -> None:
    """Contracts: C13"""
    from mlflow.entities.span import LiveSpan, Span

    otel_span = _make_active_mock_otel_span(
        trace_id=3, span_id=3, name="roundtrip_test",
    )
    live = LiveSpan(otel_span, "tr-roundtrip")
    live.set_attribute("foo", "bar")
    live.set_attribute("num", 42)

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C13", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()

    if not hasattr(type(immutable), "to_dict"):
        _record_failure("C13", "Span.to_dict method not found")
        return

    if not hasattr(Span, "from_dict"):
        _record_failure("C13", "Span.from_dict classmethod not found")
        return

    d = immutable.to_dict()
    if not isinstance(d, dict):
        _record_failure("C13", f"to_dict() returned {type(d).__name__}, expected dict")
        return

    # Check required keys
    required_keys = ["trace_id", "span_id", "name", "start_time_unix_nano",
                     "end_time_unix_nano", "events", "status", "attributes"]
    for key in required_keys:
        if key not in d:
            _record_failure("C13", f"to_dict() missing key: {key!r}")
            return

    # Round-trip
    try:
        recreated = Span.from_dict(d)
    except Exception as e:
        _record_failure("C13", f"from_dict raised: {type(e).__name__}: {e}")
        return

    if recreated.name != immutable.name:
        _record_failure("C13",
                        f"name mismatch: {recreated.name!r} != {immutable.name!r}")
        return
    if recreated.trace_id != immutable.trace_id:
        _record_failure("C13",
                        f"trace_id mismatch: {recreated.trace_id!r} != {immutable.trace_id!r}")
        return
    if recreated.span_id != immutable.span_id:
        _record_failure("C13",
                        f"span_id mismatch: {recreated.span_id!r} != {immutable.span_id!r}")
        return
    if recreated.start_time_ns != immutable.start_time_ns:
        _record_failure("C13", "start_time_ns mismatch")
        return

    print("PASS: C13 - Span.to_dict round-trip preserves name, trace_id, span_id, start_time_ns")


# --- C14: Span.from_otel_proto produces valid Span --------------------------
# Contracts: C14

def check_C14_span_from_otel_proto() -> None:
    """Contracts: C14"""
    from mlflow.entities.span import Span

    if not hasattr(Span, "from_otel_proto"):
        _record_failure("C14", "Span.from_otel_proto classmethod not found")
        return

    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    # Build a minimal OTel protobuf span
    proto_span = OTelProtoSpan()
    proto_span.name = "proto_test_span"
    proto_span.trace_id = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01'
    proto_span.span_id = b'\x00\x00\x00\x00\x00\x00\x00\x01'
    proto_span.start_time_unix_nano = 1000000
    proto_span.end_time_unix_nano = 2000000
    proto_span.kind = OTelProtoSpan.SPAN_KIND_INTERNAL
    proto_span.status.code = 1  # OK in OTel protobuf
    proto_span.status.message = ""

    result = Span.from_otel_proto(proto_span)
    if not isinstance(result, Span):
        _record_failure("C14",
                        f"Expected Span, got {type(result).__name__}")
        return
    if result.name != "proto_test_span":
        _record_failure("C14",
                        f"Name mismatch: {result.name!r} != 'proto_test_span'")
        return

    print("PASS: C14 - Span.from_otel_proto returns valid Span with correct name")


# --- C15: Span.to_otel_proto produces OTelProtoSpan -------------------------
# Contracts: C15

def check_C15_span_to_otel_proto() -> None:
    """Contracts: C15"""
    from mlflow.entities.span import LiveSpan

    otel_span = _make_active_mock_otel_span(
        trace_id=4, span_id=4, name="to_otel_test",
    )
    live = LiveSpan(otel_span, "tr-to-otel")

    if not hasattr(live, "to_immutable_span"):
        _record_failure("C15", "LiveSpan.to_immutable_span method not found")
        return

    immutable = live.to_immutable_span()

    if not hasattr(type(immutable), "to_otel_proto"):
        _record_failure("C15", "Span.to_otel_proto method not found")
        return

    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    result = immutable.to_otel_proto()
    if not isinstance(result, OTelProtoSpan):
        _record_failure("C15",
                        f"Expected OTelProtoSpan, got {type(result).__name__}")
        return

    # trace_id should be populated as bytes (16 bytes from hex decode)
    if not result.trace_id:
        _record_failure("C15", "OTelProtoSpan.trace_id is empty")
        return

    print("PASS: C15 - Span.to_otel_proto returns OTelProtoSpan with trace_id bytes")


# --- C16: _CachedSpanAttributesRegistry.set raises MlflowException ----------
# Contracts: C16

def check_C16_cached_registry_set_raises() -> None:
    """Contracts: C16"""
    from mlflow.entities.span import _CachedSpanAttributesRegistry
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    otel_span = _make_active_mock_otel_span(
        trace_id=5, span_id=5, name="cached_test",
    )
    reg = _CachedSpanAttributesRegistry(otel_span)

    if not hasattr(reg, "set"):
        _record_failure("C16", "_CachedSpanAttributesRegistry.set method not found")
        return

    try:
        reg.set("key", "value")
        _record_failure("C16",
                        "Expected MlflowException but no exception was raised")
    except MlflowException as e:
        # Check error code
        if e.error_code != INVALID_PARAMETER_VALUE:
            _record_failure("C16",
                            f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}")
            return
        print("PASS: C16 - _CachedSpanAttributesRegistry.set raises MlflowException "
              "with INVALID_PARAMETER_VALUE")
    except Exception as e:
        _record_failure("C16",
                        f"Expected MlflowException, got {type(e).__name__}: {e}")


# --- C20 (behavior angle): _Trace.to_mlflow_trace span-type check -----------
# Contracts: C20

def check_C20b_trace_immutable_spans() -> None:
    """Contracts: C20 (behavioral verification)"""
    from mlflow.entities.span import LiveSpan, Span
    from mlflow.tracing.trace_manager import _Trace
    from mlflow.entities import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState

    if not hasattr(_Trace, "to_mlflow_trace"):
        _record_failure("C20", "_Trace.to_mlflow_trace method not found (behavior)")
        return

    info = TraceInfo(
        trace_id="tr-c20b",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
        trace_metadata={},
        tags={},
    )

    otel_span = _make_active_mock_otel_span(
        trace_id=6, span_id=6, name="c20b_test",
    )
    live_span = LiveSpan(otel_span, "tr-c20b")
    internal_trace = _Trace(info=info, span_dict={live_span.span_id: live_span})

    mlflow_trace = internal_trace.to_mlflow_trace()
    spans = mlflow_trace.data.spans

    if len(spans) == 0:
        _record_failure("C20", "No spans in trace data")
        return

    for span in spans:
        if type(span) is LiveSpan:
            _record_failure("C20",
                            "Trace contains LiveSpan; all spans must be Span (immutable)")
            return
        if not isinstance(span, Span):
            _record_failure("C20",
                            f"Span is not a Span instance: {type(span).__name__}")
            return

    print("PASS: C20 (behavior) - all spans in Trace.data.spans are Span instances")


# --- Supplemental: NoOpSpan end_time_ns returns None ------------------------
# Contracts: C8

def check_noop_span_end_time_ns_none() -> None:
    """Contracts: C8 (supplemental)"""
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    if noop.end_time_ns is not None:
        _record_failure("C8",
                        f"NoOpSpan.end_time_ns expected None, got {noop.end_time_ns!r}")
    else:
        print("PASS: NoOpSpan.end_time_ns returns None")


# --- Supplemental: NoOpSpan.name returns None -------------------------------
# Contracts: C8

def check_noop_span_name_none() -> None:
    """Contracts: C8 (supplemental)"""
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    if noop.name is not None:
        _record_failure("C8",
                        f"NoOpSpan.name expected None, got {noop.name!r}")
    else:
        print("PASS: NoOpSpan.name returns None")


# ===========================================================================
# Runner
# ===========================================================================

def main() -> None:
    checks = [
        ("C1",  check_C1_set_span_type_stores_attribute),
        ("C2",  check_C2_set_span_type_overwrites),
        ("C5",  check_C5_live_span_from_dict_raises),
        ("C7",  check_C7_noop_span_setters_no_raise),
        ("C13", check_C13_span_to_dict_roundtrip),
        ("C14", check_C14_span_from_otel_proto),
        ("C15", check_C15_span_to_otel_proto),
        ("C16", check_C16_cached_registry_set_raises),
        ("C20b", check_C20b_trace_immutable_spans),
        ("supp", check_noop_span_end_time_ns_none),
        ("supp", check_noop_span_name_none),
    ]

    for cid, fn in checks:
        try:
            fn()
        except Exception:
            _record_failure(cid, traceback.format_exc().strip().split('\n')[-1])

    if _FAILURES:
        print(f"\n{len(_FAILURES)} FAILURE(S):")
        for f in _FAILURES:
            print(f"  {f}")
        sys.exit(1)
    else:
        print("\nAll behavior spec checks passed.")


if __name__ == "__main__":
    main()
