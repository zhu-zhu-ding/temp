# Semantic IR

## L1. Requirement Obligations

### R1: LiveSpan.set_span_type
- **Type:** Behavior
- **Statement:** `LiveSpan.set_span_type(span_type: str)` must store the given span type string as a span attribute under the key `SpanAttributeKey.SPAN_TYPE`, overwriting any previous value.
- **Task Evidence:** Interface Description 2 — `LiveSpan.set_span_type(self, span_type: str)` docstring states "Set the type of the span to categorize its purpose or functionality… Setting the span type multiple times will overwrite the previous value."
- **Acceptance:** After calling `set_span_type("LLM")`, `span.get_attribute(SpanAttributeKey.SPAN_TYPE)` returns `"LLM"`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:525-527` (reference impl); `/testbed/mlflow/semantic_kernel/autolog.py:103` (caller: `set_span_type(mlflow_span)`); `/testbed/mlflow/tracing/fluent.py:492` (caller: `mlflow_span.set_span_type(span_type)`).
- **Uncertainty:** None.

### R2: LiveSpan.to_immutable_span
- **Type:** Behavior
- **Statement:** `LiveSpan.to_immutable_span()` must return a new immutable `Span` object wrapping the same underlying OpenTelemetry span, without copying data.
- **Task Evidence:** Interface Description 2 — `LiveSpan.to_immutable_span(self) -> 'Span'` docstring states "downcasts the live span object to an immutable span by wrapping the underlying OpenTelemetry span object."
- **Acceptance:** The returned `Span` has the same `trace_id`, `span_id`, `name`, `start_time_ns`, `attributes`, and `status` as the `LiveSpan`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:668-675` (reference impl); `/testbed/tests/utils/test_databricks_tracing_utils.py:199,249,311` (test callers); `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:31` (caller in `_Trace.to_mlflow_trace`).
- **Uncertainty:** None.

### R3: LiveSpan.from_dict (NotImplementedError)
- **Type:** Failure
- **Statement:** `LiveSpan.from_dict(cls, data)` must raise `NotImplementedError` because LiveSpan objects cannot be reconstructed from serialized data.
- **Task Evidence:** Interface Description 2 — `LiveSpan.from_dict` docstring states "This method is not supported for the LiveSpan class… Always raised since LiveSpan objects cannot be created from dictionary data."
- **Acceptance:** Calling `LiveSpan.from_dict({})` raises `NotImplementedError`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:665-666` (reference impl).
- **Uncertainty:** None.

### R4: NoOpSpan — full interface compatibility
- **Type:** Compatibility
- **Statement:** `NoOpSpan` must implement every property and method of `Span`/`LiveSpan` as a no-op (returning `None` or doing nothing) so that user code calling setters/getters on a `NoOpSpan` does not raise runtime errors.
- **Task Evidence:** Interface Description 2 — `NoOpSpan` docstring states "This instance should be returned from the mlflow.start_span context manager when span creation fails. This class should have exactly the same interface as the Span so that user's setter calls do not raise runtime errors."
- **Acceptance:** For every public property/method of `Span` and `LiveSpan`, calling it on `NoOpSpan()` completes without raising.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:761-851` (reference impl); `/testbed/tests/tracing/test_fluent.py:1832-1839` (test: `test_span_record_exception_no_op_span`); `/testbed/mlflow/tracking/client.py:1490` (caller returns `NoOpSpan()` on failure).
- **Uncertainty:** None.

### R5: NoOpSpan.trace_id returns sentinel constant
- **Type:** Behavior
- **Statement:** `NoOpSpan.trace_id` must return the string constant `"MLFLOW_NO_OP_SPAN_TRACE_ID"` to distinguish no-op spans from real spans.
- **Task Evidence:** Interface Description 2 — `NoOpSpan.trace_id` docstring states "Returns: str: A special constant trace ID 'MLFLOW_NO_OP_SPAN_TRACE_ID' that distinguishes no-op spans from real spans."
- **Acceptance:** `NoOpSpan().trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:784-788` (reference impl); `/testbed/mlflow/tracking/client.py:48` (import of `NO_OP_SPAN_TRACE_ID`).
- **Uncertainty:** None.

### R6: Span.attributes property
- **Type:** Dataflow
- **Statement:** `Span.attributes` must return a dictionary of all deserialized span attributes, deserializing each from its JSON-string internal representation.
- **Task Evidence:** Interface Description 2 — `Span.attributes` docstring states "The attributes are automatically deserialized from their internal JSON string representation to their original Python objects when accessed through this property."
- **Acceptance:** Given a span with attribute `"key"` set to `{"nested": true}`, `span.attributes["key"]` returns the Python dict `{"nested": True}`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:181-188` (reference impl using `get_all()`); `/testbed/libs/skinny/mlflow/entities/span.py:868-869` (`_SpanAttributesRegistry.get_all`).
- **Uncertainty:** None.

### R7: Span.events property
- **Type:** Dataflow
- **Statement:** `Span.events` must return a list of `SpanEvent` objects extracted from the underlying OpenTelemetry span events, converting internal `BoundedAttributes` to plain dicts.
- **Task Evidence:** Interface Description 2 — `Span.events` docstring states "The returned events are converted from OpenTelemetry's internal BoundedAttributes format to simple dictionaries to ensure proper serialization."
- **Acceptance:** After adding an event via `LiveSpan.add_event(SpanEvent(...))`, the corresponding immutable `Span.events` list contains a `SpanEvent` with matching name, timestamp, and attributes.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:191-207` (reference impl).
- **Uncertainty:** None.

### R8: Span.request_id property
- **Type:** Compatibility
- **Statement:** `Span.request_id` must return the same value as `Span.trace_id`, providing backward compatibility for deprecated `request_id` usage.
- **Task Evidence:** Interface Description 2 — `Span.request_id` docstring states "This property provides backward compatibility for code that uses the deprecated `request_id` attribute."
- **Acceptance:** `span.request_id == span.trace_id`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:121-123` (reference impl); `/testbed/mlflow/tracing/trace_manager.py:99` (uses `span.request_id`).
- **Uncertainty:** None.

### R9: Span.span_type property
- **Type:** Dataflow
- **Statement:** `Span.span_type` must return the span type string stored under `SpanAttributeKey.SPAN_TYPE`, or `None` if not set.
- **Task Evidence:** Interface Description 2 — `Span.span_type` docstring states "returns the span type as a string, which categorizes the kind of operation… Common span types include predefined values from the SpanType class… or 'UNKNOWN'."
- **Acceptance:** For a span created with `span_type="LLM"`, `span.span_type` returns `"LLM"`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:168-170` (reference impl).
- **Uncertainty:** None.

### R10: Span.to_dict serialization
- **Type:** Dataflow
- **Statement:** `Span.to_dict()` must serialize the span into a dictionary with base64-encoded trace_id/span_id/parent_span_id, plus name, start/end times in nanoseconds, events, status, and attributes.
- **Task Evidence:** Interface Description 2 — `Span.to_dict` docstring specifies exact keys and encoding: trace_id as 16-byte big-endian base64, span_id/parent_span_id as 8-byte big-endian base64.
- **Acceptance:** Round-trip: `Span.from_dict(span.to_dict())` produces an equivalent span.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:227-256` (reference impl with `_encode_trace_id_to_byte`, `_encode_span_id_to_byte`, `_encode_bytes_to_base64`).
- **Uncertainty:** None.

### R11: Span.from_otel_proto classmethod
- **Type:** Dataflow
- **Statement:** `Span.from_otel_proto(otel_proto_span, location_id=None)` must convert an OpenTelemetry protobuf span into an MLflow `Span` object, extracting trace/span IDs, timing, attributes (deserialized via `_decode_otel_proto_anyvalue`), events, and status.
- **Task Evidence:** Interface Description 2 — `Span.from_otel_proto` docstring states "This is an internal method used for receiving spans via the OpenTelemetry protocol (OTLP)." It specifies attribute serialization, location-dependent trace ID generation, and status code mapping.
- **Acceptance:** A protobuf span with trace_id bytes and span_id bytes round-trips through `from_otel_proto` to produce a valid MLflow Span.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:366-420` (reference impl); `/testbed/mlflow/entities/trace.py:184` (caller: `Span.from_otel_proto(span)`).
- **Uncertainty:** None.

### R12: Span.to_otel_proto conversion
- **Type:** Dataflow
- **Statement:** `Span.to_otel_proto()` must convert the MLflow `Span` into an OpenTelemetry protobuf Span message for OTLP export, mapping trace_id/span_id from hex to bytes, attributes via `_set_otel_proto_anyvalue`, and events via `SpanEvent.to_otel_proto()`.
- **Task Evidence:** Interface Description 2 — `Span.to_otel_proto` docstring states "conversion enables interoperability with OpenTelemetry-compatible tracing systems."
- **Acceptance:** The returned `OTelProtoSpan` has a valid `trace_id`, `span_id`, `name`, `start_time_unix_nano`, and status matching the source Span.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:422-453` (reference impl); `/testbed/mlflow/entities/trace.py:180` (caller: `span.to_otel_proto()`).
- **Uncertainty:** None.

### R13: _CachedSpanAttributesRegistry.set raises MlflowException
- **Type:** Failure
- **Statement:** `_CachedSpanAttributesRegistry.set(key, value)` must raise `MlflowException` with `INVALID_PARAMETER_VALUE` because cached spans are immutable.
- **Task Evidence:** Interface Description 2 — `_CachedSpanAttributesRegistry.set` docstring states "Always raised since this method is not supported for immutable spans."
- **Acceptance:** `_CachedSpanAttributesRegistry(otel_span).set("key", "val")` raises `MlflowException`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:905-908` (reference impl).
- **Uncertainty:** None.

### R14: create_mlflow_span factory function
- **Type:** Interface
- **Statement:** `create_mlflow_span(otel_span, trace_id, span_type=None)` must return the correct MLflow span subtype: `NoOpSpan` for `None`/`NonRecordingSpan`, `LiveSpan` for active `OTelSpan`, `Span` for finished `OTelReadableSpan`; raise `MlflowException` for invalid types.
- **Task Evidence:** Interface Description 2 — `create_mlflow_span` docstring states "This factory function creates the appropriate MLflow span object based on the type of the input OpenTelemetry span."
- **Acceptance:** With a `NonRecordingSpan`, returns `NoOpSpan`; with an active `OTelSpan`, returns `LiveSpan(request_id, span_type)`; with a finished `OTelReadableSpan`, returns `Span`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:66-88` (reference impl); `/testbed/tests/tracking/test_client.py:41` (import); `/testbed/mlflow/tracing/processor/otel.py:4` (import/caller); `/testbed/mlflow/tracing/processor/base_mlflow.py:87` (caller).
- **Uncertainty:** None.

### R15: _Trace.to_mlflow_trace
- **Type:** Dataflow
- **Statement:** `_Trace.to_mlflow_trace()` must convert all `LiveSpan` objects in `span_dict` to immutable `Span` objects via `to_immutable_span()`, call `set_request_response_preview` on the trace info, and return a `Trace` object.
- **Task Evidence:** Interface Description 1 — `_Trace.to_mlflow_trace` docstring states "transforms the mutable internal trace representation into an immutable MLflow Trace object… converts all LiveSpan objects… to immutable Span objects."
- **Acceptance:** The returned `Trace.data.spans` contains only `Span` (not `LiveSpan`) instances, and the `Trace.info` has request/response previews set.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:26-32` (reference impl); `/testbed/mlflow/tracing/trace_manager.py:186` (caller: `internal_trace.to_mlflow_trace()`); `/testbed/tests/tracing/test_trace_manager.py:56-70` (test: `test_add_spans` verifies `Span`, not `LiveSpan`).
- **Uncertainty:** None.

### R16: _decode_otel_proto_anyvalue
- **Type:** Dataflow
- **Statement:** `_decode_otel_proto_anyvalue(pb_any_value)` must recursively decode an OpenTelemetry protobuf `AnyValue` message into a Python object, handling all types: `None` for unset, `bool`, `str`, `int`, `float`, `bytes`, `list` for arrays, `dict` for key-value lists.
- **Task Evidence:** Interface Description 3 — `_decode_otel_proto_anyvalue` docstring states "recursively converts an OpenTelemetry AnyValue protobuf message into its corresponding Python representation… handles all supported AnyValue types."
- **Acceptance:** `_decode_otel_proto_anyvalue(AnyValue(string_value="hello"))` returns `"hello"`; `_decode_otel_proto_anyvalue(AnyValue(int_value=42))` returns `42`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:157-176` (reference impl); `/testbed/tests/entities/test_span_event.py:41-45` (test caller); `/testbed/libs/skinny/mlflow/entities/span.py:34,401,411` (caller in `from_otel_proto`).
- **Uncertainty:** None.

## L2. Functional Design Graph

### N1: Span (class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:91`

### N2: LiveSpan (class, extends Span)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:484`

### N3: NoOpSpan (class, extends Span)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:761`

### N4: _SpanAttributesRegistry
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:854`

### N5: _CachedSpanAttributesRegistry (extends _SpanAttributesRegistry)
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:892`

### N6: _Trace (dataclass)
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/tracing/trace_manager.py:24`

### N7: InMemoryTraceManager
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/tracing/trace_manager.py:55`

### N8: Trace
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace.py:22`

### N9: TraceData
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_data.py`

### N10: SpanEvent
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/span_event.py:12`

### N11: SpanStatus / SpanStatusCode
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/span_status.py`

### N12: create_mlflow_span (factory function)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/entities/span.py:66` (reference); imported in `/testbed/tests/tracking/test_client.py:41`

### N13: _decode_otel_proto_anyvalue
- **Kind:** Function
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:157` (reference)

### N14: set_request_response_preview
- **Kind:** Function
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/tracing/utils/truncation.py:15` (reference)

### N15: OTelProtoSpan (external)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:7` (import)

### N16: SpanType
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:44`

### N17: NO_OP_SPAN_TRACE_ID constant
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/entities/span.py:758`

### N18: SpanAttributeKey
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/tracing/constant.py`

---

### E1: create_mlflow_span -> NoOpSpan / LiveSpan / Span
- **Kind:** CONTROL
- **Condition:** If `otel_span` is None or `NonRecordingSpan` → `NoOpSpan`; if active `OTelSpan` → `LiveSpan`; if finished `OTelReadableSpan` → `Span`; else raise `MlflowException`.
- **Transfer:** `otel_span`, `trace_id`, `span_type` flow to the constructor of the chosen subtype.
- **Evidence:** Interface Description 2 for `create_mlflow_span`; `/testbed/libs/skinny/mlflow/entities/span.py:66-88`.
- **Obligations:** R14

### E2: LiveSpan.set_span_type -> _SpanAttributesRegistry.set
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `span_type` string → stored under `SpanAttributeKey.SPAN_TYPE` via attribute registry.
- **Evidence:** Interface Description 2 for `LiveSpan.set_span_type`; `/testbed/libs/skinny/mlflow/entities/span.py:525-527`.
- **Obligations:** R1

### E3: LiveSpan.to_immutable_span -> Span.__init__
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** `self._span` (OTel span) → `Span(otel_span)` constructor.
- **Evidence:** Interface Description 2 for `LiveSpan.to_immutable_span`; `/testbed/libs/skinny/mlflow/entities/span.py:668-675`.
- **Obligations:** R2

### E4: LiveSpan.from_dict -> NotImplementedError
- **Kind:** CONTROL
- **Condition:** Always (unconditional raise)
- **Transfer:** Exception raised to caller.
- **Evidence:** Interface Description 2 for `LiveSpan.from_dict`; `/testbed/libs/skinny/mlflow/entities/span.py:665-666`.
- **Obligations:** R3

### E5: NoOpSpan (all setters) -> no-op
- **Kind:** CONTROL
- **Condition:** Always
- **Transfer:** No state change; all methods return None or pass.
- **Evidence:** Interface Description 2 for NoOpSpan methods; `/testbed/libs/skinny/mlflow/entities/span.py:761-851`.
- **Obligations:** R4, R5

### E6: Span.attributes -> _CachedSpanAttributesRegistry.get_all
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Returns dict of all deserialized attributes.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:181-188`.
- **Obligations:** R6

### E7: Span.events -> _span.events iteration
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** OTel events list → list of SpanEvent with plain dict attributes.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:191-207`.
- **Obligations:** R7

### E8: Span.request_id -> Span.trace_id
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns same value as `trace_id`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:121-123`.
- **Obligations:** R8

### E9: Span.span_type -> _CachedSpanAttributesRegistry.get
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Returns value under `SpanAttributeKey.SPAN_TYPE`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:168-170`.
- **Obligations:** R9

### E10: Span.to_dict -> base64 encoding helpers
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** trace_id (16 bytes big-endian → base64), span_id (8 bytes big-endian → base64), parent_span_id, name, times, events, status, attributes.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:227-256`.
- **Obligations:** R10

### E11: Span.from_otel_proto -> _decode_otel_proto_anyvalue, build_otel_context
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Protobuf trace_id/span_id bytes → int IDs → OTel context; attributes decoded per element; status mapped; returns Span.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:366-420`.
- **Obligations:** R11, R16

### E12: Span.to_otel_proto -> _set_otel_proto_anyvalue, SpanEvent.to_otel_proto
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** MLflow span → OTelProtoSpan with hex-to-bytes ID conversion, attribute serialization, event conversion.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:422-453`.
- **Obligations:** R12

### E13: _CachedSpanAttributesRegistry.set -> MlflowException
- **Kind:** CONTROL
- **Condition:** Always (unconditional raise)
- **Transfer:** Exception raised; no state change.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:905-908`.
- **Obligations:** R13

### E14: _Trace.to_mlflow_trace -> LiveSpan.to_immutable_span, set_request_response_preview, Trace constructor
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Each LiveSpan → immutable Span; TraceData assembled; previews set; Trace(info, data) returned.
- **Evidence:** Interface Description 1; `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:26-32`.
- **Obligations:** R2, R15

### E15: _decode_otel_proto_anyvalue -> recursive self
- **Kind:** CALL
- **Condition:** On `array_value` or `kvlist_value` fields.
- **Transfer:** Recursively decoded elements → list or dict.
- **Evidence:** Interface Description 3; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:157-176`.
- **Obligations:** R16

### E16: InMemoryTraceManager.pop_trace -> _Trace.to_mlflow_trace
- **Kind:** CALL
- **Condition:** When internal_trace is not None.
- **Transfer:** `_Trace` → `ManagerTrace(trace=..., prompts=...)`.
- **Evidence:** `/testbed/mlflow/tracing/trace_manager.py:180-187`; `/testbed/libs/skinny/mlflow/tracing/trace_manager.py:185-187`.
- **Obligations:** R15

## L3. Verifiable Contracts

### C1: LiveSpan.set_span_type stores attribute
- **Type:** SideEffect
- **Subject:** `LiveSpan.set_span_type("LLM")`
- **Relation:** EQ
- **Expected:** `span.get_attribute(SpanAttributeKey.SPAN_TYPE)` returns `"LLM"`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:525-527`.
- **Observe:** RETURN_VALUE (via `get_attribute`)
- **Target:** `LiveSpan.get_attribute(SpanAttributeKey.SPAN_TYPE)`
- **Obligations:** R1
- **Graph:** E2, N2, N4

### C2: LiveSpan.set_span_type overwrites previous
- **Type:** State
- **Subject:** `LiveSpan.set_span_type` called twice with different values
- **Relation:** EQ
- **Expected:** Last call wins; `get_attribute(SpanAttributeKey.SPAN_TYPE)` returns last value.
- **Evidence:** Interface Description 2: "Setting the span type multiple times will overwrite the previous value."
- **Observe:** RETURN_VALUE (via `get_attribute`)
- **Target:** `LiveSpan.get_attribute(SpanAttributeKey.SPAN_TYPE)`
- **Obligations:** R1
- **Graph:** E2, N2

### C3: LiveSpan.to_immutable_span returns Span instance
- **Type:** Interface
- **Subject:** Return type of `LiveSpan.to_immutable_span()`
- **Relation:** TYPE_IS
- **Expected:** `Span` (not `LiveSpan`)
- **Evidence:** Interface Description 2; `/testbed/tests/tracing/test_trace_manager.py:66-68`.
- **Observe:** RETURN_VALUE
- **Target:** `type(live_span.to_immutable_span())`
- **Obligations:** R2
- **Graph:** E3, N2, N1

### C4: LiveSpan.to_immutable_span preserves trace_id
- **Type:** Dataflow
- **Subject:** `trace_id` after `to_immutable_span()`
- **Relation:** EQ
- **Expected:** `live_span.to_immutable_span().trace_id == live_span.trace_id`
- **Evidence:** `/testbed/tests/utils/test_databricks_tracing_utils.py:199-200`.
- **Observe:** FIELD_READ
- **Target:** `Span.trace_id`
- **Obligations:** R2
- **Graph:** E3, N1, N2

### C5: LiveSpan.from_dict raises NotImplementedError
- **Type:** Failure
- **Subject:** `LiveSpan.from_dict({})`
- **Relation:** RAISES
- **Expected:** `NotImplementedError`
- **Evidence:** Interface Description 2.
- **Observe:** EXCEPTION
- **Target:** `LiveSpan.from_dict`
- **Obligations:** R3
- **Graph:** E4, N2

### C6: NoOpSpan.trace_id is sentinel constant
- **Type:** Interface
- **Subject:** `NoOpSpan().trace_id`
- **Relation:** EQ
- **Expected:** `"MLFLOW_NO_OP_SPAN_TRACE_ID"`
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:784-788`.
- **Observe:** RETURN_VALUE
- **Target:** `NoOpSpan.trace_id`
- **Obligations:** R5
- **Graph:** N3, N17

### C7: NoOpSpan setters do not raise
- **Type:** Behavior
- **Subject:** All setter methods on NoOpSpan: `set_attribute`, `set_attributes`, `set_inputs`, `set_outputs`, `set_status`, `add_event`, `end`
- **Relation:** UNCHANGED
- **Expected:** No exception raised; no observable state change.
- **Evidence:** Interface Description 2; `/testbed/tests/tracing/test_fluent.py:1832-1839`.
- **Observe:** EXCEPTION (none raised)
- **Target:** Each NoOpSpan setter method
- **Obligations:** R4
- **Graph:** E5, N3

### C8: NoOpSpan properties return None (except trace_id)
- **Type:** Interface
- **Subject:** `span_id`, `name`, `start_time_ns`, `end_time_ns`, `status`, `_trace_id` on NoOpSpan
- **Relation:** EQ
- **Expected:** Each returns `None`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:791-820`.
- **Observe:** RETURN_VALUE
- **Target:** NoOpSpan property accessors
- **Obligations:** R4
- **Graph:** E5, N3

### C9: Span.attributes returns dict of deserialized values
- **Type:** Dataflow
- **Subject:** `Span.attributes` after setting attribute `"key"` to `{"nested": 1}`
- **Relation:** EQ
- **Expected:** `span.attributes["key"]` is `{"nested": 1}` (Python dict, not JSON string).
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:181-188`.
- **Observe:** RETURN_VALUE
- **Target:** `Span.attributes`
- **Obligations:** R6
- **Graph:** E6, N1, N5

### C10: Span.events returns list of SpanEvent
- **Type:** Interface
- **Subject:** Type and content of `Span.events`
- **Relation:** TYPE_IS
- **Expected:** `list[SpanEvent]`; each element has `name`, `timestamp`, `attributes` (dict).
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:191-207`.
- **Observe:** RETURN_VALUE
- **Target:** `Span.events`
- **Obligations:** R7
- **Graph:** E7, N1, N10

### C11: Span.request_id equals trace_id
- **Type:** Dataflow
- **Subject:** `Span.request_id` vs `Span.trace_id`
- **Relation:** EQ
- **Expected:** `span.request_id == span.trace_id`
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:121-123`.
- **Observe:** RETURN_VALUE
- **Target:** `Span.request_id`
- **Obligations:** R8
- **Graph:** E8, N1

### C12: Span.span_type returns stored type
- **Type:** Dataflow
- **Subject:** `Span.span_type` for span created with `span_type="LLM"`
- **Relation:** EQ
- **Expected:** `"LLM"`
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:168-170`.
- **Observe:** RETURN_VALUE
- **Target:** `Span.span_type`
- **Obligations:** R9
- **Graph:** E9, N1, N5

### C13: Span.to_dict round-trip via Span.from_dict
- **Type:** Dataflow
- **Subject:** `Span.from_dict(span.to_dict())`
- **Relation:** PRESERVE
- **Expected:** Resulting span has same `name`, `trace_id`, `span_id`, `start_time_ns`, `end_time_ns`, `status`, `attributes`, `events`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:227-256` (to_dict), `258-330` (from_dict).
- **Observe:** FIELD_READ
- **Target:** `Span.from_dict` / `Span.to_dict`
- **Obligations:** R10
- **Graph:** E10, N1

### C14: Span.from_otel_proto produces valid Span
- **Type:** Dataflow
- **Subject:** `Span.from_otel_proto(proto_span)`
- **Relation:** TYPE_IS
- **Expected:** Returns `Span` instance with correct name, trace_id, start_time_ns.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:366-420`.
- **Observe:** RETURN_VALUE
- **Target:** `Span.from_otel_proto`
- **Obligations:** R11, R16
- **Graph:** E11, N1, N13, N15

### C15: Span.to_otel_proto produces OTelProtoSpan
- **Type:** Dataflow
- **Subject:** `span.to_otel_proto()`
- **Relation:** TYPE_IS
- **Expected:** `OTelProtoSpan` with trace_id bytes matching hex decode of `span._trace_id`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:422-453`.
- **Observe:** RETURN_VALUE
- **Target:** `Span.to_otel_proto`
- **Obligations:** R12
- **Graph:** E12, N1, N15

### C16: _CachedSpanAttributesRegistry.set raises MlflowException
- **Type:** Failure
- **Subject:** `_CachedSpanAttributesRegistry(otel_span).set("key", "value")`
- **Relation:** RAISES
- **Expected:** `MlflowException` with error code `INVALID_PARAMETER_VALUE`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:905-908`.
- **Observe:** EXCEPTION
- **Target:** `_CachedSpanAttributesRegistry.set`
- **Obligations:** R13
- **Graph:** E13, N5

### C17: create_mlflow_span with NonRecordingSpan → NoOpSpan
- **Type:** Interface
- **Subject:** `create_mlflow_span(NonRecordingSpan(context=None), "tr-123")`
- **Relation:** TYPE_IS
- **Expected:** Returns `NoOpSpan` instance.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:76-79`.
- **Observe:** RETURN_VALUE
- **Target:** `create_mlflow_span`
- **Obligations:** R14
- **Graph:** E1, N12, N3

### C18: create_mlflow_span with active OTelSpan → LiveSpan
- **Type:** Interface
- **Subject:** `create_mlflow_span(active_otel_span, "tr-123", "LLM")`
- **Relation:** TYPE_IS
- **Expected:** Returns `LiveSpan` with `span_type` attribute set to `"LLM"`.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:81-82`; `/testbed/mlflow/tracing/processor/base_mlflow.py:87`.
- **Observe:** RETURN_VALUE
- **Target:** `create_mlflow_span`
- **Obligations:** R14
- **Graph:** E1, N12, N2

### C19: create_mlflow_span with finished OTelReadableSpan → Span
- **Type:** Interface
- **Subject:** `create_mlflow_span(finished_readable_span, "tr-123")`
- **Relation:** TYPE_IS
- **Expected:** Returns `Span` instance.
- **Evidence:** Interface Description 2; `/testbed/libs/skinny/mlflow/entities/span.py:84-85`.
- **Observe:** RETURN_VALUE
- **Target:** `create_mlflow_span`
- **Obligations:** R14
- **Graph:** E1, N12, N1

### C20: _Trace.to_mlflow_trace returns Trace with immutable spans
- **Type:** State
- **Subject:** Spans in returned `Trace.data.spans`
- **Relation:** TYPE_IS
- **Expected:** Every span is `Span` (not `LiveSpan`).
- **Evidence:** Interface Description 1; `/testbed/tests/tracing/test_trace_manager.py:66-68`.
- **Observe:** RETURN_VALUE
- **Target:** `_Trace.to_mlflow_trace`
- **Obligations:** R15
- **Graph:** E14, N6, N8

### C21: _decode_otel_proto_anyvalue decodes string_value
- **Type:** Dataflow
- **Subject:** `_decode_otel_proto_anyvalue(AnyValue(string_value="hello"))`
- **Relation:** EQ
- **Expected:** `"hello"`
- **Evidence:** Interface Description 3; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:157-176`.
- **Observe:** RETURN_VALUE
- **Target:** `_decode_otel_proto_anyvalue`
- **Obligations:** R16
- **Graph:** E15, N13

### C22: _decode_otel_proto_anyvalue decodes int_value
- **Type:** Dataflow
- **Subject:** `_decode_otel_proto_anyvalue(AnyValue(int_value=42))`
- **Relation:** EQ
- **Expected:** `42`
- **Evidence:** Interface Description 3; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:157-176`.
- **Observe:** RETURN_VALUE
- **Target:** `_decode_otel_proto_anyvalue`
- **Obligations:** R16
- **Graph:** E15, N13

### C23: _decode_otel_proto_anyvalue returns None for unset
- **Type:** Dataflow
- **Subject:** `_decode_otel_proto_anyvalue(AnyValue())`
- **Relation:** EQ
- **Expected:** `None`
- **Evidence:** Interface Description 3; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:159-160`.
- **Observe:** RETURN_VALUE
- **Target:** `_decode_otel_proto_anyvalue`
- **Obligations:** R16
- **Graph:** E15, N13

### C24: _decode_otel_proto_anyvalue recursively decodes array
- **Type:** Dataflow
- **Subject:** `_decode_otel_proto_anyvalue(arr_any_value)` where array contains `[AnyValue(string_value="a"), AnyValue(int_value=1)]`
- **Relation:** EQ
- **Expected:** `["a", 1]`
- **Evidence:** Interface Description 3; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:171-172`.
- **Observe:** RETURN_VALUE
- **Target:** `_decode_otel_proto_anyvalue`
- **Obligations:** R16
- **Graph:** E15, N13

### C25: _decode_otel_proto_anyvalue recursively decodes kvlist
- **Type:** Dataflow
- **Subject:** `_decode_otel_proto_anyvalue(kv_any_value)` where kvlist contains `{"k": AnyValue(string_value="v")}`
- **Relation:** EQ
- **Expected:** `{"k": "v"}`
- **Evidence:** Interface Description 3; `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py:174-176`.
- **Observe:** RETURN_VALUE
- **Target:** `_decode_otel_proto_anyvalue`
- **Obligations:** R16
- **Graph:** E15, N13
