# Semantic IR

## L1. Requirement Obligations

### R1: AssessmentSourceType string standardization
- **Type:** Behavior
- **Statement:** `AssessmentSourceType._standardize(source_type: str) -> str` must accept a case-insensitive source type string, convert it to uppercase, issue a `FutureWarning` if the deprecated `"AI_JUDGE"` is provided (resolving it to `"LLM_JUDGE"`), validate the result against `_SOURCE_TYPES`, and raise `MlflowException` with message `"Invalid assessment source type"` for unrecognized values.
- **Task Evidence:** "Standardize and validate assessment source types (human, LLM judge, code-based) with proper deprecation handling" / "Case-insensitive input standardization and deprecated value migration with warnings" / Interface Description 2 `_standardize` docstring.
- **Acceptance:** Calling `AssessmentSourceType._standardize("human")` returns `"HUMAN"`; `AssessmentSourceType._standardize("AI_JUDGE")` emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and returns `"LLM_JUDGE"`; `AssessmentSourceType._standardize("ROBOT")` raises `MlflowException`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType` (class body declares `_SOURCE_TYPES`, `AI_JUDGE`, etc.); `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_type_validation`, `test_assessment_source_case_insensitivity`, `test_ai_judge_deprecation_warning`; `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`.
- **Uncertainty:** None.

### R2: AssessmentSource backward compatibility with AI_JUDGE
- **Type:** Compatibility
- **Statement:** Creating `AssessmentSource(source_type="AI_JUDGE", source_id=...)` must automatically convert `"AI_JUDGE"` to `"LLM_JUDGE"` via `_standardize` in `__post_init__`, emitting a deprecation `FutureWarning`.
- **Task Evidence:** "Support multiple assessment source types with backward compatibility for legacy values" / "Handle case-insensitive input standardization and deprecated value migration with warnings" / Interface Description 2 notes on AI_JUDGE deprecation.
- **Acceptance:** `AssessmentSource(source_type="AI_JUDGE", source_id="ai_1").source_type == "LLM_JUDGE"` with a `FutureWarning`.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`; `/testbed/tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning`.
- **Uncertainty:** None.

### R3: AssessmentSource case-insensitive normalization
- **Type:** Behavior
- **Statement:** Any case variation of a valid source type string (e.g., `"human"`, `"Human"`, `"HUMAN"`) must normalize to the uppercase canonical form.
- **Task Evidence:** "Case-insensitive input standardization" / Interface Description 2: "Case-insensitive string inputs (converts to uppercase)".
- **Acceptance:** `AssessmentSource(source_type="human").source_type == "HUMAN"`; `AssessmentSource(source_type="llm_judge").source_type == "LLM_JUDGE"`.
- **Repository Evidence:** `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_case_insensitivity`.
- **Uncertainty:** None.

### R4: Invalid source type raises MlflowException
- **Type:** Failure
- **Statement:** Providing an unrecognized source type string must raise `MlflowException` with a message matching `"Invalid assessment source type"`.
- **Task Evidence:** Interface Description 2: "Raises MlflowException: If the provided source_type is not a valid assessment source type after case normalization and deprecation handling."
- **Acceptance:** `AssessmentSource(source_type="ROBOT")` raises `MlflowException` matching `"Invalid assessment source type"`.
- **Repository Evidence:** `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_type_validation`.
- **Uncertainty:** None.

### R5: SearchTracesTool name property
- **Type:** Interface
- **Statement:** `SearchTracesTool.name` must return `ToolNames._SEARCH_TRACES` (the string `"_search_traces"`).
- **Task Evidence:** Interface Description 1 `name` property: "Returns: str: The tool name constant for the search traces functionality."
- **Acceptance:** `SearchTracesTool().name == "_search_traces"`.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool.name` abstract property.
- **Uncertainty:** None.

### R6: SearchTracesTool get_definition returns ToolDefinition
- **Type:** Interface
- **Statement:** `get_definition()` must return a `ToolDefinition` with `type="function"`, `function.name=ToolNames._SEARCH_TRACES`, a non-empty description, and a `ToolParamsSchema` with three optional properties: `filter_string` (string), `order_by` (array of strings), `max_results` (integer with default 20). The `required` list must be empty.
- **Task Evidence:** Interface Description 1 `get_definition` docstring; task statement "Provide trace search capabilities within MLflow experiments with filtering, ordering, and result pagination."
- **Acceptance:** `definition.type == "function"`; `definition.function.name == "_search_traces"`; `"filter_string"`, `"order_by"`, `"max_results"` are in `definition.function.parameters.properties`; `definition.function.parameters.required == []`.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.get_definition` (pattern for ToolDefinition construction); `/testbed/mlflow/genai/judges/tools/get_trace_info.py:GetTraceInfoTool.get_definition` (pattern); `/testbed/mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`, `ParamProperty`.
- **Uncertainty:** None.

### R7: SearchTracesTool invoke searches traces in experiment
- **Type:** Behavior
- **Statement:** `invoke(trace, filter_string, order_by, max_results)` must extract the experiment ID from the trace's location, call `mlflow.search_traces` (or equivalent `MlflowClient.search_traces`) with `experiment_ids=[experiment_id]`, the provided `filter_string`, `order_by` defaulting to `["timestamp ASC"]`, and `max_results` defaulting to 20, and convert each returned trace into a `JudgeToolTraceInfo`.
- **Task Evidence:** Interface Description 1 `invoke` docstring: "Search for traces within the same experiment as the current trace" / "Returns: List of JudgeToolTraceInfo objects."
- **Acceptance:** Given a trace with a valid MLflow experiment location, `invoke` returns a `list[JudgeToolTraceInfo]` whose elements have populated `trace_id`, `request_time`, `state`, `request`, `response`, `execution_duration`, `assessments` fields.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke` (calls `SearchTracesTool().invoke()` with filter_string, order_by, max_results); `/testbed/mlflow/tracing/fluent.py:search_traces` (public search API); `/testbed/mlflow/tracing/client.py:MlflowClient.search_traces` (client API).
- **Uncertainty:** Whether `invoke` uses `mlflow.search_traces` (fluent) or `MlflowClient().search_traces` (client). The fluent API is simpler and sufficient for the tool. The task does not specify pagination via `page_token` for the tool invoke — `max_results` acts as a limit.

### R8: Trace location validation in invoke
- **Type:** Failure
- **Statement:** If the provided trace has no `trace_location`, or the `trace_location.type` is not `MLFLOW_EXPERIMENT`, or the experiment has no `experiment_id`, `invoke` must raise `MlflowException` with an appropriate message.
- **Task Evidence:** Interface Description 1 `invoke` docstring: "Raises: MlflowException: ... The provided trace has no trace location information / The trace is not from an MLflow experiment context / The trace has no associated experiment_id."
- **Acceptance:** A trace with `trace_location=None` or non-MLFLOW_EXPERIMENT location raises `MlflowException`.
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:TraceLocation`, `TraceLocationType`, `MlflowExperimentLocation`; `/testbed/mlflow/entities/trace_info.py:TraceInfo.experiment_id` property.
- **Uncertainty:** Exact error message wording is not specified in the task; the `_get_experiment_id` helper function docstring describes the three failure conditions.

### R9: Graceful error handling for individual trace processing failures
- **Type:** Failure
- **Statement:** If an individual trace fails to process during retrieval (e.g., can't download trace data), the tool must log a warning and skip that trace rather than failing the entire search.
- **Task Evidence:** Interface Description 1 `invoke` Notes: "Traces that fail to process during retrieval are logged as warnings and skipped."
- **Acceptance:** When some traces fail to process, the result list omits those traces without raising an exception; warnings are logged.
- **Repository Evidence:** `/testbed/mlflow/tracing/client.py:_get_trace_data_with_fallback` (logs warning and returns None on trace data download failure).
- **Uncertainty:** The exact mechanism depends on whether `mlflow.search_traces` already handles this internally (it does in `MlflowClient.search_traces` via `_get_trace_data_with_fallback`). The tool may need to handle this only if it iterates results post-search.

### R10: _get_experiment_id extracts and validates experiment ID from trace
- **Type:** Dataflow
- **Statement:** `_get_experiment_id(trace: Trace) -> str` must return the experiment ID string if the trace has a valid `MLFLOW_EXPERIMENT` location with an experiment_id; otherwise raise `MlflowException`.
- **Task Evidence:** Interface Description 1 `_get_experiment_id` docstring.
- **Acceptance:** For a trace with `trace_location.type == MLFLOW_EXPERIMENT` and `experiment_id="123"`, returns `"123"`. For a trace without trace_location, raises `MlflowException`.
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:TraceLocation.type`, `MlflowExperimentLocation.experiment_id`; `/testbed/mlflow/entities/trace_info.py:TraceInfo.experiment_id` property.
- **Uncertainty:** None.

### R11: _convert_assessments_to_tool_types converts Assessment objects
- **Type:** Dataflow
- **Statement:** `_convert_assessments_to_tool_types(assessments: list[Assessment]) -> list[JudgeToolExpectation | JudgeToolFeedback]` must convert each `Expectation` to `JudgeToolExpectation(name, source, rationale, span_id, assessment_id, value)` and each `Feedback` to `JudgeToolFeedback(name, source, rationale, span_id, assessment_id, value, error_code, error_message, stack_trace, overrides, valid)`.
- **Task Evidence:** Interface Description 1 `_convert_assessments_to_tool_types` docstring; "Convert assessment data between internal formats and tool-compatible types."
- **Acceptance:** A list of `[Expectation(...), Feedback(...)]` produces a list `[JudgeToolExpectation(...), JudgeToolFeedback(...)]` with matching fields.
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:Expectation` (fields: name, source, rationale, span_id, assessment_id, value); `/testbed/mlflow/entities/assessment.py:Feedback` (fields: name, source, rationale, span_id, assessment_id, value, error_code, error_message, overrides, valid); `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation`, `JudgeToolFeedback`.
- **Uncertainty:** The `source` field in `JudgeToolExpectation`/`JudgeToolFeedback` is typed `str` but `Assessment.source` is `AssessmentSource` object. The conversion should extract `source.source_type` as the string representation. The `error_code`, `error_message`, `stack_trace` for `JudgeToolFeedback` come from `Feedback.error` (an `AssessmentError`).

### R12: JudgeToolTraceInfo fields populated from trace search results
- **Type:** Dataflow
- **Statement:** Each `JudgeToolTraceInfo` returned by `invoke` must have: `trace_id` from `TraceInfo.trace_id`, `request_time` from `TraceInfo.request_time`, `state` from `TraceInfo.state`, `request` from `TraceData.request` (or deserialized), `response` from `TraceData.response` (or deserialized), `execution_duration` from `TraceInfo.execution_duration`, `assessments` from `TraceInfo.assessments` converted via `_convert_assessments_to_tool_types`.
- **Task Evidence:** Interface Description 1 `invoke` Returns: "List of JudgeToolTraceInfo objects, each containing: trace_id, request_time, state, request, response, execution_duration, assessments."
- **Acceptance:** Each returned `JudgeToolTraceInfo` has all seven fields populated from the original trace data.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`; `/testbed/mlflow/entities/trace_info.py:TraceInfo`; `/testbed/mlflow/entities/trace.py:Trace.to_pandas_dataframe_row` (shows request/response from `data.request`/`data.response`).
- **Uncertainty:** The `TraceData` class does not have explicit `request`/`response` dataclass fields; they are set dynamically via `__init__` kwargs for backward compatibility. The `Trace.to_pandas_dataframe_row` accesses `self.data.request` and `self.data.response`. The tool must handle the case where these are None or not present.

### R13: order_by defaults to ["timestamp ASC"]
- **Type:** State
- **Statement:** When `order_by` is `None`, the search must use `["timestamp ASC"]` as the default ordering.
- **Task Evidence:** Interface Description 1 `invoke`: "order_by: ... Defaults to ['timestamp ASC'] for chronological ordering if None."
- **Acceptance:** Calling `invoke(trace)` without `order_by` uses `order_by=["timestamp ASC"]` internally.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke` passes `order_by=order_by` (defaults to None, which SearchTracesTool handles).
- **Uncertainty:** None.

### R14: max_results defaults to 20
- **Type:** State
- **Statement:** When `max_results` is not provided, the tool must limit results to 20.
- **Task Evidence:** Interface Description 1 `invoke`: "max_results: ... Defaults to 20 to prevent excessive memory usage."
- **Acceptance:** `invoke(trace)` without `max_results` returns at most 20 traces.
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` passes `max_results=20` as default.
- **Uncertainty:** None.

### R15: filter_string supports SQL-like syntax
- **Type:** Interface
- **Statement:** `filter_string` must support MLflow's SQL-like search syntax, accepting filtering on attributes (`request_id`, `timestamp_ms`, `execution_time_ms`, `status`, `name`, `run_id`), tags (via `tags.` or `tag.` prefix), and metadata (via `metadata.` prefix), with quoted string values.
- **Task Evidence:** Interface Description 1 `invoke` docstring: "Supports filtering on attributes ... tags ... and metadata ... String values must be quoted."
- **Acceptance:** A `filter_string='status = "OK"'` filters traces with OK status. The filter is passed through to `mlflow.search_traces`.
- **Repository Evidence:** `/testbed/mlflow/store/tracking/sqlalchemy_store.py:search_traces` (parses filter_string with `_get_filter_clauses_for_search_traces`); `/testbed/mlflow/tracing/fluent.py:search_traces` (accepts filter_string).
- **Uncertainty:** The filter syntax is delegated to the underlying MLflow search infrastructure; the tool just passes it through.

## L2. Functional Design Graph

### N1: AssessmentSourceType
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType`

### N2: AssessmentSourceType._standardize
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType` (method declaration gap); `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` (caller)

### N3: AssessmentSource
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource`

### N4: AssessmentSource.__post_init__
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`

### N5: MlflowException
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/exceptions.py:MlflowException`

### N6: FutureWarning
- **Kind:** External
- **Repository Evidence:** Python standard library `warnings`

### N7: SearchTracesTool
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool`; `/testbed/mlflow/genai/judges/tools/__init__.py` (exports SearchTracesTool)

### N8: JudgeTool (base class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool`

### N9: SearchTracesTool.name
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool.name` (abstract); `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool` (to implement)

### N10: SearchTracesTool.get_definition
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool.get_definition` (abstract); `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool` (to implement)

### N11: SearchTracesTool.invoke
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool.invoke` (abstract); `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool` (to implement)

### N12: ToolNames
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames`

### N13: ToolDefinition
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/types/llm.py:ToolDefinition`

### N14: FunctionToolDefinition
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/types/llm.py:FunctionToolDefinition`

### N15: ToolParamsSchema
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/types/llm.py:ToolParamsSchema`

### N16: ParamProperty
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/types/llm.py:ParamProperty`

### N17: _get_experiment_id
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py` (to implement); `/testbed/mlflow/entities/trace_info.py:TraceInfo.experiment_id` (property used)

### N18: _convert_assessments_to_tool_types
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/search_traces.py` (to implement)

### N19: JudgeToolTraceInfo
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`

### N20: JudgeToolExpectation
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation`

### N21: JudgeToolFeedback
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolFeedback`

### N22: Expectation (assessment entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:Expectation`

### N23: Feedback (assessment entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment.py:Feedback`

### N24: AssessmentSource (entity)
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource`

### N25: Trace
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace.py:Trace`

### N26: TraceInfo
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_info.py:TraceInfo`

### N27: TraceLocation
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:TraceLocation`

### N28: TraceLocationType
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/entities/trace_location.py:TraceLocationType`

### N29: mlflow.search_traces (fluent API)
- **Kind:** External
- **Repository Evidence:** `/testbed/mlflow/tracing/fluent.py:search_traces`

### N30: AssessmentError
- **Kind:** Payload
- **Repository Evidence:** `/testbed/mlflow/entities/assessment_error.py:AssessmentError`

### N31: GetTracesInSession.invoke
- **Kind:** Function
- **Repository Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke`

---

### E1: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
- **Kind:** CALL
- **Condition:** Always (on every AssessmentSource instantiation)
- **Transfer:** `self.source_type` (raw string) → `_standardize` → normalized `str` assigned back to `self.source_type`
- **Evidence:** `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` body calls `AssessmentSourceType._standardize(self.source_type)`
- **Obligations:** R1, R2, R3, R4

### E2: AssessmentSourceType._standardize -> FutureWarning
- **Kind:** CONTROL
- **Condition:** Input uppercased equals `"AI_JUDGE"`
- **Transfer:** Emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` via `warnings.warn`; returns `"LLM_JUDGE"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning` expects `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated...")`
- **Obligations:** R1, R2

### E3: AssessmentSourceType._standardize -> MlflowException
- **Kind:** CONTROL
- **Condition:** Standardized value not in `_SOURCE_TYPES`
- **Transfer:** Raises `MlflowException` with message matching `"Invalid assessment source type"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_type_validation` expects `pytest.raises(MlflowException, match="Invalid assessment source type")`
- **Obligations:** R4

### E4: SearchTracesTool.name -> ToolNames._SEARCH_TRACES
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Returns constant string `"_search_traces"`
- **Evidence:** `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.name` returns `ToolNames._GET_TRACES_IN_SESSION` (pattern)
- **Obligations:** R5

### E5: SearchTracesTool.get_definition -> ToolDefinition
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Constructs `ToolDefinition(type="function", function=FunctionToolDefinition(name=ToolNames._SEARCH_TRACES, description=..., parameters=ToolParamsSchema(...)))`
- **Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.get_definition` (pattern for building ToolDefinition with filter_string-like params)
- **Obligations:** R6

### E6: SearchTracesTool.invoke -> _get_experiment_id
- **Kind:** CALL
- **Condition:** Always (first step in invoke)
- **Transfer:** `trace` → `_get_experiment_id` → `experiment_id: str`
- **Evidence:** Interface Description 1 `_get_experiment_id` docstring; pattern in `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` (validates session before search)
- **Obligations:** R7, R8, R10

### E7: _get_experiment_id -> TraceLocation / TraceLocationType
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Reads `trace.info.trace_location`; checks `trace_location is None`, then `trace_location.type != TraceLocationType.MLFLOW_EXPERIMENT`, then `trace_location.mlflow_experiment.experiment_id`
- **Evidence:** `/testbed/mlflow/entities/trace_info.py:TraceInfo.experiment_id` property (same logic); `/testbed/mlflow/entities/trace_location.py:TraceLocationType.MLFLOW_EXPERIMENT`
- **Obligations:** R8, R10

### E8: _get_experiment_id -> MlflowException
- **Kind:** CONTROL
- **Condition:** trace_location is None, type != MLFLOW_EXPERIMENT, or experiment_id is missing
- **Transfer:** Raises `MlflowException` with descriptive message
- **Evidence:** Interface Description 1 `_get_experiment_id` Raises section
- **Obligations:** R8, R10

### E9: SearchTracesTool.invoke -> mlflow.search_traces
- **Kind:** CALL
- **Condition:** After experiment_id extracted
- **Transfer:** `experiment_ids=[experiment_id]`, `filter_string=filter_string`, `order_by=order_by or ["timestamp ASC"]`, `max_results=max_results` → `mlflow.search_traces` → list of `Trace` objects
- **Evidence:** `/testbed/mlflow/tracing/fluent.py:search_traces` signature; `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` pattern (calls `SearchTracesTool().invoke()` which would internally call `mlflow.search_traces`)
- **Obligations:** R7, R13, R14, R15

### E10: SearchTracesTool.invoke -> _convert_assessments_to_tool_types
- **Kind:** CALL
- **Condition:** For each Trace in search results
- **Transfer:** `trace.info.assessments` (list of Assessment) → `_convert_assessments_to_tool_types` → list of `JudgeToolExpectation | JudgeToolFeedback`
- **Evidence:** Interface Description 1 `_convert_assessments_to_tool_types` docstring; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo.assessments` field type
- **Obligations:** R11

### E11: _convert_assessments_to_tool_types -> JudgeToolExpectation / JudgeToolFeedback
- **Kind:** DATA
- **Condition:** For each Assessment: if isinstance Expectation → JudgeToolExpectation; if isinstance Feedback → JudgeToolFeedback
- **Transfer:** Maps `Assessment.name → name`, `Assessment.source.source_type → source`, `Assessment.rationale → rationale`, `Assessment.span_id → span_id`, `Assessment.assessment_id → assessment_id`, `Expectation.value → value`; Feedback adds `Feedback.error.error_code → error_code`, `Feedback.error.error_message → error_message`, `Feedback.error.stack_trace → stack_trace`, `Feedback.overrides → overrides`, `Feedback.valid → valid`
- **Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation` fields, `JudgeToolFeedback` fields; `/testbed/mlflow/entities/assessment.py:Expectation`, `Feedback` fields; `/testbed/mlflow/entities/assessment_error.py:AssessmentError` fields
- **Obligations:** R11

### E12: SearchTracesTool.invoke -> JudgeToolTraceInfo
- **Kind:** DATA
- **Condition:** For each Trace in search results
- **Transfer:** Constructs `JudgeToolTraceInfo(trace_id=trace.info.trace_id, request_time=trace.info.request_time, state=trace.info.state, request=trace.data.request, response=trace.data.response, execution_duration=trace.info.execution_duration, assessments=_convert_assessments_to_tool_types(trace.info.assessments))`
- **Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo` dataclass fields; `/testbed/mlflow/entities/trace_info.py:TraceInfo` fields; `/testbed/mlflow/entities/trace.py:Trace.to_pandas_dataframe_row` (shows `data.request`/`data.response` access pattern)
- **Obligations:** R7, R12

### E13: SearchTracesTool.invoke -> logger.warning
- **Kind:** CONTROL
- **Condition:** Individual trace processing fails (exception during conversion)
- **Transfer:** Logs warning via `_logger.warning(...)` and skips that trace (continues processing remaining traces)
- **Evidence:** Interface Description 1 `invoke` Notes: "Traces that fail to process during retrieval are logged as warnings and skipped"
- **Obligations:** R9

### E14: GetTracesInSession.invoke -> SearchTracesTool.invoke
- **Kind:** CALL
- **Condition:** Always (after building filter_string with session ID)
- **Transfer:** `trace`, `filter_string`, `order_by`, `max_results` → `SearchTracesTool().invoke(...)` → list of `JudgeToolTraceInfo`
- **Evidence:** `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke` calls `SearchTracesTool().invoke(trace=..., filter_string=..., order_by=..., max_results=...)`
- **Obligations:** R7, R13, R14

## L3. Verifiable Contracts

### C1: _standardize returns uppercase for valid lower-case input
- **Type:** Behavior
- **Subject:** `AssessmentSourceType._standardize`
- **Relation:** EQ
- **Expected:** `"HUMAN"` for input `"human"`; `"LLM_JUDGE"` for input `"llm_judge"`; `"CODE"` for input `"code"`; `"SOURCE_TYPE_UNSPECIFIED"` for input `"source_type_unspecified"`
- **Evidence:** Task "Case-insensitive input standardization"; `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_case_insensitivity`
- **Observe:** RETURN_VALUE
- **Target:** `AssessmentSourceType._standardize("human")`
- **Obligations:** R1, R3
- **Graph:** N2, E1

### C2: _standardize emits FutureWarning for AI_JUDGE
- **Type:** SideEffect
- **Subject:** `AssessmentSourceType._standardize`
- **Relation:** EQ
- **Expected:** Emits `FutureWarning` matching `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` when input is `"AI_JUDGE"` (any case); returns `"LLM_JUDGE"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning` expects `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
- **Observe:** SIDE_EFFECT (warnings.warn)
- **Target:** `pytest.warns(FutureWarning, ...)` wrapping `AssessmentSourceType._standardize("AI_JUDGE")`
- **Obligations:** R1, R2
- **Graph:** N2, E2

### C3: _standardize raises MlflowException for invalid type
- **Type:** Failure
- **Subject:** `AssessmentSourceType._standardize`
- **Relation:** RAISES
- **Expected:** `MlflowException` with message matching `"Invalid assessment source type"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_type_validation` expects `pytest.raises(MlflowException, match="Invalid assessment source type")` for `source_type="ROBOT"`
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, ...)` wrapping `AssessmentSourceType._standardize("ROBOT")`
- **Obligations:** R4
- **Graph:** N2, E3

### C4: AssessmentSource normalizes AI_JUDGE via __post_init__
- **Type:** Behavior
- **Subject:** `AssessmentSource.__post_init__`
- **Relation:** EQ
- **Expected:** `AssessmentSource(source_type="AI_JUDGE", source_id="ai_1").source_type == "LLM_JUDGE"` and `source.source_id == "ai_1"`
- **Evidence:** `/testbed/tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning`
- **Observe:** FIELD_READ (`source.source_type`)
- **Target:** `AssessmentSource(source_type="AI_JUDGE", source_id="ai_1").source_type`
- **Obligations:** R2
- **Graph:** N3, N4, E1

### C5: SearchTracesTool.name returns ToolNames._SEARCH_TRACES
- **Type:** Interface
- **Subject:** `SearchTracesTool.name`
- **Relation:** EQ
- **Expected:** `"_search_traces"`
- **Evidence:** `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; pattern from `/testbed/tests/genai/judges/test_judge_tool_get_traces_in_session.py:test_get_traces_in_session_tool_name`
- **Observe:** RETURN_VALUE
- **Target:** `SearchTracesTool().name`
- **Obligations:** R5
- **Graph:** N9, E4

### C6: SearchTracesTool.get_definition returns valid ToolDefinition structure
- **Type:** Interface
- **Subject:** `SearchTracesTool.get_definition`
- **Relation:** TYPE_IS
- **Expected:** Returns `ToolDefinition` where `definition.type == "function"`, `definition.function.name == "_search_traces"`, `definition.function.parameters.type == "object"`, `definition.function.parameters.required == []`, and `definition.function.parameters.properties` contains keys `"filter_string"`, `"order_by"`, `"max_results"`
- **Evidence:** Interface Description 1 `get_definition` Returns; pattern from `/testbed/tests/genai/judges/test_judge_tool_get_traces_in_session.py:test_get_traces_in_session_tool_get_definition`
- **Observe:** RETURN_VALUE
- **Target:** `SearchTracesTool().get_definition()`
- **Obligations:** R6
- **Graph:** N10, E5

### C7: filter_string parameter in definition has type "string"
- **Type:** Interface
- **Subject:** `get_definition` → `parameters.properties["filter_string"]`
- **Relation:** EQ
- **Expected:** `ParamProperty` with `type="string"` and a non-empty `description`
- **Evidence:** Interface Description 1 `get_definition` docstring mentions filter_string parameter description
- **Observe:** FIELD_READ
- **Target:** `definition.function.parameters.properties["filter_string"].type`
- **Obligations:** R6, R15
- **Graph:** N10, E5

### C8: order_by parameter in definition has type "array" with string items
- **Type:** Interface
- **Subject:** `get_definition` → `parameters.properties["order_by"]`
- **Relation:** EQ
- **Expected:** `ParamProperty` with `type="array"` and `items.type="string"`
- **Evidence:** Interface Description 1 `get_definition` docstring: "order_by (list[str])"
- **Observe:** FIELD_READ
- **Target:** `definition.function.parameters.properties["order_by"].type` and `.items.type`
- **Obligations:** R6
- **Graph:** N10, E5

### C9: max_results parameter in definition has type "integer" with default 20
- **Type:** Interface
- **Subject:** `get_definition` → `parameters.properties["max_results"]`
- **Relation:** EQ
- **Expected:** `ParamProperty` with `type="integer"` and description mentioning default 20
- **Evidence:** Interface Description 1 `get_definition` docstring: "max_results (int): ... defaults to 20"
- **Observe:** FIELD_READ
- **Target:** `definition.function.parameters.properties["max_results"].type`
- **Obligations:** R6, R14
- **Graph:** N10, E5

### C10: _get_experiment_id returns experiment_id for valid MLflow experiment trace
- **Type:** Dataflow
- **Subject:** `_get_experiment_id`
- **Relation:** EQ
- **Expected:** For trace with `trace_location.type=MLFLOW_EXPERIMENT` and `experiment_id="exp-123"`, returns `"exp-123"`
- **Evidence:** Interface Description 1 `_get_experiment_id` Returns; `/testbed/mlflow/entities/trace_location.py:MlflowExperimentLocation`
- **Observe:** RETURN_VALUE
- **Target:** `_get_experiment_id(trace)` where trace has MLFLOW_EXPERIMENT location
- **Obligations:** R10
- **Graph:** N17, E7

### C11: _get_experiment_id raises MlflowException for missing trace_location
- **Type:** Failure
- **Subject:** `_get_experiment_id`
- **Relation:** RAISES
- **Expected:** `MlflowException` when trace has no `trace_location`
- **Evidence:** Interface Description 1 `_get_experiment_id` Raises: "The trace has no trace_location attribute"
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException)` wrapping `_get_experiment_id(trace_without_location)`
- **Obligations:** R8, R10
- **Graph:** N17, E8

### C12: _get_experiment_id raises MlflowException for non-MLFLOW_EXPERIMENT location
- **Type:** Failure
- **Subject:** `_get_experiment_id`
- **Relation:** RAISES
- **Expected:** `MlflowException` when trace location type is not `MLFLOW_EXPERIMENT`
- **Evidence:** Interface Description 1 `_get_experiment_id` Raises: "The trace location type is not MLFLOW_EXPERIMENT"
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException)` wrapping `_get_experiment_id(trace_with_inference_table_location)`
- **Obligations:** R8, R10
- **Graph:** N17, E8

### C13: _get_experiment_id raises MlflowException for missing experiment_id
- **Type:** Failure
- **Subject:** `_get_experiment_id`
- **Relation:** RAISES
- **Expected:** `MlflowException` when trace location type is `MLFLOW_EXPERIMENT` but `experiment_id` is None/empty
- **Evidence:** Interface Description 1 `_get_experiment_id` Raises: "The trace has no experiment_id in its MLflow experiment location data"
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException)` wrapping `_get_experiment_id(trace_with_null_experiment_id)`
- **Obligations:** R8, R10
- **Graph:** N17, E8

### C14: _convert_assessments_to_tool_types converts Expectation to JudgeToolExpectation
- **Type:** Dataflow
- **Subject:** `_convert_assessments_to_tool_types`
- **Relation:** EQ
- **Expected:** Given `[Expectation(name="correctness", source=AssessmentSource(source_type="HUMAN"), rationale="test", span_id="span1", assessment_id="a-1", value=5)]`, returns `[JudgeToolExpectation(name="correctness", source="HUMAN", rationale="test", span_id="span1", assessment_id="a-1", value=5)]`
- **Evidence:** Interface Description 1 `_convert_assessments_to_tool_types` Notes; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation`
- **Observe:** RETURN_VALUE
- **Target:** `_convert_assessments_to_tool_types([expectation])[0]`
- **Obligations:** R11
- **Graph:** N18, E11

### C15: _convert_assessments_to_tool_types converts Feedback to JudgeToolFeedback
- **Type:** Dataflow
- **Subject:** `_convert_assessments_to_tool_types`
- **Relation:** EQ
- **Expected:** Given `[Feedback(name="quality", source=AssessmentSource(source_type="LLM_JUDGE"), rationale="r", span_id="s1", assessment_id="a-2", value=0.9, error=None, overrides=None, valid=True)]`, returns `[JudgeToolFeedback(name="quality", source="LLM_JUDGE", rationale="r", span_id="s1", assessment_id="a-2", value=0.9, error_code=None, error_message=None, stack_trace=None, overrides=None, valid=True)]`
- **Evidence:** Interface Description 1 `_convert_assessments_to_tool_types` Notes; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolFeedback`
- **Observe:** RETURN_VALUE
- **Target:** `_convert_assessments_to_tool_types([feedback])[0]`
- **Obligations:** R11
- **Graph:** N18, E11

### C16: SearchTracesTool.invoke returns list of JudgeToolTraceInfo
- **Type:** Interface
- **Subject:** `SearchTracesTool.invoke`
- **Relation:** TYPE_IS
- **Expected:** Returns `list[JudgeToolTraceInfo]`; each element has typed fields matching `JudgeToolTraceInfo` dataclass
- **Evidence:** Interface Description 1 `invoke` Returns
- **Observe:** RETURN_VALUE
- **Target:** `isinstance(result, list) and all(isinstance(x, JudgeToolTraceInfo) for x in result)`
- **Obligations:** R7, R12
- **Graph:** N11, E12

### C17: SearchTracesTool.invoke defaults order_by to ["timestamp ASC"]
- **Type:** Behavior
- **Subject:** `SearchTracesTool.invoke`
- **Relation:** DEFAULTS_TO
- **Expected:** When `order_by=None`, the internal call to `mlflow.search_traces` uses `order_by=["timestamp ASC"]`
- **Evidence:** Interface Description 1 `invoke` Args: "order_by: ... Defaults to ['timestamp ASC']"
- **Observe:** RUNTIME_ARGUMENT_TRACE (mock on `mlflow.search_traces`)
- **Target:** Mock assertion on `mlflow.search_traces` call kwarg `order_by`
- **Obligations:** R13
- **Graph:** N11, E9

### C18: SearchTracesTool.invoke defaults max_results to 20
- **Type:** Behavior
- **Subject:** `SearchTracesTool.invoke`
- **Relation:** DEFAULTS_TO
- **Expected:** When `max_results` not provided, internal call uses `max_results=20`
- **Evidence:** Interface Description 1 `invoke` Args: "max_results: ... Defaults to 20"
- **Observe:** RUNTIME_ARGUMENT_TRACE (mock on `mlflow.search_traces`)
- **Target:** Mock assertion on `mlflow.search_traces` call kwarg `max_results`
- **Obligations:** R14
- **Graph:** N11, E9

### C19: SearchTracesTool.invoke raises MlflowException for invalid trace location
- **Type:** Failure
- **Subject:** `SearchTracesTool.invoke`
- **Relation:** RAISES
- **Expected:** `MlflowException` when trace has no experiment context (delegates to `_get_experiment_id`)
- **Evidence:** Interface Description 1 `invoke` Raises
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException)` wrapping `SearchTracesTool().invoke(trace_without_location)`
- **Obligations:** R7, R8
- **Graph:** N11, E6, E8

### C20: JudgeToolTraceInfo.assessments uses converted types
- **Type:** Dataflow
- **Subject:** `SearchTracesTool.invoke` → `JudgeToolTraceInfo.assessments`
- **Relation:** TYPE_IS
- **Expected:** Each element of the `assessments` list is either `JudgeToolExpectation` or `JudgeToolFeedback`
- **Evidence:** `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo` field type annotation; Interface Description 1 `invoke` Returns mention "assessments: List of expectations and feedback"
- **Observe:** FIELD_READ
- **Target:** `all(isinstance(a, (JudgeToolExpectation, JudgeToolFeedback)) for a in result[0].assessments)`
- **Obligations:** R11, R12
- **Graph:** N19, E10, E11
