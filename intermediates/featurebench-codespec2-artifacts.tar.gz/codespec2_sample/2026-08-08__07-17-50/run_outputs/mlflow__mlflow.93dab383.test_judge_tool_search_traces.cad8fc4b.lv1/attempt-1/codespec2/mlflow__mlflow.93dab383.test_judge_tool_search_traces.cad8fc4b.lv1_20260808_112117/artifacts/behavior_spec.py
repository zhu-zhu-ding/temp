"""
Behavior spec for SearchTracesTool, AssessmentSourceType, and related
contracts.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility.
"""
import sys
import warnings
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Core imports under test
# ---------------------------------------------------------------------------
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.entities.trace import Trace, TraceData
from mlflow.entities.trace_info import TraceInfo
from mlflow.entities.trace_location import (
    InferenceTableLocation,
    MlflowExperimentLocation,
    TraceLocation,
    TraceLocationType,
)
from mlflow.entities.trace_state import TraceState
from mlflow.exceptions import MlflowException
from mlflow.genai.judges.tools.search_traces import (
    SearchTracesTool,
    _convert_assessments_to_tool_types,
    _get_experiment_id,
)
from mlflow.genai.judges.tools.types import (
    JudgeToolExpectation,
    JudgeToolFeedback,
    JudgeToolTraceInfo,
)


# ===========================================================================
# Helpers
# ===========================================================================


def _make_trace(experiment_id="exp-123", trace_location_type=None, **kwargs):
    """Build a Trace with the given location type."""
    if trace_location_type is None:
        trace_location_type = TraceLocationType.MLFLOW_EXPERIMENT

    mlflow_exp = None
    inf_table = None
    if trace_location_type == TraceLocationType.MLFLOW_EXPERIMENT:
        mlflow_exp = MlflowExperimentLocation(experiment_id=experiment_id)
    elif trace_location_type == TraceLocationType.INFERENCE_TABLE:
        inf_table = InferenceTableLocation(full_table_name="cat.schema.table")

    loc = TraceLocation(
        type=trace_location_type,
        mlflow_experiment=mlflow_exp,
        inference_table=inf_table,
    )
    info = TraceInfo(
        trace_id=kwargs.pop("trace_id", "trace-1"),
        trace_location=loc,
        request_time=kwargs.pop("request_time", 1700000000000),
        state=kwargs.pop("state", TraceState.OK),
        execution_duration=kwargs.pop("execution_duration", 250),
        assessments=kwargs.pop("assessments", []),
        **kwargs,
    )
    data = TraceData(spans=kwargs.pop("spans", []), **kwargs.pop("data_kwargs", {}))
    tr = Trace(info=info, data=data)
    # Attach request/response for invoke tests
    tr.data.request = kwargs.pop("request_data", "req")
    tr.data.response = kwargs.pop("response_data", "resp")
    return tr


# ===========================================================================
# C1: _standardize returns uppercase for valid lower-case input
# ===========================================================================


def check_c1_standardize_case_insensitivity():
    """
    Contracts: C1

    _standardize must accept case-insensitive input and return uppercase.
    """
    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("Human") == "HUMAN"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("Llm_Judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("code") == "CODE"
    assert AssessmentSourceType._standardize("CODE") == "CODE"
    assert AssessmentSourceType._standardize("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType._standardize("SOURCE_TYPE_UNSPECIFIED") == "SOURCE_TYPE_UNSPECIFIED"
    print("PASS: C1 – _standardize case-insensitive normalization")


# ===========================================================================
# C2: _standardize emits FutureWarning for AI_JUDGE
# ===========================================================================


def check_c2_ai_judge_deprecation_warning():
    """
    Contracts: C2

    _standardize("AI_JUDGE") must emit FutureWarning and return "LLM_JUDGE".
    Case variations must also trigger the warning.
    """
    # Uppercase input
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = AssessmentSourceType._standardize("AI_JUDGE")
    assert result == "LLM_JUDGE"

    # Lowercase input should also trigger
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = AssessmentSourceType._standardize("ai_judge")
    assert result == "LLM_JUDGE"

    # Mixed case
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = AssessmentSourceType._standardize("Ai_Judge")
    assert result == "LLM_JUDGE"

    print("PASS: C2 – _standardize warns on AI_JUDGE and returns LLM_JUDGE")


# ===========================================================================
# C3: _standardize raises MlflowException for invalid type
# ===========================================================================


def check_c3_invalid_type_raises():
    """
    Contracts: C3

    _standardize must raise MlflowException with "Invalid assessment source type"
    for unrecognized values.
    """
    invalid_values = ["ROBOT", "UNKNOWN", "INVALID", "ai", "judge", ""]
    for val in invalid_values:
        with pytest.raises(MlflowException, match="Invalid assessment source type"):
            AssessmentSourceType._standardize(val)

    print("PASS: C3 – _standardize raises MlflowException for invalid types")


# ===========================================================================
# C11: _get_experiment_id raises for missing trace_location
# ===========================================================================


def check_c11_get_experiment_id_raises_no_location():
    """
    Contracts: C11

    _get_experiment_id raises MlflowException when trace has no
    trace_location (trace_location is None).
    """
    # Create trace with trace_location None via post-init override
    loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-1"),
    )
    info = TraceInfo(
        trace_id="t1",
        trace_location=loc,
        request_time=1000,
        state=TraceState.OK,
    )
    # Set trace_location to None to simulate missing location
    info.trace_location = None
    trace = Trace(info=info, data=TraceData())

    with pytest.raises(MlflowException):
        _get_experiment_id(trace)
    print("PASS: C11 – _get_experiment_id raises for missing trace_location")


# ===========================================================================
# C12: _get_experiment_id raises for non-MLFLOW_EXPERIMENT location
# ===========================================================================


def check_c12_get_experiment_id_raises_wrong_location_type():
    """
    Contracts: C12

    _get_experiment_id raises MlflowException when trace location type
    is not MLFLOW_EXPERIMENT (e.g. INFERENCE_TABLE).
    """
    trace = _make_trace(
        trace_location_type=TraceLocationType.INFERENCE_TABLE,
        experiment_id="",  # not used for inference table
    )
    with pytest.raises(MlflowException):
        _get_experiment_id(trace)
    print("PASS: C12 – _get_experiment_id raises for non-MLFLOW_EXPERIMENT location")


# ===========================================================================
# C13: _get_experiment_id raises for missing experiment_id
# ===========================================================================


def check_c13_get_experiment_id_raises_null_experiment_id():
    """
    Contracts: C13

    _get_experiment_id raises MlflowException when location is
    MLFLOW_EXPERIMENT but experiment_id is None or empty.
    """
    # Construct a TraceLocation with MLFLOW_EXPERIMENT type but None experiment_id
    loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id=None),
    )
    info = TraceInfo(
        trace_id="t1",
        trace_location=loc,
        request_time=1000,
        state=TraceState.OK,
    )
    trace = Trace(info=info, data=TraceData())

    with pytest.raises(MlflowException):
        _get_experiment_id(trace)

    # Also test with empty string
    loc2 = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id=""),
    )
    info2 = TraceInfo(
        trace_id="t2",
        trace_location=loc2,
        request_time=1000,
        state=TraceState.OK,
    )
    trace2 = Trace(info=info2, data=TraceData())

    with pytest.raises(MlflowException):
        _get_experiment_id(trace2)

    print("PASS: C13 – _get_experiment_id raises for missing/null experiment_id")


# ===========================================================================
# C17: SearchTracesTool.invoke defaults order_by to ["timestamp ASC"]
# ===========================================================================


def check_c17_invoke_default_order_by():
    """
    Contracts: C17

    When order_by=None, mlflow.search_traces must be called with
    order_by=["timestamp ASC"].
    """
    trace = _make_trace(experiment_id="exp-1")

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        SearchTracesTool().invoke(trace=trace, order_by=None)

    mock_search.assert_called_once()
    kw = mock_search.call_args[1]
    assert kw["order_by"] == ["timestamp ASC"], (
        f"Expected ['timestamp ASC'], got {kw.get('order_by')}"
    )
    print("PASS: C17 – invoke defaults order_by to ['timestamp ASC']")


# ===========================================================================
# C18: SearchTracesTool.invoke defaults max_results to 20
# ===========================================================================


def check_c18_invoke_default_max_results():
    """
    Contracts: C18

    When max_results not explicitly provided, mlflow.search_traces must
    be called with max_results=20.
    """
    trace = _make_trace(experiment_id="exp-1")

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        SearchTracesTool().invoke(trace=trace)

    mock_search.assert_called_once()
    kw = mock_search.call_args[1]
    assert kw["max_results"] == 20, (
        f"Expected max_results=20, got {kw.get('max_results')}"
    )
    print("PASS: C18 – invoke defaults max_results to 20")


# ===========================================================================
# C19: SearchTracesTool.invoke raises MlflowException for invalid trace
#      location (delegates to _get_experiment_id)
# ===========================================================================


def check_c19_invoke_raises_on_invalid_trace_location():
    """
    Contracts: C19

    invoke must raise MlflowException when trace has no experiment context.
    """
    # Trace with INFERENCE_TABLE location — not an MLflow experiment
    trace = _make_trace(
        trace_location_type=TraceLocationType.INFERENCE_TABLE,
        experiment_id="",
    )
    with pytest.raises(MlflowException):
        SearchTracesTool().invoke(trace=trace)

    # Trace with missing trace_location
    loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp-1"),
    )
    info = TraceInfo(
        trace_id="t1",
        trace_location=loc,
        request_time=1000,
        state=TraceState.OK,
    )
    info.trace_location = None
    bad_trace = Trace(info=info, data=TraceData())
    with pytest.raises(MlflowException):
        SearchTracesTool().invoke(trace=bad_trace)

    print("PASS: C19 – invoke raises MlflowException for invalid trace location")


# ===========================================================================
# R9 (E13): SearchTracesTool.invoke logs warning and skips failing traces
# ===========================================================================


def check_r9_invoke_skips_failing_traces_with_warning():
    """
    Contracts: R9 (no explicit L3 C contract; derived from E13)

    When an individual trace fails to process during retrieval, invoke
    must log a warning and skip that trace (continue with remaining).
    """
    from mlflow.entities.assessment import Expectation

    src = AssessmentSource(source_type="HUMAN")
    exp = Expectation(name="test", source=src, value=1)
    exp.assessment_id = "a-1"

    good_trace = _make_trace(
        experiment_id="exp-1",
        trace_id="good-trace",
        assessments=[exp],
    )

    # Create a trace that will fail during _convert_assessments_to_tool_types
    # by giving it a malformed assessment source
    bad_assessment = MagicMock()
    bad_assessment.name = "bad"
    # Make the source return something that breaks conversion
    bad_assessment.source = MagicMock()
    bad_assessment.source.source_type = "HUMAN"
    bad_assessment.rationale = None
    bad_assessment.span_id = None
    bad_assessment.assessment_id = None
    # Remove value to cause an AttributeError
    del bad_assessment.value

    bad_trace = _make_trace(
        experiment_id="exp-1",
        trace_id="bad-trace",
        assessments=[bad_assessment],
    )

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = [good_trace, bad_trace]

        with patch("mlflow.genai.judges.tools.search_traces._logger") as mock_logger:
            result = SearchTracesTool().invoke(trace=good_trace)

    # Only the good trace should appear
    assert len(result) == 1
    assert result[0].trace_id == "good-trace"

    # Warning should have been logged about the bad trace
    assert mock_logger.warning.call_count >= 1

    print("PASS: R9 – invoke skips failing traces and logs warning")


# ===========================================================================
# C17+C18 combined: invoke with explicit order_by and max_results passes them
# ===========================================================================


def check_invoke_passes_explicit_order_by_and_max_results():
    """
    Contracts: C17, C18 (boundary/override)

    When explicit order_by and max_results are provided, they must be
    forwarded to mlflow.search_traces.
    """
    trace = _make_trace(experiment_id="exp-1")

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        SearchTracesTool().invoke(
            trace=trace,
            order_by=["execution_time_ms DESC"],
            max_results=5,
        )

    mock_search.assert_called_once()
    kw = mock_search.call_args[1]
    assert kw["order_by"] == ["execution_time_ms DESC"]
    assert kw["max_results"] == 5
    print("PASS: invoke passes explicit order_by and max_results")


# ===========================================================================
# C16 boundary: filter_string is passed through to mlflow.search_traces
# ===========================================================================


def check_invoke_passes_filter_string():
    """
    Contracts: supports R15 (filter_string SQL-like syntax passthrough)

    Verify that filter_string is forwarded to mlflow.search_traces.
    """
    trace = _make_trace(experiment_id="exp-1")

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        SearchTracesTool().invoke(
            trace=trace,
            filter_string='status = "OK"',
        )

    mock_search.assert_called_once()
    kw = mock_search.call_args[1]
    assert kw["filter_string"] == 'status = "OK"'
    print("PASS: invoke passes filter_string through to search_traces")


# ===========================================================================
# C15 boundary: Feedback with error fields
# ===========================================================================


def check_convert_feedback_with_error():
    """
    Contracts: C15 (boundary)

    When Feedback has an AssessmentError, error_code, error_message,
    stack_trace must be populated in JudgeToolFeedback.
    """
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_error import AssessmentError

    src = AssessmentSource(source_type="LLM_JUDGE")
    fb = Feedback(
        name="quality",
        source=src,
        rationale="r",
        span_id="s1",
        value=None,
        error=AssessmentError(
            error_code="RATE_LIMIT",
            error_message="Rate limit exceeded",
            stack_trace="Traceback...",
        ),
        overrides="a-3",
        valid=False,
    )
    fb.assessment_id = "a-2"

    result = _convert_assessments_to_tool_types([fb])
    obj = result[0]
    assert isinstance(obj, JudgeToolFeedback)
    assert obj.error_code == "RATE_LIMIT"
    assert obj.error_message == "Rate limit exceeded"
    assert obj.stack_trace == "Traceback..."
    assert obj.overrides == "a-3"
    assert obj.valid is False
    assert obj.value is None

    print("PASS: C15 boundary – Feedback with error fields converted correctly")


# ===========================================================================
# C14+C15 boundary: mixed assessment list
# ===========================================================================


def check_convert_mixed_assessments():
    """
    Contracts: C14, C15 (combined)

    A list containing both Expectation and Feedback must convert all
    elements in the same order.
    """
    from mlflow.entities.assessment import Expectation, Feedback

    src_h = AssessmentSource(source_type="HUMAN")
    exp = Expectation(name="correctness", source=src_h, value=5)
    exp.assessment_id = "a-1"

    src_l = AssessmentSource(source_type="LLM_JUDGE")
    fb = Feedback(name="quality", source=src_l, value=0.95)
    fb.assessment_id = "a-2"

    result = _convert_assessments_to_tool_types([exp, fb])
    assert len(result) == 2
    assert isinstance(result[0], JudgeToolExpectation)
    assert isinstance(result[1], JudgeToolFeedback)
    assert result[0].name == "correctness"
    assert result[1].name == "quality"

    print("PASS: C14+C15 – mixed assessment list converts correctly")


# ===========================================================================
# Runner
# ===========================================================================

if __name__ == "__main__":
    check_c1_standardize_case_insensitivity()
    check_c2_ai_judge_deprecation_warning()
    check_c3_invalid_type_raises()
    check_c11_get_experiment_id_raises_no_location()
    check_c12_get_experiment_id_raises_wrong_location_type()
    check_c13_get_experiment_id_raises_null_experiment_id()
    check_c17_invoke_default_order_by()
    check_c18_invoke_default_max_results()
    check_c19_invoke_raises_on_invalid_trace_location()
    check_r9_invoke_skips_failing_traces_with_warning()
    check_invoke_passes_explicit_order_by_and_max_results()
    check_invoke_passes_filter_string()
    check_convert_feedback_with_error()
    check_convert_mixed_assessments()
    sys.exit(0)
