"""
Architecture spec for SearchTracesTool, AssessmentSourceType, and related
connective contracts.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check_* function maps to one or more contract IDs.
"""
import sys
import warnings
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Core imports under test
# ---------------------------------------------------------------------------
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.entities.trace import Trace, TraceData
from mlflow.entities.trace_info import TraceInfo
from mlflow.entities.trace_location import (
    MlflowExperimentLocation,
    TraceLocation,
    TraceLocationType,
)
from mlflow.entities.trace_state import TraceState
from mlflow.genai.judges.tools.constants import ToolNames
from mlflow.genai.judges.tools.search_traces import (
    SearchTracesTool,
    _convert_assessments_to_tool_types,
    _get_experiment_id,
)
from mlflow.genai.judges.tools.types import (
    JudgeToolExpectation,
    JudgeToolFeedback,
    JudgeToolTraceInfo,
)
from mlflow.types.llm import ToolDefinition


# ===========================================================================
# Helpers
# ===========================================================================


def _make_trace(experiment_id="exp-123", **kwargs):
    """Build a Trace with MLFLOW_EXPERIMENT location."""
    loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id=experiment_id),
    )
    info = TraceInfo(
        trace_id=kwargs.pop("trace_id", "trace-1"),
        trace_location=loc,
        request_time=kwargs.pop("request_time", 1700000000000),
        state=kwargs.pop("state", TraceState.OK),
        execution_duration=kwargs.pop("execution_duration", 250),
        assessments=kwargs.pop("assessments", []),
        **kwargs,
    )
    data = TraceData(spans=kwargs.pop("spans", []), **kwargs.pop("data_kwargs", {}))
    return Trace(info=info, data=data)


# ===========================================================================
# C4: AssessmentSource.__post_init__ -> AssessmentSourceType._standardize
# ===========================================================================


def check_c4_assessment_source_post_init_delegates_to_standardize():
    """
    Contracts: C4

    Verifies that AssessmentSource.__post_init__ normalizes source_type
    via _standardize.  AI_JUDGE → LLM_JUDGE, case-insensitive input → uppercase.
    """
    # C4: AI_JUDGE deprecation through __post_init__
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        src = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")
    assert src.source_type == "LLM_JUDGE", (
        f"Expected LLM_JUDGE, got {src.source_type}"
    )
    assert src.source_id == "ai_1"
    assert len(w) == 1
    assert issubclass(w[0].category, FutureWarning)

    # C4: case-insensitive normalization through __post_init__
    src2 = AssessmentSource(source_type="human", source_id="u1")
    assert src2.source_type == "HUMAN"

    print("PASS: C4 – AssessmentSource.__post_init__ delegates to _standardize")


# ===========================================================================
# C5: SearchTracesTool.name
# ===========================================================================


def check_c5_name():
    """Contracts: C5"""
    tool = SearchTracesTool()
    assert tool.name == "_search_traces", f"Expected _search_traces, got {tool.name}"
    assert tool.name == ToolNames._SEARCH_TRACES
    print("PASS: C5 – SearchTracesTool.name == _search_traces")


# ===========================================================================
# C6, C7, C8, C9: get_definition structure
# ===========================================================================


def check_c6_c7_c8_c9_get_definition():
    """
    Contracts: C6, C7, C8, C9

    Verifies ToolDefinition shape returned by get_definition.
    """
    definition = SearchTracesTool().get_definition()

    # C6
    assert isinstance(definition, ToolDefinition), type(definition)
    assert definition.type == "function"
    fn = definition.function
    assert fn.name == "_search_traces"
    assert fn.name == ToolNames._SEARCH_TRACES
    assert fn.description and len(fn.description) > 0, "description must be non-empty"
    params = fn.parameters
    assert params.type == "object"
    assert params.required == [] or params.required is None, (
        f"required must be empty, got {params.required}"
    )

    props = params.properties
    assert "filter_string" in props, props.keys()
    assert "order_by" in props, props.keys()
    assert "max_results" in props, props.keys()

    # C7: filter_string type
    fs = props["filter_string"]
    assert fs.type == "string", f"filter_string type: {fs.type}"
    assert fs.description and len(fs.description) > 0

    # C8: order_by type
    ob = props["order_by"]
    assert ob.type == "array", f"order_by type: {ob.type}"
    assert ob.items.type == "string", f"order_by items type: {ob.items.type}"

    # C9: max_results type
    mr = props["max_results"]
    assert mr.type == "integer", f"max_results type: {mr.type}"
    assert mr.description and len(mr.description) > 0

    print("PASS: C6,C7,C8,C9 – get_definition returns valid ToolDefinition")


# ===========================================================================
# C10: _get_experiment_id returns experiment_id
# ===========================================================================


def check_c10_get_experiment_id_returns_experiment_id():
    """Contracts: C10"""
    trace = _make_trace(experiment_id="exp-abc")
    result = _get_experiment_id(trace)
    assert result == "exp-abc", f"Expected exp-abc, got {result}"
    print("PASS: C10 – _get_experiment_id returns experiment_id")


# ===========================================================================
# C14: _convert_assessments_to_tool_types – Expectation
# ===========================================================================


def check_c14_convert_expectation():
    """Contracts: C14"""
    from mlflow.entities.assessment import Expectation

    src = AssessmentSource(source_type="HUMAN")
    exp = Expectation(
        name="correctness",
        source=src,
        rationale="test rationale",
        span_id="span1",
        value=5,
    )
    exp.assessment_id = "a-1"

    result = _convert_assessments_to_tool_types([exp])
    assert len(result) == 1
    obj = result[0]
    assert isinstance(obj, JudgeToolExpectation)
    assert obj.name == "correctness"
    assert obj.source == "HUMAN"
    assert obj.rationale == "test rationale"
    assert obj.span_id == "span1"
    assert obj.assessment_id == "a-1"
    assert obj.value == 5

    print("PASS: C14 – Expectation → JudgeToolExpectation")


# ===========================================================================
# C15: _convert_assessments_to_tool_types – Feedback
# ===========================================================================


def check_c15_convert_feedback():
    """Contracts: C15"""
    from mlflow.entities.assessment import Feedback

    src = AssessmentSource(source_type="LLM_JUDGE")
    fb = Feedback(
        name="quality",
        source=src,
        rationale="r",
        span_id="s1",
        value=0.9,
        error=None,
        overrides=None,
        valid=True,
    )
    fb.assessment_id = "a-2"

    result = _convert_assessments_to_tool_types([fb])
    assert len(result) == 1
    obj = result[0]
    assert isinstance(obj, JudgeToolFeedback)
    assert obj.name == "quality"
    assert obj.source == "LLM_JUDGE"
    assert obj.rationale == "r"
    assert obj.span_id == "s1"
    assert obj.assessment_id == "a-2"
    assert obj.value == 0.9
    assert obj.error_code is None
    assert obj.error_message is None
    assert obj.stack_trace is None
    assert obj.overrides is None
    assert obj.valid is True

    print("PASS: C15 – Feedback → JudgeToolFeedback")


# ===========================================================================
# C16, C20: invoke returns list[JudgeToolTraceInfo] with converted assessment types
# ===========================================================================


def check_c16_c20_invoke_returns_judge_tool_trace_info():
    """
    Contracts: C16, C20

    Mock mlflow.search_traces to return a minimal Trace list and verify
    the invoke return shape and assessment types.
    """
    from mlflow.entities.assessment import Expectation

    src = AssessmentSource(source_type="HUMAN")
    exp = Expectation(name="correctness", source=src, value=5)
    exp.assessment_id = "a-1"

    trace = _make_trace(
        experiment_id="exp-1",
        trace_id="t1",
        request_time=1000,
        state=TraceState.OK,
        execution_duration=100,
        assessments=[exp],
    )
    # Patch data.request / data.response
    trace.data.request = '{"q": "hello"}'
    trace.data.response = '{"a": "hi"}'

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = [trace]
        result = SearchTracesTool().invoke(trace=trace)

    # C16
    assert isinstance(result, list), type(result)
    assert len(result) == 1
    ti = result[0]
    assert isinstance(ti, JudgeToolTraceInfo), type(ti)
    assert ti.trace_id == "t1"
    assert ti.request_time == 1000
    assert ti.state == TraceState.OK
    assert ti.request == '{"q": "hello"}'
    assert ti.response == '{"a": "hi"}'
    assert ti.execution_duration == 100

    # C20
    assert len(ti.assessments) == 1
    a = ti.assessments[0]
    assert isinstance(a, (JudgeToolExpectation, JudgeToolFeedback)), type(a)
    assert isinstance(a, JudgeToolExpectation)

    print("PASS: C16,C20 – invoke returns list[JudgeToolTraceInfo] with converted assessments")


# ===========================================================================
# Additional dataflow: verify invoke calls mlflow.search_traces with
# correct arguments (E9 connectivity)
# ===========================================================================


def check_invoke_calls_search_traces_with_experiment_id():
    """
    Contracts: (supports C10, C16, C17, C18 connectivity)

    Verify that invoke extracts experiment_id and passes it through to
    mlflow.search_traces.
    """
    trace = _make_trace(experiment_id="exp-xyz")
    trace.data.request = "req"
    trace.data.response = "resp"

    with patch("mlflow.genai.judges.tools.search_traces.mlflow.search_traces") as mock_search:
        mock_search.return_value = []
        SearchTracesTool().invoke(trace=trace)

    mock_search.assert_called_once()
    call_kwargs = mock_search.call_args[1]
    assert call_kwargs["experiment_ids"] == ["exp-xyz"], (
        f"experiment_ids: {call_kwargs.get('experiment_ids')}"
    )
    print("PASS: invoke → mlflow.search_traces with experiment_ids=['exp-xyz']")


# ===========================================================================
# Runner
# ===========================================================================

if __name__ == "__main__":
    check_c4_assessment_source_post_init_delegates_to_standardize()
    check_c5_name()
    check_c6_c7_c8_c9_get_definition()
    check_c10_get_experiment_id_returns_experiment_id()
    check_c14_convert_expectation()
    check_c15_convert_feedback()
    check_c16_c20_invoke_returns_judge_tool_trace_info()
    check_invoke_calls_search_traces_with_experiment_id()
    sys.exit(0)
