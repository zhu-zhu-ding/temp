"""
Executable architecture spec for MLflow GenAI scorer validation system.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check function validates connectivity from a public entry point
to the documented observer, preserving contract IDs in comments.

Contracts covered:
  C1  - scorer(func) returns CustomScorer instance (Interface)
  C4  - CustomScorer.__call__ signature matches original function (Interface)
  C11 - valid_data_for_builtin_scorers remaps request->inputs, response->outputs (Dataflow)
  C12 - valid_data_for_builtin_scorers treats outputs as available when predict_fn provided (Dataflow)
  C13 - valid_data_for_builtin_scorers infers inputs/outputs from trace column (Dataflow)
  C18 - get_all_scorers items are all Scorer instances (Interface)
  C19 - get_all_scorers includes OSS scorer classes (Interface)
  C21 - evaluation/base.py imports from validation module (Interface)
"""

import importlib
import inspect
import logging
import io

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _reset_tracking_uri():
    """Reset MLflow tracking URI to a clean file-based URI."""
    import mlflow
    mlflow.set_tracking_uri("file:///tmp/mlflow-test-arch-spec")


def _capture_logs(logger_name, level=logging.INFO):
    """Context manager that captures log records from a named logger."""
    logger = logging.getLogger(logger_name)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(level)
    old_handlers = logger.handlers[:]
    logger.handlers.clear()
    logger.addHandler(handler)
    old_level = logger.level
    logger.setLevel(level)
    try:
        yield stream
    finally:
        logger.handlers.clear()
        for h in old_handlers:
            logger.addHandler(h)
        logger.setLevel(old_level)


# ---------------------------------------------------------------------------
# C1: scorer(func) returns CustomScorer instance (Interface)
# ---------------------------------------------------------------------------

def check_c1_scorer_returns_custom_scorer():
    """Contracts: C1
    L2 path: N1(scorer) -> E1(CONTROL) -> N2(CustomScorer) -> E16(DATA) -> N3(Scorer)
    """
    from mlflow.genai.scorers.base import Scorer, scorer as scorer_decorator

    def my_func(outputs):
        return True

    s = scorer_decorator(my_func)
    assert isinstance(s, Scorer), "C1: scorer(func) must return a Scorer instance"

    # Verify it is a CustomScorer (dynamically created subclass of Scorer)
    assert type(s).__name__ == "CustomScorer", (
        f"C1: expected class name 'CustomScorer', got '{type(s).__name__}'"
    )
    assert issubclass(type(s), Scorer), "C1: CustomScorer must be a subclass of Scorer"

    # Verify the kind attribute marks it as DECORATOR
    assert s.kind.value == "decorator", (
        f"C1: expected kind 'decorator', got '{s.kind.value}'"
    )

    print("PASS: C1 - scorer(func) returns a CustomScorer instance (subclass of Scorer)")


# ---------------------------------------------------------------------------
# C4: CustomScorer.__call__ signature matches original function (Interface)
# ---------------------------------------------------------------------------

def check_c4_custom_scorer_signature():
    """Contracts: C4
    L2 path: N2(CustomScorer) -> E3(CALL) -> original func
    """
    from mlflow.genai.scorers.base import scorer as scorer_decorator

    def example_func(outputs, expectations):
        return outputs == expectations.get("expected_response")

    s = scorer_decorator(example_func)

    sig = inspect.signature(s.__call__)
    param_names = list(sig.parameters.keys())

    # First parameter must be 'self'
    assert param_names[0] == "self", (
        f"C4: first parameter must be 'self', got '{param_names[0]}'"
    )

    # Remaining parameters must match original function
    assert param_names[1:] == ["outputs", "expectations"], (
        f"C4: signature params (after self) must match original, "
        f"got {param_names[1:]} instead of ['outputs', 'expectations']"
    )

    # Verify calling works through the signature
    result = s(outputs="hello", expectations={"expected_response": "hello"})
    assert result is True, "C4: call through __call__ must invoke original function"

    print("PASS: C4 - CustomScorer.__call__ signature matches original function params")


# ---------------------------------------------------------------------------
# C11: valid_data_for_builtin_scorers remaps request->inputs, response->outputs
# ---------------------------------------------------------------------------

def check_c11_column_remapping():
    """Contracts: C11
    L2 path: N7(valid_data_for_builtin_scorers) -> E13(DATA) -> DataFrame columns
    Observer: log inspection after calling with request/response columns
    """
    import pandas as pd

    _reset_tracking_uri()

    # Import the validation function and a builtin scorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import RelevanceToQuery

    # RelevanceToQuery requires inputs and trace columns.
    # If only "request" is present (no "inputs"), the remapping should treat
    # "request" as "inputs" and validation should not fail due to missing "inputs".
    data = pd.DataFrame({
        "request": ["what is mlflow?"],
        "response": ["mlflow is a platform"],
    })

    # Capture log output to verify remapping behavior
    with _capture_logs("mlflow.genai.scorers.validation") as log_stream:
        valid_data_for_builtin_scorers(data, [RelevanceToQuery()])

    log_output = log_stream.getvalue()
    # After remapping, "request" becomes "inputs", and "response" becomes "outputs".
    # RelevanceToQuery requires {"inputs", "trace"}.
    # With remapping, "inputs" is satisfied by "request" -> "inputs".
    # "trace" is still missing, so we expect a log about missing "trace".
    # The key point: there should be NO log about missing "inputs" because
    # "request" was remapped.
    assert "missing following columns" in log_output or log_output == "", (
        f"C11: expected log about missing columns (or empty), got: {log_output!r}"
    )
    # If there is a log, "inputs" should NOT be listed as missing
    if "missing following columns" in log_output:
        assert "`inputs`" not in log_output.split("missing following columns")[1] if len(log_output.split("missing following columns")) > 1 else True, (
            f"C11: 'inputs' should not appear as missing after request->inputs remap. Log: {log_output}"
        )

    print("PASS: C11 - valid_data_for_builtin_scorers remaps request->inputs, response->outputs")


# ---------------------------------------------------------------------------
# C12: valid_data_for_builtin_scorers treats outputs available with predict_fn
# ---------------------------------------------------------------------------

def check_c12_predict_fn_makes_outputs_available():
    """Contracts: C12
    L2 path: N7(valid_data_for_builtin_scorers) -> E13(DATA) -> predict_fn check
    Observer: no log about missing outputs column when predict_fn provided
    """
    import pandas as pd

    _reset_tracking_uri()

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    # Correctness requires inputs, outputs.
    # Data has inputs but NOT outputs. With predict_fn, outputs should be
    # considered available.
    data = pd.DataFrame({
        "inputs": [{"question": "what is mlflow?"}],
    })

    def dummy_predict_fn(x):
        return "dummy output"

    with _capture_logs("mlflow.genai.scorers.validation") as log_stream:
        valid_data_for_builtin_scorers(data, [Correctness()], predict_fn=dummy_predict_fn)

    log_output = log_stream.getvalue()
    # Should NOT log about missing "outputs" column because predict_fn is provided
    if "missing following columns" in log_output:
        # If anything is missing, it should not be "outputs"
        # Split after the header to check column listings
        parts = log_output.split("missing following columns")
        if len(parts) > 1:
            body = parts[1]
            assert "`outputs`" not in body, (
                f"C12: 'outputs' should NOT appear as missing when predict_fn provided. Log: {log_output}"
            )

    print("PASS: C12 - valid_data_for_builtin_scorers treats outputs as available with predict_fn")


# ---------------------------------------------------------------------------
# C13: valid_data_for_builtin_scorers infers inputs/outputs from trace column
# ---------------------------------------------------------------------------

def check_c13_trace_infers_inputs_outputs():
    """Contracts: C13
    L2 path: N7(valid_data_for_builtin_scorers) -> E13(DATA) -> trace check
    Observer: no log about missing inputs/outputs when trace column present
    """
    import pandas as pd

    _reset_tracking_uri()

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    # Correctness requires inputs, outputs.
    # Data has only "trace". Both inputs and outputs should be inferred.
    data = pd.DataFrame({
        "trace": ["dummy_trace_object"],
    })

    with _capture_logs("mlflow.genai.scorers.validation") as log_stream:
        valid_data_for_builtin_scorers(data, [Correctness()])

    log_output = log_stream.getvalue()
    # Should NOT log about missing "inputs" or "outputs" because trace implies both
    if "missing following columns" in log_output:
        parts = log_output.split("missing following columns")
        if len(parts) > 1:
            body = parts[1]
            assert "`inputs`" not in body, (
                f"C13: 'inputs' should NOT appear as missing when trace present. Log: {log_output}"
            )
            assert "`outputs`" not in body, (
                f"C13: 'outputs' should NOT appear as missing when trace present. Log: {log_output}"
            )

    print("PASS: C13 - valid_data_for_builtin_scorers infers inputs/outputs from trace column")


# ---------------------------------------------------------------------------
# C18: get_all_scorers items are all Scorer instances (Interface)
# ---------------------------------------------------------------------------

def check_c18_get_all_scorers_are_scorer_instances():
    """Contracts: C18
    L2 path: N8(get_all_scorers) -> E12(CALL) -> N16 -> N15(BuiltInScorer) -> N3(Scorer)
    """
    _reset_tracking_uri()

    from mlflow.genai.scorers.base import Scorer
    # get_all_scorers is lazily imported via __getattr__
    from mlflow.genai.scorers import get_all_scorers

    scorers = get_all_scorers()
    assert len(scorers) > 0, "C18: get_all_scorers() must return non-empty list"

    for s in scorers:
        assert isinstance(s, Scorer), (
            f"C18: all items must be Scorer instances, got {type(s).__name__}"
        )

    print("PASS: C18 - get_all_scorers items are all Scorer instances")


# ---------------------------------------------------------------------------
# C19: get_all_scorers includes OSS scorer classes (Interface)
# ---------------------------------------------------------------------------

def check_c19_get_all_scorers_oss_composition():
    """Contracts: C19
    L2 path: N8(get_all_scorers) -> E12(CALL) -> N16 builtin classes
    """
    _reset_tracking_uri()

    from mlflow.genai.scorers import get_all_scorers

    scorers = get_all_scorers()

    type_names = [type(s).__name__ for s in scorers]

    expected_oss = [
        "ExpectationsGuidelines",
        "Correctness",
        "RelevanceToQuery",
        "RetrievalSufficiency",
        "RetrievalGroundedness",
        "Equivalence",
    ]

    # All expected OSS scorers must be present in order
    for expected in expected_oss:
        assert expected in type_names, (
            f"C19: expected {expected} in get_all_scorers(), got {type_names}"
        )

    # Verify order: expected_oss should appear as a subsequence in order
    idx = 0
    for name in type_names:
        if idx < len(expected_oss) and name == expected_oss[idx]:
            idx += 1
    assert idx == len(expected_oss), (
        f"C19: OSS scorers must appear in order {expected_oss}, got {type_names}"
    )

    print("PASS: C19 - get_all_scorers includes OSS scorers in expected order")


# ---------------------------------------------------------------------------
# C21: evaluation/base.py imports from validation module (Interface)
# ---------------------------------------------------------------------------

def check_c21_evaluation_imports_validation():
    """Contracts: C21
    L2 path: N11(evaluate) -> E5(CALL) -> N6(validate_scorers),
             N11(evaluate) -> E6(CALL) -> N7(valid_data_for_builtin_scorers)
    Observer: static analysis of import statements in evaluation/base.py
    """
    import ast

    eval_base_path = "/testbed/mlflow/genai/evaluation/base.py"
    with open(eval_base_path) as f:
        tree = ast.parse(f.read(), filename=eval_base_path)

    # Gather all imports from mlflow.genai.scorers.validation
    found_validate_scorers = False
    found_valid_data = False

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.module == "mlflow.genai.scorers.validation":
                for alias in node.names:
                    if alias.name == "validate_scorers":
                        found_validate_scorers = True
                    if alias.name == "valid_data_for_builtin_scorers":
                        found_valid_data = True

    # If not found at top level, also check for any import that makes these names available
    # (e.g., they could be imported inside a function body)
    if not found_validate_scorers or not found_valid_data:
        # Check function-body imports
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                if isinstance(node, ast.ImportFrom):
                    if node.module == "mlflow.genai.scorers.validation":
                        for alias in node.names:
                            if alias.name == "validate_scorers":
                                found_validate_scorers = True
                            if alias.name == "valid_data_for_builtin_scorers":
                                found_valid_data = True

    assert found_validate_scorers, (
        "C21: evaluation/base.py must import validate_scorers from "
        "mlflow.genai.scorers.validation"
    )
    assert found_valid_data, (
        "C21: evaluation/base.py must import valid_data_for_builtin_scorers from "
        "mlflow.genai.scorers.validation"
    )

    # Additionally verify the call sites exist at lines 243 and 248
    source = open(eval_base_path).read()
    assert "validate_scorers(scorers)" in source, (
        "C21: evaluation/base.py must call validate_scorers(scorers)"
    )
    assert "valid_data_for_builtin_scorers(df, builtin_scorers" in source, (
        "C21: evaluation/base.py must call valid_data_for_builtin_scorers(df, builtin_scorers, ...)"
    )

    print("PASS: C21 - evaluation/base.py imports from validation module and calls both functions")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    check_c1_scorer_returns_custom_scorer()
    check_c4_custom_scorer_signature()
    check_c11_column_remapping()
    check_c12_predict_fn_makes_outputs_available()
    check_c13_trace_infers_inputs_outputs()
    check_c18_get_all_scorers_are_scorer_instances()
    check_c19_get_all_scorers_oss_composition()
    check_c21_evaluation_imports_validation()
    print("\nAll architecture spec checks passed.")
