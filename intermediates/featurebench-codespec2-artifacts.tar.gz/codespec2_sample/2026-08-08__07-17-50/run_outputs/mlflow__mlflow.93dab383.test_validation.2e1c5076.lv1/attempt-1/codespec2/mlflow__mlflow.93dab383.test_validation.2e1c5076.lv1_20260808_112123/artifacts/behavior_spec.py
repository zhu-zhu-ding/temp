"""
Executable behavior spec for MLflow GenAI scorer validation system.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility contracts. Each check function validates runtime
outcomes from a public entry point, preserving contract IDs in comments.

Contracts covered:
  C2  - CustomScorer.name equals function name by default (State)
  C3  - scorer(name="X")(func).name equals "X" (State)
  C5  - CustomScorer._original_func stores the decorated function (State)
  C6  - validate_scorers accepts list of Scorer instances (Behavior)
  C7  - validate_scorers raises on non-list input (Failure)
  C8  - validate_scorers raises with hint for nested get_all_scorers() (Failure)
  C9  - validate_scorers raises with hint for class instead of instance (Failure)
  C10 - validate_scorers returns empty list for empty input (Behavior)
  C14 - valid_data_for_builtin_scorers raises on non-dict expectations (Failure)
  C15 - valid_data_for_builtin_scorers logs missing columns info (SideEffect)
  C16 - get_all_scorers returns 6 scorers for OSS tracking URI (Behavior)
  C17 - get_all_scorers returns 8 scorers for Databricks tracking URI (Behavior)
  C20 - get_all_scorers conditionally includes Safety and RetrievalRelevance (Behavior)
"""

import io
import logging

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _reset_tracking_uri(uri="file:///tmp/mlflow-test-behavior-spec"):
    """Reset MLflow tracking URI."""
    import mlflow
    mlflow.set_tracking_uri(uri)


def _capture_logs(logger_name, level=logging.INFO):
    """Context manager that captures log records from a named logger."""
    logger = logging.getLogger(logger_name)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(level)
    old_handlers = logger.handlers[:]
    old_level = logger.level
    logger.handlers.clear()
    logger.addHandler(handler)
    logger.setLevel(level)
    try:
        yield stream
    finally:
        logger.handlers.clear()
        for h in old_handlers:
            logger.addHandler(h)
        logger.setLevel(old_level)


# ---------------------------------------------------------------------------
# C2: CustomScorer.name equals function name by default (State)
# ---------------------------------------------------------------------------

def check_c2_default_name_is_function_name():
    """Contracts: C2
    L2 path: N1(scorer) -> E1(CONTROL) -> N2(CustomScorer) -> name field
    """
    from mlflow.genai.scorers.base import scorer as scorer_decorator

    def my_custom_eval(outputs):
        return bool(outputs)

    s = scorer_decorator(my_custom_eval)
    assert s.name == "my_custom_eval", (
        f"C2: expected name 'my_custom_eval', got '{s.name}'"
    )

    # Also test with lambda (name will be '<lambda>')
    s2 = scorer_decorator(lambda outputs: True)
    assert s2.name == "<lambda>", (
        f"C2: lambda name should be '<lambda>', got '{s2.name}'"
    )

    print("PASS: C2 - CustomScorer.name defaults to func.__name__")


# ---------------------------------------------------------------------------
# C3: scorer(name="X")(func).name equals "X" (State)
# ---------------------------------------------------------------------------

def check_c3_parameterized_name():
    """Contracts: C3
    L2 path: N1(scorer) -> E2(CONTROL) -> functools.partial -> E1 -> N2(CustomScorer)
    """
    from mlflow.genai.scorers.base import scorer as scorer_decorator

    # Parameterized usage: scorer(name="custom")(func)
    parameterized = scorer_decorator(name="my_custom_name")
    assert callable(parameterized), "C3: scorer(name=...) must return a callable partial"

    s = parameterized(lambda outputs: True)
    assert s.name == "my_custom_name", (
        f"C3: expected name 'my_custom_name', got '{s.name}'"
    )

    # Verify description also works
    s2 = scorer_decorator(name="described", description="A test scorer")(
        lambda outputs: False
    )
    assert s2.name == "described", f"C3: expected name 'described', got '{s2.name}'"
    assert s2.description == "A test scorer", (
        f"C3: expected description to be preserved, got '{s2.description}'"
    )

    print("PASS: C3 - scorer(name='X')(func).name equals 'X'")


# ---------------------------------------------------------------------------
# C5: CustomScorer._original_func stores the decorated function (State)
# ---------------------------------------------------------------------------

def check_c5_original_func_stored():
    """Contracts: C5
    L2 path: N2(CustomScorer) -> E1(CONTROL) -> _original_func PrivateAttr
    """
    from mlflow.genai.scorers.base import scorer as scorer_decorator

    def original(outputs, expectations, trace):
        return {"score": 1.0}

    s = scorer_decorator(original)
    assert hasattr(s, "_original_func"), "C5: CustomScorer must have _original_func"
    assert s._original_func is original, (
        "C5: _original_func must be the same object as the decorated function"
    )

    # Verify model_dump includes serialization fields from _original_func
    dump = s.model_dump()
    assert "call_source" in dump, "C5: model_dump must contain 'call_source'"
    assert "call_signature" in dump, "C5: model_dump must contain 'call_signature'"
    assert "original_func_name" in dump, "C5: model_dump must contain 'original_func_name'"
    assert dump["original_func_name"] == "original", (
        f"C5: original_func_name must be 'original', got '{dump['original_func_name']}'"
    )

    print("PASS: C5 - CustomScorer._original_func stores the decorated function")


# ---------------------------------------------------------------------------
# C6: validate_scorers accepts list of Scorer instances (Behavior)
# ---------------------------------------------------------------------------

def check_c6_validate_scorers_accepts_scorer_list():
    """Contracts: C6
    L2 path: N11(evaluate) -> E5(CALL) -> N6(validate_scorers) -> E5 returns list
    """
    _reset_tracking_uri()

    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness, RelevanceToQuery
    from mlflow.genai.scorers.base import Scorer

    scorer1 = Correctness()
    scorer2 = RelevanceToQuery()
    input_list = [scorer1, scorer2]

    result = validate_scorers(input_list)

    # Must return the same list (preserve identity)
    assert result == input_list, "C6: validate_scorers must return the same list"
    assert len(result) == 2, f"C6: expected 2 scorers, got {len(result)}"

    # Each item must be a Scorer
    for s in result:
        assert isinstance(s, Scorer), f"C6: all items must be Scorer instances"

    print("PASS: C6 - validate_scorers accepts and returns list of Scorer instances")


# ---------------------------------------------------------------------------
# C7: validate_scorers raises on non-list input (Failure)
# ---------------------------------------------------------------------------

def check_c7_validate_scorers_raises_on_non_list():
    """Contracts: C7
    L2 path: N6(validate_scorers) -> E8(CONTROL) -> N12(MlflowException)
    """
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.exceptions import MlflowException

    with pytest.raises(MlflowException, match="must be a list"):
        validate_scorers("not_a_list")

    with pytest.raises(MlflowException, match="must be a list"):
        validate_scorers(42)

    with pytest.raises(MlflowException, match="must be a list"):
        validate_scorers(None)

    print("PASS: C7 - validate_scorers raises MlflowException on non-list input")


# ---------------------------------------------------------------------------
# C8: validate_scorers raises with hint for nested get_all_scorers() (Failure)
# ---------------------------------------------------------------------------

def check_c8_validate_scorers_raises_on_nested_get_all_scorers():
    """Contracts: C8
    L2 path: N6(validate_scorers) -> E7(CALL) -> N8(get_all_scorers) -> E8(CONTROL) -> N12
    """
    _reset_tracking_uri()

    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers import get_all_scorers
    from mlflow.exceptions import MlflowException

    # Passing [get_all_scorers()] nests the result list inside another list
    with pytest.raises(MlflowException, match="get_all_scorers"):
        validate_scorers([get_all_scorers()])

    print("PASS: C8 - validate_scorers raises with hint for nested get_all_scorers()")


# ---------------------------------------------------------------------------
# C9: validate_scorers raises with hint for class instead of instance (Failure)
# ---------------------------------------------------------------------------

def check_c9_validate_scorers_raises_on_class_not_instance():
    """Contracts: C9
    L2 path: N6(validate_scorers) -> E8(CONTROL) -> N12(MlflowException)
    """
    _reset_tracking_uri()

    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness
    from mlflow.exceptions import MlflowException

    # Passing the class Correctness instead of Correctness()
    with pytest.raises(MlflowException, match="class instead of an instance"):
        validate_scorers([Correctness])

    print("PASS: C9 - validate_scorers raises with hint for class instead of instance")


# ---------------------------------------------------------------------------
# C10: validate_scorers returns empty list for empty input (Behavior)
# ---------------------------------------------------------------------------

def check_c10_validate_scorers_empty_list():
    """Contracts: C10
    L2 path: N6(validate_scorers) early return
    """
    from mlflow.genai.scorers.validation import validate_scorers

    result = validate_scorers([])
    assert result == [], f"C10: expected empty list, got {result}"
    assert isinstance(result, list), "C10: result must be a list"

    print("PASS: C10 - validate_scorers returns empty list for empty input")


# ---------------------------------------------------------------------------
# C14: valid_data_for_builtin_scorers raises on non-dict expectations (Failure)
# ---------------------------------------------------------------------------

def check_c14_raises_on_non_dict_expectations():
    """Contracts: C14
    L2 path: N7(valid_data_for_builtin_scorers) -> E11(CONTROL) -> N12(MlflowException)
    """
    import pandas as pd

    _reset_tracking_uri()

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness
    from mlflow.exceptions import MlflowException

    # expectations column with a non-dict, non-NaN value
    data = pd.DataFrame({
        "inputs": [{"question": "test"}],
        "outputs": ["answer"],
        "expectations": ["not_a_dict"],
    })

    with pytest.raises(MlflowException, match="must be a dictionary"):
        valid_data_for_builtin_scorers(data, [Correctness()])

    print("PASS: C14 - valid_data_for_builtin_scorers raises on non-dict expectations")


# ---------------------------------------------------------------------------
# C15: valid_data_for_builtin_scorers logs missing columns info (SideEffect)
# ---------------------------------------------------------------------------

def check_c15_logs_missing_columns():
    """Contracts: C15
    L2 path: N7(valid_data_for_builtin_scorers) -> E9(CALL) -> N9(validate_columns)
             -> E10(CONTROL) -> N10(MissingColumnsException) -> N14(_logger)
    """
    import pandas as pd

    _reset_tracking_uri()

    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    # Correctness requires inputs, outputs.
    # Data has only inputs — outputs is missing.
    data = pd.DataFrame({
        "inputs": [{"question": "test"}],
    })

    with _capture_logs("mlflow.genai.scorers.validation") as log_stream:
        valid_data_for_builtin_scorers(data, [Correctness()])

    log_output = log_stream.getvalue()
    assert "missing following columns" in log_output, (
        f"C15: expected log about missing columns, got: {log_output!r}"
    )
    assert "correctness" in log_output.lower(), (
        f"C15: expected log to mention scorer name 'correctness', got: {log_output!r}"
    )
    assert "outputs" in log_output, (
        f"C15: expected log to mention missing column 'outputs', got: {log_output!r}"
    )

    print("PASS: C15 - valid_data_for_builtin_scorers logs INFO about missing columns")


# ---------------------------------------------------------------------------
# C16: get_all_scorers returns 6 scorers for OSS tracking URI (Behavior)
# ---------------------------------------------------------------------------

def check_c16_get_all_scorers_oss_count():
    """Contracts: C16
    L2 path: N8(get_all_scorers) -> E14(CALL) -> is_databricks_uri -> E12(CALL) -> N16
    """
    _reset_tracking_uri("file:///tmp/mlflow-test-oss")

    from mlflow.genai.scorers import get_all_scorers

    scorers = get_all_scorers()
    assert len(scorers) == 6, (
        f"C16: expected 6 scorers for OSS tracking URI, got {len(scorers)}"
    )

    print("PASS: C16 - get_all_scorers returns 6 scorers for OSS tracking URI")


# ---------------------------------------------------------------------------
# C17: get_all_scorers returns 8 scorers for Databricks tracking URI (Behavior)
# ---------------------------------------------------------------------------

def check_c17_get_all_scorers_databricks_count():
    """Contracts: C17
    L2 path: N8(get_all_scorers) -> E14(CALL) -> is_databricks_uri -> E12(CALL) -> N16
    """
    _reset_tracking_uri("databricks")

    from mlflow.genai.scorers import get_all_scorers

    scorers = get_all_scorers()
    assert len(scorers) == 8, (
        f"C17: expected 8 scorers for Databricks tracking URI, got {len(scorers)}"
    )

    _reset_tracking_uri()  # Reset after test

    print("PASS: C17 - get_all_scorers returns 8 scorers for Databricks tracking URI")


# ---------------------------------------------------------------------------
# C20: get_all_scorers conditionally includes Safety and RetrievalRelevance (Behavior)
# ---------------------------------------------------------------------------

def check_c20_databricks_only_scorers():
    """Contracts: C20
    L2 path: N8(get_all_scorers) -> E14(CALL) -> E12(CALL) -> N16(Safety, RetrievalRelevance)
    """
    _reset_tracking_uri("databricks")

    from mlflow.genai.scorers import get_all_scorers

    scorers = get_all_scorers()
    type_names = [type(s).__name__ for s in scorers]

    assert "Safety" in type_names, (
        f"C20: expected Safety in Databricks scorers, got {type_names}"
    )
    assert "RetrievalRelevance" in type_names, (
        f"C20: expected RetrievalRelevance in Databricks scorers, got {type_names}"
    )

    # Verify they are NOT present in OSS mode
    _reset_tracking_uri("file:///tmp/mlflow-test-oss2")
    scorers_oss = get_all_scorers()
    type_names_oss = [type(s).__name__ for s in scorers_oss]

    assert "Safety" not in type_names_oss, (
        f"C20: Safety should NOT be in OSS scorers, got {type_names_oss}"
    )
    assert "RetrievalRelevance" not in type_names_oss, (
        f"C20: RetrievalRelevance should NOT be in OSS scorers, got {type_names_oss}"
    )

    _reset_tracking_uri()  # Reset after test

    print("PASS: C20 - get_all_scorers conditionally includes Safety/RetrievalRelevance for Databricks")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    check_c2_default_name_is_function_name()
    check_c3_parameterized_name()
    check_c5_original_func_stored()
    check_c6_validate_scorers_accepts_scorer_list()
    check_c7_validate_scorers_raises_on_non_list()
    check_c8_validate_scorers_raises_on_nested_get_all_scorers()
    check_c9_validate_scorers_raises_on_class_not_instance()
    check_c10_validate_scorers_empty_list()
    check_c14_raises_on_non_dict_expectations()
    check_c15_logs_missing_columns()
    check_c16_get_all_scorers_oss_count()
    check_c17_get_all_scorers_databricks_count()
    check_c20_databricks_only_scorers()
    print("\nAll behavior spec checks passed.")
