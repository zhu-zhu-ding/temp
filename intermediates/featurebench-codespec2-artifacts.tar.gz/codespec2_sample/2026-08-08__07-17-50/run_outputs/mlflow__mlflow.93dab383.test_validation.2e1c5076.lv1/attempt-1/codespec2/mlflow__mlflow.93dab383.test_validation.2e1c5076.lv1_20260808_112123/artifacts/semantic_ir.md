# Semantic IR

## L1. Requirement Obligations

### R1: scorer decorator returns a callable Scorer instance
- **Type:** Behavior
- **Statement:** When `scorer` is applied as a decorator to a user function, it must produce a `CustomScorer` instance that is a subclass of `Scorer`, wraps the original function, and is callable with the same signature as the original function.
- **Task Evidence:** Interface Description 1 — "A decorator to define a custom scorer that can be used in `mlflow.genai.evaluate()`."
- **Acceptance:** Decorating a function `def f(outputs) -> bool: ...` with `@scorer` yields an object that is `isinstance(scorer, Scorer)`, has `kind == ScorerKind.DECORATOR`, and calling `.run(...)` or `.__call__(...)` invokes the original function.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1016` (reference `CustomScorer` class); `/testbed/tests/genai/scorers/test_scorer.py:61-63` (`test_scorer_existence_in_metrics` parametrized with `scorer(always_yes)`).
- **Uncertainty:** None.

### R2: scorer supports parameterized usage (name, description, aggregations)
- **Type:** Interface
- **Statement:** When `scorer` is called with keyword arguments `name`, `description`, or `aggregations` without a decorated function, it must return a `functools.partial` that can later accept the function.
- **Task Evidence:** Interface Description 1 — "Args: func: The scorer function to be decorated. name: The name of the scorer. description: A description... aggregations: A list of aggregation functions..."
- **Acceptance:** `scorer(name="custom_name")(func)` yields a `Scorer` with `name == "custom_name"`, and `scorer(func)` yields a `Scorer` with `name == func.__name__`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:994-997` (`if func is None: return functools.partial(...)`) ; `/testbed/tests/genai/scorers/test_scorer_description.py:17-53` (tests for description parameter).
- **Uncertainty:** None.

### R3: CustomScorer wraps original function with signature introspection
- **Type:** Dataflow
- **Statement:** The `CustomScorer.__call__` method's signature must be updated to match the original function's parameters (with `self` prepended) so that MLflow's evaluation harness can introspect and pass the correct subset of `inputs`, `outputs`, `expectations`, `trace`.
- **Task Evidence:** Interface Description 1 docstring table listing `inputs`, `outputs`, `expectations`, `trace` parameters.
- **Acceptance:** `inspect.signature(custom_scorer.__call__)` returns a signature whose parameter names (minus `self`) exactly match the decorated function's parameter names.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1021-1027` (signature replacement logic); `/testbed/tests/genai/scorers/test_scorer.py:155` (`test_trace_passed_to_custom_scorer_correctly` verifies parameters passed).
- **Uncertainty:** None.

### R4: CustomScorer stores _original_func for serialization
- **Type:** State
- **Statement:** The `CustomScorer` must store a reference to the original decorated function as `_original_func` (a Pydantic PrivateAttr) so that `model_dump()` can extract source code for serialization.
- **Task Evidence:** Task docstring example shows scorers being used in `mlflow.genai.evaluate()`; serialization is needed for registration.
- **Acceptance:** `custom_scorer._original_func is func` is `True`, and `custom_scorer.model_dump()` returns a dict with `call_source`, `call_signature`, and `original_func_name` keys.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1001-1008` (CustomScorer __init__); `/testbed/mlflow/genai/scorers/base.py:149-198` (Scorer.model_dump uses `_original_func`); `/testbed/tests/genai/scorers/test_serialization.py:23-47` (test_decorator_scorer_serialization_format).
- **Uncertainty:** None.

### R5: validate_scorers validates list of scorers
- **Type:** Behavior
- **Statement:** `validate_scorers(scorers)` must accept a list of potential scorer objects, validate each is a `Scorer` instance (or legacy `databricks.rag_eval.evaluation.metrics.Metric`), and return a list of valid `Scorer` objects, raising `MlflowException` for invalid items with helpful hints.
- **Task Evidence:** Interface Description 2 — "Validate a list of specified scorers and ensure they are valid Scorer instances."
- **Acceptance:** Given `[Correctness(), Scorer(name="x")]`, returns the same list. Given `[get_all_scorers()]` (nested list), raises `MlflowException` with hint about using `get_all_scorers()` directly. Given `[Correctness]` (class not instance), raises with hint about instantiation. Given a non-list, raises `MlflowException`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-96` (full implementation); `/testbed/mlflow/genai/evaluation/base.py:243` (caller `scorers = validate_scorers(scorers)`).
- **Uncertainty:** None.

### R6: validate_scorers supports legacy databricks.rag_eval metrics
- **Type:** Compatibility
- **Statement:** When `databricks.agents` is installed, `validate_scorers` must accept `databricks.rag_eval.evaluation.metrics.Metric` instances as valid scorers and log a deprecation warning.
- **Task Evidence:** Interface Description 2 — "Legacy databricks.rag_eval metrics are supported but deprecated, and will log warnings."
- **Acceptance:** If `databricks.agents` is importable and a `Metric` instance is passed, it is included in the returned list and a warning is logged.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:22-24,53-60,91-96` (IS_DBX_AGENTS_INSTALLED check, legacy handling, warning).
- **Uncertainty:** None.

### R7: valid_data_for_builtin_scorers validates DataFrame columns
- **Type:** Dataflow
- **Statement:** `valid_data_for_builtin_scorers(data, builtin_scorers, predict_fn)` must check that the input DataFrame contains all columns required by each builtin scorer, performing column name transformations (`request→inputs`, `response→outputs`), handling `predict_fn` (which makes `outputs` optional), `trace` column (which implies `inputs` and `outputs`), and exploding `expectations` dict keys into `expectations/<key>` columns.
- **Task Evidence:** Interface Description 2 — "Validate that the required columns are present in the data for running the builtin scorers."
- **Acceptance:** When required columns are missing, logs an informative message listing which scorers need which columns but does not raise. When `expectations` column contains non-dict values, raises `MlflowException`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101-174` (full implementation); `/testbed/mlflow/genai/evaluation/base.py:248` (caller); `/testbed/mlflow/genai/optimize/util.py:91` (caller).
- **Uncertainty:** None.

### R8: get_all_scorers returns all builtin scorer instances
- **Type:** Behavior
- **Statement:** `get_all_scorers()` must return a list of instantiated `BuiltInScorer` objects covering all available builtin scorers. In OSS tracking, it returns 6 scorers: `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, `Equivalence`. In Databricks tracking, it additionally includes `Safety` and `RetrievalRelevance` (8 total).
- **Task Evidence:** Interface Description 3 — "Get all available built-in scorers for MLflow GenAI evaluation."
- **Acceptance:** `len(get_all_scorers()) == 6` when tracking URI is not databricks; `len(get_all_scorers()) == 8` when tracking URI is databricks. All items are `isinstance(s, Scorer)`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1597` (reference implementation); `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-576` (`test_get_all_scorers_oss`); `/testbed/mlflow/genai/evaluation/base.py:361,385` (caller uses `get_all_scorers()` as default); `/testbed/mlflow/cli/genai_eval_utils.py:12,121` (CLI caller).
- **Uncertainty:** None.

### R9: evaluation/base.py imports validate_scorers and valid_data_for_builtin_scorers
- **Type:** Dataflow
- **Statement:** The `evaluate()` function in `/testbed/mlflow/genai/evaluation/base.py` must import `validate_scorers` and `valid_data_for_builtin_scorers` from `mlflow.genai.scorers.validation` so that it can call them at lines 243 and 248.
- **Task Evidence:** Interface Description 2 defines both functions as callable from the evaluate pipeline.
- **Acceptance:** The import statement `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers` is present in evaluation/base.py, and calling `evaluate(data=..., scorers=[...])` does not raise `NameError`.
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21` (reference import); `/testbed/mlflow/genai/evaluation/base.py:243,248` (call sites that use these names without importing them).
- **Uncertainty:** Whether the testbed's evaluation/base.py is intentionally incomplete or whether there is another import path (e.g., delayed import inside the function). The skinny reference has a top-level import.

## L2. Functional Design Graph

### N1: scorer (decorator factory)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:847` (`def scorer(...)`); `/testbed/mlflow/genai/scorers/__init__.py:4` (exported as `scorer`).

### N2: CustomScorer (class created inside scorer)
- **Kind:** Class
- **Repository Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1016` (class definition inside `scorer`).

### N3: Scorer (base class)
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:111` (`class Scorer(BaseModel)`).

### N4: Scorer.model_dump
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:149-198`.

### N5: Scorer.run
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/base.py:374-427`.

### N6: validate_scorers
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/validation.py:26` (signature exists, body empty); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-96` (reference body).

### N7: valid_data_for_builtin_scorers
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/validation.py:101` (signature exists, body empty); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:101-174` (reference body).

### N8: get_all_scorers
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py` (function missing); `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1597` (reference); `/testbed/mlflow/genai/scorers/__init__.py:36,93` (listed in exports).

### N9: BuiltInScorer.validate_columns
- **Kind:** Method
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py:324-327`.

### N10: MissingColumnsException
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py:1600-1605`.

### N11: evaluate (in evaluation/base.py)
- **Kind:** PublicEntry
- **Repository Evidence:** `/testbed/mlflow/genai/evaluation/base.py:230` (eval_harness context), caller of validate_scorers and valid_data_for_builtin_scorers.

### N12: MlflowException
- **Kind:** Error
- **Repository Evidence:** `/testbed/mlflow/exceptions.py`.

### N13: IS_DBX_AGENTS_INSTALLED
- **Kind:** State
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/validation.py:22`.

### N14: _logger (in validation.py)
- **Kind:** Observer
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/validation.py:20`.

### N15: BuiltInScorer base class
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py:259`.

### N16: ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence, Safety, RetrievalRelevance
- **Kind:** Class
- **Repository Evidence:** `/testbed/mlflow/genai/scorers/builtin_scorers.py:826,1196,980,464,590,1380,1094,335`.

### E1: scorer -> CustomScorer
- **Kind:** CONTROL
- **Condition:** `func is not None` (i.e., used as `@scorer` without arguments or `scorer(func)`)
- **Transfer:** Creates `CustomScorer` class, instantiates it with `name`, `description`, `aggregations`, wraps `func` as `_original_func`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:994-1031`.
- **Obligations:** R1, R2, R3, R4

### E2: scorer -> functools.partial
- **Kind:** CONTROL
- **Condition:** `func is None` (i.e., used as `@scorer(name=...)` or `scorer(name=...)`)
- **Transfer:** Returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)`.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:994-997`.
- **Obligations:** R2

### E3: CustomScorer.__call__ -> original func
- **Kind:** CALL
- **Condition:** Always (when CustomScorer is called)
- **Transfer:** Forwards all arguments to the original decorated function; signature is dynamically set to match original function params plus `self`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1013-1014,1021-1027`.
- **Obligations:** R1, R3

### E4: Scorer.run -> Scorer.__call__
- **Kind:** CALL
- **Condition:** Always (run delegates to __call__ with filtered kwargs)
- **Transfer:** Filters kwargs by __call__ signature, invokes __call__, validates return type, renames default Feedback name to scorer name.
- **Evidence:** `/testbed/mlflow/genai/scorers/base.py:374-427`.
- **Obligations:** R1

### E5: evaluate -> validate_scorers
- **Kind:** CALL
- **Condition:** Always at start of evaluate()
- **Transfer:** Passes `scorers` list, receives validated `list[Scorer]`.
- **Evidence:** `/testbed/mlflow/genai/evaluation/base.py:243`; `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21,243`.
- **Obligations:** R5, R6, R9

### E6: evaluate -> valid_data_for_builtin_scorers
- **Kind:** CALL
- **Condition:** After validate_scorers returns
- **Transfer:** Passes DataFrame `df`, list of `BuiltInScorer` instances, and optional `predict_fn`.
- **Evidence:** `/testbed/mlflow/genai/evaluation/base.py:248`; `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21,248`.
- **Obligations:** R7, R9

### E7: validate_scorers -> get_all_scorers
- **Kind:** CALL
- **Condition:** When a scorers list item `isinstance(scorer, list)` (to detect nested mistake)
- **Transfer:** Calls `get_all_scorers()` and compares with the nested list to provide helpful error hint.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:62-72`.
- **Obligations:** R5, R8

### E8: validate_scorers -> MlflowException
- **Kind:** CONTROL
- **Condition:** When scorers is not a list, or any item is not a Scorer instance (and not a legacy Metric), or a class instead of instance.
- **Transfer:** Raises `MlflowException` with informative message and hint.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:34-86`.
- **Obligations:** R5

### E9: valid_data_for_builtin_scorers -> BuiltInScorer.validate_columns
- **Kind:** CALL
- **Condition:** For each scorer in builtin_scorers list
- **Transfer:** Passes `input_columns` set (after transformations); catches `MissingColumnsException`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:152-157`.
- **Obligations:** R7

### E10: valid_data_for_builtin_scorers -> MissingColumnsException
- **Kind:** CONTROL
- **Condition:** When `BuiltInScorer.validate_columns` raises `MissingColumnsException`
- **Transfer:** Catches exception, aggregates missing column info, logs via `_logger.info`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:155-174`.
- **Obligations:** R7

### E11: valid_data_for_builtin_scorers -> MlflowException
- **Kind:** CONTROL
- **Condition:** When `expectations` column contains non-dict values
- **Transfer:** Raises `MlflowException` with message about dict requirement.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:143-148`.
- **Obligations:** R7

### E12: get_all_scorers -> BuiltInScorer subclasses
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Instantiates and returns list of all builtin scorer instances; conditionally includes `Safety()` and `RetrievalRelevance()` when `is_databricks_uri(tracking_uri)`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1587-1597`.
- **Obligations:** R8

### E13: valid_data_for_builtin_scorers columns -> DataFrame
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** Reads `data.columns`, remaps `request→inputs`, `response→outputs`; adds `outputs` if `predict_fn` is not None; adds `inputs` and `outputs` if `trace` column exists; explodes `expectations` dict keys into `expectations/<k>` columns.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:117-149`.
- **Obligations:** R7

### E14: get_all_scorers -> is_databricks_uri
- **Kind:** CALL
- **Condition:** Always
- **Transfer:** Calls `is_databricks_uri(mlflow.get_tracking_uri())` to determine whether to include Databricks-only scorers.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1596`.
- **Obligations:** R8

### E15: validate_scorers -> IS_DBX_AGENTS_INSTALLED
- **Kind:** CONTROL
- **Condition:** When a scorer item is not a `Scorer` instance
- **Transfer:** Checks if `databricks.agents` is importable; if so, checks if item is `databricks.rag_eval.evaluation.metrics.Metric`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:53-60`.
- **Obligations:** R6

### E16: CustomScorer -> Scorer (inheritance)
- **Kind:** DATA
- **Condition:** Always
- **Transfer:** `class CustomScorer(Scorer)` — inherits `name`, `description`, `aggregations`, `run()`, `model_dump()`, `model_validate()`, etc.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999`.
- **Obligations:** R1, R3, R4

## L3. Verifiable Contracts

### C1: scorer(func) returns CustomScorer instance
- **Type:** Interface
- **Subject:** `scorer(func)` return value
- **Relation:** TYPE_IS
- **Expected:** Returns an instance of a dynamically created `CustomScorer` class that is a subclass of `Scorer`.
- **Evidence:** Task: "A decorator to define a custom scorer that can be used in `mlflow.genai.evaluate()`." ; `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1031`.
- **Observe:** RETURN_VALUE
- **Target:** `isinstance(scorer(lambda outputs: True), Scorer)` at module level
- **Obligations:** R1
- **Graph:** N1, N2, N3, E1, E16

### C2: CustomScorer.name equals function name by default
- **Type:** State
- **Subject:** CustomScorer instance name attribute
- **Relation:** EQ
- **Expected:** `scorer(lambda outputs: True).name == "<lambda>"` — i.e., name defaults to `func.__name__`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1029` (`name=name or func.__name__`); Task: "The metric name will be determined by the scorer function's name."
- **Observe:** FIELD_READ
- **Target:** `scorer(my_func).name`
- **Obligations:** R1, R2
- **Graph:** N2, E1, E16

### C3: scorer(name="X")(func).name equals "X"
- **Type:** State
- **Subject:** CustomScorer instance name when parameterized
- **Relation:** EQ
- **Expected:** `scorer(name="my_name")(lambda outputs: True).name == "my_name"`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:994-997,1029`; `/testbed/tests/genai/scorers/test_scorer_description.py:35-44`.
- **Observe:** FIELD_READ
- **Target:** `scorer(name="custom")(func).name`
- **Obligations:** R2
- **Graph:** N1, N2, E2, E1

### C4: CustomScorer.__call__ signature matches original function
- **Type:** Interface
- **Subject:** CustomScorer.__call__ signature
- **Relation:** EQ
- **Expected:** `inspect.signature(custom.__call__).parameters.keys()` equals `('self',)` plus the original function's parameter names.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1021-1027`.
- **Observe:** RUNTIME_ARGUMENT_TRACE
- **Target:** `inspect.signature(scorer(lambda outputs, expectations: True).__call__)`
- **Obligations:** R3
- **Graph:** N2, E3

### C5: CustomScorer._original_func stores the decorated function
- **Type:** State
- **Subject:** CustomScorer._original_func attribute
- **Relation:** EQ
- **Expected:** For `s = scorer(f)`, `s._original_func is f` is `True` (same object identity).
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1001-1008`.
- **Observe:** FIELD_READ
- **Target:** `scorer(f)._original_func`
- **Obligations:** R4
- **Graph:** N2, E1

### C6: validate_scorers accepts list of Scorer instances
- **Type:** Behavior
- **Subject:** validate_scorers function
- **Relation:** PRESERVE
- **Expected:** `validate_scorers([Correctness(), RelevanceToQuery()])` returns the same list unchanged.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:49-51`.
- **Observe:** RETURN_VALUE
- **Target:** Direct function call in test
- **Obligations:** R5
- **Graph:** N6, E5

### C7: validate_scorers raises on non-list input
- **Type:** Failure
- **Subject:** validate_scorers with non-list argument
- **Relation:** RAISES
- **Expected:** `validate_scorers("not_a_list")` raises `MlflowException` with message containing "must be a list of scorers".
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:34-40`.
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, match="must be a list")`
- **Obligations:** R5
- **Graph:** N6, N12, E8

### C8: validate_scorers raises with hint for nested get_all_scorers()
- **Type:** Failure
- **Subject:** validate_scorers with `[get_all_scorers()]` (nested list)
- **Relation:** RAISES
- **Expected:** `validate_scorers([get_all_scorers()])` raises `MlflowException` with hint "Use `scorers=get_all_scorers()`".
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:62-68`.
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, match="get_all_scorers")`
- **Obligations:** R5, R8
- **Graph:** N6, N8, E7, E8

### C9: validate_scorers raises with hint for class instead of instance
- **Type:** Failure
- **Subject:** validate_scorers with `[Correctness]` (class, not instance)
- **Relation:** RAISES
- **Expected:** `validate_scorers([Correctness])` raises `MlflowException` with hint "you passed a scorer class instead of an instance".
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:73-79`.
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, match="class instead of an instance")`
- **Obligations:** R5
- **Graph:** N6, N12, N15, E8

### C10: validate_scorers returns empty list for empty input
- **Type:** Behavior
- **Subject:** validate_scorers([]) 
- **Relation:** EQ
- **Expected:** `validate_scorers([])` returns `[]`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:42-43`.
- **Observe:** RETURN_VALUE
- **Target:** Direct function call
- **Obligations:** R5
- **Graph:** N6

### C11: valid_data_for_builtin_scorers remaps request→inputs, response→outputs
- **Type:** Dataflow
- **Subject:** Column name remapping in valid_data_for_builtin_scorers
- **Relation:** TRANSITIONS
- **Expected:** When data has columns `["request", "response"]`, internally these are treated as `inputs` and `outputs` respectively for validation purposes.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:119-124`.
- **Observe:** SIDE_EFFECT (logs missing columns based on remapped names)
- **Target:** Log inspection after calling valid_data_for_builtin_scorers with request/response columns
- **Obligations:** R7
- **Graph:** N7, E13

### C12: valid_data_for_builtin_scorers treats outputs as available when predict_fn provided
- **Type:** Dataflow
- **Subject:** Column availability with predict_fn
- **Relation:** TRANSITIONS
- **Expected:** When `predict_fn is not None`, the `outputs` column is considered available even if not present in data.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:126-128`.
- **Observe:** SIDE_EFFECT (no log about missing outputs column)
- **Target:** Log inspection after calling with predict_fn and data missing outputs column
- **Obligations:** R7
- **Graph:** N7, E13

### C13: valid_data_for_builtin_scorers infers inputs/outputs from trace column
- **Type:** Dataflow
- **Subject:** Column inference from trace
- **Relation:** TRANSITIONS
- **Expected:** When `trace` column is present, both `inputs` and `outputs` are considered available.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:130-132`.
- **Observe:** SIDE_EFFECT (no log about missing inputs/outputs columns)
- **Target:** Log inspection after calling with data containing trace column
- **Obligations:** R7
- **Graph:** N7, E13

### C14: valid_data_for_builtin_scorers raises on non-dict expectations
- **Type:** Failure
- **Subject:** Expectations column validation
- **Relation:** RAISES
- **Expected:** When `expectations` column contains a non-dict, non-NaN value, raises `MlflowException` with message about dict requirement.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:143-148`.
- **Observe:** EXCEPTION
- **Target:** `pytest.raises(MlflowException, match="must be a dictionary")`
- **Obligations:** R7
- **Graph:** N7, N12, E11

### C15: valid_data_for_builtin_scorers logs missing columns info
- **Type:** SideEffect
- **Subject:** Logging when required columns are missing
- **Relation:** CONTAINS
- **Expected:** When columns are missing, logs an INFO message containing "missing following columns" and lists the scorers requiring each missing column.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:159-174`.
- **Observe:** SIDE_EFFECT (logging output)
- **Target:** `caplog` fixture inspecting `_logger.info` calls
- **Obligations:** R7
- **Graph:** N7, N14, E10

### C16: get_all_scorers returns 6 scorers for OSS tracking URI
- **Type:** Behavior
- **Subject:** get_all_scorers return value length with non-Databricks URI
- **Relation:** EQ
- **Expected:** `len(get_all_scorers()) == 6` when `mlflow.get_tracking_uri()` is not a databricks URI.
- **Evidence:** `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-576`; `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1587-1597`.
- **Observe:** RETURN_VALUE
- **Target:** `len(get_all_scorers())` with `tracking_uri="file://test"`
- **Obligations:** R8
- **Graph:** N8, E12, E14

### C17: get_all_scorers returns 8 scorers for Databricks tracking URI
- **Type:** Behavior
- **Subject:** get_all_scorers return value length with Databricks URI
- **Relation:** EQ
- **Expected:** `len(get_all_scorers()) == 8` when `mlflow.get_tracking_uri()` is a databricks URI.
- **Evidence:** `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-576`; `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1596-1597`.
- **Observe:** RETURN_VALUE
- **Target:** `len(get_all_scorers())` with `tracking_uri="databricks"`
- **Obligations:** R8
- **Graph:** N8, N16, E12, E14

### C18: get_all_scorers items are all Scorer instances
- **Type:** Interface
- **Subject:** Each item in get_all_scorers() return value
- **Relation:** TYPE_IS
- **Expected:** `all(isinstance(s, Scorer) for s in get_all_scorers())` is `True`.
- **Evidence:** `/testbed/tests/genai/scorers/test_builtin_scorers.py:577`.
- **Observe:** RETURN_VALUE
- **Target:** `isinstance(s, Scorer)` on each item
- **Obligations:** R8
- **Graph:** N8, N3, N15, N16, E12

### C19: get_all_scorers includes ExpectationsGuidelines, Correctness, RelevanceToQuery, RetrievalSufficiency, RetrievalGroundedness, Equivalence
- **Type:** Interface
- **Subject:** get_all_scorers return value composition (OSS)
- **Relation:** CONTAINS
- **Expected:** The returned list contains exactly one instance each of `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, `Equivalence` (in that order).
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1587-1594`.
- **Observe:** RETURN_VALUE
- **Target:** `[type(s).__name__ for s in get_all_scorers()]`
- **Obligations:** R8
- **Graph:** N8, N16, E12

### C20: get_all_scorers conditionally includes Safety and RetrievalRelevance for Databricks
- **Type:** Behavior
- **Subject:** get_all_scorers Databricks-only scorers
- **Relation:** CONTAINS
- **Expected:** When `is_databricks_uri(mlflow.get_tracking_uri())` is True, the returned list also includes instances of `Safety` and `RetrievalRelevance`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1596-1597`.
- **Observe:** RETURN_VALUE
- **Target:** `[type(s).__name__ for s in get_all_scorers()]` with Databricks URI
- **Obligations:** R8
- **Graph:** N8, N16, E12, E14

### C21: evaluation/base.py imports from validation module
- **Type:** Interface
- **Subject:** Import statement in evaluation/base.py
- **Relation:** CALLS
- **Expected:** Module contains `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers`.
- **Evidence:** `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21`; `/testbed/mlflow/genai/evaluation/base.py:243,248` (call sites without import).
- **Observe:** IMPORT_BOUNDARY
- **Target:** Static analysis of import statements in the module
- **Obligations:** R9
- **Graph:** N11, N6, N7, E5, E6
