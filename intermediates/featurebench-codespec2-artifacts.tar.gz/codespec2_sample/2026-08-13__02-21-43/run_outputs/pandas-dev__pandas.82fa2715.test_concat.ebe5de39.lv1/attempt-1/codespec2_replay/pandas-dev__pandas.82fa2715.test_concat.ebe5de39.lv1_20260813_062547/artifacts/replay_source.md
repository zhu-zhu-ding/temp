# Replay Source

- Reference artifacts: `/agent-logs/codespec2_reference/artifacts`
- Copied artifacts: `semantic_ir.md`, `arch_spec.py`, `behavior_spec.py`, `static_issues.md`, `static_analysis.md`
- Execution: only the unchanged CodeSpec2 implement prompt is run in this replay.
