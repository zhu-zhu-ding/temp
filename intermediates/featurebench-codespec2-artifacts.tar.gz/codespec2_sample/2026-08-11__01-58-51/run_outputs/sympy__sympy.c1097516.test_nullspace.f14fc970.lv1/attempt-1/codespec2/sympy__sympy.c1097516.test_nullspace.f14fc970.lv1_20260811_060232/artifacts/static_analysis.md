# Static Analysis

## Scope
- Repository: `/testbed`
- Declared interfaces: 5
- `sympy/polys/matrices/domainmatrix.py`: `DomainMatrix` (class)
- `sympy/polys/matrices/domainmatrix.py`: `DomainMatrix.nullspace` (method)
- `sympy/polys/matrices/domainmatrix.py`: `DomainMatrix.primitive` (method)
- `sympy/polys/matrices/domainmatrix.py`: `DomainMatrix.to_sdm` (method)
- `sympy/polys/matrices/domainmatrix.py`: `DomainMatrix.to_sparse` (method)

## Findings
## static issue

- **`sympy/polys/compatibility.py`** (3):
  - ? 'dup_clear_denoms' is used but not defined or imported in this file
  - ? 'dup_content' is used but not defined or imported in this file
  - ? 'dup_primitive' is used but not defined or imported in this file
- **`sympy/polys/euclidtools.py`** (3):
  - ? 'dup_clear_denoms' is used but not defined or imported in this file
  - ? 'dup_convert' is used but not defined or imported in this file
  - ? 'dup_primitive' is used but not defined or imported in this file
- **`sympy/polys/factortools.py`** (4):
  - ? 'dup_clear_denoms' is used but not defined or imported in this file
  - ? 'dup_content' is used but not defined or imported in this file
  - ? 'dup_convert' is used but not defined or imported in this file
  - ? 'dup_primitive' is used but not defined or imported in this file
- **`sympy/polys/matrices/ddm.py`** (2):
  - ? 'ddm_imul' is used but not defined or imported in this file
  - ? 'ddm_irref' is used but not defined or imported in this file
- **`sympy/polys/matrices/domainmatrix.py`** (2):
  - ? 'dup_content' is used but not defined or imported in this file
  - ? 'dup_convert' is used but not defined or imported in this file
- **`sympy/polys/matrices/linsolve.py`** (1):
  - ? 'sdm_nullspace_from_rref' is used but not defined or imported in this file
- **`sympy/polys/matrices/rref.py`** (4):
  - ? '_dm_elements' is used but not defined or imported in this file
  - ? '_dm_rref_choose_method_QQ' is used but not defined or imported in this file
  - ? '_dm_rref_den_FF' is used but not defined or imported in this file
  - ? 'ddm_irref' is used but not defined or imported in this file
- **`sympy/polys/matrices/sdm.py`** (3):
  - ? 'sdm_nullspace_from_rref' is used but not defined or imported in this file
  - ? 'sdm_rref_den' is used but not defined or imported in this file
  - ? 'sdm_scalar_mul' is used but not defined or imported in this file
- **`sympy/polys/numberfields/modules.py`** (1):
  - ? 'dup_clear_denoms' is used but not defined or imported in this file
- **`sympy/polys/polyclasses.py`** (1):
  - ? 'dup_convert' is used but not defined or imported in this file
- **`sympy/polys/sqfreetools.py`** (2):
  - ? 'dup_convert' is used but not defined or imported in this file
  - ? 'dup_primitive' is used but not defined or imported in this file

## Use
- Requirement Compile: use findings to identify dependency, caller-binding, and compatibility risks.
- Test Spec: compile relevant findings into runtime checks; static evidence alone is not a behavior proof.
