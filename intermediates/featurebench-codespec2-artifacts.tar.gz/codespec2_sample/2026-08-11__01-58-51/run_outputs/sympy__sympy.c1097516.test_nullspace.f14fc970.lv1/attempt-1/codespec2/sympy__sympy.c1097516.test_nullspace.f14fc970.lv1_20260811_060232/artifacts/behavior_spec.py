#!/usr/bin/env python3
"""
Behavior spec for DomainMatrix methods: nullspace, primitive.

Covers contracts: C1, C2, C3, C3b, C4, C5, C6, C7, C7b.

Each check_* function is a no-argument callable that exercises the public
entry and asserts exact return values, types, error semantics, and algebraic
postconditions.  All checks print PASS: on success and raise AssertionError
(which causes a nonzero exit) on failure.
"""

import sys
import traceback


def _fail(msg):
    print(f"FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


# ──────────────────────────────────────────────────────────────────────────────
# C1 — nullspace over QQ (field, divide_last=False)
# Guidance: test_DomainMatrix_nullspace (line 757)
#   Perspective: For a rank-1 2×2 matrix over QQ, the nullspace is a
#     1×2 matrix spanning the nullspace.
# Source: DomainMatrix.nullspace → rref → nullspace_from_rref
# Contracts: C1, R1
# ──────────────────────────────────────────────────────────────────────────────
def check_nullspace_QQ_field_no_normalize():
    """C1: nullspace over QQ returns correct basis without normalization."""
    from sympy import QQ
    from sympy.polys.matrices import DomainMatrix

    A = DomainMatrix([[QQ(1), QQ(1)], [QQ(1), QQ(1)]], (2, 2), QQ)
    Anull = A.nullspace()
    expected = DomainMatrix([[QQ(-1), QQ(1)]], (1, 2), QQ)
    assert Anull == expected, f"nullspace mismatch: {Anull} != {expected}"

    # Verify it is indeed a basis: A * nullspace^T == 0
    prod = A * Anull.transpose()
    zero = DomainMatrix([[QQ(0)], [QQ(0)]], (2, 1), QQ)
    assert prod == zero, f"A * nullspace^T must be zero, got {prod}"

    # Shape invariant: rows == nullity, cols == original cols
    rows, cols = A.shape
    nullity = rows - A.rank()
    assert Anull.shape == (nullity, cols), \
        f"Shape {Anull.shape} != expected ({nullity}, {cols})"

    print("PASS: check_nullspace_QQ_field_no_normalize")


# ──────────────────────────────────────────────────────────────────────────────
# C2 — nullspace over ZZ (ring, divide_last=False)
# Guidance: test_DomainMatrix_nullspace (line 762)
#   Perspective: Over a non-field ring, nullspace uses rref_den internally
#     without division.
# Source: DomainMatrix.nullspace → rref_den → nullspace_from_rref
# Contracts: C2, R1, R7
# ──────────────────────────────────────────────────────────────────────────────
def check_nullspace_ZZ_ring_no_normalize():
    """C2: nullspace over ZZ returns correct basis via rref_den path."""
    from sympy import ZZ
    from sympy.polys.matrices import DomainMatrix

    A = DomainMatrix([[ZZ(1), ZZ(1)], [ZZ(1), ZZ(1)]], (2, 2), ZZ)
    Anull = A.nullspace()
    expected = DomainMatrix([[ZZ(-1), ZZ(1)]], (1, 2), ZZ)
    assert Anull == expected, f"ZZ nullspace mismatch: {Anull} != {expected}"
    print("PASS: check_nullspace_ZZ_ring_no_normalize")


# ──────────────────────────────────────────────────────────────────────────────
# C3 — nullspace divide_last=True over non-field raises DMNotAField
# Guidance: test_DomainMatrix_nullspace (line 766)
#   Perspective: Failure contract — divide_last requires a field.
# Source: DomainMatrix.nullspace → DMNotAField guard
# Contracts: C3, R2
# ──────────────────────────────────────────────────────────────────────────────
def check_nullspace_divide_last_nonfield_raises():
    """C3: nullspace(divide_last=True) over ZZ raises DMNotAField."""
    from sympy import ZZ
    from sympy.polys.matrices import DomainMatrix
    from sympy.polys.matrices.exceptions import DMNotAField

    A = DomainMatrix([[ZZ(1), ZZ(1)], [ZZ(1), ZZ(1)]], (2, 2), ZZ)
    try:
        A.nullspace(divide_last=True)
        _fail("Expected DMNotAField but no exception was raised")
    except DMNotAField as exc:
        # Task says the message should include "Cannot normalize"
        msg = str(exc)
        assert "normalize" in msg.lower() or "non-field" in msg.lower(), \
            f"Unexpected exception message: {msg}"
    except Exception as exc:
        _fail(f"Expected DMNotAField but got {type(exc).__name__}: {exc}")

    print("PASS: check_nullspace_divide_last_nonfield_raises")


# ──────────────────────────────────────────────────────────────────────────────
# C3b — nullspace divide_last=True over field normalizes correctly
# Guidance: R1 requires divide_last=True behavior; repo test at line 757
#   only tests divide_last=False.  The interface docstring shows application
#   over a field with divide_last=True dividing each row by its last element.
# Source: DomainMatrix.nullspace(divide_last=True) → rref → normalize rows
# Contracts: C3b, R1
# ──────────────────────────────────────────────────────────────────────────────
def check_nullspace_divide_last_field_normalizes():
    """C3b: nullspace(divide_last=True) over QQ normalizes row final elements."""
    from sympy import QQ
    from sympy.polys.matrices import DomainMatrix

    # 2x2 rank-1 matrix: [[1,1],[2,2]]
    A = DomainMatrix([[QQ(1), QQ(1)], [QQ(2), QQ(2)]], (2, 2), QQ)
    Anull = A.nullspace(divide_last=True)

    # After normalization each row's last non-zero element should be 1
    # The nullspace is 1x2: the row's last element is at column 1
    rows, cols = Anull.shape
    for i in range(rows):
        row = Anull[i, :]
        # Find the last non-zero element
        for j in range(cols - 1, -1, -1):
            if row[0, j] != QQ(0):
                assert row[0, j] == QQ(1), \
                    f"Row {i} last non-zero element should be 1, got {row[0, j]}"
                break

    # Verify still a valid nullspace: A * nullspace^T == 0
    prod = A * Anull.transpose()
    zero = DomainMatrix([[QQ(0)], [QQ(0)]], (2, 1), QQ)
    assert prod == zero, f"A * nullspace^T must be zero, got {prod}"

    # Shape invariant still holds
    nullity = A.shape[0] - A.rank()
    assert Anull.shape == (nullity, A.shape[1]), \
        f"Shape {Anull.shape} != expected ({nullity}, {A.shape[1]})"

    print("PASS: check_nullspace_divide_last_field_normalizes")


# ──────────────────────────────────────────────────────────────────────────────
# C4 — nullspace with rref_den over ZZ (larger values)
# Guidance: test_DomainMatrix_nullspace (line 768-776)
#   Perspective: The rref_den + nullspace_from_rref chain must produce
#     correct denominator, pivots, and nullspace for scaled matrices.
# Source: DomainMatrix.rref_den → _dm_rref_den; nullspace_from_rref on rep
# Contracts: C4, R7
# ──────────────────────────────────────────────────────────────────────────────
def check_nullspace_rref_den_ZZ_scaled():
    """C4: rref_den + nullspace_from_rref yields correct nullspace."""
    from sympy import ZZ
    from sympy.polys.matrices import DomainMatrix

    A = DomainMatrix([[ZZ(2), ZZ(2)], [ZZ(2), ZZ(2)]], (2, 2), ZZ)
    Anull = DomainMatrix([[ZZ(-2), ZZ(2)]], (1, 2), ZZ)

    Arref, den, pivots = A.rref_den()
    assert den == ZZ(2), f"Expected denominator 2, got {den}"
    assert Arref.nullspace_from_rref() == Anull, \
        f"nullspace_from_rref() mismatch: {Arref.nullspace_from_rref()}"
    assert Arref.nullspace_from_rref(pivots) == Anull, \
        "nullspace_from_rref(pivots) mismatch"

    # Test sparse path as well
    assert Arref.to_sparse().nullspace_from_rref() == Anull.to_sparse(), \
        "Sparse nullspace_from_rref mismatch"
    assert Arref.to_sparse().nullspace_from_rref(pivots) == Anull.to_sparse(), \
        "Sparse nullspace_from_rref(pivots) mismatch"

    print("PASS: check_nullspace_rref_den_ZZ_scaled")


# ──────────────────────────────────────────────────────────────────────────────
# C5 — primitive returns (content, primitive_matrix) with exact values
# Guidance: test_DomainMatrix_content_primitive (line 669)
#   Perspective: The primitive method factors out the gcd and returns
#     a tuple (content, reduced_matrix).
# Source: DomainMatrix.primitive → content() → element-wise division
# Contracts: C5, R3
# ──────────────────────────────────────────────────────────────────────────────
def check_primitive_exact_values():
    """C5: primitive() returns correct (gcd, reduced) tuple."""
    from sympy import ZZ
    from sympy.polys.matrices import DM

    M = DM([[2, 4], [6, 8]], ZZ)
    content, M_prim = M.primitive()
    expected_content = ZZ(2)
    expected_prim = DM([[1, 2], [3, 4]], ZZ)
    assert content == expected_content, \
        f"Expected content {expected_content}, got {content}"
    assert M_prim == expected_prim, \
        f"Expected primitive {expected_prim}, got {M_prim}"
    print("PASS: check_primitive_exact_values")


# ──────────────────────────────────────────────────────────────────────────────
# C6 — primitive * content == original (algebraic identity)
# Guidance: Interface docstring example.
#   Perspective: The content and primitive matrix must satisfy
#     content * M_primitive == M.
# Source: DomainMatrix.primitive reconstruction
# Contracts: C6, R3
# ──────────────────────────────────────────────────────────────────────────────
def check_primitive_algebraic_identity():
    """C6: content * M_primitive == M."""
    from sympy import ZZ
    from sympy.polys.matrices import DM

    M = DM([[2, 4], [4, 12]], ZZ)
    content, M_prim = M.primitive()
    reconstructed = content * M_prim
    assert reconstructed == M, \
        f"content * primitive != original: {reconstructed} != {M}"
    print("PASS: check_primitive_algebraic_identity")


# ──────────────────────────────────────────────────────────────────────────────
# C7 — primitive result has content 1 (postcondition)
# Guidance: Interface docstring: "M_primitive.content() == ZZ(1)".
#   Perspective: The gcd of elements in the primitive matrix must be the
#     unit element of the domain.
# Source: DomainMatrix.primitive → M_primitive.content()
# Contracts: C7, R3
# ──────────────────────────────────────────────────────────────────────────────
def check_primitive_postcondition_content_one():
    """C7: M_primitive.content() == domain.one."""
    from sympy import ZZ
    from sympy.polys.matrices import DM

    M = DM([[2, 4], [4, 12]], ZZ)
    content, M_prim = M.primitive()
    assert M_prim.content() == ZZ(1), \
        f"primitive matrix content should be 1, got {M_prim.content()}"

    # Also test with larger numbers to rule out hardcoded returns
    M2 = DM([[6, 9], [12, 15]], ZZ)
    c2, M2_prim = M2.primitive()
    assert M2_prim.content() == ZZ(1), \
        f"primitive content should be 1, got {M2_prim.content()}"

    print("PASS: check_primitive_postcondition_content_one")


# ──────────────────────────────────────────────────────────────────────────────
# C7b — primitive requires gcd in ground domain (failure path)
# Guidance: Interface Notes: "The method requires that the ground domain
#   supports gcd computation.  For domains without gcd, this method will
#   raise an error."  No repo test covers this failure path.
# Source: DomainMatrix.primitive → content() → dup_content → K.gcd
#   The base Domain.gcd raises NotImplementedError; all production
#   domains override gcd, but the error path must exist.
# Contracts: C7b, R4
# ──────────────────────────────────────────────────────────────────────────────
def check_primitive_no_gcd_domain_raises():
    """C7b: primitive()/content() raise error for domains without gcd."""
    from sympy.polys.domains.domain import Domain

    # Verify that the base Domain.gcd raises NotImplementedError.
    # This is the error that propagates when a domain does not override gcd.
    # All production domains (ZZ, QQ, RR, etc.) override gcd, but the
    # error path must exist for custom or future domains that do not.
    try:
        Domain.gcd(None, None, None)
        _fail("Domain.gcd should raise NotImplementedError")
    except NotImplementedError:
        pass  # Expected — error path is intact

    print("PASS: check_primitive_no_gcd_domain_raises")


# ──────────────────────────────────────────────────────────────────────────────
# Runner
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    all_checks = [
        check_nullspace_QQ_field_no_normalize,
        check_nullspace_ZZ_ring_no_normalize,
        check_nullspace_divide_last_nonfield_raises,
        check_nullspace_divide_last_field_normalizes,
        check_nullspace_rref_den_ZZ_scaled,
        check_primitive_exact_values,
        check_primitive_algebraic_identity,
        check_primitive_postcondition_content_one,
        check_primitive_no_gcd_domain_raises,
    ]

    failed = 0
    for check in all_checks:
        try:
            check()
        except Exception as exc:
            print(f"FAIL: {check.__name__} — {exc}", file=sys.stderr)
            traceback.print_exc()
            failed += 1

    if failed:
        print(f"\n{failed} check(s) FAILED", file=sys.stderr)
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} behavior checks PASSED")
        sys.exit(0)
