# Spec Review Report

## Evidence Reviewed

- **Task document** (primary oracle): Interface Description 1 — `nullspace`, `primitive`, `to_sdm`, `to_sparse`
- **Semantic IR**: `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260811_060232/artifacts/semantic_ir.md` (518 lines, covering R1–R8, E1–E14, C1–C23)
- **Architecture spec**: `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260811_060232/artifacts/arch_spec.py`
- **Behavior spec**: `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260811_060232/artifacts/behavior_spec.py`
- **Static issues**: `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260811_060232/artifacts/static_issues.md`
- **Static analysis**: `/agent-logs/codespec2/sympy__sympy.c1097516.test_nullspace.f14fc970.lv1_20260811_060232/artifacts/static_analysis.md`
- **Repository source**:
  - `/testbed/sympy/polys/matrices/domainmatrix.py` (3994 lines) — target for all four methods; none exist yet (confirmed by `hasattr` at runtime)
  - `/testbed/sympy/polys/matrices/ddm.py` — `DDM.nullspace_from_rref`, `DDM.rref`, `DDM.to_sdm` present
  - `/testbed/sympy/polys/matrices/sdm.py` — `SDM.nullspace_from_rref`, `SDM.rref`, `SDM.to_sdm` present
  - `/testbed/sympy/polys/matrices/_dfm.py` — `DFM.nullspace_from_rref`, `DFM.to_sdm` present
  - `/testbed/sympy/polys/matrices/rref.py` — `_dm_rref_den` present but has broken dependencies (`_dm_rref_den_FF`, `_dm_rref_choose_method_QQ`, `_dm_elements`, `ddm_irref` all undefined)
  - `/testbed/sympy/polys/matrices/exceptions.py` — `DMNotAField` defined
- **Repository tests**:
  - `/testbed/sympy/polys/matrices/tests/test_domainmatrix.py:267` — `test_DomainMatrix_to_sparse`
  - `/testbed/sympy/polys/matrices/tests/test_domainmatrix.py:669` — `test_DomainMatrix_content_primitive`
  - `/testbed/sympy/polys/matrices/tests/test_domainmatrix.py:757` — `test_DomainMatrix_nullspace`
- **Analogous tests**: `test_DomainMatrix_to_dense` (line 272), `test_DomainMatrix_rref` (line 688), `test_DomainMatrix_columnspace` (line 728), `test_DomainMatrix_rowspace` (line 737)

## Rubric Scores

### Seed rubric: Requirement coverage

| ID | Rubric | Score | Evidence | Affected R/E/C |
|----|--------|-------|----------|-----------------|
| RC1 | Every atomic requirement has traceable R/G/C path with executable observations | PASS | R1→C1,C2,C3,C4; R2→C3; R3→C5,C6,C7; R4→(gap); R5→C8,C9; R6→C10,C11,C12; R7→C4; R8→C9,C10,C12 | R4 untested (see Finding 1) |
| RC2 | IR contracts all present in specs | PARTIAL | C1–C12 are in specs; C13–C23 are arch-spec only; `nullspace_from_rref` on DomainMatrix is tested in behavior spec C4 but has no arch contract | C4, E2 |

### Seed rubric: Requirement fidelity

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| RF1 | Tests assert task-supported relation, not stronger/looser proxy | PASS | C1 uses exact expected `DomainMatrix([[QQ(-1), QQ(1)]], …)` matching repo test; C5 uses exact `(ZZ(2), DM([[1,2],[3,4]],ZZ))` |
| RF2 | divide_last=True success path asserts correct normalization | FAIL | R1 describes divide_last=True behavior but neither spec tests it on a field domain (see Finding 2) |

### Seed rubric: Caller binding and architecture

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| CB1 | Material CALL edges execute through actual public entry | PASS | C1–C4 call `A.nullspace()`; C5–C7 call `M.primitive()`; C8–C9 call `A.to_sdm()`; C10–C12 call `A.to_sparse()` |
| CB2 | Helper-only / symbol-existence checks are not the only verification | PASS | C13 exercises `content()` live; C15 exercises `rref()` live; C16–C23 are import-boundary checks for pre-existing issues |
| CB3 | `nullspace_from_rref` on DomainMatrix has architecture contract | FAIL | Behavior spec C4 and repo test line 773 call `Arref.nullspace_from_rref()` but arch spec has no equivalent to C15 for this method (see Finding 3) |

### Seed rubric: Dataflow and lifecycle

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| DL1 | Tests distinguish correct forwarding from wrong implementations | PASS | C9 checks exact SDM dict; C10 checks rep format change; C11 checks identity; C12 checks round-trip |
| DL2 | to_flat_nz delegation is verified | FAIL | C14 checks return types but not that delegation goes through `self.rep.to_flat_nz()` (see Finding 4) |

### Seed rubric: Failure and compatibility

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| FC1 | Invalid/failure paths use expected exception and semantics | PARTIAL | C3 correctly tests `DMNotAField` for non-field divide_last; R4 failure path (no-gcd domain) untested (Finding 1); R1 divide_last=True success path untested (Finding 2) |
| FC2 | Empty/edge matrices tested | PASS | C15 includes empty matrix `DomainMatrix([], (0, 1), QQ)`; DDM/SDM nullspace_from_rref handle empty/no-pivot cases |

### Seed rubric: Static-issue closure

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| SI1 | Every static issue has runtime observation or explicit disposition | PARTIAL | C13 covers `dup_content` in domainmatrix.py (but weakly — see Finding 5); C16–C23 cover remaining static issues with import-boundary checks; `dup_content` call binding is not verified as importable |
| SI2 | C13 does not verify `dup_content` is importable | FAIL | C13 only checks `content()` returns correct value, not that `dup_content` as called at line 2115 resolves (see Finding 5) |

### Seed rubric: Oracle strength

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| OS1 | Assertions use exact values | PASS | C1, C2, C5 use exact DomainMatrix equality; C6 uses algebraic identity; C7 uses exact `content() == ZZ(1)` |
| OS2 | C8 is type-only (weak) | ACCEPT | C8 only checks `isinstance(sdm, SDM)` but C9 compensates with exact element verification |
| OS3 | C16–C23 are import-only (weak but intentional) | ACCEPT | These are pre-existing broken-dependency checks; the IR explicitly dispositions them as out-of-scope but needed for nullspace to function; import checks are appropriate for arch-level verification |

### Repository-test-derived domain rubrics

| ID | Source test | Perspective | Score | Notes |
|----|------------|-------------|-------|-------|
| DR1 | `test_DomainMatrix_to_sparse:267` | Sparse conversion must preserve exact rep dict shape and element domain types | PASS | C10 checks `.rep` equality with `{0: {0: 1}, 1: {1: 2}}` matching test pattern |
| DR2 | `test_DomainMatrix_content_primitive:669` | primitive returns exact `(content, matrix)` tuple | PASS | C5 matches exact expected values |
| DR3 | `test_DomainMatrix_nullspace:757` | nullspace over QQ returns exact basis; nullspace over ZZ uses rref_den path | PASS | C1, C2, C4 align with repo test |
| DR4 | `test_DomainMatrix_rref:688` | rref over QQ returns `(rref_matrix, pivots)`; empty matrix handled | PASS | C15 tests empty-matrix edge case |
| DR5 | `test_DomainMatrix_to_dense:272` | to_dense on sparse returns self (idempotence) | PASS | C11 mirrors the to_dense idempotence pattern for to_sparse |
| DR6 | `test_DomainMatrix_columnspace:728` | columnspace/rowspace raise DMNotAField for non-field domains | ADAPT | Pattern confirms C3 exception behavior but neither columnspace nor rowspace has a divide_last equivalent — no analogous test for the normalization success path |

## Findings

### Finding 1: missing_requirement

- **Affected IDs**: R4, C5, C6, C7
- **Static issue**: None (R4 has no explicit static issue; the task docstring says "For domains without gcd, this method will raise an error.")
- **Repository evidence**: `test_DomainMatrix_content_primitive` at `/testbed/sympy/polys/matrices/tests/test_domainmatrix.py:669` only tests `primitive()` over ZZ (which supports gcd). The `content()` method at domainmatrix.py:2092 similarly only documents success over ZZ. No test exercises the failure path where the domain lacks gcd.
- **Gap**: The IR's R4 states: "The primitive method requires the ground domain to support gcd. For domains without gcd, an error shall be raised." The behavior spec tests C5, C6, C7 — all success cases over ZZ. Neither spec includes a test that calls `primitive()` on a domain without gcd support (e.g., `EX` or a polynomial ring without `gcd`) and asserts an error is raised. The task description explicitly notes this requirement, and without a test a plausible implementation could silently produce incorrect results or crash with an unexpected exception.
- **Rework instruction**: Add a behavior test (e.g., C7b) that constructs a DomainMatrix over a domain that does not support `gcd` (such as `EX`), calls `.primitive()`, and asserts that an appropriate error is raised (the exact exception class is not specified in the task, but `DMDomainError` or a descriptive `NotImplementedError` would be reasonable). This closes the R4 acceptance gap.

### Finding 2: missing_requirement

- **Affected IDs**: R1, C1, C2, C3, C4
- **Static issue**: None
- **Repository evidence**: `test_DomainMatrix_nullspace` at `/testbed/sympy/polys/matrices/tests/test_domainmatrix.py:757-766` tests `nullspace(divide_last=True)` only for the failure case (`raises(DMNotAField, lambda: A.nullspace(divide_last=True))` over ZZ). The success case — calling `nullspace(divide_last=True)` on a field domain — is never tested. The task docstring explicitly describes: "If True, then each row is divided by its final element; the domain must be a field in this case." The example in the docstring shows `M.to_DM().to_field().nullspace(divide_last=True).to_Matrix().transpose()` producing a normalized result.
- **Gap**: The IR's R1 states: "When divide_last=True, each row of the nullspace basis is divided by its final (rightmost) element, requiring a field domain." C3 tests the failure case (DMNotAField on non-field), but there is no test that verifies the normalization behavior actually works on a field domain. A plausible incorrect implementation could raise DMNotAField unconditionally when divide_last=True (passing C3), or could divide by the wrong element, or could corrupt the basis. The repository test at line 757 also omits this path, but the docstring examples provide an oracle.
- **Rework instruction**: Add a behavior test (e.g., C3b) that constructs a DomainMatrix over QQ with a non-trivial nullspace, calls `.nullspace(divide_last=True)`, and asserts (a) no exception is raised, (b) each row's last non-zero element equals the domain's unit (e.g., `QQ(1)`), and (c) the nullspace still satisfies `A * nullspace^T == 0`. Example fixture: `A = DM([[QQ(2), QQ(-2), QQ(0)], [QQ(4), QQ(-4), QQ(0)]], QQ)` — nullspace should have last element normalized to 1 after divide_last.

### Finding 3: missing_requirement

- **Affected IDs**: R7, C4, E2
- **Static issue**: None directly, but related to the fact that `nullspace_from_rref` exists on DDM/SDM/DFM but not on DomainMatrix.
- **Repository evidence**: `test_DomainMatrix_nullspace` at `/testbed/sympy/polys/matrices/tests/test_domainmatrix.py:773-776`:
  ```python
  assert Arref.nullspace_from_rref() == Anull
  assert Arref.nullspace_from_rref(pivots) == Anull
  assert Arref.to_sparse().nullspace_from_rref() == Anull.to_sparse()
  assert Arref.to_sparse().nullspace_from_rref(pivots) == Anull.to_sparse()
  ```
  Here `Arref` is a `DomainMatrix` returned by `rref_den()`. The behavior spec C4 mirrors this test exactly. However, the architecture spec has no contract checking that `DomainMatrix.nullspace_from_rref` exists and correctly delegates to `self.rep.nullspace_from_rref(pivots)`.
- **Gap**: The architecture spec includes C15 (`check_rref_method_exists_and_delegates`) for `rref()` but has no equivalent for `nullspace_from_rref()`. The IR's E2 describes this delegation chain (`N2 → E2 → N10/N11/N12`), and the IR's R1 uncertainty notes explicitly: "The nullspace_from_rref helper exists on DDM, SDM, DFM but not yet plumbed through DomainMatrix." The behavior spec C4 will fail at runtime if `DomainMatrix.nullspace_from_rref` is missing or incorrectly delegates. An architecture check would catch this earlier and more precisely.
- **Rework instruction**: Add an architecture check (e.g., C15b) that: (a) verifies `DomainMatrix.nullspace_from_rref` exists as a method, (b) calls it on a DomainMatrix wrapping a sparse rep and a dense rep, and (c) verifies the return type is `DomainMatrix` (not a tuple — the underlying reps return `(basis, nonpivots)` but the DomainMatrix wrapper should discard `nonpivots` to match the test expectation at line 773). Compare results against calling `rep.nullspace_from_rref(pivots)` directly on the internal rep to verify correct delegation.

### Finding 4: weak_constraint

- **Affected IDs**: C14, E13
- **Static issue**: None directly; `to_flat_nz` is called at domainmatrix.py:1997, 2082, 2114 but not defined on DomainMatrix.
- **Repository evidence**: `content()` at domainmatrix.py:2114 calls `self.to_flat_nz()`. Currently this raises `AttributeError` at runtime. DDM.to_flat_nz (ddm.py:256), SDM.to_flat_nz (sdm.py:398), and DFM.to_flat_nz (_dfm.py:263) all exist and return `(elements, data)`.
- **Gap**: The arch spec's `check_to_flat_nz_delegation` (C14) calls `A_d.to_flat_nz()` and checks that `elements_d` is a list containing expected values and `data_d` is a tuple. This is essentially a behavior test. It does **not** verify that `DomainMatrix.to_flat_nz` actually delegates to `self.rep.to_flat_nz()`. A wrong implementation that computes `to_flat_nz` by iterating over `.to_list_flat()` directly (bypassing the rep method) would pass this check. The IR's E13 explicitly states this should be a CALL delegation: `DomainMatrix.to_flat_nz → rep.to_flat_nz()`.
- **Rework instruction**: Strengthen C14 to verify delegation. For a DomainMatrix `A_d` with dense rep, compare `A_d.to_flat_nz()` against `A_d.rep.to_flat_nz()` — both should return identical `(elements, data)`. Do the same for a DomainMatrix `A_s` with sparse rep. This confirms the method delegates rather than reimplements. Example:
  ```python
  A_d = DomainMatrix([[ZZ(2), ZZ(4)], [ZZ(6), ZZ(8)]], (2, 2), ZZ)
  elems_dm, data_dm = A_d.to_flat_nz()
  elems_rep, data_rep = A_d.rep.to_flat_nz()
  assert elems_dm == elems_rep and data_dm == data_rep
  ```

### Finding 5: weak_constraint

- **Affected IDs**: C13, E8, static issue "`dup_content` is used but not defined or imported in this file" for domainmatrix.py
- **Static issue**: `sympy/polys/matrices/domainmatrix.py` — `dup_content` used at line 2115 as bare function `dup_content(elements, K)`, but `dup_content` exists only as a method on `Domain` classes in `compatibility.py:1126`, not as a standalone importable function.
- **Repository evidence**: `grep -rn "def dup_content" sympy/` returns only `sympy/polys/compatibility.py:1126` (a method `Domain.dup_content`). No standalone `dup_content` function exists. The call at domainmatrix.py:2115 `return dup_content(elements, K)` will raise `NameError` at runtime. The `content()` method at line 2092 is therefore broken.
- **Gap**: The arch spec's `check_dup_content_caller_binding` (C13) calls `M.content()` and asserts the return value is `ZZ(2)`. But this test only exercises the `content()` method end-to-end — it does not verify that `dup_content` is properly imported or callable. An implementer could work around the missing import by inlining a gcd computation specifically for this test case (e.g., `return ZZ(2)`) without fixing the actual `dup_content` call path at line 2115. The static issue explicitly identifies `dup_content` as an unresolved symbol, and the architecture check should verify the import binding, not just the behavioral outcome.
- **Rework instruction**: Strengthen C13 to verify the import binding. Either: (a) add an explicit import check `from sympy.polys.compatibility import dup_content` (or wherever `dup_content` should be importable from) and assert it is callable; or (b) test `content()` on at least two different matrices with different gcd values to rule out a hardcoded return. The ideal fix for the implementation is to either import `dup_content` from its defining module or change the call to `K.dup_content(elements)`. The architecture check should verify the chosen resolution path. Example:
  ```python
  # Verify dup_content is importable as called at domainmatrix.py:2115
  try:
      from sympy.polys.densetools import dup_content
      assert callable(dup_content)
  except ImportError:
      # If not importable as standalone, verify the alternative works
      from sympy import ZZ
      assert hasattr(ZZ, 'dup_content') or hasattr(ZZ, 'gcd')
  ```

## Decision

**Decision: REWORK**

Five findings exist (three `missing_requirement`, two `weak_constraint`). All must be addressed before the specs provide sufficient discriminating constraints for a correct implementation. The rework instructions above describe concrete observations to add to the behavior and architecture specs.
