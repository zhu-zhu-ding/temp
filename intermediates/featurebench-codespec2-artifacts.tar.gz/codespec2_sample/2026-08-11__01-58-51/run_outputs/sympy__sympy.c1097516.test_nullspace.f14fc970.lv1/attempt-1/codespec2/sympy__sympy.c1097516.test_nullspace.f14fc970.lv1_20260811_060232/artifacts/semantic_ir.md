# Semantic IR

## L1. Requirement Obligations

### R1: nullspace — compute basis for nullspace
- **Type**: Behavior
- **Statement**: `DomainMatrix.nullspace(divide_last=False)` returns a `DomainMatrix` whose rows form a basis for the nullspace of `self`. For field domains when `divide_last=False`, RREF is computed via `rref()` and the nullspace extracted from RREF pivots. For non-field (ring) domains when `divide_last=False`, RREF is computed via `rref_den()` and the denominator discarded; the nullspace is extracted from the fraction-free RREF. When `divide_last=True`, each row of the nullspace basis is divided by its final (rightmost) element, requiring a field domain.
- **Task Evidence**: Interface Description 1 — `nullspace` method docstring with parameters, returns, raises, examples, notes.
- **Acceptance**: 
  - Over QQ (field): `A.nullspace()` returns basis, `A * A.nullspace().transpose()` is zero matrix.
  - Over ZZ (ring): `B.nullspace()` returns basis without division; `B.nullspace(divide_last=True)` raises `DMNotAField`.
  - The returned matrix has `shape[0] == nullity`, `shape[1] == cols`.
  - `nullspace().primitive()` returns `(content, primitive_basis)` over rings with gcd.
- **Repository Evidence**: Test `test_DomainMatrix_nullspace` at `/testbed/sympy/polys/matrices/tests/test_domainmatrix.py:757`; `test_DomainMatrix_content_primitive` at line 669; existing `DMNotAField` in `/testbed/sympy/polys/matrices/exceptions.py:28`.
- **Uncertainty**: The exact helper delegation chain (`rref` → rep method, `rref_den` → `_dm_rref_den`) is partially present but `rref` is not defined on `DomainMatrix` (only on DDM/SDM). The `nullspace_from_rref` helper exists on DDM, SDM, DFM but not yet plumbed through DomainMatrix.

### R2: nullspace — divide_last field requirement and error path
- **Type**: Failure
- **Statement**: When `divide_last=True`, the domain must be a field. If the domain is not a field, `DMNotAField` is raised with message "Cannot normalize vectors over a non-field".
- **Task Evidence**: Interface Description 1 — Raises section and example showing `DMNotAField` traceback.
- **Acceptance**: `DMNotAField` raised for `ZZ` domain with `divide_last=True`.
- **Repository Evidence**: Test at line 766; `DMNotAField` class in `/testbed/sympy/polys/matrices/exceptions.py:28`.
- **Uncertainty**: Exact exception message string.

### R3: primitive — factor out gcd of all matrix elements
- **Type**: Behavior
- **Statement**: `DomainMatrix.primitive()` returns a tuple `(content, M_primitive)` where `content` is a `DomainElement` (the gcd of all matrix elements) and `M_primitive` is a `DomainMatrix` such that `content * M_primitive == self`. The primitive matrix has `content() == 1`.
- **Task Evidence**: Interface Description 1 — `primitive` method docstring with examples.
- **Acceptance**:
  - `M = DM([[2, 4], [4, 12]], ZZ); content, M_primitive = M.primitive(); content == ZZ(2); M_primitive == DM([[1, 2], [2, 6]], ZZ)`.
  - `content * M_primitive == M`.
  - `M_primitive.content() == ZZ(1)`.
- **Repository Evidence**: Test `test_DomainMatrix_content_primitive` at line 669; existing `content()` method definition at line 2092; `dup_content` used at line 2115.
- **Uncertainty**: `dup_content` is not importable as a standalone function — it exists only as a method on `Domain` in `compatibility.py:1126`. The `to_flat_nz`/`from_flat_nz` delegation from `DomainMatrix` to its `rep` is missing.

### R4: primitive — requires gcd in ground domain
- **Type**: Failure
- **Statement**: The `primitive` method requires the ground domain to support `gcd`. For domains without gcd, an error shall be raised (the interface does not specify exact exception type).
- **Task Evidence**: Interface Description 1 — Notes section: "The method requires that the ground domain supports gcd computation. For domains without gcd, this method will raise an error."
- **Acceptance**: Error raised for domains lacking gcd.
- **Repository Evidence**: `content()` method (line 2092) similarly requires gcd; tests do not cover no-gcd domains explicitly.
- **Uncertainty**: Exact exception class and message for no-gcd domains; the task does not specify a dedicated exception type.

### R5: to_sdm — return SDM representation
- **Type**: Interface
- **Statement**: `DomainMatrix.to_sdm()` returns the underlying `SDM` (Sparse Domain Matrix) representation of `self`, regardless of the current internal format. The returned value is an `SDM` instance, not a `DomainMatrix`.
- **Task Evidence**: Interface Description 1 — `to_sdm` method docstring.
- **Acceptance**:
  - `A = DomainMatrix([[1, 0],[0, 2]], (2, 2), QQ); sdm = A.to_sdm(); type(sdm) is SDM`.
  - `sdm == {0: {0: 1}, 1: {1: 2}}`.
- **Repository Evidence**: SDM class at `/testbed/sympy/polys/matrices/sdm.py`; pattern from `to_ddm` at line 638 delegating to `self.rep.to_ddm()`.
- **Uncertainty**: None — pattern is clearly established by `to_ddm`.

### R6: to_sparse — convert to sparse DomainMatrix
- **Type**: Interface / State
- **Statement**: `DomainMatrix.to_sparse()` returns a new `DomainMatrix` whose internal representation is sparse (SDM). If the matrix is already sparse, it returns `self` unchanged. The returned DomainMatrix preserves the same domain and shape.
- **Task Evidence**: Interface Description 1 — `to_sparse` method docstring with example showing rep format change from dense list to SDM dict.
- **Acceptance**:
  - `A = DomainMatrix([[1, 0],[0, 2]], (2, 2), QQ); A.rep` is dense; `B = A.to_sparse(); B.rep == {0: {0: 1}, 1: {1: 2}}`.
  - Calling `to_sparse()` on an already-sparse matrix returns the same object.
- **Repository Evidence**: Test `test_DomainMatrix_to_sparse` at line 267; `to_dense` at line 614 returns `self` when already dense; pattern established.
- **Uncertainty**: Whether `to_sparse` should return `self` (identity) or a copy for already-sparse matrices — `to_dense` returns `self` for already-dense, so consistent behavior is to return `self`.

### R7: nullspace — domain compatibility via rref_den for non-fields
- **Type**: Dataflow
- **Statement**: For non-field domains, `nullspace` uses `rref_den()` which returns a fraction-free RREF, a denominator, and pivots. The denominator is discarded and `nullspace_from_rref` is called on the RREF matrix to extract the nullspace. This avoids fractions during elimination, preserving ring arithmetic.
- **Task Evidence**: Interface Description 1 — Notes section: "For non-field domains, the computation uses `rref_den` to avoid fractions during the elimination process."
- **Acceptance**: `B = DM([[6, -3], [4, -2]], ZZ); B.nullspace() == DomainMatrix([[3, 6]], (1, 2), ZZ)`.
- **Repository Evidence**: `rref_den` defined at line 2242; `_dm_rref_den` imported from `.rref` at line 61; `nullspace_from_rref` on SDM (line 1159) and DDM (line 879).
- **Uncertainty**: The delegation path `DomainMatrix.nullspace` → `self.rref_den()` → extract RREF → `nullspace_from_rref` is partially present — `rref` on DomainMatrix is missing.

### R8: to_sdm / to_sparse — conversion preservation
- **Type**: Dataflow
- **Statement**: Conversions between dense and sparse representations preserve all elements (including zeros), domain type, and matrix shape. The mathematical content of the matrix is unchanged.
- **Task Evidence**: Task document "Format Conversion": "Enable seamless conversion between dense and sparse matrix representations while preserving mathematical properties and domain constraints."
- **Acceptance**: After `to_sparse()` or `to_sdm()`, the elements are identical; `to_dense().to_sparse() == to_sparse()` (round-trip).
- **Repository Evidence**: Test `test_DomainMatrix_to_sparse` at line 267; `to_dense` at line 614; SDM ↔ DDM conversion methods in sdm.py and ddm.py.
- **Uncertainty**: None.

## L2. Functional Design Graph

### N1: DomainMatrix (public entry)
- **Kind**: Class
- **Repository Evidence**: `/testbed/sympy/polys/matrices/domainmatrix.py:89`

### N2: DomainMatrix.nullspace
- **Kind**: Method (to be implemented)
- **Repository Evidence**: Interface Description 1; test at line 757

### N3: DomainMatrix.primitive
- **Kind**: Method (to be implemented)
- **Repository Evidence**: Interface Description 1; test at line 669

### N4: DomainMatrix.to_sdm
- **Kind**: Method (to be implemented)
- **Repository Evidence**: Interface Description 1

### N5: DomainMatrix.to_sparse
- **Kind**: Method (to be implemented)
- **Repository Evidence**: Interface Description 1; test at line 267

### N6: DomainMatrix.rref
- **Kind**: Method (missing — needed by nullspace and rank)
- **Repository Evidence**: Called at line 1262 (`rank()`); defined on DDM (ddm.py:832) and SDM (sdm.py:980) but not on DomainMatrix.

### N7: DomainMatrix.rref_den
- **Kind**: Method (exists)
- **Repository Evidence**: `/testbed/sympy/polys/matrices/domainmatrix.py:2242`

### N8: DomainMatrix.content
- **Kind**: Method (exists, broken — calls missing `self.to_flat_nz()`)
- **Repository Evidence**: `/testbed/sympy/polys/matrices/domainmatrix.py:2092`

### N9: DomainMatrix.to_flat_nz / from_flat_nz
- **Kind**: Methods (missing on DomainMatrix, exist on DDM/SDM/DFM)
- **Repository Evidence**: Called in `content` (line 2114), `cancel_denom` (line 1997); defined on SDM (sdm.py:398), DDM (ddm.py:256), DFM (_dfm.py:263)

### N10: DDM.nullspace / DDM.nullspace_from_rref
- **Kind**: Methods (exist)
- **Repository Evidence**: `/testbed/sympy/polys/matrices/ddm.py:865,879`

### N11: SDM.nullspace / SDM.nullspace_from_rref
- **Kind**: Methods (exist)
- **Repository Evidence**: `/testbed/sympy/polys/matrices/sdm.py:1125,1159`

### N12: DFM.nullspace / DFM.nullspace_from_rref
- **Kind**: Methods (exist)
- **Repository Evidence**: `/testbed/sympy/polys/matrices/_dfm.py:821,843`

### N13: dup_content (helper)
- **Kind**: Function (missing as standalone — exists as Domain method)
- **Repository Evidence**: Called at domainmatrix.py:2115; defined as method at compatibility.py:1126; static issue flagged.

### N14: dup_convert (helper)
- **Kind**: Function (missing import)
- **Repository Evidence**: Called at domainmatrix.py:3718; exists in `sympy.polys.densebasic`; static issue flagged.

### N15: DMNotAField (error class)
- **Kind**: Exception class
- **Repository Evidence**: `/testbed/sympy/polys/matrices/exceptions.py:28`

### N16: SDM.to_sdm / DDM.to_sdm
- **Kind**: Methods (exist on reps)
- **Repository Evidence**: SDM.to_sdm at sdm.py:614; DDM has `to_sdm()` pattern.

### N17: _dm_rref_den (helper)
- **Kind**: Function
- **Repository Evidence**: `/testbed/sympy/polys/matrices/rref.py:89`; imported at domainmatrix.py:61

### E1: DomainMatrix.nullspace -> DomainMatrix.rref (or rref_den)
- **Kind**: CALL
- **Condition**: When `divide_last=False` and domain is a field → `self.rref()`; when domain is not a field → `self.rref_den()`.
- **Transfer**: Returns (RREF matrix, pivots) or (RREF matrix, denominator, pivots).
- **Evidence**: Interface Description 1 Notes; DDM.nullspace pattern at ddm.py:865.
- **Obligations**: R1, R2, R7

### E2: DomainMatrix.nullspace -> nullspace_from_rref (on RREF matrix)
- **Kind**: CALL
- **Condition**: After obtaining RREF and pivots.
- **Transfer**: RREF matrix and pivots → nullspace basis rows.
- **Evidence**: DDM.nullspace pattern at ddm.py:877; SDM.nullspace at sdm.py:1125.
- **Obligations**: R1, R7

### E3: DomainMatrix.nullspace -> DMNotAField
- **Kind**: CONTROL (error path)
- **Condition**: `divide_last=True` and domain is not a field.
- **Transfer**: Raise `DMNotAField` exception.
- **Evidence**: Interface Description 1 Raises section; test at line 766.
- **Obligations**: R2

### E4: DomainMatrix.nullspace -> divide-last normalization
- **Kind**: DATA
- **Condition**: `divide_last=True` and domain is a field.
- **Transfer**: Each row of the nullspace basis is divided by its final (rightmost non-zero) element.
- **Evidence**: Interface Description 1 docstring.
- **Obligations**: R1

### E5: DomainMatrix.primitive -> DomainMatrix.content
- **Kind**: CALL
- **Condition**: Always — compute gcd of all elements.
- **Transfer**: Returns `DomainElement` (the gcd).
- **Evidence**: Interface Description 1: "content * M_primitive == self".
- **Obligations**: R3

### E6: DomainMatrix.primitive -> element-wise division
- **Kind**: DATA
- **Condition**: After obtaining content.
- **Transfer**: Divide every element of the matrix by the content; return `(content, M_primitive)`.
- **Evidence**: Interface Description 1; existing `content()` at line 2092.
- **Obligations**: R3, R4

### E7: DomainMatrix.content -> DomainMatrix.to_flat_nz
- **Kind**: CALL
- **Condition**: To collect all non-zero elements for gcd computation.
- **Transfer**: Returns `(elements_list, data_dict)`.
- **Evidence**: domainmatrix.py:2114 `elements, _ = self.to_flat_nz()`.
- **Obligations**: R3

### E8: DomainMatrix.content -> dup_content
- **Kind**: CALL
- **Condition**: After obtaining flat element list.
- **Transfer**: Returns gcd of elements over the domain.
- **Evidence**: domainmatrix.py:2115 `return dup_content(elements, K)`.
- **Obligations**: R4

### E9: DomainMatrix.to_sdm -> rep.to_sdm()
- **Kind**: CALL
- **Condition**: Always.
- **Transfer**: Returns `SDM` instance.
- **Evidence**: Pattern from `to_ddm` at domainmatrix.py:661 `return self.rep.to_ddm()`.
- **Obligations**: R5

### E10: DomainMatrix.to_sparse -> rep.to_sdm() + from_rep
- **Kind**: CALL
- **Condition**: When current rep is not sparse; returns `self` when already sparse.
- **Transfer**: Converts rep to SDM, wraps in new DomainMatrix via `from_rep`.
- **Evidence**: Pattern from `to_dense` at domainmatrix.py:614-636.
- **Obligations**: R6, R8

### E11: DomainMatrix.to_sparse -> self (identity)
- **Kind**: CONTROL
- **Condition**: When `self.rep.fmt == 'sparse'`.
- **Transfer**: Return `self` unchanged.
- **Evidence**: `to_dense` returns `self` when already dense (line 631-632).
- **Obligations**: R6

### E12: DomainMatrix.rref -> rep.rref()
- **Kind**: CALL (to be implemented)
- **Condition**: Delegates to underlying rep's rref method.
- **Transfer**: Returns `(rref_matrix, pivots)`.
- **Evidence**: Pattern from `copy`, `transpose`, `to_ddm`; DDM.rref at ddm.py:832, SDM.rref at sdm.py:980.
- **Obligations**: R1, R7

### E13: DomainMatrix.to_flat_nz -> rep.to_flat_nz()
- **Kind**: CALL (to be implemented)
- **Condition**: Delegates to underlying rep.
- **Transfer**: Returns `(elements, data)` tuple.
- **Evidence**: Defined on SDM (sdm.py:398), DDM (ddm.py:256), DFM (_dfm.py:263); called in DomainMatrix methods.
- **Obligations**: R3

### E14: DomainMatrix.from_flat_nz -> rep.from_flat_nz() + from_rep
- **Kind**: CALL (to be implemented)
- **Condition**: Used to reconstruct matrix after element manipulation.
- **Transfer**: Returns new DomainMatrix.
- **Evidence**: Defined on SDM (sdm.py:436), DDM (ddm.py:289), DFM (_dfm.py:268).
- **Obligations**: R3

## L3. Verifiable Contracts

### C1: nullspace over QQ (field, no normalize)
- **Type**: Behavior
- **Subject**: `DomainMatrix.nullspace`
- **Relation**: For matrix `A = DomainMatrix([[QQ(1), QQ(1)], [QQ(1), QQ(1)]], (2, 2), QQ)`, `A.nullspace()` returns `DomainMatrix([[QQ(-1), QQ(1)]], (1, 2), QQ)`.
- **Expected**: Basis matrix with rows spanning nullspace.
- **Evidence**: Test at test_domainmatrix.py:758-760.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.nullspace`
- **Obligations**: R1
- **Graph**: N2 → E1 → N6 → E12; N2 → E2 → N10/N11/N12

### C2: nullspace over ZZ (ring, no normalize)
- **Type**: Behavior
- **Subject**: `DomainMatrix.nullspace`
- **Relation**: For matrix `A = DomainMatrix([[ZZ(1), ZZ(1)], [ZZ(1), ZZ(1)]], (2, 2), ZZ)`, `A.nullspace()` returns `DomainMatrix([[ZZ(-1), ZZ(1)]], (1, 2), ZZ)`.
- **Expected**: Basis over ring via rref_den path.
- **Evidence**: Test at test_domainmatrix.py:762-764.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.nullspace`
- **Obligations**: R1, R7
- **Graph**: N2 → E1 → N7 → N17; N2 → E2

### C3: nullspace divide_last=True over non-field raises DMNotAField
- **Type**: Failure
- **Subject**: `DomainMatrix.nullspace(divide_last=True)`
- **Relation**: When domain is ZZ (non-field), calling with `divide_last=True` raises `DMNotAField`.
- **Expected**: `DMNotAField` exception raised.
- **Evidence**: Test at test_domainmatrix.py:766.
- **Observe**: EXCEPTION
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.nullspace`
- **Obligations**: R2
- **Graph**: N2 → E3 → N15

### C4: nullspace with rref_den over ZZ (larger values)
- **Type**: Behavior
- **Subject**: `DomainMatrix.nullspace` via `rref_den`
- **Relation**: For `A = DomainMatrix([[ZZ(2), ZZ(2)], [ZZ(2), ZZ(2)]], (2, 2), ZZ)`, `A.rref_den()` returns `(rref, ZZ(2), (0,))` and `rref.nullspace_from_rref()` returns `DomainMatrix([[ZZ(-2), ZZ(2)]], (1, 2), ZZ)`.
- **Expected**: Correct denominator, pivots, and nullspace from rref_den path.
- **Evidence**: Test at test_domainmatrix.py:768-776.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.rref_den` and `DomainMatrix.nullspace_from_rref` (via rep)
- **Obligations**: R7
- **Graph**: N2 → E1 → N7; N2 → E2

### C5: primitive returns (content, primitive_matrix)
- **Type**: Behavior
- **Subject**: `DomainMatrix.primitive`
- **Relation**: For `A = DM([[2, 4], [6, 8]], ZZ)`, `A.primitive()` returns `(ZZ(2), DM([[1, 2], [3, 4]], ZZ))`.
- **Expected**: Tuple of (gcd, reduced matrix).
- **Evidence**: Test at test_domainmatrix.py:669-674.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.primitive`
- **Obligations**: R3
- **Graph**: N3 → E5 → N8 → E7 → N9; N3 → E6

### C6: primitive * content == original
- **Type**: Behavior
- **Subject**: `DomainMatrix.primitive` algebraic identity
- **Relation**: `content * M_primitive == M` where `content, M_primitive = M.primitive()`.
- **Expected**: Identity holds.
- **Evidence**: Interface docstring example.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.primitive`
- **Obligations**: R3
- **Graph**: N3 → E6

### C7: primitive result has content 1
- **Type**: Behavior
- **Subject**: `DomainMatrix.primitive` postcondition
- **Relation**: `M_primitive.content() == domain.one` (unit element of domain).
- **Expected**: GCD of primitive matrix elements is the unit.
- **Evidence**: Interface docstring: `M_primitive.content() == ZZ(1)`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.primitive`
- **Obligations**: R3
- **Graph**: N3 → N8

### C8: to_sdm returns SDM instance
- **Type**: Interface
- **Subject**: `DomainMatrix.to_sdm`
- **Relation**: For any `DomainMatrix`, `to_sdm()` returns an `SDM` instance (not `DomainMatrix`).
- **Expected**: `type(result) is SDM`.
- **Evidence**: Interface Description 1.
- **Observe**: RETURN_VALUE (type check)
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.to_sdm`
- **Obligations**: R5
- **Graph**: N4 → E9 → N16

### C9: to_sdm preserves all elements
- **Type**: Dataflow
- **Subject**: `DomainMatrix.to_sdm`
- **Relation**: Elements accessible via SDM dict match original matrix elements.
- **Expected**: `A.to_sdm() == {0: {0: 1}, 1: {1: 2}}` for `A = DomainMatrix([[1, 0],[0, 2]], (2, 2), QQ)`.
- **Evidence**: Interface Description 1.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.to_sdm`
- **Obligations**: R5, R8
- **Graph**: N4 → E9

### C10: to_sparse converts dense to sparse DomainMatrix
- **Type**: State
- **Subject**: `DomainMatrix.to_sparse`
- **Relation**: For dense `A = DomainMatrix([[1, 0],[0, 2]], (2, 2), QQ)`, `A.to_sparse().rep == {0: {0: 1}, 1: {1: 2}}`.
- **Expected**: Internal rep changes from DDM to SDM; returned value is a `DomainMatrix`.
- **Evidence**: Test at test_domainmatrix.py:267-269.
- **Observe**: FIELD_READ (`.rep`)
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.to_sparse`
- **Obligations**: R6, R8
- **Graph**: N5 → E10

### C11: to_sparse on already-sparse returns self
- **Type**: State
- **Subject**: `DomainMatrix.to_sparse` idempotence
- **Relation**: Calling `to_sparse()` on an already-sparse DomainMatrix returns the same object (`self`).
- **Expected**: `A_sparse is A_sparse.to_sparse()` or equivalent.
- **Evidence**: Pattern from `to_dense` at domainmatrix.py:631-632; consistent with sparsity-preserving design.
- **Observe**: RETURN_VALUE (identity check)
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.to_sparse`
- **Obligations**: R6
- **Graph**: N5 → E11

### C12: to_sparse preserves round-trip with to_dense
- **Type**: Dataflow
- **Subject**: `DomainMatrix.to_sparse` ↔ `to_dense` round-trip
- **Relation**: `A.to_sparse().to_dense() == A` for any DomainMatrix A (when both methods exist).
- **Expected**: Mathematical equality preserved.
- **Evidence**: General conversion contract; `to_dense` already exists.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.to_sparse`, `DomainMatrix.to_dense`
- **Obligations**: R8
- **Graph**: N5 → E10

### C13: dup_content import resolved for content/primitive
- **Type**: Interface
- **Subject**: `dup_content` callable
- **Relation**: The `dup_content` function used in `content()` and needed by `primitive()` must be importable. Currently it is called as a bare function `dup_content(elements, K)` at domainmatrix.py:2115 but is not imported.
- **Expected**: Import resolution — either import from `sympy.polys.densetools` or implement inline using domain's gcd.
- **Evidence**: Static issue: `'dup_content' is used but not defined or imported in this file` for domainmatrix.py.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py`
- **Obligations**: R3, R4
- **Graph**: N8 → E8 → N13

### C14: to_flat_nz delegation from DomainMatrix to rep
- **Type**: Interface
- **Subject**: `DomainMatrix.to_flat_nz`
- **Relation**: Calling `self.to_flat_nz()` on a DomainMatrix must delegate to `self.rep.to_flat_nz()` and return `(elements, data)`.
- **Expected**: Method exists and delegates; returns flat non-zero element list and structural data dict.
- **Evidence**: Called at domainmatrix.py:1997, 2082, 2114; defined on SDM/DDM/DFM; not yet defined on DomainMatrix.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.to_flat_nz`
- **Obligations**: R3
- **Graph**: N9 → E13

### C15: DomainMatrix.rref method exists and delegates
- **Type**: Interface
- **Subject**: `DomainMatrix.rref`
- **Relation**: `self.rref()` called in `rank()` (line 1262) and needed by `nullspace()` must delegate to `self.rep.rref()`.
- **Expected**: Method returns `(rref_matrix, pivots)`.
- **Evidence**: Called at domainmatrix.py:1262; DDM.rref at ddm.py:832; SDM.rref at sdm.py:980; missing on DomainMatrix.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py` — `DomainMatrix.rref`
- **Obligations**: R1
- **Graph**: N6 → E12

### C16: Static issue closure — sdm_nullspace_from_rref in linsolve.py
- **Type**: Interface
- **Subject**: `sdm_nullspace_from_rref` in `/testbed/sympy/polys/matrices/linsolve.py`
- **Relation**: The static issue reports `sdm_nullspace_from_rref` used but not defined/imported in linsolve.py. This function is called at linsolve.py:97. It must be importable.
- **Expected**: Import resolution from SDM module or inline definition.
- **Evidence**: Static issue; linsolve.py:97 calls `sdm_nullspace_from_rref(Arref, K.one, nsyms, pivots, nzcols)`.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/linsolve.py`
- **Obligations**: R7
- **Graph**: N11 → linsolve.py caller

**Disposition**: This is a pre-existing missing dependency. The `sdm_nullspace_from_rref` function signature `(B, one, ncols, pivots, nzcols)` differs from `SDM.nullspace_from_rref(A, pivots=None)`. This appears to be a lower-level helper that should be defined in `sdm.py`. This is out of scope for the current task unless implementing `nullspace` requires it. The `nullspace` method on `DomainMatrix` uses `rref_den` and `nullspace_from_rref` at the rep level, not `sdm_nullspace_from_rref` directly.

### C17: Static issue closure — _dm_rref_choose_method_QQ in rref.py
- **Type**: Interface
- **Subject**: `_dm_rref_choose_method_QQ` in `/testbed/sympy/polys/matrices/rref.py`
- **Relation**: Static issue reports this function used but not defined. Called at rref.py:254.
- **Expected**: Function must be defined.
- **Evidence**: Static issue.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/rref.py`
- **Obligations**: R1
- **Graph**: N17 → rref.py internals

**Disposition**: This is a pre-existing broken dependency in the RREF subsystem. The function is called in `_dm_rref_choose_method` at rref.py:254. Its absence means `rref_den` with `method='auto'` over QQ would fail. This must be resolved for `nullspace` to work correctly over QQ.

### C18: Static issue closure — _dm_rref_den_FF in rref.py
- **Type**: Interface
- **Subject**: `_dm_rref_den_FF` in `/testbed/sympy/polys/matrices/rref.py`
- **Relation**: Static issue reports this function used but not defined. Called at rref.py:115,138.
- **Expected**: Function must be defined.
- **Evidence**: Static issue.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/rref.py`
- **Obligations**: R1, R7
- **Graph**: N17 → rref.py internals

**Disposition**: Same as C17 — pre-existing broken dependency in RREF subsystem needed for fraction-free RREF over fields.

### C19: Static issue closure — _dm_elements in rref.py
- **Type**: Interface
- **Subject**: `_dm_elements` in `/testbed/sympy/polys/matrices/rref.py`
- **Relation**: Static issue reports this function used but not defined.
- **Expected**: Function must be defined.
- **Evidence**: Static issue.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/rref.py`
- **Obligations**: R1
- **Graph**: N17 → rref.py internals

**Disposition**: Pre-existing broken dependency.

### C20: Static issue closure — ddm_irref in ddm.py and rref.py
- **Type**: Interface
- **Subject**: `ddm_irref` in `/testbed/sympy/polys/matrices/ddm.py` and `rref.py`
- **Relation**: Used at ddm.py:846 and rref.py:212 but not defined in `/testbed/sympy/polys/matrices/dense.py`.
- **Expected**: Function must be defined.
- **Evidence**: Static issue; grep confirms no `def ddm_irref` in dense.py.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/dense.py`
- **Obligations**: R1, R7
- **Graph**: N10 → ddm.py rref; N17 → rref.py _dm_rref_GJ_dense

**Disposition**: Pre-existing broken dependency. `ddm_irref` is the dense implementation of fraction-free Gaussian elimination. Without it, DDM.rref() and rref_den with GJ_dense method fail.

### C21: Static issue closure — ddm_imul in ddm.py
- **Type**: Interface
- **Subject**: `ddm_imul` in `/testbed/sympy/polys/matrices/ddm.py`
- **Relation**: Used at ddm.py:689 but not defined in dense.py.
- **Expected**: Function must be defined.
- **Evidence**: Static issue.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/dense.py`
- **Obligations**: (indirect — used in DDM matmul)
- **Graph**: N10 → ddm.py internals

**Disposition**: Pre-existing broken dependency in DDM matrix multiplication path. Not directly required for nullspace/primitive/to_sdm/to_sparse.

### C22: Static issue closure — sdm_rref_den and sdm_scalar_mul in sdm.py
- **Type**: Interface
- **Subject**: `sdm_rref_den`, `sdm_scalar_mul` in `/testbed/sympy/polys/matrices/sdm.py`
- **Relation**: Static issues report these used but not defined/imported in sdm.py.
- **Expected**: Functions must be defined.
- **Evidence**: Static issue.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/sdm.py`
- **Obligations**: R1
- **Graph**: N11 → sdm.py internals

**Disposition**: `sdm_rref_den` is needed for `SDM.rref_den()` which is used by `_dm_rref_den` for sparse matrices. `sdm_scalar_mul` is used in SDM operations. Pre-existing broken dependencies.

### C23: Static issue closure — dup_convert in domainmatrix.py
- **Type**: Interface
- **Subject**: `dup_convert` in `/testbed/sympy/polys/matrices/domainmatrix.py`
- **Relation**: Used at domainmatrix.py:3718 (`cp = dup_convert(cp, K_r, K_f)`). Exists in `sympy.polys.densebasic` but not imported.
- **Expected**: Import from `sympy.polys.densebasic`.
- **Evidence**: Static issue; `grep -rn "def dup_convert" /testbed/sympy/polys/` finds it in `rootconditions.py` import from densebasic.
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/sympy/polys/matrices/domainmatrix.py`
- **Obligations**: (indirect — used in charpoly/factorization path)
- **Graph**: N1 → domainmatrix.py internals

**Disposition**: Pre-existing missing import. Not directly required for nullspace/primitive/to_sdm/to_sparse but must be resolved for full file correctness.

