#!/usr/bin/env python3
"""
Architecture spec for DomainMatrix methods: nullspace, primitive, to_sdm, to_sparse
and related static-issue closures.

Covers contracts: C8, C9, C10, C11, C12, C13, C14, C15, C15b, C16, C17, C18,
C19, C20, C21, C22, C23.

Each check_* function is a no-argument callable that exercises a live
caller-binding or import-boundary observation.  All checks print PASS: on
success and raise AssertionError (which causes a nonzero exit) on failure.
"""

import sys
import traceback


def _fail(msg):
    print(f"FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


# ──────────────────────────────────────────────────────────────────────────────
# C8 — to_sdm returns SDM instance (Interface)
# Guidance: test_DomainMatrix_to_sparse (line 267) exercises the to_sparse
#   path; we extend the same pattern for to_sdm.  The IR expects the result
#   type to be SDM, not DomainMatrix.
# Source: DomainMatrix.to_sdm → self.rep.to_sdm() → returns SDM
# Contracts: C8
# ──────────────────────────────────────────────────────────────────────────────
def check_to_sdm_returns_sdm_instance():
    """C8: to_sdm() must return an SDM instance (not DomainMatrix)."""
    from sympy import QQ
    from sympy.polys.matrices import DomainMatrix
    from sympy.polys.matrices.sdm import SDM

    A = DomainMatrix([[1, 0], [0, 2]], (2, 2), QQ)
    sdm = A.to_sdm()
    assert isinstance(sdm, SDM), f"Expected SDM, got {type(sdm)}"
    assert not isinstance(sdm, DomainMatrix), "to_sdm must not return DomainMatrix"
    print("PASS: check_to_sdm_returns_sdm_instance")


# ──────────────────────────────────────────────────────────────────────────────
# C9 — to_sdm preserves all elements (Dataflow)
# Guidance: Interface Description 1 shows the expected dict.
# Source: DomainMatrix.to_sdm → rep.to_sdm() → SDM dict
# Contracts: C9, R5, R8
# ──────────────────────────────────────────────────────────────────────────────
def check_to_sdm_preserves_elements():
    """C9: to_sdm() dict must match the original matrix elements exactly."""
    from sympy import QQ
    from sympy.polys.matrices import DomainMatrix

    A = DomainMatrix([[1, 0], [0, 2]], (2, 2), QQ)
    sdm = A.to_sdm()
    expected = {0: {0: QQ(1)}, 1: {1: QQ(2)}}
    assert dict(sdm) == expected, f"to_sdm dict mismatch: {dict(sdm)} != {expected}"
    print("PASS: check_to_sdm_preserves_elements")


# ──────────────────────────────────────────────────────────────────────────────
# C10 — to_sparse converts dense to sparse DomainMatrix (State)
# Guidance: test_DomainMatrix_to_sparse (line 267)
# Source: DomainMatrix.to_sparse → from_rep(rep.to_sdm())
# Contracts: C10, R6, R8
# ──────────────────────────────────────────────────────────────────────────────
def check_to_sparse_converts_dense_to_sparse():
    """C10: Dense DomainMatrix.to_sparse() switches .rep to SDM."""
    from sympy import QQ
    from sympy.polys.matrices import DomainMatrix
    from sympy.polys.matrices.sdm import SDM

    A = DomainMatrix([[1, 0], [0, 2]], (2, 2), QQ)
    # Pre-condition: rep is not sparse
    assert A.rep.fmt != 'sparse', "Expected dense starting rep"
    B = A.to_sparse()
    # Post-condition: B is a DomainMatrix with sparse rep
    assert isinstance(B, DomainMatrix), "to_sparse must return DomainMatrix"
    assert B.rep.fmt == 'sparse', f"Expected sparse rep, got {B.rep.fmt}"
    assert isinstance(B.rep, SDM), f"Expected SDM rep, got {type(B.rep)}"
    # Values preserved
    expected_rep = {0: {0: QQ(1)}, 1: {1: QQ(2)}}
    assert dict(B.rep) == expected_rep, f"Sparse rep mismatch: {dict(B.rep)}"
    print("PASS: check_to_sparse_converts_dense_to_sparse")


# ──────────────────────────────────────────────────────────────────────────────
# C11 — to_sparse on already-sparse returns self (State / idempotence)
# Guidance: Pattern from to_dense (line 630-632) which returns self
#   when already dense.
# Source: DomainMatrix.to_sparse identity path
# Contracts: C11, R6
# ──────────────────────────────────────────────────────────────────────────────
def check_to_sparse_idempotent():
    """C11: Calling to_sparse() on an already-sparse matrix returns self."""
    from sympy import QQ
    from sympy.polys.matrices import DomainMatrix

    # Build a sparse DomainMatrix
    A = DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    assert A.rep.fmt == 'sparse', "Expected sparse starting rep"
    B = A.to_sparse()
    assert B is A, "to_sparse on sparse matrix must return self (identity)"
    print("PASS: check_to_sparse_idempotent")


# ──────────────────────────────────────────────────────────────────────────────
# C12 — to_sparse preserves round-trip with to_dense (Dataflow)
# Guidance: General conversion contract; to_dense already exists (line 614).
# Source: DomainMatrix.to_sparse ↔ to_dense round-trip
# Contracts: C12, R8
# ──────────────────────────────────────────────────────────────────────────────
def check_to_sparse_dense_roundtrip():
    """C12: to_sparse().to_dense() == original for mathematical equality."""
    from sympy import QQ
    from sympy.polys.matrices import DomainMatrix

    A = DomainMatrix([[1, 0], [0, 2]], (2, 2), QQ)
    B = A.to_sparse().to_dense()
    assert B == A, f"Round-trip failed: {B} != {A}"
    # Also verify the reverse: start sparse, go dense, go sparse
    Asp = DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    Bsp = Asp.to_dense().to_sparse()
    assert Bsp == Asp, f"Reverse round-trip failed: {Bsp} != {Asp}"
    print("PASS: check_to_sparse_dense_roundtrip")


# ──────────────────────────────────────────────────────────────────────────────
# C13 — dup_content import resolved for content/primitive (Caller-binding)
# Guidance: Static issue: 'dup_content' used but not defined/imported in
#   domainmatrix.py (line 2115).  dup_content exists only as a method on
#   the IPolys class in compatibility.py, not as a standalone function.
#   The content() method calls it.  We verify: (a) the import binding is
#   resolved so the call site at domainmatrix.py:2115 does not raise
#   NameError, and (b) content() returns correct values for two different
#   input matrices to rule out hardcoded returns.
# Source: DomainMatrix.content → dup_content(elements, K)
# Contracts: C13, R3, R4
# ──────────────────────────────────────────────────────────────────────────────
def check_dup_content_caller_binding():
    """C13: content() must successfully call dup_content at runtime."""
    from sympy import ZZ
    from sympy.polys.matrices import DM

    # Verify dup_content is importable — the call at domainmatrix.py:2115
    # uses a bare function call.  Check both possible resolution paths.
    dup_importable = False
    try:
        from sympy.polys.densetools import dup_content
        assert callable(dup_content), "dup_content must be callable"
        dup_importable = True
    except ImportError:
        pass

    if not dup_importable:
        # Alternative: dup_content may be available as K.dup_content method
        assert hasattr(ZZ, 'dup_content') or hasattr(ZZ, 'gcd'), \
            "dup_content must be importable or ZZ must have dup_content/gcd"

    # Test content() on two different matrices to rule out hardcoded returns
    M1 = DM([[2, 4], [4, 12]], ZZ)
    c1 = M1.content()
    assert c1 == ZZ(2), f"content() should return 2, got {c1}"

    M2 = DM([[6, 9], [12, 15]], ZZ)
    c2 = M2.content()
    assert c2 == ZZ(3), f"content() should return 3, got {c2}"

    print("PASS: check_dup_content_caller_binding")


# ──────────────────────────────────────────────────────────────────────────────
# C14 — to_flat_nz delegation from DomainMatrix to rep (Caller-binding)
# Guidance: content() at line 2114 calls self.to_flat_nz().  The rep types
#   (SDM, DDM, DFM) all define to_flat_nz.  We verify the delegation chain
#   by comparing DomainMatrix.to_flat_nz() against self.rep.to_flat_nz()
#   for both dense and sparse representations.
# Source: DomainMatrix.to_flat_nz → self.rep.to_flat_nz()
# Contracts: C14, R3
# ──────────────────────────────────────────────────────────────────────────────
def check_to_flat_nz_delegation():
    """C14: to_flat_nz() must delegate to self.rep.to_flat_nz()."""
    from sympy import ZZ, QQ
    from sympy.polys.matrices import DomainMatrix

    # Dense rep: compare DomainMatrix.to_flat_nz vs rep.to_flat_nz
    A_d = DomainMatrix([[ZZ(2), ZZ(4)], [ZZ(6), ZZ(8)]], (2, 2), ZZ)
    elems_dm, data_dm = A_d.to_flat_nz()
    elems_rep, data_rep = A_d.rep.to_flat_nz()
    assert elems_dm == elems_rep, \
        f"Dense delegation mismatch: {elems_dm} != {elems_rep}"
    assert data_dm == data_rep, \
        f"Dense data delegation mismatch: {data_dm} != {data_rep}"
    assert isinstance(elems_dm, list), f"Expected list, got {type(elems_dm)}"
    assert isinstance(data_dm, tuple), f"Expected tuple for data, got {type(data_dm)}"

    # Sparse rep: compare DomainMatrix.to_flat_nz vs rep.to_flat_nz
    A_s = DomainMatrix({0: {0: QQ(1)}, 1: {1: QQ(2)}}, (2, 2), QQ)
    elems_s_dm, data_s_dm = A_s.to_flat_nz()
    elems_s_rep, data_s_rep = A_s.rep.to_flat_nz()
    assert elems_s_dm == elems_s_rep, \
        f"Sparse delegation mismatch: {elems_s_dm} != {elems_s_rep}"
    assert data_s_dm == data_s_rep, \
        f"Sparse data delegation mismatch: {data_s_dm} != {data_s_rep}"
    assert isinstance(elems_s_dm, list)
    assert isinstance(data_s_dm, tuple)

    print("PASS: check_to_flat_nz_delegation")


# ──────────────────────────────────────────────────────────────────────────────
# C15 — DomainMatrix.rref method exists and delegates (Caller-binding)
# Guidance: rank() at line 1262 calls self.rref(); columnspace() at 2372
#   and rowspace() at 2400 also need it.  The static IR notes it is missing.
#   We verify the live call path via rank() or columnspace().
# Source: DomainMatrix.rref → self.rep.rref()
# Contracts: C15, R1
# ──────────────────────────────────────────────────────────────────────────────
def check_rref_method_exists_and_delegates():
    """C15: rref() must exist on DomainMatrix and return (rref_matrix, pivots)."""
    from sympy import QQ, ZZ
    from sympy.polys.matrices import DomainMatrix

    A = DomainMatrix([[QQ(1), QQ(2)], [QQ(3), QQ(4)]], (2, 2), QQ)
    rref, pivots = A.rref()
    assert isinstance(rref, DomainMatrix), \
        f"rref result must be DomainMatrix, got {type(rref)}"
    assert isinstance(pivots, tuple), \
        f"pivots must be tuple, got {type(pivots)}"
    # rank() depends on rref — verify the chain
    assert A.rank() == 2, f"rank should be 2, got {A.rank()}"

    # Empty matrix
    A0 = DomainMatrix([], (0, 1), QQ)
    rref0, pivots0 = A0.rref()
    assert pivots0 == (), f"Empty matrix pivots must be (), got {pivots0}"

    # Over ZZ (non-field) — should convert to field for rref
    Az = DomainMatrix([[ZZ(1), ZZ(2)], [ZZ(3), ZZ(4)]], (2, 2), ZZ)
    rref_z, pivots_z = Az.rref()
    assert pivots_z == (0, 1)
    print("PASS: check_rref_method_exists_and_delegates")


# ──────────────────────────────────────────────────────────────────────────────
# C15b — DomainMatrix.nullspace_from_rref method exists and delegates
# Guidance: repo test line 773 calls Arref.nullspace_from_rref() where
#   Arref is a DomainMatrix.  The IR's E2 describes this delegation chain
#   (N2 → E2 → N10/N11/N12).  The underlying reps (DDM, SDM, DFM) return
#   (basis, nonpivots) tuples, but the DomainMatrix wrapper must discard
#   nonpivots and return only the basis as a DomainMatrix.
# Source: DomainMatrix.nullspace_from_rref → self.rep.nullspace_from_rref(pivots)
# Contracts: C15b, R1, R7
# ──────────────────────────────────────────────────────────────────────────────
def check_nullspace_from_rref_method_exists_and_delegates():
    """C15b: DomainMatrix.nullspace_from_rref exists and delegates to rep."""
    from sympy import ZZ
    from sympy.polys.matrices import DomainMatrix

    # Build a matrix, compute rref_den, then nullspace_from_rref
    A = DomainMatrix([[ZZ(2), ZZ(2)], [ZZ(2), ZZ(2)]], (2, 2), ZZ)
    Anull = DomainMatrix([[ZZ(-2), ZZ(2)]], (1, 2), ZZ)
    Arref, den, pivots = A.rref_den()

    # Verify the method exists and returns a DomainMatrix (not a tuple)
    result = Arref.nullspace_from_rref()
    assert isinstance(result, DomainMatrix), \
        f"nullspace_from_rref() must return DomainMatrix, got {type(result)}"
    assert result == Anull, \
        f"nullspace_from_rref() mismatch: {result} != {Anull}"

    # Verify with explicit pivots
    result_p = Arref.nullspace_from_rref(pivots)
    assert isinstance(result_p, DomainMatrix), \
        f"nullspace_from_rref(pivots) must return DomainMatrix, got {type(result_p)}"
    assert result_p == Anull, \
        f"nullspace_from_rref(pivots) mismatch: {result_p} != {Anull}"

    # Verify delegation: compare against calling rep.nullspace_from_rref directly.
    # The rep returns (basis, nonpivots); the DomainMatrix wrapper discards nonpivots.
    rep_basis, rep_nonpivots = Arref.rep.nullspace_from_rref(pivots)
    # Wrap the rep basis back into a DomainMatrix for comparison
    from sympy.polys.matrices import DomainMatrix as DM
    expected_from_rep = DM.from_rep(rep_basis)
    assert result_p == expected_from_rep, \
        f"Delegation mismatch: {result_p} != {expected_from_rep}"

    # Also test sparse path
    Arref_sp = Arref.to_sparse()
    result_sp = Arref_sp.nullspace_from_rref()
    assert isinstance(result_sp, DomainMatrix), \
        "Sparse nullspace_from_rref() must return DomainMatrix"
    assert result_sp == Anull.to_sparse(), \
        f"Sparse nullspace_from_rref() mismatch: {result_sp} != {Anull.to_sparse()}"

    print("PASS: check_nullspace_from_rref_method_exists_and_delegates")


# ──────────────────────────────────────────────────────────────────────────────
# C16 — Static issue: sdm_nullspace_from_rref in linsolve.py (Import-boundary)
# Guidance: The static issue flags sdm_nullspace_from_rref as used but not
#   defined.  We verify whether the symbol exists in the sdm module (where
#   it would logically belong) or in linsolve.py itself.
# Disposition: Pre-existing missing dependency.  The check confirms the
#   symbol's importability status for diagnostic purposes.
# Contracts: C16
# ──────────────────────────────────────────────────────────────────────────────
def check_sdm_nullspace_from_rref_importable():
    """C16: sdm_nullspace_from_rref must be importable from sdm module."""
    try:
        from sympy.polys.matrices.sdm import sdm_nullspace_from_rref
        assert callable(sdm_nullspace_from_rref), \
            "sdm_nullspace_from_rref must be callable"
        print("PASS: check_sdm_nullspace_from_rref_importable")
    except ImportError as e:
        _fail(f"sdm_nullspace_from_rref not importable from sdm: {e}")


# ──────────────────────────────────────────────────────────────────────────────
# C17 — Static issue: _dm_rref_choose_method_QQ in rref.py (Import-boundary)
# Guidance: rref.py:254 calls _dm_rref_choose_method_QQ.  Must be defined
#   or importable within rref.py.
# Contracts: C17, R1
# ──────────────────────────────────────────────────────────────────────────────
def check_dm_rref_choose_method_QQ_importable():
    """C17: _dm_rref_choose_method_QQ must be defined in rref.py."""
    try:
        from sympy.polys.matrices.rref import _dm_rref_choose_method_QQ
        assert callable(_dm_rref_choose_method_QQ), \
            "_dm_rref_choose_method_QQ must be callable"
        print("PASS: check_dm_rref_choose_method_QQ_importable")
    except ImportError as e:
        _fail(f"_dm_rref_choose_method_QQ not importable: {e}")


# ──────────────────────────────────────────────────────────────────────────────
# C18 — Static issue: _dm_rref_den_FF in rref.py (Import-boundary)
# Guidance: rref.py:115,138 call _dm_rref_den_FF.
# Contracts: C18, R1, R7
# ──────────────────────────────────────────────────────────────────────────────
def check_dm_rref_den_FF_importable():
    """C18: _dm_rref_den_FF must be defined in rref.py."""
    try:
        from sympy.polys.matrices.rref import _dm_rref_den_FF
        assert callable(_dm_rref_den_FF), \
            "_dm_rref_den_FF must be callable"
        print("PASS: check_dm_rref_den_FF_importable")
    except ImportError as e:
        _fail(f"_dm_rref_den_FF not importable: {e}")


# ──────────────────────────────────────────────────────────────────────────────
# C19 — Static issue: _dm_elements in rref.py (Import-boundary)
# Guidance: rref.py uses _dm_elements.  Must be defined.
# Contracts: C19, R1
# ──────────────────────────────────────────────────────────────────────────────
def check_dm_elements_importable():
    """C19: _dm_elements must be defined in rref.py."""
    try:
        from sympy.polys.matrices.rref import _dm_elements
        assert callable(_dm_elements), \
            "_dm_elements must be callable"
        print("PASS: check_dm_elements_importable")
    except ImportError as e:
        _fail(f"_dm_elements not importable: {e}")


# ──────────────────────────────────────────────────────────────────────────────
# C20 — Static issue: ddm_irref in ddm.py / dense.py (Import-boundary)
# Guidance: ddm.py:846 and rref.py:212 call ddm_irref.  Must be defined
#   in dense.py or importable from there.
# Contracts: C20, R1, R7
# ──────────────────────────────────────────────────────────────────────────────
def check_ddm_irref_importable():
    """C20: ddm_irref must be importable from dense module."""
    try:
        from sympy.polys.matrices.dense import ddm_irref
        assert callable(ddm_irref), "ddm_irref must be callable"
        print("PASS: check_ddm_irref_importable")
    except ImportError as e:
        _fail(f"ddm_irref not importable from dense: {e}")


# ──────────────────────────────────────────────────────────────────────────────
# C21 — Static issue: ddm_imul in ddm.py / dense.py (Import-boundary)
# Guidance: ddm.py:689 calls ddm_imul.  Not directly needed for the four
#   target methods but part of the pre-existing broken dependency set.
# Contracts: C21
# ──────────────────────────────────────────────────────────────────────────────
def check_ddm_imul_importable():
    """C21: ddm_imul must be importable from dense module."""
    try:
        from sympy.polys.matrices.dense import ddm_imul
        assert callable(ddm_imul), "ddm_imul must be callable"
        print("PASS: check_ddm_imul_importable")
    except ImportError as e:
        _fail(f"ddm_imul not importable from dense: {e}")


# ──────────────────────────────────────────────────────────────────────────────
# C22 — Static issue: sdm_rref_den, sdm_scalar_mul in sdm.py (Import-boundary)
# Guidance: sdm.py:1014,837,841 references sdm_rref_den and sdm_scalar_mul.
#   Must be defined or importable within sdm.py.
# Contracts: C22, R1
# ──────────────────────────────────────────────────────────────────────────────
def check_sdm_rref_den_scalar_mul_importable():
    """C22: sdm_rref_den and sdm_scalar_mul must be importable from sdm."""
    try:
        from sympy.polys.matrices.sdm import sdm_rref_den
        assert callable(sdm_rref_den), "sdm_rref_den must be callable"
    except ImportError as e:
        _fail(f"sdm_rref_den not importable from sdm: {e}")

    try:
        from sympy.polys.matrices.sdm import sdm_scalar_mul
        assert callable(sdm_scalar_mul), "sdm_scalar_mul must be callable"
    except ImportError as e:
        _fail(f"sdm_scalar_mul not importable from sdm: {e}")

    print("PASS: check_sdm_rref_den_scalar_mul_importable")


# ──────────────────────────────────────────────────────────────────────────────
# C23 — Static issue: dup_convert in domainmatrix.py (Import-boundary)
# Guidance: domainmatrix.py:3718 calls dup_convert.  Must be imported from
#   sympy.polys.densebasic.
# Disposition: Pre-existing missing import; not directly required for the
#   four target methods but needed for full file correctness.
# Contracts: C23
# ──────────────────────────────────────────────────────────────────────────────
def check_dup_convert_importable():
    """C23: dup_convert must be importable from sympy.polys.densebasic."""
    try:
        from sympy.polys.densebasic import dup_convert
        assert callable(dup_convert), "dup_convert must be callable"
        print("PASS: check_dup_convert_importable")
    except ImportError as e:
        _fail(f"dup_convert not importable from densebasic: {e}")


# ──────────────────────────────────────────────────────────────────────────────
# Runner
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    all_checks = [
        check_to_sdm_returns_sdm_instance,
        check_to_sdm_preserves_elements,
        check_to_sparse_converts_dense_to_sparse,
        check_to_sparse_idempotent,
        check_to_sparse_dense_roundtrip,
        check_dup_content_caller_binding,
        check_to_flat_nz_delegation,
        check_rref_method_exists_and_delegates,
        check_nullspace_from_rref_method_exists_and_delegates,
        check_sdm_nullspace_from_rref_importable,
        check_dm_rref_choose_method_QQ_importable,
        check_dm_rref_den_FF_importable,
        check_dm_elements_importable,
        check_ddm_irref_importable,
        check_ddm_imul_importable,
        check_sdm_rref_den_scalar_mul_importable,
        check_dup_convert_importable,
    ]

    failed = 0
    for check in all_checks:
        try:
            check()
        except Exception as exc:
            print(f"FAIL: {check.__name__} — {exc}", file=sys.stderr)
            traceback.print_exc()
            failed += 1

    if failed:
        print(f"\n{failed} check(s) FAILED", file=sys.stderr)
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} architecture checks PASSED")
        sys.exit(0)
