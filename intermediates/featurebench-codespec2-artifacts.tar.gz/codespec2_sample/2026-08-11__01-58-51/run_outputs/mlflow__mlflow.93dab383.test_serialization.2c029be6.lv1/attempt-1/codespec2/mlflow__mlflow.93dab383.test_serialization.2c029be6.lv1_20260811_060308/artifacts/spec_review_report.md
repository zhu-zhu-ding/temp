# Spec Review Report

## Evidence Reviewed

| Artifact | Path | Purpose |
|----------|------|---------|
| Task document | Primary oracle | Defines required interfaces and behaviors |
| Semantic IR | `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260811_060308/artifacts/semantic_ir.md` | Maps task → R/G/C records |
| Architecture spec | `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260811_060308/artifacts/arch_spec.py` | 8 executable architecture checks (C9, C23, C25, C29–C33) |
| Behavior spec | `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260811_060308/artifacts/behavior_spec.py` | 27 executable behavior checks (C1–C28) |
| Review skill | `/installed-agent/codespec2/review_skill.md` | Seed rubrics and domain perspectives |
| Static issues | `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260811_060308/artifacts/static_issues.md` | 3 issues (base.py undefined symbols) |
| Static analysis | `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_serialization.2c029be6.lv1_20260811_060308/artifacts/static_analysis.md` | 10 declared interfaces; same 3 issues |

**Repository sources examined:**

| File | Relevance |
|------|-----------|
| `/testbed/mlflow/entities/assessment_source.py` | AssessmentSourceType class (constants present; `__init__`, `__str__`, `_parse`, `_standardize` missing — blank space between constants and `from_proto`) |
| `/testbed/mlflow/entities/assessment.py` | Imports `AssessmentSourceType` from `.assessment_source`; defines `DEFAULT_FEEDBACK_NAME` |
| `/testbed/mlflow/entities/__init__.py` | Re-exports `AssessmentSourceType` from `.assessment` |
| `/testbed/mlflow/genai/scorers/base.py` | `Scorer`, `SerializedScorer`, `CustomScorer` classes; `_extract_source_code_info` (missing inline import), `_reconstruct_decorator_scorer` (missing inline import), `scorer` function (entirely missing) |
| `/testbed/mlflow/genai/scorers/scorer_utils.py` | `FunctionBodyExtractor` (class body empty), `extract_function_body` (body empty), `recreate_function` (body empty) |
| `/testbed/mlflow/genai/scorers/__init__.py` | `"scorer"` in `__all__` but no import from `.base` |
| `/testbed/mlflow/genai/__init__.py` | `"scorer"` in `__all__` but no import from `.scorers` |
| `/testbed/libs/skinny/mlflow/entities/assessment_source.py` | Reference implementation for `AssessmentSourceType` (complete) |
| `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` | Reference implementation for extractor utilities (complete) |
| `/testbed/libs/skinny/mlflow/genai/scorers/base.py` | Reference implementation for `scorer` decorator (complete) |
| `/testbed/tests/entities/test_assessment_source.py` | 5 tests: equality, properties, dict round-trip, type validation, case insensitivity, AI_JUDGE deprecation |
| `/testbed/tests/genai/scorers/test_scorer_utils.py` | ~20 tests: recreate_function basic, control flow, loops, Feedback, invalid signature, syntax errors |
| `/testbed/tests/genai/scorers/test_scorer_description.py` | 10 tests: decorator scorer description, serialization, deserialization |
| `/testbed/tests/genai/scorers/test_scorer.py` | Scorer evaluation, custom scorer, registration, return type validation |

## Rubric Scores

### Seed Rubrics

**Requirement Coverage**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| RC1 | Every atomic task requirement has a traceable R/G/C path and one or more executable observations | PASS | All R1–R18 map to contracts C1–C33 in the IR. Every contract has at least one arch or behavior check. |
| RC2 | Flag requirements missing from the IR as well as IR contracts missing from specs | FAIL (partial) | R7's `aggregations` parameter is documented in the task interface and mentioned in the IR prose, but no behavior-spec check verifies it. See Finding 1. |

**Requirement Fidelity**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| RF1 | Tests must assert the task-supported relation, not a guessed stronger behavior | PASS | C1–C28 map directly to task interface descriptions. C14 checks exact error message; C15–C17 check Feedback name semantics. |
| RF2 | Tests must not assert a looser proxy that changes the meaning | PASS (with reservation) | C4's exact `FutureWarning` message, C5's `INVALID_PARAMETER_VALUE` error code, and C27's `Invalid signature format` match exactly match reference implementation evidence. |

**Caller Binding and Architecture**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| CB1 | Material CALL edges execute through the actual public/owning entry | MIXED | Arch E3 tests `model_dump → _extract_source_code_info → extract_function_body` end-to-end. But E3 cannot run without `scorer` being defined first (circular bootstrap). Arch E4/E5 similarly depends on `scorer`. Behavior C24 tests `extract_function_body` independently. Behavior C25–C28 test `recreate_function` independently. |
| CB2 | Helper-only and symbol-existence checks are insufficient | MIXED | Arch C29/C30/C31 are import-only checks (callable/hasattr). These are architecture-level, but the behavior spec compensates with C11/C12 (full decorator cycle) and C1–C8 (full AssessmentSourceType cycle). |

**Dataflow and Lifecycle**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| DL1 | Tests distinguish correct forwarding, ordering, representation, identity/copy from wrong implementations | PASS | C19 verifies caching identity (`is` check). C15–C17 distinguish default vs explicit vs list Feedback name overwrite. C6 checks `_source_type` private attr after init. |
| DL2 | Tests cover mutation, conversion, cleanup, and rollback | PASS (with gap) | C8 tests `_standardize` happy + failure paths. C18 tests `model_dump` field presence. C20 tests `model_validate` round-trip. But no check for `model_dump` raising on unsupported scorer type. |

**Failure and Compatibility**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| FC1 | Invalid, partial, empty, optional, and fallback paths use expected exception class and diagnostics | PASS | C5 (MlflowException + INVALID_PARAMETER_VALUE + exact message), C14 (MlflowException + "must return one of"), C21 (MlflowException + "not supported outside of"), C27 (MlflowException + "Invalid signature format"), C28 (SyntaxError + exact message). |
| FC2 | Backward compatibility with deprecated values (AI_JUDGE) | PASS | C4 (FutureWarning + conversion), C10 (AssessmentSource with AI_JUDGE normalizes), C21/C22 (security gates). |

**Static-Issue Closure**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| SI1 | Every static issue is represented by a relevant runtime observation | PASS | All 3 static_issues.md items (extract_function_body, recreate_function, scorer undefined in base.py) have corresponding contracts: C23 (arch E3), C25 (arch E4/E5 + behavior C25–C28), C11/C12 (behavior + arch C29/C30). Additional IR-dispositioned issues (AssessmentSourceType methods, FunctionBodyExtractor empty) are covered by C3–C8 and C24. |

**Repository-Test Alignment**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| RT1 | Generated tests adapt the applicable angle from repository tests | PASS | Behavior C4 mirrors `test_ai_judge_deprecation_warning` from `/testbed/tests/entities/test_assessment_source.py:72`. Behavior C25 mirrors `test_simple_function_recreation` from `/testbed/tests/genai/scorers/test_scorer_utils.py:15`. C20 mirrors `test_scorer_deserialization_with_description` from `/testbed/tests/genai/scorers/test_scorer_description.py:95`. |
| RT2 | Tests do not merely resemble names or copy fixtures | PASS | The behavior spec adapts repository test patterns but uses internal-scoped test functions (`_behavior_test_simple`, `_len_check`) and different assertion styles (e.g., C19 uses `is` identity check not present in repository tests). |

**Oracle Strength**

| ID | Rubric | Score | Evidence |
|----|--------|-------|----------|
| OS1 | Assertions use exact values, fields, order, identity, cardinality where evidence supports them | PASS | C1 checks exact constants; C19 uses `is` identity; C15–C17 test exact name values; C5 checks exact error message; C27 checks `error_code`. |
| OS2 | Success-only, non-empty, broad-type, and import-only checks are weak | MIXED | Arch C29/C30/C31 are import-only (symbol existence + callable). The behavior spec compensates with strong behavioral tests for the same symbols. C18's source-code check (`"len(outputs)" in dumped["call_source"]`) is somewhat loose but acceptable given AST-based extraction variability. |

### Derived Domain Rubrics (from repository tests)

**DR1: AssessmentSource normalization through __post_init__**
- **Source**: `/testbed/tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` (lines 60–73)
- **Entity**: `AssessmentSource.__post_init__` → `AssessmentSourceType._standardize`
- **Risk**: If `__post_init__` calls a non-existent `_standardize`, every `AssessmentSource(...)` instantiation raises `AttributeError`
- **Spec observation needed**: Arch C9 checks `src.source_type == "HUMAN"` after passing lowercase input. This is sufficient.

**DR2: recreate_function namespace includes mlflow imports**
- **Source**: `/testbed/tests/genai/scorers/test_scorer_utils.py::test_mlflow_imports_available` (lines 218–267)
- **Entity**: `recreate_function` → `exec()` namespace
- **Risk**: Scorer functions that use `Feedback`, `Trace`, or `AssessmentSourceType` would raise `NameError` at runtime
- **Spec observation**: Behavior C26 explicitly tests `Feedback`, `AssessmentSourceType`, and `Trace` availability. Matches repository test structure.

**DR3: model_validate security gate**
- **Source**: `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` (lines 349–360)
- **Entity**: `Scorer._reconstruct_decorator_scorer` → `is_in_databricks_runtime()` guard
- **Risk**: Code execution during deserialization in uncontrolled environments
- **Spec observation**: Behavior C21 tests with `patch("...is_in_databricks_runtime", return_value=False)`. Arch E4/E5 tests with `return_value=True`. Both match repository test patterns.

**DR4: Feedback name overwrite semantics**
- **Source**: `/testbed/tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` (lines 304–315)
- **Entity**: `Scorer.run` → `result.name = self.name` for default-name Feedback
- **Risk**: Inconsistent feedback naming between success and failure paths
- **Spec observation**: C15, C16, C17 together cover default overwrite, explicit-name preservation, and list preservation. Matches repository test design.

## Findings

### Finding 1: `missing_requirement` — `aggregations` parameter of `scorer` decorator not tested

- **Affected IDs**: R7, C11, C12
- **Static issue**: None (aggregations is a task requirement, not a static finding)
- **Repository evidence**: Task Interface Description 1 documents `aggregations: A list of aggregation functions to apply to the scorer's output. ... By default, "mean" is used as the aggregation function.` The skinny reference at `/testbed/libs/skinny/mlflow/genai/scorers/base.py:847` accepts `aggregations: list[_AggregationType] | None = None`. The `SerializedScorer` dataclass includes `aggregations: list[str] | None = None`. The `_reconstruct_decorator_scorer` at line 364 of base.py passes `aggregations=serialized.aggregations` to `scorer()`.
- **Gap**: The behavior spec has 27 checks (C1–C28) but none test that `@scorer(aggregations=["mean", "max"])` stores, serializes, and deserializes the `aggregations` field. C11 only checks `kind`, `name`, `description`. C12 only checks `name` and `description`. C18 tests `model_dump` fields (`name`, `description`, `call_source`, `call_signature`, `original_func_name`, `mlflow_version`, `serialization_version`) but omits `aggregations`. C20 tests `model_validate` round-trip but omits `aggregations` verification.
- **Rework instruction**: Add a behavior check (e.g., `check_C_aggregations_round_trip`) that:
  1. Creates a scorer with `@scorer(aggregations=["mean", "max", "min"])`
  2. Asserts `scorer_instance.aggregations == ["mean", "max", "min"]`
  3. Serializes via `model_dump()` and asserts `dumped["aggregations"] == ["mean", "max", "min"]`
  4. Deserializes via `Scorer.model_validate()` (with Databricks mock) and asserts `deserialized.aggregations == ["mean", "max", "min"]`
  
  Also update C18 (`check_C18_model_dump_includes_source_code`) to include an assertion for `"aggregations"` key presence.

### Finding 2: `weak_constraint` — Arch spec E3, E4, E5 cannot isolate internal dataflow failures from `scorer` decorator failures

- **Affected IDs**: E3, E4, E5; C23, C25
- **Static issue**: `extract_function_body` and `recreate_function` used but not defined/imported in base.py
- **Repository evidence**: The arch spec `check_E3_extract_source_code_info_calls_extract_function_body` creates a scorer with `@scorer` and then calls `model_dump()`. If the `scorer` function is not yet defined in `base.py`, the entire check fails with `NameError`, giving no signal about `_extract_source_code_info` or `extract_function_body`. Similarly, `check_E4_E5_reconstruct_decorator_scorer_calls_recreate_function_and_scorer` depends on both `scorer` and `recreate_function` being defined.
- **Gap**: The arch spec's E3 check is meant to verify the caller binding `model_dump → _extract_source_code_info → extract_function_body`. But the check can only run when the entire `scorer` → `CustomScorer` → `model_dump` chain works. This makes the check unable to detect a failure in `_extract_source_code_info` independently of a failure in the `scorer` decorator. The behavior spec partially mitigates this: C24 tests `extract_function_body` independently and C25–C28 test `recreate_function` independently. However, there is no intermediate arch check that tests `_extract_source_code_info` with a mock `_original_func` without going through the full `scorer` → `CustomScorer` path.
- **Rework instruction**: Add an arch-level check that directly instantiates a `Scorer` subclass with a mock `_original_func` and calls `_extract_source_code_info()`, verifying that the inline import `from mlflow.genai.scorers.scorer_utils import extract_function_body` resolves and that the return dict has the expected keys. This provides a sub-unit caller-binding test that can fail independently of the `scorer` decorator. The current behavior spec C24 covers `extract_function_body` correctness but not the caller-binding from `_extract_source_code_info`.

### Finding 3: `weak_constraint` — Arch spec import checks (C29, C30, C31) are symbol-existence-only

- **Affected IDs**: C29, C30, C31; R16, R17
- **Static issue**: `scorer` in `__all__` of `scorers/__init__.py` and `genai/__init__.py` but not imported
- **Repository evidence**: `/testbed/mlflow/genai/scorers/__init__.py:76` lists `"scorer"` in `__all__` but has no `from mlflow.genai.scorers.base import scorer`. `/testbed/mlflow/genai/__init__.py:50` lists `"scorer"` in `__all__` but has no `from mlflow.genai.scorers import scorer`. Repository tests at `/testbed/tests/genai/scorers/test_scorer.py:10` use `from mlflow.genai import scorer`.
- **Gap**: Arch C29 checks `callable(sc)` and C30 checks `callable(sc)`. These are import-existence checks — they verify a symbol with the name `scorer` is importable and callable, but they don't verify it's the *right* symbol (i.e., the decorator function from `base.py`). A malicious/accidental implementation could make `scorer` importable by defining a stub function in `__init__.py` while leaving `base.py` incomplete. The behavior spec C11/C12/C13 compensate by testing decorator semantics, but those checks import `scorer` from `mlflow.genai` (bypassing the `scorers/__init__.py` path). There's no check that `from mlflow.genai.scorers import scorer` returns the *same object* as `from mlflow.genai import scorer` (which is the chain: `genai/__init__.py` → `genai/scorers/__init__.py` → `genai/scorers/base.py`).
- **Rework instruction**: Add an arch check that verifies identity: `from mlflow.genai.scorers import scorer as sc1; from mlflow.genai import scorer as sc2; assert sc1 is sc2`. This ensures the import chain resolves through both `__init__.py` files to the same underlying function in `base.py`.

## Decision

**Decision: REWORK**

Three findings require spec amendment before the IR/specs can be considered a faithful compilation of the task:

1. **Finding 1** (`missing_requirement`): The `aggregations` parameter must be tested through the full decorator → serialization → deserialization lifecycle.
2. **Finding 2** (`weak_constraint`): The arch spec needs a sub-unit caller-binding check for `_extract_source_code_info` that doesn't depend on the `scorer` decorator.
3. **Finding 3** (`weak_constraint`): The arch spec's import checks need an identity assertion verifying both import paths resolve to the same `scorer` function.

None of these findings indicate the IR or specs are fundamentally wrong. The IR correctly traces all requirements through the codebase. Both specs compile most contracts into discriminating, repository-grounded checks. The three gaps are precise and limited in scope.
