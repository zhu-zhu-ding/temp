"""
Executable behavior spec for AssessmentSourceType / scorer framework.

Covers return values, field values, types, ordering, defaults,
state transitions, errors, side effects, compatibility, and boundary cases.

Contracts mapped:
  C1-C2  (constants/enumeration)       C3-C5  (_parse)
  C6     (__init__ stores value)       C7     (__str__)
  C8     (_standardize)                C10    (AI_JUDGE compatibility)
  C11-C12 (scorer decorator modes)     C13    (CustomScorer.__call__)
  C14    (run type validation)         C15-C17 (Feedback name handling)
  C18-C19 (model_dump / caching)       C20-C21 (model_validate)
  C22    (registration security gate)  C24    (FunctionBodyExtractor skips docstring)
  C25    (recreate_function basic)     C26    (recreate_function with MLflow imports)
  C27    (recreate_function invalid sig) C28  (recreate_function syntax error)

Static-issue closure:
- AssessmentSourceType methods missing: C3-C8 cover __init__, __str__, _parse, _standardize
- FunctionBodyExtractor empty: C24 covers docstring-skipping behavior
- extract_function_body empty: C23 (in arch_spec) + C24 (here) cover behavior
- recreate_function empty: C25-C28 cover behavior
- scorer not defined in base.py: C11-C12 verify decorator functionality

Review report resolution:
- Finding 1 (missing_requirement): Added check_Cnew_aggregations_round_trip which
  tests the aggregations parameter through the full decorator → serialization →
  deserialization lifecycle. Also updated C18 to assert aggregations key presence.
"""

import sys
import warnings

import pytest


# ════════════════════════════════════════════════════════════════════════════
# AssessmentSourceType constants and enumeration
# ════════════════════════════════════════════════════════════════════════════


def check_C1_C2_AssessmentSourceType_constants():
    """
    # Contracts: C1, C2
    # Requirements: R1
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_properties, test_assessment_source_type_validation
    # Perspective: Representation contract – verify all five constants are plain
    #   strings with correct values and _SOURCE_TYPES has exactly the 4 valid types.
    # Source: /testbed/mlflow/entities/assessment_source.py lines 153-158
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    # C2: constants are plain strings
    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.CODE == "CODE"

    assert isinstance(AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED, str)
    assert isinstance(AssessmentSourceType.LLM_JUDGE, str)
    assert isinstance(AssessmentSourceType.AI_JUDGE, str)
    assert isinstance(AssessmentSourceType.HUMAN, str)
    assert isinstance(AssessmentSourceType.CODE, str)

    # C1: _SOURCE_TYPES has exactly the 4 valid (non-deprecated) types
    st = AssessmentSourceType._SOURCE_TYPES
    assert len(st) == 4, f"Expected 4, got {len(st)}"
    assert "SOURCE_TYPE_UNSPECIFIED" in st
    assert "LLM_JUDGE" in st
    assert "HUMAN" in st
    assert "CODE" in st
    # AI_JUDGE is deprecated and must NOT be in valid types
    assert "AI_JUDGE" not in st

    print("PASS: C1/C2 AssessmentSourceType constants and _SOURCE_TYPES correct")


# ════════════════════════════════════════════════════════════════════════════
# _parse behavior
# ════════════════════════════════════════════════════════════════════════════


def check_C3_parse_uppercases_input():
    """
    # Contracts: C3
    # Requirements: R4
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_case_insensitivity lines 60-73
    # Perspective: Representation contract – _parse must uppercase input before
    #   validating, making it case-insensitive.
    # Source: /testbed/mlflow/entities/assessment_source.py (N14)
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._parse("human") == "HUMAN"
    assert AssessmentSourceType._parse("Human") == "HUMAN"
    assert AssessmentSourceType._parse("HUMAN") == "HUMAN"
    assert AssessmentSourceType._parse("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("Llm_Judge") == "LLM_JUDGE"
    assert AssessmentSourceType._parse("code") == "CODE"
    assert AssessmentSourceType._parse("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"

    print("PASS: C3 _parse uppercases input (case-insensitive)")


def check_C4_parse_emits_FutureWarning_for_AI_JUDGE():
    """
    # Contracts: C4
    # Requirements: R4, R18
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_ai_judge_deprecation_warning lines 76-81
    # Perspective: Compatibility contract – _parse must emit FutureWarning
    #   with exact message and convert AI_JUDGE to LLM_JUDGE.
    # Source: /testbed/mlflow/entities/assessment_source.py (E9)
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = AssessmentSourceType._parse("AI_JUDGE")

    assert result == "LLM_JUDGE", f"AI_JUDGE must be converted to LLM_JUDGE, got {result}"

    # Also test case-insensitive AI_JUDGE
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result2 = AssessmentSourceType._parse("ai_judge")
    assert result2 == "LLM_JUDGE"

    print("PASS: C4 _parse emits FutureWarning for AI_JUDGE and converts to LLM_JUDGE")


def check_C5_parse_raises_for_invalid_type():
    """
    # Contracts: C5
    # Requirements: R4
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_type_validation lines 46-56
    # Perspective: Failure contract – _parse must raise MlflowException with
    #   INVALID_PARAMETER_VALUE and message containing "Invalid assessment source type".
    # Source: /testbed/mlflow/entities/assessment_source.py (E10)
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException, match="Invalid assessment source type"):
        AssessmentSourceType._parse("ROBOT")

    try:
        AssessmentSourceType._parse("NONEXISTENT")
    except MlflowException as e:
        assert e.error_code == INVALID_PARAMETER_VALUE, (
            f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}"
        )

    # Also test with empty string
    with pytest.raises(MlflowException, match="Invalid assessment source type"):
        AssessmentSourceType._parse("")

    print("PASS: C5 _parse raises MlflowException for invalid type")


# ════════════════════════════════════════════════════════════════════════════
# __init__ and __str__
# ════════════════════════════════════════════════════════════════════════════


def check_C6_init_stores_validated_value():
    """
    # Contracts: C6
    # Requirements: R2
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_type_validation lines 46-56
    # Perspective: State contract – __init__ must call _parse and store the
    #   result in self._source_type.
    # Source: /testbed/mlflow/entities/assessment_source.py (N13)
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    instance = AssessmentSourceType("llm_judge")
    assert instance._source_type == "LLM_JUDGE", (
        f"Expected LLM_JUDGE, got {instance._source_type}"
    )

    instance2 = AssessmentSourceType("HUMAN")
    assert instance2._source_type == "HUMAN"

    # Deprecated AI_JUDGE should be stored as LLM_JUDGE
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", FutureWarning)
        instance3 = AssessmentSourceType("AI_JUDGE")
    assert instance3._source_type == "LLM_JUDGE"

    print("PASS: C6 __init__ stores validated value in _source_type")


def check_C7_str_returns_stored_value():
    """
    # Contracts: C7
    # Requirements: R3
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_case_insensitivity lines 60-73
    # Perspective: Representation contract – __str__ must return the stored
    #   uppercase source type string.
    # Source: /testbed/mlflow/entities/assessment_source.py (N15)
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert str(AssessmentSourceType("human")) == "HUMAN"
    assert str(AssessmentSourceType("HUMAN")) == "HUMAN"
    assert str(AssessmentSourceType("code")) == "CODE"

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", FutureWarning)
        assert str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"

    # Ensure __str__ returns a string type
    assert isinstance(str(AssessmentSourceType("human")), str)

    print("PASS: C7 __str__ returns stored uppercase value")


# ════════════════════════════════════════════════════════════════════════════
# _standardize
# ════════════════════════════════════════════════════════════════════════════


def check_C8_standardize_returns_str_of_temporary_instance():
    """
    # Contracts: C8
    # Requirements: R5
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_case_insensitivity lines 60-73
    # Perspective: Interface contract – _standardize must delegate to __init__
    #   via a temporary instance and return its str().
    # Source: /testbed/mlflow/entities/assessment_source.py (N16)
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("code") == "CODE"

    # Deprecated value should be converted
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
    assert result == "LLM_JUDGE"
    assert len(w) >= 1, "Must emit FutureWarning for AI_JUDGE"

    # Invalid value should raise (via __init__ → _parse)
    from mlflow.exceptions import MlflowException

    with pytest.raises(MlflowException, match="Invalid assessment source type"):
        AssessmentSourceType._standardize("ROBOT")

    print("PASS: C8 _standardize returns str() of temporary instance")


# ════════════════════════════════════════════════════════════════════════════
# AssessmentSource + AssessmentSourceType integration
# ════════════════════════════════════════════════════════════════════════════


def check_C10_AssessmentSource_with_AI_JUDGE_converts_and_warns():
    """
    # Contracts: C10
    # Requirements: R6, R18
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_ai_judge_deprecation_warning lines 76-81
    # Perspective: Compatibility contract – AssessmentSource with AI_JUDGE
    #   must emit FutureWarning and convert to LLM_JUDGE.
    # Source: /testbed/mlflow/entities/assessment_source.py (E9)
    """
    from mlflow.entities.assessment_source import AssessmentSource

    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        src = AssessmentSource(source_type="AI_JUDGE", source_id="ai_1")

    assert src.source_type == "LLM_JUDGE"
    assert src.source_id == "ai_1"

    print("PASS: C10 AssessmentSource with AI_JUDGE converts and warns")


# ════════════════════════════════════════════════════════════════════════════
# scorer decorator
# ════════════════════════════════════════════════════════════════════════════


def check_C11_scorer_decorator_without_arguments():
    """
    # Contracts: C11
    # Requirements: R8, R9
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_decorator_scorer_without_description lines 23-27
    # Perspective: Interface contract – @scorer (no args) must produce a
    #   CustomScorer with name=func.__name__, kind=DECORATOR, description=None.
    # Source: /testbed/mlflow/genai/scorers/base.py (N18)
    """
    from mlflow.genai import scorer
    from mlflow.genai.scorers.base import ScorerKind

    @scorer
    def my_test_scorer(outputs) -> bool:
        return True

    assert my_test_scorer.name == "my_test_scorer"
    assert my_test_scorer.kind == ScorerKind.DECORATOR
    assert my_test_scorer.description is None

    # Verify it's callable and returns correct value
    assert my_test_scorer.run(outputs="test") is True

    print("PASS: C11 scorer decorator without arguments produces CustomScorer")


def check_C12_scorer_decorator_with_arguments():
    """
    # Contracts: C12
    # Requirements: R8, R9, R7
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_decorator_scorer_with_name_and_description lines 33-39
    # Perspective: Interface contract – @scorer(name=..., description=...)
    #   must produce a CustomScorer with the given name and description.
    # Source: /testbed/mlflow/genai/scorers/base.py (N18)
    """
    from mlflow.genai import scorer
    from mlflow.genai.scorers.base import ScorerKind

    @scorer(name="custom_name", description="custom desc")
    def my_scorer(outputs) -> bool:
        return True

    assert my_scorer.name == "custom_name"
    assert my_scorer.description == "custom desc"
    assert my_scorer.kind == ScorerKind.DECORATOR

    print("PASS: C12 scorer decorator with arguments produces CustomScorer")


# ════════════════════════════════════════════════════════════════════════════
# CustomScorer.__call__ delegation
# ════════════════════════════════════════════════════════════════════════════


def check_C13_CustomScorer_call_delegates_to_original():
    """
    # Contracts: C13
    # Requirements: R9
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py
    #   test_scorer_existence_in_metrics lines 62-64
    # Perspective: Interface contract – CustomScorer.__call__ must delegate
    #   to the original decorated function.
    # Source: /testbed/mlflow/genai/scorers/base.py (N18)
    """
    from mlflow.genai import scorer

    call_count = 0

    @scorer
    def counting_scorer(outputs) -> int:
        nonlocal call_count
        call_count += 1
        return len(outputs)

    result = counting_scorer.run(outputs="hello")
    assert call_count == 1
    assert result == 5

    # Calling again should increment
    result2 = counting_scorer.run(outputs="world")
    assert call_count == 2
    assert result2 == 5

    print("PASS: C13 CustomScorer.__call__ delegates to original function")


# ════════════════════════════════════════════════════════════════════════════
# run type validation and Feedback name handling
# ════════════════════════════════════════════════════════════════════════════


def check_C14_run_validates_return_types():
    """
    # Contracts: C14
    # Requirements: R11
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py
    #   test_scorer_returns_unsupported_type lines ~320-350
    # Perspective: Failure contract – run() must raise MlflowException
    #   for unsupported return types.
    # Source: /testbed/mlflow/genai/scorers/base.py (run method)
    """
    from mlflow.exceptions import MlflowException
    from mlflow.genai import scorer

    @scorer
    def dict_scorer(outputs) -> dict:
        return {"bad": "type"}

    with pytest.raises(MlflowException, match="must return one of"):
        dict_scorer.run(outputs="test")

    @scorer
    def tuple_scorer(outputs) -> tuple:
        return (1, 2)

    with pytest.raises(MlflowException, match="must return one of"):
        tuple_scorer.run(outputs="test")

    print("PASS: C14 run() validates return types")


def check_C15_run_overwrites_default_Feedback_name():
    """
    # Contracts: C15
    # Requirements: R9
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py
    #   test_custom_scorer_overwrites_default_feedback_name lines ~538-557
    # Perspective: State contract – run() must overwrite Feedback.name with
    #   the scorer name when the Feedback uses the default name.
    # Source: /testbed/mlflow/genai/scorers/base.py (run method)
    """
    from mlflow.entities import Feedback
    from mlflow.genai import scorer

    @scorer
    def default_feedback_scorer(outputs) -> Feedback:
        return Feedback(value=42, rationale="test")

    result = default_feedback_scorer.run(outputs="hello")
    assert result.name == "default_feedback_scorer"
    assert result.value == 42

    print("PASS: C15 run() overwrites default Feedback name")


def check_C16_run_does_not_overwrite_explicit_Feedback_name():
    """
    # Contracts: C16
    # Requirements: R9
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py
    #   test_custom_scorer_overwrites_default_feedback_name lines ~538-557
    # Perspective: State contract – run() must NOT overwrite Feedback.name
    #   when the user has explicitly set it.
    # Source: /testbed/mlflow/genai/scorers/base.py (run method)
    """
    from mlflow.entities import Feedback
    from mlflow.genai import scorer

    @scorer
    def explicit_feedback_scorer(outputs) -> Feedback:
        return Feedback(name="my_feedback", value=99, rationale="explicit")

    result = explicit_feedback_scorer.run(outputs="hello")
    assert result.name == "my_feedback"
    assert result.value == 99

    print("PASS: C16 run() does not overwrite explicit Feedback name")


def check_C17_run_does_not_overwrite_Feedback_names_in_list():
    """
    # Contracts: C17
    # Requirements: R9
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py
    #   test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list
    # Perspective: State contract – run() must NOT overwrite Feedback.name
    #   for any Feedback in a returned list.
    # Source: /testbed/mlflow/genai/scorers/base.py (run method)
    """
    from mlflow.entities import Feedback
    from mlflow.genai import scorer

    @scorer
    def list_feedback_scorer(outputs) -> list:
        return [
            Feedback(value=True, rationale="good"),
            Feedback(name="bad_one", value=False, rationale="bad"),
        ]

    results = list_feedback_scorer.run(outputs="hello")
    assert len(results) == 2
    # First one has default name → should be overwritten with scorer name
    assert results[0].name == "list_feedback_scorer"
    # Second one has explicit name → should NOT be overwritten
    assert results[1].name == "bad_one"

    print("PASS: C17 run() handles list[Feedback] name overwrite correctly")


# ════════════════════════════════════════════════════════════════════════════
# model_dump serialization
# ════════════════════════════════════════════════════════════════════════════


def check_C18_model_dump_includes_source_code():
    """
    # Contracts: C18
    # Requirements: R7
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_serialization lines 85-95
    # Perspective: Representation contract – model_dump() must include
    #   call_source, call_signature, original_func_name, name, description,
    #   aggregations, mlflow_version, serialization_version.
    # Source: /testbed/mlflow/genai/scorers/base.py (model_dump method)
    # Review Finding 1: added 'aggregations' key presence assertion.
    """
    from mlflow.genai import scorer

    @scorer
    def dump_test_scorer(outputs) -> bool:
        """Docstring."""
        return len(outputs) > 0

    dumped = dump_test_scorer.model_dump()

    assert "call_source" in dumped, "Missing call_source"
    assert dumped["call_source"] is not None
    assert "call_signature" in dumped, "Missing call_signature"
    assert dumped["call_signature"] is not None
    assert "original_func_name" in dumped, "Missing original_func_name"
    assert dumped["original_func_name"] == "dump_test_scorer"
    assert "name" in dumped, "Missing name"
    assert dumped["name"] == "dump_test_scorer"
    assert "description" in dumped, "Missing description"
    assert dumped["description"] is None
    assert "aggregations" in dumped, "Missing aggregations (Review Finding 1)"
    assert dumped["aggregations"] is None, (
        f"Expected aggregations=None by default, got {dumped['aggregations']}"
    )
    assert "mlflow_version" in dumped, "Missing mlflow_version"
    assert "serialization_version" in dumped, "Missing serialization_version"

    print("PASS: C18 model_dump includes all required fields including aggregations")


def check_C18b_model_dump_includes_aggregations_when_set():
    """
    # Contracts: C18
    # Requirements: R7
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_serialization lines 85-95
    # Perspective: Representation contract – model_dump() must include
    #   aggregations when explicitly set on the decorator.
    # Source: /testbed/mlflow/genai/scorers/base.py (model_dump method)
    # Review Finding 1: tests aggregations field in serialized output.
    """
    from mlflow.genai import scorer

    @scorer(aggregations=["mean", "max", "min"])
    def agg_test_scorer(outputs) -> bool:
        return len(outputs) > 0

    dumped = agg_test_scorer.model_dump()

    assert "aggregations" in dumped, "Missing aggregations"
    assert dumped["aggregations"] == ["mean", "max", "min"], (
        f"Expected ['mean', 'max', 'min'], got {dumped['aggregations']}"
    )

    print("PASS: C18b model_dump preserves aggregations when set")


def check_C19_model_dump_caches_result():
    """
    # Contracts: C19
    # Requirements: R7
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_serialization lines 85-95
    # Perspective: Lifecycle contract – model_dump() must cache the result
    #   so that second call returns the same object (is check).
    # Source: /testbed/mlflow/genai/scorers/base.py (model_dump method)
    """
    from mlflow.genai import scorer

    @scorer
    def cache_test_scorer(outputs) -> bool:
        return True

    dump1 = cache_test_scorer.model_dump()
    dump2 = cache_test_scorer.model_dump()

    # Must be the same object (identity, not just equality)
    assert dump1 is dump2, "model_dump must cache and return the same object"

    print("PASS: C19 model_dump caches result (identity check)")


# ════════════════════════════════════════════════════════════════════════════
# model_validate deserialization
# ════════════════════════════════════════════════════════════════════════════


def check_C20_model_validate_reconstructs_decorator_scorer():
    """
    # Contracts: C20
    # Requirements: R10
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_deserialization_with_description lines 95-108
    # Perspective: Interface contract – Scorer.model_validate() must
    #   reconstruct a decorator scorer from serialized data.
    # Source: /testbed/mlflow/genai/scorers/base.py (model_validate method)
    """
    from unittest.mock import patch

    from mlflow.genai import scorer
    from mlflow.genai.scorers.base import Scorer, ScorerKind

    @scorer(description="deser_test")
    def deser_test_scorer(outputs) -> bool:
        return len(outputs) > 0

    serialized = deser_test_scorer.model_dump()

    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        reconstructed = Scorer.model_validate(serialized)

    assert reconstructed.name == "deser_test_scorer"
    assert reconstructed.description == "deser_test"
    assert reconstructed.kind == ScorerKind.DECORATOR
    assert reconstructed.run(outputs="hello") is True

    print("PASS: C20 model_validate reconstructs decorator scorer")


def check_C21_model_validate_blocks_outside_databricks():
    """
    # Contracts: C21
    # Requirements: R10
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py
    #   test_custom_scorer_loading_blocked_for_non_databricks_uri
    # Perspective: Failure contract – Scorer._reconstruct_decorator_scorer
    #   must raise MlflowException when not in Databricks runtime.
    # Source: /testbed/mlflow/genai/scorers/base.py (_reconstruct_decorator_scorer)
    """
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.base import Scorer, SerializedScorer

    serialized = SerializedScorer(
        name="blocked_scorer",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="blocked_scorer",
    )

    with pytest.raises(MlflowException, match="is not supported outside of"):
        Scorer._reconstruct_decorator_scorer(serialized)

    print("PASS: C21 model_validate blocks deserialization outside Databricks")


# ════════════════════════════════════════════════════════════════════════════
# Aggregations round-trip (Review Finding 1)
# ════════════════════════════════════════════════════════════════════════════


def check_Cnew_aggregations_round_trip():
    """
    # Contracts: Cnew (R7 aggregations)
    # Requirements: R7
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_serialization lines 85-95 and
    #   test_scorer_deserialization_with_description lines 95-108
    # Perspective: Lifecycle contract – aggregations parameter must survive
    #   the full round-trip: decorator → instance → model_dump → model_validate.
    # Source: /testbed/mlflow/genai/scorers/base.py
    #   Scorer.model_dump line 149, Scorer._reconstruct_decorator_scorer line 302,
    #   scorer() line 847
    # Review Finding 1: This check validates that the aggregations field is
    #   stored, serialized, and deserialized correctly across the full lifecycle.
    """
    from unittest.mock import patch

    from mlflow.genai import scorer
    from mlflow.genai.scorers.base import Scorer, ScorerKind

    # 1. Create scorer with aggregations
    @scorer(aggregations=["mean", "max", "min"])
    def agg_scorer(outputs) -> bool:
        return len(outputs) > 0

    # 2. Assert aggregations on the instance
    assert agg_scorer.aggregations == ["mean", "max", "min"], (
        f"Expected ['mean', 'max', 'min'], got {agg_scorer.aggregations}"
    )

    # 3. Serialize and assert aggregations in the dump
    serialized = agg_scorer.model_dump()
    assert "aggregations" in serialized, "aggregations must be in model_dump output"
    assert serialized["aggregations"] == ["mean", "max", "min"], (
        f"Expected ['mean', 'max', 'min'] in serialized, got {serialized['aggregations']}"
    )

    # 4. Deserialize and assert aggregations survive
    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        deserialized = Scorer.model_validate(serialized)

    assert deserialized.aggregations == ["mean", "max", "min"], (
        f"Expected ['mean', 'max', 'min'] after deserialization, got {deserialized.aggregations}"
    )
    assert deserialized.kind == ScorerKind.DECORATOR
    assert deserialized.name == "agg_scorer"

    # 5. Verify the deserialized scorer still works
    result = deserialized.run(outputs="hello")
    assert result is True

    # 6. Also test aggregations=None (default) survives round-trip
    @scorer
    def no_agg_scorer(outputs) -> bool:
        return True

    assert no_agg_scorer.aggregations is None
    serialized_none = no_agg_scorer.model_dump()
    assert serialized_none["aggregations"] is None

    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        deserialized_none = Scorer.model_validate(serialized_none)
    assert deserialized_none.aggregations is None

    print("PASS: Cnew aggregations round-trip through decorator→serialize→deserialize")


# ════════════════════════════════════════════════════════════════════════════
# Registration security gate
# ════════════════════════════════════════════════════════════════════════════


def check_C22_decorator_scorer_registration_blocked_non_databricks():
    """
    # Contracts: C22
    # Requirements: R10
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py
    #   test_custom_scorer_registration_blocked_for_non_databricks_uri
    # Perspective: Failure contract – decorator scorer .register() must be
    #   blocked outside Databricks environments.
    # Source: /testbed/mlflow/genai/scorers/base.py (_check_can_be_registered)
    """
    import mlflow
    from mlflow.genai import scorer

    experiment_id = mlflow.create_experiment("test_security_spec")

    @scorer
    def security_test_scorer(outputs) -> bool:
        return bool(outputs)

    with pytest.raises(
        mlflow.exceptions.MlflowException,
        match="Custom scorer registration.*not supported outside of Databricks tracking",
    ):
        security_test_scorer.register(experiment_id=experiment_id, name="security_test")

    mlflow.delete_experiment(experiment_id)

    print("PASS: C22 decorator scorer registration blocked outside Databricks")


# ════════════════════════════════════════════════════════════════════════════
# FunctionBodyExtractor
# ════════════════════════════════════════════════════════════════════════════


def check_C24_FunctionBodyExtractor_skips_docstring():
    """
    # Contracts: C24
    # Requirements: R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_utils.py
    #   (indirectly, through extract_function_body tests)
    # Perspective: Representation contract – extract_function_body must
    #   return the function body without the docstring.
    # Source: /testbed/mlflow/genai/scorers/scorer_utils.py (FunctionBodyExtractor)
    """
    from mlflow.genai.scorers.scorer_utils import extract_function_body

    def func_with_docstring(x):
        """This is a docstring."""
        return x + 1

    body, indent = extract_function_body(func_with_docstring)

    # Body must not contain the docstring
    assert "docstring" not in body, f"Docstring should be skipped, but found in: {body}"
    assert "return x + 1" in body, f"Function body must be present, got: {body}"
    assert isinstance(indent, int), f"Indent unit must be int, got {type(indent)}"

    print("PASS: C24 FunctionBodyExtractor skips docstring")


# ════════════════════════════════════════════════════════════════════════════
# recreate_function
# ════════════════════════════════════════════════════════════════════════════


def check_C25_recreate_function_basic():
    """
    # Contracts: C25
    # Requirements: R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_utils.py
    #   test_simple_function_recreation lines 14-24
    # Perspective: Interface contract – recreate_function must create a
    #   callable with the given name that executes the source code.
    # Source: /testbed/mlflow/genai/scorers/scorer_utils.py (recreate_function)
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    recreated = recreate_function("return x + y", "(x, y)", "add_func")

    assert recreated is not None
    assert callable(recreated)
    assert recreated.__name__ == "add_func"
    assert recreated(3, 4) == 7
    assert recreated(10, -5) == 5

    print("PASS: C25 recreate_function creates callable from source")


def check_C26_recreate_function_with_MLflow_imports():
    """
    # Contracts: C26
    # Requirements: R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_utils.py
    #   test_mlflow_imports_available lines 218-267
    # Perspective: Interface contract – recreate_function must make Feedback,
    #   AssessmentSourceType, Trace etc. available in the execution namespace.
    # Source: /testbed/mlflow/genai/scorers/scorer_utils.py (N11)
    """
    from mlflow.entities import Feedback, Trace
    from mlflow.genai.scorers.scorer_utils import recreate_function

    # Test Feedback creation
    source = (
        'import re\n'
        'words = re.findall(r"\\b\\w+\\b", text)\n'
        'return Feedback(value=len(words), rationale=f"Found {len(words)} words")'
    )
    recreated = recreate_function(source, "(text)", "word_counter")
    result = recreated("hello world")
    assert isinstance(result, Feedback)
    assert result.value == 2
    assert "Found 2 words" in result.rationale

    # Test AssessmentSourceType availability
    source2 = (
        "from mlflow.entities.assessment_source import AssessmentSourceType\n"
        'return AssessmentSourceType.CODE'
    )
    recreated2 = recreate_function(source2, "()", "get_source_type")
    result2 = recreated2()
    assert result2 == "CODE"

    # Test Trace availability
    source3 = (
        "from mlflow.entities import TraceInfo, TraceState, TraceData\n"
        "from mlflow.entities.trace_location import (\n"
        "    TraceLocation, TraceLocationType, MlflowExperimentLocation\n"
        ")\n"
        "from mlflow.entities import Trace\n"
        'mlflow_exp_location = MlflowExperimentLocation(experiment_id="0")\n'
        "trace_location = TraceLocation(\n"
        "    type=TraceLocationType.MLFLOW_EXPERIMENT,\n"
        "    mlflow_experiment=mlflow_exp_location\n"
        ")\n"
        "trace_info = TraceInfo(\n"
        '    trace_id="test_id",\n'
        "    trace_location=trace_location,\n"
        "    request_time=1000,\n"
        "    state=TraceState.OK\n"
        ")\n"
        "return Trace(info=trace_info, data=TraceData())"
    )
    recreated3 = recreate_function(source3, "()", "make_trace")
    result3 = recreated3()
    assert isinstance(result3, Trace)

    print("PASS: C26 recreate_function with MLflow imports available")


def check_C27_recreate_function_invalid_signature_raises():
    """
    # Contracts: C27
    # Requirements: R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_utils.py
    #   test_invalid_signature_format lines 228-233
    # Perspective: Failure contract – recreate_function with an invalid
    #   signature format must raise MlflowException with INVALID_PARAMETER_VALUE.
    # Source: /testbed/mlflow/genai/scorers/scorer_utils.py (N11)
    """
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.scorer_utils import recreate_function
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException, match="Invalid signature format"):
        recreate_function("return 42", "invalid", "f")

    try:
        recreate_function("return 42", "not_a_sig", "g")
    except MlflowException as e:
        assert e.error_code == INVALID_PARAMETER_VALUE

    print("PASS: C27 recreate_function raises for invalid signature")


def check_C28_recreate_function_syntax_error_raises():
    """
    # Contracts: C28
    # Requirements: R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_utils.py
    #   test_function_with_syntax_error lines 268-275
    # Perspective: Failure contract – recreate_function with syntax error in
    #   source code must raise SyntaxError.
    # Source: /testbed/mlflow/genai/scorers/scorer_utils.py (N11)
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    # Missing colon after if statement
    with pytest.raises(SyntaxError, match="expected ':'"):
        recreate_function("if x > 0\n    return True", "(x)", "bad")

    # Empty source
    with pytest.raises(SyntaxError, match="expected an indented block"):
        recreate_function("", "()", "empty_func")

    print("PASS: C28 recreate_function raises SyntaxError for bad source")


# ════════════════════════════════════════════════════════════════════════════
# Runner
# ════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    all_checks = [
        check_C1_C2_AssessmentSourceType_constants,
        check_C3_parse_uppercases_input,
        check_C4_parse_emits_FutureWarning_for_AI_JUDGE,
        check_C5_parse_raises_for_invalid_type,
        check_C6_init_stores_validated_value,
        check_C7_str_returns_stored_value,
        check_C8_standardize_returns_str_of_temporary_instance,
        check_C10_AssessmentSource_with_AI_JUDGE_converts_and_warns,
        check_C11_scorer_decorator_without_arguments,
        check_C12_scorer_decorator_with_arguments,
        check_C13_CustomScorer_call_delegates_to_original,
        check_C14_run_validates_return_types,
        check_C15_run_overwrites_default_Feedback_name,
        check_C16_run_does_not_overwrite_explicit_Feedback_name,
        check_C17_run_does_not_overwrite_Feedback_names_in_list,
        check_C18_model_dump_includes_source_code,
        check_C18b_model_dump_includes_aggregations_when_set,
        check_C19_model_dump_caches_result,
        check_C20_model_validate_reconstructs_decorator_scorer,
        check_C21_model_validate_blocks_outside_databricks,
        check_Cnew_aggregations_round_trip,
        check_C22_decorator_scorer_registration_blocked_non_databricks,
        check_C24_FunctionBodyExtractor_skips_docstring,
        check_C25_recreate_function_basic,
        check_C26_recreate_function_with_MLflow_imports,
        check_C27_recreate_function_invalid_signature_raises,
        check_C28_recreate_function_syntax_error_raises,
    ]
    failed = 0
    for check in all_checks:
        try:
            check()
        except Exception as e:
            failed += 1
            print(f"FAIL: {check.__name__}: {e}")
    if failed:
        print(f"\n{failed} check(s) FAILED")
        sys.exit(1)
    print(f"\nAll {len(all_checks)} behavior checks passed.")
