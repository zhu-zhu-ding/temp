# Semantic IR

## L1. Requirement Obligations

### R1: AssessmentSourceType static constants and source-type enumeration
- **Type**: Interface
- **Statement**: `AssessmentSourceType` MUST expose five class-level string constants: `SOURCE_TYPE_UNSPECIFIED = "SOURCE_TYPE_UNSPECIFIED"`, `LLM_JUDGE = "LLM_JUDGE"`, `AI_JUDGE = "AI_JUDGE"` (deprecated), `HUMAN = "HUMAN"`, `CODE = "CODE"`. A private `_SOURCE_TYPES` list MUST contain the four valid (non-deprecated) types `[SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]`.
- **Task Evidence**: Interface Description 2 lists available source types (HUMAN, LLM_JUDGE, CODE, SOURCE_TYPE_UNSPECIFIED) and notes AI_JUDGE as deprecated legacy. The `_SOURCE_TYPES` list expression shows `[SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]`.
- **Acceptance**: Constants accessible as `AssessmentSourceType.LLM_JUDGE` etc., returning plain strings. `_SOURCE_TYPES` is a list of four strings.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 153-158 already define these constants with correct values and the `_SOURCE_TYPES` list. `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 153-158 confirm identical definition. `/testbed/libs/tracing/mlflow/entities/assessment_source.py` likewise.
- **Uncertainty**: None.

### R2: AssessmentSourceType.__init__ validation and standardization
- **Type**: Interface / State
- **Statement**: `AssessmentSourceType.__init__(self, source_type: str)` MUST validate the input via `_parse`, store the standardized result in `self._source_type`, and raise `MlflowException` (error_code `INVALID_PARAMETER_VALUE`) for unrecognized types.
- **Task Evidence**: Interface Description 2 `__init__` docstring: "Initialize an AssessmentSourceType instance with validation and standardization… automatic validation, case normalization, and deprecation handling."
- **Acceptance**: `AssessmentSourceType("llm_judge")` stores `"LLM_JUDGE"`. `AssessmentSourceType("ROBOT")` raises `MlflowException` with message containing "Invalid assessment source type".
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 161-162 show exact implementation: `def __init__(self, source_type: str): self._source_type = AssessmentSourceType._parse(source_type)`. Test `/testbed/tests/entities/test_assessment_source.py` line 54-56 confirms invalid type raises `MlflowException` with "Invalid assessment source type".
- **Uncertainty**: None.

### R3: AssessmentSourceType.__str__ returns standardized source type
- **Type**: Interface
- **Statement**: `AssessmentSourceType.__str__(self)` MUST return the stored standardized (uppercase) source-type string.
- **Task Evidence**: Interface Description 2 `__str__` docstring: "Return the string representation of the assessment source type… The returned string is always in uppercase format."
- **Acceptance**: `str(AssessmentSourceType("human"))` returns `"HUMAN"`. `str(AssessmentSourceType("AI_JUDGE"))` returns `"LLM_JUDGE"`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 185-186: `def __str__(self): return self._source_type`. Tests in `/testbed/tests/entities/test_assessment_source.py` lines 63-73 verify case normalization returns uppercase.
- **Uncertainty**: None.

### R4: AssessmentSourceType._parse case-insensitive validation with deprecation
- **Type**: Interface / Compatibility
- **Statement**: `AssessmentSourceType._parse(source_type: str)` static method MUST uppercase the input, emit a `FutureWarning` if input equals `"AI_JUDGE"` (converting to `"LLM_JUDGE"`), validate membership in `_SOURCE_TYPES`, and raise `MlflowException` with `INVALID_PARAMETER_VALUE` for invalid types.
- **Task Evidence**: Interface Description 2 `_parse` docstring: "case-insensitive validation and standardization… handles deprecated values by converting them to their modern equivalents and issuing appropriate warnings."
- **Acceptance**: `_parse("llm_judge")` returns `"LLM_JUDGE"`. `_parse("AI_JUDGE")` emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and returns `"LLM_JUDGE"`. `_parse("ROBOT")` raises `MlflowException`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 165-182 exact implementation. Test `/testbed/tests/entities/test_assessment_source.py` lines 48-52 and 76-81 confirm deprecation warning and case-insensitivity.
- **Uncertainty**: None.

### R5: AssessmentSourceType._standardize delegation wrapper
- **Type**: Interface
- **Statement**: `AssessmentSourceType._standardize(source_type: str)` static method MUST create a temporary `AssessmentSourceType` instance and return its `str()` representation, thereby delegating all validation and deprecation logic.
- **Task Evidence**: Interface Description 2 `_standardize` docstring: "creating a temporary AssessmentSourceType instance and converting it to its string representation."
- **Acceptance**: `_standardize("human")` returns `"HUMAN"`. `_standardize("AI_JUDGE")` returns `"LLM_JUDGE"` with warning.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 188-189: `return str(AssessmentSourceType(source_type))`. Called by `AssessmentSource.__post_init__` at `/testbed/mlflow/entities/assessment_source.py` line 78.
- **Uncertainty**: None.

### R6: AssessmentSource.__post_init__ calls _standardize
- **Type**: Dataflow
- **Statement**: `AssessmentSource.__post_init__` MUST call `AssessmentSourceType._standardize(self.source_type)` and store the result back into `self.source_type`, ensuring the dataclass field always holds a validated, uppercase value.
- **Task Evidence**: Task mentions "Parse, validate, and standardize assessment source types with backward compatibility."
- **Acceptance**: `AssessmentSource(source_type="human", source_id="x").source_type == "HUMAN"`.
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 76-78: `self.source_type = AssessmentSourceType._standardize(self.source_type)`. Test at `/testbed/tests/entities/test_assessment_source.py` lines 63-73.
- **Uncertainty**: None.

### R7: scorer decorator function with optional arguments
- **Type**: Interface
- **Statement**: A `scorer` function in `/testbed/mlflow/genai/scorers/base.py` MUST act as a decorator. When called as `@scorer` (no arguments), `func` is the decorated function. When called as `@scorer(name=..., description=..., aggregations=...)`, it MUST return a `functools.partial` that, when applied to a function, creates the scorer. The decorator MUST return a `CustomScorer` (subclass of `Scorer`) instance.
- **Task Evidence**: Interface Description 1 shows `@scorer` and `@scorer(...)` usage patterns. The `scorer` function signature shows `func = None` as first parameter with optional `name`, `description`, `aggregations`.
- **Acceptance**: `@scorer` on a function returns a `Scorer` instance with `kind == ScorerKind.DECORATOR`. `scorer(name="x")(func)` returns a `Scorer` instance with `name == "x"`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` tail section shows the full `scorer` implementation with `functools.partial` pattern and `CustomScorer` inner class. Tests at `/testbed/tests/genai/scorers/test_scorer.py` line 51 uses `scorer(always_yes)`, line 60 uses `scorer(name="always_no")(always_yes)`.
- **Uncertainty**: None.

### R8: CustomScorer wraps original function with __call__ delegation
- **Type**: Interface / Dataflow
- **Statement**: The `CustomScorer` inner class MUST store the original decorated function as `_original_func` (a Pydantic `PrivateAttr`), delegate `__call__` to it, set `kind` property to `ScorerKind.DECORATOR`, and update `__call__.__signature__` to prepend `self` parameter matching the original function's signature.
- **Task Evidence**: Interface Description 1: "The scorer function should take in a subset of [inputs, outputs, expectations, trace]" and "The scorer function should return one of [bool, int, float, str, Feedback, list[Feedback]]."
- **Acceptance**: Calling `my_scorer.run(inputs=..., outputs=...)` invokes the original decorated function with the matching kwargs.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` tail section shows `CustomScorer.__call__` delegates to `func`, `_original_func` stored via `object.__setattr__`, `kind` returns `ScorerKind.DECORATOR`, `__signature__` updated. Tests at `/testbed/tests/genai/scorers/test_scorer.py` lines 37-71.
- **Uncertainty**: None.

### R9: scorer serialization via model_dump with source code extraction
- **Type**: Interface / Dataflow
- **Statement**: `Scorer.model_dump()` (overridden in base `Scorer`) MUST detect decorator scorers via `_original_func` attribute, call `_extract_source_code_info()` to extract source code, signature, and function name, then produce a `SerializedScorer` dict. The result MUST be cached in `_cached_dump`.
- **Task Evidence**: Interface Description 1 mentions "Provide secure serialization that handles source code extraction and reconstruction." Task mentions "serialization/deserialization capabilities."
- **Acceptance**: `decorator_scorer.model_dump()` returns dict with keys `call_source`, `call_signature`, `original_func_name`. `_cached_dump` is populated.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 149-183 show `model_dump` checks `_original_func`, calls `_extract_source_code_info()`, creates `SerializedScorer`, caches. Test at `/testbed/tests/genai/scorers/test_scorer_description.py` lines 82-92.
- **Uncertainty**: The `_extract_source_code_info` method exists at line 186 but calls `extract_function_body` which is imported inline at line 188; this import path requires `scorer_utils.py` to define the function.

### R10: scorer deserialization via Scorer.model_validate
- **Type**: Interface / Dataflow
- **Statement**: `Scorer.model_validate(cls, obj)` MUST accept a `SerializedScorer` or dict, detect decorator scorers by presence of `call_source`/`call_signature`/`original_func_name`, and call `_reconstruct_decorator_scorer` which reconstructs the function via `recreate_function` and wraps it with the `scorer` decorator. Deserialization outside Databricks runtime MUST raise `MlflowException`.
- **Task Evidence**: Interface Description 1 notes: "Custom scorers created with this decorator can be registered for automatic trace evaluation, but registration is only supported in Databricks environments due to security considerations."
- **Acceptance**: `Scorer.model_validate(serialized_dict)` returns a `Scorer` with `kind == ScorerKind.DECORATOR` in Databricks. Outside Databricks, raises `MlflowException` with "Loading custom scorer" message.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 204-300 show `model_validate` and `_reconstruct_decorator_scorer` with security checks. Tests at `/testbed/tests/genai/scorers/test_scorer.py` lines 366-378, 380-393 confirm blocking behavior.
- **Uncertainty**: The `_reconstruct_decorator_scorer` method at line 303 imports `recreate_function` inline; this requires `scorer_utils.py` to define `recreate_function`.

### R11: extract_function_body utility
- **Type**: Interface
- **Statement**: `extract_function_body(func: Callable) -> tuple[str, int]` in `scorer_utils.py` MUST use `inspect.getsourcelines` and `FunctionBodyExtractor` (AST visitor) to extract the body of a function as a dedented string, skipping docstrings, and return the body string and indentation unit.
- **Task Evidence**: Task mentions "Handle dynamic function reconstruction from serialized source code." Static issue identifies `extract_function_body` as used but not defined in `base.py` — must be defined in `scorer_utils.py`.
- **Acceptance**: For a function `def f(): return 42`, `extract_function_body(f)` returns `("return 42", 4)`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 16-61 define `FunctionBodyExtractor` class and lines 64-74 define `extract_function_body`. Imported inline in `/testbed/mlflow/genai/scorers/base.py` line 188.
- **Uncertainty**: None.

### R12: recreate_function utility
- **Type**: Interface
- **Statement**: `recreate_function(source: str, signature: str, func_name: str) -> Callable` in `scorer_utils.py` MUST parse the signature string, build a function definition with `from __future__ import annotations`, indent the source code, provide a namespace with common MLflow imports (`Feedback`, `Assessment`, `AssessmentSource`, `AssessmentSourceType`, `Trace`, `CategoricalRating`, `mlflow`), execute via `exec()`, and return the recreated function.
- **Task Evidence**: Task mentions "Handle dynamic function reconstruction from serialized source code" and "Secure code execution during scorer deserialization (restricted to controlled environments)."
- **Acceptance**: `recreate_function("return x + y", "(x, y)", "add")` returns a callable `add` where `add(3, 4) == 7`. Invalid signature raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 77-131. Imported inline in `/testbed/mlflow/genai/scorers/base.py` line 303. Tests at `/testbed/tests/genai/scorers/test_scorer_utils.py` extensively cover happy paths, edge cases, and error conditions.
- **Uncertainty**: None.

### R13: ScorerKind.DECORATOR registration restriction
- **Type**: Compatibility / Security
- **Statement**: Decorator scorers (kind `DECORATOR`) MUST only be registerable when tracking URI is Databricks (`is_databricks_uri`). The `_check_can_be_registered` method MUST raise `MlflowException` otherwise with message "not supported outside of Databricks tracking environments."
- **Task Evidence**: Task mentions "Secure code execution during scorer deserialization (restricted to controlled environments)." Interface Description 1 notes registration only supported in Databricks.
- **Acceptance**: Calling `.register()` on a decorator scorer with non-Databricks tracking URI raises `MlflowException`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 806-831. Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 354-365.
- **Uncertainty**: None.

### R14: Scorer.run type validation
- **Type**: Interface / Failure
- **Statement**: `Scorer.run()` MUST validate that the return value of `__call__` is one of `(int, float, bool, str, Assessment, LegacyAssessment, None)` or `list[Assessment|LegacyAssessment]`. Otherwise MUST raise `MlflowException` with message containing the scorer name and the invalid type.
- **Task Evidence**: Interface Description 1: "The scorer function should return one of: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects." Also "Raises: MlflowException: If the scorer function returns an unsupported type."
- **Acceptance**: Scorer returning a dict raises `MlflowException` with "must return one of int, float, bool, str, Feedback, or list[Feedback]."
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 420-440 (the `run` method validation). Tests at `/testbed/tests/genai/scorers/test_scorer.py`.
- **Uncertainty**: None.

### R15: Default Feedback name overwrite in Scorer.run
- **Type**: Dataflow
- **Statement**: When `Scorer.run()` receives a single `Feedback` whose `name == DEFAULT_FEEDBACK_NAME`, MUST overwrite `result.name = self.name` for consistency between success and failure paths.
- **Task Evidence**: Task document mentions consistent interfaces. Implicit in the scoring framework design.
- **Acceptance**: `@scorer def my_scorer(...): return Feedback(value=42)` produces feedback with `name == "my_scorer"`.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 442-461. Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 310-340.
- **Uncertainty**: None.

### R16: scorer export chain to mlflow.genai
- **Type**: Interface / Compatibility
- **Statement**: The `scorer` function MUST be importable from `mlflow.genai` (i.e., `from mlflow.genai import scorer`), which requires export through `mlflow.genai.scorers.__init__` and `mlflow.genai.__init__`.
- **Task Evidence**: Interface Description 1 example code: `from mlflow.genai.scorers import scorer` and `from mlflow.genai import scorer`. Tests use both import paths.
- **Acceptance**: `from mlflow.genai import scorer` succeeds and returns the `scorer` function.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/__init__.py` line 75 lists `"scorer"` in `__all__` but does not import it (missing `from mlflow.genai.scorers.base import scorer`). `/testbed/mlflow/genai/__init__.py` line 50 lists `"scorer"` in `__all__` but line 43 only imports `Scorer`, not `scorer`. Tests at `/testbed/tests/genai/scorers/test_scorer.py` line 10 imports `from mlflow.genai import Scorer, scorer` — this currently fails due to missing export.
- **Uncertainty**: Both `__init__.py` files list `"scorer"` in `__all__` implying intent, but neither imports it. This is a static issue (missing symbol binding).

### R17: AssessmentSourceType export chain to mlflow.entities
- **Type**: Interface / Compatibility
- **Statement**: `AssessmentSourceType` MUST remain importable from `mlflow.entities` via the chain `mlflow.entities.__init__` → `mlflow.entities.assessment` → `mlflow.entities.assessment_source`.
- **Task Evidence**: Tests import `from mlflow.entities import AssessmentSourceType` (e.g., `/testbed/tests/genai/scorers/test_scorer.py` line 10).
- **Acceptance**: `from mlflow.entities import AssessmentSourceType` succeeds.
- **Repository Evidence**: `/testbed/mlflow/entities/__init__.py` line 10 imports `AssessmentSourceType` from `.assessment` (which re-exports from `.assessment_source`). This chain is intact. The only missing piece is the method bodies in `assessment_source.py`.
- **Uncertainty**: None.

### R18: Backward compatibility: AI_JUDGE deprecation
- **Type**: Compatibility
- **Statement**: The `AssessmentSourceType._parse` method MUST treat `"AI_JUDGE"` as valid input, emit `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`, and return `"LLM_JUDGE"`. The `AssessmentSource.__post_init__` must propagate this so that `AssessmentSource(source_type="AI_JUDGE").source_type == "LLM_JUDGE"`.
- **Task Evidence**: Interface Description 2 mentions "Deprecation warnings for legacy values (AI_JUDGE → LLM_JUDGE)" and "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE'."
- **Acceptance**: `AssessmentSource(source_type="AI_JUDGE").source_type == "LLM_JUDGE"` with `FutureWarning`.
- **Repository Evidence**: Tests at `/testbed/tests/entities/test_assessment_source.py` lines 76-81.
- **Uncertainty**: None.

---

## L2. Functional Design Graph

### N1: `scorer` function (entry point)
- **Kind**: Public Entry (decorator factory)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` (to be added at end of file). Referenced by tests and `__all__` in both `scorers/__init__.py` and `genai/__init__.py`.

### N2: `CustomScorer` (inner class)
- **Kind**: Class (Pydantic model, Scorer subclass)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` (to be added inside `scorer`). `/testbed/libs/skinny/mlflow/genai/scorers/base.py` confirms pattern.

### N3: `Scorer` (base class)
- **Kind**: Class (Pydantic BaseModel)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 111-881.

### N4: `Scorer.run` method
- **Kind**: Method (execution + validation)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 420-465.

### N5: `Scorer.model_dump` method
- **Kind**: Method (serialization)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 149-183.

### N6: `Scorer.model_validate` classmethod
- **Kind**: Method (deserialization dispatch)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 204-300.

### N7: `Scorer._extract_source_code_info` method
- **Kind**: Method (source extraction helper)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 186-198.

### N8: `Scorer._reconstruct_decorator_scorer` classmethod
- **Kind**: Method (deserialization helper)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 302-379.

### N9: `extract_function_body` function
- **Kind**: Helper (utility)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/scorer_utils.py` (body missing, must be added). Full implementation in `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py`.

### N10: `FunctionBodyExtractor` class
- **Kind**: Helper (AST visitor)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/scorer_utils.py` (body missing). Full implementation in `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py`.

### N11: `recreate_function` function
- **Kind**: Helper (dynamic code execution)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/scorer_utils.py` (body missing). Full implementation in `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py`.

### N12: `AssessmentSourceType` class
- **Kind**: Class (validator/enumeration)
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 102-194 (constants present, methods missing). Full implementation in `/testbed/libs/skinny/mlflow/entities/assessment_source.py`.

### N13: `AssessmentSourceType.__init__`
- **Kind**: Method (validation entry)
- **Repository Evidence**: Missing in main file; present in skinny/tracing libs.

### N14: `AssessmentSourceType._parse`
- **Kind**: Static Method (core validation logic)
- **Repository Evidence**: Missing in main file; present in skinny/tracing libs.

### N15: `AssessmentSourceType._standardize`
- **Kind**: Static Method (delegation wrapper)
- **Repository Evidence**: Missing in main file; present in skinny/tracing libs.

### N16: `AssessmentSourceType.__str__`
- **Kind**: Method (string conversion)
- **Repository Evidence**: Missing in main file; present in skinny/tracing libs.

### N17: `AssessmentSource.__post_init__`
- **Kind**: Method (dataclass post-init hook)
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 76-78.

### N18: `mlflow.genai.scorers.__init__` (package init)
- **Kind**: Module (export surface)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/__init__.py`.

### N19: `mlflow.genai.__init__` (package init)
- **Kind**: Module (export surface)
- **Repository Evidence**: `/testbed/mlflow/genai/__init__.py`.

### N20: `mlflow.entities.__init__` (package init)
- **Kind**: Module (export surface)
- **Repository Evidence**: `/testbed/mlflow/entities/__init__.py`.

### E1: scorer → CustomScorer
- **Kind**: CALL (instantiation)
- **Condition**: Always when `scorer` is invoked with a callable.
- **Transfer**: Returns `CustomScorer(name=..., description=..., aggregations=...)`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` tail.
- **Obligations**: R7, R8.

### E2: CustomScorer.__call__ → original function
- **Kind**: CALL (delegation)
- **Condition**: When `CustomScorer.__call__` (or `.run()`) is invoked.
- **Transfer**: Passes filtered kwargs to original decorated function.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` `CustomScorer.__call__`.
- **Obligations**: R8, R14, R15.

### E3: Scorer._extract_source_code_info → extract_function_body
- **Kind**: CALL (inline import + invocation)
- **Condition**: During `model_dump()` for decorator scorers.
- **Transfer**: Receives `(source_code_str, indent_unit)` tuple.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 188-193.
- **Obligations**: R9, R11.

### E4: Scorer._reconstruct_decorator_scorer → recreate_function
- **Kind**: CALL (inline import + invocation)
- **Condition**: During `model_validate()` for decorator scorers in Databricks runtime.
- **Transfer**: Receives recreated callable.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 303, 346.
- **Obligations**: R10, R12.

### E5: _reconstruct_decorator_scorer → scorer (decorator)
- **Kind**: CALL
- **Condition**: After recreating the function.
- **Transfer**: Wraps recreated function via `scorer(recreated_func, name=..., description=..., aggregations=...)`.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 356-361.
- **Obligations**: R10.

### E6: AssessmentSource.__post_init__ → AssessmentSourceType._standardize
- **Kind**: CALL
- **Condition**: Every `AssessmentSource` instantiation.
- **Transfer**: Receives validated uppercase string, writes to `self.source_type`.
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` line 78.
- **Obligations**: R6.

### E7: AssessmentSourceType._standardize → AssessmentSourceType.__init__
- **Kind**: CALL
- **Condition**: Always.
- **Transfer**: Creates temporary instance.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 189.
- **Obligations**: R5.

### E8: AssessmentSourceType.__init__ → AssessmentSourceType._parse
- **Kind**: CALL
- **Condition**: Always.
- **Transfer**: Stores `_parse` return value in `self._source_type`.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` line 162.
- **Obligations**: R2.

### E9: AssessmentSourceType._parse → warnings.warn (deprecation path)
- **Kind**: CONTROL / SIDE_EFFECT
- **Condition**: When input uppercased equals `"AI_JUDGE"`.
- **Transfer**: Emits `FutureWarning`, converts to `"LLM_JUDGE"`.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 168-174.
- **Obligations**: R4, R18.

### E10: AssessmentSourceType._parse → MlflowException (invalid path)
- **Kind**: CONTROL / STATE (error)
- **Condition**: When input uppercased not in `_SOURCE_TYPES`.
- **Transfer**: Raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 176-181.
- **Obligations**: R4.

### E11: mlflow.genai.scorers.__init__ → scorer (export)
- **Kind**: DATA (import binding)
- **Condition**: Module load time.
- **Transfer**: `scorer` symbol available as `mlflow.genai.scorers.scorer`.
- **Evidence**: `__all__` lists `"scorer"` but missing import statement. Tests expect this path.
- **Obligations**: R16.

### E12: mlflow.genai.__init__ → scorer (export)
- **Kind**: DATA (import binding)
- **Condition**: Module load time.
- **Transfer**: `scorer` symbol available as `mlflow.genai.scorer`.
- **Evidence**: `__all__` lists `"scorer"` but missing import statement. Tests expect this path.
- **Obligations**: R16.

### E13: Scorer._check_can_be_registered → MlflowException (security gate)
- **Kind**: CONTROL / STATE (error)
- **Condition**: When `self.kind == ScorerKind.DECORATOR` and not `is_databricks_uri(get_tracking_uri())`.
- **Transfer**: Raises `MlflowException` with security message.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 821-831.
- **Obligations**: R13.

### E14: Scorer.run → MlflowException (type validation failure)
- **Kind**: CONTROL / STATE (error)
- **Condition**: When `__call__` return value is not int/float/bool/str/Assessment/list[Assessment]/None.
- **Transfer**: Raises `MlflowException` with type error message.
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 432-438.
- **Obligations**: R14.

---

## L3. Verifiable Contracts

### C1: AssessmentSourceType constants are plain strings
- **Type**: Interface
- **Subject**: `AssessmentSourceType.LLM_JUDGE`
- **Relation**: `==`
- **Expected**: `"LLM_JUDGE"`
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` line 154. Skinny/tracing libs confirm.
- **Observe**: `FIELD_READ`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R1
- **Graph**: N12

### C2: AssessmentSourceType._SOURCE_TYPES contains valid non-deprecated types
- **Type**: Interface
- **Subject**: `AssessmentSourceType._SOURCE_TYPES`
- **Relation**: `==`
- **Expected**: `["SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "HUMAN", "CODE"]`
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` line 158.
- **Observe**: `FIELD_READ`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R1
- **Graph**: N12

### C3: _parse uppercases and validates valid types
- **Type**: Interface
- **Subject**: `AssessmentSourceType._parse("llm_judge")`
- **Relation**: `==`
- **Expected**: `"LLM_JUDGE"`
- **Evidence**: Skinny lib `/testbed/libs/skinny/mlflow/entities/assessment_source.py` lines 165-182. Test at `/testbed/tests/entities/test_assessment_source.py` lines 63-73.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R4
- **Graph**: N14

### C4: _parse emits FutureWarning for AI_JUDGE
- **Type**: Interface / Compatibility
- **Subject**: `warnings.warn` call during `_parse("AI_JUDGE")`
- **Relation**: `EMITS`
- **Expected**: `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
- **Evidence**: Skinny lib lines 168-174. Test at `/testbed/tests/entities/test_assessment_source.py` lines 76-81.
- **Observe**: `SIDE_EFFECT` (warnings emitted)
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R4, R18
- **Graph**: N14, E9

### C5: _parse raises for invalid type
- **Type**: Interface / Failure
- **Subject**: `AssessmentSourceType._parse("ROBOT")`
- **Relation**: `RAISES`
- **Expected**: `MlflowException` with message containing "Invalid assessment source type" and `error_code=INVALID_PARAMETER_VALUE`
- **Evidence**: Skinny lib lines 176-181. Test at `/testbed/tests/entities/test_assessment_source.py` lines 54-56.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R4
- **Graph**: N14, E10

### C6: __init__ stores validated value
- **Type**: Interface / State
- **Subject**: `AssessmentSourceType("human")._source_type`
- **Relation**: `==`
- **Expected**: `"HUMAN"`
- **Evidence**: Skinny lib line 162. Tests infer this through `str()` and `source_type` fields.
- **Observe**: `FIELD_READ`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R2
- **Graph**: N13, E8

### C7: __str__ returns stored value
- **Type**: Interface
- **Subject**: `str(AssessmentSourceType("llm_judge"))`
- **Relation**: `==`
- **Expected**: `"LLM_JUDGE"`
- **Evidence**: Skinny lib line 185-186. Test at `/testbed/tests/entities/test_assessment_source.py` lines 66-67.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R3
- **Graph**: N16

### C8: _standardize returns str of temporary instance
- **Type**: Interface
- **Subject**: `AssessmentSourceType._standardize("code")`
- **Relation**: `==`
- **Expected**: `"CODE"`
- **Evidence**: Skinny lib line 189. Called by `AssessmentSource.__post_init__`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R5
- **Graph**: N15, E7

### C9: AssessmentSource.__post_init__ normalizes source_type
- **Type**: Interface / Dataflow
- **Subject**: `AssessmentSource(source_type="human").source_type`
- **Relation**: `==`
- **Expected**: `"HUMAN"`
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` line 78. Test at `/testbed/tests/entities/test_assessment_source.py` lines 65-67.
- **Observe**: `FIELD_READ`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R6
- **Graph**: N17, E6

### C10: AssessmentSource with AI_JUDGE converts and warns
- **Type**: Compatibility
- **Subject**: `AssessmentSource(source_type="AI_JUDGE")`
- **Relation**: `COMBINED`
- **Expected**: `source_type == "LLM_JUDGE"` AND `FutureWarning` emitted
- **Evidence**: Test at `/testbed/tests/entities/test_assessment_source.py` lines 76-81.
- **Observe**: `FIELD_READ` + `SIDE_EFFECT`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R6, R18
- **Graph**: N17, E6, E9

### C11: scorer as decorator without arguments
- **Type**: Interface
- **Subject**: `@scorer` applied to a function `def f(outputs): return True`
- **Relation**: `INSTANCE_OF` / `HAS_ATTR`
- **Expected**: Returns `Scorer` instance with `kind == ScorerKind.DECORATOR`, `name == "f"`, `description is None`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` tail. Test at `/testbed/tests/genai/scorers/test_scorer_description.py` lines 25-28.
- **Observe**: `RETURN_VALUE` + `FIELD_READ`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R7, R8
- **Graph**: N1, N2, E1

### C12: scorer as decorator with arguments
- **Type**: Interface
- **Subject**: `scorer(name="custom", description="desc")(func)`
- **Relation**: `INSTANCE_OF` / `HAS_ATTR`
- **Expected**: Returns `Scorer` with `name == "custom"`, `description == "desc"`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` tail (functools.partial pattern). Test at `/testbed/tests/genai/scorers/test_scorer_description.py` lines 30-37.
- **Observe**: `RETURN_VALUE` + `FIELD_READ`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R7
- **Graph**: N1, N2

### C13: CustomScorer.__call__ delegates to original function
- **Type**: Dataflow
- **Subject**: Decorated `def f(outputs): return len(outputs) > 0` called via `.run(outputs="hello")`
- **Relation**: `==`
- **Expected**: `True`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` `CustomScorer.__call__`. Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 42-57.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R8
- **Graph**: N2, E2

### C14: Scorer.run validates return types
- **Type**: Failure
- **Subject**: Scorer whose `__call__` returns a `dict`
- **Relation**: `RAISES`
- **Expected**: `MlflowException` with "must return one of int, float, bool, str, Feedback, or list[Feedback]"
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 432-438.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R14
- **Graph**: N4, E14

### C15: Scorer.run overwrites default Feedback name
- **Type**: Dataflow
- **Subject**: `@scorer def my_scorer(...): return Feedback(value=42)`
- **Relation**: `HAS_ATTR`
- **Expected**: `result.name == "my_scorer"`
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 442-461. Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 310-340.
- **Observe**: `FIELD_READ`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R15
- **Graph**: N4

### C16: Scorer.run does NOT overwrite explicit Feedback name
- **Type**: Dataflow
- **Subject**: `@scorer def my_scorer(...): return Feedback(name="custom", value=42)`
- **Relation**: `HAS_ATTR`
- **Expected**: `result.name == "custom"`
- **Evidence**: Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 312-340.
- **Observe**: `FIELD_READ`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R15
- **Graph**: N4

### C17: Scorer.run does NOT overwrite Feedback names in list
- **Type**: Dataflow
- **Subject**: Scorer returning `list[Feedback]` with custom names
- **Relation**: `HAS_ATTR`
- **Expected**: Each feedback retains its explicit name
- **Evidence**: Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 342-352.
- **Observe**: `FIELD_READ`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R15
- **Graph**: N4

### C18: model_dump includes source code for decorator scorers
- **Type**: Interface
- **Subject**: `decorator_scorer.model_dump()`
- **Relation**: `HAS_KEY`
- **Expected**: Dict contains `call_source` (non-None str), `call_signature` (str), `original_func_name` (str)
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 169-183. Test at `/testbed/tests/genai/scorers/test_scorer_description.py` lines 82-92.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R9
- **Graph**: N5, E3

### C19: model_dump caches result in _cached_dump
- **Type**: State
- **Subject**: Second call to `scorer.model_dump()` after first
- **Relation**: `IS`
- **Expected**: Returns same dict (identity via `_cached_dump`), does not re-extract source
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 153-154.
- **Observe**: `RETURN_VALUE` (identity)
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R9
- **Graph**: N5

### C20: model_validate reconstructs decorator scorer (Databricks only)
- **Type**: Interface
- **Subject**: `Scorer.model_validate(serialized_dict)` with `call_source`, `call_signature`, `original_func_name`
- **Relation**: `INSTANCE_OF`
- **Expected**: Returns `Scorer` with `kind == ScorerKind.DECORATOR` when `is_in_databricks_runtime()` is True
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 302-379. Test at `/testbed/tests/genai/scorers/test_scorer_description.py` lines 95-108.
- **Observe**: `RETURN_VALUE` + `FIELD_READ`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R10
- **Graph**: N6, N8, E4, E5

### C21: model_validate blocks decorator scorers outside Databricks
- **Type**: Failure / Security
- **Subject**: `Scorer._reconstruct_decorator_scorer(serialized)` when `is_in_databricks_runtime()` is False
- **Relation**: `RAISES`
- **Expected**: `MlflowException` with "is not supported outside of Databricks runtime"
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 311-340. Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 366-378.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R10, R13
- **Graph**: N8, E13

### C22: Decorator scorer registration blocked for non-Databricks URI
- **Type**: Failure / Security
- **Subject**: `decorator_scorer.register()` with non-Databricks tracking URI
- **Relation**: `RAISES`
- **Expected**: `MlflowException` with "not supported outside of Databricks tracking"
- **Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 821-831. Test at `/testbed/tests/genai/scorers/test_scorer.py` lines 354-365.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/mlflow/genai/scorers/base.py`
- **Obligations**: R13
- **Graph**: N3, E13

### C23: extract_function_body extracts function source
- **Type**: Interface
- **Subject**: `extract_function_body(lambda: 42)` applied to a named function `def f(): return 42`
- **Relation**: `==`
- **Expected**: Returns `("return 42", <indent_unit>)`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 64-74.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/genai/scorers/scorer_utils.py`
- **Obligations**: R11
- **Graph**: N9, N10

### C24: FunctionBodyExtractor skips docstring
- **Type**: Interface
- **Subject**: Function with docstring `def f(): """doc"""; return 42`
- **Relation**: `NOT_CONTAINS`
- **Expected**: Extracted body is `"return 42"`, not `'"""doc"""; return 42'`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 31-36.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/genai/scorers/scorer_utils.py`
- **Obligations**: R11
- **Graph**: N10

### C25: recreate_function basic reconstruction
- **Type**: Interface
- **Subject**: `recreate_function("return x + y", "(x, y)", "add")`
- **Relation**: `CALL_RESULT`
- **Expected**: Callable `add` with `add(3, 4) == 7`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 77-131. Test at `/testbed/tests/genai/scorers/test_scorer_utils.py` lines 15-22.
- **Observe**: `RETURN_VALUE` (callable) + `RETURN_VALUE` (call result)
- **Target**: `/testbed/mlflow/genai/scorers/scorer_utils.py`
- **Obligations**: R12
- **Graph**: N11

### C26: recreate_function with MLflow imports available
- **Type**: Interface
- **Subject**: Function body using `Feedback(value=True)`
- **Relation**: `CALL_RESULT`
- **Expected**: Returns `Feedback` instance without ImportError
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 97-120 (namespace setup). Test at `/testbed/tests/genai/scorers/test_scorer_utils.py` lines 80-93.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/genai/scorers/scorer_utils.py`
- **Obligations**: R12
- **Graph**: N11

### C27: recreate_function with invalid signature raises
- **Type**: Failure
- **Subject**: `recreate_function("return 42", "invalid", "f")`
- **Relation**: `RAISES`
- **Expected**: `MlflowException` with `INVALID_PARAMETER_VALUE`
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 85-88. Test at `/testbed/tests/genai/scorers/test_scorer_utils.py` lines 228-233.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/mlflow/genai/scorers/scorer_utils.py`
- **Obligations**: R12
- **Graph**: N11

### C28: recreate_function with syntax error raises
- **Type**: Failure
- **Subject**: `recreate_function("if x > 0\n    return True", "(x)", "bad")` (missing colon)
- **Relation**: `RAISES`
- **Expected**: `SyntaxError`
- **Evidence**: Test at `/testbed/tests/genai/scorers/test_scorer_utils.py` lines 268-275.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/mlflow/genai/scorers/scorer_utils.py`
- **Obligations**: R12
- **Graph**: N11

### C29: scorer importable from mlflow.genai.scorers
- **Type**: Interface / Compatibility
- **Subject**: `from mlflow.genai.scorers import scorer`
- **Relation**: `SUCCEEDS`
- **Expected**: Import succeeds, `scorer` is the decorator function
- **Evidence**: `__all__` in `/testbed/mlflow/genai/scorers/__init__.py` line 76 lists `"scorer"`. Tests at `/testbed/tests/genai/optimize/test_optimize.py` line 12 use this path.
- **Observe**: `IMPORT_BOUNDARY`
- **Target**: `/testbed/mlflow/genai/scorers/__init__.py`
- **Obligations**: R16
- **Graph**: N18, E11

### C30: scorer importable from mlflow.genai
- **Type**: Interface / Compatibility
- **Subject**: `from mlflow.genai import scorer`
- **Relation**: `SUCCEEDS`
- **Expected**: Import succeeds, `scorer` is the decorator function
- **Evidence**: `__all__` in `/testbed/mlflow/genai/__init__.py` line 50 lists `"scorer"`. Tests at `/testbed/tests/genai/scorers/test_scorer.py` line 10 use this path.
- **Observe**: `IMPORT_BOUNDARY`
- **Target**: `/testbed/mlflow/genai/__init__.py`
- **Obligations**: R16
- **Graph**: N19, E12

### C31: AssessmentSourceType importable from mlflow.entities
- **Type**: Interface / Compatibility
- **Subject**: `from mlflow.entities import AssessmentSourceType`
- **Relation**: `SUCCEEDS`
- **Expected**: Import succeeds
- **Evidence**: `/testbed/mlflow/entities/__init__.py` line 10 imports from `.assessment`. Tests use this path.
- **Observe**: `IMPORT_BOUNDARY`
- **Target**: `/testbed/mlflow/entities/__init__.py`
- **Obligations**: R17
- **Graph**: N20

### C32: AssessmentSourceType.from_proto preserves existing behavior
- **Type**: Compatibility
- **Subject**: `AssessmentSourceType.from_proto(proto_source_type)`
- **Relation**: `==`
- **Expected**: Returns `ProtoAssessmentSource.SourceType.Name(proto_source_type)` (unchanged)
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 192-194.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R17
- **Graph**: N12

### C33: AssessmentSource.to_proto uses normalized source_type
- **Type**: Compatibility
- **Subject**: `AssessmentSource(source_type="human").to_proto()`
- **Relation**: `HAS_ATTR`
- **Expected**: Proto `source_type` field set to `ProtoAssessmentSource.SourceType.Value("HUMAN")` (via `__post_init__` normalization)
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py` lines 87-92.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/mlflow/entities/assessment_source.py`
- **Obligations**: R6
- **Graph**: N17

---

## Static Issue Disposition

| Issue | Disposition |
|-------|-------------|
| `extract_function_body` used but not defined in `base.py` | **In scope.** Must be defined in `/testbed/mlflow/genai/scorers/scorer_utils.py`. Imported inline in `base.py` line 188. Contract C23 covers this. |
| `recreate_function` used but not defined in `base.py` | **In scope.** Must be defined in `/testbed/mlflow/genai/scorers/scorer_utils.py`. Imported inline in `base.py` line 303. Contract C25 covers this. |
| `scorer` used but not defined in `base.py` | **In scope.** Must be defined in `/testbed/mlflow/genai/scorers/base.py` (at end of file). Used internally by `_reconstruct_decorator_scorer` (line 356) and exported to callers. Contracts C11, C12 cover this. |
| `scorer` in `__all__` of `scorers/__init__.py` but not imported | **In scope.** Must add `from mlflow.genai.scorers.base import scorer` to `scorers/__init__.py`. Contract C29. |
| `scorer` in `__all__` of `genai/__init__.py` but not imported | **In scope.** Must add `from mlflow.genai.scorers import scorer` to `genai/__init__.py`. Contract C30. |
| `AssessmentSourceType` methods missing in main file | **In scope.** `__init__`, `__str__`, `_parse`, `_standardize` must be added. Skinny/tracing libs contain reference implementation. Contracts C3-C8. |
| `FunctionBodyExtractor` class body empty in `scorer_utils.py` | **In scope.** Must fill in AST visitor logic. Reference in skinny/tracing libs. Contract C24. |
| `extract_function_body` body empty in `scorer_utils.py` | **In scope.** Must fill in source extraction logic. Contract C23. |
| `recreate_function` body empty in `scorer_utils.py` | **In scope.** Must fill in dynamic function reconstruction. Contracts C25-C28. |
