"""
Executable architecture spec for AssessmentSourceType / scorer framework.

Covers public scope, import/dependency binding, graph connectivity,
real CALL/CONTROL paths, and dataflow.

Contracts mapped: C9, C23, C25, C29, C30, C31, C32, C33
Edges mapped: E3, E4, E5, E6, E7, E8, E11, E12
Requirements: R1, R5, R6, R7, R8, R11, R12, R16, R17

Static-issue closure:
- 'scorer' in scorers/__init__.py: C29, C30 checks verify runtime importability
- 'extract_function_body' in base.py: C23 checks real caller-binding from _extract_source_code_info
- 'recreate_function' in base.py: C25 checks real caller-binding from _reconstruct_decorator_scorer
- 'scorer' in base.py: C29, C30, and identity check verify the decorator is callable

Review report resolution:
- Finding 2 (weak_constraint): Added check_Cnew_subunit_extract_source_code_info which tests
  _extract_source_code_info independently of the full scorer decorator chain.
- Finding 3 (weak_constraint): Added check_C29_C30_scorer_import_identity which verifies
  both import paths (mlflow.genai.scorers and mlflow.genai) resolve to the same scorer function.
"""

import sys
import inspect
import warnings


def check_C29_scorer_importable_from_mlflow_genai_scorers():
    """
    # Contracts: C29
    # Requirements: R16
    # Repository test: /testbed/tests/genai/optimize/test_optimize.py line 12
    #   uses `from mlflow.genai.scorers import scorer`
    # Perspective: Public-surface contract – verify scorer is importable from
    #   the scorers subpackage as declared in __all__.
    # Source: /testbed/mlflow/genai/scorers/__init__.py (E11)
    # Static issue: 'scorer' in __all__ of scorers/__init__.py but not imported
    """
    from mlflow.genai.scorers import scorer as sc

    assert callable(sc), "scorer must be callable from mlflow.genai.scorers"
    print("PASS: C29 scorer importable from mlflow.genai.scorers")


def check_C30_scorer_importable_from_mlflow_genai():
    """
    # Contracts: C30
    # Requirements: R16
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py line 10
    #   uses `from mlflow.genai import scorer`
    # Perspective: Public-surface contract – verify scorer is importable from
    #   mlflow.genai top-level as declared in __all__.
    # Source: /testbed/mlflow/genai/__init__.py (E12)
    # Static issue: 'scorer' in __all__ of genai/__init__.py but not imported
    """
    from mlflow.genai import scorer as sc

    assert callable(sc), "scorer must be callable from mlflow.genai"
    print("PASS: C30 scorer importable from mlflow.genai")


def check_C29_C30_scorer_import_identity():
    """
    # Contracts: C29, C30
    # Requirements: R16
    # Repository test: /testbed/tests/genai/scorers/test_scorer.py line 10
    #   uses `from mlflow.genai import scorer`; /testbed/tests/genai/optimize/
    #   test_optimize.py line 12 uses `from mlflow.genai.scorers import scorer`
    # Perspective: Public-surface contract – verify both import paths
    #   (mlflow.genai.scorers and mlflow.genai) resolve to the same underlying
    #   scorer function, proving the re-export chain genai/__init__.py →
    #   scorers/__init__.py → scorers/base.py is intact.
    # Source: /testbed/mlflow/genai/__init__.py (E12),
    #   /testbed/mlflow/genai/scorers/__init__.py (E11)
    # Static issue: 'scorer' in __all__ of both __init__.py files but imports missing
    # Review Finding 3: identity check prevents accidental stub or wrong symbol
    """
    from mlflow.genai import scorer as sc_from_genai
    from mlflow.genai.scorers import scorer as sc_from_scorers

    assert sc_from_genai is sc_from_scorers, (
        "Both import paths must resolve to the same scorer function object. "
        f"genai path: {sc_from_genai}, scorers path: {sc_from_scorers}"
    )
    assert callable(sc_from_genai), "scorer must be callable"
    assert callable(sc_from_scorers), "scorer must be callable"
    print("PASS: C29/C30 scorer import identity – both paths resolve to same function")


def check_C31_AssessmentSourceType_importable_from_mlflow_entities():
    """
    # Contracts: C31
    # Requirements: R17
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   uses AssessmentSource (which depends on AssessmentSourceType)
    # Perspective: Public-surface contract – verify AssessmentSourceType is
    #   importable from mlflow.entities as declared in __init__.
    # Source: /testbed/mlflow/entities/__init__.py line 10
    """
    from mlflow.entities import AssessmentSourceType

    assert AssessmentSourceType is not None
    # Verify it is the class, not something else
    assert hasattr(AssessmentSourceType, "LLM_JUDGE"), "Must expose LLM_JUDGE constant"
    assert hasattr(AssessmentSourceType, "HUMAN"), "Must expose HUMAN constant"
    assert hasattr(AssessmentSourceType, "CODE"), "Must expose CODE constant"
    print("PASS: C31 AssessmentSourceType importable from mlflow.entities")


def check_C9_E6_AssessmentSource_post_init_normalizes_via_standardize():
    """
    # Contracts: C9
    # Edges: E6
    # Requirements: R6
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_case_insensitivity lines 60-73
    # Perspective: Caller-binding – AssessmentSource.__post_init__ must call
    #   AssessmentSourceType._standardize and store result in source_type.
    # Source: /testbed/mlflow/entities/assessment_source.py line 78
    """
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    # Verify the __post_init__ dataflow: case-insensitive normalization
    src = AssessmentSource(source_type="human", source_id="x")
    assert src.source_type == "HUMAN", (
        f"Expected HUMAN, got {src.source_type}. __post_init__ must normalize via _standardize."
    )

    # Verify _standardize is actually called (via its effect on case)
    # Lowercase input must become uppercase
    src2 = AssessmentSource(source_type="code", source_id="y")
    assert src2.source_type == "CODE"

    # Verify source_type is a plain string (not an AssessmentSourceType instance)
    assert isinstance(src.source_type, str)

    print("PASS: C9/E6 AssessmentSource.__post_init__ normalizes source_type via _standardize")


def check_E7_E8_standardize_delegates_to_init_to_parse():
    """
    # Contracts: C8 (behavioral side; arch proves the path)
    # Edges: E7, E8
    # Requirements: R2, R5
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_case_insensitivity lines 60-73
    # Perspective: Caller-binding – _standardize creates a temp instance which
    #   calls _parse; the result flows back.
    # Source: /testbed/mlflow/entities/assessment_source.py line 78,
    #   /testbed/libs/skinny/mlflow/entities/assessment_source.py lines 161-189
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    # E7: _standardize → __init__ → _parse
    # Validate the delegation chain works end-to-end
    result = AssessmentSourceType._standardize("llm_judge")
    assert result == "LLM_JUDGE", f"Expected LLM_JUDGE, got {result}"

    # Verify the path: _standardize creates temp AssessmentSourceType instance
    # whose __init__ calls _parse. _parse uppercases and validates.
    # Test with a deprecated value (AI_JUDGE) to verify deprecation path
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result_dep = AssessmentSourceType._standardize("AI_JUDGE")
    assert result_dep == "LLM_JUDGE", f"Expected LLM_JUDGE for AI_JUDGE, got {result_dep}"
    assert len(w) >= 1
    assert issubclass(w[0].category, FutureWarning)

    print("PASS: E7/E8 _standardize → __init__ → _parse delegation chain works")


def check_Cnew_subunit_extract_source_code_info_caller_binding():
    """
    # Contracts: C23 (new; sub-unit caller-binding)
    # Edges: E3
    # Requirements: R7, R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_serialization lines 85-95
    # Perspective: Sub-unit caller-binding – verify that _extract_source_code_info
    #   correctly calls extract_function_body from scorer_utils via inline import
    #   at the real call site, without requiring the full scorer decorator chain.
    #   This isolates the dataflow model_dump → _extract_source_code_info →
    #   extract_function_body so a failure in scorer() does not mask a failure
    #   in _extract_source_code_info.
    # Source: /testbed/mlflow/genai/scorers/base.py line 186 (Scorer._extract_source_code_info)
    # Static issue: 'extract_function_body' used but not defined/imported in base.py
    # Review Finding 2: independent sub-unit check decouples _extract_source_code_info
    #   testing from scorer decorator bootstrap.
    """
    from unittest.mock import MagicMock

    from mlflow.genai.scorers.base import Scorer

    # Create a Scorer subclass that carries a mock _original_func so we can
    # exercise _extract_source_code_info directly without going through scorer().
    mock_func = MagicMock()
    mock_func.__name__ = "mock_scorer_func"

    class _TestScorer(Scorer):
        _original_func = mock_func

    scorer_instance = _TestScorer(name="test_scorer")

    # The inline import from mlflow.genai.scorers.scorer_utils import extract_function_body
    # must resolve inside _extract_source_code_info. If it's missing/incorrect,
    # this will raise ImportError or NameError.
    source_info = scorer_instance._extract_source_code_info()

    assert isinstance(source_info, dict), "Must return a dict"
    assert "call_source" in source_info, "Missing call_source key"
    assert "call_signature" in source_info, "Missing call_signature key"
    assert "original_func_name" in source_info, "Missing original_func_name key"

    # The original_func_name must match the mock's __name__
    assert source_info["original_func_name"] == "mock_scorer_func", (
        f"Expected mock_scorer_func, got {source_info['original_func_name']}"
    )

    # call_signature should be the inspect.signature of the mock
    assert source_info["call_signature"] is not None, "call_signature must not be None"

    print("PASS: Cnew _extract_source_code_info → extract_function_body caller-binding works")


def check_E3_extract_source_code_info_calls_extract_function_body():
    """
    # Contracts: C23
    # Edges: E3
    # Requirements: R7, R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_serialization lines 85-95
    # Perspective: Caller-binding – model_dump → _extract_source_code_info →
    #   extract_function_body. An end-to-end test that exercises the full
    #   serialization path for a decorator scorer.
    # Source: /testbed/mlflow/genai/scorers/base.py lines 149-184
    # Static issue: 'extract_function_body' used but not defined/imported in base.py
    """
    from mlflow.genai import scorer as sc

    @sc
    def _arch_test_func(outputs) -> bool:
        """Docstring that should be skipped."""
        return bool(outputs)

    # E3: model_dump → _extract_source_code_info → extract_function_body
    # Verify the real call path: model_dump produces call_source etc.
    dumped = _arch_test_func.model_dump()

    assert "call_source" in dumped, "model_dump must contain call_source"
    assert dumped["call_source"] is not None, "call_source must not be None for decorator scorer"
    assert "call_signature" in dumped, "model_dump must contain call_signature"
    assert dumped["call_signature"] is not None, "call_signature must not be None"
    assert "original_func_name" in dumped, "model_dump must contain original_func_name"
    assert dumped["original_func_name"] == "_arch_test_func"

    # The extracted source should contain the function body (not docstring)
    assert "bool(outputs)" in dumped["call_source"], (
        "call_source must contain the actual function body code"
    )

    print("PASS: E3 model_dump → extract_function_body dataflow verified")


def check_E4_E5_reconstruct_decorator_scorer_calls_recreate_function_and_scorer():
    """
    # Contracts: C25 (arch side: the call path)
    # Edges: E4, E5
    # Requirements: R10, R12
    # Repository test: /testbed/tests/genai/scorers/test_scorer_description.py
    #   test_scorer_deserialization_with_description lines 95-108
    # Perspective: Caller-binding – Scorer.model_validate for decorator scorers
    #   must inline-import and call recreate_function, then wrap result with scorer().
    # Source: /testbed/mlflow/genai/scorers/base.py lines 302-379
    # Static issue: 'recreate_function' and 'scorer' used but not defined/imported in base.py
    """
    from unittest.mock import patch

    from mlflow.genai import scorer as sc
    from mlflow.genai.scorers.base import Scorer, ScorerKind

    # Create and serialize a decorator scorer
    @sc(description="arch test")
    def _arch_recon_test(outputs) -> bool:
        return len(outputs) > 0

    serialized = _arch_recon_test.model_dump()

    # E4/E5: _reconstruct_decorator_scorer calls recreate_function then scorer()
    # This must work when is_in_databricks_runtime() is True
    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        reconstructed = Scorer._reconstruct_decorator_scorer(serialized)

    assert reconstructed is not None
    assert reconstructed.kind == ScorerKind.DECORATOR
    assert reconstructed.name == "_arch_recon_test"
    assert reconstructed.description == "arch test"

    # Verify the reconstructed scorer works
    result = reconstructed.run(outputs="hello")
    assert result is True

    print("PASS: E4/E5 _reconstruct_decorator_scorer → recreate_function → scorer path works")


def check_C32_AssessmentSourceType_from_proto_exists():
    """
    # Contracts: C32
    # Requirements: R17
    # Repository test: None directly; proto path tested in integration.
    #   Evidence from /testbed/mlflow/entities/assessment_source.py lines 192-194.
    # Perspective: Public-surface – from_proto classmethod must exist and be callable.
    # Source: /testbed/mlflow/entities/assessment_source.py
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.protos.assessments_pb2 import AssessmentSource as ProtoAssessmentSource

    assert hasattr(AssessmentSourceType, "from_proto"), "from_proto must exist"
    assert callable(AssessmentSourceType.from_proto), "from_proto must be callable"

    # Test with a valid proto source type value (LLM_JUDGE = 2)
    result = AssessmentSourceType.from_proto(ProtoAssessmentSource.SourceType.LLM_JUDGE)
    assert result == "LLM_JUDGE", f"Expected LLM_JUDGE, got {result}"

    print("PASS: C32 AssessmentSourceType.from_proto exists and works")


def check_C33_AssessmentSource_to_proto_uses_normalized_source_type():
    """
    # Contracts: C33
    # Requirements: R6
    # Repository test: /testbed/tests/entities/test_assessment_source.py
    #   test_assessment_source_case_insensitivity lines 60-73
    # Perspective: Dataflow – to_proto must use the normalized (uppercase)
    #   source_type from __post_init__, not the raw input.
    # Source: /testbed/mlflow/entities/assessment_source.py lines 87-92
    """
    from mlflow.entities.assessment_source import AssessmentSource

    # Create with lowercase, verify to_proto uses uppercase
    src = AssessmentSource(source_type="human", source_id="user_1")
    proto = src.to_proto()

    # The proto source_type should be "HUMAN" (the normalized value)
    from mlflow.protos.assessments_pb2 import AssessmentSource as ProtoAssessmentSource

    expected_value = ProtoAssessmentSource.SourceType.Value("HUMAN")
    assert proto.source_type == expected_value, (
        f"to_proto source_type {proto.source_type} != {expected_value}"
    )

    print("PASS: C33 AssessmentSource.to_proto uses normalized source_type")


# ============================================================================
# Runner
# ============================================================================
if __name__ == "__main__":
    all_checks = [
        check_C29_scorer_importable_from_mlflow_genai_scorers,
        check_C30_scorer_importable_from_mlflow_genai,
        check_C29_C30_scorer_import_identity,
        check_C31_AssessmentSourceType_importable_from_mlflow_entities,
        check_C9_E6_AssessmentSource_post_init_normalizes_via_standardize,
        check_E7_E8_standardize_delegates_to_init_to_parse,
        check_Cnew_subunit_extract_source_code_info_caller_binding,
        check_E3_extract_source_code_info_calls_extract_function_body,
        check_E4_E5_reconstruct_decorator_scorer_calls_recreate_function_and_scorer,
        check_C32_AssessmentSourceType_from_proto_exists,
        check_C33_AssessmentSource_to_proto_uses_normalized_source_type,
    ]
    failed = 0
    for check in all_checks:
        try:
            check()
        except Exception as e:
            failed += 1
            print(f"FAIL: {check.__name__}: {e}")
    if failed:
        print(f"\n{failed} check(s) FAILED")
        sys.exit(1)
    print(f"\nAll {len(all_checks)} architecture checks passed.")
