# Static Analysis

## Scope
- Repository: `/testbed`
- Declared interfaces: 10
- `mlflow/genai/scorers/base.py`: `scorer` (function)
- `mlflow/genai/scorers/base.py`: `not_empty` (function)
- `mlflow/genai/scorers/base.py`: `exact_match` (function)
- `mlflow/genai/scorers/base.py`: `num_tool_calls` (function)
- `mlflow/genai/scorers/base.py`: `harmfulness` (function)
- `mlflow/entities/assessment_source.py`: `AssessmentSourceType` (class)
- `mlflow/entities/assessment_source.py`: `AssessmentSourceType.__init__` (method)
- `mlflow/entities/assessment_source.py`: `AssessmentSourceType.__str__` (method)
- `mlflow/entities/assessment_source.py`: `AssessmentSourceType._parse` (method)
- `mlflow/entities/assessment_source.py`: `AssessmentSourceType._standardize` (method)

## Findings
## static issue

- **`mlflow/genai/scorers/base.py`** (3):
  - ? 'extract_function_body' is used but not defined or imported in this file
  - ? 'recreate_function' is used but not defined or imported in this file
  - ? 'scorer' is used but not defined or imported in this file

## Use
- Requirement Compile: use findings to identify dependency, caller-binding, and compatibility risks.
- Test Spec: compile relevant findings into runtime checks; static evidence alone is not a behavior proof.
