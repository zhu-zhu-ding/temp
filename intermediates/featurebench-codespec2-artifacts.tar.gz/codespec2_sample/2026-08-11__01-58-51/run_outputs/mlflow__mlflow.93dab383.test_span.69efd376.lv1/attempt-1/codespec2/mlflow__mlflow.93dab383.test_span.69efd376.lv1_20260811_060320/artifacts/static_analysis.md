# Static Analysis

## Scope
- Repository: `/testbed`
- Declared interfaces: 33
- `mlflow/tracing/trace_manager.py`: `_Trace` (class)
- `mlflow/tracing/trace_manager.py`: `_Trace.to_mlflow_trace` (method)
- `mlflow/entities/span.py`: `LiveSpan` (class)
- `mlflow/entities/span.py`: `LiveSpan.from_dict` (method)
- `mlflow/entities/span.py`: `LiveSpan.set_span_type` (method)
- `mlflow/entities/span.py`: `LiveSpan.to_immutable_span` (method)
- `mlflow/entities/span.py`: `NoOpSpan` (class)
- `mlflow/entities/span.py`: `NoOpSpan._trace_id` (method)
- `mlflow/entities/span.py`: `NoOpSpan.add_event` (method)
- `mlflow/entities/span.py`: `NoOpSpan.end` (method)
- `mlflow/entities/span.py`: `NoOpSpan.end_time_ns` (method)
- `mlflow/entities/span.py`: `NoOpSpan.name` (method)
- `mlflow/entities/span.py`: `NoOpSpan.set_attribute` (method)
- `mlflow/entities/span.py`: `NoOpSpan.set_attributes` (method)
- `mlflow/entities/span.py`: `NoOpSpan.set_inputs` (method)
- `mlflow/entities/span.py`: `NoOpSpan.set_outputs` (method)
- `mlflow/entities/span.py`: `NoOpSpan.set_status` (method)
- `mlflow/entities/span.py`: `NoOpSpan.span_id` (method)
- `mlflow/entities/span.py`: `NoOpSpan.start_time_ns` (method)
- `mlflow/entities/span.py`: `NoOpSpan.status` (method)
- `mlflow/entities/span.py`: `NoOpSpan.trace_id` (method)
- `mlflow/entities/span.py`: `Span` (class)
- `mlflow/entities/span.py`: `Span.attributes` (method)
- `mlflow/entities/span.py`: `Span.events` (method)
- `mlflow/entities/span.py`: `Span.from_otel_proto` (method)
- `mlflow/entities/span.py`: `Span.request_id` (method)
- `mlflow/entities/span.py`: `Span.span_type` (method)
- `mlflow/entities/span.py`: `Span.to_dict` (method)
- `mlflow/entities/span.py`: `Span.to_otel_proto` (method)
- `mlflow/entities/span.py`: `_CachedSpanAttributesRegistry` (class)
- `mlflow/entities/span.py`: `_CachedSpanAttributesRegistry.set` (method)
- `mlflow/entities/span.py`: `_CachedSpanAttributesRegistry.create_mlflow_span` (method)
- `mlflow/tracing/utils/otlp.py`: `_decode_otel_proto_anyvalue` (function)

## Findings
## static issue

- **`mlflow/entities/span.py`** (3):
  - ? '_decode_id_from_byte' is used but not defined or imported in this file
  - ? '_is_base64_encoded' is used but not defined or imported in this file
  - ? 'apply_span_processors' is used but not defined or imported in this file
- **`mlflow/store/tracking/sqlalchemy_store.py`** (1):
  - ? '_get_truncated_preview' is used but not defined or imported in this file
- **`mlflow/tracing/processor/base_mlflow.py`** (1):
  - ? 'create_mlflow_span' is used but not defined or imported in this file

## Use
- Requirement Compile: use findings to identify dependency, caller-binding, and compatibility risks.
- Test Spec: compile relevant findings into runtime checks; static evidence alone is not a behavior proof.
