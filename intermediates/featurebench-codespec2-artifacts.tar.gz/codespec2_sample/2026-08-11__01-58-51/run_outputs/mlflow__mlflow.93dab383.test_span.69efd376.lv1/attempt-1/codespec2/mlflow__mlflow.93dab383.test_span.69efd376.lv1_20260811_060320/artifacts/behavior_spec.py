"""
Executable behavior spec for MLflow Distributed Tracing System.

Covers: return values, field values, types, ordering, defaults,
state transitions, errors, side effects, compatibility, and boundary
cases.

Each check_* function exercises a specific L3 contract from the IR
and asserts the exact observable outcome.
"""

import base64
import sys
import traceback


PASSED = 0
FAILED = 0


def _pass(msg: str) -> None:
    global PASSED
    PASSED += 1
    print(f"PASS: {msg}")


def _fail(msg: str) -> None:
    global FAILED
    FAILED += 1
    print(f"FAIL: {msg}")


# ── Helpers ──────────────────────────────────────────────────────────


def _make_mock_otel_span(trace_id=1, span_id=1, name="test_span"):
    """Create a minimal mock OTel Span (live, mutable).

    Fix (F3): set_attribute / set_attributes write to s.attributes (real dict)
    so that _SpanAttributesRegistry.get reads the same store that
    _SpanAttributesRegistry.set writes to.  This matches the repository
    test pattern in tests/tracing/helper.py L65-85.
    """
    from unittest import mock
    import opentelemetry.sdk.trace as otel_sdk

    s = mock.MagicMock(spec=otel_sdk.ReadableSpan)
    s.name = name
    s._start_time = 100
    s._end_time = None
    ctx = mock.MagicMock()
    ctx.trace_id = trace_id
    ctx.span_id = span_id
    s.context = ctx
    s.parent = None
    s.attributes = {}            # real dict – shared read/write store
    s.events = []
    s.status = mock.MagicMock()
    s.status.status_code = mock.MagicMock()
    s.status.status_code.name = "UNSET"
    s.status.description = ""
    s.get_span_context = lambda: ctx

    # Write to s.attributes (same dict read by _SpanAttributesRegistry.get)
    def _set_attr(k, v):
        s.attributes[k] = v
    s.set_attribute = _set_attr
    s.set_attributes = lambda d: s.attributes.update(d)

    s._events_list = []
    def _add_event(name, attributes=None, timestamp=None):
        from opentelemetry.sdk.trace import Event as OTelEvent
        s._events_list.append(OTelEvent(name, attributes, timestamp))
    s.add_event = _add_event
    s.events = s._events_list

    return s


def _make_mock_otel_readable_span(
    trace_id=1, span_id=1, name="test_span",
    parent_id=None, attributes=None, events=None,
    start_time=100, end_time=200,
):
    """Create a minimal mock OTel ReadableSpan (finished, immutable)."""
    from unittest import mock

    s = mock.MagicMock()
    s.name = name
    s._start_time = start_time
    s._end_time = end_time

    ctx = mock.MagicMock()
    ctx.trace_id = trace_id
    ctx.span_id = span_id
    s.context = ctx

    if parent_id is not None:
        parent_ctx = mock.MagicMock()
        parent_ctx.span_id = parent_id
        s.parent = parent_ctx
    else:
        s.parent = None

    s.attributes = attributes or {}
    s.events = events or []
    s.status = mock.MagicMock()
    s.status.status_code = mock.MagicMock()
    s.status.status_code.name = "OK"
    s.status.description = ""
    s.get_span_context = lambda: ctx

    return s


# ── Behavior Checks ──────────────────────────────────────────────────


def check_C1_livespan_from_dict_raises_not_implemented() -> None:
    """
    # Contract: C1, R1 — LiveSpan.from_dict raises NotImplementedError
    # Guidance: Interface Description 2. No existing repository test
    #   directly tests this, but the skinny reference confirms.
    # Perspective: Failure contract — verify exact exception type.
    # Source: /testbed/mlflow/entities/span.py (skinny L665-666)
    """
    from mlflow.entities.span import LiveSpan

    try:
        LiveSpan.from_dict({"some": "data"})
        _fail("C1: LiveSpan.from_dict did not raise")
    except NotImplementedError:
        _pass("C1: LiveSpan.from_dict raises NotImplementedError")
    except Exception as e:
        _fail(f"C1: LiveSpan.from_dict raised {type(e).__name__} instead of NotImplementedError: {e}")


def check_C2_livespan_set_span_type_observable() -> None:
    """
    # Contract: C2, R2 — LiveSpan.set_span_type sets the span_type
    #   attribute and is observable via span_type property.
    # Guidance: Interface Description 2.
    # Perspective: Side-effect — verify the attribute is stored and
    #   retrievable through the public property.
    # Source: /testbed/mlflow/entities/span.py (skinny L525-527)
    """
    from mlflow.entities.span import LiveSpan

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-test", "UNKNOWN")
    live.set_span_type("LLM")
    st = live.span_type
    assert st == "LLM", f"Expected 'LLM', got {st!r}"
    _pass("C2: LiveSpan.set_span_type('LLM') → span_type == 'LLM'")


def check_C2_livespan_set_span_type_custom() -> None:
    """
    # Contract: C2, R2 — LiveSpan.set_span_type with custom string
    # Guidance: Interface Description 2 mentions custom strings are allowed.
    # Perspective: Combination — verify custom span types are supported.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import LiveSpan

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-test", "UNKNOWN")
    live.set_span_type("CUSTOM_OPERATION")
    assert live.span_type == "CUSTOM_OPERATION"
    _pass("C2: LiveSpan.set_span_type('CUSTOM_OPERATION') → span_type == 'CUSTOM_OPERATION'")


def check_C2_livespan_set_span_type_overwrite() -> None:
    """
    # Contract: C2 — Setting span_type multiple times overwrites
    # Guidance: Interface Description 2: "Setting the span type multiple
    #   times will overwrite the previous value".
    # Perspective: Lifecycle — verify overwrite semantics.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import LiveSpan

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-test", "UNKNOWN")
    live.set_span_type("LLM")
    live.set_span_type("CHAIN")
    assert live.span_type == "CHAIN"
    _pass("C2: LiveSpan.set_span_type overwrite: 'LLM' then 'CHAIN' → 'CHAIN'")


def check_C3_livespan_to_immutable_span_preserves_data() -> None:
    """
    # Contract: C3, R3 — LiveSpan.to_immutable_span returns Span
    #   with same data (name, span_id, attributes).
    # Guidance: Interface Description 2; skinny L668-675.
    # Perspective: State transition — verify data preservation.
    # Source: /testbed/mlflow/entities/span.py (skinny L668-675)
    """
    from mlflow.entities.span import LiveSpan, Span

    otel = _make_mock_otel_span(name="my_span")
    live = LiveSpan(otel, "tr-test", "LLM")
    immutable = live.to_immutable_span()

    assert isinstance(immutable, Span), f"Expected Span, got {type(immutable)}"
    assert not isinstance(immutable, LiveSpan), "Must not be LiveSpan"
    assert immutable.name == "my_span"
    _pass("C3: to_immutable_span preserves name and returns Span")


# ── NoOpSpan checks (C4-C17) ─────────────────────────────────────────


def check_C4_noop_trace_id_internal_is_none() -> None:
    """
    # Contract: C4, R4 — NoOpSpan._trace_id returns None
    # Guidance: Interface Description 2.
    # Perspective: Return value — verify internal trace ID is None.
    # Source: /testbed/mlflow/entities/span.py (skinny L820)
    """
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    assert noop._trace_id is None
    _pass("C4: NoOpSpan._trace_id is None")


def check_C5_noop_add_event_is_noop() -> None:
    """
    # Contract: C5, R5 — NoOpSpan.add_event does not raise
    # Guidance: Interface Description 2.
    # Perspective: Side-effect — verify no exception.
    # Source: /testbed/mlflow/entities/span.py (skinny L838)
    """
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_event import SpanEvent

    noop = NoOpSpan()
    noop.add_event(SpanEvent("test_event", 0, {}))
    _pass("C5: NoOpSpan.add_event does not raise")


def check_C6_noop_end_is_noop() -> None:
    """
    # Contract: C6, R6 — NoOpSpan.end does not raise regardless of args
    # Guidance: Interface Description 2.
    # Perspective: Side-effect — verify no exception with various arg combos.
    # Source: /testbed/mlflow/entities/span.py (skinny L844-851)
    """
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_status import SpanStatus

    noop = NoOpSpan()

    # No args
    noop.end()
    _pass("C6: NoOpSpan.end() no args — ok")

    # All args
    noop.end(outputs={"x": 1}, attributes={"k": "v"}, status="OK", end_time_ns=100)
    _pass("C6: NoOpSpan.end(all args) — ok")

    # SpanStatus object
    noop.end(status=SpanStatus("ERROR"))
    _pass("C6: NoOpSpan.end(status=SpanStatus) — ok")


def check_C7_noop_end_time_ns_is_none() -> None:
    """
    # Contract: C7, R7 — NoOpSpan.end_time_ns returns None
    # Guidance: Interface Description 2.
    # Perspective: Return value.
    # Source: /testbed/mlflow/entities/span.py (skinny L804)
    """
    from mlflow.entities.span import NoOpSpan

    assert NoOpSpan().end_time_ns is None
    _pass("C7: NoOpSpan.end_time_ns is None")


def check_C8_noop_name_is_none() -> None:
    """
    # Contract: C8, R8 — NoOpSpan.name returns None
    # Guidance: Interface Description 2.
    # Perspective: Return value.
    # Source: /testbed/mlflow/entities/span.py (skinny L796)
    """
    from mlflow.entities.span import NoOpSpan

    assert NoOpSpan().name is None
    _pass("C8: NoOpSpan.name is None")


def check_C9_noop_set_attribute_is_noop() -> None:
    """
    # Contract: C9, R9 — NoOpSpan.set_attribute does not raise
    # Guidance: Interface Description 2.
    # Perspective: Side-effect.
    # Source: /testbed/mlflow/entities/span.py (skinny L832)
    """
    from mlflow.entities.span import NoOpSpan

    NoOpSpan().set_attribute("key", "value")
    _pass("C9: NoOpSpan.set_attribute does not raise")


def check_C10_noop_set_attributes_is_noop() -> None:
    """
    # Contract: C10, R10 — NoOpSpan.set_attributes does not raise
    # Guidance: Interface Description 2.
    # Perspective: Side-effect.
    # Source: /testbed/mlflow/entities/span.py (skinny L829)
    """
    from mlflow.entities.span import NoOpSpan

    NoOpSpan().set_attributes({"k": "v"})
    _pass("C10: NoOpSpan.set_attributes does not raise")


def check_C11_noop_set_inputs_is_noop() -> None:
    """
    # Contract: C11, R11 — NoOpSpan.set_inputs does not raise
    # Guidance: Interface Description 2.
    # Perspective: Side-effect.
    # Source: /testbed/mlflow/entities/span.py (skinny L823)
    """
    from mlflow.entities.span import NoOpSpan

    NoOpSpan().set_inputs({"x": 1})
    _pass("C11: NoOpSpan.set_inputs does not raise")


def check_C12_noop_set_outputs_is_noop() -> None:
    """
    # Contract: C12, R12 — NoOpSpan.set_outputs does not raise
    # Guidance: Interface Description 2.
    # Perspective: Side-effect.
    # Source: /testbed/mlflow/entities/span.py (skinny L826)
    """
    from mlflow.entities.span import NoOpSpan

    NoOpSpan().set_outputs({"y": 2})
    _pass("C12: NoOpSpan.set_outputs does not raise")


def check_C13_noop_set_status_is_noop() -> None:
    """
    # Contract: C13, R13 — NoOpSpan.set_status does not raise
    # Guidance: Interface Description 2.
    # Perspective: Side-effect.
    # Source: /testbed/mlflow/entities/span.py (skinny L835)
    """
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_status import SpanStatus

    NoOpSpan().set_status(SpanStatus("OK"))
    _pass("C13: NoOpSpan.set_status does not raise")


def check_C14_noop_span_id_is_none() -> None:
    """
    # Contract: C14, R14 — NoOpSpan.span_id returns None
    # Guidance: Interface Description 2.
    # Perspective: Return value.
    # Source: /testbed/mlflow/entities/span.py (skinny L792)
    """
    from mlflow.entities.span import NoOpSpan

    assert NoOpSpan().span_id is None
    _pass("C14: NoOpSpan.span_id is None")


def check_C15_noop_start_time_ns_is_none() -> None:
    """
    # Contract: C15, R15 — NoOpSpan.start_time_ns returns None
    # Guidance: Interface Description 2.
    # Perspective: Return value.
    # Source: /testbed/mlflow/entities/span.py (skinny L800)
    """
    from mlflow.entities.span import NoOpSpan

    assert NoOpSpan().start_time_ns is None
    _pass("C15: NoOpSpan.start_time_ns is None")


def check_C16_noop_status_is_none() -> None:
    """
    # Contract: C16, R16 — NoOpSpan.status returns None
    # Guidance: Interface Description 2.
    # Perspective: Return value.
    # Source: /testbed/mlflow/entities/span.py (skinny L816)
    """
    from mlflow.entities.span import NoOpSpan

    assert NoOpSpan().status is None
    _pass("C16: NoOpSpan.status is None")


def check_C17_noop_trace_id_is_sentinel() -> None:
    """
    # Contract: C17, R17, R35 — NoOpSpan.trace_id returns
    #   "MLFLOW_NO_OP_SPAN_TRACE_ID"
    # Guidance: Interface Description 2.
    # Perspective: Return value — verify the exact sentinel value.
    # Source: /testbed/mlflow/entities/span.py (skinny L785)
    """
    from mlflow.entities.span import NoOpSpan

    tid = NoOpSpan().trace_id
    assert tid == "MLFLOW_NO_OP_SPAN_TRACE_ID", f"Expected sentinel, got {tid!r}"
    _pass("C17: NoOpSpan.trace_id == 'MLFLOW_NO_OP_SPAN_TRACE_ID'")


# ── Span checks (C18-C24) ────────────────────────────────────────────


def check_C18_span_attributes_is_dict() -> None:
    """
    # Contract: C18, R18, R32 — Span.attributes returns dict[str, Any]
    #   with deserialized values.
    # Guidance: Interface Description 2; test_trace_data.py uses
    #   span attributes via trace data dicts.
    # Perspective: Return value — verify type and content.
    # Source: /testbed/mlflow/entities/span.py (skinny L181-188)
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM"),
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test"),
        "custom_key": dump_span_attribute_value(42),
    }
    readable = _make_mock_otel_readable_span(attributes=attrs)
    s = Span(readable)
    result = s.attributes
    assert isinstance(result, dict), f"Expected dict, got {type(result)}"
    # Verify deserialization: "LLM" not '"LLM"'
    st = result.get(SpanAttributeKey.SPAN_TYPE)
    if st is not None:
        assert st == "LLM", f"Expected 'LLM' (deserialized), got {st!r}"
    cust = result.get("custom_key")
    if cust is not None:
        assert cust == 42, f"Expected 42, got {cust!r}"
    _pass("C18: Span.attributes returns deserialized dict")


def check_C19_span_events_returns_spanevent_list() -> None:
    """
    # Contract: C19, R19 — Span.events returns list[SpanEvent]
    # Guidance: Interface Description 2, test_span_event.py.
    # Perspective: Return value — verify type and structure.
    # Source: /testbed/mlflow/entities/span.py (skinny L191-207)
    """
    from mlflow.entities.span import Span
    from mlflow.entities.span_event import SpanEvent
    from opentelemetry.sdk.trace import Event as OTelEvent

    events = [
        OTelEvent(name="ev1", timestamp=100, attributes={"k": "v"}),
    ]
    readable = _make_mock_otel_readable_span(events=events)
    s = Span(readable)
    result = s.events
    assert isinstance(result, list)
    if len(result) > 0:
        ev = result[0]
        assert isinstance(ev, SpanEvent), f"Expected SpanEvent, got {type(ev)}"
        assert ev.name == "ev1"
        assert ev.timestamp == 100
        # attributes should be a plain dict (not BoundedAttributes)
        assert isinstance(ev.attributes, dict)
    _pass("C19: Span.events returns list[SpanEvent] with proper structure")


def check_C20_span_request_id_equals_trace_id() -> None:
    """
    # Contract: C20, R20 — Span.request_id is alias for trace_id
    # Guidance: Interface Description 2.
    # Perspective: Return value — verify equivalence.
    # Source: /testbed/mlflow/entities/span.py (skinny L125-126)
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-xyz"),
    }
    readable = _make_mock_otel_readable_span(attributes=attrs)
    s = Span(readable)
    assert s.request_id == s.trace_id, \
        f"request_id={s.request_id!r} != trace_id={s.trace_id!r}"
    _pass("C20: Span.request_id == trace_id")


def check_C21_span_span_type_returns_attribute() -> None:
    """
    # Contract: C21, R21 — Span.span_type returns the SPAN_TYPE attr
    # Guidance: Interface Description 2.
    # Perspective: Return value — verify retrieves the correct attribute.
    # Source: /testbed/mlflow/entities/span.py (skinny L168-173)
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("CHAIN"),
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test"),
    }
    readable = _make_mock_otel_readable_span(attributes=attrs)
    s = Span(readable)
    st = s.span_type
    if st is not None:
        assert st == "CHAIN", f"Expected 'CHAIN', got {st!r}"
    _pass("C21: Span.span_type returns SPAN_TYPE attribute")


def check_C22_span_from_otel_proto_creates_valid_span() -> None:
    """
    # Contract: C22, R22 — Span.from_otel_proto returns a Span
    #   with correct basic properties.
    #   Fix (F2): asserts start_time_ns, end_time_ns, status, and non-None IDs.
    # Guidance: Interface Description 2.
    # Perspective: Return value — verify the created span has expected
    #   name, timing, status, and IDs.
    # Source: /testbed/mlflow/entities/span.py (skinny L366-420)
    """
    from mlflow.entities.span import Span
    from mlflow.entities.span_status import SpanStatusCode
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus

    proto_span = OTelProtoSpan()
    proto_span.trace_id = b'\x00' * 15 + b'\x01'
    proto_span.span_id = b'\x00' * 7 + b'\x02'
    proto_span.parent_span_id = b'\x00' * 7 + b'\x01'
    proto_span.name = "from_proto_test"
    proto_span.start_time_unix_nano = 1000
    proto_span.end_time_unix_nano = 2000
    proto_span.status.code = OTelProtoStatus.STATUS_CODE_OK

    span = Span.from_otel_proto(proto_span)
    assert isinstance(span, Span)
    assert span.name == "from_proto_test"
    # F2: verify timing fields
    assert span.start_time_ns == 1000, f"Expected start_time_ns=1000, got {span.start_time_ns}"
    assert span.end_time_ns == 2000, f"Expected end_time_ns=2000, got {span.end_time_ns}"
    # F2: verify status
    assert span.status.status_code == SpanStatusCode.OK, \
        f"Expected OK, got {span.status.status_code}"
    # F2: verify IDs are non-None
    assert span.trace_id is not None, "trace_id should not be None"
    assert span.span_id is not None, "span_id should not be None"
    _pass("C22: Span.from_otel_proto creates valid Span with correct timing, status, and IDs")


def check_C23_span_to_dict_shape_and_base64_ids() -> None:
    """
    # Contract: C23, R23 — Span.to_dict returns dict with base64-encoded
    #   IDs and correct keys.
    # Guidance: Interface Description 2 has detailed encoding notes.
    #   tests/tracing/test_fluent.py compares to_dict output structure.
    # Perspective: Representation — verify dict keys, base64 encoding,
    #   and status code format.
    # Source: /testbed/mlflow/entities/span.py (skinny L227-255)
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test"),
    }
    readable = _make_mock_otel_readable_span(
        trace_id=1, span_id=2, name="dict_test",
        attributes=attrs, start_time=1000, end_time=2000,
    )
    s = Span(readable)
    d = s.to_dict()

    # Required keys
    for key in ["trace_id", "span_id", "parent_span_id", "name",
                 "start_time_unix_nano", "end_time_unix_nano",
                 "events", "status", "attributes"]:
        assert key in d, f"Missing key '{key}' in to_dict output"

    assert d["name"] == "dict_test"
    assert d["start_time_unix_nano"] == 1000
    assert d["end_time_unix_nano"] == 2000

    # trace_id should be base64 (can be decoded)
    assert isinstance(d["trace_id"], str)
    try:
        base64.b64decode(d["trace_id"], validate=True)
    except Exception:
        _fail(f"C23: trace_id {d['trace_id']!r} is not valid base64")

    # span_id should be base64
    assert isinstance(d["span_id"], str)
    try:
        base64.b64decode(d["span_id"], validate=True)
    except Exception:
        _fail(f"C23: span_id {d['span_id']!r} is not valid base64")

    # Status code should be OTel protobuf status code name format
    assert "code" in d["status"]
    assert d["status"]["code"].startswith("STATUS_CODE_"), \
        f"Expected STATUS_CODE_*, got {d['status']['code']!r}"

    _pass("C23: Span.to_dict has correct keys, base64 IDs, and status code format")


def check_C24_span_to_otel_proto_populates_fields() -> None:
    """
    # Contract: C24, R24 — Span.to_otel_proto returns OTelProtoSpan
    #   with populated fields.
    # Guidance: Interface Description 2.
    # Perspective: Representation — verify protobuf fields.
    # Source: /testbed/mlflow/entities/span.py (skinny L422-453)
    """
    from mlflow.entities.span import Span

    readable = _make_mock_otel_readable_span(
        trace_id=1, span_id=2, name="proto_test",
        start_time=1000, end_time=2000,
    )
    s = Span(readable)
    proto = s.to_otel_proto()

    assert proto.name == "proto_test"
    assert proto.start_time_unix_nano == 1000
    assert proto.end_time_unix_nano == 2000
    # trace_id and span_id should be bytes
    assert isinstance(proto.trace_id, bytes)
    assert isinstance(proto.span_id, bytes)
    _pass("C24: Span.to_otel_proto returns populated OTelProtoSpan with byte IDs")


# ── _CachedSpanAttributesRegistry (C25) ──────────────────────────────


def check_C25_cached_registry_set_raises() -> None:
    """
    # Contract: C25, R25 — _CachedSpanAttributesRegistry.set raises
    #   MlflowException with INVALID_PARAMETER_VALUE.
    # Guidance: Interface Description 2; skinny L905-907.
    # Perspective: Failure — verify exact exception and error code.
    # Source: /testbed/mlflow/entities/span.py (skinny L902-904)
    """
    from mlflow.entities.span import _CachedSpanAttributesRegistry
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    readable = _make_mock_otel_readable_span()
    registry = _CachedSpanAttributesRegistry(readable)

    try:
        registry.set("key", "value")
        _fail("C25: _CachedSpanAttributesRegistry.set did not raise")
    except MlflowException as e:
        # Error code should be INVALID_PARAMETER_VALUE
        if hasattr(e, 'error_code'):
            assert e.error_code == INVALID_PARAMETER_VALUE, \
                f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}"
        _pass("C25: _CachedSpanAttributesRegistry.set raises MlflowException")
    except Exception as e:
        _fail(f"C25: Expected MlflowException, got {type(e).__name__}: {e}")


# ── create_mlflow_span (C26) ─────────────────────────────────────────


def check_C26_create_mlflow_span_invalid_type_raises() -> None:
    """
    # Contract: C26, R26 — create_mlflow_span with invalid type raises
    #   MlflowException(INVALID_PARAMETER_VALUE).
    # Guidance: Skinny L86-88.
    # Perspective: Failure — verify exception on invalid input.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import create_mlflow_span
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    try:
        create_mlflow_span("invalid_string", "tr-test")
        _fail("C26: create_mlflow_span with invalid type did not raise")
    except MlflowException as e:
        if hasattr(e, 'error_code'):
            assert e.error_code == INVALID_PARAMETER_VALUE, \
                f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}"
        _pass("C26: create_mlflow_span raises MlflowException for invalid type")
    except Exception as e:
        _fail(f"C26: Expected MlflowException, got {type(e).__name__}: {e}")


# ── _Trace.to_mlflow_trace (C27) ─────────────────────────────────────


def check_C27_trace_to_mlflow_trace_spans_are_immutable() -> None:
    """
    # Contract: C27, R27 — _Trace.to_mlflow_trace returns Trace with
    #   immutable Span objects.
    # Guidance: test_trace_manager.py test_add_spans verifies pop_trace
    #   returns ManagerTrace with Span objects.
    # Perspective: State transition — verify live spans become immutable.
    # Source: /testbed/mlflow/tracing/trace_manager.py
    """
    from mlflow.entities import Trace, TraceInfo, LiveSpan
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import _Trace

    otel = _make_mock_otel_span(name="test_root")
    live = LiveSpan(otel, "tr-27", "LLM")
    info = TraceInfo(
        trace_id="tr-27",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
    )
    t = _Trace(info=info, span_dict={"s1": live})
    result = t.to_mlflow_trace()
    assert isinstance(result, Trace)
    assert len(result.data.spans) > 0
    for span in result.data.spans:
        assert not isinstance(span, LiveSpan), \
            f"Expected immutable Span, got {type(span)}"
    _pass("C27: _Trace.to_mlflow_trace produces Trace with immutable spans")


# ── _decode_otel_proto_anyvalue (C28) ────────────────────────────────


def check_C28_decode_otel_proto_anyvalue_primitives() -> None:
    """
    # Contract: C28, R28 — _decode_otel_proto_anyvalue decodes all
    #   primitive types correctly.
    # Guidance: test_span_event.py uses this for round-trip.
    # Perspective: Return value — verify each primitive type.
    # Source: /testbed/mlflow/tracing/utils/otlp.py (skinny L157-167)
    """
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue

    # String
    av = AnyValue()
    av.string_value = "hello"
    assert _decode_otel_proto_anyvalue(av) == "hello"

    # Int
    av2 = AnyValue()
    av2.int_value = 42
    assert _decode_otel_proto_anyvalue(av2) == 42

    # Bool
    av3 = AnyValue()
    av3.bool_value = True
    assert _decode_otel_proto_anyvalue(av3) is True

    # Double
    av4 = AnyValue()
    av4.double_value = 3.14
    assert _decode_otel_proto_anyvalue(av4) == 3.14

    # Bytes
    av5 = AnyValue()
    av5.bytes_value = b"data"
    assert _decode_otel_proto_anyvalue(av5) == b"data"

    # Unset → None
    av6 = AnyValue()
    assert _decode_otel_proto_anyvalue(av6) is None

    _pass("C28: _decode_otel_proto_anyvalue decodes all primitives")


# ── apply_span_processors (C29) ──────────────────────────────────────


def check_C29_apply_span_processors_noop_when_none() -> None:
    """
    # Contract: C29, R30 — apply_span_processors handles empty config
    # Guidance: Skinny processor.py L10-33 returns early when no processors.
    # Perspective: Side-effect — verify does not raise.
    # Source: /testbed/mlflow/tracing/utils/processor.py
    """
    from mlflow.entities.span import LiveSpan

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-29", "LLM")

    try:
        from mlflow.tracing.utils.processor import apply_span_processors
        # Should not raise
        apply_span_processors(live)
        _pass("C29: apply_span_processors is callable without error")
    except ImportError:
        _fail("C29: apply_span_processors not importable")
    except Exception as e:
        _fail(f"C29: apply_span_processors raised unexpected: {e}")


# ── set_request_response_preview (C30) ───────────────────────────────


def check_C30_set_request_response_preview_populates() -> None:
    """
    # Contract: C30, R31 — set_request_response_preview sets
    #   request_preview and response_preview on TraceInfo.
    # Guidance: Skinny truncation.py L12-20.
    # Perspective: Side-effect — verify fields are populated.
    # Source: /testbed/mlflow/tracing/utils/truncation.py
    """
    from mlflow.entities import TraceInfo, TraceData
    from mlflow.entities.trace_state import TraceState
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.tracing.utils.truncation import set_request_response_preview

    info = TraceInfo(
        trace_id="tr-test",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
    )
    # Create a TraceData with a span that has inputs/outputs
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.INPUTS: dump_span_attribute_value("hello input"),
        SpanAttributeKey.OUTPUTS: dump_span_attribute_value("hello output"),
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test"),
    }
    readable = _make_mock_otel_readable_span(attributes=attrs)
    span = Span(readable)
    data = TraceData(spans=[span])

    set_request_response_preview(info, data)

    # request_preview and response_preview should be set
    assert info.request_preview is not None or info.response_preview is not None, \
        "Neither request_preview nor response_preview was set"
    _pass("C30: set_request_response_preview populates trace_info previews")


# ── _otel_proto_bytes_to_id (C31) ────────────────────────────────────


def check_C31_otel_proto_bytes_to_id_conversion() -> None:
    """
    # Contract: C31, R29 — _otel_proto_bytes_to_id uses
    #   int.from_bytes(id_bytes, byteorder='big', signed=False).
    # Guidance: Skinny otlp.py L143-145.
    # Perspective: Return value — verify exact conversion.
    # Source: /testbed/mlflow/tracing/utils/otlp.py
    """
    from mlflow.tracing.utils.otlp import _otel_proto_bytes_to_id

    assert _otel_proto_bytes_to_id(b'\x00' * 7 + b'\x01') == 1
    assert _otel_proto_bytes_to_id(b'\x00' * 15 + b'\x01') == 1
    assert _otel_proto_bytes_to_id(b'\x00' * 6 + b'\x01\x00') == 256
    _pass("C31: _otel_proto_bytes_to_id converts bytes to int correctly")


# ── _SpanAttributesRegistry.get_all (C32) ────────────────────────────


def check_C32_span_attributes_registry_get_all_deserializes() -> None:
    """
    # Contract: C32, R32 — _SpanAttributesRegistry.get_all returns
    #   deserialized values for all keys.
    # Guidance: No existing direct test in repo.
    # Perspective: Return value — verify deserialization.
    # Source: /testbed/mlflow/entities/span.py (skinny L868-869)
    """
    from mlflow.entities.span import _SpanAttributesRegistry
    from mlflow.tracing.utils import dump_span_attribute_value

    otel = _make_mock_otel_span()
    otel.set_attribute("str_key", dump_span_attribute_value("string_val"))
    otel.set_attribute("int_key", dump_span_attribute_value(42))
    otel.set_attribute("list_key", dump_span_attribute_value([1, 2, 3]))

    registry = _SpanAttributesRegistry(otel)
    all_attrs = registry.get_all()

    assert isinstance(all_attrs, dict)
    assert "str_key" in all_attrs
    assert all_attrs["str_key"] == "string_val"
    assert all_attrs["int_key"] == 42
    assert all_attrs["list_key"] == [1, 2, 3]
    _pass("C32: _SpanAttributesRegistry.get_all deserializes all values correctly")


# ── _get_truncated_preview (C33) ─────────────────────────────────────


def check_C33_get_truncated_preview_truncates() -> None:
    """
    # Contract: C33, R31 — _get_truncated_preview returns truncated
    #   content with max length for OSS (1000 chars) or DBX (10000 chars).
    # Guidance: Skinny truncation.py L24-52.
    # Perspective: Return value — verify truncation behavior.
    # Source: /testbed/mlflow/tracing/utils/truncation.py
    """
    from mlflow.tracing.utils.truncation import _get_truncated_preview

    long_str = "x" * 2000
    result = _get_truncated_preview(long_str, "user")
    # Should be truncated to at most 1000 chars (OSS) + "..."
    assert isinstance(result, str)
    assert len(result) <= 1003, f"Truncated too long: {len(result)}"
    if len(long_str) > 1000:
        assert result.endswith("..."), f"Expected '...' suffix, got {result[-10:]!r}"
    _pass("C33: _get_truncated_preview truncates long strings with '...' suffix")


# ── Span.from_dict base64 & v2 schema (C34, F1) ──────────────────────


def check_C34_span_from_dict_handles_base64_ids() -> None:
    """
    # Contract: C34, R33 — Span.from_dict handles base64-encoded IDs
    #   using _is_base64_encoded and _decode_id_from_byte.
    # Guidance: test_trace.py test_trace_from_dict_load_old_trace uses
    #   Trace.from_dict which internally calls Span.from_dict.
    # Perspective: Representation — verify base64 ID deserialization.
    # Source: /testbed/mlflow/entities/span.py (skinny L258-329)
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value
    from mlflow.entities.span import _encode_trace_id_to_byte, _encode_span_id_to_byte
    from mlflow.entities.span import _encode_bytes_to_base64

    # Build a dict with base64-encoded IDs
    trace_id_b64 = _encode_bytes_to_base64(_encode_trace_id_to_byte(1))
    span_id_b64 = _encode_bytes_to_base64(_encode_span_id_to_byte(2))

    data = {
        "trace_id": trace_id_b64,
        "span_id": span_id_b64,
        "parent_span_id": "",
        "name": "from_dict_test",
        "start_time_unix_nano": 1000,
        "end_time_unix_nano": 2000,
        "status": {"code": "STATUS_CODE_OK", "message": ""},
        "attributes": {
            SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-from-dict"),
        },
        "events": [],
    }

    span = Span.from_dict(data)
    assert isinstance(span, Span)
    assert span.name == "from_dict_test"
    assert span.start_time_ns == 1000
    assert span.end_time_ns == 2000
    _pass("C34: Span.from_dict handles base64-encoded IDs correctly")


def check_C34_span_from_dict_v2_schema() -> None:
    """
    # Contract: C34, R33, E16 — Span.from_dict handles v2 schema format
    #   (legacy compatibility path with "context" key).
    #   Fix (F1): adds test for the v2 deserialization branch.
    # Guidance: Skinny span.py L336-364 implements from_dict_v2.
    #   The v2 schema has a "context" key containing hex trace_id/span_id.
    # Perspective: Compatibility — verify v2-schema dicts deserialize.
    # Source: /testbed/mlflow/entities/span.py (skinny L336-364)
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    # Build a v2-schema data dict
    data_v2 = {
        "context": {
            "trace_id": "0x00000000000000000000000000000001",
            "span_id": "0x0000000000000002",
        },
        "parent_span_id": "",
        "name": "v2_span_test",
        "start_time": 1000,
        "end_time": 2000,
        "status": {"code": "STATUS_CODE_OK", "message": ""},
        "attributes": {
            SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-v2"),
        },
        "events": [],
    }

    try:
        span = Span.from_dict(data_v2)
        assert isinstance(span, Span)
        assert span.name == "v2_span_test"
        assert span.start_time_ns == 1000
        assert span.end_time_ns == 2000
        _pass("C34-v2: Span.from_dict handles v2 schema with 'context' key")
    except Exception as e:
        _fail(f"C34-v2: Span.from_dict v2 schema failed: {type(e).__name__}: {e}")


def check_C34_span_is_v2_schema_detection() -> None:
    """
    # Contract: C34, R33 — Span._is_span_v2_schema detects v2 format.
    #   Fix (F1): tests the static helper directly.
    # Guidance: Skinny span.py L333: return "context" in data.
    # Perspective: Representation — verify the v2 detection helper.
    # Source: /testbed/mlflow/entities/span.py (skinny L333)
    """
    from mlflow.entities.span import Span

    # v2 schema data has "context" key
    assert Span._is_span_v2_schema({"context": {}, "name": "x"}) is True
    # v3 schema data does not have "context" key
    assert Span._is_span_v2_schema({"trace_id": "abc", "name": "x"}) is False
    assert Span._is_span_v2_schema({}) is False
    _pass("C34-v2-detect: Span._is_span_v2_schema correctly detects v2 format")


# ── Span.to_dict / from_dict roundtrip (C35) ─────────────────────────


def check_C35_span_to_dict_from_dict_roundtrip() -> None:
    """
    # Contract: C35, R23, R33 — Span.to_dict / Span.from_dict roundtrip
    #   preserves core data.
    #   Fix (F4): pre-serializes mock attributes using dump_span_attribute_value
    #   so that from_dict's attribute deserialization works correctly.
    # Guidance: test_trace.py test_trace_from_dict_load_old_trace verifies
    #   from_dict with real trace data.
    # Perspective: Compatibility — verify structural equivalence.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    # F4: Pre-serialize attributes so from_dict can deserialize them
    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-roundtrip"),
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM"),
        "custom_int": dump_span_attribute_value(42),
    }

    readable = _make_mock_otel_readable_span(
        trace_id=12345, span_id=67890, name="roundtrip_span",
        attributes=attrs, start_time=5000, end_time=6000,
    )
    original = Span(readable)

    d = original.to_dict()
    restored = Span.from_dict(d)

    assert restored.name == original.name
    assert restored.start_time_ns == original.start_time_ns
    assert restored.end_time_ns == original.end_time_ns
    _pass("C35: Span.to_dict/from_dict roundtrip preserves name and timing")


# ── NoOpSpan full interface (C36) ────────────────────────────────────


def check_C36_noop_span_all_interface_methods() -> None:
    """
    # Contract: C36, R4-R17, R34, R35 — Comprehensive NoOpSpan interface
    #   test: no method raises and all properties return correct types.
    # Guidance: Interface Description 2 enumerates all NoOpSpan methods.
    # Perspective: Compatibility — exhaustive interface compliance.
    # Source: /testbed/mlflow/entities/span.py (skinny L761-850)
    """
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_event import SpanEvent
    from mlflow.entities.span_status import SpanStatus

    noop = NoOpSpan()

    # Properties that return None
    assert noop._trace_id is None
    assert noop.span_id is None
    assert noop.name is None
    assert noop.start_time_ns is None
    assert noop.end_time_ns is None
    assert noop.status is None
    assert noop.parent_id is None

    # Properties with special values
    assert noop.trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"
    assert noop.context is None

    # Methods (all should be no-op)
    noop.set_inputs({"x": 1})
    noop.set_outputs({"y": 2})
    noop.set_attributes({"k": "v"})
    noop.set_attribute("key", "value")
    noop.set_status(SpanStatus("OK"))
    noop.set_status("ERROR")
    noop.add_event(SpanEvent("ev", 0, {}))
    noop.end()
    noop.end(outputs={"o": 1}, attributes={"a": "b"}, status="OK", end_time_ns=100)
    noop.record_exception("test error")
    noop.record_exception(Exception("test"))

    _pass("C36: NoOpSpan: all properties and methods work without exception")


# ── ID Encoder Behavior Checks (F5) ──────────────────────────────────


def check_F5_encode_trace_id_to_byte_exact_length() -> None:
    """
    # Fix (F5): _encode_trace_id_to_byte must produce exactly 16 bytes
    #   in big-endian unsigned order.
    # Guidance: Skinny span.py L461-463.
    # Perspective: Representation — verify exact byte length and order.
    # Source: /testbed/mlflow/entities/span.py (skinny L461-463)
    """
    from mlflow.entities.span import _encode_trace_id_to_byte

    # Simple value
    b = _encode_trace_id_to_byte(1)
    assert len(b) == 16, f"Expected 16 bytes, got {len(b)}"
    assert b == b'\x00' * 15 + b'\x01'

    # Larger value
    b2 = _encode_trace_id_to_byte(0xDEADBEEF)
    assert len(b2) == 16
    # Check that the last 4 bytes encode 0xDEADBEEF
    assert b2[-4:] == (0xDEADBEEF).to_bytes(4, 'big', signed=False)

    _pass("F5: _encode_trace_id_to_byte: exactly 16 bytes, big-endian unsigned")


def check_F5_encode_span_id_to_byte_exact_length() -> None:
    """
    # Fix (F5): _encode_span_id_to_byte must produce exactly 8 bytes
    #   in big-endian unsigned order.
    # Guidance: Skinny span.py L456-458.
    # Perspective: Representation — verify exact byte length and order.
    # Source: /testbed/mlflow/entities/span.py (skinny L456-458)
    """
    from mlflow.entities.span import _encode_span_id_to_byte

    b = _encode_span_id_to_byte(1)
    assert len(b) == 8, f"Expected 8 bytes, got {len(b)}"
    assert b == b'\x00' * 7 + b'\x01'

    b2 = _encode_span_id_to_byte(0xABCD)
    assert len(b2) == 8
    assert b2[-2:] == b'\xab\xcd'

    _pass("F5: _encode_span_id_to_byte: exactly 8 bytes, big-endian unsigned")


def check_F5_encode_bytes_to_base64_roundtrip() -> None:
    """
    # Fix (F5): _encode_bytes_to_base64 must produce decodable base64,
    #   and _decode_id_from_byte must be its inverse.
    # Guidance: Skinny span.py L466-474.
    # Perspective: Compatibility — verify encoding/decoding roundtrip.
    # Source: /testbed/mlflow/entities/span.py (skinny L466-474)
    """
    from mlflow.entities.span import (
        _encode_bytes_to_base64,
        _decode_id_from_byte,
        _encode_span_id_to_byte,
        _encode_trace_id_to_byte,
        _is_base64_encoded,
    )

    # Span ID roundtrip
    span_orig = 0xCAFEBABE
    span_b64 = _encode_bytes_to_base64(_encode_span_id_to_byte(span_orig))
    assert _is_base64_encoded(span_b64)
    span_decoded = _decode_id_from_byte(span_b64)
    assert span_decoded == span_orig, f"Span ID roundtrip: {span_orig} → {span_decoded}"

    # Trace ID roundtrip
    trace_orig = 0x1234567890ABCDEF
    trace_b64 = _encode_bytes_to_base64(_encode_trace_id_to_byte(trace_orig))
    assert _is_base64_encoded(trace_b64)
    trace_decoded = _decode_id_from_byte(trace_b64)
    assert trace_decoded == trace_orig, f"Trace ID roundtrip: {trace_orig} → {trace_decoded}"

    _pass("F5: _encode_bytes_to_base64 / _decode_id_from_byte roundtrip")


def check_F5_is_base64_encoded_edge_cases() -> None:
    """
    # Fix (F5): _is_base64_encoded must correctly discriminate base64
    #   from hex, empty, and arbitrary strings.
    # Guidance: Skinny span.py L476-481.
    # Perspective: Compatibility — verify edge cases.
    # Source: /testbed/mlflow/entities/span.py (skinny L476-481)
    """
    from mlflow.entities.span import _is_base64_encoded
    from mlflow.entities.span import _encode_bytes_to_base64
    from mlflow.entities.span import _encode_span_id_to_byte

    # Valid base64
    valid_b64 = _encode_bytes_to_base64(_encode_span_id_to_byte(42))
    assert _is_base64_encoded(valid_b64) is True

    # Empty string
    assert _is_base64_encoded("") is False

    # Hex string
    assert _is_base64_encoded("0123456789abcdef") is False

    # Random non-base64 string
    assert _is_base64_encoded("!!!not-base64!!!") is False

    # Standard base64 alphabet strings that are NOT valid base64 due to padding/length
    assert _is_base64_encoded("abc") is False  # too short for valid base64

    _pass("F5: _is_base64_encoded correctly discriminates edge cases")


# ── Additional checks ────────────────────────────────────────────────


def check_noop_parent_id_is_none() -> None:
    """
    # Contract: R34 — NoOpSpan.parent_id returns None
    # Guidance: Implicit from NoOpSpan interface.
    # Perspective: Return value.
    # Source: /testbed/mlflow/entities/span.py (skinny L812)
    """
    from mlflow.entities.span import NoOpSpan

    assert NoOpSpan().parent_id is None
    _pass("NoOpSpan.parent_id is None")


def check_livespan_set_inputs_and_outputs() -> None:
    """
    # Additional: LiveSpan.set_inputs and set_outputs behavior
    # Guidance: test_trace_data.py tests request/response via set_inputs/set_outputs.
    # Perspective: Side-effect — verify stored values are retrievable.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-test", "UNKNOWN")

    live.set_inputs({"x": 1, "y": 2})
    live.set_outputs("result_value")

    inp = live.get_attribute(SpanAttributeKey.INPUTS)
    out = live.get_attribute(SpanAttributeKey.OUTPUTS)
    assert inp == {"x": 1, "y": 2}, f"Expected input dict, got {inp!r}"
    assert out == "result_value", f"Expected 'result_value', got {out!r}"
    _pass("LiveSpan.set_inputs/set_outputs: stored and retrievable")


def check_span_inputs_outputs_properties() -> None:
    """
    # Additional: Span.inputs and Span.outputs property access
    # Guidance: test_trace_data.py reads request/response which maps to
    #   root span inputs/outputs.
    # Perspective: Return value — verify properties delegate to attributes.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.INPUTS: dump_span_attribute_value("input_data"),
        SpanAttributeKey.OUTPUTS: dump_span_attribute_value("output_data"),
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test"),
    }
    readable = _make_mock_otel_readable_span(attributes=attrs)
    s = Span(readable)

    inp = s.inputs
    out = s.outputs
    if inp is not None:
        assert inp == "input_data"
    if out is not None:
        assert out == "output_data"
    _pass("Span.inputs and Span.outputs delegate to attributes")


def check_span_attributes_is_cached_immutable() -> None:
    """
    # Additional: Verify Span.attributes uses caching — repeated
    #   access returns the same logical values.
    # Guidance: Interface Description 2 — _CachedSpanAttributesRegistry.
    # Perspective: Lifecycle — verify caching behavior.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM"),
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test"),
    }
    readable = _make_mock_otel_readable_span(attributes=attrs)
    s = Span(readable)

    a1 = s.attributes
    a2 = s.attributes
    # Cached registry means same values on repeated access
    st1 = a1.get(SpanAttributeKey.SPAN_TYPE)
    st2 = a2.get(SpanAttributeKey.SPAN_TYPE)
    if st1 is not None and st2 is not None:
        assert st1 == st2
    _pass("Span.attributes: cached access returns consistent values")


def check_noop_span_does_not_crash_on_record_exception() -> None:
    """
    # Additional: NoOpSpan.record_exception with various types
    # Guidance: Interface Description 2.
    # Perspective: Compatibility.
    # Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import NoOpSpan

    noop = NoOpSpan()
    noop.record_exception("string error")
    noop.record_exception(ValueError("value error"))
    noop.record_exception(Exception("generic"))
    _pass("NoOpSpan.record_exception: handles str and Exception")


def check_livespan_end_sets_default_status() -> None:
    """
    # Additional: LiveSpan.end() sets status to OK if not ERROR
    # Guidance: Skinny L650-654 — automatically sets OK status.
    # Perspective: Lifecycle — verify default status on end.
    # Source: /testbed/mlflow/entities/span.py (skinny L650-654)
    """
    from mlflow.entities.span import LiveSpan
    from mlflow.entities.span_status import SpanStatusCode

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-test", "UNKNOWN")
    # end() without explicit status
    live.end()

    # After end(), status should be OK
    s = live.status
    assert s is not None
    # Status should be OK (not UNSET)
    assert s.status_code == SpanStatusCode.OK, \
        f"Expected OK status after end(), got {s.status_code}"
    _pass("LiveSpan.end(): sets default status to OK")


# ── Main ─────────────────────────────────────────────────────────────


def main() -> None:
    checks = [
        # C1-C3: LiveSpan
        check_C1_livespan_from_dict_raises_not_implemented,
        check_C2_livespan_set_span_type_observable,
        check_C2_livespan_set_span_type_custom,
        check_C2_livespan_set_span_type_overwrite,
        check_C3_livespan_to_immutable_span_preserves_data,
        # C4-C17: NoOpSpan
        check_C4_noop_trace_id_internal_is_none,
        check_C5_noop_add_event_is_noop,
        check_C6_noop_end_is_noop,
        check_C7_noop_end_time_ns_is_none,
        check_C8_noop_name_is_none,
        check_C9_noop_set_attribute_is_noop,
        check_C10_noop_set_attributes_is_noop,
        check_C11_noop_set_inputs_is_noop,
        check_C12_noop_set_outputs_is_noop,
        check_C13_noop_set_status_is_noop,
        check_C14_noop_span_id_is_none,
        check_C15_noop_start_time_ns_is_none,
        check_C16_noop_status_is_none,
        check_C17_noop_trace_id_is_sentinel,
        # C18-C24: Span
        check_C18_span_attributes_is_dict,
        check_C19_span_events_returns_spanevent_list,
        check_C20_span_request_id_equals_trace_id,
        check_C21_span_span_type_returns_attribute,
        check_C22_span_from_otel_proto_creates_valid_span,
        check_C23_span_to_dict_shape_and_base64_ids,
        check_C24_span_to_otel_proto_populates_fields,
        # C25: _CachedSpanAttributesRegistry
        check_C25_cached_registry_set_raises,
        # C26: create_mlflow_span
        check_C26_create_mlflow_span_invalid_type_raises,
        # C27: _Trace.to_mlflow_trace
        check_C27_trace_to_mlflow_trace_spans_are_immutable,
        # C28: _decode_otel_proto_anyvalue
        check_C28_decode_otel_proto_anyvalue_primitives,
        # C29: apply_span_processors
        check_C29_apply_span_processors_noop_when_none,
        # C30: set_request_response_preview
        check_C30_set_request_response_preview_populates,
        # C31: _otel_proto_bytes_to_id
        check_C31_otel_proto_bytes_to_id_conversion,
        # C32: _SpanAttributesRegistry.get_all
        check_C32_span_attributes_registry_get_all_deserializes,
        # C33: _get_truncated_preview
        check_C33_get_truncated_preview_truncates,
        # C34: Span.from_dict base64 + v2 schema (F1)
        check_C34_span_from_dict_handles_base64_ids,
        check_C34_span_from_dict_v2_schema,
        check_C34_span_is_v2_schema_detection,
        # C35: roundtrip (F4)
        check_C35_span_to_dict_from_dict_roundtrip,
        # C36: NoOpSpan full interface
        check_C36_noop_span_all_interface_methods,
        # F5: ID encoding helpers
        check_F5_encode_trace_id_to_byte_exact_length,
        check_F5_encode_span_id_to_byte_exact_length,
        check_F5_encode_bytes_to_base64_roundtrip,
        check_F5_is_base64_encoded_edge_cases,
        # Additional
        check_noop_parent_id_is_none,
        check_livespan_set_inputs_and_outputs,
        check_span_inputs_outputs_properties,
        check_span_attributes_is_cached_immutable,
        check_noop_span_does_not_crash_on_record_exception,
        check_livespan_end_sets_default_status,
    ]

    for check in checks:
        try:
            check()
        except Exception:
            _fail(f"{check.__name__} raised unexpected:\n{traceback.format_exc()}")

    print(f"\n{'-'*60}")
    print(f"Results: {PASSED} passed, {FAILED} failed")
    if FAILED > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
