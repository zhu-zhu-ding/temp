"""
Executable architecture spec for MLflow Distributed Tracing System.

Covers: public scope, import/dependency binding, real caller-to-helper
call chains, dispatch, argument/result dataflow, exports, and lifecycle
connectivity.

Each check_* function exercises a real L2 CALL/CONTROL path from the IR
and observes the caller-resolved binding at runtime.
"""

import base64
import sys
import traceback


PASSED = 0
FAILED = 0


def _pass(msg: str) -> None:
    global PASSED
    PASSED += 1
    print(f"PASS: {msg}")


def _fail(msg: str) -> None:
    global FAILED
    FAILED += 1
    print(f"FAIL: {msg}")


# ── Helpers ──────────────────────────────────────────────────────────


def _make_mock_otel_readable_span(
    trace_id: int = 1,
    span_id: int = 1,
    name: str = "test_span",
    parent_id: int | None = None,
    attributes: dict | None = None,
    events: list | None = None,
    start_time: int = 100,
    end_time: int | None = 200,
):
    """Create a minimal mock OTel ReadableSpan for architecture checks."""
    from unittest import mock

    s = mock.MagicMock()
    s.name = name
    s._start_time = start_time
    s._end_time = end_time

    ctx = mock.MagicMock()
    ctx.trace_id = trace_id
    ctx.span_id = span_id
    s.context = ctx

    if parent_id is not None:
        parent_ctx = mock.MagicMock()
        parent_ctx.span_id = parent_id
        s.parent = parent_ctx
    else:
        s.parent = None

    s.attributes = attributes or {}
    s.events = events or []
    s.status = mock.MagicMock()
    s.status.status_code = mock.MagicMock()
    s.status.status_code.name = "OK"
    s.status.description = ""

    # Provide get_span_context for LiveSpan cloning path
    s.get_span_context = lambda: ctx

    return s


def _make_mock_otel_span(trace_id=1, span_id=1, name="test"):
    """Create a minimal mock OTel Span (live, mutable) for LiveSpan construction.

    Fix (F3): set_attribute / set_attributes write to the same s.attributes
    dict that _SpanAttributesRegistry.get reads from, matching the repository
    test pattern in tests/tracing/helper.py L65-85.
    """
    from unittest import mock
    import opentelemetry.sdk.trace as otel_sdk

    s = mock.MagicMock(spec=otel_sdk.ReadableSpan)
    s.name = name
    s._start_time = 100
    s._end_time = None

    ctx = mock.MagicMock()
    ctx.trace_id = trace_id
    ctx.span_id = span_id
    s.context = ctx
    s.parent = None
    s.attributes = {}            # real dict — read/write share this store
    s.events = []
    s.status = mock.MagicMock()
    s.status.status_code = mock.MagicMock()
    s.status.status_code.name = "UNSET"
    s.status.description = ""
    s.get_span_context = lambda: ctx

    # Write to s.attributes (same dict read by _SpanAttributesRegistry.get)
    def _set_attr(k, v):
        s.attributes[k] = v
    s.set_attribute = _set_attr
    s.set_attributes = lambda d: s.attributes.update(d)

    return s


# ── Architecture Checks ──────────────────────────────────────────────


def check_public_imports() -> None:
    """
    # Contracts: C1, C2, C3, C17, C26, C36 — public surface accessible
    # Guidance: No single repository test; tests/tracing/test_fluent.py uses
    #   from mlflow.entities import LiveSpan, Span, etc.
    # Perspective: Public-surface contract — verify all expected symbols
    #   are importable from their public packages.
    # Source: /testbed/mlflow/entities/__init__.py, span.py
    """
    try:
        from mlflow.entities import Span, LiveSpan, NoOpSpan, SpanType  # noqa: F401
        _pass("Public imports: Span, LiveSpan, NoOpSpan, SpanType")
    except ImportError as e:
        _fail(f"Public import failed: {e}")


def check_span_subclass_hierarchy() -> None:
    """
    # Contracts: C3, C17, C36 — Span is base, LiveSpan and NoOpSpan extend it
    # Guidance: tests/tracing/test_trace_manager.py creates LiveSpan and
    #   verifies isinstance checks.
    # Perspective: Caller-binding — verify the runtime MRO.
    # Source: /testbed/mlflow/entities/span.py L484, L761
    """
    from mlflow.entities.span import Span, LiveSpan, NoOpSpan

    assert issubclass(LiveSpan, Span), "LiveSpan must extend Span"
    assert issubclass(NoOpSpan, Span), "NoOpSpan must extend Span"
    _pass("Span subclass hierarchy: LiveSpan and NoOpSpan extend Span")


def check_create_mlflow_span_import_and_call_path() -> None:
    """
    # Contracts: C26, E14 — create_mlflow_span factory dispatches correctly
    # Guidance: Static issue: create_mlflow_span undefined in base_mlflow.py
    #   Must be importable from mlflow.entities.span.
    # Perspective: Caller-binding — verify the factory exists and dispatches
    #   on input span type.
    # Source: /testbed/mlflow/entities/span.py (skinny L66-88)
    """
    from mlflow.entities.span import create_mlflow_span

    # None → NoOpSpan
    from mlflow.entities.span import NoOpSpan
    result_none = create_mlflow_span(None, "tr-1")
    assert isinstance(result_none, NoOpSpan), f"None → NoOpSpan, got {type(result_none)}"
    _pass("create_mlflow_span: None → NoOpSpan")

    # NonRecordingSpan → NoOpSpan
    from opentelemetry.trace import NonRecordingSpan
    nrs = NonRecordingSpan(context=None)
    result_nrs = create_mlflow_span(nrs, "tr-2")
    assert isinstance(result_nrs, NoOpSpan), f"NonRecordingSpan → NoOpSpan, got {type(result_nrs)}"
    _pass("create_mlflow_span: NonRecordingSpan → NoOpSpan")

    # OTelSpan → LiveSpan
    from mlflow.entities.span import LiveSpan
    otel_span = _make_mock_otel_span()
    result_live = create_mlflow_span(otel_span, "tr-3", "LLM")
    assert isinstance(result_live, LiveSpan), f"OTelSpan → LiveSpan, got {type(result_live)}"
    _pass("create_mlflow_span: OTelSpan → LiveSpan")

    # OTelReadableSpan → Span
    from mlflow.entities.span import Span
    readable = _make_mock_otel_readable_span()
    result_span = create_mlflow_span(readable, "tr-4")
    assert isinstance(result_span, Span), f"OTelReadableSpan → Span, got {type(result_span)}"
    assert not isinstance(result_span, LiveSpan)
    _pass("create_mlflow_span: OTelReadableSpan → Span")


def check_livespan_to_immutable_span_path() -> None:
    """
    # Contracts: C3, E9 — LiveSpan.to_immutable_span returns Span
    # Guidance: Interface Description 2; skinny L668-675.
    # Perspective: Caller-binding — verify the downcast returns an immutable
    #   Span (not LiveSpan) and the call chain resolves.
    # Source: /testbed/mlflow/entities/span.py (skinny L668-675)
    """
    from mlflow.entities.span import LiveSpan, Span

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-test", "LLM")
    result = live.to_immutable_span()
    assert isinstance(result, Span), f"Expected Span, got {type(result)}"
    assert not isinstance(result, LiveSpan), "Must not be LiveSpan"
    _pass("LiveSpan.to_immutable_span: returns Span (not LiveSpan)")


def check_livespan_set_span_type_to_attribute_registry() -> None:
    """
    # Contracts: C2, E7 — LiveSpan.set_span_type delegates to
    #   _SpanAttributesRegistry.set.
    # Guidance: Interface Description 2.
    # Perspective: Caller-binding — verify set_span_type flows through
    #   the attribute registry to the OTel span.
    # Source: /testbed/mlflow/entities/span.py (skinny L525-527)
    """
    from mlflow.entities.span import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    otel = _make_mock_otel_span()
    live = LiveSpan(otel, "tr-test", "UNKNOWN")
    live.set_span_type("LLM")
    # Verify the attribute was set on the underlying OTel span
    st = live.span_type
    assert st == "LLM", f"Expected 'LLM', got {st!r}"
    _pass("LiveSpan.set_span_type: flows through _SpanAttributesRegistry to OTel span")


def check_span_attributes_via_cached_registry() -> None:
    """
    # Contracts: C18, C32, E2 — Span.attributes uses
    #   _CachedSpanAttributesRegistry.get_all.
    # Guidance: Interface Description 2; test_trace_data.py accesses
    #   span attributes via trace data dicts.
    # Perspective: Caller-binding — verify Span.attributes delegates to
    #   the cached registry and returns deserialized values.
    # Source: /testbed/mlflow/entities/span.py (skinny L181-188)
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM"),
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-test"),
    }
    readable = _make_mock_otel_readable_span(attributes=attrs)
    s = Span(readable)
    result = s.attributes
    assert isinstance(result, dict), f"Expected dict, got {type(result)}"
    _pass("Span.attributes: uses _CachedSpanAttributesRegistry, returns dict")


def check_span_events_dataflow() -> None:
    """
    # Contracts: C19, E3 — Span.events iterates OTel events
    # Guidance: Interface Description 2, test_span_event.py exercises
    #   SpanEvent creation and conversion.
    # Perspective: Caller-binding — Span.events converts OTel event list
    #   to list[SpanEvent].
    # Source: /testbed/mlflow/entities/span.py (skinny L191-207)
    """
    from mlflow.entities.span import Span
    from mlflow.entities.span_event import SpanEvent
    from opentelemetry.sdk.trace import Event as OTelEvent

    events = [
        OTelEvent(name="ev1", timestamp=100, attributes={"k": "v"}),
        OTelEvent(name="ev2", timestamp=200, attributes={}),
    ]
    readable = _make_mock_otel_readable_span(events=events)
    s = Span(readable)
    result = s.events
    assert isinstance(result, list), f"Expected list, got {type(result)}"
    if len(result) == 2:
        assert isinstance(result[0], SpanEvent), f"Expected SpanEvent, got {type(result[0])}"
        assert result[0].name == "ev1"
        assert result[1].name == "ev2"
    _pass("Span.events: returns list[SpanEvent] from OTel events")


def check_span_to_dict_id_encoding_helpers() -> None:
    """
    # Contracts: C23, C34, E4, E16 — Span.to_dict uses encoding helpers
    #   _encode_trace_id_to_byte, _encode_span_id_to_byte, _encode_bytes_to_base64.
    #   Fix (F5): tests byte length (16 for trace_id, 8 for span_id), big-endian
    #   correctness, and base64 roundtrip.
    # Guidance: Static issues: _decode_id_from_byte, _is_base64_encoded are
    #   used but not defined. The helpers must be importable.
    # Perspective: Caller-binding — verify the encoding helpers are callable
    #   and produce correct byte and base64 outputs.
    # Source: /testbed/mlflow/entities/span.py (skinny L456-469)
    """
    from mlflow.entities.span import _encode_trace_id_to_byte
    from mlflow.entities.span import _encode_span_id_to_byte
    from mlflow.entities.span import _encode_bytes_to_base64

    # Trace ID: 16 bytes big-endian
    trace_bytes = _encode_trace_id_to_byte(1)
    assert isinstance(trace_bytes, bytes), f"Expected bytes, got {type(trace_bytes)}"
    assert len(trace_bytes) == 16, f"Expected 16 bytes, got {len(trace_bytes)}"
    assert trace_bytes == b'\x00' * 15 + b'\x01'

    # Larger trace ID value
    trace_bytes2 = _encode_trace_id_to_byte(256)
    assert len(trace_bytes2) == 16
    assert trace_bytes2 == b'\x00' * 14 + b'\x01\x00'

    # Span ID: 8 bytes big-endian
    span_bytes = _encode_span_id_to_byte(1)
    assert isinstance(span_bytes, bytes)
    assert len(span_bytes) == 8
    assert span_bytes == b'\x00' * 7 + b'\x01'

    # Larger span ID value
    span_bytes2 = _encode_span_id_to_byte(65536)
    assert len(span_bytes2) == 8
    assert span_bytes2 == b'\x00' * 5 + b'\x01\x00\x00'

    # Base64 encoding roundtrip
    b64 = _encode_bytes_to_base64(span_bytes)
    assert isinstance(b64, str)
    decoded = base64.b64decode(b64)
    assert decoded == span_bytes

    _pass("Encoding helpers: _encode_trace_id_to_byte(16 bytes), _encode_span_id_to_byte(8 bytes), _encode_bytes_to_base64")


def check_span_from_dict_uses_decode_helpers() -> None:
    """
    # Contracts: C34, E16 — Span.from_dict uses _is_base64_encoded and
    #   _decode_id_from_byte to deserialize IDs.
    #   Fix (F5): verifies _decode_id_from_byte roundtrips correctly and
    #   _is_base64_encoded discriminates base64 from non-base64 strings.
    # Guidance: Static issues: these helpers are used but undefined.
    # Perspective: Caller-binding — verify the decode helpers are importable
    #   and produce correct integer IDs from base64.
    # Source: /testbed/mlflow/entities/span.py (skinny L470-481)
    """
    from mlflow.entities.span import _decode_id_from_byte
    from mlflow.entities.span import _is_base64_encoded
    from mlflow.entities.span import _encode_span_id_to_byte
    from mlflow.entities.span import _encode_bytes_to_base64
    from mlflow.entities.span import _encode_trace_id_to_byte

    # Round-trip span ID: int → bytes → base64 → int
    original = 12345
    b64 = _encode_bytes_to_base64(_encode_span_id_to_byte(original))
    assert _is_base64_encoded(b64), f"{b64!r} should be detected as base64"
    decoded = _decode_id_from_byte(b64)
    assert decoded == original, f"Roundtrip failed: {original} → {decoded}"

    # Round-trip trace ID
    trace_original = 999
    trace_b64 = _encode_bytes_to_base64(_encode_trace_id_to_byte(trace_original))
    assert _is_base64_encoded(trace_b64)
    trace_decoded = _decode_id_from_byte(trace_b64)
    assert trace_decoded == trace_original

    # Non-base64 string should return False
    assert not _is_base64_encoded("not-base64!!"), "Non-base64 should not pass"
    assert not _is_base64_encoded(""), "Empty string should not pass"
    # Hex string should not be detected as base64
    assert not _is_base64_encoded("0123456789abcdef"), "Hex should not pass as base64"

    _pass("Decode helpers: _is_base64_encoded and _decode_id_from_byte correct")


def check_span_to_otel_proto_path() -> None:
    """
    # Contracts: C24, E6 — Span.to_otel_proto returns OTelProtoSpan
    # Guidance: Interface Description 2.
    # Perspective: Caller-binding — verify the method returns the protobuf
    #   message type with expected fields.
    # Source: /testbed/mlflow/entities/span.py (skinny L422-453)
    """
    from mlflow.entities.span import Span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    readable = _make_mock_otel_readable_span()
    s = Span(readable)
    proto = s.to_otel_proto()
    assert isinstance(proto, OTelProtoSpan), f"Expected OTelProtoSpan, got {type(proto)}"
    assert proto.name == "test_span"
    _pass("Span.to_otel_proto: returns OTelProtoSpan with name")


def check_span_from_otel_proto_path() -> None:
    """
    # Contracts: C22, C28, C31, E5 — Span.from_otel_proto creates Span
    #   from protobuf using _otel_proto_bytes_to_id and
    #   _decode_otel_proto_anyvalue.
    #   Fix (F2): adds assertions for start_time_ns, end_time_ns, status,
    #   trace_id and span_id are non-None, not just span.name.
    # Guidance: Interface Description 2.
    # Perspective: Caller-binding — verify the classmethod returns a Span
    #   with correct timing, status, and ID fields populated.
    # Source: /testbed/mlflow/entities/span.py (skinny L366-420)
    """
    from mlflow.entities.span import Span
    from mlflow.entities.span_status import SpanStatusCode
    from mlflow.tracing.utils.otlp import _otel_proto_bytes_to_id
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
    from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus

    # Verify _otel_proto_bytes_to_id
    result = _otel_proto_bytes_to_id(b'\x00' * 7 + b'\x01')
    assert result == 1, f"Expected 1, got {result}"

    # Verify _decode_otel_proto_anyvalue on primitives
    av = AnyValue()
    av.string_value = "hello"
    assert _decode_otel_proto_anyvalue(av) == "hello"

    av2 = AnyValue()
    av2.int_value = 42
    assert _decode_otel_proto_anyvalue(av2) == 42

    av3 = AnyValue()
    av3.bool_value = True
    assert _decode_otel_proto_anyvalue(av3) is True

    # Create a minimal proto span and convert
    proto_span = OTelProtoSpan()
    proto_span.trace_id = b'\x00' * 15 + b'\x01'
    proto_span.span_id = b'\x00' * 7 + b'\x01'
    proto_span.parent_span_id = b''
    proto_span.name = "proto_span"
    proto_span.start_time_unix_nano = 100
    proto_span.end_time_unix_nano = 200
    proto_span.status.code = OTelProtoStatus.STATUS_CODE_OK

    span = Span.from_otel_proto(proto_span)
    assert isinstance(span, Span), f"Expected Span, got {type(span)}"
    assert span.name == "proto_span"

    # F2: verify timing fields are transferred
    assert span.start_time_ns == 100, f"Expected start_time_ns=100, got {span.start_time_ns}"
    assert span.end_time_ns == 200, f"Expected end_time_ns=200, got {span.end_time_ns}"

    # F2: verify status is correctly mapped
    assert span.status.status_code == SpanStatusCode.OK, \
        f"Expected OK status, got {span.status.status_code}"

    # F2: verify trace_id and span_id are non-None
    assert span.trace_id is not None, "trace_id should not be None"
    assert span.span_id is not None, "span_id should not be None"

    _pass("Span.from_otel_proto: creates Span with correct name, timing, status, and IDs")


def check_trace_to_mlflow_trace_path() -> None:
    """
    # Contracts: C27, E13, E17 — _Trace.to_mlflow_trace calls
    #   LiveSpan.to_immutable_span and set_request_response_preview.
    # Guidance: tests/tracing/test_trace_manager.py verifies ManagerTrace
    #   contains Trace with Span objects after pop_trace.
    # Perspective: Caller-binding — verify that _Trace.to_mlflow_trace
    #   produces a Trace with immutable Span objects.
    # Source: /testbed/mlflow/tracing/trace_manager.py (skinny L22-27)
    """
    from mlflow.entities import Trace
    from mlflow.entities import TraceInfo, LiveSpan
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.trace_manager import _Trace

    otel = _make_mock_otel_span(name="root_span")
    live = LiveSpan(otel, "tr-arch-test", "LLM")
    info = TraceInfo(
        trace_id="tr-arch-test",
        trace_location=TraceLocation.from_experiment_id("0"),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
    )
    t = _Trace(info=info, span_dict={"s1": live})
    result = t.to_mlflow_trace()
    assert isinstance(result, Trace), f"Expected Trace, got {type(result)}"
    _pass("_Trace.to_mlflow_trace: produces Trace with immutable spans")


def check_noop_span_public_interface_exists() -> None:
    """
    # Contracts: C4-C17, C36 — NoOpSpan public methods exist
    # Guidance: Interface Description 2 lists all NoOpSpan methods.
    # Perspective: Interface existence — verify all expected methods
    #   are present on the class.
    # Source: /testbed/mlflow/entities/span.py (skinny L761-850)
    """
    from mlflow.entities.span import NoOpSpan

    expected_attrs = [
        "trace_id", "span_id", "name", "start_time_ns", "end_time_ns",
        "status", "_trace_id", "parent_id",
        "set_inputs", "set_outputs", "set_attributes", "set_attribute",
        "set_status", "add_event", "end", "record_exception",
    ]
    for attr in expected_attrs:
        assert hasattr(NoOpSpan, attr), f"NoOpSpan missing {attr}"

    _pass("NoOpSpan: all expected public interface methods/properties exist")


def check_apply_span_processors_importable() -> None:
    """
    # Contracts: Static issue #3 — apply_span_processors is used but
    #   undefined in span.py. Must be importable from
    #   mlflow.tracing.utils.processor.
    # Guidance: Static issues list apply_span_processors as undefined.
    # Perspective: Caller-binding — verify the function is importable
    #   and callable.
    # Source: /testbed/mlflow/tracing/utils/processor.py (skinny L10-33)
    """
    try:
        from mlflow.tracing.utils.processor import apply_span_processors
        # Should be callable with a span
        callable(apply_span_processors)
        _pass("apply_span_processors: importable from mlflow.tracing.utils.processor")
    except ImportError as e:
        _fail(f"apply_span_processors not importable: {e}")


def check_truncation_helpers_importable() -> None:
    """
    # Contracts: C30, C33, E13 — set_request_response_preview and
    #   _get_truncated_preview are used by _Trace.to_mlflow_trace.
    # Guidance: Static issue: _get_truncated_preview undefined in
    #   sqlalchemy_store.py. Must be importable.
    # Perspective: Caller-binding — verify truncation helpers are
    #   importable.
    # Source: /testbed/mlflow/tracing/utils/truncation.py (skinny L15-52)
    """
    try:
        from mlflow.tracing.utils.truncation import set_request_response_preview
        assert callable(set_request_response_preview)
        _pass("set_request_response_preview: importable")
    except ImportError as e:
        _fail(f"set_request_response_preview not importable: {e}")

    try:
        from mlflow.tracing.utils.truncation import _get_truncated_preview
        assert callable(_get_truncated_preview)
        _pass("_get_truncated_preview: importable")
    except ImportError as e:
        _fail(f"_get_truncated_preview not importable: {e}")


def check_decode_otel_proto_anyvalue_recursive() -> None:
    """
    # Contracts: C28, E15 — _decode_otel_proto_anyvalue handles
    #   array_value and kvlist_value recursively.
    # Guidance: test_span_event.py uses _decode_otel_proto_anyvalue for
    #   round-trip verification of event attributes.
    # Perspective: Caller-binding — verify nested structures decode
    #   correctly.
    # Source: /testbed/mlflow/tracing/utils/otlp.py (skinny L157-167)
    """
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue

    # Array
    av_array = AnyValue()
    inner = av_array.array_value.values.add()
    inner.string_value = "a"
    inner2 = av_array.array_value.values.add()
    inner2.int_value = 1
    result = _decode_otel_proto_anyvalue(av_array)
    assert result == ["a", 1], f"Expected ['a', 1], got {result}"

    # Key-value list
    av_kv = AnyValue()
    kv = av_kv.kvlist_value.values.add()
    kv.key = "x"
    kv.value.string_value = "hello"
    result2 = _decode_otel_proto_anyvalue(av_kv)
    assert result2 == {"x": "hello"}, f"Expected {{'x': 'hello'}}, got {result2}"

    _pass("_decode_otel_proto_anyvalue: recursive array and kvlist decoding")


def check_span_attributes_registry_get_all() -> None:
    """
    # Contracts: C32, E2 — _SpanAttributesRegistry.get_all returns all
    #   attributes as deserialized dict.
    # Guidance: Interface Description 2; not directly tested in existing
    #   repository tests.
    # Perspective: Caller-binding — verify get_all() returns a dict with
    #   all keys.
    # Source: /testbed/mlflow/entities/span.py (skinny L868-869)
    """
    from mlflow.entities.span import _SpanAttributesRegistry
    from mlflow.tracing.utils import dump_span_attribute_value

    otel_span = _make_mock_otel_span()
    otel_span.set_attribute("key1", dump_span_attribute_value("val1"))
    otel_span.set_attribute("key2", dump_span_attribute_value(42))

    registry = _SpanAttributesRegistry(otel_span)
    all_attrs = registry.get_all()
    assert isinstance(all_attrs, dict)
    assert all_attrs.get("key1") == "val1"
    assert all_attrs.get("key2") == 42
    _pass("_SpanAttributesRegistry.get_all: returns all deserialized attributes")


def check__set_otel_proto_anyvalue_importable() -> None:
    """
    # Contracts: E6 — _set_otel_proto_anyvalue is used by
    #   Span.to_otel_proto.
    # Guidance: test_span_event.py uses _decode_otel_proto_anyvalue
    #   but not _set_otel_proto_anyvalue directly.
    # Perspective: Caller-binding — verify the function exists and can
    #   set values on AnyValue messages.
    # Source: /testbed/mlflow/tracing/utils/otlp.py
    """
    from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue

    av = AnyValue()
    _set_otel_proto_anyvalue(av, "hello")
    assert av.string_value == "hello"

    av2 = AnyValue()
    _set_otel_proto_anyvalue(av2, 42)
    assert av2.int_value == 42

    av3 = AnyValue()
    _set_otel_proto_anyvalue(av3, True)
    assert av3.bool_value is True

    _pass("_set_otel_proto_anyvalue: sets primitives on AnyValue")


# ── Main ─────────────────────────────────────────────────────────────


def main() -> None:
    checks = [
        check_public_imports,
        check_span_subclass_hierarchy,
        check_create_mlflow_span_import_and_call_path,
        check_livespan_to_immutable_span_path,
        check_livespan_set_span_type_to_attribute_registry,
        check_span_attributes_via_cached_registry,
        check_span_events_dataflow,
        check_span_to_dict_id_encoding_helpers,
        check_span_from_dict_uses_decode_helpers,
        check_span_to_otel_proto_path,
        check_span_from_otel_proto_path,
        check_trace_to_mlflow_trace_path,
        check_noop_span_public_interface_exists,
        check_apply_span_processors_importable,
        check_truncation_helpers_importable,
        check_decode_otel_proto_anyvalue_recursive,
        check_span_attributes_registry_get_all,
        check__set_otel_proto_anyvalue_importable,
    ]

    for check in checks:
        try:
            check()
        except Exception:
            _fail(f"{check.__name__} raised unexpected:\n{traceback.format_exc()}")

    print(f"\n{'-'*60}")
    print(f"Results: {PASSED} passed, {FAILED} failed")
    if FAILED > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
