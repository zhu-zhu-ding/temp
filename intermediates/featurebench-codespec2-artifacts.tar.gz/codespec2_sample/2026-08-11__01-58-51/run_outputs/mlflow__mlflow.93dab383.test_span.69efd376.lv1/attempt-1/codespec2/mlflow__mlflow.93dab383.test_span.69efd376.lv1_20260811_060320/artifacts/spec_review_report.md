# Spec Review Report

## Evidence Reviewed

| Source | Path | Relevance |
|--------|------|-----------|
| Task Document | (primary oracle) | Interface Descriptions 1–3 |
| Semantic IR | `/agent-logs/.../semantic_ir.md` | R1–R36, E1–E17, C1–C36 |
| Architecture Spec | `/agent-logs/.../arch_spec.py` | 18 `check_*` functions |
| Behavior Spec | `/agent-logs/.../behavior_spec.py` | 40+ `check_*` functions |
| Static Issues | `/agent-logs/.../static_issues.md` | 5 issues across 3 files |
| Static Analysis | `/agent-logs/.../static_analysis.md` | 33 declared interfaces |
| Review Skill | `/installed-agent/codespec2/review_skill.md` | Seed rubrics |
| Repository: span.py | `/testbed/mlflow/entities/span.py` (904 lines) | Current stub implementation |
| Repository: skinny span.py | `/testbed/libs/skinny/mlflow/entities/span.py` (908 lines) | Reference implementation |
| Repository: trace_manager.py | `/testbed/mlflow/tracing/trace_manager.py` (213 lines) | Current stub |
| Repository: skinny trace_manager.py | `/testbed/libs/skinny/mlflow/tracing/trace_manager.py` | Reference |
| Repository: otlp.py | `/testbed/mlflow/tracing/utils/otlp.py` (158 lines) | Current stub |
| Repository: skinny otlp.py | `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py` | Reference |
| Repository: truncation.py | `/testbed/mlflow/tracing/utils/truncation.py` | Partial stub |
| Repository: skinny truncation.py | `/testbed/libs/skinny/mlflow/tracing/utils/truncation.py` | Reference |
| Repository: processor.py | `/testbed/mlflow/tracing/utils/processor.py` | Partial stub |
| Repository tests | `/testbed/tests/tracing/test_trace_manager.py` | Test design patterns |
| Repository tests | `/testbed/tests/tracing/test_fluent.py` | Test design patterns |
| Repository tests | `/testbed/tests/entities/test_span_event.py` | Uses `_decode_otel_proto_anyvalue` |
| Repository tests | `/testbed/tests/tracing/helper.py` | Mock OTel span patterns |
| Repository: `__init__.py` | `/testbed/mlflow/entities/__init__.py` | Public exports |

## Rubric Scores

### Seed rubric: Requirement coverage
**Score**: PARTIAL — 1 finding

Every task interface method maps to an R/C/E chain. The IR captures all 33 declared interfaces and derives 36 requirement obligations, 17 execution edges, and 36 verifiable contracts. However, the existing `Span.from_dict` implementation in the testbed calls `Span._is_span_v2_schema` and `Span.from_dict_v2` — referenced at E16 and R33 — but **neither the arch spec nor the behavior spec tests the v2 deserialization branch**. The `C34` behavior check only tests base64 decoding; the v2 schema path (legacy compatibility) is untested. R33 states "Also handles legacy non-base64 format and v2 schema" but the spec has no observer for the v2 path.
- **Affected**: R33, C34, E16

### Seed rubric: Requirement fidelity
**Score**: PASS

Each observable contract (C1–C36) directly tests the relation stated in the task and IR. No guessed stronger behaviors, no looser proxies. For example, C1 asserts `NotImplementedError` (the exact exception class), C17 asserts the exact sentinel string `"MLFLOW_NO_OP_SPAN_TRACE_ID"`, and C23 verifies base64 encoding on `to_dict` output.

### Seed rubric: Caller binding and architecture
**Score**: PARTIAL — 2 findings

The arch spec resolves material CALL edges through actual imports. For instance, `check_create_mlflow_span_import_and_call_path` imports `create_mlflow_span` from `mlflow.entities.span` and dispatches through four input types. `check_trace_to_mlflow_trace_path` imports `_Trace` from `mlflow.tracing.trace_manager` and calls `to_mlflow_trace()`. However:

1. **F1 (weak_constraint)**: `check_span_from_otel_proto_path` verifies that `Span.from_otel_proto` is callable and returns a Span with the correct name, but it does **not** verify that trace_id, span_id, attributes, events, status, or timing fields are correctly transferred from the protobuf. The only field-level assertion is `span.name == "proto_span"`. A stub that returns `Span(mock_span)` with a hardcoded name would pass.
   - **Affected**: C22, E5, R22

2. **F2 (weak_constraint)**: The arch spec `check_span_to_dict_id_encoding_helpers` only verifies the four helper functions are importable and callable — it does **not** test correctness (e.g., byte length for trace_id must be exactly 16, span_id exactly 8; base64 encoding round-trips). The behavior spec C23 partially covers this but uses the same mock with dataflow disconnect (see F3).
   - **Affected**: C23, E4, R23

### Seed rubric: Dataflow and lifecycle
**Score**: FAIL — 1 critical finding

**F3 (weak_constraint — mock dataflow disconnect)**: Both specs use `_make_mock_otel_span()` (arch spec) and `_make_mock_otel_span()` (behavior spec) that create mock OTel spans with a broken attribute dataflow:

```python
s.attributes = {}                           # ← _SpanAttributesRegistry.get reads from here
s._attr_store = {}                          # ← set_attribute writes here
s.set_attribute = lambda k, v: s._attr_store.update({k: v})
```

The real `_SpanAttributesRegistry.get` reads `self._span.attributes.get(key)`, but the mock's `set_attribute` writes to a separate `_attr_store` dict. Therefore, **any test that sets an attribute via the registry and then reads it back will observe None instead of the set value**. This affects every behavior check that exercises the attribute read path after a write through the mock:

| Affected Check | What breaks | Impact |
|---|---|---|
| C2 (LiveSpan.set_span_type) | `live.span_type` returns None, not "LLM" | False negative |
| C3 (to_immutable_span data) | Attribute comparison may fail | False negative |
| C18 (Span.attributes) | `_CachedSpanAttributesRegistry.get_all` returns empty dict | False negative |
| C20 (Span.request_id) | `request_id` via `get_attribute` returns None | False negative |
| C21 (Span.span_type) | `span_type` via `get_attribute` returns None | False negative |
| C23 (Span.to_dict) | Attributes dict is empty in output | False negative |
| C24 (Span.to_otel_proto) | Attributes not populated in proto | False negative |
| C27 (to_mlflow_trace) | Span attributes lost during conversion | False negative |
| C32 (_SpanAttributesRegistry.get_all) | Returns empty dict | False negative |
| C35 (roundtrip) | Attribute data lost | False negative |

The `_make_mock_otel_readable_span` helper (used for Span construction) does **not** have this bug because it directly sets `s.attributes = attributes or {}` and Span construction doesn't require `set_attribute` on ReadableSpan. So C18/C19/C20/C21/C23/C24 may partially work if they construct Span from a ReadableSpan mock, but any check that goes through `LiveSpan` → `_SpanAttributesRegistry.set` → `get` will fail.

**The same mock helpers appear in the repository test suite** (`/testbed/tests/tracing/helper.py`, `create_mock_otel_span`), but those tests exercise `InMemoryTraceManager` flows that primarily check trace/span registration and popping — they do not test attribute round-trips through `_SpanAttributesRegistry`. The generated specs, however, **do** test attribute round-trips and are therefore vulnerable.

- **Affected**: C2, C3, C18, C20, C21, C23, C24, C27, C32, C35; R2, R3, R18, R20, R21, R23, R24, R27, R32; E2, E7, E8, E13

### Seed rubric: Failure and compatibility
**Score**: PASS

Error paths are tested with correct exception classes. C1 asserts `NotImplementedError` for `LiveSpan.from_dict`. C25 asserts `MlflowException` for `_CachedSpanAttributesRegistry.set`. C26 asserts `MlflowException` with `INVALID_PARAMETER_VALUE` for invalid `create_mlflow_span` input. C6 asserts `NoOpSpan.end` does not raise regardless of arguments. C36 exhaustively tests NoOpSpan interface. All NoOpSpan properties return correct types/values (None or sentinel).

### Seed rubric: Static-issue closure
**Score**: PASS

All 5 static issues have corresponding runtime checks in the arch spec:

| Static Issue | Arch Spec Check | Verdict |
|---|---|---|
| `_decode_id_from_byte` undefined | `check_span_to_dict_id_encoding_helpers` | Covered |
| `_is_base64_encoded` undefined | `check_span_to_dict_id_encoding_helpers` | Covered |
| `apply_span_processors` undefined | `check_apply_span_processors_importable` | Covered |
| `_get_truncated_preview` undefined | `check_truncation_helpers_importable` | Covered |
| `create_mlflow_span` undefined | `check_create_mlflow_span_import_and_call_path` | Covered |

### Seed rubric: Repository-test alignment
**Score**: PARTIAL — 1 finding

The repository test `/testbed/tests/tracing/test_trace_manager.py` tests `pop_trace` → `ManagerTrace` with `isinstance(trace.data.spans[0], Span)` and `not isinstance(trace.data.spans[0], LiveSpan)`. The generated specs replicate this pattern (C27). However, the repository's `create_mock_otel_span` helper in `/testbed/tests/tracing/helper.py` creates a `_MockOTelSpan` that extends both `trace_api.Span` and `ReadableSpan` and correctly wires `set_attribute` to write into `self._attributes` (the same dict that is read). The generated specs' mock helpers do **not** replicate this correct wiring. The repository test helper sets `self._attributes = {}` in `__init__` and `set_attribute` writes to `self._attributes[key] = value` — the same dict. The generated specs should adopt this pattern.

- **Affected**: F3 (above), all mock-dependent checks

### Seed rubric: Oracle strength
**Score**: PARTIAL — 2 findings

**F4 (weak_constraint)**: Several arch spec checks are import-level only, testing existence/callability without behavioral assertions:
- `check_apply_span_processors_importable`: tests `callable(apply_span_processors)` but not that it actually processes a span.
- `check_truncation_helpers_importable`: tests import + callable but not truncation correctness.
- `check_span_to_dict_id_encoding_helpers`: tests import + callable but not encoding correctness.

The behavior spec partially compensates (C29 tests `apply_span_processors` with None/noop processors; C31 tests `_otel_proto_bytes_to_id`; C33 tests truncation preview), so the combined suite is adequate. However, `_encode_span_id_to_byte` and `_encode_trace_id_to_byte` correctness (exact byte length) is only tested indirectly through the to_dict roundtrip (C23/C35).

**F5 (weak_constraint)**: `C35` (roundtrip) constructs a mock OTel ReadableSpan, creates a Span, calls `to_dict()` then `from_dict()`, and compares `trace_id`, `span_id`, `name`, `start_time`, `end_time`, `status`, `events`, `attributes`. However, because the mock ReadableSpan uses `s.attributes = attributes or {}` as a plain dict, and `from_dict` expects serialized attribute values (JSON strings), the roundtrip's attribute comparison may fail on deserialization mismatch unless the mock attributes happen to be JSON-serialized. The test does not explicitly set up JSON-serialized attributes on the mock, so the roundtrip check is fragile.

- **Affected**: C35, R23, R33

## Findings

### Finding 1: `missing_requirement` — v2 schema deserialization path untested
- **Affected IDs**: R33, C34, E16
- **Static Issue**: None directly (v2 path is not a static issue, it's a code path in the existing `from_dict`)
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` L269–270: `from_dict` calls `Span._is_span_v2_schema(data)` and `cls.from_dict_v2(data)`. The skinny reference at L258–329 implements both `_is_span_v2_schema` and `from_dict_v2`. The IR mentions "v2 schema" in C34/R33.
- **Gap**: Neither spec test exercises the v2 deserialization branch. If `_is_span_v2_schema` always returns False or `from_dict_v2` is missing, the existing C34 base64 test would still pass because v3-path would handle base64-encoded IDs.
- **Rework Instruction**: Add a behavior check that provides a v2-schema dict (with `"context"` keys containing hex `trace_id`/`span_id` instead of base64-encoded top-level keys) and verifies `Span.from_dict` correctly deserializes it. Alternatively, explicitly test `Span._is_span_v2_schema` returns True for v2-format data and `Span.from_dict_v2` returns a valid Span.

### Finding 2: `weak_constraint` — `Span.from_otel_proto` field coverage
- **Affected IDs**: C22, E5, R22
- **Static Issue**: None
- **Repository Evidence**: Skinny `/testbed/libs/skinny/mlflow/entities/span.py` L366–420 extracts trace_id, span_id, parent_span_id, name, start/end times, attributes, events, and status from the protobuf. The arch spec check only asserts `span.name == "proto_span"`.
- **Gap**: A stub that returns `Span(mock_readable_span)` with hardcoded name would pass. The check does not verify trace_id, span_id, start_time, end_time, attributes, events, or status are correctly transferred.
- **Rework Instruction**: Extend `check_span_from_otel_proto_path` to assert at minimum `span.start_time_ns == 100`, `span.end_time_ns == 200`, and that `span.status.status_code == SpanStatusCode.OK`. Also verify the trace_id and span_id are non-None.

### Finding 3: `weak_constraint` — Mock attribute dataflow disconnect (CRITICAL)
- **Affected IDs**: C2, C3, C18, C20, C21, C23, C24, C27, C32, C35; R2, R3, R18, R20, R21, R23, R24, R27, R32; E2, E7, E8, E13
- **Static Issue**: None
- **Repository Evidence**: `/testbed/tests/tracing/helper.py` L65–85: `_MockOTelSpan.__init__` sets `self._attributes = {}` and `set_attribute` writes to `self._attributes[key] = value` — the same dict used for reading. The generated specs' `_make_mock_otel_span` writes to `s._attr_store` while `_SpanAttributesRegistry.get` reads from `s.attributes` (a separate empty dict `{}`).
- **Gap**: Every behavior check that sets attributes via `LiveSpan` → `_SpanAttributesRegistry.set` and then reads them back via `get` will observe None/failure because the mock does not connect write and read paths. This makes ~10 behavior checks unreliable.
- **Rework Instruction**: Fix `_make_mock_otel_span` in both arch_spec.py and behavior_spec.py to use a single dict for attribute storage. Either:
  ```python
  s.attributes = {}
  s.set_attribute = lambda k, v: s.attributes.__setitem__(k, v)
  s.set_attributes = lambda d: s.attributes.update(d)
  ```
  Or follow the repository test pattern from `/testbed/tests/tracing/helper.py` L65–85 which uses a single `self._attributes` dict and a `set_attribute` method that writes to it.

### Finding 4: `weak_constraint` — `C35` roundtrip attribute fragility
- **Affected IDs**: C35, R23, R33
- **Static Issue**: None
- **Repository Evidence**: The `from_dict` implementation at `/testbed/mlflow/entities/span.py` L258–329 expects attributes dict values to be JSON-serialized strings (matching `to_dict` output). The behavior spec's `_make_mock_otel_readable_span` sets `s.attributes = attributes or {}` with raw (non-JSON-serialized) values.
- **Gap**: When the roundtrip test calls `span.to_dict()`, attributes are stored as-is in the dict. When `Span.from_dict()` processes the result, it expects attributes in `data["attributes"]` to be JSON strings. The `OTelReadableSpan` constructor receives these as-is and stores them. Subsequent `_CachedSpanAttributesRegistry.get` calls `json.loads` on them. If the original attribute values weren't JSON-encoded, the deserialization will fail or produce incorrect results.
- **Rework Instruction**: In the roundtrip test, pre-serialize mock attributes using `dump_span_attribute_value` to match the format that `from_dict` expects. E.g., `attrs = {SpanAttributeKey.SPAN_TYPE: dump_span_attribute_value("LLM")}`.

### Finding 5: `weak_constraint` — `check_span_to_dict_id_encoding_helpers` tests existence only
- **Affected IDs**: C23, E4, R23
- **Static Issue**: `_decode_id_from_byte`, `_is_base64_encoded` undefined (static issue #1, #2)
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L456–481: `_encode_span_id_to_byte` uses `int.to_bytes(length=8, ...)`, `_encode_trace_id_to_byte` uses `length=16`, `_decode_id_from_byte` uses `base64.b64decode` + `int.from_bytes`. The arch spec only tests importability.
- **Gap**: A function that returns wrong byte lengths or doesn't use big-endian encoding would pass the arch spec check. The behavior spec C31 tests `_otel_proto_bytes_to_id` (a different function in otlp.py) but not `_encode_span_id_to_byte` or `_encode_trace_id_to_byte`.
- **Rework Instruction**: Add behavior checks that verify `_encode_trace_id_to_byte(N)` produces exactly 16 bytes in big-endian order, `_encode_span_id_to_byte(N)` produces exactly 8 bytes, `_encode_bytes_to_base64` is the inverse of `_decode_id_from_byte`, and `_is_base64_encoded` correctly discriminates base64 from hex strings.

## Decision

**Decision: REWORK**

Five findings require rework before the specs can reliably validate the implementation:
1. **Missing v2 schema test** (F1) — add a behavior check for the legacy deserialization path.
2. **Weak from_otel_proto test** (F2) — add field-level assertions beyond span name.
3. **CRITICAL mock dataflow disconnect** (F3) — fix `_make_mock_otel_span` in both specs to use a single attribute dict, following the repository test pattern.
4. **Fragile roundtrip test** (F4) — pre-serialize mock attributes for the from_dict path.
5. **Weak ID encoder tests** (F5) — add byte-length and roundtrip assertions for the four span.py helper functions.
