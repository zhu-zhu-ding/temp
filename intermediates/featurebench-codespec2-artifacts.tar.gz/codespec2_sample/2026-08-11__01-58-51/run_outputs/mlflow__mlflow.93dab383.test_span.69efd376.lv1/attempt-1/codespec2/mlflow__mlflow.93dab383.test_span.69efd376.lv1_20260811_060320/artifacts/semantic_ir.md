# Semantic IR

## L1. Requirement Obligations

### R1: LiveSpan.from_dict — Always Raise NotImplementedError
- **Type**: Failure / Interface
- **Statement**: `LiveSpan.from_dict(cls, data)` must always raise `NotImplementedError` with a message indicating the method is not supported for the `LiveSpan` class, because live spans represent active runtime objects that cannot be reconstructed from serialized data.
- **Task Evidence**: Interface Description 2 (`LiveSpan.from_dict`)
- **Acceptance**: Calling `LiveSpan.from_dict(some_dict)` raises `NotImplementedError`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L665-666: full implementation raises `NotImplementedError("The \`from_dict\` method is not supported for the LiveSpan class.")`.
- **Uncertainty**: Exact error message wording.

### R2: LiveSpan.set_span_type — Set Span Type Attribute
- **Type**: Dataflow / Side-effect
- **Statement**: `LiveSpan.set_span_type(span_type)` must store the given span type string as a span attribute under the key `SpanAttributeKey.SPAN_TYPE` via the internal `_SpanAttributesRegistry.set()` mechanism.
- **Task Evidence**: Interface Description 2 (`LiveSpan.set_span_type`)
- **Acceptance**: After calling `set_span_type("LLM")`, reading `span.span_type` returns `"LLM"`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L525-527: delegates to `self.set_attribute(SpanAttributeKey.SPAN_TYPE, span_type)`.
- **Uncertainty**: None.

### R3: LiveSpan.to_immutable_span — Downcast to Span
- **Type**: State / Dataflow
- **Statement**: `LiveSpan.to_immutable_span()` must return an immutable `Span` object wrapping the same underlying OpenTelemetry span. No data copying is required because all state is already in the OTel span object. The returned `Span` must not allow further attribute modifications through `_CachedSpanAttributesRegistry`.
- **Task Evidence**: Interface Description 2 (`LiveSpan.to_immutable_span`)
- **Acceptance**: `live_span.to_immutable_span()` returns `isinstance(result, Span)` and `result is not isinstance(result, LiveSpan)`. The returned span's attributes match the live span's.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L668-675: `return Span(self._span)`.
- **Uncertainty**: None.

### R4: NoOpSpan._trace_id — Return None
- **Type**: Interface
- **Statement**: `NoOpSpan._trace_id` property must return `None` since no-op spans have no valid OpenTelemetry trace ID.
- **Task Evidence**: Interface Description 2 (`NoOpSpan._trace_id`)
- **Acceptance**: `NoOpSpan()._trace_id is None`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `@property` returning `None`.
- **Uncertainty**: None.

### R5: NoOpSpan.add_event — No-Operation
- **Type**: Interface / Side-effect
- **Statement**: `NoOpSpan.add_event(event)` must accept a `SpanEvent` argument and perform no operation (pass), maintaining interface compatibility without errors.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.add_event`)
- **Acceptance**: Calling `noop.add_event(some_event)` does not raise.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `def add_event(self, event: SpanEvent): pass`.
- **Uncertainty**: None.

### R6: NoOpSpan.end — No-Operation
- **Type**: Interface / Side-effect
- **Statement**: `NoOpSpan.end(outputs, attributes, status, end_time_ns)` must accept the same parameters as `LiveSpan.end()` and perform no operation.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.end`)
- **Acceptance**: Calling `noop.end(outputs={"x": 1})` does not raise.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `def end(self, outputs=None, attributes=None, status=None, end_time_ns=None): pass`.
- **Uncertainty**: None.

### R7: NoOpSpan.end_time_ns — Return None
- **Type**: Interface
- **Statement**: `NoOpSpan.end_time_ns` property must return `None`.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.end_time_ns`)
- **Acceptance**: `NoOpSpan().end_time_ns is None`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `return None`.
- **Uncertainty**: None.

### R8: NoOpSpan.name — Return None
- **Type**: Interface
- **Statement**: `NoOpSpan.name` property must return `None`.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.name`)
- **Acceptance**: `NoOpSpan().name is None`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `return None`.
- **Uncertainty**: None.

### R9: NoOpSpan.set_attribute — No-Operation
- **Type**: Interface / Side-effect
- **Statement**: `NoOpSpan.set_attribute(key, value)` must accept key and value arguments and perform no operation.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.set_attribute`)
- **Acceptance**: Calling `noop.set_attribute("key", "value")` does not raise.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `def set_attribute(self, key: str, value: Any): pass`.
- **Uncertainty**: None.

### R10: NoOpSpan.set_attributes — No-Operation
- **Type**: Interface / Side-effect
- **Statement**: `NoOpSpan.set_attributes(attributes)` must accept a dictionary argument and perform no operation.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.set_attributes`)
- **Acceptance**: Calling `noop.set_attributes({"k": "v"})` does not raise.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `def set_attributes(self, attributes: dict[str, Any]): pass`.
- **Uncertainty**: None.

### R11: NoOpSpan.set_inputs — No-Operation
- **Type**: Interface / Side-effect
- **Statement**: `NoOpSpan.set_inputs(inputs)` must accept any value and perform no operation.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.set_inputs`)
- **Acceptance**: Calling `noop.set_inputs({"x": 1})` does not raise.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `def set_inputs(self, inputs: dict[str, Any]): pass`.
- **Uncertainty**: None.

### R12: NoOpSpan.set_outputs — No-Operation
- **Type**: Interface / Side-effect
- **Statement**: `NoOpSpan.set_outputs(outputs)` must accept any value and perform no operation.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.set_outputs`)
- **Acceptance**: Calling `noop.set_outputs({"y": 2})` does not raise.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `def set_outputs(self, outputs: dict[str, Any]): pass`.
- **Uncertainty**: None.

### R13: NoOpSpan.set_status — No-Operation
- **Type**: Interface / Side-effect
- **Statement**: `NoOpSpan.set_status(status)` must accept a `SpanStatus` argument and perform no operation.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.set_status`)
- **Acceptance**: Calling `noop.set_status(SpanStatus("OK"))` does not raise.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `def set_status(self, status: SpanStatus): pass`.
- **Uncertainty**: None.

### R14: NoOpSpan.span_id — Return None
- **Type**: Interface
- **Statement**: `NoOpSpan.span_id` property must return `None`.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.span_id`)
- **Acceptance**: `NoOpSpan().span_id is None`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `return None`.
- **Uncertainty**: None.

### R15: NoOpSpan.start_time_ns — Return None
- **Type**: Interface
- **Statement**: `NoOpSpan.start_time_ns` property must return `None`.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.start_time_ns`)
- **Acceptance**: `NoOpSpan().start_time_ns is None`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `return None`.
- **Uncertainty**: None.

### R16: NoOpSpan.status — Return None
- **Type**: Interface
- **Statement**: `NoOpSpan.status` property must return `None`.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.status`)
- **Acceptance**: `NoOpSpan().status is None`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class: `return None`.
- **Uncertainty**: None.

### R17: NoOpSpan.trace_id — Return Sentinel Constant
- **Type**: Interface
- **Statement**: `NoOpSpan.trace_id` property must return the constant `NO_OP_SPAN_TRACE_ID = "MLFLOW_NO_OP_SPAN_TRACE_ID"` to distinguish no-op spans from real ones.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.trace_id`)
- **Acceptance**: `NoOpSpan().trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L758 and NoOpSpan class: `return NO_OP_SPAN_TRACE_ID`.
- **Uncertainty**: None.

### R18: Span.attributes — Return All Deserialized Attributes
- **Type**: Dataflow
- **Statement**: `Span.attributes` property must return a dictionary of all span attributes, deserialized from their JSON string representation using `_CachedSpanAttributesRegistry.get_all()`.
- **Task Evidence**: Interface Description 2 (`Span.attributes`)
- **Acceptance**: Accessing `span.attributes` returns a `dict[str, Any]` containing all deserialized attribute key-value pairs.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L184-188: `return self._attributes.get_all()`.
- **Uncertainty**: Requires `get_all()` method on `_SpanAttributesRegistry`.

### R19: Span.events — Return List of SpanEvent Objects
- **Type**: Dataflow
- **Statement**: `Span.events` property must return a list of `SpanEvent` objects, converting each OTel event's `BoundedAttributes` to a plain dictionary to avoid serialization issues with lock objects.
- **Task Evidence**: Interface Description 2 (`Span.events`)
- **Acceptance**: `span.events` returns `list[SpanEvent]` with each event having `name`, `timestamp`, and `attributes` (plain dict).
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L191-207: list comprehension over `self._span.events` with `dict(event.attributes)`.
- **Uncertainty**: None.

### R20: Span.request_id — Alias for trace_id
- **Type**: Compatibility / Interface
- **Statement**: `Span.request_id` property must return the same value as `Span.trace_id`, providing backward compatibility for deprecated `request_id` usage.
- **Task Evidence**: Interface Description 2 (`Span.request_id`)
- **Acceptance**: `span.request_id == span.trace_id`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L124-126: `return self.trace_id`.
- **Uncertainty**: None.

### R21: Span.span_type — Return Span Type Attribute
- **Type**: Dataflow
- **Statement**: `Span.span_type` property must return the value of the `SpanAttributeKey.SPAN_TYPE` attribute, deserialized via `get_attribute`.
- **Task Evidence**: Interface Description 2 (`Span.span_type`)
- **Acceptance**: `span.span_type` returns the span type string (e.g., `"LLM"`, `"UNKNOWN"`) or `None` if not set.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L171-173: `return self.get_attribute(SpanAttributeKey.SPAN_TYPE)`.
- **Uncertainty**: None.

### R22: Span.from_otel_proto — Create Span from OTel Protobuf
- **Type**: Dataflow / Compatibility
- **Statement**: `Span.from_otel_proto(otel_proto_span, location_id=None)` classmethod must convert an OpenTelemetry protobuf span into an MLflow `Span` object. It must decode trace/span IDs from protobuf bytes via `_otel_proto_bytes_to_id`, map protobuf status codes to OTel SDK status codes, generate an MLflow trace ID (v4 if location_id provided, otherwise standard), serialize all attributes using `dump_span_attribute_value`, decode events, and construct an `OTelReadableSpan` passed to the Span constructor.
- **Task Evidence**: Interface Description 2 (`Span.from_otel_proto`)
- **Acceptance**: Given a valid OTel proto span, returns an `isinstance(result, Span)` with correct trace_id, span_id, name, status, events, and attributes.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L366-420.
- **Uncertainty**: `_otel_proto_bytes_to_id` must be defined in `mlflow/tracing/utils/otlp.py`.

### R23: Span.to_dict — Serialize to Dictionary
- **Type**: Dataflow / Compatibility
- **Statement**: `Span.to_dict()` must serialize the span into a dictionary with keys: `trace_id` (base64-encoded 16-byte trace ID), `span_id` (base64-encoded 8-byte span ID), `parent_span_id` (base64 or None), `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events` (list of dicts), `status` (code name + message), and `attributes` (dumped attribute values). IDs must be converted from OTel integer format to bytes (trace_id: 16 bytes big-endian, span_id: 8 bytes big-endian) then base64-encoded.
- **Task Evidence**: Interface Description 2 (`Span.to_dict`)
- **Acceptance**: `span.to_dict()` returns a dict with all keys; trace_id and span_id are base64 strings; roundtrip via `Span.from_dict(span.to_dict())` preserves data.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L227-255. Helper functions `_encode_span_id_to_byte`, `_encode_trace_id_to_byte`, `_encode_bytes_to_base64`.
- **Uncertainty**: None.

### R24: Span.to_otel_proto — Convert to OTel Protobuf Span
- **Type**: Dataflow / Compatibility
- **Statement**: `Span.to_otel_proto()` must convert the MLflow Span to an OpenTelemetry protobuf `Span` message for OTLP export. It must set trace_id/span_id from hex strings to bytes, name, start/end times, parent_span_id (if any), status, attributes (via `_set_otel_proto_anyvalue`), and events (via `SpanEvent.to_otel_proto()`).
- **Task Evidence**: Interface Description 2 (`Span.to_otel_proto`)
- **Acceptance**: Returns an `OTelProtoSpan` protobuf message with all fields populated correctly.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L422-453.
- **Uncertainty**: None.

### R25: _CachedSpanAttributesRegistry.set — Raise MlflowException
- **Type**: Failure / State
- **Statement**: `_CachedSpanAttributesRegistry.set(key, value)` must always raise `MlflowException` with `INVALID_PARAMETER_VALUE` error code and message "The attributes of the immutable span must not be updated.", because cached spans are immutable and must not be modified.
- **Task Evidence**: Interface Description 2 (`_CachedSpanAttributesRegistry.set`)
- **Acceptance**: Calling `cached_registry.set("key", "value")` raises `MlflowException` with `INVALID_PARAMETER_VALUE`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L908-910.
- **Uncertainty**: None.

### R26: create_mlflow_span — Factory for Span/LiveSpan/NoOpSpan
- **Type**: Interface / Control
- **Statement**: `create_mlflow_span(otel_span, trace_id, span_type=None)` function must create the appropriate MLflow span object based on the input type: `NoOpSpan()` for None or `NonRecordingSpan`, `LiveSpan(otel_span, trace_id, span_type)` for `OTelSpan`, `Span(otel_span)` for `OTelReadableSpan`, and `MlflowException` for any other type.
- **Task Evidence**: Interface Description 2 (`create_mlflow_span`)
- **Acceptance**: Passing None returns NoOpSpan; passing OTelSpan returns LiveSpan; passing OTelReadableSpan returns Span; passing invalid type raises MlflowException(INVALID_PARAMETER_VALUE).
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L66-88.
- **Uncertainty**: `span_type` parameter defaults to `SpanType.UNKNOWN` in LiveSpan constructor.

### R27: _Trace.to_mlflow_trace — Convert Internal Trace to MLflow Trace
- **Type**: State / Dataflow
- **Statement**: `_Trace.to_mlflow_trace()` must convert all `LiveSpan` objects in `span_dict` to immutable `Span` objects via `to_immutable_span()`, construct a `TraceData` container, call `set_request_response_preview(trace_info, trace_data)` to set previews, and return a `Trace(info, trace_data)` object.
- **Task Evidence**: Interface Description 1 (`_Trace.to_mlflow_trace`)
- **Acceptance**: Calling `_trace.to_mlflow_trace()` returns `isinstance(result, Trace)` with all spans as `Span` (not `LiveSpan`) and request/response previews populated.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/tracing/trace_manager.py` L22-27.
- **Uncertainty**: Requires `set_request_response_preview` from `mlflow.tracing.utils.truncation`.

### R28: _decode_otel_proto_anyvalue — Decode OTel Protobuf AnyValue
- **Type**: Dataflow
- **Statement**: `_decode_otel_proto_anyvalue(pb_any_value)` must recursively decode an OpenTelemetry protobuf `AnyValue` message into a Python value. It must use `WhichOneof("value")` to determine the value type, handle `None` for unset values, `array_value` as list (recursive), `kvlist_value` as dict (recursive), and simple types via `getattr`. Return types: None, bool, str, int, float, bytes, list, dict.
- **Task Evidence**: Interface Description 3 (`_decode_otel_proto_anyvalue`)
- **Acceptance**: Decoding a protobuf AnyValue with `int_value=42` returns `42`; with `array_value=[1, "two"]` returns `[1, "two"]`; with empty value returns `None`.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py` L149-167.
- **Uncertainty**: None.

### R29: _otel_proto_bytes_to_id — Convert Protobuf Bytes to Integer ID
- **Type**: Dataflow
- **Statement**: `_otel_proto_bytes_to_id(id_bytes)` must convert protobuf byte sequences to integers using `int.from_bytes(id_bytes, byteorder="big", signed=False)`. Required by `Span.from_otel_proto`.
- **Task Evidence**: Implicit from static analysis — `_otel_proto_bytes_to_id` is imported by `span.py` (skinny version) and used in `from_otel_proto`. Not declared in interface descriptions but required for compilation.
- **Acceptance**: `_otel_proto_bytes_to_id(b'\x00\x01') == 1`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py` L143-145.
- **Uncertainty**: None.

### R30: apply_span_processors — Apply Configured Span Processors
- **Type**: Side-effect / Control
- **Statement**: `apply_span_processors(span)` must retrieve configured span processors from `mlflow.tracing.config.get_config()` and invoke each with the span, logging warnings on failure. Used by `LiveSpan.end()`.
- **Task Evidence**: Implicit from static analysis — `apply_span_processors` is called from `LiveSpan.end()` but undefined in the stub. Declared in the skinny reference.
- **Acceptance**: With no processors configured, calling `apply_span_processors(span)` is a no-op.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/tracing/utils/processor.py` L10-33.
- **Uncertainty**: Requires `mlflow.tracing.config.get_config()` to exist.

### R31: set_request_response_preview — Set Trace Info Previews
- **Type**: Side-effect / Dataflow
- **Statement**: `set_request_response_preview(trace_info, trace_data)` must extract request/response from `trace_data`, truncate them to the platform-appropriate maximum length (DBX vs OSS), and set them on `trace_info` only if not already set by the user.
- **Task Evidence**: Implicit from `_Trace.to_mlflow_trace()` — the method calls `set_request_response_preview`. Static analysis shows `_get_truncated_preview` is used but undefined.
- **Acceptance**: After calling `set_request_response_preview(info, data)`, `info.request_preview` and `info.response_preview` are populated.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/tracing/utils/truncation.py` L12-20.
- **Uncertainty**: None.

### R32: _SpanAttributesRegistry.get_all — Return All Deserialized Attributes
- **Type**: Dataflow
- **Statement**: `_SpanAttributesRegistry.get_all()` must iterate over all attribute keys in the underlying OTel span and deserialize each via `self.get(key)`, returning a dictionary.
- **Task Evidence**: Implicit — `Span.attributes` calls `self._attributes.get_all()`. The base `_SpanAttributesRegistry` in the stub lacks `get_all()`.
- **Acceptance**: Returns `dict[str, Any]` with all span attributes deserialized.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L874-875: `return {key: self.get(key) for key in self._span.attributes.keys()}`.
- **Uncertainty**: None.

### R33: Span.from_dict — Deserialization Compatibility (v2, v3, base64)
- **Type**: Compatibility / Dataflow
- **Statement**: The existing `Span.from_dict()` method must handle three schemas: v2 (with "context" key), v3 base64-encoded IDs, and pre-3.5.0 non-base64 IDs. Helper functions `_is_base64_encoded` and `_decode_id_from_byte` are required. Static analysis flags these as undefined in the stub.
- **Task Evidence**: Already partially implemented in stub (L258-329), but requires helper functions `_is_base64_encoded` and `_decode_id_from_byte`.
- **Acceptance**: `Span.from_dict(data)` correctly deserializes all three schema formats.
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L258-329 for `from_dict`, L470-481 for `_is_base64_encoded` and `_decode_id_from_byte`.
- **Uncertainty**: None.

### R34: NoOpSpan — Override parent_id to Return None
- **Type**: Interface
- **Statement**: `NoOpSpan.parent_id` must return `None`. Already present in stub but requires confirmation.
- **Task Evidence**: Implicit from NoOpSpan interface.
- **Acceptance**: `NoOpSpan().parent_id is None`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` — NoOpSpan class already has `parent_id` returning None in the stub.
- **Uncertainty**: Already present in stub.

### R35: NoOpSpan — Override trace_id to Return NO_OP_SPAN_TRACE_ID
- **Type**: Interface
- **Statement**: `NoOpSpan` must override `trace_id` to return `NO_OP_SPAN_TRACE_ID` instead of delegating to the parent's `Span.trace_id` which would fail because `_CachedSpanAttributesRegistry.get` would attempt to read from a `NonRecordingSpan`.
- **Task Evidence**: Interface Description 2 (`NoOpSpan.trace_id`)
- **Acceptance**: `NoOpSpan().trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"`
- **Repository Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L810-813: overrides `trace_id` property.
- **Uncertainty**: None.

## L2. Functional Design Graph

### N1: span.py module
- **Kind**: Module
- **Repository Evidence**: `/testbed/mlflow/entities/span.py`

### N2: Span (class)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` L91-112 (stub), full in skinny

### N3: LiveSpan (class)
- **Kind**: Class (extends Span)
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` L440- (stub), full in skinny

### N4: NoOpSpan (class)
- **Kind**: Class (extends Span)
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` L761- (stub), full in skinny

### N5: _SpanAttributesRegistry (class)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` L854-889

### N6: _CachedSpanAttributesRegistry (class)
- **Kind**: Class (extends _SpanAttributesRegistry)
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` L892-903

### N7: create_mlflow_span (module-level function)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/entities/span.py` (missing from stub; present in skinny)

### N8: trace_manager.py module
- **Kind**: Module
- **Repository Evidence**: `/testbed/mlflow/tracing/trace_manager.py`

### N9: _Trace (dataclass)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/tracing/trace_manager.py` L21-24

### N10: InMemoryTraceManager (class)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/tracing/trace_manager.py` L37-

### N11: otlp.py module
- **Kind**: Module
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/otlp.py`

### N12: _decode_otel_proto_anyvalue (function)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/otlp.py` (missing from stub)

### N13: processor.py module
- **Kind**: Module
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/processor.py`

### N14: apply_span_processors (function)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/processor.py` (missing from stub)

### N15: truncation.py module
- **Kind**: Module
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/truncation.py`

### N16: set_request_response_preview (function)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/truncation.py` (missing from stub)

### N17: _encode_span_id_to_byte, _encode_trace_id_to_byte, _encode_bytes_to_base64, _decode_id_from_byte, _is_base64_encoded (helper functions)
- **Kind**: Module-level functions in span.py
- **Repository Evidence**: Present in skinny span.py; missing from stub

### N18: _otel_proto_bytes_to_id (function)
- **Kind**: Function in otlp.py
- **Repository Evidence**: Present in skinny otlp.py; missing from stub

### N19: _get_truncated_preview (function)
- **Kind**: Function in truncation.py
- **Repository Evidence**: Present in skinny truncation.py; missing from stub

### E1: Span -> _CachedSpanAttributesRegistry (CONSTRUCT)
- **Kind**: CONTROL
- **Condition**: On `Span.__init__`, creates `_CachedSpanAttributesRegistry(otel_span)` and assigns to `self._attributes`.
- **Transfer**: `OTelReadableSpan` -> `_CachedSpanAttributesRegistry`
- **Evidence**: `/testbed/mlflow/entities/span.py` L110-112
- **Obligations**: R18, R19, R20, R21

### E2: Span.attributes -> _CachedSpanAttributesRegistry.get_all (CALL)
- **Kind**: CALL
- **Condition**: On property access.
- **Transfer**: Delegates to `self._attributes.get_all()`.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L188
- **Obligations**: R18, R32

### E3: Span.events -> OTelReadableSpan.events (DATA)
- **Kind**: DATA
- **Condition**: On property access, iterates `self._span.events` and converts each to `SpanEvent`.
- **Transfer**: OTel Event list -> `list[SpanEvent]`
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L198-207
- **Obligations**: R19

### E4: Span.to_dict -> _encode_trace_id_to_byte, _encode_span_id_to_byte, _encode_bytes_to_base64 (CALL)
- **Kind**: CALL
- **Condition**: Serializes span to dict with base64-encoded IDs.
- **Transfer**: OTel int IDs -> bytes -> base64 strings
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L227-255
- **Obligations**: R23

### E5: Span.from_otel_proto -> _otel_proto_bytes_to_id, _decode_otel_proto_anyvalue, generate_mlflow_trace_id_from_otel_trace_id, generate_trace_id_v4_from_otel_trace_id (CALL)
- **Kind**: CALL
- **Condition**: On classmethod call.
- **Transfer**: OTel protobuf -> MLflow Span
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L366-420
- **Obligations**: R22, R29, R28

### E6: Span.to_otel_proto -> _set_otel_proto_anyvalue, SpanEvent.to_otel_proto (CALL)
- **Kind**: CALL
- **Condition**: On method call.
- **Transfer**: MLflow Span -> OTelProtoSpan
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L422-453
- **Obligations**: R24

### E7: LiveSpan -> _SpanAttributesRegistry (CONSTRUCT)
- **Kind**: CONTROL
- **Condition**: On `LiveSpan.__init__`, creates `_SpanAttributesRegistry(otel_span)`.
- **Transfer**: `OTelSpan` -> `_SpanAttributesRegistry`
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L514-515
- **Obligations**: R2

### E8: LiveSpan.set_span_type -> _SpanAttributesRegistry.set (CALL)
- **Kind**: CALL
- **Condition**: On method call with span_type string.
- **Transfer**: Sets `SpanAttributeKey.SPAN_TYPE = span_type`.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L525-527
- **Obligations**: R2

### E9: LiveSpan.to_immutable_span -> Span (CONSTRUCT)
- **Kind**: CONTROL
- **Condition**: On method call.
- **Transfer**: Wraps `self._span` in new `Span()`.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L674-675
- **Obligations**: R3

### E10: LiveSpan.from_dict -> NotImplementedError (CONTROL)
- **Kind**: CONTROL
- **Condition**: Always raises.
- **Transfer**: No data transfer.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L665-666
- **Obligations**: R1

### E11: LiveSpan.end -> apply_span_processors (CALL)
- **Kind**: CALL
- **Condition**: During span end processing.
- **Transfer**: LiveSpan -> processor functions.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L654
- **Obligations**: R30

### E12: NoOpSpan -> NonRecordingSpan (CONSTRUCT)
- **Kind**: CONTROL
- **Condition**: On `NoOpSpan.__init__`.
- **Transfer**: Sets `self._span = NonRecordingSpan(context=None)`.
- **Evidence**: `/testbed/mlflow/entities/span.py` L781
- **Obligations**: R4-R17, R34, R35

### E13: _Trace.to_mlflow_trace -> LiveSpan.to_immutable_span, set_request_response_preview, Trace (CALL)
- **Kind**: CALL
- **Condition**: On method call.
- **Transfer**: `dict[str, LiveSpan]` -> `TraceData` with `Span` objects -> `Trace`.
- **Evidence**: `/testbed/libs/skinny/mlflow/tracing/trace_manager.py` L22-27
- **Obligations**: R27, R3, R31

### E14: create_mlflow_span -> LiveSpan, Span, NoOpSpan (CONTROL)
- **Kind**: CONTROL
- **Condition**: Based on type of otel_span.
- **Transfer**: OTel span -> appropriate MLflow span.
- **Evidence**: `/testbed/libs/skinny/mlflow/entities/span.py` L66-88
- **Obligations**: R26

### E15: _decode_otel_proto_anyvalue -> recursive self (CALL)
- **Kind**: CALL
- **Condition**: For array and kvlist value types.
- **Transfer**: Protobuf AnyValue -> Python value.
- **Evidence**: `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py` L149-167
- **Obligations**: R28

### E16: Span.from_dict -> _is_base64_encoded, _decode_id_from_byte (CALL)
- **Kind**: CALL
- **Condition**: During deserialization to determine ID encoding format.
- **Transfer**: Base64 string -> integer IDs.
- **Evidence**: `/testbed/mlflow/entities/span.py` L272-278
- **Obligations**: R33

### E17: InMemoryTraceManager.pop_trace -> _Trace.to_mlflow_trace (CALL)
- **Kind**: CALL
- **Condition**: When popping a completed trace.
- **Transfer**: Internal _Trace -> ManagerTrace with immutable Trace.
- **Evidence**: `/testbed/mlflow/tracing/trace_manager.py` L118-128 (stub, needs to_mlflow_trace)
- **Obligations**: R27

## L3. Verifiable Contracts

### C1: LiveSpan.from_dict raises NotImplementedError
- **Type**: Exception
- **Subject**: N3 (LiveSpan)
- **Relation**: `LiveSpan.from_dict(data)` → `NotImplementedError`
- **Expected**: Raises `NotImplementedError` with descriptive message.
- **Evidence**: Interface Description 2, skinny L665-666.
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/span.py` — `LiveSpan.from_dict`
- **Obligations**: R1
- **Graph**: E10

### C2: LiveSpan.set_span_type sets attribute
- **Type**: Side-effect
- **Subject**: N3 (LiveSpan)
- **Relation**: `live_span.set_span_type("LLM")` → `live_span.span_type == "LLM"`
- **Expected**: After setting, `span_type` property returns the set value.
- **Evidence**: Interface Description 2, skinny L525-527.
- **Observe**: FIELD_READ (via `span_type` property)
- **Target**: `/testbed/mlflow/entities/span.py` — `LiveSpan.set_span_type`
- **Obligations**: R2
- **Graph**: E8

### C3: LiveSpan.to_immutable_span returns Span
- **Type**: Return value
- **Subject**: N3 (LiveSpan)
- **Relation**: `live_span.to_immutable_span()` → `Span`
- **Expected**: Returns `isinstance(result, Span)` and `not isinstance(result, LiveSpan)`. All attributes preserved.
- **Evidence**: Interface Description 2, skinny L674-675.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `LiveSpan.to_immutable_span`
- **Obligations**: R3
- **Graph**: E9

### C4: NoOpSpan._trace_id is None
- **Type**: Return value
- **Subject**: N4 (NoOpSpan)
- **Relation**: `NoOpSpan()._trace_id` → `None`
- **Expected**: Returns `None`.
- **Evidence**: Interface Description 2, skinny NoOpSpan.
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan._trace_id`
- **Obligations**: R4
- **Graph**: E12

### C5: NoOpSpan.add_event is no-op
- **Type**: Side-effect
- **Subject**: N4 (NoOpSpan)
- **Relation**: `noop.add_event(event)` → no exception
- **Expected**: Does not raise.
- **Evidence**: Interface Description 2, skinny NoOpSpan.
- **Observe**: RETURN_VALUE (implicit None)
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.add_event`
- **Obligations**: R5
- **Graph**: E12

### C6: NoOpSpan.end is no-op
- **Type**: Side-effect
- **Subject**: N4 (NoOpSpan)
- **Relation**: `noop.end(outputs={"x": 1}, attributes={"k": "v"}, status="OK")` → no exception
- **Expected**: Does not raise regardless of arguments.
- **Evidence**: Interface Description 2, skinny NoOpSpan.
- **Observe**: RETURN_VALUE (implicit None)
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.end`
- **Obligations**: R6
- **Graph**: E12

### C7: NoOpSpan.end_time_ns is None
- **Type**: Return value
- **Subject**: N4 (NoOpSpan)
- **Relation**: `NoOpSpan().end_time_ns` → `None`
- **Expected**: Returns `None`.
- **Evidence**: Interface Description 2.
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.end_time_ns`
- **Obligations**: R7
- **Graph**: E12

### C8: NoOpSpan.name is None
- **Type**: Return value
- **Subject**: N4 (NoOpSpan)
- **Relation**: `NoOpSpan().name` → `None`
- **Expected**: Returns `None`.
- **Evidence**: Interface Description 2.
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.name`
- **Obligations**: R8
- **Graph**: E12

### C9: NoOpSpan.set_attribute is no-op
- **Type**: Side-effect
- **Subject**: N4 (NoOpSpan)
- **Relation**: `noop.set_attribute("key", "value")` → no exception
- **Expected**: Does not raise.
- **Evidence**: Interface Description 2.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.set_attribute`
- **Obligations**: R9
- **Graph**: E12

### C10: NoOpSpan.set_attributes is no-op
- **Type**: Side-effect
- **Subject**: N4 (NoOpSpan)
- **Relation**: `noop.set_attributes({"k": "v"})` → no exception
- **Expected**: Does not raise.
- **Evidence**: Interface Description 2.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.set_attributes`
- **Obligations**: R10
- **Graph**: E12

### C11: NoOpSpan.set_inputs is no-op
- **Type**: Side-effect
- **Subject**: N4 (NoOpSpan)
- **Relation**: `noop.set_inputs({"x": 1})` → no exception
- **Expected**: Does not raise.
- **Evidence**: Interface Description 2.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.set_inputs`
- **Obligations**: R11
- **Graph**: E12

### C12: NoOpSpan.set_outputs is no-op
- **Type**: Side-effect
- **Subject**: N4 (NoOpSpan)
- **Relation**: `noop.set_outputs({"y": 2})` → no exception
- **Expected**: Does not raise.
- **Evidence**: Interface Description 2.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.set_outputs`
- **Obligations**: R12
- **Graph**: E12

### C13: NoOpSpan.set_status is no-op
- **Type**: Side-effect
- **Subject**: N4 (NoOpSpan)
- **Relation**: `noop.set_status(SpanStatus("OK"))` → no exception
- **Expected**: Does not raise.
- **Evidence**: Interface Description 2.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.set_status`
- **Obligations**: R13
- **Graph**: E12

### C14: NoOpSpan.span_id is None
- **Type**: Return value
- **Subject**: N4 (NoOpSpan)
- **Relation**: `NoOpSpan().span_id` → `None`
- **Expected**: Returns `None`.
- **Evidence**: Interface Description 2.
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.span_id`
- **Obligations**: R14
- **Graph**: E12

### C15: NoOpSpan.start_time_ns is None
- **Type**: Return value
- **Subject**: N4 (NoOpSpan)
- **Relation**: `NoOpSpan().start_time_ns` → `None`
- **Expected**: Returns `None`.
- **Evidence**: Interface Description 2.
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.start_time_ns`
- **Obligations**: R15
- **Graph**: E12

### C16: NoOpSpan.status is None
- **Type**: Return value
- **Subject**: N4 (NoOpSpan)
- **Relation**: `NoOpSpan().status` → `None`
- **Expected**: Returns `None`.
- **Evidence**: Interface Description 2.
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.status`
- **Obligations**: R16
- **Graph**: E12

### C17: NoOpSpan.trace_id equals sentinel
- **Type**: Return value
- **Subject**: N4 (NoOpSpan)
- **Relation**: `NoOpSpan().trace_id` → `"MLFLOW_NO_OP_SPAN_TRACE_ID"`
- **Expected**: Returns the constant `NO_OP_SPAN_TRACE_ID`.
- **Evidence**: Interface Description 2, skinny NoOpSpan.
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan.trace_id`
- **Obligations**: R17, R35
- **Graph**: E12

### C18: Span.attributes returns all attributes
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `span.attributes` → `dict[str, Any]` with all keys from OTel span attributes.
- **Expected**: Returns dictionary containing all deserialized attribute values. Given a span with `{SpanAttributeKey.SPAN_TYPE: 'UNKNOWN'}`, accessing `.attributes` returns a dict including that key.
- **Evidence**: Interface Description 2, skinny L188.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.attributes`
- **Obligations**: R18, R32
- **Graph**: E2

### C19: Span.events returns list of SpanEvent
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `span.events` → `list[SpanEvent]`
- **Expected**: Returns `list[SpanEvent]` with each event having `name`, `timestamp`, and `attributes` (plain dict).
- **Evidence**: Interface Description 2, skinny L198-207.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.events`
- **Obligations**: R19
- **Graph**: E3

### C20: Span.request_id equals trace_id
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `span.request_id == span.trace_id`
- **Expected**: Returns same value as `trace_id`.
- **Evidence**: Interface Description 2, skinny L125-126.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.request_id`
- **Obligations**: R20
- **Graph**: E1

### C21: Span.span_type returns span type
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `span.span_type` → `str | None`
- **Expected**: Returns the `SpanAttributeKey.SPAN_TYPE` attribute value.
- **Evidence**: Interface Description 2, skinny L171-173.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.span_type`
- **Obligations**: R21
- **Graph**: E1

### C22: Span.from_otel_proto creates Span
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `Span.from_otel_proto(proto_span)` → `Span`
- **Expected**: Returns `isinstance(result, Span)`. Trace ID is generated from the OTel proto trace_id bytes.
- **Evidence**: Interface Description 2, skinny L366-420.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.from_otel_proto`
- **Obligations**: R22, R28, R29
- **Graph**: E5

### C23: Span.to_dict returns serialized dict
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `span.to_dict()` → `dict` with keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`.
- **Expected**: `trace_id` and `span_id` are base64-encoded strings (not raw ints or hex). `status.code` is OTel protobuf status code name (e.g., "STATUS_CODE_OK"). Round-trippable via `Span.from_dict`.
- **Evidence**: Interface Description 2 (detailed encoding notes), skinny L227-255.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.to_dict`
- **Obligations**: R23
- **Graph**: E4

### C24: Span.to_otel_proto returns protobuf span
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `span.to_otel_proto()` → `OTelProtoSpan`
- **Expected**: Returns protobuf message with `trace_id`, `span_id`, `name`, timing, `status`, `attributes`, `events` populated.
- **Evidence**: Interface Description 2, skinny L422-453.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.to_otel_proto`
- **Obligations**: R24
- **Graph**: E6

### C25: _CachedSpanAttributesRegistry.set raises MlflowException
- **Type**: Exception
- **Subject**: N6 (_CachedSpanAttributesRegistry)
- **Relation**: `cached_registry.set("key", "value")` → `MlflowException(INVALID_PARAMETER_VALUE)`
- **Expected**: Raises `MlflowException` with error code `INVALID_PARAMETER_VALUE` and message "The attributes of the immutable span must not be updated."
- **Evidence**: Interface Description 2, skinny L908-910.
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/span.py` — `_CachedSpanAttributesRegistry.set`
- **Obligations**: R25
- **Graph**: E1

### C26: create_mlflow_span returns correct type
- **Type**: Return value
- **Subject**: N7 (create_mlflow_span)
- **Relation**: Input type → output type:
  - `None` → `NoOpSpan`
  - `NonRecordingSpan` → `NoOpSpan`
  - `OTelSpan` → `LiveSpan`
  - `OTelReadableSpan` → `Span`
  - invalid → `MlflowException(INVALID_PARAMETER_VALUE)`
- **Expected**: Factory returns correct subclass for each valid OTel span type.
- **Evidence**: Interface Description 2, skinny L66-88.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `create_mlflow_span`
- **Obligations**: R26
- **Graph**: E14

### C27: _Trace.to_mlflow_trace returns Trace with immutable spans
- **Type**: Return value
- **Subject**: N9 (_Trace)
- **Relation**: `_trace.to_mlflow_trace()` → `Trace` where all `data.spans` are `Span` (not `LiveSpan`).
- **Expected**: Returns `Trace` with `TraceInfo` and `TraceData`. All spans are immutable. Request/response previews are set on TraceInfo.
- **Evidence**: Interface Description 1, skinny L22-27.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/trace_manager.py` — `_Trace.to_mlflow_trace`
- **Obligations**: R27, R3, R31
- **Graph**: E13

### C28: _decode_otel_proto_anyvalue decodes AnyValue
- **Type**: Return value
- **Subject**: N12 (_decode_otel_proto_anyvalue)
- **Relation**: Input protobuf type → output Python type:
  - `bool_value` → `bool`
  - `string_value` → `str`
  - `int_value` → `int`
  - `double_value` → `float`
  - `bytes_value` → `bytes`
  - `array_value` → `list` (recursive)
  - `kvlist_value` → `dict` (recursive)
  - unset → `None`
- **Expected**: Recursively decodes all AnyValue types to Python equivalents.
- **Evidence**: Interface Description 3, skinny L149-167.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/utils/otlp.py` — `_decode_otel_proto_anyvalue`
- **Obligations**: R28
- **Graph**: E15

### C29: apply_span_processors calls processors
- **Type**: Side-effect
- **Subject**: N14 (apply_span_processors)
- **Relation**: With no processors configured → no-op (no exception). With a processor → processor is called with span.
- **Expected**: Retrieves processors from config and invokes each.
- **Evidence**: Skinny L10-33.
- **Observe**: SIDE_EFFECT (processor call)
- **Target**: `/testbed/mlflow/tracing/utils/processor.py` — `apply_span_processors`
- **Obligations**: R30
- **Graph**: E11

### C30: set_request_response_preview populates trace_info
- **Type**: Side-effect
- **Subject**: N16 (set_request_response_preview)
- **Relation**: Given `TraceInfo` and `TraceData`, sets `request_preview` and `response_preview` on the info object if not already set.
- **Expected**: `trace_info.request_preview` and `trace_info.response_preview` are populated as truncated strings.
- **Evidence**: Skinny truncation.py L12-20.
- **Observe**: FIELD_READ (on trace_info after call)
- **Target**: `/testbed/mlflow/tracing/utils/truncation.py` — `set_request_response_preview`
- **Obligations**: R31
- **Graph**: E13

### C31: _otel_proto_bytes_to_id converts bytes to int
- **Type**: Return value
- **Subject**: N18 (_otel_proto_bytes_to_id)
- **Relation**: `_otel_proto_bytes_to_id(b'\x00\x00\x00\x00\x00\x00\x00\x01')` → `1`
- **Expected**: Uses `int.from_bytes(id_bytes, byteorder="big", signed=False)`.
- **Evidence**: Skinny otlp.py L143-145.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/utils/otlp.py` — `_otel_proto_bytes_to_id`
- **Obligations**: R29
- **Graph**: E5

### C32: _SpanAttributesRegistry.get_all returns all attributes
- **Type**: Return value
- **Subject**: N5 (_SpanAttributesRegistry)
- **Relation**: `registry.get_all()` → `dict[str, Any]` with all keys deserialized.
- **Expected**: Iterates `self._span.attributes.keys()` and deserializes each.
- **Evidence**: Skinny span.py L874-875.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `_SpanAttributesRegistry.get_all`
- **Obligations**: R32
- **Graph**: E2

### C33: _get_truncated_preview returns truncated string
- **Type**: Return value
- **Subject**: N19 (_get_truncated_preview)
- **Relation**: Given request/response string and role, returns truncated content fitting max length.
- **Expected**: For DBX, max 10000 chars; for OSS, max 1000 chars. Truncation appends "...".
- **Evidence**: Skinny truncation.py L24-52.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/tracing/utils/truncation.py` — `_get_truncated_preview`
- **Obligations**: R31
- **Graph**: E13

### C34: Span.from_dict handles base64-encoded IDs
- **Type**: Return value
- **Subject**: N2 (Span)
- **Relation**: `Span.from_dict({"trace_id": base64_encoded, ...})` → `Span` with correct integer OTel IDs.
- **Expected**: Detects base64 encoding via `_is_base64_encoded`, decodes via `_decode_id_from_byte`. Also handles legacy non-base64 format and v2 schema.
- **Evidence**: Stub L258-329 (partial), skinny L258-329 + helper functions.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.from_dict`, `_is_base64_encoded`, `_decode_id_from_byte`
- **Obligations**: R33
- **Graph**: E16

### C35: Span.to_dict / from_dict roundtrip
- **Type**: Compatibility
- **Subject**: N2 (Span)
- **Relation**: `Span.from_dict(span.to_dict())` → structurally equivalent Span (same trace_id, span_id, name, start_time, end_time, status, events, attributes).
- **Expected**: Full roundtrip preserves all span data.
- **Evidence**: `test_trace_from_dict_load_old_trace` in `/testbed/tests/entities/test_trace.py` tests from_dict with real data.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/span.py` — `Span.to_dict` and `Span.from_dict`
- **Obligations**: R23, R33
- **Graph**: E4, E16

### C36: NoOpSpan does not crash on any Span interface method
- **Type**: Compatibility
- **Subject**: N4 (NoOpSpan)
- **Relation**: All methods (`trace_id`, `span_id`, `name`, `start_time_ns`, `end_time_ns`, `status`, `parent_id`, `set_inputs`, `set_outputs`, `set_attributes`, `set_attribute`, `set_status`, `add_event`, `end`, `record_exception`) → no exception.
- **Expected**: No method on NoOpSpan raises an exception. It provides a complete, safe no-op implementation.
- **Evidence**: Interface Description 2 (all NoOpSpan methods), skinny NoOpSpan class.
- **Observe**: RETURN_VALUE (each method)
- **Target**: `/testbed/mlflow/entities/span.py` — `NoOpSpan`
- **Obligations**: R4-R17, R34, R35
- **Graph**: E12

## Static Issue Disposition

| Issue | Disposition | Evidence |
|-------|-------------|----------|
| `_decode_id_from_byte` undefined in span.py | Must be added as module-level helper | `/testbed/libs/skinny/mlflow/entities/span.py` L470-473 |
| `_is_base64_encoded` undefined in span.py | Must be added as module-level helper | `/testbed/libs/skinny/mlflow/entities/span.py` L476-481 |
| `apply_span_processors` undefined in span.py | Must be imported from `mlflow.tracing.utils.processor`; the function `apply_span_processors` must be defined there | `/testbed/libs/skinny/mlflow/tracing/utils/processor.py` L10-33 |
| `_get_truncated_preview` undefined in sqlalchemy_store.py | Must be defined in `mlflow/tracing/utils/truncation.py` and imported | `/testbed/libs/skinny/mlflow/tracing/utils/truncation.py` L24-52 |
| `create_mlflow_span` undefined in base_mlflow.py | Must be defined in `mlflow/entities/span.py` and properly exported | `/testbed/libs/skinny/mlflow/entities/span.py` L66-88 |

## Uncertainty Summary

1. **Exact error message wording** for `LiveSpan.from_dict` and `_CachedSpanAttributesRegistry.set` — the skinny reference provides the canonical messages.
2. **Import path resolution** for `create_mlflow_span` from `mlflow.tracing.processor.base_mlflow` — the function must be importable from `mlflow.entities.span`. The `__init__.py` at `/testbed/mlflow/entities/__init__.py` already exports `Span`, `LiveSpan`, `NoOpSpan`, `SpanType` but not `create_mlflow_span`. If callers import `create_mlflow_span` directly from `mlflow.entities.span`, the import must resolve.
3. **`_SpanAttributesRegistry.get_all()`** is called by `Span.attributes` but not defined in the stub. Must be added.
4. **`truncation.py`** has substantial missing content beyond `set_request_response_preview` — helper functions `_get_truncated_preview`, `_get_max_length`, `_try_extract_messages`, `_is_message`, `_get_last_message`, `_get_text_content_from_message` are all used by `set_request_response_preview` and must be present.
