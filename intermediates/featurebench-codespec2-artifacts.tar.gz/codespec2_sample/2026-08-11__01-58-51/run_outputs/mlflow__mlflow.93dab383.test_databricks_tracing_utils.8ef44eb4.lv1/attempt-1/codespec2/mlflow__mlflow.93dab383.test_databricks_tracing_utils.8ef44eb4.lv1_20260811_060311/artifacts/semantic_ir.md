# Semantic IR

## L1. Requirement Obligations

### R1: assessment_to_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert an MLflow `Assessment` entity to a `databricks_tracing_pb2.Assessment` protobuf message, mapping all fields including metadata (string-keyed), timestamps (ms → protobuf Timestamp via `FromMilliseconds`), source, expectation/feedback oneof, optional fields (span_id, rationale, assessment_id, overrides, valid), and extracting `trace_location` from `trace_id` for UC Schema locations.
- **Task Evidence**: Interface Description 1, function `assessment_to_proto`.
- **Acceptance**: The returned proto has `assessment_name`, `trace_id`, `source`, `create_time`, `last_update_time` always set; optional fields set only when non-None; metadata values stringified; exactly one of expectation/feedback set; `trace_location` set when trace_id is v4 UC Schema format.
- **Repository Evidence**: Caller at `/testbed/mlflow/store/tracking/databricks_rest_store.py:511` calls `assessment_to_proto(assessment)` and passes result to `message_to_json`. The existing `Assessment.to_proto()` at `/testbed/mlflow/entities/assessment.py:117` converts to `assessments_pb2.Assessment` (no `trace_location` field). The new function must convert to `databricks_tracing_pb2.Assessment` which has `trace_location` field (confirmed via proto inspection: `databricks_tracing_pb2.Assessment` has fields `['assessment_id','assessment_name','trace_id','trace_location','span_id','source','create_time','last_update_time','feedback','expectation','rationale','metadata','overrides','valid']`).
- **Uncertainty**: Whether `assessments_pb2.Assessment`'s `error` field needs handling in the databricks proto (the databricks proto lacks `error` field — confirmed via proto field listing).

### R2: get_trace_id_from_assessment_proto extraction
- **Type**: Dataflow / Compatibility
- **Statement**: Extract trace ID from either `databricks_tracing_pb2.Assessment` or `assessments_pb2.Assessment` proto. For UC Schema locations (proto has `trace_location` with `uc_schema` set), construct a v4 trace ID via `construct_trace_id_v4`. Otherwise return `proto.trace_id` directly.
- **Task Evidence**: Interface Description 1, function `get_trace_id_from_assessment_proto`.
- **Acceptance**: Returns a string trace ID. For UC Schema locations, uses `construct_trace_id_v4(location, trace_id)` where location = `catalog_name.schema_name`. For non-UC locations, returns raw `proto.trace_id`.
- **Repository Evidence**: Callers at `/testbed/mlflow/entities/assessment.py:288` (Feedback.from_proto) and `/testbed/mlflow/entities/assessment.py:426` (Expectation.from_proto), both import from `mlflow.utils.databricks_tracing_utils`. The `construct_trace_id_v4` utility exists at `/testbed/mlflow/tracing/utils/__init__.py`.
- **Uncertainty**: None.

### R3: inference_table_location_to_proto conversion
- **Type**: Dataflow
- **Statement**: Convert `InferenceTableLocation` entity to `databricks_tracing_pb2.InferenceTableLocation` proto, mapping `full_table_name`.
- **Task Evidence**: Interface Description 1, function `inference_table_location_to_proto`.
- **Acceptance**: Proto has `full_table_name` field set from entity.
- **Repository Evidence**: `InferenceTableLocation` entity at `/testbed/mlflow/entities/trace_location.py` has `full_table_name: str` field. Called indirectly via `trace_location_to_proto`.
- **Uncertainty**: None.

### R4: mlflow_experiment_location_to_proto conversion
- **Type**: Dataflow
- **Statement**: Convert `MlflowExperimentLocation` entity to `databricks_tracing_pb2.MlflowExperimentLocation` proto, mapping `experiment_id`.
- **Task Evidence**: Interface Description 1, function `mlflow_experiment_location_to_proto`.
- **Acceptance**: Proto has `experiment_id` field set from entity.
- **Repository Evidence**: `MlflowExperimentLocation` entity at `/testbed/mlflow/entities/trace_location.py` has `experiment_id: str` field. Called indirectly via `trace_location_to_proto`.
- **Uncertainty**: None.

### R5: trace_from_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert `databricks_tracing_pb2.Trace` proto to MLflow `Trace` entity. Extract `TraceInfo` via `TraceInfo.from_proto(proto.trace_info)` and convert each OTel proto span via `Span.from_otel_proto(span, location_id)`.
- **Task Evidence**: Interface Description 1, function `trace_from_proto`.
- **Acceptance**: Returns a `Trace` entity with valid `info` (TraceInfo) and `data` (TraceData with spans list).
- **Repository Evidence**: Caller at `/testbed/mlflow/store/tracking/databricks_rest_store.py:189` calls `trace_from_proto(proto, location)` for each proto in batch response. `Span.from_otel_proto` exists at `/testbed/mlflow/entities/span.py:366`. `TraceInfo.from_proto` exists at `/testbed/mlflow/entities/trace_info.py:165`.
- **Uncertainty**: The `location_id` passed to `Span.from_otel_proto` is the store's location string.

### R6: trace_info_to_v4_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert `TraceInfo` entity to `databricks_tracing_pb2.TraceInfo` proto (v4 format). Parse trace ID via `parse_trace_id_v4` for UC Schema locations; set all fields including `trace_location`, `client_request_id`, `request_preview`, `response_preview`, timestamps (ms → protobuf), `execution_duration`, `state`, `trace_metadata` (truncated), `tags` (truncated), and `assessments` (converted via `assessment_to_proto`).
- **Task Evidence**: Interface Description 1, function `trace_info_to_v4_proto`.
- **Acceptance**: Returns `pb.TraceInfo` with all fields populated correctly. For UC Schema locations, `trace_id` is the parsed inner trace ID (not the v4 wrapper).
- **Repository Evidence**: Caller at `/testbed/mlflow/entities/trace_info.py:103` calls `trace_info_to_v4_proto(self)` when `_is_v4()` is True. Static issue confirms this symbol is used but not imported. The `_truncate_request_metadata` and `_truncate_tags` helpers exist at `/testbed/mlflow/entities/trace_info_v2.py`. The `parse_trace_id_v4` function exists at `/testbed/mlflow/tracing/utils/__init__.py`.
- **Uncertainty**: None.

### R7: trace_location_from_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert `databricks_tracing_pb2.TraceLocation` proto to `TraceLocation` entity. Use `WhichOneof('identifier')` to determine type (UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE) and delegate to respective `from_proto` class methods or construct directly.
- **Task Evidence**: Interface Description 1, function `trace_location_from_proto`.
- **Acceptance**: Returns `TraceLocation` entity with correct `type` and location-specific field populated. Falls back to `TRACE_LOCATION_TYPE_UNSPECIFIED` if no identifier recognized.
- **Repository Evidence**: Caller at `/testbed/mlflow/entities/trace_location.py:246` calls `trace_location_from_proto(proto)` in `TraceLocation.from_proto`. Static issue confirms this symbol is used but not imported. The `pb.TraceLocation` has `uc_schema` field that `service_pb2.TraceLocation` lacks.
- **Uncertainty**: None.

### R8: trace_location_to_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert `TraceLocation` entity to `databricks_tracing_pb2.TraceLocation` proto. Dispatch on `trace_location.type` to call `uc_schema_location_to_proto`, `mlflow_experiment_location_to_proto`, or `inference_table_location_to_proto`. Raise `ValueError` for unsupported types.
- **Task Evidence**: Interface Description 1, function `trace_location_to_proto`.
- **Acceptance**: Returns `pb.TraceLocation` with correct `type` enum and location-specific field set.
- **Repository Evidence**: Callers at `/testbed/mlflow/store/tracking/databricks_rest_store.py:290,294,558` call `trace_location_to_proto(...)` for search and update operations. Static issue confirms these are used but not imported. The `service_pb2.TraceLocation` lacks `uc_schema`; the databricks version includes it—this function bridges the gap.
- **Uncertainty**: None.

### R9: trace_to_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert MLflow `Trace` entity to `databricks_tracing_pb2.Trace` proto. Uses `trace_info.to_proto()` (which dispatches to `trace_info_to_v4_proto` for v4) for trace_info and converts each span to OTel proto format.
- **Task Evidence**: Interface Description 1, function `trace_to_proto`.
- **Acceptance**: Returns `pb.Trace` with `trace_info` and `spans` fields populated.
- **Repository Evidence**: Caller at `/testbed/tests/store/tracking/test_databricks_rest_store.py:212,451` imports and uses `trace_to_proto` from `mlflow.utils.databricks_tracing_utils`. The test file explicitly imports `from mlflow.utils.databricks_tracing_utils import assessment_to_proto, trace_to_proto`.
- **Uncertainty**: None.

### R10: uc_schema_location_from_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert `databricks_tracing_pb2.UCSchemaLocation` proto to `UCSchemaLocation` entity. Extract `catalog_name`, `schema_name`, and optionally `otel_spans_table_name` and `otel_logs_table_name` (set as private attributes `_otel_spans_table_name`, `_otel_logs_table_name` when present via `HasField`).
- **Task Evidence**: Interface Description 1, function `uc_schema_location_from_proto`.
- **Acceptance**: Returns `UCSchemaLocation` entity with catalog/schema names and optional OTel table names.
- **Repository Evidence**: Caller at `/testbed/mlflow/store/tracking/databricks_rest_store.py:422` calls `uc_schema_location_from_proto(response.uc_schema)`. Static issue confirms used but not imported. `UCSchemaLocation` entity has default table names at `/testbed/mlflow/entities/trace_location.py`.
- **Uncertainty**: None.

### R11: uc_schema_location_to_proto conversion
- **Type**: Dataflow / Interface
- **Statement**: Convert `UCSchemaLocation` entity to `databricks_tracing_pb2.UCSchemaLocation` proto. Map `catalog_name`, `schema_name`, and private `_otel_spans_table_name`, `_otel_logs_table_name`.
- **Task Evidence**: Interface Description 1, function `uc_schema_location_to_proto`.
- **Acceptance**: Returns `pb.UCSchemaLocation` with all four fields populated.
- **Repository Evidence**: Callers at `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451` call `uc_schema_location_to_proto(location)`. Static issue confirms used but not imported.
- **Uncertainty**: None.

### R12: Span.inputs property
- **Type**: Interface / Dataflow
- **Statement**: The `Span` class must expose an `inputs` property that retrieves the input data stored as `SpanAttributeKey.INPUTS` (`"mlflow.spanInputs"`) via the cached attributes registry. Returns deserialized value or None.
- **Task Evidence**: Interface Description 3, `Span.inputs` property.
- **Acceptance**: `span.inputs` returns the deserialized input value (e.g., dict, list, string) or None if not set.
- **Repository Evidence**: Test at `/testbed/tests/entities/test_span.py:43` reads `span.inputs` and expects `{"input": 1}`. `LiveSpan.set_inputs` at `/testbed/mlflow/entities/span.py:529` stores via `SpanAttributeKey.INPUTS`. The `Span` class currently lacks `inputs` and `outputs` properties (visible gap at lines 155-165 of span.py).
- **Uncertainty**: None.

### R13: Span.outputs property
- **Type**: Interface / Dataflow
- **Statement**: The `Span` class must expose an `outputs` property that retrieves the output data stored as `SpanAttributeKey.OUTPUTS` (`"mlflow.spanOutputs"`) via the cached attributes registry. Returns deserialized value or None.
- **Task Evidence**: Interface Description 3, `Span.outputs` property.
- **Acceptance**: `span.outputs` returns the deserialized output value or None if not set.
- **Repository Evidence**: Test at `/testbed/tests/entities/test_span.py:44` reads `span.outputs` and expects `2`. `LiveSpan.set_outputs` at `/testbed/mlflow/entities/span.py:533` stores via `SpanAttributeKey.OUTPUTS`.
- **Uncertainty**: None.

### R14: AssessmentSourceType._standardize static method
- **Type**: Interface / Validation
- **Statement**: Provide a static method that validates and normalizes assessment source type strings. Creates an `AssessmentSourceType` instance, converts to string, returns the standardized value. Handles case-insensitivity, AI_JUDGE→LLM_JUDGE deprecation, and raises `MlflowException` with `INVALID_PARAMETER_VALUE` for invalid types.
- **Task Evidence**: Interface Description 2, `AssessmentSourceType._standardize`.
- **Acceptance**: Accepts any-cased valid type strings and deprecated AI_JUDGE; returns uppercase standardized string; raises `MlflowException` for invalid types.
- **Repository Evidence**: `AssessmentSource.__post_init__` at `/testbed/mlflow/entities/assessment_source.py:78` calls `AssessmentSourceType._standardize(self.source_type)`. Test at `/testbed/tests/entities/test_assessment_source.py` tests validation, case-insensitivity, and deprecation. Current class lacks `_standardize`.
- **Uncertainty**: None.

### R15: AssessmentSourceType __init__ and __str__
- **Type**: Interface / State
- **Statement**: `AssessmentSourceType.__init__(source_type: str)` must store the parsed source type value (delegating to `_parse`). `__str__()` must return the stored source type string. `_parse(source_type: str)` static method performs case-insensitive normalization, AI_JUDGE deprecation with `FutureWarning`, and validation against `_SOURCE_TYPES`.
- **Task Evidence**: Interface Description 2 notes: "The _standardize method must instantiate an AssessmentSourceType object by calling the constructor AssessmentSourceType(source_type), then convert the instance to a string representation to obtain the standardized value."
- **Acceptance**: `AssessmentSourceType("llm_judge")` creates instance; `str(instance)` returns `"LLM_JUDGE"`. `AssessmentSourceType("AI_JUDGE")` emits `FutureWarning` and stores `"LLM_JUDGE"`. Invalid types raise `MlflowException`.
- **Repository Evidence**: Class constants are simple strings at `/testbed/mlflow/entities/assessment_source.py:150-155`: `SOURCE_TYPE_UNSPECIFIED = "SOURCE_TYPE_UNSPECIFIED"`, `LLM_JUDGE = "LLM_JUDGE"`, etc. These must remain simple string values (not dicts).
- **Uncertainty**: None.

### R16: Caller binding resolution (static issues)
- **Type**: Compatibility / Dependency
- **Statement**: All 11 functions in `databricks_tracing_utils.py` must be importable by their callers. `trace_info_to_v4_proto` is called in `trace_info.py`; `trace_location_from_proto` is called in `trace_location.py`; `assessment_to_proto`, `trace_from_proto`, `trace_location_to_proto`, `uc_schema_location_from_proto`, `uc_schema_location_to_proto` are called in `databricks_rest_store.py`; `get_trace_id_from_assessment_proto` is called in `assessment.py`.
- **Task Evidence**: Static issues document: 7 unresolved symbols across 3 files.
- **Acceptance**: All callers can resolve their imports at runtime without import errors.
- **Repository Evidence**: `assessment.py` already uses lazy imports: `from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto`. `trace_info.py:103` calls bare `trace_info_to_v4_proto(self)` without import. `trace_location.py:246` calls bare `trace_location_from_proto(proto)` without import. `databricks_rest_store.py` calls 5 functions without imports.
- **Uncertainty**: `trace_info.py` and `trace_location.py` need import statements added; `databricks_rest_store.py` needs imports added. The exact import style (top-level vs lazy) should match existing patterns — `assessment.py` uses lazy imports, which suggests other entity modules should follow suit.

## L2. Functional Design Graph

### N1: databricks_tracing_utils module
- **Kind**: Module
- **Repository Evidence**: `/testbed/mlflow/utils/databricks_tracing_utils.py` (currently only imports, 11 functions must be added)

### N2: TraceInfo (entity)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/trace_info.py`

### N3: TraceLocation (entity)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/trace_location.py`

### N4: DatabricksTracingRestStore
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py`

### N5: Assessment (entity)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/assessment.py`

### N6: Span (entity)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/span.py`

### N7: AssessmentSourceType (entity)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/assessment_source.py`

### N8: Trace (entity)
- **Kind**: Class
- **Repository Evidence**: `/testbed/mlflow/entities/trace.py`

### N9: construct_trace_id_v4 / parse_trace_id_v4 (helpers)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/tracing/utils/__init__.py`

### N10: _truncate_request_metadata / _truncate_tags (helpers)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/entities/trace_info_v2.py`

### E1: TraceInfo._is_v4 → trace_info_to_v4_proto
- **Kind**: CALL
- **Condition**: When `self.trace_location.uc_schema is not None`
- **Transfer**: Passes `self` (TraceInfo), receives `pb.TraceInfo`
- **Evidence**: `/testbed/mlflow/entities/trace_info.py:100-103`
- **Obligations**: R6, R16

### E2: TraceLocation.from_proto → trace_location_from_proto
- **Kind**: CALL
- **Condition**: Always (classmethod dispatch)
- **Transfer**: Passes `proto` (pb.TraceLocation), receives `TraceLocation`
- **Evidence**: `/testbed/mlflow/entities/trace_location.py:246`
- **Obligations**: R7, R16

### E3: DatabricksTracingRestStore → assessment_to_proto
- **Kind**: CALL
- **Condition**: When creating assessment with UC schema location
- **Transfer**: Passes `assessment` (Assessment entity), receives `pb.Assessment`
- **Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py:511`
- **Obligations**: R1, R16

### E4: DatabricksTracingRestStore → trace_from_proto
- **Kind**: CALL
- **Condition**: When batch-getting traces from v4 endpoint
- **Transfer**: Passes `proto` (pb.Trace), `location` (str), receives `Trace`
- **Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py:189`
- **Obligations**: R5, R16

### E5: DatabricksTracingRestStore → trace_location_to_proto
- **Kind**: CALL
- **Condition**: When constructing search/update requests with UC schema
- **Transfer**: Passes `TraceLocation` entity, receives `pb.TraceLocation`
- **Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py:290,294,558`
- **Obligations**: R8, R16

### E6: DatabricksTracingRestStore → uc_schema_location_to_proto
- **Kind**: CALL
- **Condition**: When creating/linking UC storage locations
- **Transfer**: Passes `UCSchemaLocation` entity, receives `pb.UCSchemaLocation`
- **Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py:412,434,451`
- **Obligations**: R11, R16

### E7: DatabricksTracingRestStore → uc_schema_location_from_proto
- **Kind**: CALL
- **Condition**: When receiving UC storage location response
- **Transfer**: Passes `pb.UCSchemaLocation`, receives `UCSchemaLocation`
- **Evidence**: `/testbed/mlflow/store/tracking/databricks_rest_store.py:422`
- **Obligations**: R10, R16

### E8: Assessment (Feedback/Expectation).from_proto → get_trace_id_from_assessment_proto
- **Kind**: CALL
- **Condition**: Always during proto deserialization
- **Transfer**: Passes proto (pb.Assessment or assessments_pb2.Assessment), receives trace_id str
- **Evidence**: `/testbed/mlflow/entities/assessment.py:288,426`
- **Obligations**: R2, R16

### E9: trace_location_to_proto → uc_schema_location_to_proto / mlflow_experiment_location_to_proto / inference_table_location_to_proto
- **Kind**: CALL (dispatch)
- **Condition**: Based on `trace_location.type`
- **Transfer**: Passes subtype entity, receives subtype proto
- **Evidence**: Task Interface Description 1 (`trace_location_to_proto` delegates to specific converters)
- **Obligations**: R3, R4, R8, R11

### E10: trace_info_to_v4_proto → assessment_to_proto
- **Kind**: CALL
- **Condition**: When TraceInfo has assessments
- **Transfer**: Passes each Assessment entity, receives pb.Assessment
- **Evidence**: Task Interface Description 1 notes: "Associated assessments converted to protobuf format"
- **Obligations**: R1, R6

### E11: trace_to_proto → trace_info_to_v4_proto (via trace_info.to_proto)
- **Kind**: CALL (indirect)
- **Condition**: When Trace.info is v4
- **Transfer**: TraceInfo → pb.TraceInfo
- **Evidence**: `Trace.to_proto()` at `/testbed/mlflow/entities/trace.py` calls `self.info.to_proto()`, which dispatches to `trace_info_to_v4_proto` for v4
- **Obligations**: R6, R9

### E12: trace_from_proto → TraceInfo.from_proto / Span.from_otel_proto
- **Kind**: CALL
- **Condition**: Always
- **Transfer**: proto.trace_info → TraceInfo; proto.spans + location_id → list[Span]
- **Evidence**: Task Interface Description 1; `Span.from_otel_proto` at `/testbed/mlflow/entities/span.py:366`
- **Obligations**: R5

### E13: Span.inputs / Span.outputs → _CachedSpanAttributesRegistry.get
- **Kind**: CALL
- **Condition**: Property access
- **Transfer**: Looks up `SpanAttributeKey.INPUTS` / `SpanAttributeKey.OUTPUTS`
- **Evidence**: Existing `_CachedSpanAttributesRegistry` at `/testbed/mlflow/entities/span.py`; `SpanAttributeKey.INPUTS = "mlflow.spanInputs"` at `/testbed/mlflow/tracing/constant.py`
- **Obligations**: R12, R13

### E14: AssessmentSourceType.__init__ → AssessmentSourceType._parse
- **Kind**: CALL
- **Condition**: Constructor
- **Transfer**: source_type string → validated/stored value
- **Evidence**: Task Interface Description 2
- **Obligations**: R15

### E15: AssessmentSourceType._standardize → AssessmentSourceType.__init__ / __str__
- **Kind**: CALL
- **Condition**: Static method invocation
- **Transfer**: Creates instance, returns str(instance)
- **Evidence**: Task Interface Description 2; `AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize`
- **Obligations**: R14, R15

### E16: AssessmentSource.__post_init__ → AssessmentSourceType._standardize
- **Kind**: CALL
- **Condition**: After AssessmentSource dataclass initialization
- **Transfer**: Passes `self.source_type` string, receives standardized string
- **Evidence**: `/testbed/mlflow/entities/assessment_source.py:78`
- **Obligations**: R14

## L3. Verifiable Contracts

### C1: assessment_to_proto sets required fields
- **Type**: RETURN_VALUE
- **Subject**: `assessment_to_proto(assessment)`
- **Relation**: `proto.assessment_name == assessment.name AND proto.trace_id == assessment.trace_id AND proto.source == assessment.source.to_proto() AND proto.create_time == FromMilliseconds(assessment.create_time_ms) AND proto.last_update_time == FromMilliseconds(assessment.last_update_time_ms)`
- **Expected**: All required fields populated; trace_location set when trace_id is v4 format
- **Evidence**: Task Interface Description 1; existing `Assessment.to_proto()` pattern at `/testbed/mlflow/entities/assessment.py:117-150`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`
- **Obligations**: R1
- **Graph**: E3, E10

### C2: assessment_to_proto sets optional fields only when present
- **Type**: RETURN_VALUE
- **Subject**: `assessment_to_proto(assessment)` where `assessment.span_id is None`
- **Relation**: `proto.span_id` is empty/default
- **Expected**: Optional fields (span_id, rationale, assessment_id, overrides, valid) only set when non-None in source
- **Evidence**: Task Interface Description 1: "handles None values gracefully by only setting proto fields when the corresponding assessment fields are not None"
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`
- **Obligations**: R1
- **Graph**: E3

### C3: assessment_to_proto sets expectation or feedback but not both
- **Type**: RETURN_VALUE
- **Subject**: `assessment_to_proto(assessment)` where assessment has expectation
- **Relation**: `proto.WhichOneof('value') == 'expectation'` and proto.expectation is set, proto.feedback is not
- **Expected**: Exactly one of expectation/feedback set in proto
- **Evidence**: Task Interface Description 1: "Either expectation or feedback will be set in the proto, but not both"
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`
- **Obligations**: R1
- **Graph**: E3

### C4: assessment_to_proto converts metadata values to strings
- **Type**: RETURN_VALUE
- **Subject**: `assessment_to_proto(assessment)` where assessment has metadata with non-string values
- **Relation**: All proto.metadata values are strings (`str(v)`)
- **Expected**: Metadata values stringified regardless of original type
- **Evidence**: Task Interface Description 1: "Metadata values are converted to strings regardless of their original type"
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`
- **Obligations**: R1
- **Graph**: E3

### C5: get_trace_id_from_assessment_proto with UC schema location
- **Type**: RETURN_VALUE
- **Subject**: `get_trace_id_from_assessment_proto(proto)` where proto has `trace_location.uc_schema` set
- **Relation**: Returns `construct_trace_id_v4(f"{catalog}.{schema}", proto.trace_id)`
- **Expected**: v4 trace ID string combining location and trace ID
- **Evidence**: Task Interface Description 1; `construct_trace_id_v4` at `/testbed/mlflow/tracing/utils/__init__.py`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`
- **Obligations**: R2
- **Graph**: E8

### C6: get_trace_id_from_assessment_proto without UC schema
- **Type**: RETURN_VALUE
- **Subject**: `get_trace_id_from_assessment_proto(proto)` where proto has no `trace_location.uc_schema`
- **Relation**: Returns `proto.trace_id` directly
- **Expected**: Raw trace ID string
- **Evidence**: Task Interface Description 1: "For other location types, it returns the trace ID directly"
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`
- **Obligations**: R2
- **Graph**: E8

### C7: get_trace_id_from_assessment_proto handles both proto types
- **Type**: RETURN_VALUE
- **Subject**: `get_trace_id_from_assessment_proto(proto)` where proto is `assessments_pb2.Assessment` (no trace_location field)
- **Relation**: Returns `proto.trace_id` directly (no trace_location to check)
- **Expected**: Works with both `databricks_tracing_pb2.Assessment` and `assessments_pb2.Assessment`
- **Evidence**: Task Interface Description 1: type annotation `pb.Assessment | assessments_pb2.Assessment`; `assessments_pb2.Assessment` lacks `trace_location` field (confirmed via proto inspection)
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`
- **Obligations**: R2
- **Graph**: E8

### C8: inference_table_location_to_proto maps full_table_name
- **Type**: RETURN_VALUE
- **Subject**: `inference_table_location_to_proto(loc)` where `loc.full_table_name = "catalog.schema.table"`
- **Relation**: `proto.full_table_name == "catalog.schema.table"`
- **Expected**: Proto field matches entity field
- **Evidence**: Task Interface Description 1; `InferenceTableLocation` at `/testbed/mlflow/entities/trace_location.py`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:inference_table_location_to_proto`
- **Obligations**: R3
- **Graph**: E9

### C9: mlflow_experiment_location_to_proto maps experiment_id
- **Type**: RETURN_VALUE
- **Subject**: `mlflow_experiment_location_to_proto(loc)` where `loc.experiment_id = "123"`
- **Relation**: `proto.experiment_id == "123"`
- **Expected**: Proto field matches entity field
- **Evidence**: Task Interface Description 1; `MlflowExperimentLocation` at `/testbed/mlflow/entities/trace_location.py`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:mlflow_experiment_location_to_proto`
- **Obligations**: R4
- **Graph**: E9

### C10: trace_from_proto returns Trace with valid info and spans
- **Type**: RETURN_VALUE
- **Subject**: `trace_from_proto(proto, location_id)` where proto has trace_info and spans
- **Relation**: Returns `Trace` where `isinstance(result.info, TraceInfo)` and `isinstance(result.data, TraceData)` and `len(result.data.spans) == len(proto.spans)`
- **Expected**: Trace entity reconstructed from proto
- **Evidence**: Task Interface Description 1; existing `Trace.from_proto` at `/testbed/mlflow/entities/trace.py`; `Span.from_otel_proto` at `/testbed/mlflow/entities/span.py:366`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`
- **Obligations**: R5
- **Graph**: E4, E12

### C11: trace_info_to_v4_proto sets all fields
- **Type**: RETURN_VALUE
- **Subject**: `trace_info_to_v4_proto(trace_info)` where trace_info has UC schema location
- **Relation**: `proto.trace_id == parse_trace_id_v4(trace_info.trace_id)[1]` (inner trace ID); proto.trace_location set; proto.request_time and execution_duration converted from ms; proto.trace_metadata and tags truncated
- **Expected**: Full v4 TraceInfo proto
- **Evidence**: Task Interface Description 1; `parse_trace_id_v4` at `/testbed/mlflow/tracing/utils/__init__.py`; truncation helpers at `/testbed/mlflow/entities/trace_info_v2.py`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`
- **Obligations**: R6
- **Graph**: E1, E10, E11

### C12: trace_info_to_v4_proto handles missing execution_duration
- **Type**: RETURN_VALUE
- **Subject**: `trace_info_to_v4_proto(trace_info)` where `trace_info.execution_duration is None`
- **Relation**: proto.execution_duration is not set (no `HasField`)
- **Expected**: execution_duration only set when not None
- **Evidence**: Task Interface Description 1: "Execution duration is only set in the protobuf if it's not None in the input"
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`
- **Obligations**: R6
- **Graph**: E1

### C13: trace_location_from_proto dispatches on identifier type
- **Type**: RETURN_VALUE
- **Subject**: `trace_location_from_proto(proto)` where proto has `uc_schema` identifier
- **Relation**: Returns `TraceLocation(type=UC_SCHEMA, uc_schema=UCSchemaLocation(...))`
- **Expected**: Correct TraceLocation entity for each identifier type
- **Evidence**: Task Interface Description 1; proto `WhichOneof('identifier')` pattern
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`
- **Obligations**: R7
- **Graph**: E2

### C14: trace_location_from_proto falls back to UNSPECIFIED
- **Type**: RETURN_VALUE
- **Subject**: `trace_location_from_proto(proto)` where no identifier field is set
- **Relation**: Returns `TraceLocation(type=TRACE_LOCATION_TYPE_UNSPECIFIED)`
- **Expected**: Graceful fallback
- **Evidence**: Task Interface Description 1: "Falls back to TRACE_LOCATION_TYPE_UNSPECIFIED if no recognized identifier is found"
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`
- **Obligations**: R7
- **Graph**: E2

### C15: trace_location_to_proto dispatches on type
- **Type**: RETURN_VALUE
- **Subject**: `trace_location_to_proto(loc)` where `loc.type == UC_SCHEMA`
- **Relation**: Returns `pb.TraceLocation(type=UC_SCHEMA, uc_schema=uc_schema_location_to_proto(loc.uc_schema))`
- **Expected**: Correct proto for each type
- **Evidence**: Task Interface Description 1; three location types
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`
- **Obligations**: R8
- **Graph**: E5, E9

### C16: trace_location_to_proto raises ValueError for unsupported type
- **Type**: EXCEPTION
- **Subject**: `trace_location_to_proto(loc)` where `loc.type` is not UC_SCHEMA, MLFLOW_EXPERIMENT, or INFERENCE_TABLE
- **Relation**: Raises `ValueError`
- **Expected**: ValueError with descriptive message
- **Evidence**: Task Interface Description 1: "Raises ValueError if the trace_location.type is not one of the supported types"
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`
- **Obligations**: R8
- **Graph**: E5

### C17: trace_to_proto returns pb.Trace with info and spans
- **Type**: RETURN_VALUE
- **Subject**: `trace_to_proto(trace)` where trace has valid info and spans
- **Relation**: `proto.trace_info` is set from `trace.info.to_proto()`; `proto.spans` contains OTel proto spans from each span
- **Expected**: pb.Trace with both fields populated
- **Evidence**: Task Interface Description 1; test at `/testbed/tests/store/tracking/test_databricks_rest_store.py:212` uses `trace_to_proto(trace)`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:trace_to_proto`
- **Obligations**: R9
- **Graph**: E11

### C18: uc_schema_location_from_proto maps all fields
- **Type**: RETURN_VALUE
- **Subject**: `uc_schema_location_from_proto(proto)` where proto has catalog_name, schema_name, otel_spans_table_name, otel_logs_table_name
- **Relation**: Returns `UCSchemaLocation(catalog_name=proto.catalog_name, schema_name=proto.schema_name)` with `_otel_spans_table_name` and `_otel_logs_table_name` set when present
- **Expected**: Full UCSchemaLocation entity
- **Evidence**: Task Interface Description 1; `UCSchemaLocation` at `/testbed/mlflow/entities/trace_location.py`
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`
- **Obligations**: R10
- **Graph**: E7

### C19: uc_schema_location_from_proto handles missing OTel table names
- **Type**: RETURN_VALUE
- **Subject**: `uc_schema_location_from_proto(proto)` where proto has no otel_spans_table_name
- **Relation**: `HasField('otel_spans_table_name')` is False; attribute not set on entity
- **Expected**: OTel table names only set when present in proto
- **Evidence**: Task Interface Description 1: "optionally sets the OpenTelemetry table names if they are present"; `HasField()` check
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`
- **Obligations**: R10
- **Graph**: E7

### C20: uc_schema_location_to_proto maps all fields including private attrs
- **Type**: RETURN_VALUE
- **Subject**: `uc_schema_location_to_proto(loc)` where loc has _otel_spans_table_name and _otel_logs_table_name set
- **Relation**: `proto.catalog_name == loc.catalog_name`; `proto.schema_name == loc.schema_name`; `proto.otel_spans_table_name == loc._otel_spans_table_name`; `proto.otel_logs_table_name == loc._otel_logs_table_name`
- **Expected**: Full pb.UCSchemaLocation with all four fields
- **Evidence**: Task Interface Description 1; private attributes accessed
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_to_proto`
- **Obligations**: R11
- **Graph**: E6, E9

### C21: Span.inputs returns deserialized input value
- **Type**: RETURN_VALUE
- **Subject**: `span.inputs` where span has INPUTS attribute set to `{"input": 1}`
- **Relation**: Returns `{"input": 1}` (deserialized from JSON)
- **Expected**: Same value that was set via `set_inputs`
- **Evidence**: Test at `/testbed/tests/entities/test_span.py:43` asserts `span.inputs == {"input": 1}`; `SpanAttributeKey.INPUTS = "mlflow.spanInputs"`; `_CachedSpanAttributesRegistry.get` deserializes JSON
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py:Span.inputs`
- **Obligations**: R12
- **Graph**: E13

### C22: Span.inputs returns None when not set
- **Type**: RETURN_VALUE
- **Subject**: `span.inputs` where no INPUTS attribute exists
- **Relation**: Returns None
- **Expected**: None when inputs never set
- **Evidence**: Task Interface Description 3: "Returns None if no inputs were set"
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py:Span.inputs`
- **Obligations**: R12
- **Graph**: E13

### C23: Span.outputs returns deserialized output value
- **Type**: RETURN_VALUE
- **Subject**: `span.outputs` where span has OUTPUTS attribute set to `2`
- **Relation**: Returns `2` (deserialized from JSON)
- **Expected**: Same value that was set via `set_outputs`
- **Evidence**: Test at `/testbed/tests/entities/test_span.py:44` asserts `span.outputs == 2`; `SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"`
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py:Span.outputs`
- **Obligations**: R13
- **Graph**: E13

### C24: Span.outputs returns None when not set
- **Type**: RETURN_VALUE
- **Subject**: `span.outputs` where no OUTPUTS attribute exists
- **Relation**: Returns None
- **Expected**: None when outputs never set
- **Evidence**: Task Interface Description 3: "Returns None if no outputs were set"
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py:Span.outputs`
- **Obligations**: R13
- **Graph**: E13

### C25: AssessmentSourceType._standardize normalizes case
- **Type**: RETURN_VALUE
- **Subject**: `AssessmentSourceType._standardize("human")`
- **Relation**: Returns `"HUMAN"`
- **Expected**: Lowercase/any-case input normalized to uppercase
- **Evidence**: Test at `/testbed/tests/entities/test_assessment_source.py:54-67` tests case insensitivity; Interface Description 2: "Input is case-insensitive but output is always uppercase"
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`
- **Obligations**: R14
- **Graph**: E15, E16

### C26: AssessmentSourceType._standardize handles AI_JUDGE deprecation
- **Type**: SIDE_EFFECT + RETURN_VALUE
- **Subject**: `AssessmentSourceType._standardize("AI_JUDGE")`
- **Relation**: Emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and returns `"LLM_JUDGE"`
- **Expected**: Warning emitted, value converted
- **Evidence**: Test at `/testbed/tests/entities/test_assessment_source.py:71-76` expects FutureWarning; Interface Description 2
- **Observe**: SIDE_EFFECT (warnings.warn) + RETURN_VALUE
- **Target**: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`
- **Obligations**: R14
- **Graph**: E15

### C27: AssessmentSourceType._standardize raises on invalid type
- **Type**: EXCEPTION
- **Subject**: `AssessmentSourceType._standardize("ROBOT")`
- **Relation**: Raises `MlflowException` with `INVALID_PARAMETER_VALUE` error code
- **Expected**: MlflowException with message containing "Invalid assessment source type"
- **Evidence**: Test at `/testbed/tests/entities/test_assessment_source.py:52-53` expects `MlflowException` with match "Invalid assessment source type"; Interface Description 2
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize`
- **Obligations**: R14
- **Graph**: E15

### C28: AssessmentSourceType.__init__ stores parsed value
- **Type**: STATE_READ
- **Subject**: `AssessmentSourceType("llm_judge")` then `str(instance)`
- **Relation**: `str(instance) == "LLM_JUDGE"`
- **Expected**: Constructor stores standardized uppercase value; `__str__` returns it
- **Evidence**: Interface Description 2: "The AssessmentSourceType class must implement an __init__(source_type: str) method that stores the parsed source type value, and a __str__() method that returns the stored source type string"
- **Observe**: STATE_READ (via `__str__`)
- **Target**: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType`
- **Obligations**: R15
- **Graph**: E14, E15

### C29: AssessmentSourceType._parse validates against _SOURCE_TYPES
- **Type**: EXCEPTION
- **Subject**: `AssessmentSourceType._parse("INVALID")`
- **Relation**: Raises `MlflowException` with `INVALID_PARAMETER_VALUE`
- **Expected**: Validation failure for types not in `_SOURCE_TYPES`
- **Evidence**: Interface Description 2: "validates against the _SOURCE_TYPES list, raising MlflowException with INVALID_PARAMETER_VALUE error code for invalid types"
- **Observe**: EXCEPTION
- **Target**: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._parse`
- **Obligations**: R15
- **Graph**: E14

### C30: AssessmentSourceType class constants are simple strings
- **Type**: IMPORT_BOUNDARY
- **Subject**: `AssessmentSourceType.LLM_JUDGE`
- **Relation**: `isinstance(AssessmentSourceType.LLM_JUDGE, str)` and `AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"`
- **Expected**: Constants are plain string values, not dicts
- **Evidence**: Interface Description 2: "The class constants (SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, AI_JUDGE, HUMAN, CODE) should be defined as simple string values, not dictionary structures"; current code at `/testbed/mlflow/entities/assessment_source.py:150-155` already uses simple strings
- **Observe**: IMPORT_BOUNDARY (attribute access)
- **Target**: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType`
- **Obligations**: R15
- **Graph**: N7

### C31: trace_info.py imports trace_info_to_v4_proto
- **Type**: IMPORT_BOUNDARY
- **Subject**: `from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto` in trace_info.py
- **Relation**: Import resolves to the function defined in databricks_tracing_utils.py
- **Expected**: No ImportError at runtime
- **Evidence**: Static issue: `trace_info_to_v4_proto` used at `/testbed/mlflow/entities/trace_info.py:103` but not imported; existing lazy import pattern in `assessment.py`
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/mlflow/entities/trace_info.py`
- **Obligations**: R16
- **Graph**: E1

### C32: trace_location.py imports trace_location_from_proto
- **Type**: IMPORT_BOUNDARY
- **Subject**: `from mlflow.utils.databricks_tracing_utils import trace_location_from_proto` in trace_location.py
- **Relation**: Import resolves to the function defined in databricks_tracing_utils.py
- **Expected**: No ImportError at runtime
- **Evidence**: Static issue: `trace_location_from_proto` used at `/testbed/mlflow/entities/trace_location.py:246` but not imported
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/mlflow/entities/trace_location.py`
- **Obligations**: R16
- **Graph**: E2

### C33: databricks_rest_store.py imports all 5 required functions
- **Type**: IMPORT_BOUNDARY
- **Subject**: Import of `assessment_to_proto`, `trace_from_proto`, `trace_location_to_proto`, `uc_schema_location_from_proto`, `uc_schema_location_to_proto` in databricks_rest_store.py
- **Relation**: All imports resolve to functions in databricks_tracing_utils.py
- **Expected**: No ImportError at runtime
- **Evidence**: Static issue: 5 functions used at `/testbed/mlflow/store/tracking/databricks_rest_store.py` but not imported; test file at `/testbed/tests/store/tracking/test_databricks_rest_store.py:46` already imports `assessment_to_proto, trace_to_proto` from the module
- **Observe**: IMPORT_BOUNDARY
- **Target**: `/testbed/mlflow/store/tracking/databricks_rest_store.py`
- **Obligations**: R16
- **Graph**: E3, E4, E5, E6, E7

### C34: Span.inputs and Span.outputs are read-only properties
- **Type**: FIELD_READ
- **Subject**: `Span.inputs` / `Span.outputs` on immutable Span
- **Relation**: No setter; uses `@property` decorator
- **Expected**: Cannot be assigned (AttributeError on set)
- **Evidence**: Task Interface Description 3: "This is a read-only property for immutable Span objects"; Span docstring: "This Span class represents immutable span data"
- **Observe**: FIELD_READ
- **Target**: `/testbed/mlflow/entities/span.py:Span`
- **Obligations**: R12, R13
- **Graph**: E13
