# Spec Review Report

## Evidence Reviewed

1. **Task Document** (`/testbed`): Primary oracle specifying 16 interfaces across 3 files — 11 functions in `databricks_tracing_utils.py`, 1 class (`AssessmentSourceType` with `_standardize`) in `assessment_source.py`, and 2 properties (`Span.inputs`, `Span.outputs`) in `span.py`.

2. **Semantic IR** (`/agent-logs/.../semantic_ir.md`): 16 requirements (R1–R16), 16 call-graph edges (E1–E16), 34 verifiable contracts (C1–C34), 10 nodes (N1–N10).

3. **Architecture Spec** (`/agent-logs/.../arch_spec.py`): 15 checks covering export surface (C31–C33), caller-binding import resolution (C31–C33, E8), call-graph/dispatch (E1, E2, E9, E10, E11), dataflow (E13), and constructor lifecycle (E14, E15, E16).

4. **Behavior Spec** (`/agent-logs/.../behavior_spec.py`): 36 checks covering assessment_to_proto (C1–C4 + v4), get_trace_id_from_assessment_proto (C5–C7), location converters (C8–C9), trace_from_proto (C10), trace_info_to_v4_proto (C11–C12), trace_location_from_proto (C13–C14), trace_location_to_proto (C16 only — C15 is in arch spec), trace_to_proto (C17), uc_schema_location_from_proto/to_proto (C18–C20), Span.inputs/outputs (C21–C24, C34), AssessmentSourceType (C25–C30).

5. **Static Issues** (`/agent-logs/.../static_issues.md`): 7 unresolved symbols: `trace_info_to_v4_proto` in `trace_info.py`, `trace_location_from_proto` in `trace_location.py`, 5 functions in `databricks_rest_store.py`.

6. **Static Analysis** (`/agent-logs/.../static_analysis.md`): Confirms the same 7 missing imports.

7. **Repository Source Files Examined**:
   - `/testbed/mlflow/utils/databricks_tracing_utils.py` (24 lines, imports only, no functions implemented)
   - `/testbed/mlflow/entities/assessment_source.py` (AssessmentSourceType has constants but lacks `__init__`, `__str__`, `_parse`, `_standardize`)
   - `/testbed/mlflow/entities/span.py` (Span class lacks `inputs`/`outputs` properties; confirmed `hasattr(Span, 'inputs') == False`)
   - `/testbed/mlflow/entities/trace_info.py` (`to_proto()` calls bare `trace_info_to_v4_proto(self)` at line 103; `from_proto()` calls `TraceLocation.from_proto(proto.trace_location)` at line ~140)
   - `/testbed/mlflow/entities/trace_location.py` (`from_proto()` calls bare `trace_location_from_proto(proto)` at line 246)
   - `/testbed/mlflow/store/tracking/databricks_rest_store.py` (calls 5 functions without imports at lines 189, 290, 294, 412, 422, 434, 451, 511, 558)
   - `/testbed/mlflow/entities/assessment.py` (existing `Assessment.to_proto()` pattern for `assessments_pb2`; Feedback/Expectation `.from_proto()` use lazy import of `get_trace_id_from_assessment_proto`)
   - `/testbed/mlflow/tracing/utils/__init__.py` (`parse_trace_id_v4`, `construct_trace_id_v4` confirmed available)
   - `/testbed/mlflow/protos/databricks_tracing_pb2.py` (field listings confirmed for Assessment, TraceInfo, TraceLocation)

8. **Repository Tests Examined**:
   - `/testbed/tests/entities/test_assessment_source.py` — tests `AssessmentSource` construction, case-insensitivity, AI_JUDGE deprecation via `__post_init__` → `_standardize`
   - `/testbed/tests/entities/test_span.py` — tests `span.inputs` / `span.outputs` on both LiveSpan and immutable Span (lines 43–44, 111–112, 117–118, 179–180, 206–207, 245–246, 272–273)
   - `/testbed/tests/entities/test_trace_info.py` — tests `TraceInfo.to_proto()` roundtrip with both v3 and v4 paths, including `TraceLocation.from_proto()` with both `service_pb2.TraceLocation` and `databricks_tracing_pb2.TraceLocation`
   - `/testbed/tests/entities/test_trace_location.py` — tests `TraceLocation.from_proto()` with `service_pb2.TraceLocation`
   - `/testbed/tests/store/tracking/test_databricks_rest_store.py` — line 46 imports `assessment_to_proto, trace_to_proto` from `databricks_tracing_utils`

---

## Rubric Scores

### Seed Rubric: Requirement Coverage
**Score**: PARTIAL. All 16 requirements (R1–R16) and 34 contracts (C1–C34) are traced in the IR and mapped to executable checks in at least one spec. However, C15 (`trace_location_to_proto` dispatch) has no dedicated behavior check — it is tested only in the arch spec (E9), which verifies dispatch but not return-value fidelity for each subtype. See Finding 6.

### Seed Rubric: Requirement Fidelity
**Score**: PARTIAL. Several behavior checks use `HasField()` or `isinstance()` without validating the actual field value, leaving room for plausible wrong implementations to pass. See Findings 1–5.

### Seed Rubric: Caller Binding and Architecture
**Score**: PARTIAL. E1 (TraceInfo.to_proto → trace_info_to_v4_proto) and E2 (TraceLocation.from_proto → trace_location_from_proto) exercise the actual call chain through public entry points. C31–C33 verify function export from the module, but the `databricks_rest_store.py` path (C33/E3–E7) has no equivalent end-to-end call-graph test — the arch spec imports functions directly rather than exercising them through the store class. See Finding 7.

### Seed Rubric: Dataflow and Lifecycle
**Score**: ADEQUATE. C21–C24 verify Span.inputs/outputs dataflow through the attribute registry. E13 verifies the attribute key constants and property existence. E14–E16 verify AssessmentSourceType constructor → _parse and _standardize → AssessmentSource.__post_init__ lifecycle.

### Seed Rubric: Failure and Compatibility
**Score**: ADEQUATE. C16 (ValueError for unsupported trace_location type), C27 (MlflowException for invalid source type), C29 (_parse validation), and C34 (AttributeError on Span property set) cover the primary failure paths. C7 covers dual proto type support for `get_trace_id_from_assessment_proto`. C26 covers AI_JUDGE deprecation warning.

### Seed Rubric: Static-Issue Closure
**Score**: PARTIAL. All 7 static issues are mapped to contracts C31–C33 and graph edges E1–E8. The arch spec checks that the 11 functions are exportable. However, C33 only verifies that the 5 functions can be imported from `databricks_tracing_utils` — it does not verify that `databricks_rest_store.py` (the actual caller file) can resolve them in its module context. See Finding 7.

### Seed Rubric: Repository-Test Alignment
**Score**: ADEQUATE. The behavior spec's Span.inputs/outputs checks (C21–C24, C34) align well with repository tests at `test_span.py` that test `span.inputs` and `span.outputs` return values. The AssessmentSourceType checks (C25–C30) align with `test_assessment_source.py` patterns for case-insensitivity, deprecation warnings, and validation errors. The `trace_to_proto` check (C17) aligns with `test_databricks_rest_store.py:212` usage.

### Seed Rubric: Oracle Strength
**Score**: WEAK in several places. See Findings 1–5 for specific instances where `HasField()` checks replace value assertions, 0-element collections bypass conversion testing, and source content is not verified.

---

## Findings

### Finding 1: weak_constraint — C1 required-fields check does not verify source content

- **Affected IDs**: C1 / R1
- **Static Issue**: None
- **Repository Evidence**: The existing `Assessment.to_proto()` at `/testbed/mlflow/entities/assessment.py:117` populates `assessment.source.CopyFrom(self.source.to_proto())` and the repository test `test_assessment_source.py` verifies source_type and source_id values. The behavior spec's `check_assessment_to_proto_required_fields()` only checks `proto.HasField("source")` — it does not verify `proto.source.source_type` or `proto.source.source_id`. A wrong implementation that sets a default/empty `AssessmentSource` proto would pass.
- **Gap**: No assertion on the actual source_type or source_id in the returned proto.
- **Rework Instruction**: Add assertions in `check_assessment_to_proto_required_fields()`:
  ```python
  _check(proto.source.source_type == "HUMAN", f"Wrong source_type: {proto.source.source_type}")
  _check(proto.source.source_id == "u1", f"Wrong source_id: {proto.source.source_id}")
  ```

### Finding 2: weak_constraint — C1 does not verify trace_location is absent for non-v4 trace IDs

- **Affected IDs**: C1 / R1
- **Static Issue**: None
- **Repository Evidence**: The task interface notes state "The function automatically parses the trace_id to extract location information and constructs the appropriate trace_location proto field for UC Schema locations." The semantics imply trace_location should only be set for v4 UC Schema trace IDs. `check_assessment_to_proto_required_fields()` creates a Feedback with `trace_id="my_trace"` (non-v4) but never checks `proto.trace_location`. A buggy implementation that always populates `trace_location` with a default/empty value would pass all existing checks.
- **Gap**: No check that `trace_location` is NOT set when trace_id is non-v4 format.
- **Rework Instruction**: Add an assertion in `check_assessment_to_proto_required_fields()`:
  ```python
  _check(not proto.HasField("trace_location"), 
         "trace_location should not be set for non-v4 trace_id")
  ```

### Finding 3: weak_constraint — C11 does not check `state` field in trace_info_to_v4_proto output

- **Affected IDs**: C11 / R6
- **Static Issue**: None
- **Repository Evidence**: The IR contract C11 states the proto must have "all fields populated" including `state`. The existing `TraceInfo.to_proto()` at `/testbed/mlflow/entities/trace_info.py:100-120` sets `state=self.state.to_proto()`. The behavior spec's `check_trace_info_to_v4_proto_all_fields()` checks trace_id, client_request_id, request_preview, response_preview, request_time, execution_duration (HasField only), trace_location, trace_metadata count, and tags count — but never checks `proto.state`. The input is `TraceState.OK` — a wrong implementation that always sets `STATE_UNSPECIFIED` would pass.
- **Gap**: Missing assertion for the `state` field value.
- **Rework Instruction**: Add to `check_trace_info_to_v4_proto_all_fields()`:
  ```python
  _check(proto.state == proto.TRACE_STATE_OK or proto.state == 1, 
         f"Expected TRACE_STATE_OK, got {proto.state}")
  ```

### Finding 4: weak_constraint — C11 checks `HasField("execution_duration")` but not its value

- **Affected IDs**: C11 / R6
- **Static Issue**: None
- **Repository Evidence**: The IR contract C11 requires `execution_duration` converted from ms (value 1500). The behavior spec only checks `HasField("execution_duration")` — it does not verify the actual duration in milliseconds. A wrong implementation that hardcodes duration to 0 would pass.
- **Gap**: No value assertion for execution_duration.
- **Rework Instruction**: Add to `check_trace_info_to_v4_proto_all_fields()`:
  ```python
  _check(proto.execution_duration.ToMilliseconds() == 1500,
         f"execution_duration: {proto.execution_duration.ToMilliseconds()}")
  ```

### Finding 5: weak_constraint — C17 trace_to_proto uses 0 spans, bypassing span conversion

- **Affected IDs**: C17 / R9
- **Static Issue**: None
- **Repository Evidence**: The task interface says `trace_to_proto` converts "All spans in the trace data... to OpenTelemetry protobuf format." The repository test at `test_databricks_rest_store.py:212` uses `trace_to_proto(trace)` in a real context. The behavior spec's `check_trace_to_proto_returns_pb_trace()` creates `Trace(info=info, data=TraceData(spans=[]))` and checks `len(proto.spans) == 0`. With zero spans, the critical span-to-OTel-proto conversion path is never exercised. A wrong implementation that ignores spans entirely would pass.
- **Gap**: No test with actual spans.
- **Rework Instruction**: Extend `check_trace_to_proto_returns_pb_trace()` to include at least one span (e.g., a minimal OTelReadableSpan) and verify it appears in `proto.spans` as an OTel protobuf span.

### Finding 6: weak_constraint — C15 (trace_location_to_proto dispatch) has no dedicated behavior check

- **Affected IDs**: C15 / R8
- **Static Issue**: None
- **Repository Evidence**: The arch spec's `check_trace_location_to_proto_dispatches()` (E9) tests dispatch for all 3 types and verifies the subtype fields. However, the behavior spec contains only `check_trace_location_to_proto_raises_valueerror()` (C16) with a section header `# C15-C16: trace_location_to_proto` but no C15 behavior check. The dispatch behavior for the 3 supported types is tested only in the arch spec, which is admissible but reduces behavioral coverage compared to the pattern used for `trace_location_from_proto` (C13 has 3 behavior checks + C14 fallback).
- **Gap**: Missing C15 behavior checks for the three supported location type dispatches, matching the pattern established by C13.
- **Rework Instruction**: Add behavior checks for each of the 3 supported types, mirroring the C13 pattern:
  ```python
  def check_trace_location_to_proto_uc_schema(): ...
  def check_trace_location_to_proto_mlflow_experiment(): ...
  def check_trace_location_to_proto_inference_table(): ...
  ```

### Finding 7: weak_constraint — C33 import check does not verify resolution in the actual caller module context

- **Affected IDs**: C33 / R16
- **Static Issue**: `databricks_rest_store.py` uses 5 functions without imports
- **Repository Evidence**: The static issues document and `test_databricks_rest_store.py:46` confirm that `databricks_rest_store.py` calls `assessment_to_proto`, `trace_from_proto`, `trace_location_to_proto`, `uc_schema_location_from_proto`, `uc_schema_location_to_proto` without importing them. The arch spec's `check_databricks_rest_store_imports_5_functions()` imports all 5 directly from `databricks_tracing_utils` and verifies they are callable — but this only proves the symbols exist in the utils module, not that the store module can resolve them. Unlike E1 and E2 (which exercise the full call chain through TraceInfo.to_proto and TraceLocation.from_proto), there is no end-to-end test that exercises these 5 functions through the `DatabricksTracingRestStore` class.
- **Gap**: No verification that `databricks_rest_store.py` can import and call these functions.
- **Rework Instruction**: Add an arch check that verifies the import statement exists (or, at minimum, that importing `DatabricksTracingRestStore` does not raise ImportError due to missing symbols). Alternatively, exercise one function through a minimal store method invocation.

---

## Decision

**Decision: REWORK**

Seven findings were identified: 0 `missing_requirement`, 7 `weak_constraint`, 0 `requirement_misread`. All findings are addressable by strengthening existing checks with value-level assertions (Findings 1–5), adding a missing behavior dispatch check (Finding 6), and strengthening the caller-binding verification for the store module (Finding 7). No structural redesign is needed — the IR coverage is complete and the spec architecture is sound.
