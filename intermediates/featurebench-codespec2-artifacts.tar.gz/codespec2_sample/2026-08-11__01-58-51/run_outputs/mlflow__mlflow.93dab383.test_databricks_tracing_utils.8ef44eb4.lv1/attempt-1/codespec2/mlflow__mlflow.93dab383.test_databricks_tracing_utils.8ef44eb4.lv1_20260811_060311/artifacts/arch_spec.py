"""
Architecture spec: import/dependency binding, call-chain connectivity,
public scope, and dataflow checks for databricks_tracing_utils, AssessmentSourceType,
and Span.

Each check_* is a no-argument top-level function.  On success it prints
``PASS: <short description>``.  The script runs all checks and exits non-zero
on the first failure.
"""

import sys
import warnings

# ── helpers ──────────────────────────────────────────────────────────────────
_FAILURES = []


def _fail(msg: str) -> None:
    _FAILURES.append(msg)


def _check(condition, msg: str) -> None:
    if not condition:
        _fail(msg)


def _run_all():
    """Discover and execute every top-level ``check_*`` function."""
    import inspect

    mod = sys.modules[__name__]
    funcs = [
        (name, fn)
        for name, fn in inspect.getmembers(mod, inspect.isfunction)
        if name.startswith("check_")
    ]
    for name, fn in funcs:
        try:
            fn()
        except Exception as exc:
            _fail(f"{name} raised {type(exc).__name__}: {exc}")
    if _FAILURES:
        print("\n".join(f"FAIL: {m}" for m in _FAILURES), file=sys.stderr)
        sys.exit(1)
    print("ALL CHECKS PASSED")


# ══════════════════════════════════════════════════════════════════════════════
# Module / export-surface checks
# ══════════════════════════════════════════════════════════════════════════════
# Contracts: C31, C32, C33 — static-issue resolution
# Repo test: databricks_rest_store.py imports from this module in tests
# Lens: import resolution at runtime


def check_module_exists():
    """Verify databricks_tracing_utils module is importable."""
    import mlflow.utils.databricks_tracing_utils as _m
    _check(hasattr(_m, "__name__"), "module has no __name__")
    print("PASS: databricks_tracing_utils module is importable")


def check_all_11_functions_exported():
    """All 11 public functions declared in the IR are importable."""
    from mlflow.utils import databricks_tracing_utils as mod

    required = [
        "assessment_to_proto",
        "get_trace_id_from_assessment_proto",
        "inference_table_location_to_proto",
        "mlflow_experiment_location_to_proto",
        "trace_from_proto",
        "trace_info_to_v4_proto",
        "trace_location_from_proto",
        "trace_location_to_proto",
        "trace_to_proto",
        "uc_schema_location_from_proto",
        "uc_schema_location_to_proto",
    ]
    for name in required:
        obj = getattr(mod, name, None)
        _check(obj is not None, f"{name} not found in databricks_tracing_utils")
        if obj is not None:
            _check(callable(obj), f"{name} is not callable")
    print("PASS: all 11 functions exported from databricks_tracing_utils")


# ══════════════════════════════════════════════════════════════════════════════
# Caller-binding checks — real import paths
# ══════════════════════════════════════════════════════════════════════════════


def check_trace_info_imports_trace_info_to_v4_proto():
    """C31: trace_info.py can resolve trace_info_to_v4_proto at runtime.

    Repo test: none (static issue only)
    Lens: caller-binding import resolution
    Path: mlflow.entities.trace_info → mlflow.utils.databricks_tracing_utils
    """
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    _check(callable(trace_info_to_v4_proto), "trace_info_to_v4_proto not callable")
    print("PASS: trace_info_to_v4_proto importable from databricks_tracing_utils (C31)")


def check_trace_location_imports_trace_location_from_proto():
    """C32: trace_location.py can resolve trace_location_from_proto.

    Repo test: none (static issue only)
    Lens: caller-binding import resolution
    Path: mlflow.entities.trace_location → mlflow.utils.databricks_tracing_utils
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    _check(callable(trace_location_from_proto), "trace_location_from_proto not callable")
    print("PASS: trace_location_from_proto importable from databricks_tracing_utils (C32)")


def check_databricks_rest_store_imports_5_functions():
    """C33: databricks_rest_store.py can resolve all 5 functions.

    Repo test: test_databricks_rest_store.py:46 imports assessment_to_proto, trace_to_proto
    Lens: caller-binding import resolution
    Path: mlflow.store.tracking.databricks_rest_store
    """
    from mlflow.utils.databricks_tracing_utils import (
        assessment_to_proto,
        trace_from_proto,
        trace_location_to_proto,
        uc_schema_location_from_proto,
        uc_schema_location_to_proto,
    )
    _check(callable(assessment_to_proto), "assessment_to_proto not callable")
    _check(callable(trace_from_proto), "trace_from_proto not callable")
    _check(callable(trace_location_to_proto), "trace_location_to_proto not callable")
    _check(callable(uc_schema_location_from_proto), "uc_schema_location_from_proto not callable")
    _check(callable(uc_schema_location_to_proto), "uc_schema_location_to_proto not callable")
    print("PASS: all 5 functions importable for databricks_rest_store (C33)")


def check_databricks_rest_store_class_importable():
    """C33 / Finding 7: databricks_rest_store module itself can be imported
    without ImportError, proving the actual caller module resolves all 5
    required symbols.

    Repo test: test_databricks_rest_store.py imports DatabricksTracingRestStore
    Lens: caller-site import resolution — the store module's own imports must succeed
    Static issue: databricks_rest_store.py uses 5 functions without imports
    Path: mlflow.store.tracking.databricks_rest_store → mlflow.utils.databricks_tracing_utils
    """
    from mlflow.store.tracking.databricks_rest_store import DatabricksTracingRestStore
    _check(DatabricksTracingRestStore is not None,
           "DatabricksTracingRestStore class not importable")
    # Verify the import did not fail due to missing symbols in the module's own scope
    _check(hasattr(DatabricksTracingRestStore, "__name__") or True,
           "DatabricksTracingRestStore import succeeded")
    print("PASS: databricks_rest_store module importable without ImportError (C33/Finding7)")


def check_assessment_imports_get_trace_id_from_assessment_proto():
    """E8: assessment.py lazy-imports get_trace_id_from_assessment_proto.

    Repo test: assessment.py:288,426 uses lazy import pattern
    Lens: caller-binding import resolution
    """
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    _check(callable(get_trace_id_from_assessment_proto), "get_trace_id_from_assessment_proto not callable")
    print("PASS: get_trace_id_from_assessment_proto importable from assessment.py context (E8)")


# ══════════════════════════════════════════════════════════════════════════════
# Call-graph / dispatch checks (real call paths)
# ══════════════════════════════════════════════════════════════════════════════


def check_trace_info_v4_dispatch_calls_trace_info_to_v4_proto():
    """E1: TraceInfo.to_proto() for v4 dispatches to trace_info_to_v4_proto.

    When TraceInfo has a UC Schema location, to_proto() must call
    trace_info_to_v4_proto and return a v4 protobuf.

    Repo test: none direct; inferred from trace_info.py:100-103
    Lens: caller binding — public entry → helper
    Source: /testbed/mlflow/entities/trace_info.py → TraceInfo.to_proto
    """
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation, UCSchemaLocation, TraceLocationType
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos.databricks_tracing_pb2 import TraceInfo as ProtoTraceInfoV4

    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    info = TraceInfo(
        trace_id="trace:/cat.sch/test_trace_id",
        trace_location=loc,
        request_time=1000000,
        state=TraceState.IN_PROGRESS,
    )
    proto = info.to_proto()
    _check(isinstance(proto, ProtoTraceInfoV4), f"Expected v4 proto, got {type(proto)}")
    # The v4 proto must have tags field (v3 doesn't)
    _check(hasattr(proto, "tags"), "v4 proto missing tags field")
    print("PASS: TraceInfo.to_proto dispatches to trace_info_to_v4_proto for v4 (E1)")


def check_trace_location_from_proto_dispatch():
    """E2: TraceLocation.from_proto dispatches to trace_location_from_proto.

    Repo test: none direct; trace_location.py:246 calls bare function
    Lens: caller binding — classmethod → helper
    Source: /testbed/mlflow/entities/trace_location.py → TraceLocation.from_proto
    """
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation
    from mlflow.protos.databricks_tracing_pb2 import (
        MlflowExperimentLocation as PbMlflowExperimentLocation,
    )

    proto = PbTraceLocation()
    proto.type = PbTraceLocation.TRACE_LOCATION_TYPE_MLFLOW_EXPERIMENT
    proto.mlflow_experiment.experiment_id = "exp_123"

    loc = TraceLocation.from_proto(proto)
    _check(loc.type.value == "MLFLOW_EXPERIMENT", f"Unexpected type: {loc.type}")
    _check(loc.mlflow_experiment is not None, "mlflow_experiment not set")
    _check(loc.mlflow_experiment.experiment_id == "exp_123",
           f"Wrong experiment_id: {loc.mlflow_experiment.experiment_id}")
    print("PASS: TraceLocation.from_proto dispatches to trace_location_from_proto (E2)")


def check_trace_to_proto_calls_info_to_proto():
    """E11: trace_to_proto calls trace.info.to_proto() which may be v4.

    Repo test: test_databricks_rest_store.py uses trace_to_proto
    Lens: caller binding — Trace entity → TraceInfo.to_proto dispatch
    Source: /testbed/mlflow/entities/trace.py → Trace.to_proto
    """
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_location import TraceLocation, UCSchemaLocation, TraceLocationType
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos.databricks_tracing_pb2 import Trace as PbTrace

    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    info = TraceInfo(
        trace_id="trace:/cat.sch/test_trace",
        trace_location=loc,
        request_time=1000000,
        state=TraceState.IN_PROGRESS,
    )
    trace = Trace(info=info, data=TraceData(spans=[]))

    proto = trace_to_proto(trace)
    _check(isinstance(proto, PbTrace), f"Expected PbTrace, got {type(proto)}")
    _check(proto.HasField("trace_info"), "trace_info not set")
    _check(len(proto.spans) == 0, "Expected 0 spans")
    print("PASS: trace_to_proto returns PbTrace with trace_info set (E11)")


def check_assessment_to_proto_called_by_trace_info_to_v4_proto():
    """E10: trace_info_to_v4_proto calls assessment_to_proto for assessments.

    Repo test: none direct
    Lens: dataflow — assessments in TraceInfo → assessment_to_proto → proto
    Source: /testbed/mlflow/utils/databricks_tracing_utils.py
    """
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation, UCSchemaLocation, TraceLocationType
    from mlflow.entities.trace_state import TraceState
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_source import AssessmentSource

    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    fb = Feedback(
        value="good",
        trace_id="trace:/cat.sch/test_trace_abc",
        source=AssessmentSource(source_type="HUMAN", source_id="user1"),
    )
    info = TraceInfo(
        trace_id="trace:/cat.sch/test_trace_abc",
        trace_location=loc,
        request_time=1000000,
        state=TraceState.OK,
        assessments=[fb],
    )
    proto = trace_info_to_v4_proto(info)
    _check(len(proto.assessments) == 1, f"Expected 1 assessment, got {len(proto.assessments)}")
    _check(proto.assessments[0].HasField("feedback"), "feedback not set in assessment proto")
    print("PASS: trace_info_to_v4_proto converts assessments via assessment_to_proto (E10)")


def check_trace_location_to_proto_dispatches():
    """E9: trace_location_to_proto dispatches to subtype converters.

    Repo test: none direct
    Lens: dispatch — type-based → uc_schema_location_to_proto / mlflow_experiment / inference_table
    Source: /testbed/mlflow/utils/databricks_tracing_utils.py
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation,
        UCSchemaLocation,
        MlflowExperimentLocation,
        InferenceTableLocation,
        TraceLocationType,
    )

    # UC Schema
    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    proto = trace_location_to_proto(loc)
    _check(proto.HasField("uc_schema"), "UC_SCHEMA: uc_schema field not set")
    _check(proto.uc_schema.catalog_name == "cat", "Wrong catalog_name")
    _check(proto.uc_schema.schema_name == "sch", "Wrong schema_name")

    # MLflow Experiment
    loc2 = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="789"),
    )
    proto2 = trace_location_to_proto(loc2)
    _check(proto2.HasField("mlflow_experiment"), "MLFLOW_EXP: mlflow_experiment not set")
    _check(proto2.mlflow_experiment.experiment_id == "789", "Wrong experiment_id")

    # Inference Table
    loc3 = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="c.s.t"),
    )
    proto3 = trace_location_to_proto(loc3)
    _check(proto3.HasField("inference_table"), "INFERENCE_TABLE: inference_table not set")
    _check(proto3.inference_table.full_table_name == "c.s.t", "Wrong full_table_name")

    print("PASS: trace_location_to_proto dispatches correctly for all 3 types (E9)")


def check_span_inputs_outputs_use_attribute_registry():
    """E13: Span.inputs / Span.outputs read from _CachedSpanAttributesRegistry.

    Repo test: test_span.py (test_create_live_span, test_create_non_live_span)
    Lens: dataflow — property → attribute registry → SpanAttributeKey
    Source: /testbed/mlflow/entities/span.py
    """
    from mlflow.entities.span import Span, LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey

    # Check inputs/outputs exist as properties on Span
    _check(hasattr(Span, "inputs"), "Span missing 'inputs' property")
    _check(hasattr(Span, "outputs"), "Span missing 'outputs' property")

    # Verify they are properties (read-only, not settable)
    span_inputs = getattr(Span, "inputs", None)
    span_outputs = getattr(Span, "outputs", None)
    _check(isinstance(span_inputs, property) or callable(span_inputs),
           "Span.inputs must be a property")
    _check(isinstance(span_outputs, property) or callable(span_outputs),
           "Span.outputs must be a property")

    # Check that LiveSpan has set_inputs/set_outputs (for the write path)
    _check(hasattr(LiveSpan, "set_inputs"), "LiveSpan missing set_inputs")
    _check(hasattr(LiveSpan, "set_outputs"), "LiveSpan missing set_outputs")

    # Verify SpanAttributeKey constants
    _check(SpanAttributeKey.INPUTS == "mlflow.spanInputs", "INPUTS key mismatch")
    _check(SpanAttributeKey.OUTPUTS == "mlflow.spanOutputs", "OUTPUTS key mismatch")

    print("PASS: Span.inputs/outputs use attribute registry (E13)")


def check_assessment_source_post_init_calls_standardize():
    """E16: AssessmentSource.__post_init__ calls AssessmentSourceType._standardize.

    Repo test: test_assessment_source.py
    Lens: lifecycle — dataclass post_init → _standardize → source_type normalized
    Source: /testbed/mlflow/entities/assessment_source.py
    """
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    # lowercase input should be normalized on init
    src = AssessmentSource(source_type="human", source_id="u1")
    _check(src.source_type == "HUMAN", f"Expected HUMAN, got {src.source_type}")
    _check(callable(AssessmentSourceType._standardize), "_standardize not callable")
    print("PASS: AssessmentSource.__post_init__ calls _standardize (E16)")


def check_assessment_source_type_init_calls_parse():
    """E14: AssessmentSourceType.__init__ delegates to _parse.

    Repo test: none direct
    Lens: constructor → static _parse → stored value
    Source: /testbed/mlflow/entities/assessment_source.py
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    _check(hasattr(AssessmentSourceType, "_parse"), "AssessmentSourceType missing _parse")
    _check(callable(AssessmentSourceType._parse), "_parse not callable")

    # Construct and validate
    inst = AssessmentSourceType("llm_judge")
    _check(str(inst) == "LLM_JUDGE", f"Expected LLM_JUDGE, got {str(inst)}")
    print("PASS: AssessmentSourceType.__init__ delegates to _parse (E14)")


def check_assessment_source_type_standardize_creates_instance():
    """E15: _standardize creates an instance, returns str(instance).

    Repo test: test_assessment_source.py tests case insensitivity
    Lens: static method → constructor → __str__
    Source: /testbed/mlflow/entities/assessment_source.py
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    result = AssessmentSourceType._standardize("code")
    _check(result == "CODE", f"Expected CODE, got {result}")
    _check(isinstance(result, str), f"Expected str, got {type(result)}")
    print("PASS: _standardize creates instance and returns __str__ (E15)")


# ══════════════════════════════════════════════════════════════════════════════
# Execution
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    _run_all()
