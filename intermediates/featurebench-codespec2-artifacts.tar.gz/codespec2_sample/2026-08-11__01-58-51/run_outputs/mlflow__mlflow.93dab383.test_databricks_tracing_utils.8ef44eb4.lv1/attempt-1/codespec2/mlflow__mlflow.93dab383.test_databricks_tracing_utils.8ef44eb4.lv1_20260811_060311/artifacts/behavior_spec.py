"""
Behavior spec: return values, field values, types, ordering, defaults,
state transitions, errors, side effects, compatibility, boundary cases.

Each check_* is a no-argument top-level function.  On success it prints
``PASS: <short description>``.  The script runs all checks and exits non-zero
on the first failure.
"""

import sys
import warnings

# ── helpers ──────────────────────────────────────────────────────────────────
_FAILURES = []


def _fail(msg: str) -> None:
    _FAILURES.append(msg)


def _check(condition, msg: str) -> None:
    if not condition:
        _fail(msg)


def _run_all():
    import inspect

    mod = sys.modules[__name__]
    funcs = [
        (name, fn)
        for name, fn in inspect.getmembers(mod, inspect.isfunction)
        if name.startswith("check_")
    ]
    for name, fn in funcs:
        try:
            fn()
        except Exception as exc:
            _fail(f"{name} raised {type(exc).__name__}: {exc}")
    if _FAILURES:
        print("\n".join(f"FAIL: {m}" for m in _FAILURES), file=sys.stderr)
        sys.exit(1)
    print("ALL CHECKS PASSED")


# ══════════════════════════════════════════════════════════════════════════════
# C1-C4: assessment_to_proto behavior
# ══════════════════════════════════════════════════════════════════════════════


def _make_feedback(name="test", value="good", source_type="HUMAN", source_id="u1",
                   trace_id="trace123"):
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_source import AssessmentSource
    return Feedback(
        name=name,
        value=value,
        trace_id=trace_id,
        source=AssessmentSource(source_type=source_type, source_id=source_id),
    )


def _make_expectation(name="exp1", value="expected_val", source_type="HUMAN", source_id="u1",
                      trace_id="trace123"):
    from mlflow.entities.assessment import Expectation
    from mlflow.entities.assessment_source import AssessmentSource
    return Expectation(
        name=name,
        value=value,
        trace_id=trace_id,
        source=AssessmentSource(source_type=source_type, source_id=source_id),
    )


def check_assessment_to_proto_required_fields():
    """C1: assessment_to_proto sets required fields.

    Repo test: none direct; pattern from Assessment.to_proto()
    Lens: representation — proto must have all required fields populated
    Source: mlflow.utils.databricks_tracing_utils.assessment_to_proto
    """
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from google.protobuf.timestamp_pb2 import Timestamp

    fb = _make_feedback(name="correctness", value="good", trace_id="my_trace")
    proto = assessment_to_proto(fb)

    _check(proto.assessment_name == "correctness",
           f"Wrong name: {proto.assessment_name}")
    _check(proto.trace_id == "my_trace",
           f"Wrong trace_id: {proto.trace_id}")
    _check(proto.HasField("source"), "source not set")
    _check(proto.HasField("create_time"), "create_time not set")
    _check(proto.HasField("last_update_time"), "last_update_time not set")

    # Verify timestamps are protobuf Timestamps
    assert isinstance(proto.create_time, type(Timestamp()))

    # Verify create_time roughly matches now (within a few ms)
    import time
    ts_ms = proto.create_time.ToMilliseconds()
    now_ms = int(time.time() * 1000)
    _check(abs(now_ms - ts_ms) < 60000,  # within 1 minute
           f"create_time too far from now: delta={abs(now_ms - ts_ms)}ms")

    # C1 / Finding 1: trace_location should NOT be set for non-v4 trace_id
    _check(not proto.HasField("trace_location"),
           "trace_location should not be set for non-v4 trace_id")

    print("PASS: assessment_to_proto sets all required fields (C1)")


def check_assessment_to_proto_optional_fields_none():
    """C2: assessment_to_proto only sets optional fields when non-None.

    Repo test: none direct
    Lens: optionality — None fields left unset in proto
    Source: mlflow.utils.databricks_tracing_utils.assessment_to_proto
    """
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_source import AssessmentSource

    fb = Feedback(
        name="basic",
        value="ok",
        source=AssessmentSource(source_type="CODE"),
        trace_id="t1",
        span_id=None,
        rationale=None,
        assessment_id=None,
        overrides=None,
        valid=None,
    )
    proto = assessment_to_proto(fb)
    _check(not proto.HasField("span_id") or proto.span_id == "",
           "span_id should not be set when None")
    _check(not proto.HasField("rationale") or proto.rationale == "",
           "rationale should not be set when None")
    _check(not proto.HasField("assessment_id") or proto.assessment_id == "",
           "assessment_id should not be set when None")
    _check(not proto.HasField("overrides") or proto.overrides == "",
           "overrides should not be set when None")
    print("PASS: assessment_to_proto skips None optional fields (C2)")


def check_assessment_to_proto_optional_fields_present():
    """C2 (continued): when optional fields are set, they appear in proto.

    Lens: optionality — non-None fields propagated
    """
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_source import AssessmentSource

    fb = Feedback(
        name="full",
        value="ok",
        source=AssessmentSource(source_type="CODE"),
        trace_id="t1",
        span_id="span_abc",
        rationale="because",
        overrides="old_assess_id",
        valid=True,
    )
    proto = assessment_to_proto(fb)
    _check(proto.span_id == "span_abc", f"span_id: {proto.span_id}")
    _check(proto.rationale == "because", f"rationale: {proto.rationale}")
    _check(proto.overrides == "old_assess_id", f"overrides: {proto.overrides}")
    _check(proto.valid is True, f"valid: {proto.valid}")
    print("PASS: assessment_to_proto propagates non-None optional fields (C2)")


def check_assessment_to_proto_expectation_not_feedback():
    """C3: assessment_to_proto sets expectation XOR feedback, not both.

    Repo test: none direct
    Lens: oneof — WhichOneof('value') returns correct discriminator
    """
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    exp = _make_expectation(name="e", value="expected")
    proto = assessment_to_proto(exp)
    which = proto.WhichOneof("value")
    _check(which == "expectation", f"Expected 'expectation', got {which}")
    _check(proto.HasField("expectation"), "expectation not set")
    _check(not proto.HasField("feedback"), "feedback should not be set")

    fb = _make_feedback(name="f", value="nice")
    proto2 = assessment_to_proto(fb)
    which2 = proto2.WhichOneof("value")
    _check(which2 == "feedback", f"Expected 'feedback', got {which2}")
    _check(not proto2.HasField("expectation"), "expectation should not be set")
    _check(proto2.HasField("feedback"), "feedback not set")
    print("PASS: assessment_to_proto sets exactly one of expectation/feedback (C3)")


def check_assessment_to_proto_metadata_stringified():
    """C4: assessment_to_proto converts metadata values to strings.

    Repo test: none direct
    Lens: type conversion — metadata values must be str
    """
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_source import AssessmentSource

    fb = Feedback(
        value="ok",
        source=AssessmentSource(source_type="CODE"),
        trace_id="t1",
        metadata={"int_val": 42, "float_val": 3.14, "bool_val": True, "str_val": "hello"},
    )
    proto = assessment_to_proto(fb)
    md = dict(proto.metadata)
    _check(md["int_val"] == "42", f"int_val not stringified: {md['int_val']}")
    _check(md["float_val"] == "3.14", f"float_val not stringified: {md['float_val']}")
    _check(md["bool_val"] == "True", f"bool_val not stringified: {md['bool_val']}")
    _check(md["str_val"] == "hello", f"str_val changed: {md['str_val']}")
    print("PASS: assessment_to_proto stringifies metadata values (C4)")


def check_assessment_to_proto_trace_location_v4():
    """C1 (v4): assessment_to_proto sets trace_location for v4 trace_ids.

    Lens: trace_location extraction
    """
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    fb = _make_feedback(trace_id="trace:/cat.sch/inner_trace")
    proto = assessment_to_proto(fb)
    _check(proto.HasField("trace_location"), "trace_location not set for v4 trace_id")
    _check(proto.trace_location.HasField("uc_schema"), "uc_schema not set in trace_location")
    _check(proto.trace_location.uc_schema.catalog_name == "cat", "wrong catalog")
    _check(proto.trace_location.uc_schema.schema_name == "sch", "wrong schema")

    # C1 / Finding 2: verify the inner trace_id is the raw trace_id (not the v4 URI)
    _check(proto.trace_id == "inner_trace",
           f"Expected inner trace_id 'inner_trace', got {proto.trace_id!r}")

    print("PASS: assessment_to_proto sets trace_location for v4 trace_id (C1 v4)")


# ══════════════════════════════════════════════════════════════════════════════
# C5-C7: get_trace_id_from_assessment_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_get_trace_id_from_assessment_proto_uc_schema():
    """C5: get_trace_id_from_assessment_proto returns v4 trace_id for UC Schema.

    Repo test: none direct
    Lens: compatibility — combines location + trace_id for UC
    """
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.Assessment()
    proto.trace_id = "inner123"
    proto.trace_location.uc_schema.catalog_name = "cat"
    proto.trace_location.uc_schema.schema_name = "sch"

    result = get_trace_id_from_assessment_proto(proto)
    expected = "trace:/cat.sch/inner123"
    _check(result == expected, f"Expected {expected!r}, got {result!r}")
    print("PASS: get_trace_id_from_assessment_proto v4 for UC Schema (C5)")


def check_get_trace_id_from_assessment_proto_no_uc_schema():
    """C6: get_trace_id_from_assessment_proto returns raw trace_id without UC Schema.

    Lens: direct passthrough
    """
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.Assessment()
    proto.trace_id = "plain_trace_42"
    # no trace_location set

    result = get_trace_id_from_assessment_proto(proto)
    _check(result == "plain_trace_42", f"Expected 'plain_trace_42', got {result!r}")
    print("PASS: get_trace_id_from_assessment_proto returns raw trace_id (C6)")


def check_get_trace_id_from_assessment_proto_v4_no_location():
    """C6 variant: v4 trace_id without trace_location returns raw value."""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    proto = pb.Assessment()
    proto.trace_id = "trace:/cat.sch/abc"
    # trace_location not set — should still return raw

    result = get_trace_id_from_assessment_proto(proto)
    _check(result == "trace:/cat.sch/abc", f"Got {result!r}")
    print("PASS: get_trace_id_from_assessment_proto raw when no trace_location set (C6)")


def check_get_trace_id_from_assessment_proto_assessments_pb2():
    """C7: get_trace_id_from_assessment_proto works with assessments_pb2.Assessment.

    assessments_pb2.Assessment has no trace_location field.
    Lens: compatibility — dual proto type support
    """
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos.assessments_pb2 import Assessment as ProtoAssessment

    proto = ProtoAssessment()
    proto.trace_id = "legacy_trace"

    result = get_trace_id_from_assessment_proto(proto)
    _check(result == "legacy_trace", f"Expected 'legacy_trace', got {result!r}")
    print("PASS: get_trace_id_from_assessment_proto works with assessments_pb2 (C7)")


# ══════════════════════════════════════════════════════════════════════════════
# C8-C9: location entity → proto converters
# ══════════════════════════════════════════════════════════════════════════════


def check_inference_table_location_to_proto():
    """C8: inference_table_location_to_proto maps full_table_name.

    Repo test: none direct
    Lens: representation — field mapping
    """
    from mlflow.utils.databricks_tracing_utils import inference_table_location_to_proto
    from mlflow.entities.trace_location import InferenceTableLocation

    loc = InferenceTableLocation(full_table_name="catalog.schema.table")
    proto = inference_table_location_to_proto(loc)
    _check(proto.full_table_name == "catalog.schema.table",
           f"Wrong full_table_name: {proto.full_table_name}")
    print("PASS: inference_table_location_to_proto maps full_table_name (C8)")


def check_mlflow_experiment_location_to_proto():
    """C9: mlflow_experiment_location_to_proto maps experiment_id.

    Lens: representation — field mapping
    """
    from mlflow.utils.databricks_tracing_utils import mlflow_experiment_location_to_proto
    from mlflow.entities.trace_location import MlflowExperimentLocation

    loc = MlflowExperimentLocation(experiment_id="exp_456")
    proto = mlflow_experiment_location_to_proto(loc)
    _check(proto.experiment_id == "exp_456",
           f"Wrong experiment_id: {proto.experiment_id}")
    print("PASS: mlflow_experiment_location_to_proto maps experiment_id (C9)")


# ══════════════════════════════════════════════════════════════════════════════
# C10: trace_from_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_trace_from_proto_basic():
    """C10: trace_from_proto returns valid Trace with info and spans.

    Repo test: databricks_rest_store.py:189 calls this in batch get
    Lens: roundtrip — proto → Trace entity
    """
    from mlflow.utils.databricks_tracing_utils import trace_from_proto
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_data import TraceData
    from mlflow.protos.databricks_tracing_pb2 import Trace as PbTrace
    from mlflow.protos.databricks_tracing_pb2 import TraceInfo as PbTraceInfo
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation
    from google.protobuf.timestamp_pb2 import Timestamp
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    ts = Timestamp()
    ts.FromMilliseconds(1000000)

    pb_info = PbTraceInfo()
    pb_info.trace_id = "plain_trace"
    pb_info.request_time.CopyFrom(ts)
    pb_info.state = PbTraceInfo.TRACE_STATE_OK
    pb_info.trace_location.type = PbTraceLocation.TRACE_LOCATION_TYPE_MLFLOW_EXPERIMENT
    pb_info.trace_location.mlflow_experiment.experiment_id = "exp_1"

    otel_span = OTelProtoSpan()
    otel_span.name = "my_span"
    otel_span.trace_id = b'\x00' * 16
    otel_span.span_id = b'\x00' * 8
    otel_span.start_time_unix_nano = 1000
    otel_span.end_time_unix_nano = 2000

    pb_trace = PbTrace()
    pb_trace.trace_info.CopyFrom(pb_info)
    pb_trace.spans.append(otel_span)

    result = trace_from_proto(pb_trace, location_id="cat.sch")
    _check(isinstance(result, Trace), f"Expected Trace, got {type(result)}")
    _check(isinstance(result.info, TraceInfo), f"Expected TraceInfo, got {type(result.info)}")
    _check(isinstance(result.data, TraceData), f"Expected TraceData, got {type(result.data)}")
    _check(len(result.data.spans) == 1, f"Expected 1 span, got {len(result.data.spans)}")
    print("PASS: trace_from_proto returns valid Trace entity (C10)")


# ══════════════════════════════════════════════════════════════════════════════
# C11-C12: trace_info_to_v4_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_trace_info_to_v4_proto_all_fields():
    """C11: trace_info_to_v4_proto sets all fields including parsed trace_id.

    Repo test: none direct
    Lens: full conversion — v4 format, timestamps, location, tags, assessments
    """
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation, UCSchemaLocation, TraceLocationType
    from mlflow.entities.trace_state import TraceState

    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    info = TraceInfo(
        trace_id="trace:/cat.sch/inner_id",
        trace_location=loc,
        request_time=5000000,
        state=TraceState.OK,
        client_request_id="cli_1",
        request_preview='{"q": "hi"}',
        response_preview='{"a": "hello"}',
        execution_duration=1500,
        trace_metadata={"k1": "v1"},
        tags={"tag1": "val1"},
    )

    proto = trace_info_to_v4_proto(info)

    # Inner trace ID (parsed from v4)
    _check(proto.trace_id == "inner_id",
           f"Expected inner trace_id 'inner_id', got {proto.trace_id!r}")
    _check(proto.client_request_id == "cli_1", "client_request_id mismatch")
    _check(proto.request_preview == '{"q": "hi"}', "request_preview mismatch")
    _check(proto.response_preview == '{"a": "hello"}', "response_preview mismatch")
    _check(proto.HasField("request_time"), "request_time not set")
    _check(proto.request_time.ToMilliseconds() == 5000000,
           f"request_time: {proto.request_time.ToMilliseconds()}")

    # C11 / Finding 4: verify execution_duration value, not just HasField
    _check(proto.HasField("execution_duration"), "execution_duration not set")
    _check(proto.execution_duration.ToMilliseconds() == 1500,
           f"execution_duration: {proto.execution_duration.ToMilliseconds()}")

    # C11 / Finding 3: verify state field
    _check(proto.HasField("state"), "state not set")
    _check(proto.state == proto.TRACE_STATE_OK or proto.state == 1,
           f"Expected TRACE_STATE_OK, got {proto.state}")

    _check(proto.HasField("trace_location"), "trace_location not set")
    _check(proto.trace_location.HasField("uc_schema"), "uc_schema not set in trace_location")
    _check(len(proto.trace_metadata) == 1, "trace_metadata count mismatch")
    _check(len(proto.tags) == 1, "tags count mismatch")
    print("PASS: trace_info_to_v4_proto sets all fields correctly (C11)")


def check_trace_info_to_v4_proto_no_execution_duration():
    """C12: trace_info_to_v4_proto skips execution_duration when None.

    Lens: optionality — not set when None
    """
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation, UCSchemaLocation, TraceLocationType
    from mlflow.entities.trace_state import TraceState

    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    info = TraceInfo(
        trace_id="trace:/cat.sch/abc",
        trace_location=loc,
        request_time=1000000,
        state=TraceState.IN_PROGRESS,
        execution_duration=None,
    )
    proto = trace_info_to_v4_proto(info)
    _check(not proto.HasField("execution_duration"),
           "execution_duration should not be set when None")
    print("PASS: trace_info_to_v4_proto skips execution_duration when None (C12)")


# ══════════════════════════════════════════════════════════════════════════════
# C13-C14: trace_location_from_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_trace_location_from_proto_uc_schema():
    """C13: trace_location_from_proto returns UC_SCHEMA location.

    Lens: dispatch — uc_schema identifier → UCSchemaLocation
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation

    proto = PbTraceLocation()
    proto.type = PbTraceLocation.TRACE_LOCATION_TYPE_UC_SCHEMA
    proto.uc_schema.catalog_name = "cat"
    proto.uc_schema.schema_name = "sch"

    loc = trace_location_from_proto(proto)
    _check(loc.type.value == "UC_SCHEMA", f"Wrong type: {loc.type}")
    _check(loc.uc_schema is not None, "uc_schema not set")
    _check(loc.uc_schema.catalog_name == "cat", f"catalog: {loc.uc_schema.catalog_name}")
    _check(loc.uc_schema.schema_name == "sch", f"schema: {loc.uc_schema.schema_name}")
    print("PASS: trace_location_from_proto returns UC_SCHEMA (C13)")


def check_trace_location_from_proto_mlflow_experiment():
    """C13 (cont): mlflow_experiment dispatch."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation

    proto = PbTraceLocation()
    proto.type = PbTraceLocation.TRACE_LOCATION_TYPE_MLFLOW_EXPERIMENT
    proto.mlflow_experiment.experiment_id = "exp_42"

    loc = trace_location_from_proto(proto)
    _check(loc.type.value == "MLFLOW_EXPERIMENT", f"Wrong type: {loc.type}")
    _check(loc.mlflow_experiment is not None, "mlflow_experiment not set")
    _check(loc.mlflow_experiment.experiment_id == "exp_42", "experiment_id mismatch")
    print("PASS: trace_location_from_proto returns MLFLOW_EXPERIMENT (C13)")


def check_trace_location_from_proto_inference_table():
    """C13 (cont): inference_table dispatch."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation

    proto = PbTraceLocation()
    proto.type = PbTraceLocation.TRACE_LOCATION_TYPE_INFERENCE_TABLE
    proto.inference_table.full_table_name = "c.s.t"

    loc = trace_location_from_proto(proto)
    _check(loc.type.value == "INFERENCE_TABLE", f"Wrong type: {loc.type}")
    _check(loc.inference_table is not None, "inference_table not set")
    _check(loc.inference_table.full_table_name == "c.s.t", "full_table_name mismatch")
    print("PASS: trace_location_from_proto returns INFERENCE_TABLE (C13)")


def check_trace_location_from_proto_unspecified():
    """C14: trace_location_from_proto falls back to UNSPECIFIED.

    Lens: fallback — no identifier → TRACE_LOCATION_TYPE_UNSPECIFIED
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation

    proto = PbTraceLocation()
    # no identifier field set

    loc = trace_location_from_proto(proto)
    _check(loc.type.value == "TRACE_LOCATION_TYPE_UNSPECIFIED",
           f"Expected UNSPECIFIED, got {loc.type.value}")
    print("PASS: trace_location_from_proto falls back to UNSPECIFIED (C14)")


# ══════════════════════════════════════════════════════════════════════════════
# C15-C16: trace_location_to_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_trace_location_to_proto_uc_schema():
    """C15: trace_location_to_proto returns proto with uc_schema for UC_SCHEMA type.

    Repo test: none direct (inferred from databricks_rest_store.py:412,434,451)
    Lens: dispatch — UC_SCHEMA type → pb.TraceLocation with uc_schema field
    Source: mlflow.utils.databricks_tracing_utils.trace_location_to_proto
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation, UCSchemaLocation, TraceLocationType,
    )
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation

    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="my_cat", schema_name="my_sch"),
    )
    proto = trace_location_to_proto(loc)
    _check(isinstance(proto, PbTraceLocation),
           f"Expected PbTraceLocation, got {type(proto)}")
    _check(proto.type == PbTraceLocation.TRACE_LOCATION_TYPE_UC_SCHEMA,
           f"Wrong type: {proto.type}")
    _check(proto.HasField("uc_schema"), "uc_schema field not set")
    _check(proto.uc_schema.catalog_name == "my_cat",
           f"catalog_name: {proto.uc_schema.catalog_name}")
    _check(proto.uc_schema.schema_name == "my_sch",
           f"schema_name: {proto.uc_schema.schema_name}")
    print("PASS: trace_location_to_proto returns UC_SCHEMA proto (C15)")


def check_trace_location_to_proto_mlflow_experiment():
    """C15 (cont): trace_location_to_proto returns proto with mlflow_experiment.

    Lens: dispatch — MLFLOW_EXPERIMENT type → pb.TraceLocation with mlflow_experiment
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation, MlflowExperimentLocation, TraceLocationType,
    )
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation

    loc = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="exp_999"),
    )
    proto = trace_location_to_proto(loc)
    _check(isinstance(proto, PbTraceLocation),
           f"Expected PbTraceLocation, got {type(proto)}")
    _check(proto.type == PbTraceLocation.TRACE_LOCATION_TYPE_MLFLOW_EXPERIMENT,
           f"Wrong type: {proto.type}")
    _check(proto.HasField("mlflow_experiment"), "mlflow_experiment field not set")
    _check(proto.mlflow_experiment.experiment_id == "exp_999",
           f"experiment_id: {proto.mlflow_experiment.experiment_id}")
    print("PASS: trace_location_to_proto returns MLFLOW_EXPERIMENT proto (C15)")


def check_trace_location_to_proto_inference_table():
    """C15 (cont): trace_location_to_proto returns proto with inference_table.

    Lens: dispatch — INFERENCE_TABLE type → pb.TraceLocation with inference_table
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation, InferenceTableLocation, TraceLocationType,
    )
    from mlflow.protos.databricks_tracing_pb2 import TraceLocation as PbTraceLocation

    loc = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="cat.sch.tbl"),
    )
    proto = trace_location_to_proto(loc)
    _check(isinstance(proto, PbTraceLocation),
           f"Expected PbTraceLocation, got {type(proto)}")
    _check(proto.type == PbTraceLocation.TRACE_LOCATION_TYPE_INFERENCE_TABLE,
           f"Wrong type: {proto.type}")
    _check(proto.HasField("inference_table"), "inference_table field not set")
    _check(proto.inference_table.full_table_name == "cat.sch.tbl",
           f"full_table_name: {proto.inference_table.full_table_name}")
    print("PASS: trace_location_to_proto returns INFERENCE_TABLE proto (C15)")


def check_trace_location_to_proto_raises_valueerror():
    """C16: trace_location_to_proto raises ValueError for unsupported type.

    Lens: failure — unsupported type raises ValueError
    """
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import TraceLocation, TraceLocationType

    # Create a TraceLocation with only type, no subtype
    loc = TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)

    try:
        trace_location_to_proto(loc)
        _fail("Expected ValueError for unsupported type")
    except ValueError:
        pass  # expected
    print("PASS: trace_location_to_proto raises ValueError for unsupported type (C16)")


# ══════════════════════════════════════════════════════════════════════════════
# C17: trace_to_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_trace_to_proto_returns_pb_trace():
    """C17: trace_to_proto returns pb.Trace with info and spans.

    Repo test: test_databricks_rest_store.py:212
    Lens: representation — full Trace → proto, including span conversion

    C17 / Finding 5: includes at least one span to exercise the span-to-OTel-proto
    conversion path, ensuring a wrong implementation that ignores spans would fail.
    """
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_location import TraceLocation, UCSchemaLocation, TraceLocationType
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos.databricks_tracing_pb2 import Trace as PbTrace
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    loc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
    )
    info = TraceInfo(
        trace_id="trace:/cat.sch/xyz",
        trace_location=loc,
        request_time=1000000,
        state=TraceState.OK,
    )

    # Create a minimal OTel proto span to exercise span conversion
    otel_span = OTelProtoSpan()
    otel_span.name = "test_span"
    otel_span.trace_id = b'\x01' * 16
    otel_span.span_id = b'\x02' * 8
    otel_span.start_time_unix_nano = 1000
    otel_span.end_time_unix_nano = 2000

    # Build a Span entity from the OTel proto span via from_otel_proto
    from mlflow.entities.span import Span
    span = Span.from_otel_proto(otel_span, location_id="cat.sch")

    trace = Trace(info=info, data=TraceData(spans=[span]))

    proto = trace_to_proto(trace)
    _check(isinstance(proto, PbTrace), f"Expected PbTrace, got {type(proto)}")
    _check(proto.HasField("trace_info"), "trace_info not set")

    # C17 / Finding 5: verify the span was actually converted to OTel proto
    _check(len(proto.spans) == 1, f"Expected 1 span in proto, got {len(proto.spans)}")
    _check(proto.spans[0].name == "test_span",
           f"Expected span name 'test_span', got {proto.spans[0].name!r}")
    print("PASS: trace_to_proto returns pb.Trace with info and spans (C17)")


# ══════════════════════════════════════════════════════════════════════════════
# C18-C19: uc_schema_location_from_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_uc_schema_location_from_proto_all_fields():
    """C18: uc_schema_location_from_proto maps all fields.

    Lens: representation — full entity reconstruction
    """
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import UCSchemaLocation as PbUCSchema

    proto = PbUCSchema()
    proto.catalog_name = "my_cat"
    proto.schema_name = "my_sch"
    proto.otel_spans_table_name = "spans_table"
    proto.otel_logs_table_name = "logs_table"

    loc = uc_schema_location_from_proto(proto)
    _check(loc.catalog_name == "my_cat", f"catalog_name: {loc.catalog_name}")
    _check(loc.schema_name == "my_sch", f"schema_name: {loc.schema_name}")
    _check(loc._otel_spans_table_name == "spans_table",
           f"_otel_spans_table_name: {loc._otel_spans_table_name}")
    _check(loc._otel_logs_table_name == "logs_table",
           f"_otel_logs_table_name: {loc._otel_logs_table_name}")
    print("PASS: uc_schema_location_from_proto maps all fields (C18)")


def check_uc_schema_location_from_proto_missing_otel_tables():
    """C19: uc_schema_location_from_proto handles missing OTel table names.

    Lens: optionality — OTel table names only set when present
    """
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.protos.databricks_tracing_pb2 import UCSchemaLocation as PbUCSchema

    proto = PbUCSchema()
    proto.catalog_name = "cat2"
    proto.schema_name = "sch2"
    # otel_spans_table_name and otel_logs_table_name not set

    loc = uc_schema_location_from_proto(proto)
    _check(loc.catalog_name == "cat2", f"catalog_name: {loc.catalog_name}")
    _check(loc.schema_name == "sch2", f"schema_name: {loc.schema_name}")
    # Defaults from the entity should be preserved
    _check(loc._otel_spans_table_name is not None,
           "_otel_spans_table_name should have default value")
    print("PASS: uc_schema_location_from_proto handles missing OTel table names (C19)")


# ══════════════════════════════════════════════════════════════════════════════
# C20: uc_schema_location_to_proto
# ══════════════════════════════════════════════════════════════════════════════


def check_uc_schema_location_to_proto_all_fields():
    """C20: uc_schema_location_to_proto maps all fields including private attrs.

    Lens: representation — entity → proto including private _otel_* attrs
    """
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto
    from mlflow.entities.trace_location import UCSchemaLocation

    loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    loc._otel_spans_table_name = "custom_spans"
    loc._otel_logs_table_name = "custom_logs"

    proto = uc_schema_location_to_proto(loc)
    _check(proto.catalog_name == "cat", f"catalog_name: {proto.catalog_name}")
    _check(proto.schema_name == "sch", f"schema_name: {proto.schema_name}")
    _check(proto.otel_spans_table_name == "custom_spans",
           f"otel_spans_table_name: {proto.otel_spans_table_name}")
    _check(proto.otel_logs_table_name == "custom_logs",
           f"otel_logs_table_name: {proto.otel_logs_table_name}")
    print("PASS: uc_schema_location_to_proto maps all fields (C20)")


# ══════════════════════════════════════════════════════════════════════════════
# C21-C24, C34: Span.inputs / Span.outputs
# ══════════════════════════════════════════════════════════════════════════════


def _create_readable_span(attributes=None):
    from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    from opentelemetry.trace import SpanContext, TraceFlags

    ctx = SpanContext(
        trace_id=12345, span_id=222, is_remote=False,
        trace_flags=TraceFlags(TraceFlags.SAMPLED)
    )
    if attributes is None:
        attributes = {}
    return OTelReadableSpan(
        name="test",
        context=ctx,
        parent=None,
        attributes=attributes,
        start_time=1000,
        end_time=2000,
    )


def check_span_inputs_returns_value():
    """C21: Span.inputs returns deserialized input value.

    Repo test: test_span.py:43-44
    Lens: representation — attribute deserialization
    """
    import json
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-1"),
        SpanAttributeKey.INPUTS: dump_span_attribute_value({"input": 1, "nested": {"foo": "bar"}}),
    }
    otel = _create_readable_span(attrs)
    span = Span(otel)

    result = span.inputs
    _check(result == {"input": 1, "nested": {"foo": "bar"}},
           f"inputs mismatch: {result}")
    print("PASS: Span.inputs returns deserialized value (C21)")


def check_span_inputs_returns_none():
    """C22: Span.inputs returns None when not set.

    Lens: default — None when attribute absent
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-2"),
        # No INPUTS attribute
    }
    otel = _create_readable_span(attrs)
    span = Span(otel)

    result = span.inputs
    _check(result is None, f"Expected None, got {result!r}")
    print("PASS: Span.inputs returns None when not set (C22)")


def check_span_outputs_returns_value():
    """C23: Span.outputs returns deserialized output value.

    Repo test: test_span.py:43-44
    Lens: representation — attribute deserialization
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-3"),
        SpanAttributeKey.OUTPUTS: dump_span_attribute_value(2),
    }
    otel = _create_readable_span(attrs)
    span = Span(otel)

    result = span.outputs
    _check(result == 2, f"outputs mismatch: {result}")
    print("PASS: Span.outputs returns deserialized value (C23)")


def check_span_outputs_returns_none():
    """C24: Span.outputs returns None when not set.

    Lens: default — None when attribute absent
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-4"),
        # No OUTPUTS attribute
    }
    otel = _create_readable_span(attrs)
    span = Span(otel)

    result = span.outputs
    _check(result is None, f"Expected None, got {result!r}")
    print("PASS: Span.outputs returns None when not set (C24)")


def check_span_inputs_outputs_read_only():
    """C34: Span.inputs and Span.outputs are read-only properties.

    Lens: immutability — AttributeError on set
    """
    from mlflow.entities.span import Span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.utils import dump_span_attribute_value

    attrs = {
        SpanAttributeKey.REQUEST_ID: dump_span_attribute_value("tr-5"),
        SpanAttributeKey.INPUTS: dump_span_attribute_value({"x": 1}),
        SpanAttributeKey.OUTPUTS: dump_span_attribute_value(42),
    }
    otel = _create_readable_span(attrs)
    span = Span(otel)

    # Attempting to set inputs/outputs on immutable Span must raise
    try:
        span.inputs = {"new": "val"}
        _fail("Setting Span.inputs should raise AttributeError")
    except AttributeError:
        pass  # expected

    try:
        span.outputs = "new_output"
        _fail("Setting Span.outputs should raise AttributeError")
    except AttributeError:
        pass  # expected

    print("PASS: Span.inputs/outputs are read-only (C34)")


# ══════════════════════════════════════════════════════════════════════════════
# C25-C30: AssessmentSourceType behavior
# ══════════════════════════════════════════════════════════════════════════════


def check_assessment_source_type_standardize_normalizes_case():
    """C25: _standardize normalizes case (any case → uppercase).

    Repo test: test_assessment_source.py:54-67
    Lens: normalization — case-insensitive input
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    _check(AssessmentSourceType._standardize("human") == "HUMAN", "human")
    _check(AssessmentSourceType._standardize("Human") == "HUMAN", "Human")
    _check(AssessmentSourceType._standardize("HUMAN") == "HUMAN", "HUMAN")
    _check(AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE", "llm_judge")
    _check(AssessmentSourceType._standardize("Llm_Judge") == "LLM_JUDGE", "Llm_Judge")
    _check(AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE", "LLM_JUDGE")
    _check(AssessmentSourceType._standardize("code") == "CODE", "code")
    _check(AssessmentSourceType._standardize("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED",
           "source_type_unspecified")
    print("PASS: _standardize normalizes case (C25)")


def check_assessment_source_type_standardize_ai_judge_deprecation():
    """C26: _standardize emits FutureWarning and returns LLM_JUDGE for AI_JUDGE.

    Repo test: test_assessment_source.py:71-76
    Lens: deprecation — side effect + value replacement
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._standardize("AI_JUDGE")
        _check(result == "LLM_JUDGE", f"Expected LLM_JUDGE, got {result}")
        _check(len(w) >= 1, "Expected at least one warning")
        future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        _check(len(future_warnings) >= 1, "Expected a FutureWarning")
        msg = str(future_warnings[0].message)
        _check("AI_JUDGE" in msg and "deprecated" in msg.lower(),
               f"Warning message should mention AI_JUDGE deprecation: {msg}")
    print("PASS: _standardize handles AI_JUDGE deprecation (C26)")


def check_assessment_source_type_standardize_raises_invalid():
    """C27: _standardize raises MlflowException for invalid type.

    Repo test: test_assessment_source.py:52-53
    Lens: failure — MlflowException with INVALID_PARAMETER_VALUE
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    try:
        AssessmentSourceType._standardize("ROBOT")
        _fail("Expected MlflowException for invalid type")
    except MlflowException as e:
        _check("Invalid assessment source type" in str(e),
               f"Message should mention 'Invalid assessment source type': {e}")
        print("PASS: _standardize raises MlflowException for invalid type (C27)")


def check_assessment_source_type_init_and_str():
    """C28: AssessmentSourceType.__init__ stores parsed value; __str__ returns it.

    Repo test: none direct (via AssessmentSource construction)
    Lens: state — constructor stores value, str() reveals it
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    inst = AssessmentSourceType("llm_judge")
    _check(str(inst) == "LLM_JUDGE", f"Expected LLM_JUDGE, got {str(inst)}")

    inst2 = AssessmentSourceType("human")
    _check(str(inst2) == "HUMAN", f"Expected HUMAN, got {str(inst2)}")
    print("PASS: AssessmentSourceType __init__/__str__ stores and returns parsed value (C28)")


def check_assessment_source_type_parse_validates():
    """C29: _parse validates against _SOURCE_TYPES.

    Lens: validation — _parse rejects invalid types
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException

    try:
        AssessmentSourceType._parse("INVALID")
        _fail("Expected MlflowException from _parse for invalid type")
    except MlflowException as e:
        _check("Invalid assessment source type" in str(e),
               "Message should mention 'Invalid assessment source type'")
    print("PASS: _parse validates against _SOURCE_TYPES (C29)")


def check_assessment_source_type_parse_handles_ai_judge():
    """C29 (deprecation): _parse converts AI_JUDGE to LLM_JUDGE with warning."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._parse("AI_JUDGE")
        _check(result == "LLM_JUDGE", f"Expected LLM_JUDGE, got {result}")
        future_warnings = [x for x in w if issubclass(x.category, FutureWarning)]
        _check(len(future_warnings) >= 1, "Expected FutureWarning from _parse")
    print("PASS: _parse handles AI_JUDGE deprecation (C29)")


def check_assessment_source_type_constants_are_strings():
    """C30: AssessmentSourceType constants are simple string values, not dicts.

    Lens: representation — attribute type
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    _check(isinstance(AssessmentSourceType.LLM_JUDGE, str),
           "LLM_JUDGE must be str")
    _check(AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE",
           "LLM_JUDGE must equal 'LLM_JUDGE'")
    _check(isinstance(AssessmentSourceType.HUMAN, str), "HUMAN must be str")
    _check(AssessmentSourceType.HUMAN == "HUMAN", "HUMAN must equal 'HUMAN'")
    _check(isinstance(AssessmentSourceType.CODE, str), "CODE must be str")
    _check(AssessmentSourceType.CODE == "CODE", "CODE must equal 'CODE'")
    _check(isinstance(AssessmentSourceType.AI_JUDGE, str), "AI_JUDGE must be str")
    _check(AssessmentSourceType.AI_JUDGE == "AI_JUDGE", "AI_JUDGE must equal 'AI_JUDGE'")
    _check(isinstance(AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED, str),
           "SOURCE_TYPE_UNSPECIFIED must be str")
    _check(AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED",
           "SOURCE_TYPE_UNSPECIFIED must equal 'SOURCE_TYPE_UNSPECIFIED'")

    # _SOURCE_TYPES must be a list of strings
    _check(isinstance(AssessmentSourceType._SOURCE_TYPES, list),
           "_SOURCE_TYPES must be a list")
    for t in AssessmentSourceType._SOURCE_TYPES:
        _check(isinstance(t, str), f"_SOURCE_TYPES element must be str, got {type(t)}")

    # AI_JUDGE should NOT be in _SOURCE_TYPES (deprecated)
    _check("AI_JUDGE" not in AssessmentSourceType._SOURCE_TYPES,
           "AI_JUDGE should not be in _SOURCE_TYPES")
    print("PASS: AssessmentSourceType constants are simple strings (C30)")


# ══════════════════════════════════════════════════════════════════════════════
# Execution
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    _run_all()
