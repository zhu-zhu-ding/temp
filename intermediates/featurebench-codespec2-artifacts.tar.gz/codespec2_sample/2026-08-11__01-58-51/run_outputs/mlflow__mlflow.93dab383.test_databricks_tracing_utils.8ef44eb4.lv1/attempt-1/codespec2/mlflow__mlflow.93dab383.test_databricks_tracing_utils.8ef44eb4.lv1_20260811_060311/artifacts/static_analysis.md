# Static Analysis

## Scope
- Repository: `/testbed`
- Declared interfaces: 16
- `mlflow/utils/databricks_tracing_utils.py`: `assessment_to_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `get_trace_id_from_assessment_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `inference_table_location_to_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `mlflow_experiment_location_to_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `trace_from_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `trace_info_to_v4_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `trace_location_from_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `trace_location_to_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `trace_to_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `uc_schema_location_from_proto` (function)
- `mlflow/utils/databricks_tracing_utils.py`: `uc_schema_location_to_proto` (function)
- `mlflow/entities/assessment_source.py`: `AssessmentSourceType` (class)
- `mlflow/entities/assessment_source.py`: `AssessmentSourceType._standardize` (method)
- `mlflow/entities/span.py`: `Span` (class)
- `mlflow/entities/span.py`: `Span.inputs` (method)
- `mlflow/entities/span.py`: `Span.outputs` (method)

## Findings
## static issue

- **`mlflow/entities/trace_info.py`** (1):
  - ? 'trace_info_to_v4_proto' is used but not defined or imported in this file
- **`mlflow/entities/trace_location.py`** (1):
  - ? 'trace_location_from_proto' is used but not defined or imported in this file
- **`mlflow/store/tracking/databricks_rest_store.py`** (5):
  - ? 'assessment_to_proto' is used but not defined or imported in this file
  - ? 'trace_from_proto' is used but not defined or imported in this file
  - ? 'trace_location_to_proto' is used but not defined or imported in this file
  - ? 'uc_schema_location_from_proto' is used but not defined or imported in this file
  - ? 'uc_schema_location_to_proto' is used but not defined or imported in this file

## Use
- Requirement Compile: use findings to identify dependency, caller-binding, and compatibility risks.
- Test Spec: compile relevant findings into runtime checks; static evidence alone is not a behavior proof.
