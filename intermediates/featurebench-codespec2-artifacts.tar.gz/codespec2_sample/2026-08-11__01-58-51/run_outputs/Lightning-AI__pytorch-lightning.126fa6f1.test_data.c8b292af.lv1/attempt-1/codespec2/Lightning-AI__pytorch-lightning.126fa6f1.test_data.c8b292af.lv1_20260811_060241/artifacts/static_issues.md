## static issue

- **`src/lightning/fabric/fabric.py`** (1):
  - ? '_replace_dunder_methods' is used but not defined or imported in this file
- **`src/lightning/fabric/utilities/data.py`** (2):
  - ? '_reinstantiate_wrapped_cls' is used but not defined or imported in this file
  - ? '_replace_value_in_saved_args' is used but not defined or imported in this file
- **`src/lightning/pytorch/loops/evaluation_loop.py`** (1):
  - ? 'has_len_all_ranks' is used but not defined or imported in this file
- **`src/lightning/pytorch/loops/fit_loop.py`** (1):
  - ? 'has_len_all_ranks' is used but not defined or imported in this file
- **`src/lightning/pytorch/loops/prediction_loop.py`** (1):
  - ? 'has_len_all_ranks' is used but not defined or imported in this file
- **`src/lightning/pytorch/trainer/connectors/data_connector.py`** (3):
  - ? '_is_dataloader_shuffled' is used but not defined or imported in this file
  - ? '_replace_dunder_methods' is used but not defined or imported in this file
  - ? '_update_dataloader' is used but not defined or imported in this file
- **`src/lightning/pytorch/trainer/connectors/logger_connector/result.py`** (1):
  - ? 'extract_batch_size' is used but not defined or imported in this file
