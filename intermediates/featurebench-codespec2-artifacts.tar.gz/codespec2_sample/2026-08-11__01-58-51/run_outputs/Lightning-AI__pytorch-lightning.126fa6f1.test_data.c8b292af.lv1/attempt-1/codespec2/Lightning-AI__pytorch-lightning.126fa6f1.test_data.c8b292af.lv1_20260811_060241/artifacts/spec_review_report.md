# Spec Review Report

## Evidence Reviewed

1. **Task document** — primary oracle: DataLoader management utilities with 6 interface descriptions.
2. **Semantic IR** (`semantic_ir.md`, 741 lines) — 17 requirements (R1–R17), 20 nodes (N1–N20), 16 edges (E1–E16), 36 contracts (C1–C36).
3. **Architecture spec** (`arch_spec.py`, ~316 lines) — import-boundary, caller-binding, and dataflow checks.
4. **Behavior spec** (`behavior_spec.py`, 1196 lines) — return-value, state, error, side-effect, and lifecycle checks.
5. **Static issues** (`static_issues.md`) — 10 unresolved-symbol call sites across 7 files.
6. **Static analysis** (`static_analysis.md`) — confirms the 10 static issues.
7. **Repository source files**:
   - `src/lightning/fabric/utilities/data.py` (505 lines) — N1, N2, N3 missing; N4–N9 defined.
   - `src/lightning/pytorch/utilities/data.py` (59 lines) — N10–N14 missing; N15–N16 defined.
   - `src/lightning/fabric/fabric.py` — N18 caller at line 1076.
   - `src/lightning/pytorch/trainer/connectors/data_connector.py` — N17 caller at lines 192, 266, 330, 482.
   - `src/lightning/pytorch/trainer/connectors/logger_connector/result.py` — N19 caller at line 349.
   - `src/lightning/pytorch/loops/fit_loop.py`, `evaluation_loop.py`, `prediction_loop.py` — N20 callers.
8. **Repository tests**:
   - `tests/tests_fabric/utilities/test_data.py` (647+ lines) — comprehensive parametrized tests for `_replace_dunder_methods`, `_update_dataloader`, `_get_dataloader_init_args_and_kwargs`, `_replace_value_in_saved_args`, `_set_sampler_epoch`, `suggested_max_num_workers`, `has_iterable_dataset`, `has_len`.
   - `tests/tests_pytorch/trainer/test_dataloaders.py` — imports `has_len_all_ranks` (line 41) and tests it with IterableDataset at lines 720, 734.
   - No repository tests exist for `_is_dataloader_shuffled` or `extract_batch_size` (confirmed via grep).

---

## Rubric Scores

### Seed Rubrics

| Rubric | Score | Evidence |
|--------|-------|----------|
| **Requirement coverage** | PASS | Every R1–R17 has at least one traceable R/E/C in the IR and at least one arch or behavior check. All 36 contracts are mapped to spec checks. |
| **Requirement fidelity** | MIXED | See Findings 1, 2, 3, 5. Several contracts (C12, C13, C28, C29) have weak or missing failure-path/side-effect assertions. |
| **Caller binding and architecture** | PASS | E1, E2, E3, E11, E12, E13 are exercised at actual caller-resolved entry points (fabric.utilities.data, pytorch.utilities.data) with real DataLoader instances, not mock symbols. |
| **Dataflow and lifecycle** | MIXED | C6 tests attribute replay indirectly; C3/C4 test init-time exclusion well. C28/C29 side-effects are untestable with mock strategy. |
| **Failure and compatibility** | FAIL | C12 (MisconfigurationException), C13 (TypeError), and all error paths for `_update_dataloader` (C19 ValueError/MisconfigurationException/TypeError) lack behavioral tests. See Findings 1, 5. |
| **Static-issue closure** | PASS | All 10 static issues have a corresponding runtime import-boundary or caller-binding check (C30–C34, C1–C10, E1/E11, E12, E13). |
| **Repository-test alignment** | PASS | Specs adapt fixture shapes from parametrized `test_replace_dunder_methods_dataloader`, mock patterns from `test_set_sampler_epoch`, and lifecycle setup from `test_replace_dunder_methods_restore_methods`. |
| **Oracle strength** | MIXED | C1–C5, C7–C10, C35–C36 use exact-value assertions. C24, C28, C29 use weak proxy assertions (see Findings 2, 3, 4). |

### Derived Domain Rubrics (from repository test practice)

| Source Test | Perspective | Risk | Generated Check | Score |
|-------------|-------------|------|-----------------|-------|
| `test_data.py:208` `test_replace_dunder_methods_dataloader` | Parametrized end-to-end: wrap→reconstruct→verify type identity, attr preservation, PL-attr absence | Reconstruction could silently drop attrs or leak PL bookkeeping | C6 checks type, attrs, deletions, leakage | PASS |
| `test_data.py:261` `test_replace_dunder_methods_attrs` | Custom `__setattr__` + DEL replay ordering | Replay order could diverge from original mutation order | C3 checks exact `__pl_attrs_record` list order and values | PASS |
| `test_data.py:306` `test_replace_dunder_methods_restore_methods` | Dunder restoration across multiple subclass combinations | Patch leakage corrupts unrelated test/usage | C5 checks method identity restoration and `__old__init__` absence on non-defining subclasses | PASS |
| `test_data.py:375` `test_replace_value_in_args` | Parametrized exact return values for positional, kwarg, default, missing cases | Wrong arg resolution silently produces invalid re-instantiation | C7–C10 check exact `(success, args, kwargs)` tuples | PASS |
| `test_data.py:558` `test_dataloader_kwargs_replacement_with_array_default_comparison` | Array-valued attributes (truth-value-ambiguous comparison) | `==` comparison could crash on NumPy arrays | No equivalent spec check | GAP — see Finding 7 |
| `test_data.py:422` `test_custom_torch_batch_sampler` | Custom BatchSampler subclass with `__pl_saved_args` → sampler injection | Missing sampler arg in saved_kwargs causes silent failure | No equivalent spec check for `_reinstantiate_wrapped_cls` on BatchSampler specifically | GAP — see Finding 7 |
| `test_dataloaders.py:720` | `has_len_all_ranks` with IterableDataset+len → True; without len → False | Could incorrectly return True for IterableDataset without __len__ | C25, C26 cover this | PASS |

---

## Findings

### Finding 1: `missing_requirement` — C12 and C13 error-path assertions absent

- **Affected IDs**: C12, C13; R3, R16; N10.
- **Static issue**: None directly (these are error paths, not unresolved symbols).
- **Repository evidence**: `src/lightning/fabric/utilities/data.py:141–168` implements both `MisconfigurationException` (missing required attrs) and `TypeError` (missing kwargs in non-variadic signature) for the fabric base version. Repository test `test_update_dataloader_typerror_custom_exception` (line 385) exercises these paths for the fabric 2-param version.
- **Gap**: The behavior spec's `check_get_dataloader_init_args_and_kwargs_regular_dataset` mentions C12/C13 in its docstring but only asserts the happy path (valid args/kwargs return). It never constructs a scenario where `required_args` is non-empty (C12) or where `missing_kwargs` triggers (C13). There is no test that raises `MisconfigurationException` or `TypeError` for the pytorch 3-param `_get_dataloader_init_args_and_kwargs`.
- **Concrete rework**: Add two behavioral checks:
  1. A DataLoader subclass whose `__init__` has a required positional arg not exposed as an instance attribute → assert `MisconfigurationException` with diagnostic listing the missing attribute.
  2. A DataLoader subclass without `**kwargs` whose `__init__` lacks a keyword that must be passed → assert `TypeError`.

### Finding 2: `weak_constraint` — C28 zero-total-length warning not verifiable

- **Affected IDs**: C28; R11; N14.
- **Static issue**: None.
- **Repository evidence**: Interface Description 2 states `has_len_all_ranks` "Issues warnings for various edge cases: When total length across all ranks is zero." The repository has no direct test for this warning on `has_len_all_ranks`.
- **Gap**: The behavior spec `check_has_len_all_ranks_warning_zero_total` uses a Mock strategy and acknowledges: "The warning may come from has_len -> rank_zero_warn" with a bare `pass`. The check cannot distinguish between an implementation that emits the warning and one that silently returns True. A mock strategy object cannot exercise the real `rank_zero_warn` code path because `has_len` (called internally) relies on actual `len()` of the dataloader, not the strategy.
- **Concrete rework**: Instead of using a Mock strategy, use a real (or minimal) Strategy subclass with a functional `reduce` method. Construct a zero-length DataLoader and verify via `warnings.catch_warnings` that a zero-length warning is emitted. Alternatively, restructure the check to mock `rank_zero_warn` and verify it is called with a message containing "0 length" when total length is zero.

### Finding 3: `weak_constraint` — C29 uneven-distribution warning not verifiable

- **Affected IDs**: C29; R11; N14.
- **Static issue**: None.
- **Repository evidence**: Interface Description 2 states `has_len_all_ranks` warns "When there's uneven batch length distribution across ranks." No repository test exists.
- **Gap**: Same root cause as Finding 2. The behavior spec `check_has_len_all_ranks_warning_uneven` admits: "The warning may or may not fire depending on exact logic; we at least verify the function completes without error and returns correct result." This is not a discriminating assertion.
- **Concrete rework**: Same approach as Finding 2 — use a real Strategy or mock `rank_zero_warn` to verify an uneven-distribution warning is emitted when `local_len * world_size != total_len` (or whatever the implementation's uneven-detection criterion is).

### Finding 4: `weak_constraint` — C24 does not verify first-tensor batch-size semantics

- **Affected IDs**: C24; R10; N13.
- **Static issue**: None.
- **Repository evidence**: Interface Description 2 states "When multiple tensors with different batch sizes are found, the function issues a warning and uses the first encountered batch size." The internal `_extract_batch_size` generator yields values in traversal order. No repository test exists for `extract_batch_size`.
- **Gap**: The behavior spec `check_extract_batch_size_ambiguous_warning` checks that some warning about "batch size" is emitted and that the return value is 4 (the first tensor's batch size). However, it does not verify that the return value is specifically the *first* encountered tensor's batch size as opposed to, say, the last, the minimum, or the maximum. A wrong implementation that returns 6 (the second tensor's size) would still emit a warning and return an int — the check would pass.
- **Concrete rework**: The check should explicitly assert that the return value matches `batch["a"].size(0)` (the first tensor in dict iteration order) and that the warning message contains language about "ambiguous" or "different batch sizes." Alternatively, construct a batch where traversal order is deterministic (e.g., a list `[torch.randn(4,3), torch.randn(6,3)]`) and assert `extract_batch_size(...) == 4`.

### Finding 5: `missing_requirement` — `_update_dataloader` (pytorch) error paths untested

- **Affected IDs**: C19, C31; R9, R15; N12.
- **Static issue**: `data_connector.py` uses `_update_dataloader` but has no import (static issue line 7).
- **Repository evidence**: Interface Description 2 states `_update_dataloader` raises `ValueError` (non-DataLoader), `MisconfigurationException` (missing init args), and `TypeError` (custom batch sampler). Repository test `test_update_dataloader_typerror_custom_exception` exercises these for the fabric 2-param version.
- **Gap**: The behavior spec tests only the happy path (C19) and prediction-mode `drop_last=False` (C20). No check verifies that the pytorch 3-param `_update_dataloader` raises `ValueError` for non-DataLoader input, `MisconfigurationException` for missing init args, or `TypeError` for incompatible batch samplers. These paths are exercised by the fabric version's tests but the pytorch wrapper must propagate them.
- **Concrete rework**: Add behavioral checks:
  1. Pass a non-DataLoader (e.g., a plain list) → assert `ValueError`.
  2. Construct a `BadImpl`-style DataLoader subclass with required init args not available as attrs (without wrapping) → assert `MisconfigurationException`.
  3. Construct a custom batch sampler that doesn't follow PyTorch's API → assert `TypeError`.

### Finding 6: `missing_requirement` — `_replace_dunder_methods` BatchSampler path (store_explicit_arg=None) untested

- **Affected IDs**: C1, C2, C30; R7, R14; N1, N18; E1.
- **Static issue**: `fabric.py:1076` uses `_replace_dunder_methods(BatchSampler)` without `store_explicit_arg`.
- **Repository evidence**: `fabric.py:1076` calls `_replace_dunder_methods(DataLoader, "dataset"), _replace_dunder_methods(BatchSampler)`. The repository test `test_custom_torch_batch_sampler` (line 422) exercises `_replace_dunder_methods(BatchSampler)` via the full hook path. The arch spec's `check_replace_dunder_methods_integration_fabric` tests both context managers together but the behavior spec only tests `_replace_dunder_methods(DataLoader, "dataset")`.
- **Gap**: The behavior spec does not independently verify that `_replace_dunder_methods(BatchSampler)` (with `store_explicit_arg=None`) correctly patches `BatchSampler.__init__` and does not store a `__dataset` attribute. The behavior spec's C1/C2 checks exclusively use `DataLoader` with `store_explicit_arg="dataset"`. A bug that always requires `store_explicit_arg` to be non-None would pass all current behavior checks.
- **Concrete rework**: Add a behavioral check that enters `_replace_dunder_methods(BatchSampler)` (no second argument), instantiates a `BatchSampler` within the context, and verifies: (a) `__pl_saved_args` and `__pl_saved_kwargs` are set, (b) `__dataset` is NOT set (since `store_explicit_arg` was not provided), (c) the context exits cleanly without error.

### Finding 7: `missing_requirement` — `_is_dataloader_shuffled` missing no-sampler case

- **Affected IDs**: C15–C18; R8; N11.
- **Static issue**: `data_connector.py:482` calls `_is_dataloader_shuffled` (no import).
- **Repository evidence**: Interface Description 2 explicitly states `_is_dataloader_shuffled` returns `False` for "DataLoaders without samplers." The repository has no tests for `_is_dataloader_shuffled` at all.
- **Gap**: Contracts C15–C18 cover RandomSampler→True, SequentialSampler→False, IterableDataset→False, and saved-kwargs precedence. None covers the "no sampler at all" case. A DataLoader created without explicit `sampler` or `shuffle` that uses PyTorch's default `_utils.fetch._MapDatasetFetcher`-based path (which may or may not create a sampler internally) is not tested. The behavior spec faithfully tests C15–C18 but the IR itself missed this case from the interface description.
- **Concrete rework**: First, add a contract to the IR: `C17b: _is_dataloader_shuffled returns False when no sampler is configured`. Then add a behavioral check: construct `DataLoader(range(10))` with no `shuffle` or `sampler` argument, and assert `_is_dataloader_shuffled(dl) is False`.

---

## Decision

**Decision: REWORK**

Six findings must be addressed before the specs can be considered a faithful and discriminating compilation of the task:

| # | Type | Summary | Affected IDs |
|---|------|---------|-------------|
| 1 | `missing_requirement` | C12/C13 error paths (MisconfigurationException, TypeError) for pytorch `_get_dataloader_init_args_and_kwargs` untested | C12, C13, R3, R16, N10 |
| 2 | `weak_constraint` | C28 zero-total-length warning not observed (mock strategy cannot trigger real warning path) | C28, R11, N14 |
| 3 | `weak_constraint` | C29 uneven-distribution warning not observed (same root cause) | C29, R11, N14 |
| 4 | `weak_constraint` | C24 does not verify first-tensor batch-size semantics | C24, R10, N13 |
| 5 | `missing_requirement` | `_update_dataloader` (pytorch) error paths (ValueError, MisconfigurationException, TypeError) untested | C19, C31, R9, R15, N12 |
| 6 | `missing_requirement` | `_replace_dunder_methods(BatchSampler)` with `store_explicit_arg=None` path untested | C1, C2, C30, R7, R14, N1, N18, E1 |

Additional observation (not blocking): `_is_dataloader_shuffled` no-sampler case (Finding 7) is an IR gap first; after IR correction, a spec check is needed. The `test_dataloader_kwargs_replacement_with_array_default_comparison` regression test (#15408) for array-valued attributes in `_get_dataloader_init_args_and_kwargs` has no equivalent spec check — consider adding one.
