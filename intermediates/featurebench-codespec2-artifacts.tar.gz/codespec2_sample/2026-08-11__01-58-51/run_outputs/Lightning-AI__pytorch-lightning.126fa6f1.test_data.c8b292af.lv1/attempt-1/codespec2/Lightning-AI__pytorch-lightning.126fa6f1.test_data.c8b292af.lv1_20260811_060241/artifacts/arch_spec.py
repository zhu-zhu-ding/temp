#!/usr/bin/env python3
"""Executable architecture spec for DataLoader management utilities.

Validates import bindings, caller–callee connectivity, dispatch paths,
and dataflow edges from the semantic IR.  Each check_* function maps to one
or more contract IDs and exercises the real repository call sites.
"""
import sys
import importlib
import inspect

_EXIT = 0


def _pass(msg: str) -> None:
    print(f"PASS: {msg}")


def _fail(msg: str) -> None:
    global _EXIT
    print(f"FAIL: {msg}")
    _EXIT = 1


# ---------------------------------------------------------------------------
# C30: Import boundary — _replace_dunder_methods from fabric.utilities.data
# ---------------------------------------------------------------------------
def check_import_replace_dunder_methods_fabric() -> None:
    """Contracts: C30.  Obligations: R14.  Graph: N1, N18, E1.

    Repository test: tests/tests_fabric/utilities/test_data.py imports
    _replace_dunder_methods from lightning.fabric.utilities.data.

    Testing perspective: import-boundary — verify the symbol exists and is a
    context-manager function importable from the expected public module.

    Source: src/lightning/fabric/utilities/data.py
    """
    try:
        from lightning.fabric.utilities.data import _replace_dunder_methods
    except ImportError as exc:
        _fail(f"C30: cannot import _replace_dunder_methods: {exc}")
        return

    if not callable(_replace_dunder_methods):
        _fail("C30: _replace_dunder_methods is not callable")
        return

    # Must be usable as a context manager (decorated with @contextmanager)
    import contextlib
    mgr = _replace_dunder_methods(object)
    if not hasattr(mgr, "__enter__"):
        _fail("C30: _replace_dunder_methods does not return a context manager")
        return
    mgr.__exit__(None, None, None)  # clean up the un-entered context

    _pass("C30: _replace_dunder_methods importable from lightning.fabric.utilities.data")


# ---------------------------------------------------------------------------
# E1/E11: N18→N1, N17→N1 — _replace_dunder_methods used with both DataLoader
#         and BatchSampler (the exact call patterns in fabric.py:1076 and
#         data_connector.py:330)
# ---------------------------------------------------------------------------
def check_replace_dunder_methods_integration_fabric() -> None:
    """Contracts: C30, C1, C2.  Obligations: R7, R14.  Graph: N1, N18, N17, E1, E11.

    Repository test: tests/tests_fabric/utilities/test_data.py:422
    test_custom_torch_batch_sampler exercises this exact dual-context pattern.

    Testing perspective: caller-binding — verify the exact dual-context-manager
    pattern used at fabric.py:1076 and data_connector.py:330 works:
        with _replace_dunder_methods(DataLoader, "dataset"), \
             _replace_dunder_methods(BatchSampler):

    Source: src/lightning/fabric/utilities/data.py
    """
    try:
        from lightning.fabric.utilities.data import _replace_dunder_methods
    except ImportError as exc:
        _fail(f"E1: cannot import _replace_dunder_methods: {exc}")
        return

    from torch.utils.data import DataLoader, BatchSampler, RandomSampler

    # Exact pattern from fabric.py:1076 and data_connector.py:330
    with _replace_dunder_methods(DataLoader, "dataset"), _replace_dunder_methods(BatchSampler):
        dl = DataLoader(range(10), batch_size=2, shuffle=True)
        sampler = RandomSampler(range(10))
        bs = BatchSampler(sampler, batch_size=5, drop_last=False)

    # Verify DataLoader got its args saved
    if not hasattr(dl, "__pl_saved_args"):
        _fail("E1: __pl_saved_args not saved on DataLoader within dual context")
        return
    if not hasattr(dl, "__dataset"):
        _fail("E1: __dataset not saved on DataLoader within dual context")
        return

    # Verify BatchSampler got its args saved (no __dataset expected)
    if not hasattr(bs, "__pl_saved_args"):
        _fail("E1: __pl_saved_args not saved on BatchSampler within dual context")
        return
    if hasattr(bs, "__dataset"):
        _fail("E1: __dataset should NOT be on BatchSampler (no store_explicit_arg)")
        return

    _pass("E1/E11: dual context _replace_dunder_methods(DataLoader, BatchSampler) works correctly")


# ---------------------------------------------------------------------------
# C31: Import boundary — _update_dataloader resolved for data_connector.py
# ---------------------------------------------------------------------------
def check_import_update_dataloader_pytorch() -> None:
    """Contracts: C31.  Obligations: R15.  Graph: N12, N17, E2.

    Repository test: tests/tests_pytorch/trainer/test_dataloaders.py imports
    has_len_all_ranks from lightning.pytorch.utilities.data (implied pattern).

    Testing perspective: import-boundary — verify the 3-param _update_dataloader
    is importable from lightning.pytorch.utilities.data.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import _update_dataloader
    except ImportError as exc:
        _fail(f"C31: cannot import _update_dataloader from pytorch: {exc}")
        return

    if not callable(_update_dataloader):
        _fail("C31: _update_dataloader is not callable")
        return

    # Verify 3-param signature: (dataloader, sampler, mode)
    sig = inspect.signature(_update_dataloader)
    params = list(sig.parameters.keys())
    if len(params) < 3:
        _fail(f"C31: _update_dataloader pytorch version needs >=3 params, got {params}")
        return

    _pass("C31: _update_dataloader importable from lightning.pytorch.utilities.data")


# ---------------------------------------------------------------------------
# C32: Import boundary — _is_dataloader_shuffled resolved for data_connector.py
# ---------------------------------------------------------------------------
def check_import_is_dataloader_shuffled() -> None:
    """Contracts: C32.  Obligations: R15.  Graph: N11, N17, E3.

    Repository test: none directly (static issue).

    Testing perspective: import-boundary — verify _is_dataloader_shuffled
    exists in lightning.pytorch.utilities.data and returns bool.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import _is_dataloader_shuffled
    except ImportError as exc:
        _fail(f"C32: cannot import _is_dataloader_shuffled: {exc}")
        return

    if not callable(_is_dataloader_shuffled):
        _fail("C32: _is_dataloader_shuffled is not callable")
        return

    _pass("C32: _is_dataloader_shuffled importable from lightning.pytorch.utilities.data")


# ---------------------------------------------------------------------------
# C33: Import boundary — extract_batch_size resolved for result.py
# ---------------------------------------------------------------------------
def check_import_extract_batch_size() -> None:
    """Contracts: C33.  Obligations: R15.  Graph: N13, N19, E13.

    Repository test: none directly (static issue).

    Testing perspective: import-boundary — verify extract_batch_size
    exists in lightning.pytorch.utilities.data and returns int.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import extract_batch_size
    except ImportError as exc:
        _fail(f"C33: cannot import extract_batch_size: {exc}")
        return

    if not callable(extract_batch_size):
        _fail("C33: extract_batch_size is not callable")
        return

    _pass("C33: extract_batch_size importable from lightning.pytorch.utilities.data")


# ---------------------------------------------------------------------------
# C34: Import boundary — has_len_all_ranks resolved for loops
# ---------------------------------------------------------------------------
def check_import_has_len_all_ranks() -> None:
    """Contracts: C34.  Obligations: R15.  Graph: N14, N20, E12.

    Repository test: tests/tests_pytorch/trainer/test_dataloaders.py:41
    imports has_len_all_ranks from lightning.pytorch.utilities.data.

    Testing perspective: import-boundary — verify has_len_all_ranks
    is importable with correct signature.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import has_len_all_ranks
    except ImportError as exc:
        _fail(f"C34: cannot import has_len_all_ranks: {exc}")
        return

    if not callable(has_len_all_ranks):
        _fail("C34: has_len_all_ranks is not callable")
        return

    # Verify accepts (dataloader, strategy, allow_zero_length_dataloader_with_multiple_devices)
    sig = inspect.signature(has_len_all_ranks)
    params = list(sig.parameters.keys())
    expected = ["dataloader", "strategy"]
    for p in expected:
        if p not in params:
            _fail(f"C34: has_len_all_ranks missing param '{p}', got {params}")
            return

    _pass("C34: has_len_all_ranks importable from lightning.pytorch.utilities.data")


# ---------------------------------------------------------------------------
# E12: N20→N14 — has_len_all_ranks uses strategy.reduce
# ---------------------------------------------------------------------------
def check_has_len_all_ranks_call_chain() -> None:
    """Contracts: C26, C34.  Obligations: R11, R15.  Graph: N14, N20, E12.

    Repository test: tests/tests_pytorch/trainer/test_dataloaders.py:720.

    Testing perspective: caller-binding — has_len_all_ranks calls
    strategy.reduce to sum lengths across ranks.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import has_len_all_ranks
    except ImportError as exc:
        _fail(f"E12: cannot import has_len_all_ranks: {exc}")
        return

    from torch.utils.data import DataLoader
    from unittest.mock import Mock

    # Simulate a minimal strategy with a reduce method
    strategy = Mock()
    strategy.reduce.return_value = 3  # total across ranks

    dl = DataLoader(range(10), batch_size=2)
    result = has_len_all_ranks(dl, strategy, allow_zero_length_dataloader_with_multiple_devices=False)
    if not isinstance(result, bool):
        _fail(f"E12: has_len_all_ranks did not return bool, got {type(result)}")
        return
    if result is not True:
        _fail(f"E12: has_len_all_ranks returned {result}, expected True for valid dataloader")
        return

    _pass("E12: has_len_all_ranks call chain functional (strategy→reduce)→TypeGuard[Sized]")


# ---------------------------------------------------------------------------
# E13, E14: N19→N13→N15 — extract_batch_size wraps _extract_batch_size
# ---------------------------------------------------------------------------
def check_extract_batch_size_dataflow() -> None:
    """Contracts: C21, C33.  Obligations: R10, R15.  Graph: N13, N15, N19, E13, E14.

    Repository test: none directly for public extract_batch_size.

    Testing perspective: dataflow — verify extract_batch_size returns int
    for tensor batches by delegating to the internal _extract_batch_size generator.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import extract_batch_size
    except ImportError as exc:
        _fail(f"E13: cannot import extract_batch_size: {exc}")
        return

    import torch

    # Tensor batch
    batch = torch.randn(4, 3)
    bs = extract_batch_size(batch)
    if bs != 4:
        _fail(f"C21: extract_batch_size(tensor(4,3)) = {bs}, expected 4")
        return

    # Scalar tensor
    bs = extract_batch_size(torch.tensor(1.0))
    if bs != 1:
        _fail(f"C21: extract_batch_size(scalar) = {bs}, expected 1")
        return

    _pass("E13/E14: extract_batch_size dataflow N13→N15 returns correct int")


# ---------------------------------------------------------------------------
# E15: N14→N8 — has_len_all_ranks depends on fabric helpers
# ---------------------------------------------------------------------------
def check_has_len_all_ranks_fabric_dependency() -> None:
    """Contracts: C25.  Obligations: R11.  Graph: N14, N8, E15.

    Repository test: tests/tests_pytorch/trainer/test_dataloaders.py:41.

    Testing perspective: import-dependency — has_len_all_ranks must internally
    use has_len/sized_len/has_iterable_dataset from fabric.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import has_len_all_ranks
    except ImportError as exc:
        _fail(f"E15: cannot import has_len_all_ranks: {exc}")
        return

    # Verify has_len_all_ranks uses sized_len via the existing import in pytorch/utilities/data.py:26
    import lightning.pytorch.utilities.data as pydata
    if not hasattr(pydata, "sized_len") or not hasattr(pydata, "has_iterable_dataset"):
        _fail("E15: lightning.pytorch.utilities.data missing fabric re-exports (sized_len, has_iterable_dataset)")
        return

    _pass("E15: has_len_all_ranks has access to fabric helpers (sized_len, has_iterable_dataset)")


# ---------------------------------------------------------------------------
# E16: N1→N4 — _replace_dunder_methods uses _WrapAttrTag
# ---------------------------------------------------------------------------
def check_wrap_attr_tag_usage() -> None:
    """Contracts: C3, C4.  Obligations: R7.  Graph: N1, N4, E16.

    Repository test: tests/tests_fabric/utilities/test_data.py:261-299
    test_replace_dunder_methods_attrs.

    Testing perspective: state — verify _WrapAttrTag.SET/DEL are used in
    __pl_attrs_record entries.

    Source: src/lightning/fabric/utilities/data.py
    """
    try:
        from lightning.fabric.utilities.data import _replace_dunder_methods, _WrapAttrTag
    except ImportError as exc:
        _fail(f"E16: cannot import symbols: {exc}")
        return

    from torch.utils.data import DataLoader

    class Loader(DataLoader):
        def __setattr__(self, attr, val):
            if attr == "custom_arg":
                val = val + 2
            super().__setattr__(attr, val)

    with _replace_dunder_methods(DataLoader, "dataset"):
        dl = Loader(range(10))
        dl.custom_arg = 5
        dl.my_arg = 10
        dl.another_arg = 100
        # Delete an attribute
        del dl.dataset

    if not hasattr(dl, "__pl_attrs_record"):
        _fail("C3: __pl_attrs_record missing")
        return

    record = dl.__pl_attrs_record
    # Verify SET entries use _WrapAttrTag.SET
    for entry in record:
        if entry[1] not in (_WrapAttrTag.SET, _WrapAttrTag.DEL):
            _fail(f"E16: unexpected tag {entry[1]} in __pl_attrs_record")
            return

    # Check custom __setattr__ was executed (custom_arg + 2)
    if dl.custom_arg != 7:
        _fail(f"C3: custom __setattr__ not applied, custom_arg={dl.custom_arg}")
        return

    # Check init-time attrs are NOT in record (C4)
    init_attr_names = {entry[0][0] for entry in record if isinstance(entry[0], tuple)}
    if "__pl_saved_args" in init_attr_names or "__pl_saved_kwargs" in init_attr_names:
        _fail("C4: init-time attribute sets are recorded (should be absent)")
        return

    _pass("E16: _WrapAttrTag SET/DEL used correctly in __pl_attrs_record")


# ---------------------------------------------------------------------------
# E2: N17→N12 — data_connector._process_dataloader uses pytorch _update_dataloader
# ---------------------------------------------------------------------------
def check_data_connector_to_update_dataloader() -> None:
    """Contracts: C19, C31.  Obligations: R9, R15.  Graph: N12, N17, N10, N2, E2, E4, E8.

    Repository test: tests/tests_pytorch/trainer/test_dataloaders.py integration tests.

    Testing perspective: caller-binding — data_connector._process_dataloader calls
    _update_dataloader(dataloader, sampler, mode=mode).

    Source: src/lightning/pytorch/utilities/data.py,
           src/lightning/pytorch/trainer/connectors/data_connector.py:192
    """
    try:
        from lightning.pytorch.utilities.data import _update_dataloader
    except ImportError as exc:
        _fail(f"E2: cannot import _update_dataloader: {exc}")
        return

    from torch.utils.data import DataLoader, SequentialSampler
    from lightning.pytorch.trainer.states import RunningStage

    # Simulate what data_connector does at line 192
    dl = DataLoader(range(10), batch_size=2)
    sampler = SequentialSampler(range(10))
    new_dl = _update_dataloader(dl, sampler, mode=RunningStage.TRAINING)

    if not isinstance(new_dl, DataLoader):
        _fail("C19: _update_dataloader did not return a DataLoader")
        return

    # sampler should be replaced
    if not isinstance(new_dl.sampler, SequentialSampler):
        _fail("C19: sampler not replaced in updated DataLoader")
        return

    _pass("E2: data_connector→_update_dataloader(pytorch) call chain verified")


# ---------------------------------------------------------------------------
# E3: N17→N11 — data_connector uses _is_dataloader_shuffled
# ---------------------------------------------------------------------------
def check_data_connector_to_is_dataloader_shuffled() -> None:
    """Contracts: C15, C32.  Obligations: R8, R15.  Graph: N11, N17, E3.

    Repository test: none directly.

    Testing perspective: caller-binding — _is_dataloader_shuffled called at
    data_connector.py:482 returns bool.

    Source: src/lightning/pytorch/utilities/data.py
    """
    try:
        from lightning.pytorch.utilities.data import _is_dataloader_shuffled
    except ImportError as exc:
        _fail(f"E3: cannot import _is_dataloader_shuffled: {exc}")
        return

    from torch.utils.data import DataLoader

    # RandomSampler → True
    dl = DataLoader(range(10), batch_size=2, shuffle=True)
    result = _is_dataloader_shuffled(dl)
    if not isinstance(result, bool):
        _fail("C15: _is_dataloader_shuffled did not return bool")
        return

    _pass("E3: data_connector→_is_dataloader_shuffled call chain verified")


# ---------------------------------------------------------------------------
# Top-level runner
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("check_") and callable(fn):
            try:
                fn()
            except Exception as exc:
                _fail(f"{name} raised {type(exc).__name__}: {exc}")
    sys.exit(_EXIT)
