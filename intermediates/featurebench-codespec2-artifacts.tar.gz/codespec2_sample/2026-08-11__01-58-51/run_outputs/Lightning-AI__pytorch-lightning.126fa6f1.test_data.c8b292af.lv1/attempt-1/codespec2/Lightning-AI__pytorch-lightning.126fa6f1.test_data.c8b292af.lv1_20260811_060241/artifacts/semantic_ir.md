# Semantic IR

## L1. Requirement Obligations

### R1: DataLoader introspection — dataset type detection
- **Type**: Behavior / Dataflow
- **Statement**: The system shall detect whether a DataLoader wraps an `IterableDataset` (via `has_iterable_dataset`) and a map-style dataset, and shall provide length-checking that returns `None` when `__len__` is not defined or raises `TypeError`/`NotImplementedError`.
- **Task Evidence**: Task doc §1 "DataLoader introspection and validation (dataset type detection, length checking)".
- **Acceptance**: `has_iterable_dataset(dataloader)` returns `True` iff `dataloader.dataset` exists and `isinstance(dataloader.dataset, IterableDataset)`. `sized_len(dataloader)` returns `Optional[int]`, `None` on failure.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:44-55` — `has_iterable_dataset`, `sized_len` already defined. `test_data.py:30-48` exercises both.
- **Uncertainty**: None.

### R2: DataLoader introspection — length validation with warnings
- **Type**: Behavior / Side-effect
- **Statement**: `has_len(dataloader)` shall check `__len__` existence, emit a `rank_zero_warn` for zero-length dataloaders, and emit a `rank_zero_warn` when an `IterableDataset` defines `__len__` in multi-process contexts.
- **Task Evidence**: Task doc §1 "length checking".
- **Acceptance**: `has_len` returns `TypeGuard[Sized]`. Warnings on zero length and on `IterableDataset` with `__len__`.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:58-72` — `has_len` already defined. `test_data.py:40-48` exercises.
- **Uncertainty**: None.

### R3: DataLoader reconstruction — argument extraction
- **Type**: Dataflow / Interface
- **Statement**: `_get_dataloader_init_args_and_kwargs(dataloader, sampler, mode=None)` shall extract the positional and keyword arguments from a DataLoader instance for re-instantiation. It shall handle wrapped DataLoaders (those with `__pl_saved_args`) and unwrapped DataLoaders by inspecting instance attributes and the `__init__` signature.
- **Task Evidence**: Task doc §2 "Dynamic DataLoader reconstruction with custom samplers and configurations", §3 "Handle complex inheritance hierarchies".
- **Acceptance**: Returns `tuple[tuple[Any], dict[str, Any]]`. For `IterableDataset`, sets `batch_sampler=None`, `sampler=None`. For regular datasets, delegates to `_dataloader_init_kwargs_resolve_sampler`. Raises `ValueError` if not a `DataLoader` subclass. Raises `MisconfigurationException` if required `__init__` args cannot be extracted from instance attributes. Raises `TypeError` if kwargs don't fit non-variadic `__init__` signature.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:80-168` — base version (2-param). `src/lightning/pytorch/trainer/connectors/data_connector.py:192` calls with `mode=mode` (3-param). Pytorch version (3-param with `mode`) must be defined in `src/lightning/pytorch/utilities/data.py`.
- **Uncertainty**: Whether the pytorch version delegates to the fabric base version or re-implements the logic.

### R4: DataLoader reconstruction — sampler resolution
- **Type**: Dataflow / Behavior
- **Statement**: `_dataloader_init_kwargs_resolve_sampler(dataloader, sampler)` shall resolve the sampler/batch_sampler kwargs for DataLoader re-instantiation. For custom `BatchSampler` subclasses, it shall attempt to replace the inner sampler. It shall handle three cases: (a) wrapped batch samplers with `__pl_saved_args`, (b) batch-sampler-like objects with `batch_size`/`drop_last` attributes, (c) unknown batch samplers that raise `TypeError`.
- **Task Evidence**: Task doc §2 "Dynamic DataLoader reconstruction with custom samplers", §3 "Handle complex inheritance hierarchies and custom DataLoader implementations".
- **Acceptance**: Returns `dict` with `sampler`, `shuffle`, `batch_sampler`, `batch_size`, `drop_last` keys.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:171-243` — `_dataloader_init_kwargs_resolve_sampler` already defined.
- **Uncertainty**: None.

### R5: DataLoader reconstruction — re-instantiation of wrapped classes
- **Type**: Dataflow / State
- **Statement**: `_reinstantiate_wrapped_cls(original, *args, **kwargs)` shall re-instantiate a class whose `__init__` was patched by `_replace_dunder_methods`. It shall use the saved original `__init__`, pass `*args` and `**kwargs`, then replay any recorded attribute modifications (`__pl_attrs_record`) including `_WrapAttrTag.SET` and `_WrapAttrTag.DEL` operations.
- **Task Evidence**: Task doc §2 "Preservation and restoration of custom DataLoader subclass configurations", §3 "Runtime modification of DataLoader parameters without losing original settings".
- **Acceptance**: Returns a new instance of the same type as `original`. The original `__init__` must be temporarily restored during construction. After construction, recorded `__pl_attrs_record` modifications are replayed.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:77,200` calls `_reinstantiate_wrapped_cls` but it is not defined (static issue). Test `test_data.py` imports it from `lightning.fabric.utilities.data`. Tests at lines 208-299 verify the end-to-end behavior through `_update_dataloader` → `_reinstantiate_wrapped_cls`.
- **Uncertainty**: Exact implementation of `__init__` restoration and `__pl_attrs_record` replay order.

### R6: DataLoader reconstruction — value replacement in saved args
- **Type**: Dataflow
- **Statement**: `_replace_value_in_saved_args(replace_key, replace_value, args, kwargs, default_kwargs, arg_names)` shall attempt to replace a named argument value in saved positional args or kwargs. Returns `(success: bool, new_args: tuple, new_kwargs: dict)`.
- **Task Evidence**: Task doc §2 "Dynamic DataLoader reconstruction with custom samplers".
- **Acceptance**: Returns a 3-tuple `(success, new_args, new_kwargs)`. If the key matches an arg_name, replace in `args`. If the key is in `kwargs`, replace there. If in `default_kwargs`, add to `kwargs`. Otherwise return `(False, args, kwargs)`.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:190` calls `_replace_value_in_saved_args` but it is not defined (static issue). Test `test_data.py:19,378` imports and parametrically tests it.
- **Uncertainty**: None — test parametrization fully specifies behavior.

### R7: Dunder method patching for argument capture
- **Type**: State / Interface
- **Statement**: `_replace_dunder_methods(base_cls, store_explicit_arg=None)` is a context manager that temporarily replaces `__init__`, `__setattr__`, and `__delattr__` on `base_cls` and all its subclasses. The wrapped `__init__` captures `__pl_saved_args`, `__pl_saved_kwargs`, `__pl_saved_arg_names`, `__pl_saved_default_kwargs`. If `store_explicit_arg` is given, saves that argument value as `__{store_explicit_arg}`. Wrapped `__setattr__` and `__delattr__` record modifications to `__pl_attrs_record` as `_WrapAttrTag` tuples, but skip recording during initialization. On context exit, all patches are reverted.
- **Task Evidence**: Task doc §2 "Preservation and restoration of custom DataLoader subclass configurations", §3 "Runtime modification of DataLoader parameters without losing original settings".
- **Acceptance**: All subclasses of `base_cls` (including those created after entry) have their dunder methods patched. Classes not defining `__init__` in their `__dict__` rely on MRO-inherited patched version. Original methods stored as `__old__init__`, `__old__setattr__`, `__old__delattr__` on the base class `__dict__`. On exit, all restored.
- **Repository Evidence**: `src/lightning/fabric/fabric.py:1076` and `src/lightning/pytorch/trainer/connectors/data_connector.py:330` call `_replace_dunder_methods` but it is not defined (static issue). Test `test_data.py:53-337` extensively tests it, including subclass handling, attribute recording, method restoration. `_WrapAttrTag` already defined at line 34-41.
- **Uncertainty**: Whether subclasses created after context entry are patched lazily or eagerly.

### R8: DataLoader shuffle detection
- **Type**: Behavior
- **Statement**: `_is_dataloader_shuffled(dataloader)` shall determine if a DataLoader is configured for shuffling. It shall check Lightning-specific saved kwargs (`__pl_saved_kwargs`, `__pl_saved_arg_names`) first, then inspect samplers. `IterableDataset` → `False`. `RandomSampler` → `True`. `SequentialSampler` → `False`. Custom batch samplers are checked for an internal `sampler` attribute.
- **Task Evidence**: Task doc §1 "DataLoader introspection and validation".
- **Acceptance**: Returns `bool`. `True` only for `RandomSampler`. `False` for `IterableDataset`, no sampler, `SequentialSampler`, or unknown sampler types.
- **Repository Evidence**: `src/lightning/pytorch/trainer/connectors/data_connector.py:482` calls `_is_dataloader_shuffled` but it is not defined or imported (static issue). Must be defined in `src/lightning/pytorch/utilities/data.py`.
- **Uncertainty**: None — standard PyTorch DataLoader shuffle semantics.

### R9: DataLoader update with sampler replacement
- **Type**: Dataflow / Interface
- **Statement**: `_update_dataloader(dataloader, sampler, mode=None)` shall create a new DataLoader instance identical to the input but with the sampler replaced. For `RunningStage.PREDICTING`, special handling ensures `drop_last=False`. It shall handle the complete reconstruction pipeline: extract args, resolve sampler, reinstantiate.
- **Task Evidence**: Task doc §2 "Dynamic DataLoader reconstruction with custom samplers and configurations", §3 "Runtime modification of DataLoader parameters without losing original settings".
- **Acceptance**: Returns a new `DataLoader` instance. Raises `ValueError`, `MisconfigurationException`, or `TypeError` as documented. For prediction mode, ensures all samples are processed.
- **Repository Evidence**: Fabric has 2-param version at `src/lightning/fabric/utilities/data.py:75-77`. Pytorch version with `mode` parameter must be defined in `src/lightning/pytorch/utilities/data.py`. Called at `data_connector.py:192,266` with `mode=mode`.
- **Uncertainty**: Whether pytorch `_update_dataloader` delegates to fabric `_update_dataloader` plus additional mode logic, or re-implements entirely.

### R10: Batch size extraction
- **Type**: Dataflow
- **Statement**: `extract_batch_size(batch)` shall recursively traverse a batch (tensors, mappings, iterables, dataclasses) and return the batch size as `int`. For tensors, return `tensor.size(0)`; for 0-d tensors return `1`. When multiple tensors found, use the first and warn. Raises `MisconfigurationException` if no batch size inferrable.
- **Task Evidence**: Task doc §1 "DataLoader introspection and validation".
- **Acceptance**: Returns `int`. Traverses nested structures. Warns on ambiguous sizes. Raises `MisconfigurationException` on failure.
- **Repository Evidence**: `src/lightning/pytorch/utilities/data.py:43-59` has private `_extract_batch_size` (generator). `src/lightning/pytorch/trainer/connectors/logger_connector/result.py:349` calls `extract_batch_size` (public, no import — static issue). The public `extract_batch_size` must be defined in `src/lightning/pytorch/utilities/data.py`, likely wrapping `_extract_batch_size`.
- **Uncertainty**: Exact warning message text and `MisconfigurationException` raise condition.

### R11: Distributed length validation across ranks
- **Type**: Behavior / State
- **Statement**: `has_len_all_ranks(dataloader, strategy, allow_zero_length_dataloader_with_multiple_devices=False)` shall validate that a dataloader has `__len__` on all distributed ranks. If local has no `__len__`, return `False`. Use `strategy.reduce` to sum lengths across ranks. Raise `RuntimeError` if local length is zero but total > 0 and `allow_zero_length_dataloader_with_multiple_devices` is `False`. Warn on zero total length and uneven distribution.
- **Task Evidence**: Task doc §2 "Seamless integration with distributed training environments", §3 "Ensure thread-safe operations and proper resource management".
- **Acceptance**: Returns `TypeGuard[Sized]`. Performs cross-rank length validation. Handles edge cases with appropriate warnings and errors.
- **Repository Evidence**: Used in `fit_loop.py:266,279,303`, `evaluation_loop.py:203`, `prediction_loop.py:162` — none import it (static issue). Test `test_dataloaders.py:41,720,734` imports from `lightning.pytorch.utilities.data`. Must be defined in `src/lightning/pytorch/utilities/data.py`.
- **Uncertainty**: The exact `strategy.reduce` call signature and return type.

### R12: Worker count optimization
- **Type**: Behavior
- **Statement**: `suggested_max_num_workers(local_world_size)` shall suggest an upper bound for `num_workers` based on available CPU cores and distributed process count. Uses `os.sched_getaffinity` when available, falls back to `os.cpu_count()`.
- **Task Evidence**: Task doc §1 "Automatic performance optimization (worker count suggestions)".
- **Acceptance**: Returns `int ≥ 1`. Raises `ValueError` for `local_world_size < 1`.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:439-451` — already defined. `test_data.py` parametrically tests.
- **Uncertainty**: None.

### R13: Epoch-aware sampling
- **Type**: Behavior
- **Statement**: `_set_sampler_epoch(dataloader, epoch)` shall call `set_epoch(epoch)` on all samplers (direct `sampler` and `batch_sampler.sampler`) that expose a callable `set_epoch` method.
- **Task Evidence**: Task doc §1 "epoch-aware sampling".
- **Acceptance**: Calls `set_epoch` on each unique sampler. Handles unhashable samplers via `id()` dict.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:415-436` — already defined. `test_data.py` tests.
- **Uncertainty**: None.

### R14: Caller import boundary — fabric utilities
- **Type**: Interface / Compatibility
- **Statement**: All functions in `src/lightning/fabric/utilities/data.py` must be importable by existing callers: `lightning/fabric/fabric.py`, `lightning/pytorch/trainer/connectors/data_connector.py`, `lightning/pytorch/loops/fit_loop.py`, `lightning/pytorch/loops/evaluation_loop.py`, `lightning/pytorch/utilities/data.py`, and test files.
- **Task Evidence**: Task doc §2 "Seamless integration with distributed training environments".
- **Acceptance**: All static-issue call sites resolve. Specifically:
  - `_replace_dunder_methods` importable from `lightning.fabric.utilities.data` (by `fabric.py` and `data_connector.py`)
  - `_reinstantiate_wrapped_cls` importable from `lightning.fabric.utilities.data` (by `fabric/utilities/data.py` itself)
  - `_replace_value_in_saved_args` importable from `lightning.fabric.utilities.data` (by `fabric/utilities/data.py` itself)
- **Repository Evidence**: Static issues list all unresolved symbols.
- **Uncertainty**: Whether `data_connector.py` should import from `lightning.fabric.utilities.data` or `lightning.pytorch.utilities.data` for `_replace_dunder_methods`. Caller `fabric.py` imports from fabric, so fabric module must define it.

### R15: Caller import boundary — pytorch utilities
- **Type**: Interface / Compatibility
- **Statement**: All functions in `src/lightning/pytorch/utilities/data.py` must be importable by existing callers: `data_connector.py`, `fit_loop.py`, `evaluation_loop.py`, `prediction_loop.py`, `result.py`, and test files.
- **Task Evidence**: Task doc §2.
- **Acceptance**: All static-issue call sites resolve. Specifically:
  - `_get_dataloader_init_args_and_kwargs` (3-param) importable from `lightning.pytorch.utilities.data`
  - `_is_dataloader_shuffled` importable from `lightning.pytorch.utilities.data`
  - `_update_dataloader` (3-param) importable from `lightning.pytorch.utilities.data`
  - `extract_batch_size` importable from `lightning.pytorch.utilities.data`
  - `has_len_all_ranks` importable from `lightning.pytorch.utilities.data`
- **Repository Evidence**: Static issues. `test_dataloaders.py:41` imports `has_len_all_ranks` from `lightning.pytorch.utilities.data`.
- **Uncertainty**: Whether `_update_dataloader` in pytorch module re-exports or wraps the fabric version.

### R16: Error handling — invalid DataLoader subclasses
- **Type**: Failure
- **Statement**: When a DataLoader subclass lacks required `__init__` arguments as instance attributes and was not wrapped, `_get_dataloader_init_args_and_kwargs` shall raise `MisconfigurationException` with a diagnostic message listing missing attributes. When required kwargs don't fit the `__init__` signature and the class lacks `**kwargs`, raise `TypeError`.
- **Task Evidence**: Task doc §3 "Provide robust error handling for misconfigured or incompatible DataLoader setups".
- **Acceptance**: Proper exception classes and diagnostic messages.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:141-168` implements both exception paths.
- **Uncertainty**: None.

### R17: Error handling — custom batch sampler incompatibility
- **Type**: Failure
- **Statement**: When attempting to inject a sampler into a custom batch sampler that doesn't follow PyTorch's `BatchSampler` API, raise `TypeError` with guidance about `use_distributed_sampler=False`. A distinct message for missing `sampler` argument in `__pl_saved_args`.
- **Task Evidence**: Task doc §3.
- **Acceptance**: Proper `TypeError` with actionable message.
- **Repository Evidence**: `src/lightning/fabric/utilities/data.py:191-240` implements both error paths.
- **Uncertainty**: None.

## L2. Functional Design Graph

### N1: `_replace_dunder_methods` (fabric/utilities/data.py)
- **Kind**: Function (context manager)
- **Repository Evidence**: Called at `fabric.py:1076`, `data_connector.py:330`. Tested in `test_data.py:53-337`. Not yet defined (static issue). Must import `get_all_subclasses`, `_WrapAttrTag`, `inspect`.

### N2: `_reinstantiate_wrapped_cls` (fabric/utilities/data.py)
- **Kind**: Function
- **Repository Evidence**: Called at `fabric/utilities/data.py:77,200`. Not yet defined (static issue). Must use `__old__init__`, `__pl_attrs_record`, `_WrapAttrTag`.

### N3: `_replace_value_in_saved_args` (fabric/utilities/data.py)
- **Kind**: Function
- **Repository Evidence**: Called at `fabric/utilities/data.py:190`. Not yet defined (static issue). Tested parametrically in `test_data.py:378`.

### N4: `_WrapAttrTag` (fabric/utilities/data.py)
- **Kind**: Enum class
- **Repository Evidence**: Already defined at lines 34-41. Used by `_replace_dunder_methods` and `_reinstantiate_wrapped_cls`.

### N5: `_get_dataloader_init_args_and_kwargs` (fabric/utilities/data.py) — base version
- **Kind**: Function
- **Repository Evidence**: Already defined at lines 80-168. 2-param signature.

### N6: `_dataloader_init_kwargs_resolve_sampler` (fabric/utilities/data.py)
- **Kind**: Function
- **Repository Evidence**: Already defined at lines 171-243.

### N7: `_update_dataloader` (fabric/utilities/data.py) — base version
- **Kind**: Function
- **Repository Evidence**: Already defined at lines 75-77. 2-param signature. Imported by `fabric.py:55`.

### N8: `has_iterable_dataset`, `sized_len`, `has_len` (fabric/utilities/data.py)
- **Kind**: Functions
- **Repository Evidence**: Already defined at lines 44-72.

### N9: `_set_sampler_epoch`, `suggested_max_num_workers`, `_auto_add_worker_init_fn` (fabric/utilities/data.py)
- **Kind**: Functions
- **Repository Evidence**: Already defined at lines 246-459.

### N10: `_get_dataloader_init_args_and_kwargs` (pytorch/utilities/data.py) — pytorch version
- **Kind**: Function
- **Repository Evidence**: Interface Description 2 mandates 3-param signature with `mode`. Called by data_connector indirectly via `_update_dataloader`. Not yet defined.

### N11: `_is_dataloader_shuffled` (pytorch/utilities/data.py)
- **Kind**: Function
- **Repository Evidence**: Called at `data_connector.py:482`. Not yet defined (static issue). Interface Description 2 mandates.

### N12: `_update_dataloader` (pytorch/utilities/data.py) — pytorch version
- **Kind**: Function
- **Repository Evidence**: Called at `data_connector.py:192,266` with `mode=mode`. Not yet defined (static issue). Interface Description 2 mandates 3-param signature.

### N13: `extract_batch_size` (pytorch/utilities/data.py)
- **Kind**: Function
- **Repository Evidence**: Called at `result.py:349`. Private `_extract_batch_size` generator already defined at lines 43-59. Public function not yet defined (static issue). Interface Description 2 mandates.

### N14: `has_len_all_ranks` (pytorch/utilities/data.py)
- **Kind**: Function
- **Repository Evidence**: Called at `fit_loop.py:266,279,303`, `evaluation_loop.py:203`, `prediction_loop.py:162`. Imported in `test_dataloaders.py:41`. Not yet defined (static issue). Interface Description 2 mandates.

### N15: `_extract_batch_size` (pytorch/utilities/data.py)
- **Kind**: Generator function
- **Repository Evidence**: Already defined at lines 43-59. Used internally by N13.

### N16: `BType`, `warning_cache` (pytorch/utilities/data.py)
- **Kind**: Type alias, module-level variable
- **Repository Evidence**: Already defined at lines 38-40.

### N17: `DataConnector._process_dataloader` (data_connector.py)
- **Kind**: Method (caller)
- **Repository Evidence**: Lines ~180-195. Calls `_update_dataloader(dataloader, sampler, mode=mode)` and `_is_dataloader_shuffled(dataloader)`.

### N18: `Fabric._wrap_with_setup` (fabric.py)
- **Kind**: Method (caller)
- **Repository Evidence**: Line 1076. Calls `_replace_dunder_methods(DataLoader, "dataset")` and `_replace_dunder_methods(BatchSampler)`.

### N19: `_ResultCollection._extract_batch_size` (result.py)
- **Kind**: Method (caller)
- **Repository Evidence**: Line 349. Calls `extract_batch_size(self.batch)`.

### N20: Loop callers (fit_loop.py, evaluation_loop.py, prediction_loop.py)
- **Kind**: Methods (callers)
- **Repository Evidence**: Each calls `has_len_all_ranks(dl, trainer.strategy, allow_zero_length)`.

### Edges

### E1: N18 → N1 (CALL)
- **Kind**: CALL
- **Condition**: During `Fabric._wrap_with_setup` setup.
- **Transfer**: `base_cls=DataLoader, store_explicit_arg="dataset"` and `base_cls=BatchSampler, store_explicit_arg=None`.
- **Evidence**: `fabric.py:1076`.
- **Obligations**: R7, R14.

### E2: N17 → N12 (CALL)
- **Kind**: CALL
- **Condition**: Distributed sampler injection or prediction mode.
- **Transfer**: `dataloader, sampler, mode=mode` → `_update_dataloader`.
- **Evidence**: `data_connector.py:192,266`.
- **Obligations**: R9, R15.

### E3: N17 → N11 (CALL)
- **Kind**: CALL
- **Condition**: Non-training stage validation warning.
- **Transfer**: `dataloader` → `_is_dataloader_shuffled` → `bool`.
- **Evidence**: `data_connector.py:482`.
- **Obligations**: R8, R15.

### E4: N12 → N10 (CALL)
- **Kind**: CALL
- **Condition**: Always during `_update_dataloader` execution.
- **Transfer**: `dataloader, sampler, mode` → `_get_dataloader_init_args_and_kwargs` → `(args, kwargs)`.
- **Evidence**: Interface Description 2 structure mirrors fabric version.
- **Obligations**: R3, R9.

### E5: N10 → N6 (CALL)
- **Kind**: CALL
- **Condition**: Dataset is not `IterableDataset`.
- **Transfer**: `dataloader, sampler` → `_dataloader_init_kwargs_resolve_sampler` → `dict` of sampler kwargs.
- **Evidence**: Fabric version `data.py:138`.
- **Obligations**: R3, R4.

### E6: N6 → N3 (CALL)
- **Kind**: CALL
- **Condition**: Custom batch sampler with `__pl_saved_args`.
- **Transfer**: `"sampler", sampler, args, kwargs, default_kwargs, arg_names` → `_replace_value_in_saved_args` → `(success, args, kwargs)`.
- **Evidence**: `data.py:190`.
- **Obligations**: R6.

### E7: N6 → N2 (CALL)
- **Kind**: CALL
- **Condition**: Custom batch sampler with `__pl_saved_args`.
- **Transfer**: `batch_sampler, *args, **kwargs` → `_reinstantiate_wrapped_cls` → new batch_sampler instance.
- **Evidence**: `data.py:200`.
- **Obligations**: R5.

### E8: N12 → N2 (CALL) [for main DataLoader reconstruction]
- **Kind**: CALL
- **Condition**: Always when reconstructing wrapped DataLoader.
- **Transfer**: `dataloader, *dl_args, **dl_kwargs` → `_reinstantiate_wrapped_cls` → new DataLoader instance.
- **Evidence**: `data.py:77` (fabric version delegates to N2).
- **Obligations**: R5, R9.

### E9: N7 → N5 (CALL) [fabric base]
- **Kind**: CALL
- **Condition**: Always.
- **Transfer**: Same as E4 but 2-param.
- **Evidence**: `data.py:76`.
- **Obligations**: R3.

### E10: N7 → N2 (CALL) [fabric base]
- **Kind**: CALL
- **Condition**: Always.
- **Transfer**: Same as E8.
- **Evidence**: `data.py:77`.
- **Obligations**: R5.

### E11: N17 → N1 (CALL via data_connector)
- **Kind**: CALL
- **Condition**: `_request_dataloader` context setup in data_connector.
- **Transfer**: `DataLoader, "dataset"` and `BatchSampler` → `_replace_dunder_methods` context managers.
- **Evidence**: `data_connector.py:330`.
- **Obligations**: R7, R14.

### E12: N20 → N14 (CALL)
- **Kind**: CALL
- **Condition**: Determining batch count limits in training/validation/prediction loops.
- **Transfer**: `dataloader, strategy, allow_zero_length` → `has_len_all_ranks` → `TypeGuard[Sized]`.
- **Evidence**: `fit_loop.py:266,279`, `evaluation_loop.py:203`, `prediction_loop.py:162`.
- **Obligations**: R11, R15.

### E13: N19 → N13 (CALL)
- **Kind**: CALL
- **Condition**: When batch_size not pre-specified and logging epoch-level mean reduction metrics.
- **Transfer**: `self.batch` → `extract_batch_size` → `int`.
- **Evidence**: `result.py:349`.
- **Obligations**: R10, R15.

### E14: N13 → N15 (CALL)
- **Kind**: CALL
- **Condition**: Always (wrapping the generator).
- **Transfer**: `batch` → `_extract_batch_size` → first non-None yielded value.
- **Evidence**: N15 already defined, N13 must wrap it.
- **Obligations**: R10.

### E15: N14 → N8 (DATA)
- **Kind**: DATA (import dependency)
- **Condition**: Always.
- **Transfer**: `has_len_all_ranks` uses `has_len`, `sized_len`, `has_iterable_dataset` from fabric.
- **Evidence**: `test_dataloaders.py` import chain; `pytorch/utilities/data.py:26` already imports `has_iterable_dataset, sized_len`.
- **Obligations**: R11.

### E16: N1 → N4 (STATE)
- **Kind**: STATE (uses enum for tags)
- **Condition**: During `__setattr__`/`__delattr__` recording.
- **Transfer**: `_WrapAttrTag.SET`, `_WrapAttrTag.DEL` values recorded in `__pl_attrs_record`.
- **Evidence**: `test_data.py:293-298` asserts `_WrapAttrTag.SET`/`DEL` in `__pl_attrs_record`.
- **Obligations**: R7.

## L3. Verifiable Contracts

### C1: `_replace_dunder_methods` patches `__init__` on DataLoader and subclasses
- **Type**: State
- **Subject**: N1 (`_replace_dunder_methods`)
- **Relation**: When entering the context with `base_cls=DataLoader`, all subclasses of `DataLoader` (including those created after entry) have their `__init__` replaced with a wrapped version that stores `__pl_saved_args`, `__pl_saved_kwargs`, `__pl_saved_arg_names`, `__pl_saved_default_kwargs`.
- **Expected**: `datamodule.__pl_saved_args == args`, `__pl_saved_kwargs == kwargs`, `__pl_saved_arg_names` matches param names for positional args, `__pl_saved_default_kwargs` contains default values.
- **Evidence**: `test_data.py:208-230` parametrized test.
- **Observe**: FIELD_READ on `dataloader.__pl_saved_args`, `__pl_saved_kwargs`, `__pl_saved_arg_names`, `__pl_saved_default_kwargs`.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R7, R14.
- **Graph**: N1, N4, N18, E1, E11, E16.

### C2: `_replace_dunder_methods` saves explicit arg as private attribute
- **Type**: State
- **Subject**: N1
- **Relation**: When `store_explicit_arg="dataset"`, the wrapped `__init__` saves `dataset` argument value as `__dataset` on the instance.
- **Expected**: `dataloader.__dataset == dataset_value`.
- **Evidence**: `test_data.py:289` asserts `dataloader.__dataset == range(10)`.
- **Observe**: FIELD_READ on `dataloader.__dataset`.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R7.
- **Graph**: N1.

### C3: `_replace_dunder_methods` records setattr/delattr in `__pl_attrs_record`
- **Type**: State
- **Subject**: N1
- **Relation**: After initialization, `__setattr__` records `((attr_name, val), _WrapAttrTag.SET)` and `__delattr__` records `((attr_name,), _WrapAttrTag.DEL)` in `__pl_attrs_record`. Custom `__setattr__` in subclasses is preserved (called by wrapper).
- **Expected**: `__pl_attrs_record` contains ordered list of `_WrapAttrTag` tuples reflecting all post-init modifications. Custom `__setattr__` logic executes (e.g., `+2` offset).
- **Evidence**: `test_data.py:261-299` — custom `__setattr__`, set, del, suppressed del.
- **Observe**: FIELD_READ on `dataloader.__pl_attrs_record`.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R7.
- **Graph**: N1, N4, E16.

### C4: `_replace_dunder_methods` does not record attribute changes during `__init__`
- **Type**: State
- **Subject**: N1
- **Relation**: Attribute assignments within `__init__` are NOT recorded in `__pl_attrs_record` — only post-init modifications are tracked.
- **Expected**: Entries in `__pl_attrs_record` exclude `__init__`-internal attribute sets.
- **Evidence**: `test_data.py:293-297` — only post-init `custom_arg`, `my_arg`, `another_arg`, `dataset` deletion are recorded; `__init__` sets are absent.
- **Observe**: FIELD_READ on `dataloader.__pl_attrs_record` — verify absence of init-time attr sets.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R7.
- **Graph**: N1.

### C5: `_replace_dunder_methods` restores dunder methods on context exit
- **Type**: State
- **Subject**: N1
- **Relation**: On exiting the context manager, all patched `__init__`, `__setattr__`, `__delattr__` methods are restored to their originals. `__old__*` entries on base class `__dict__` are cleaned up.
- **Expected**: After `with` block, `cls.__init__` is the original function (identity check). Subclasses without own `__init__` in `__dict__` never had `__old__init__` stored in their own dict.
- **Evidence**: `test_data.py:53-77` (method restoration), `test_data.py:306-337` (dedicated restore test).
- **Observe**: FIELD_READ on `cls.__init__` before/after context (identity comparison). Check `"__old__init__" not in cls.__dict__` for subclasses without own `__init__`.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R7.
- **Graph**: N1.

### C6: `_reinstantiate_wrapped_cls` reconstructs instance with recorded attrs
- **Type**: State
- **Subject**: N2 (`_reinstantiate_wrapped_cls`)
- **Relation**: Given an instance with `__pl_attrs_record`, `__old__init__`, creates new instance of same type using the original `__init__` with provided args/kwargs, then replays `__pl_attrs_record` using `_WrapAttrTag.__call__`.
- **Expected**: New instance has same type, same attribute values (including custom `__setattr__` effects), same deleted attributes.
- **Evidence**: `test_data.py:299` — after `_update_dataloader`, new dataloader has `custom_arg=7`, `my_arg=10`, `another_arg=100`, no `dataset` attribute.
- **Observe**: FIELD_READ on returned instance — verify type equality, attribute values, attribute absence.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R5.
- **Graph**: N2, N4, E7, E8, E10.

### C7: `_replace_value_in_saved_args` replaces value in positional args
- **Type**: Behavior
- **Subject**: N3 (`_replace_value_in_saved_args`)
- **Relation**: If `replace_key` matches an entry in `arg_names`, replace the corresponding positional arg value. Returns `(True, new_args, kwargs)`.
- **Expected**: `args=(1,), kwargs={}, arg_names=["a"], replace_key="a", replace_value=2` → `(True, (2,), {})`.
- **Evidence**: `test_data.py:378` — parametric test `simple1`.
- **Observe**: RETURN_VALUE of `_replace_value_in_saved_args`.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R6.
- **Graph**: N3, E6.

### C8: `_replace_value_in_saved_args` replaces value in keyword args
- **Type**: Behavior
- **Subject**: N3
- **Relation**: If `replace_key` is in `kwargs`, replace its value. Returns `(True, args, new_kwargs)`.
- **Expected**: `args=(1,2,3), kwargs={"a":1}, arg_names=["b","c","d"], replace_key="a", replace_value=2` → `(True, (1,2,3), {"a":2})`.
- **Evidence**: `test_data.py:378` — `simple_kwargs`.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R6.
- **Graph**: N3.

### C9: `_replace_value_in_saved_args` adds from default_kwargs
- **Type**: Behavior
- **Subject**: N3
- **Relation**: If `replace_key` is in `default_kwargs` (but not in args or kwargs), add it to `kwargs`. Returns `(True, args, new_kwargs_with_added_key)`.
- **Expected**: `args=(1,2,3), kwargs={"a":1}, default_kwargs={"e":5}, replace_key="e", replace_value=2` → `(True, (1,2,3), {"a":1, "e":2})`.
- **Evidence**: `test_data.py:378` — `default_kwargs`.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R6.
- **Graph**: N3.

### C10: `_replace_value_in_saved_args` returns failure for missing key
- **Type**: Behavior
- **Subject**: N3
- **Relation**: If `replace_key` not found in arg_names, kwargs, or default_kwargs, return `(False, args, kwargs)`.
- **Expected**: Empty case: `(False, (), {})`.
- **Evidence**: `test_data.py:378` — `empty`.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R6.
- **Graph**: N3.

### C11: `_get_dataloader_init_args_and_kwargs` raises ValueError for non-DataLoader
- **Type**: Exception
- **Subject**: N10 (pytorch version)
- **Relation**: When `dataloader` is not a `DataLoader` subclass, raises `ValueError`.
- **Expected**: `ValueError` with message about needing to subclass `DataLoader`.
- **Evidence**: Fabric version `data.py:84-85`.
- **Observe**: EXCEPTION (ValueError).
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R3, R16.
- **Graph**: N10.

### C12: `_get_dataloader_init_args_and_kwargs` raises MisconfigurationException for missing attrs
- **Type**: Exception
- **Subject**: N10
- **Relation**: When required `__init__` arguments cannot be extracted from instance attributes and the dataloader was not wrapped, raises `MisconfigurationException` with missing attribute names.
- **Expected**: `MisconfigurationException` with message containing "missing attributes".
- **Evidence**: Fabric version `data.py:141-155`.
- **Observe**: EXCEPTION (MisconfigurationException).
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R3, R16.
- **Graph**: N10.

### C13: `_get_dataloader_init_args_and_kwargs` raises TypeError for missing kwargs in non-variadic signature
- **Type**: Exception
- **Subject**: N10
- **Relation**: When extracted kwargs don't fit the `__init__` signature and class has no `**kwargs`, raises `TypeError`.
- **Expected**: `TypeError` with "doesn't expose all its attributes in the `__init__` signature".
- **Evidence**: Fabric version `data.py:158-168`.
- **Observe**: EXCEPTION (TypeError).
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R3, R16.
- **Graph**: N10.

### C14: `_get_dataloader_init_args_and_kwargs` sets sampler=None for IterableDataset
- **Type**: Dataflow
- **Subject**: N10
- **Relation**: When `dataset` is `IterableDataset`, sets `batch_sampler=None` and `sampler=None` in returned kwargs.
- **Expected**: `dl_kwargs["sampler"] is None`, `dl_kwargs["batch_sampler"] is None`.
- **Evidence**: `test_data.py:542-548`.
- **Observe**: RETURN_VALUE inspection of `dl_kwargs`.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R3.
- **Graph**: N10.

### C15: `_is_dataloader_shuffled` returns True for RandomSampler
- **Type**: Behavior
- **Subject**: N11
- **Relation**: When dataloader uses `RandomSampler` (directly or via batch_sampler), returns `True`.
- **Expected**: `True`.
- **Evidence**: Interface Description 2 notes.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R8, R15.
- **Graph**: N11, N17, E3.

### C16: `_is_dataloader_shuffled` returns False for SequentialSampler
- **Type**: Behavior
- **Subject**: N11
- **Relation**: When dataloader uses `SequentialSampler`, returns `False`.
- **Expected**: `False`.
- **Evidence**: Interface Description 2 notes.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R8.
- **Graph**: N11.

### C17: `_is_dataloader_shuffled` returns False for IterableDataset
- **Type**: Behavior
- **Subject**: N11
- **Relation**: When dataloader wraps `IterableDataset`, returns `False` (shuffling not applicable).
- **Expected**: `False`.
- **Evidence**: Interface Description 2 notes.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R8.
- **Graph**: N11.

### C18: `_is_dataloader_shuffled` checks Lightning saved kwargs first
- **Type**: Behavior
- **Subject**: N11
- **Relation**: If dataloader has `__pl_saved_kwargs` and `__pl_saved_arg_names`, checks shuffle config from saved kwargs before inspecting samplers.
- **Expected**: Respects saved shuffle configuration.
- **Evidence**: Interface Description 2 notes.
- **Observe**: RETURN_VALUE when `__pl_saved_kwargs` contains shuffle information.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R8.
- **Graph**: N11.

### C19: `_update_dataloader` returns new DataLoader with replaced sampler
- **Type**: Dataflow
- **Subject**: N12
- **Relation**: Creates new `DataLoader` of same type with new sampler, preserving all other configurations.
- **Expected**: Returned dataloader is `isinstance(dataloader, DataLoader)`, same type as input, with new sampler.
- **Evidence**: `test_data.py:227,398,418,452,492`.
- **Observe**: RETURN_VALUE — check type, sampler attribute, batch_size preservation.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R9, R15.
- **Graph**: N12, N10, N2, E4, E8.

### C20: `_update_dataloader` handles prediction mode (drop_last=False)
- **Type**: Behavior
- **Subject**: N12
- **Relation**: When `mode=RunningStage.PREDICTING`, ensures `drop_last=False` so all samples are processed.
- **Expected**: Reconstructed dataloader has `drop_last=False` regardless of original setting.
- **Evidence**: Interface Description 2 notes: "When mode is RunningStage.PREDICTING, special handling is applied to ensure all samples are processed (e.g., drop_last=False)."
- **Observe**: FIELD_READ on returned DataLoader's `drop_last`.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R9.
- **Graph**: N12.

### C21: `extract_batch_size` returns int for tensor batch
- **Type**: Dataflow
- **Subject**: N13
- **Relation**: For a tensor batch of shape `(N, ...)`, returns `N`. For 0-d scalar tensor, returns `1`.
- **Expected**: `extract_batch_size(torch.randn(4, 3)) == 4`. `extract_batch_size(torch.tensor(1.0)) == 1`.
- **Evidence**: Existing `_extract_batch_size` generator logic at lines 44-48.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R10, R15.
- **Graph**: N13, N15, N19, E13, E14.

### C22: `extract_batch_size` returns int for nested structures
- **Type**: Dataflow
- **Subject**: N13
- **Relation**: For dict/list/tuple/dataclass batches containing tensors, recursively finds first tensor and returns its batch size.
- **Expected**: Returns correct batch size from nested tensor.
- **Evidence**: Existing `_extract_batch_size` lines 49-57 handles mappings, iterables, dataclasses.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R10.
- **Graph**: N13, N15.

### C23: `extract_batch_size` raises MisconfigurationException when no tensor found
- **Type**: Exception
- **Subject**: N13
- **Relation**: When no tensor exists in the batch structure, raises `MisconfigurationException`.
- **Expected**: `MisconfigurationException` raised.
- **Evidence**: Interface Description 2: "MisconfigurationException: If no valid batch size can be inferred".
- **Observe**: EXCEPTION (MisconfigurationException).
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R10.
- **Graph**: N13.

### C24: `extract_batch_size` warns on ambiguous batch sizes
- **Type**: Side-effect
- **Subject**: N13
- **Relation**: When multiple tensors with different batch sizes found, emits warning and uses first encountered size.
- **Expected**: Warning emitted, first batch size returned.
- **Evidence**: Interface Description 2: "When multiple tensors with different batch sizes are found, the function issues a warning".
- **Observe**: SIDE_EFFECT (warning) + RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R10.
- **Graph**: N13.

### C25: `has_len_all_ranks` returns False when no __len__ defined
- **Type**: Behavior
- **Subject**: N14
- **Relation**: If local dataloader doesn't have `__len__`, returns `False` immediately without cross-rank communication.
- **Expected**: `False`.
- **Evidence**: Interface Description 2: "If the local dataloader doesn't have `__len__` defined, the function returns False and skips all validation checks."
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R11, R15.
- **Graph**: N14, N20, E12.

### C26: `has_len_all_ranks` returns True for valid distributed lengths
- **Type**: Behavior
- **Subject**: N14
- **Relation**: When dataloader has `__len__` and cross-rank validation passes, returns `True` (as `TypeGuard[Sized]`).
- **Expected**: `True`.
- **Evidence**: `test_dataloaders.py:720`.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R11.
- **Graph**: N14.

### C27: `has_len_all_ranks` raises RuntimeError for zero local length with non-zero total
- **Type**: Exception
- **Subject**: N14
- **Relation**: When local length is 0 but total across ranks > 0 and `allow_zero_length_dataloader_with_multiple_devices=False`, raises `RuntimeError`.
- **Expected**: `RuntimeError`.
- **Evidence**: Interface Description 2.
- **Observe**: EXCEPTION (RuntimeError).
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R11.
- **Graph**: N14.

### C28: `has_len_all_ranks` warns on zero total length
- **Type**: Side-effect
- **Subject**: N14
- **Relation**: When total length across all ranks is zero, emits warning.
- **Expected**: Warning emitted.
- **Evidence**: Interface Description 2: "Issues warnings for various edge cases: When total length across all ranks is zero".
- **Observe**: SIDE_EFFECT (warning).
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R11.
- **Graph**: N14.

### C29: `has_len_all_ranks` warns on uneven batch distribution
- **Type**: Side-effect
- **Subject**: N14
- **Relation**: When batch lengths differ across ranks, emits warning.
- **Expected**: Warning about uneven distribution.
- **Evidence**: Interface Description 2: "When there's uneven batch length distribution across ranks".
- **Observe**: SIDE_EFFECT (warning).
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R11.
- **Graph**: N14.

### C30: Import boundary — `_replace_dunder_methods` resolved for fabric.py
- **Type**: Interface
- **Subject**: N1
- **Relation**: `from lightning.fabric.utilities.data import ... _replace_dunder_methods` is the import path used by `fabric.py`.
- **Expected**: Symbol `_replace_dunder_methods` exists in `lightning.fabric.utilities.data` and is a context-manager function.
- **Evidence**: `fabric.py:1076` uses it; `fabric.py:55` currently imports other symbols from same module but not `_replace_dunder_methods`.
- **Observe**: IMPORT_BOUNDARY — `from lightning.fabric.utilities.data import _replace_dunder_methods` succeeds.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R14.
- **Graph**: N1, N18, E1.

### C31: Import boundary — `_update_dataloader` resolved for data_connector.py
- **Type**: Interface
- **Subject**: N12
- **Relation**: `_update_dataloader` with 3-param signature must be importable by `data_connector.py` (currently no import statement for it).
- **Expected**: Symbol exists in `lightning.pytorch.utilities.data` and accepts `(dataloader, sampler, mode)`.
- **Evidence**: `data_connector.py:192,266` calls `_update_dataloader(dataloader, sampler, mode=mode)` — static issue reports no import.
- **Observe**: IMPORT_BOUNDARY — `from lightning.pytorch.utilities.data import _update_dataloader` succeeds, and `_update_dataloader(dl, sampler, mode=mode)` returns a DataLoader.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R15.
- **Graph**: N12, N17, E2.

### C32: Import boundary — `_is_dataloader_shuffled` resolved for data_connector.py
- **Type**: Interface
- **Subject**: N11
- **Relation**: `_is_dataloader_shuffled` must be importable by `data_connector.py`.
- **Expected**: Symbol exists in `lightning.pytorch.utilities.data` and accepts `dataloader` returning `bool`.
- **Evidence**: `data_connector.py:482` calls `_is_dataloader_shuffled(dataloader)` — static issue.
- **Observe**: IMPORT_BOUNDARY — `from lightning.pytorch.utilities.data import _is_dataloader_shuffled` succeeds.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R15.
- **Graph**: N11, N17, E3.

### C33: Import boundary — `extract_batch_size` resolved for result.py
- **Type**: Interface
- **Subject**: N13
- **Relation**: `extract_batch_size` must be importable by `result.py`.
- **Expected**: Symbol exists in `lightning.pytorch.utilities.data` and returns `int`.
- **Evidence**: `result.py:349` calls `extract_batch_size(self.batch)` — static issue.
- **Observe**: IMPORT_BOUNDARY — `from lightning.pytorch.utilities.data import extract_batch_size` succeeds.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R15.
- **Graph**: N13, N19, E13.

### C34: Import boundary — `has_len_all_ranks` resolved for loops
- **Type**: Interface
- **Subject**: N14
- **Relation**: `has_len_all_ranks` must be importable by `fit_loop.py`, `evaluation_loop.py`, `prediction_loop.py`.
- **Expected**: Symbol exists in `lightning.pytorch.utilities.data` accepting `(dataloader, strategy, allow_zero_length_dataloader_with_multiple_devices)`.
- **Evidence**: All three loops call `has_len_all_ranks(dl, trainer.strategy, allow_zero_length)` — static issue. `test_dataloaders.py:41` imports from `lightning.pytorch.utilities.data`.
- **Observe**: IMPORT_BOUNDARY — `from lightning.pytorch.utilities.data import has_len_all_ranks` succeeds.
- **Target**: `src/lightning/pytorch/utilities/data.py`
- **Obligations**: R15.
- **Graph**: N14, N20, E12.

### C35: `suggested_max_num_workers` returns at least 1
- **Type**: Behavior
- **Subject**: N9
- **Relation**: Returns `max(1, cpu_count // local_world_size - 1)`.
- **Expected**: Always `≥ 1`. Raises `ValueError` for `local_world_size < 1`.
- **Evidence**: `test_data.py` parametrized tests for various CPU/world_size combos.
- **Observe**: RETURN_VALUE.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R12.
- **Graph**: N9.

### C36: `_set_sampler_epoch` calls set_epoch on all unique samplers
- **Type**: Side-effect
- **Subject**: N9
- **Relation**: Calls `set_epoch(epoch)` on `dataloader.sampler` and `dataloader.batch_sampler.sampler` if callable. Uses `id()` dict for deduplication.
- **Expected**: `set_epoch` called once per unique sampler.
- **Evidence**: `test_data.py` mock tests.
- **Observe**: SIDE_EFFECT via mock assertion.
- **Target**: `src/lightning/fabric/utilities/data.py`
- **Obligations**: R13.
- **Graph**: N9.
