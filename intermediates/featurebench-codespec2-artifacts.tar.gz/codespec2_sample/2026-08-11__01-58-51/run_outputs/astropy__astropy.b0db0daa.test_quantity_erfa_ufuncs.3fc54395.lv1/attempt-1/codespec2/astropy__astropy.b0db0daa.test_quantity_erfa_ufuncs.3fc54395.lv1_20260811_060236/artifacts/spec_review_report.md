# Spec Review Report

## Evidence Reviewed

- **Task document**: primary oracle with two Interface Descriptions (ID1:
  `_iterable_helper`, `einsum`, `like_helper`; ID2: `StructuredUnit.__rlshift__`,
  `StructuredUnit.__rmul__`)
- **Semantic IR**: `/agent-logs/codespec2/.../semantic_ir.md` — 7 requirements (R1-R7),
  16 contracts (C1-C16), 16 graph nodes (N1-N16), 11 dependency edges (E1-E11)
- **Architecture spec**: `/agent-logs/codespec2/.../arch_spec.py` — 10 executable checks
  covering C15, C16, E1, E9, E10, E6, E7+E8, E3+E4, E5
- **Behavior spec**: `/agent-logs/codespec2/.../behavior_spec.py` — 16 executable checks
  covering C1-C14 plus boundary supplements
- **Static issues**: 4 relevant undefined symbols (`_as_quantities`, `_iterable_helper`,
  `_normalize_names`, `einsum`/`like_helper` not registered)
- **Static analysis**: confirms the same 4 missing symbols as compile-time gaps
- **Repository source files read**:
  - `/testbed/astropy/units/quantity_helper/function_helpers.py` (full file, call sites at
    lines 488, 498, 729, 735, 853, 867 for `_iterable_helper`; lines 910, 928, 935, 942,
    1048, 1095, 1154, 1433, 1445, 1515, 1623 for `_as_quantities`; `full_like` helper at
    line 343 as pattern for `like_helper`; `_as_quantity` at line 410; `_quantities2arrays`
    at line 436; `_quantity_out_as_array` at line 262)
  - `/testbed/astropy/units/structured.py` (full file; `_normalize_names` called at line
    145 but undefined; existing `__truediv__` at line 471 as pattern; no `__mul__`,
    `__rmul__`, or `__rlshift__` defined)
  - `/testbed/astropy/units/core.py` (`UnitBase.__rlshift__` at 346, `UnitBase.__rmul__` at
    324, `UnitBase.__mul__` at 304)
- **Repository tests read**:
  - `/testbed/astropy/units/tests/test_quantity_non_ufuncs.py`: `TestVariousProductFunctions::test_einsum`
    (lines 1415-1428), `InvariantUnitTestSetup::test_zeros_like` (line 341),
    `test_ones_like` (line 346), `test_empty_like` (line 329 with `subok=False` variant),
    `test_full_like` (line 350-356, pattern reference)
  - `/testbed/astropy/units/tests/test_structured.py`: `TestStructuredUnitArithmatic::test_multiplication`
    (lines 384-399), `TestStructuredUnitBasics::test_extreme_recursive_initialization`
    (lines 97-127), `TestStructuredUnitBasics::test_initialization_names_invalid_list_errors`
    (lines 128-141), `TestStructuredQuantity::test_initialization_by_shifting_to_unit`
    (lines 457-461), `TestStructuredQuantity::test_initialization_by_multiplication_with_unit`
    (lines 447-455), `TestStructuredQuantityFunctions::setup_class` (line 636-637 using `<<`),
    `TestStructuredQuantityFunctions::test_zeros_ones_like` (line 646-652)

## Rubric Scores

### Seed Rubric: Requirement Coverage

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | R1 `_iterable_helper` → C1, C2 traced in both specs | arch_spec `check_iterable_helper_call_chain` (E1), behavior_spec `check_C1_*` and `check_C2_*` | R1, C1, C2, E1 |
| **PASS** | R2 `einsum` → C3-C5, C15 traced in both specs | arch_spec `check_einsum_registered`, `check_einsum_call_chain`; behavior_spec `check_C3_*`, `check_C4_*`, `check_C5_*` | R2, C3, C4, C5, C15, E3, E4 |
| **PASS** | R3 `like_helper` → C6, C7, C16 traced in both specs | arch_spec `check_like_helper_registered`, `check_like_helper_call_chain`; behavior_spec `check_C6_*`, `check_C7_*` | R3, C6, C7, C16, E5 |
| **PASS** | R4 `__rlshift__` → C8, C9 traced | arch_spec `check_rlshift_call_chain`; behavior_spec `check_C8_*`, `check_C9_*` | R4, C8, C9, E6 |
| **PASS** | R5 `__rmul__` → C10, C11 traced | arch_spec `check_rmul_call_chain`; behavior_spec `check_C10_*`, `check_C11_*` | R5, C10, C11, E7, E8 |
| **PASS** | R6 `_as_quantities` → C12, E9 traced | arch_spec `check_as_quantities_call_chain`; behavior_spec `check_C12_*` | R6, C12, E9 |
| **PASS** | R7 `_normalize_names` → C13, C14, E10 traced | arch_spec `check_normalize_names_call_chain`; behavior_spec `check_C13_*`, `check_C14_*` | R7, C13, C14, E10 |
| **FAIL** | `StructuredUnit.__mul__` absent from IR and both specs despite repository test requiring it | `test_structured.py:387` calls `self.pv_unit * u.au` which resolves to `StructuredUnit.__mul__`; `__mul__` is not defined on `StructuredUnit` (inherits only from `object`) and not in any interface description or IR requirement | R5 (incomplete), C10 |

### Seed Rubric: Requirement Fidelity

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | C1 return structure: exact 4-tuple with typed elements | `check_C1_iterable_helper_return_structure` verifies tuple/dict/UnitBase/None types | C1 |
| **PASS** | C4 unit product: `m * (1/s) = m/s` matches repo test | `check_C4_einsum_unit_product` verifies matrix-mult and trace units exactly | C4 |
| **PASS** | C5 out identity: `result is o3` matches repo test pattern | `check_C5_einsum_out_parameter` asserts identity | C5 |
| **PASS** | C6 unit preservation: value and unit both checked | `check_C6_like_helper_preserves_unit` checks `o1.unit == u.kg` and `np.all(o1.value == 1.0)` | C6 |
| **FAIL** | C7 `subok=False` check only verifies type, not values | `check_C7_like_helper_subok_false` asserts `type(o3) is np.ndarray` but never checks that the array contains correct values (zeros or ones); a helper returning an empty/different ndarray would pass | C7, R3 |
| **PASS** | C13 exact nested-name transformation matches repo test | `check_C13_normalize_names_transformation` compares full recursive tuple/list structure against expected | C13 |
| **PASS** | C14 ValueError message matches repo parametrized test strings | `check_C14_normalize_names_invalid_entries` uses `pytest.raises(ValueError, match=...)` with exact `invalid entry {x}` pattern | C14 |

### Seed Rubric: Caller Binding and Architecture

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | C15: `np.einsum in FUNCTION_HELPERS` checked | `check_einsum_registered` imports `FUNCTION_HELPERS` and tests membership | C15 |
| **PASS** | C16: `np.ones_like`, `np.zeros_like` both in FUNCTION_HELPERS | `check_like_helper_registered` loops over both functions | C16 |
| **PASS** | E3+E4: public dispatch `np.einsum("ii", q1)` tested end-to-end | `check_einsum_call_chain` calls public numpy function and verifies Quantity return with unit | E3, E4, C4 |
| **PASS** | E5: public dispatch `np.ones_like(q)` tested end-to-end | `check_like_helper_call_chain` calls public numpy function and verifies Quantity with unit and values | E5, C6 |
| **FAIL** | Arch spec references non-existent test class `TestUfuncsHelpers::test_einsum` | Comment in `check_einsum_registered` says "Repository test: test_quantity_non_ufuncs.py::TestUfuncsHelpers::test_einsum" but actual test class is `TestVariousProductFunctions` (line ~1415); same error appears for `check_like_helper_registered` referencing `TestUfuncsHelpers::test_zeros_like` when actual class is `InvariantUnitTestSetup` | C15, C16 (documentation only) |
| **PASS** | E6: `<<` operator creates Quantity via public dispatch | `check_rlshift_call_chain` uses structured array `<<` StructuredUnit and verifies Quantity | E6, C8 |
| **PASS** | E7+E8: `__rmul__` tested with both unit multiplication and array-to-Quantity | `check_rmul_call_chain` tests `u.kg * su` and `values * su` independently | E7, E8, C10, C11 |

### Seed Rubric: Dataflow and Lifecycle

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | C1: arrays are ndarray views, not Quantity | `check_C1_iterable_helper_return_structure` checks `isinstance(a, np.ndarray)` | C1 |
| **PASS** | C1: kwargs["out"] replaced with ndarray view | `check_C1_iterable_helper_with_out` checks `isinstance(kwargs["out"], np.ndarray)` | C1 |
| **PASS** | C11: `values * su` returns Quantity with correct unit | `check_C11_rmul_creates_quantity` checks `isinstance(result_q, Quantity)` | C11 |
| **FAIL** | C9: `NotImplemented` for non-array but no ndarray re-raise test | `check_C9_rlshift_returns_notimplemented` uses a string value to trigger the failure path, but IR R4 acceptance requires "unless m is an ndarray, in which case re-raise" — this distinct path is not tested | C9, R4 |
| **FAIL** | No pass-through test for non-`out` kwargs in `_iterable_helper` | Callers like `concatenate` pass `axis=axis, **kwargs`; behavior_spec never verifies non-`out` kwargs survive the call | C1, R1 |

### Seed Rubric: Failure and Compatibility

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | C2: non-Quantity out raises NotImplementedError | `check_C2_iterable_helper_bad_out` passes `out=np.array(...)` and expects `NotImplementedError` | C2 |
| **PASS** | C3: non-string subscripts raises ValueError | `check_C3_einsum_non_string_subscripts` passes Quantity as first arg, expects `ValueError` | C3 |
| **PASS** | einsum `out` that is not Quantity raises NotImplementedError | `check_einsum_non_quantity_out` passes `out=np.zeros(1)`, expects `NotImplementedError` | C5 |
| **FAIL** | No `NotImplemented` failure test for `StructuredUnit.__rmul__` | IR R5 acceptance says "Returns NotImplemented if the operation cannot be performed"; neither spec tests a failing `__rmul__` scenario (e.g., `object() * su` or incompatible type) | R5, C10, C11 |
| **FAIL** | No test for `__rmul__` with string unit argument despite repo test demanding it | Repository test `test_structured.py:394` uses `"AU" * self.pv_unit`; only `check_C10_rmul_field_multiplication` tests `u.kg * su` (Unit, not str) | C10, R5 |

### Seed Rubric: Static-Issue Closure

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | `_as_quantities` undefined → covered by C12, E9 checks | Behavior spec `check_C12`, arch spec `check_as_quantities_call_chain` | R6 |
| **PASS** | `_iterable_helper` undefined → covered by C1, C2, E1 checks | Behavior spec `check_C1_*`, arch spec `check_iterable_helper_call_chain` | R1 |
| **PASS** | `_normalize_names` undefined → covered by C13, C14, E10 checks | Behavior spec `check_C13_*`, `check_C14_*`, arch spec `check_normalize_names_call_chain` | R7 |
| **PASS** | `erfa.py` issues out of scope (explicitly R8) | Both specs note this in comments | N/A |
| **PASS** | `get_err_str` out of scope | Not part of task interfaces | N/A |

### Seed Rubric: Repository-Test Alignment

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | einsum: trace, matrix-mult, `out=`, single-operand identity all tested | `check_C4`, `check_C5`, `check_einsum_single_operand` mirror repo test lines 1417-1428 | C4, C5 |
| **PASS** | like_helper: `subok=True` preserves unit, `subok=False` returns ndarray | `check_C6`, `check_C7` mirror `test_empty_like` at line 337-339 | C6, C7 |
| **PASS** | _normalize_names: exact nested result and parametrized invalid entries | `check_C13`, `check_C14` mirror repo tests at lines 97-141 | C13, C14 |
| **PASS** | rlshift: `values << su` creates Quantity | `check_C8` mirrors `setup_class` at line 636 | C8 |
| **FAIL** | __rmul__ with string units not tested in specs | Repo test line 394 `"AU" * self.pv_unit` is uncovered; spec only tests `Unit` objects | C10 |
| **FAIL** | __rmul__ error cases (`self.pv_unit * self.pv_unit` → TypeError, `"s,s" * self.pv_unit` → TypeError) not tested | Repo test lines 395-398 test TypeError on StructuredUnit×StructuredUnit and invalid string multiplication; spec has no error-path coverage for __rmul__ | R5, C10, C11 |

### Seed Rubric: Oracle Strength

| Score | Rubric | Evidence | Affected IDs |
|-------|--------|----------|--------------|
| **PASS** | C5: identity check `result is o3` | Exact object identity, not just value equality | C5 |
| **PASS** | C13: exact recursive structure comparison | Full tuple/list nesting compared with `==` | C13 |
| **PASS** | C14: `match=` with exact invalid entry string | Uses `pytest.raises(ValueError, match=...)` | C14 |
| **FAIL** | C7: type-only assertion is weak | `assert type(o3) is np.ndarray` would pass for ANY ndarray; should verify values are correct (zeros/ones) and shape matches | C7 |
| **FAIL** | C12: only two-element tuple tested | `_as_quantities` is used with up to 5+ arguments in production code (line 1095 `_as_quantities(*sample)`); single-arg and multi-arg paths are not tested | C12, R6 |
| **WARN** | C10: checks `u.kg * su` but not the reverse `su * u.kg` | Multiplication commutativity is part of the task but `su * unit` requires `__mul__` which is unspecified | C10 |

## Findings

### Finding 1: `missing_requirement` — `StructuredUnit.__mul__` not specified but required by repository tests

- **Affected IDs**: R5, C10 (incomplete coverage)
- **Static issue**: N/A (detected via repository test analysis)
- **Repository evidence**:
  - `/testbed/astropy/units/tests/test_structured.py` line 387: `pv_times_au = self.pv_unit * u.au`
  - Line 392: `pv_times_au2 = self.pv_unit * "au"`
  - `StructuredUnit` inherits only from `object`; no `__mul__` is defined
  - Without `__mul__`, `pv_unit * u.au` would try `UnitBase.__rmul__(u.au, pv_unit)` which
    checks `hasattr(pv_unit, "unit")` (False for StructuredUnit), then tries
    `Quantity(pv_unit, unit=u.au)` which fails, returning `NotImplemented`
  - Result: `TypeError` at runtime
- **Gap**: Interface Description 2 specifies only `__rlshift__` and `__rmul__`. The
  `__rmul__` docstring says "delegates to the __mul__ method" but `__mul__` is never
  defined. The IR R5 covers `__rmul__` (C10, C11) but does not mention `__mul__`.
  Neither spec tests `su * unit` (only `unit * su`).
- **Rework instruction**: Either (a) add `StructuredUnit.__mul__` to Interface Description
  2 and IR as R5a with corresponding contracts, or (b) make `__rmul__` handle the
  reversed case internally and clarify that `__mul__` is not needed. The repository
  pattern (`UnitBase` has both `__mul__` and `__rmul__`) favors option (a). Add to both
  specs: `check_mul_field_multiplication` and `check_mul_string_unit` with `su * unit`
  and `su * "unit_str"` public calls.

### Finding 2: `weak_constraint` — C7 `like_helper` with `subok=False` does not verify result values

- **Affected IDs**: C7, R3
- **Static issue**: N/A
- **Repository evidence**: `/testbed/astropy/units/tests/test_quantity_non_ufuncs.py` line
  338-339: `np.empty_like(self.q, subok=False)` test checks `type(o3) is np.ndarray`
  but the values are uninitialized for `empty_like`. However, for `ones_like` and
  `zeros_like` (the functions `like_helper` actually serves), the repository test at
  line 342-344 verifies values: `o2 = np.zeros_like(a=self.q); assert_array_equal(o2,
  self.q * 0.0)`.
- **Gap**: The behavior spec `check_C7_like_helper_subok_false` only checks
  `assert type(o3) is np.ndarray`. A helper that returns a wrong-sized or
  incorrectly-valued ndarray would pass this check.
- **Rework instruction**: Change `check_C7_like_helper_subok_false` to also verify that
  `np.all(o3 == 0.0)` (for `zeros_like`) or `np.all(o3 == 1.0)` (for `ones_like`),
  matching the shape of the input.

### Finding 3: `weak_constraint` — C9 does not test ndarray re-raise path for `__rlshift__`

- **Affected IDs**: C9, R4
- **Static issue**: N/A
- **Repository evidence**: `/testbed/astropy/units/core.py` line 346-354: `UnitBase.__rlshift__`
  catches `Exception` and re-raises if `m` is an `np.ndarray`. The IR R4 acceptance
  explicitly requires: "unless m is an ndarray, in which case re-raise."
- **Gap**: `check_C9_rlshift_returns_notimplemented` tests with `values = "not an array"`
  which is a string (not ndarray), so it correctly tests the `NotImplemented` path. But
  the ndarray re-raise path is completely untested — a helper that silently returns
  `NotImplemented` for ndarray failures would pass all behavioral checks.
- **Rework instruction**: Add a test that passes an ndarray with incompatible structure
  (e.g., a 1D ndarray to a 2-field structured unit) and verifies the exception is
  re-raised (not swallowed into `NotImplemented`).

### Finding 4: `requirement_misread` — Arch spec references wrong test class names

- **Affected IDs**: C15, C16 (documentation only)
- **Static issue**: N/A
- **Repository evidence**:
  - `test_einsum` is in `TestVariousProductFunctions` (line ~1415 of
    `test_quantity_non_ufuncs.py`), not `TestUfuncsHelpers`
  - `test_zeros_like` and `test_ones_like` are in `InvariantUnitTestSetup` (lines
    341-347), not `TestUfuncsHelpers`
- **Gap**: Arch spec comments cite `test_quantity_non_ufuncs.py::TestUfuncsHelpers::test_einsum`
  and `::test_zeros_like` / `::test_ones_like`. `TestUfuncsHelpers` does not exist in
  the test file. This does not affect runtime correctness but breaks traceability.
- **Rework instruction**: Correct the comment references to
  `TestVariousProductFunctions::test_einsum` and
  `InvariantUnitTestSetup::test_zeros_like` / `test_ones_like`.

### Finding 5: `weak_constraint` — No failure-path test for `StructuredUnit.__rmul__`

- **Affected IDs**: R5, C10, C11
- **Static issue**: N/A
- **Repository evidence**: `/testbed/astropy/units/tests/test_structured.py` lines 395-398:
  ```python
  with pytest.raises(TypeError):
      self.pv_unit * self.pv_unit
  with pytest.raises(TypeError):
      "s,s" * self.pv_unit
  ```
  These test that StructuredUnit×StructuredUnit and invalid-string×StructuredUnit
  raise `TypeError`.
- **Gap**: Neither spec tests a failing `__rmul__` scenario. The IR says "Returns
  NotImplemented if the operation cannot be performed" but there is no behavioral
  observation that validates this path. The `check_C10_rmul_field_multiplication` and
  `check_C11_rmul_creates_quantity` only test the success paths.
- **Rework instruction**: Add to behavior spec: `check_rmul_typeerror_structured` with
  `StructuredUnit * StructuredUnit` expecting `TypeError`, and `check_rmul_typeerror_bad_string`
  with `"invalid" * su` expecting `TypeError` (matching repo test pattern).

### Finding 6: `weak_constraint` — `_as_quantities` return test too narrow

- **Affected IDs**: C12, R6
- **Static issue**: `_as_quantities` is used but not defined (`static_issues.md`)
- **Repository evidence**: `function_helpers.py` line 1095: `sample = _as_quantities(*sample)`
  with variadic unpacking; line 1623: `seqarrays = _as_quantities(*seqarrays)` with
  arbitrary-length inputs. The function is called with 1-5+ arguments throughout the
  codebase.
- **Gap**: `check_C12_as_quantities_return` only tests `_as_quantities(a, b)` with
  exactly two arguments, one with unit and one without. Single-argument calls and
  3+-argument calls (common in production) are untested. No test verifies behavior with
  StructuredUnit inputs or pre-existing Quantity inputs.
- **Rework instruction**: Add parameterized test for `_as_quantities` with 1, 2, and 3+
  arguments, and verify each return element is a Quantity preserving original units.

### Finding 7: `weak_constraint` — `__rmul__` with string unit arguments not tested

- **Affected IDs**: C10, R5
- **Static issue**: N/A
- **Repository evidence**: Line 394: `au_times_pv2 = "AU" * self.pv_unit` — expects
  correct structured unit multiplication.
- **Gap**: `check_C10_rmul_field_multiplication` only tests `u.kg * su` (Unit object).
  The repository pattern in `StructuredUnit.__truediv__` (line 472-475) converts string
  arguments via `Unit(other, parse_strict="silent")`; `__rmul__` must do the same. The
  spec does not exercise this code path.
- **Rework instruction**: Add `check_rmul_string_unit` that tests `"kg" * su` and
  verifies result matches `u.kg * su`.

## Decision

**Decision: REWORK**

Six findings (one `missing_requirement`, one `requirement_misread`, four
`weak_constraint`) exist. The most critical is Finding 1 (`__mul__` missing),
which would cause repository test failures. The remaining findings represent
gaps that could allow incorrect implementations to pass spec verification.
