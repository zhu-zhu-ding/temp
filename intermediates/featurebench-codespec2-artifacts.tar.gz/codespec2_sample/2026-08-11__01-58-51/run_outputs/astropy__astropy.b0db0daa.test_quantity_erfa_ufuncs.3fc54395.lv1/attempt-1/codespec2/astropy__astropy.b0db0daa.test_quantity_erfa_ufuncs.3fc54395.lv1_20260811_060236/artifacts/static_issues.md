## static issue

- **`astropy/units/core.py`** (1):
  - ? 'get_err_str' is used but not defined or imported in this file
- **`astropy/units/quantity_helper/erfa.py`** (2):
  - ? 'check_structured_unit' is used but not defined or imported in this file
  - ? 'ldbody_unit' is used but not defined or imported in this file
- **`astropy/units/quantity_helper/function_helpers.py`** (2):
  - ? '_as_quantities' is used but not defined or imported in this file
  - ? '_iterable_helper' is used but not defined or imported in this file
- **`astropy/units/structured.py`** (1):
  - ? '_normalize_names' is used but not defined or imported in this file
