# Static Analysis

## Scope
- Repository: `/testbed`
- Declared interfaces: 6
- `astropy/units/quantity_helper/function_helpers.py`: `_iterable_helper` (function)
- `astropy/units/quantity_helper/function_helpers.py`: `einsum` (function)
- `astropy/units/quantity_helper/function_helpers.py`: `like_helper` (function)
- `astropy/units/structured.py`: `StructuredUnit` (class)
- `astropy/units/structured.py`: `StructuredUnit.__rlshift__` (method)
- `astropy/units/structured.py`: `StructuredUnit.__rmul__` (method)

## Findings
## static issue

- **`astropy/units/core.py`** (1):
  - ? 'get_err_str' is used but not defined or imported in this file
- **`astropy/units/quantity_helper/erfa.py`** (2):
  - ? 'check_structured_unit' is used but not defined or imported in this file
  - ? 'ldbody_unit' is used but not defined or imported in this file
- **`astropy/units/quantity_helper/function_helpers.py`** (2):
  - ? '_as_quantities' is used but not defined or imported in this file
  - ? '_iterable_helper' is used but not defined or imported in this file
- **`astropy/units/structured.py`** (1):
  - ? '_normalize_names' is used but not defined or imported in this file

## Use
- Requirement Compile: use findings to identify dependency, caller-binding, and compatibility risks.
- Test Spec: compile relevant findings into runtime checks; static evidence alone is not a behavior proof.
