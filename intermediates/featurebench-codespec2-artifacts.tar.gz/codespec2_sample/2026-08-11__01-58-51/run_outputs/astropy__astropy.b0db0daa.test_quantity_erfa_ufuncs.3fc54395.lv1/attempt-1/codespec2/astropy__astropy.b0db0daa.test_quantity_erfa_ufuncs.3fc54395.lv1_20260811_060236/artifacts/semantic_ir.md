# Semantic IR

## L1. Requirement Obligations

### R1: `_iterable_helper` — convert variadic arguments and handle `out`
- **Type**: Dataflow / Interface
- **Statement**: Implement `_iterable_helper(*args, **kwargs)` in
  `/testbed/astropy/units/quantity_helper/function_helpers.py`.  The function
  processes an iterable of array-like positional arguments through
  `_quantities2arrays` to obtain value arrays and a common unit, extracts the
  optional `out` keyword argument (which must be a `Quantity` or `None`),
  converts the output Quantity to a plain ndarray view, and returns
  `(arrays, kwargs, unit, out)` where `kwargs` is updated with the array-view
  of `out` when present.
- **Task Evidence**: Interface Description 1, path and docstring.
- **Acceptance**:
  - All positional arguments are converted to arrays in compatible units via
    `_quantities2arrays`.
  - If `out` is passed as a keyword and is a `Quantity`, `kwargs["out"]` is
    replaced with `out.view(np.ndarray)` and the original `out` Quantity is
    returned in position 3.
  - If `out` is `None`, position 3 returns `None`.
  - If `out` is not `None` and not a `Quantity`, `NotImplementedError` is
    raised.
  - Returns `(arrays: tuple, kwargs: dict, unit: Unit, out: Quantity | None)`.
- **Repository Evidence**:
  - Called at lines 488, 498, 729, 735, 853, 867 of `function_helpers.py`.
  - Always destructured as `arrays, kwargs, unit, out = _iterable_helper(...)`.
  - `_quantities2arrays` is defined at line 435 of the same file.
  - `_quantity_out_as_array` at line 262 shows the pattern for `out` handling.
  - Static analysis confirms `_iterable_helper` is used but not defined.
- **Uncertainty**: None — call-site destructuring and `_quantity_out_as_array`
  fully define the contract.

### R2: `einsum` — Einstein summation with unit propagation
- **Type**: Interface / Dataflow
- **Statement**: Register a `@function_helper` for `np.einsum` that converts
  all operands after the subscripts string to `Quantity` via `_as_quantities`,
  computes the result unit as the product of all operand units, handles an
  optional `out` Quantity, and passes the raw value arrays and remaining kwargs
  to `np.einsum`.
- **Task Evidence**: Interface Description 1, einsum docstring.
- **Acceptance**:
  - First operand must be a string (subscripts); if not, `ValueError` is
    raised.
  - Remaining operands (and `out` if given) are converted to `Quantity` via
    `_as_quantities`.
  - Result unit = product of all operand units (each operand's unit multiplied
    together).
  - If `out` is a `Quantity`, it is converted to an ndarray view and passed to
    `np.einsum`; the original `out` is returned as the 4th element.
  - If `out` is not a `Quantity` and not `None`, `NotImplementedError`.
  - Returns `(arrays, kwargs, unit, out)` compatible with the function-helper
    protocol.
- **Repository Evidence**:
  - Tests at `/testbed/astropy/units/tests/test_quantity_non_ufuncs.py` lines
    1415-1428 verify `einsum` with single operand, trace, two-operand
    contraction, and `out=` parameter.
  - `einsum_path` is in `SUBCLASS_SAFE_FUNCTIONS` (line 109) but `einsum`
    itself is absent from all helper sets.
  - Masked helpers at `/testbed/astropy/utils/masked/function_helpers.py` line
    181 list `np.einsum` as subclass-safe, confirming it *can* work but
    Quantity needs explicit unit handling.
  - Static analysis confirms `_as_quantities` is used but not defined.
- **Uncertainty**: Whether `out` must be handled via `_iterable_helper` or
  inline; call-site pattern `_as_quantities(*operands)` is the simpler path
  and matches `dot_like` (line 907).

### R3: `like_helper` — array creation with unit preservation
- **Type**: Interface / Dataflow
- **Statement**: Register a `@function_helper(helps={np.ones_like,
  np.zeros_like})` named `like_helper(a, *args, **kwargs)` that extracts
  `subok` from kwargs (default `True`), preserves the input Quantity's unit
  when `subok=True`, returns `None` unit (dimensionless) when `subok=False`,
  and passes the ndarray view of `a` plus remaining args/kwargs to the
  underlying numpy function.
- **Task Evidence**: Interface Description 1, like_helper docstring.
- **Acceptance**:
  - `subok` is extracted from `kwargs` (default `True`).
  - When `subok=True`, unit = `a.unit`.
  - When `subok=False`, unit = `None` (dimensionless ndarray result).
  - `a` is converted to `a.view(np.ndarray)` before passing to numpy.
  - `out` is always `None`.
  - Returns `(args, kwargs, unit, None)`.
- **Repository Evidence**:
  - Tests at lines 341-347 verify `np.zeros_like` and `np.ones_like` work with
    Quantity.
  - `np.empty_like` (line 96) is in `SUBCLASS_SAFE_FUNCTIONS`, but
    `np.ones_like` and `np.zeros_like` are not in any helper set.
  - Comment at lines 246-255 explains why `ones_like`/`zeros_like` need
    special handling: filling with unity requires unit awareness.
  - `full_like` (line 343) follows the same `subok` pattern.
  - Static analysis does not flag this symbol as undefined — it needs to be
    created.
- **Uncertainty**: None — `full_like` at line 343 provides the exact pattern.

### R4: `StructuredUnit.__rlshift__` — value << unit operator
- **Type**: Interface / Compatibility
- **Statement**: Implement `StructuredUnit.__rlshift__(self, m)` so that
  `value << structured_unit` creates a structured `Quantity` via
  `Quantity(m, self, copy=False, subok=True)`, wrapped in try/except that
  returns `NotImplemented` on failure (unless `m` is an ndarray, in which case
  re-raise).
- **Task Evidence**: Interface Description 2, `__rlshift__` docstring.
- **Acceptance**:
  - `m` is any array-like value compatible with the structured unit.
  - Returns a `Quantity` with value `m` and unit `self`.
  - On failure, returns `NotImplemented` (or re-raises for ndarray).
- **Repository Evidence**:
  - `Unit.__rlshift__` at `/testbed/astropy/units/core.py` line 346 follows
    the identical pattern.
  - `FunctionUnitBase.__rlshift__` at `/testbed/astropy/units/function/core.py`
    line 317 follows the same pattern.
  - `StructuredUnit` does not inherit from `UnitBase` (MRO confirmed:
    `object`), so it needs its own implementation.
  - Tests use `value << structured_unit` extensively (test_structured.py
    lines 458, 529, 535, 542, 636-637, 651, 684, 687, 711, 715-716, 719,
    730).
  - Currently fails with `AttributeError` because `__rlshift__` is missing.
- **Uncertainty**: None — the pattern is identical to `Unit.__rlshift__`.

### R5: `StructuredUnit.__rmul__` — right-multiplication operator
- **Type**: Interface / Compatibility
- **Statement**: Implement `StructuredUnit.__rmul__(self, other)` to handle:
  (a) `other` is a string → parse as unit and multiply each field;
  (b) `other` is a `UnitBase` → multiply each field by `other`;
  (c) `other` is array-like → create a structured `Quantity` via
  `Quantity(other, self, copy=False, subok=True)`;
  (d) otherwise return `NotImplemented`.
- **Task Evidence**: Interface Description 2, `__rmul__` docstring.
- **Acceptance**:
  - String `other`: parsed via `Unit(other, parse_strict="silent")`, then
    `self.__mul__(other)` or equivalent.
  - `UnitBase` `other`: each field multiplied by `other`, returning new
    `StructuredUnit`.
  - Array-like `other`: returns `Quantity(other, self, ...)`.
  - `NotImplemented` on any unhandled type or parse failure.
- **Repository Evidence**:
  - `StructuredUnit.__truediv__` at line 471 follows the same dispatch pattern
    (string → parse, UnitBase → per-field operation, else
    `NotImplemented`).
  - `Unit.__rmul__` at `/testbed/astropy/units/core.py` line 324 handles
    string and array-like cases identically.
  - No `__mul__` method exists on `StructuredUnit`, so `__rmul__` must handle
    all cases directly.
- **Uncertainty**: Whether `__mul__` should also be implemented (for `unit *
  other` where `other` is a unit). The task only requires `__rmul__`, but
  symmetry with `__truediv__` suggests `__mul__` would be expected. The
  docstring states `__rmul__` delegates to `__mul__` for unit multiplication,
  implying `__mul__` must also exist. **Resolution**: both `__mul__` and
  `__rmul__` are implied by the task description.

### R6: `_as_quantities` — batch conversion to Quantity
- **Type**: Dataflow / Dependency
- **Statement**: Implement `_as_quantities(*args)` in
  `/testbed/astropy/units/quantity_helper/function_helpers.py` that converts
  each positional argument to a `Quantity` via `_as_quantity`, returning a
  tuple of Quantity objects.
- **Task Evidence**: Implicit in all function helpers that need to coerce
  multiple arguments; static analysis flags it as undefined.
- **Acceptance**:
  - Each arg is passed through `_as_quantity`.
  - Returns a tuple of `Quantity` objects (one per input arg).
  - If any conversion fails, `NotImplementedError` propagates from
    `_as_quantity`.
- **Repository Evidence**:
  - `_as_quantity` (singular) is defined at line 410.
  - `_as_quantities` (plural) is called at lines 326, 910, 928, 935, 942,
    1048, 1095, 1154, 1433, 1445, 1515, 1623 — always with multiple arguments
    and the result destructured as e.g. `a, b = _as_quantities(a, b)`.
- **Uncertainty**: None — it is a trivial tuple-map over `_as_quantity`.

### R7: `_normalize_names` — validate and normalize field-name tuples
- **Type**: State / Validation
- **Statement**: Implement `_normalize_names(names)` in
  `/testbed/astropy/units/structured.py` that recursively validates and
  normalizes a nested tuple of field names. For each inner tuple, it creates a
  list `[concatenated_name, normalized_inner_tuple]`. Validates that list
  entries have exactly 2 elements `[str, tuple]`, strings are non-empty, and
  elements are only strings or tuples (no `None`, no empty tuples, no nested
  lists).
- **Task Evidence**: Static analysis flags `_normalize_names` as used but not
  defined.
- **Acceptance**:
  - Top-level: returns a tuple with the same length as input.
  - For each element that is a tuple: returns a list
    `["".join(inner_strings), recursively_normalized_tuple]`.
  - For each element that is a string: returns unchanged.
  - Raises `ValueError(f"invalid entry {invalid}")` for: lists not of length
    2, second element not a tuple, empty tuples, `None` entries, empty
    strings.
- **Repository Evidence**:
  - Called at line 145 of `structured.py` in `StructuredUnit.__new__`.
  - Test at lines 88-127 (`test_extreme_recursive_initialization`) shows the
    expected transformation: `("t", ("p", "v", ("h", ("d1", "d2"))), "l")` →
    `('t', ['pvhd1d2', ('p', 'v', ['hd1d2', ('h', ['d1d2', ('d1',
    'd2')])])], 'l')`.
  - Invalid-entry tests at lines 127-142 verify the error messages.
  - Comment at line 228 in `field_names` shows the expected structure:
    `([name, unit.field_names] if ... else name)`.
- **Uncertainty**: Edge case of single-element inner tuples not explicitly
  tested; treating them consistently with the concatenation rule.

### R8: `get_err_str` — error formatting helper (out of scope for this task)
- **Type**: Compatibility / Dependency
- **Statement**: `get_err_str` is used at lines 520-521 of
  `/testbed/astropy/units/core.py` but not defined or imported. This is a
  static issue but not part of the interface descriptions for this task.
- **Task Evidence**: Static analysis only; not in any interface description.
- **Acceptance**: N/A — this symbol is outside the scope of the three
  interface descriptions.
- **Repository Evidence**:
  - Used in `UnitConversionError` formatting at line 520-521.
- **Uncertainty**: This may be a pre-existing bug unrelated to this task.
  Dispositioned as out of scope.

### R9: `check_structured_unit` — ERFA structured unit validator (out of scope)
- **Type**: Compatibility / Dependency
- **Statement**: `check_structured_unit` is used in
  `/testbed/astropy/units/quantity_helper/erfa.py` but not defined. Not part
  of this task's interface descriptions.
- **Task Evidence**: Static analysis only.
- **Acceptance**: N/A — out of scope.
- **Repository Evidence**: Used at lines 167, 174, 194, 195, 204, 254, 259,
  264, 322 of erfa.py.
- **Uncertainty**: Out of scope for this task.

### R10: `ldbody_unit` — ERFA light-deflection body unit factory (out of scope)
- **Type**: Compatibility / Dependency
- **Statement**: `ldbody_unit` is used in
  `/testbed/astropy/units/quantity_helper/erfa.py` but not defined. Not part
  of this task's interface descriptions.
- **Task Evidence**: Static analysis only.
- **Acceptance**: N/A — out of scope.
- **Repository Evidence**: Used at lines 315, 435, 456.
- **Uncertainty**: Out of scope for this task.

## L2. Functional Design Graph

### N1: `function_helpers.py` module
- **Kind**: Module / Namespace
- **Repository Evidence**: `/testbed/astropy/units/quantity_helper/function_helpers.py`

### N2: `structured.py` module
- **Kind**: Module / Namespace
- **Repository Evidence**: `/testbed/astropy/units/structured.py`

### N3: `_iterable_helper`
- **Kind**: Function (internal helper)
- **Repository Evidence**: Used but undefined; declared in Interface
  Description 1.

### N4: `einsum` helper
- **Kind**: Function (FUNCTION_HELPERS entry)
- **Repository Evidence**: Interface Description 1; tests at
  test_quantity_non_ufuncs.py:1415.

### N5: `like_helper`
- **Kind**: Function (FUNCTION_HELPERS entry)
- **Repository Evidence**: Interface Description 1; tests at
  test_quantity_non_ufuncs.py:341-347.

### N6: `StructuredUnit.__rlshift__`
- **Kind**: Method (dunder operator)
- **Repository Evidence**: Interface Description 2; tests throughout
  test_structured.py.

### N7: `StructuredUnit.__rmul__`
- **Kind**: Method (dunder operator)
- **Repository Evidence**: Interface Description 2.

### N8: `_as_quantities`
- **Kind**: Function (internal helper)
- **Repository Evidence**: Used but undefined; implicit dependency of R2.

### N9: `_normalize_names`
- **Kind**: Function (internal helper)
- **Repository Evidence**: Used but undefined; implicit dependency of
  StructuredUnit.__new__.

### N10: `_quantities2arrays`
- **Kind**: Function (internal helper, existing)
- **Repository Evidence**: Defined at line 435 of function_helpers.py.

### N11: `_as_quantity`
- **Kind**: Function (internal helper, existing)
- **Repository Evidence**: Defined at line 410 of function_helpers.py.

### N12: `_quantity_out_as_array`
- **Kind**: Function (internal helper, existing)
- **Repository Evidence**: Defined at line 262 of function_helpers.py.

### N13: `np.einsum` (numpy)
- **Kind**: External function
- **Repository Evidence**: Standard numpy.

### N14: `np.ones_like` / `np.zeros_like` (numpy)
- **Kind**: External functions
- **Repository Evidence**: Standard numpy.

### N15: `Quantity` constructor
- **Kind**: Class constructor
- **Repository Evidence**: `/testbed/astropy/units/quantity.py`.

### N16: `FUNCTION_HELPERS` dict
- **Kind**: Registry (dict)
- **Repository Evidence**: Module-level dict in function_helpers.py.

### N17: `Quantity.__array_function__` dispatch
- **Kind**: Protocol entry point
- **Repository Evidence**: `/testbed/astropy/units/quantity.py`.

### E1: `_iterable_helper` -> `_quantities2arrays`
- **Kind**: CALL
- **Condition**: Always (for positional args processing).
- **Transfer**: Passes `*args` to `_quantities2arrays`; receives `(arrays,
  unit)`.
- **Evidence**: Call-site patterns at lines 488, 853.
- **Obligations**: R1.

### E2: `_iterable_helper` -> `_quantity_out_as_array`
- **Kind**: CALL
- **Condition**: When `out` kwarg is a `Quantity`.
- **Transfer**: Passes `out` Quantity; receives ndarray view for kwargs.
- **Evidence**: Pattern from `_quantity_out_as_array` at line 262.
- **Obligations**: R1.

### E3: `einsum` -> `_as_quantities`
- **Kind**: CALL
- **Condition**: Always (for all operands after subscripts).
- **Transfer**: Passes variable operands; receives tuple of Quantity objects.
- **Evidence**: Pattern from `dot_like` at line 907.
- **Obligations**: R2, R6.

### E4: `einsum` -> `np.einsum`
- **Kind**: CALL
- **Condition**: After unit extraction.
- **Transfer**: Passes value arrays and updated kwargs.
- **Evidence**: Standard numpy delegation pattern.
- **Obligations**: R2.

### E5: `like_helper` -> `np.ones_like` / `np.zeros_like`
- **Kind**: CALL (via FUNCTION_HELPERS dispatch)
- **Condition**: When `np.ones_like` or `np.zeros_like` is called on Quantity.
- **Transfer**: Receives `a, *args, **kwargs`; returns helper tuple.
- **Evidence**: `full_like` at line 343 provides the pattern.
- **Obligations**: R3.

### E6: `StructuredUnit.__rlshift__` -> `Quantity`
- **Kind**: CALL
- **Condition**: When `value << structured_unit` is executed.
- **Transfer**: Passes `(m, self, copy=False, subok=True)` to Quantity
  constructor.
- **Evidence**: `Unit.__rlshift__` at core.py:346.
- **Obligations**: R4.

### E7: `StructuredUnit.__rmul__` -> `Unit` (parser)
- **Kind**: CALL
- **Condition**: When `other` is a string.
- **Transfer**: Parses string to unit.
- **Evidence**: `StructuredUnit.__truediv__` at line 471.
- **Obligations**: R5.

### E8: `StructuredUnit.__rmul__` -> `Quantity`
- **Kind**: CALL
- **Condition**: When `other` is array-like.
- **Transfer**: Passes `(other, self, ...)` to Quantity constructor.
- **Evidence**: `Unit.__rmul__` at core.py:324.
- **Obligations**: R5.

### E9: `_as_quantities` -> `_as_quantity`
- **Kind**: CALL
- **Condition**: For each positional argument.
- **Transfer**: Maps `_as_quantity` over `*args`.
- **Evidence**: `_as_quantity` at line 410.
- **Obligations**: R6.

### E10: `StructuredUnit.__new__` -> `_normalize_names`
- **Kind**: CALL
- **Condition**: When `names` is a non-dtype, non-StructuredUnit tuple.
- **Transfer**: Passes raw names tuple; receives normalized tuple.
- **Evidence**: Line 145 of structured.py.
- **Obligations**: R7.

### E11: `FUNCTION_HELPERS` registry -> `np.einsum`, `np.ones_like`, `np.zeros_like`
- **Kind**: STATE (registry binding)
- **Condition**: Module load time.
- **Transfer**: `function_helper` decorator adds entries to `FUNCTION_HELPERS`
  dict keyed by numpy function.
- **Evidence**: `function_helper` decorator at line 188.
- **Obligations**: R2, R3.

### E12: `Quantity.__array_function__` -> `FUNCTION_HELPERS`
- **Kind**: CONTROL / CALL
- **Condition**: When a numpy function is called on Quantity arguments.
- **Transfer**: Looks up function in `FUNCTION_HELPERS`, calls helper,
  processes result through `_result_as_quantity`.
- **Evidence**: `/testbed/astropy/units/quantity.py` lines 657, 1935, 2001.
- **Obligations**: R2, R3.

### E13: `StructuredUnit.__rlshift__` <- Python runtime (operator dispatch)
- **Kind**: CONTROL
- **Condition**: When left operand's `__lshift__` returns `NotImplemented`.
- **Transfer**: Python calls `StructuredUnit.__rlshift__` with the left
  operand as `m`.
- **Evidence**: Python data model.
- **Obligations**: R4.

### E14: `StructuredUnit.__rmul__` <- Python runtime (operator dispatch)
- **Kind**: CONTROL
- **Condition**: When left operand's `__mul__` returns `NotImplemented`.
- **Transfer**: Python calls `StructuredUnit.__rmul__` with the left operand
  as `other`.
- **Evidence**: Python data model.
- **Obligations**: R5.

## L3. Verifiable Contracts

### C1: `_iterable_helper` converts args and returns 4-tuple
- **Type**: Dataflow
- **Subject**: N3 (`_iterable_helper`)
- **Relation**: Return value structure
- **Expected**: `_iterable_helper(q1, q2, out=out_q)` returns
  `(arrays, kwargs, unit, out)` where `arrays` is a tuple of ndarrays with
  compatible units, `kwargs` contains `out` as ndarray view, `unit` is the
  common unit, and `out` is the original Quantity.
- **Evidence**: Call-site destructuring at lines 488, 853; `_quantities2arrays`
  at line 435; `_quantity_out_as_array` at line 262.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `_iterable_helper`
- **Obligations**: R1
- **Graph**: N3 → N10, N3 → N12

### C2: `_iterable_helper` raises NotImplementedError for non-Quantity out
- **Type**: Failure
- **Subject**: N3 (`_iterable_helper`)
- **Relation**: Exception on invalid `out`
- **Expected**: If `out` is not `None` and not a `Quantity`,
  `NotImplementedError` is raised.
- **Evidence**: `_quantity_out_as_array` at line 262 raises
  `NotImplementedError`.
- **Observe**: EXCEPTION
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `_iterable_helper`
- **Obligations**: R1
- **Graph**: N3 → N12

### C3: `einsum` validates subscripts is a string
- **Type**: Failure
- **Subject**: N4 (`einsum` helper)
- **Relation**: Exception for non-string subscripts
- **Expected**: If the first operand is not a string, `ValueError` is raised.
- **Evidence**: Interface Description 1 docstring and tests.
- **Observe**: EXCEPTION
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `einsum`
- **Obligations**: R2
- **Graph**: N4

### C4: `einsum` computes product unit from all operands
- **Type**: Dataflow
- **Subject**: N4 (`einsum` helper)
- **Relation**: Result unit equals product of operand units
- **Expected**: For `einsum('ij,jk->ik', q1 * u.m, q2 * u.s)`, result unit is
  `u.m * u.s`.
- **Evidence**: Test at line 1423: `np.einsum("ij,jk", q1, q2)` where q1 has
  unit m and q2 has unit 1/s, result unit is m/s.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `einsum`
- **Obligations**: R2
- **Graph**: N4 → N8 → N11

### C5: `einsum` handles `out` parameter
- **Type**: State / Side-effect
- **Subject**: N4 (`einsum` helper)
- **Relation**: Output written to `out` Quantity
- **Expected**: When `out=o3` is passed, result is written into `o3` and
  `result is o3` evaluates to `True`.
- **Evidence**: Test at line 1426: `result = np.einsum("ij,jk", q1, q2,
  out=o3); assert result is o3`.
- **Observe**: SIDE_EFFECT (in-place mutation) + RETURN_VALUE (identity)
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `einsum`
- **Obligations**: R2
- **Graph**: N4

### C6: `like_helper` preserves unit when subok=True
- **Type**: Dataflow
- **Subject**: N5 (`like_helper`)
- **Relation**: Unit preservation
- **Expected**: `np.ones_like(q)` returns a Quantity with the same unit as `q`
  and all values equal to 1.
- **Evidence**: Tests at lines 341-347: `np.zeros_like(a=self.q)` works and
  `assert_array_equal(o2, self.q * 0.0)`.
- **Observe**: RETURN_VALUE (via `_result_as_quantity`)
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `like_helper`
- **Obligations**: R3
- **Graph**: N5 → N14

### C7: `like_helper` returns dimensionless when subok=False
- **Type**: Dataflow
- **Subject**: N5 (`like_helper`)
- **Relation**: No unit propagation
- **Expected**: `np.ones_like(q, subok=False)` returns a plain ndarray (no
  unit).
- **Evidence**: Test at line 339 for `empty_like` with `subok=False`.
- **Observe**: RETURN_VALUE (type is `np.ndarray`, not `Quantity`)
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `like_helper`
- **Obligations**: R3
- **Graph**: N5

### C8: `StructuredUnit.__rlshift__` creates Quantity
- **Type**: Dataflow
- **Subject**: N6 (`StructuredUnit.__rlshift__`)
- **Relation**: Returns Quantity with correct value and unit
- **Expected**: `values << su` returns a Quantity where `result.unit == su`
  and field values match `values`.
- **Evidence**: Tests at line 636-637: `cls.q_pv = cls.pv << cls.pv_unit`,
  line 651: `func(self.pv) << self.pv_unit`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/structured.py`:
  `StructuredUnit.__rlshift__`
- **Obligations**: R4
- **Graph**: N6 → N15

### C9: `StructuredUnit.__rlshift__` returns NotImplemented on failure
- **Type**: Failure / Compatibility
- **Subject**: N6 (`StructuredUnit.__rlshift__`)
- **Relation**: Python operator fallback
- **Expected**: On any exception other than from ndarray, returns
  `NotImplemented`.
- **Evidence**: `Unit.__rlshift__` at core.py:346 pattern.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/structured.py`:
  `StructuredUnit.__rlshift__`
- **Obligations**: R4
- **Graph**: N6

### C10: `StructuredUnit.__rmul__` multiplies fields by unit
- **Type**: Dataflow
- **Subject**: N7 (`StructuredUnit.__rmul__`)
- **Relation**: Per-field unit multiplication
- **Expected**: `u.kg * su` where `su = StructuredUnit((u.m, u.s))` returns
  `StructuredUnit((u.kg * u.m, u.kg * u.s))`.
- **Evidence**: Interface Description 2 docstring example.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/structured.py`:
  `StructuredUnit.__rmul__`
- **Obligations**: R5
- **Graph**: N7

### C11: `StructuredUnit.__rmul__` creates Quantity from array-like
- **Type**: Dataflow
- **Subject**: N7 (`StructuredUnit.__rmul__`)
- **Relation**: Quantity creation from value × unit
- **Expected**: `values * su` returns a `Quantity` with value `values` and
  unit `su`.
- **Evidence**: Interface Description 2 docstring: `type(result)` is
  `<class 'astropy.units.quantity.Quantity'>`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/structured.py`:
  `StructuredUnit.__rmul__`
- **Obligations**: R5
- **Graph**: N7 → N15

### C12: `_as_quantities` returns tuple of Quantity objects
- **Type**: Dataflow
- **Subject**: N8 (`_as_quantities`)
- **Relation**: Type conversion
- **Expected**: `_as_quantities(a, b)` returns a tuple `(Quantity_a,
  Quantity_b)`.
- **Evidence**: Call-site destructuring at lines 910, 928: `a, b =
  _as_quantities(a, b)`.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `_as_quantities`
- **Obligations**: R6
- **Graph**: N8 → N11

### C13: `_normalize_names` transforms nested names correctly
- **Type**: Dataflow
- **Subject**: N9 (`_normalize_names`)
- **Relation**: Input-output transformation
- **Expected**: `_normalize_names(("t", ("p", "v", ("h", ("d1", "d2"))),
  "l"))` returns `('t', ['pvhd1d2', ('p', 'v', ['hd1d2', ('h', ['d1d2',
  ('d1', 'd2')])])], 'l')`.
- **Evidence**: Test at lines 88-127.
- **Observe**: RETURN_VALUE
- **Target**: `/testbed/astropy/units/structured.py`: `_normalize_names`
- **Obligations**: R7
- **Graph**: N9

### C14: `_normalize_names` raises ValueError on invalid entries
- **Type**: Failure
- **Subject**: N9 (`_normalize_names`)
- **Relation**: Validation error
- **Expected**: For invalid entries like `["p", "v"]` (list without tuple
  second element), `()` (empty tuple), `None`, `""` (empty string), raises
  `ValueError(f"invalid entry {invalid}")`.
- **Evidence**: Parametrized test at lines 127-142.
- **Observe**: EXCEPTION
- **Target**: `/testbed/astropy/units/structured.py`: `_normalize_names`
- **Obligations**: R7
- **Graph**: N9

### C15: `einsum` is registered in FUNCTION_HELPERS
- **Type**: Interface / Import boundary
- **Subject**: N4 (`einsum` helper)
- **Relation**: Registry membership
- **Expected**: `np.einsum in FUNCTION_HELPERS` evaluates to `True`.
- **Evidence**: `function_helper` decorator mechanism at line 188.
- **Observe**: FIELD_READ (FUNCTION_HELPERS dict membership)
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `FUNCTION_HELPERS`
- **Obligations**: R2
- **Graph**: N4 → N16

### C16: `like_helper` is registered for `np.ones_like` and `np.zeros_like`
- **Type**: Interface / Import boundary
- **Subject**: N5 (`like_helper`)
- **Relation**: Registry membership
- **Expected**: `np.ones_like in FUNCTION_HELPERS` and `np.zeros_like in
  FUNCTION_HELPERS` both evaluate to `True`.
- **Evidence**: `function_helper(helps={np.ones_like, np.zeros_like})`
  decorator.
- **Observe**: FIELD_READ (FUNCTION_HELPERS dict membership)
- **Target**: `/testbed/astropy/units/quantity_helper/function_helpers.py`:
  `FUNCTION_HELPERS`
- **Obligations**: R3
- **Graph**: N5 → N16
