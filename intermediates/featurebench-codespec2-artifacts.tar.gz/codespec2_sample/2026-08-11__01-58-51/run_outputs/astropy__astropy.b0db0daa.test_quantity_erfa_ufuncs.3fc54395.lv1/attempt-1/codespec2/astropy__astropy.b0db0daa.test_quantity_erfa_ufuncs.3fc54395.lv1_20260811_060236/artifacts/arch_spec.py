"""
Architecture spec: verify public scope, import/dependency binding,
graph connectivity, real CALL/CONTROL paths, and dataflow.

Each check_* function demonstrates that a required code path is
wired correctly at runtime — caller binding, registry membership,
dispatch, and inter-function dataflow.

Contracts covered: C1, C12, C15, C16, and dependency edges
E1-E11 from the semantic IR, plus __mul__ (Finding 1).
"""

import numpy as np

from astropy.units.quantity_helper.function_helpers import (
    FUNCTION_HELPERS,
    _iterable_helper,
    _as_quantities,
    _as_quantity,
    _quantities2arrays,
)


# ── C15: einsum is registered in FUNCTION_HELPERS ──────────────────────────
# R2 / C15 / N4→N16
# Repository test: test_quantity_non_ufuncs.py::TestVariousProductFunctions::test_einsum
# Perspective: registry-membership — the @function_helper decorator must
#   have added np.einsum to FUNCTION_HELPERS so that Quantity's
#   __array_function__ dispatch can locate the helper.
# Source: function_helpers.py FUNCTION_HELPERS dict
def check_einsum_registered():
    assert np.einsum in FUNCTION_HELPERS, (
        f"np.einsum not found in FUNCTION_HELPERS; "
        f"keys present: {sorted(FUNCTION_HELPERS.keys(), key=str)}"
    )
    print("PASS: C15 — np.einsum registered in FUNCTION_HELPERS")


# ── C16: like_helper registered for np.ones_like, np.zeros_like ──────────
# R3 / C16 / N5→N16
# Repository test: test_quantity_non_ufuncs.py::InvariantUnitTestSetup::test_zeros_like
#   and test_ones_like
# Perspective: registry-membership for both functions under a single helper.
# Source: function_helpers.py FUNCTION_HELPERS dict
def check_like_helper_registered():
    for func in (np.ones_like, np.zeros_like):
        assert func in FUNCTION_HELPERS, (
            f"{func.__name__} not in FUNCTION_HELPERS"
        )
    print("PASS: C16 — np.ones_like and np.zeros_like registered in FUNCTION_HELPERS")


# ── C15+C16: helpers are callable and return expected signature ────────────
# R2/R3 / C15/C16 — supplemental connectivity proof
# Perspective: the registered helper values are callable functions.
# Source: function_helpers.py FUNCTION_HELPERS
def check_helpers_are_callable():
    for func in (np.einsum, np.ones_like, np.zeros_like):
        helper = FUNCTION_HELPERS[func]
        assert callable(helper), f"FUNCTION_HELPERS[{func.__name__}] is not callable"
    print("PASS: C15/C16 — all registered helpers are callable")


# ── E1: _iterable_helper → _quantities2arrays (CALL) ───────────────────────
# R1 / C1 / N3→N10
# Repository test: no direct test exists for _iterable_helper alone;
#   it is exercised indirectly via concatenate/choose/select/nanmedian.
# Perspective: caller-binding — when _iterable_helper is invoked, it
#   must delegate to _quantities2arrays and produce a valid 4-tuple.
# Source: function_helpers.py _iterable_helper
def check_iterable_helper_call_chain():
    import astropy.units as u
    q1 = np.array([1.0, 2.0, 3.0]) * u.m
    q2 = np.array([4.0, 5.0, 6.0]) * u.m
    arrays, kwargs, unit, out = _iterable_helper(q1, q2)
    # Structural contract: 4-tuple return
    assert isinstance(arrays, tuple), f"arrays is {type(arrays)}, not tuple"
    assert isinstance(kwargs, dict), f"kwargs is {type(kwargs)}, not dict"
    # unit must be a Unit (not None for non-dimensionless inputs)
    from astropy.units import UnitBase
    assert isinstance(unit, UnitBase), f"unit is {type(unit)}, not UnitBase"
    assert out is None  # no out was passed
    # arrays should be ndarray views in compatible units
    for arr in arrays:
        assert isinstance(arr, np.ndarray), f"array element is {type(arr)}, not ndarray"
    assert len(arrays) == 2
    print("PASS: E1/C1 — _iterable_helper delegates to _quantities2arrays, returns 4-tuple")


# ── E9: _as_quantities → _as_quantity (CALL) ───────────────────────────────
# R6 / C12 / N8→N11
# Repository test: exercised by dot_like at line 910, solve at line 928, etc.
# Perspective: caller-binding with real Quantity conversion.
# Source: function_helpers.py _as_quantities
def check_as_quantities_call_chain():
    import astropy.units as u
    from astropy.units import Quantity
    a = np.array([1.0, 2.0]) * u.m
    b = np.array([3.0, 4.0]) * u.s
    result = _as_quantities(a, b)
    assert isinstance(result, tuple), f"_as_quantities returned {type(result)}, not tuple"
    assert len(result) == 2
    for q in result:
        assert isinstance(q, Quantity), f"element is {type(q)}, not Quantity"
    assert result[0].unit == u.m
    assert result[1].unit == u.s
    print("PASS: E9/C12 — _as_quantities returns tuple of Quantity objects")


# ── E10: StructuredUnit.__new__ → _normalize_names (CALL) ──────────────────
# R7 / C13 / N→N9
# Repository test: test_structured.py::TestStructuredUnitBasics::test_extreme_recursive_initialization
#   and test_initialization_names_invalid_list_errors
# Perspective: caller-binding — verify that StructuredUnit.__new__
#   invokes _normalize_names and that the result feeds into field_names.
# Source: structured.py StructuredUnit.__new__
def check_normalize_names_call_chain():
    import astropy.units as u
    from astropy.units import StructuredUnit
    from astropy.units.structured import _normalize_names

    # Direct call to _normalize_names — proves it exists and is callable
    raw = ("t", ("p", "v", ("h", ("d1", "d2"))), "l")
    result = _normalize_names(raw)
    assert isinstance(result, tuple), f"_normalize_names returned {type(result)}, not tuple"
    assert len(result) == 3, f"expected 3 top-level names, got {len(result)}"

    # Verify that StructuredUnit.__new__ routes through _normalize_names
    # by constructing with tuple names (the path at structured.py:145)
    su = StructuredUnit("(m, m/s), s", (("p", "v"), "t"))
    assert isinstance(su, StructuredUnit)
    # Names should be normalized: the inner ("p","v") becomes ["pv", ("p","v")]
    # and the outer names become a tuple with list element
    field_names = su.field_names
    assert len(field_names) == 2
    print("PASS: E10/C13 — _normalize_names exists, is callable, and feeds StructuredUnit.__new__")


# ── E6: StructuredUnit.__rlshift__ → Quantity (CALL) ───────────────────────
# R4 / C8 / N6→N15
# Repository test: test_structured.py::TestStructuredQuantityFunctions::setup_class
#   (cls.q_pv = cls.pv << cls.pv_unit)
# Perspective: public-entry caller-binding with real Quantity dispatch.
# Source: structured.py StructuredUnit.__rlshift__
def check_rlshift_call_chain():
    import astropy.units as u
    from astropy.units import StructuredUnit, Quantity
    import numpy as np

    # Use dtype to avoid _normalize_names emptiness
    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.m / u.s), dt)

    values = np.array([(10.0, 5.0), (20.0, 8.0)], dtype=dt)
    result = values << su
    assert isinstance(result, Quantity), f"result is {type(result)}, not Quantity"
    print("PASS: E6/C8 — StructuredUnit.__rlshift__ creates Quantity via << operator")


# ── E7+E8: StructuredUnit.__rmul__ dispatch (CALL) ─────────────────────────
# R5 / C10+C11 / N7→Unit, N7→N15
# Repository test: test_structured.py::TestStructuredUnitArithmatic::test_multiplication
#   (au_times_pv = u.au * self.pv_unit)
# Perspective: public-entry caller-binding — verify __rmul__ dispatches
#   correctly for unit multiplication (C10) and Quantity creation (C11).
# Source: structured.py StructuredUnit.__rmul__
def check_rmul_call_chain():
    import astropy.units as u
    from astropy.units import StructuredUnit, Quantity
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)

    # C10: unit * structured_unit → per-field multiplication
    result_unit = u.kg * su
    assert isinstance(result_unit, StructuredUnit), (
        f"u.kg * su returned {type(result_unit)}, not StructuredUnit"
    )
    assert result_unit['p'] == u.kg * u.m
    assert result_unit['v'] == u.kg * u.s

    # C11: array-like * structured_unit → Quantity
    values = np.array([(1.0, 2.0), (3.0, 4.0)], dtype=dt)
    result_q = values * su
    assert isinstance(result_q, Quantity), (
        f"values * su returned {type(result_q)}, not Quantity"
    )
    print("PASS: E7+E8/C10+C11 — __rmul__ dispatches per-field multiplication and Quantity creation")


# ── __mul__: StructuredUnit.__mul__ → per-field multiplication (CALL) ───────
# R5 (extended) / C10 / Finding 1
# Repository test: test_structured.py::TestStructuredUnitArithmatic::test_multiplication
#   (pv_times_au = self.pv_unit * u.au)
# Perspective: public-entry caller-binding — verify __mul__ dispatches
#   correctly for unit multiplication (structured_unit * unit) and string
#   conversion (structured_unit * "string").
# Source: structured.py StructuredUnit.__mul__
def check_mul_call_chain():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)

    # structured_unit * regular unit → per-field multiplication
    result_unit = su * u.kg
    assert isinstance(result_unit, StructuredUnit), (
        f"su * u.kg returned {type(result_unit)}, not StructuredUnit"
    )
    assert result_unit['p'] == u.m * u.kg
    assert result_unit['v'] == u.s * u.kg

    # structured_unit * string → string parsed as Unit, per-field multiplication
    result_str = su * "kg"
    assert isinstance(result_str, StructuredUnit), (
        f"su * 'kg' returned {type(result_str)}, not StructuredUnit"
    )
    assert result_str['p'] == u.m * u.kg
    assert result_str['v'] == u.s * u.kg
    print("PASS: __mul__ — StructuredUnit.__mul__ dispatches per-field multiplication and string parsing")


# ── E3+E4: einsum → _as_quantities → np.einsum chain ───────────────────────
# R2 / C4 / N4→N8→N13
# Repository test: test_quantity_non_ufuncs.py::TestVariousProductFunctions::test_einsum
# Perspective: caller-binding through FUNCTION_HELPERS dispatch.
# Source: function_helpers.py einsum helper
def check_einsum_call_chain():
    import astropy.units as u
    q1 = np.arange(9.0).reshape(3, 3) * u.m
    # The public call goes through Quantity.__array_function__
    # which looks up FUNCTION_HELPERS[np.einsum] and calls the helper.
    result = np.einsum("ii", q1)
    from astropy.units import Quantity
    assert isinstance(result, Quantity), f"einsum result is {type(result)}, not Quantity"
    assert result.unit == u.m, f"unit is {result.unit}, expected m"
    print("PASS: E3+E4/C4 — einsum public call produces Quantity with correct unit")


# ── E5: like_helper → np.ones_like / np.zeros_like ─────────────────────────
# R3 / C6 / N5→N14
# Repository test: test_quantity_non_ufuncs.py::InvariantUnitTestSetup::test_zeros_like
#   and test_structured.py::TestStructuredQuantityFunctions::test_zeros_ones_like
# Perspective: caller-binding through FUNCTION_HELPERS dispatch.
# Source: function_helpers.py like_helper
def check_like_helper_call_chain():
    import astropy.units as u
    q = np.array([1.0, 2.0, 3.0]) * u.kg
    o1 = np.ones_like(q)
    from astropy.units import Quantity
    assert isinstance(o1, Quantity), f"ones_like result is {type(o1)}, not Quantity"
    assert o1.unit == u.kg, f"unit is {o1.unit}, expected kg"
    assert np.all(o1.value == 1.0)
    print("PASS: E5/C6 — like_helper preserves unit when subok=True via public dispatch")


# ═══════════════════════════════════════════════════════════════════════════
# Static-issue closure
# ═══════════════════════════════════════════════════════════════════════════

# static_issues.md reports:
# - '_as_quantities' used but not defined/imported in function_helpers.py
#   → covered by check_as_quantities_call_chain which proves it exists and works
# - '_iterable_helper' used but not defined/imported in function_helpers.py
#   → covered by check_iterable_helper_call_chain which proves it exists and works
# - '_normalize_names' used but not defined/imported in structured.py
#   → covered by check_normalize_names_call_chain which proves it exists and works
# - erfa.py issues ('check_structured_unit', 'ldbody_unit') → out of scope
#   for this task (not part of this task's interfaces)
# - core.py 'get_err_str' → out of scope (not part of this task's interfaces)


def main():
    check_einsum_registered()
    check_like_helper_registered()
    check_helpers_are_callable()
    check_iterable_helper_call_chain()
    check_as_quantities_call_chain()
    check_normalize_names_call_chain()
    check_rlshift_call_chain()
    check_rmul_call_chain()
    check_mul_call_chain()
    check_einsum_call_chain()
    check_like_helper_call_chain()
    print("ALL ARCHITECTURE CHECKS PASSED")


if __name__ == "__main__":
    main()
