"""
Behavior spec: verify return values, field values, types, ordering,
defaults, state transitions, errors, side effects, compatibility,
and boundary cases.

Each check_* function demonstrates that a required behavioral contract
holds — exact outputs, exception semantics, unit propagation, and
operator compatibility.

Contracts covered: C1-C14 from the semantic IR, plus __mul__ (Finding 1),
__rmul__ failures (Finding 5), __rlshift__ ndarray re-raise (Finding 3),
and strengthened subok=False (Finding 2).
"""

import numpy as np
import pytest


# ═══════════════════════════════════════════════════════════════════════════
# C1: _iterable_helper converts args and returns 4-tuple
# ═══════════════════════════════════════════════════════════════════════════
# R1 / C1 / N3
# Repository test: None directly; exercised by concatenate/choose/select
#   (function_helpers.py lines 488, 498, 729, 735, 853, 867).
# Perspective: dataflow — exact return structure with type/value ordering.
# Source: function_helpers.py _iterable_helper
def check_C1_iterable_helper_return_structure():
    import astropy.units as u
    from astropy.units.quantity_helper.function_helpers import _iterable_helper

    q1 = np.array([1.0, 2.0, 3.0]) * u.m
    q2 = np.array([4.0, 5.0, 6.0]) * u.m
    arrays, kwargs, unit, out = _iterable_helper(q1, q2)

    # Return is always a 4-tuple
    assert len((arrays, kwargs, unit, out)) == 4, "must return exactly 4 items"
    # arrays is tuple of ndarrays
    assert isinstance(arrays, tuple)
    for a in arrays:
        assert isinstance(a, np.ndarray)
    # kwargs is dict
    assert isinstance(kwargs, dict)
    # unit is a Unit
    from astropy.units import UnitBase
    assert isinstance(unit, UnitBase)
    # out is None when not passed
    assert out is None
    # arrays have compatible units (all converted to first argument's unit)
    assert unit == u.m
    print("PASS: C1 — _iterable_helper returns (arrays, kwargs, unit, out) structure")


# ═══════════════════════════════════════════════════════════════════════════
# C1a: _iterable_helper with out=Quantity
# ═══════════════════════════════════════════════════════════════════════════
# R1 / C1 / N3→N12
# Perspective: output handling — when out is a Quantity, kwargs["out"]
#   is replaced with ndarray view and original out is returned.
# Source: function_helpers.py _iterable_helper
def check_C1_iterable_helper_with_out():
    import astropy.units as u
    from astropy.units.quantity_helper.function_helpers import _iterable_helper

    q1 = np.array([1.0, 2.0]) * u.m
    out_q = np.empty(2) * u.m
    arrays, kwargs, unit, out = _iterable_helper(q1, out=out_q)

    # out is the original Quantity
    assert out is out_q
    # kwargs["out"] is now an ndarray view
    assert "out" in kwargs
    assert isinstance(kwargs["out"], np.ndarray)
    assert kwargs["out"].shape == (2,)
    # unit is preserved
    assert unit == u.m
    print("PASS: C1 — _iterable_helper handles out=Quantity correctly")


# ═══════════════════════════════════════════════════════════════════════════
# C2: _iterable_helper raises NotImplementedError for non-Quantity out
# ═══════════════════════════════════════════════════════════════════════════
# R1 / C2 / N3→N12
# Repository test: None directly; pattern from _quantity_out_as_array at line 262.
# Perspective: failure — non-Quantity, non-None out must raise NotImplementedError.
# Source: function_helpers.py _iterable_helper
def check_C2_iterable_helper_bad_out():
    import astropy.units as u
    from astropy.units.quantity_helper.function_helpers import _iterable_helper

    q1 = np.array([1.0, 2.0]) * u.m
    with pytest.raises(NotImplementedError):
        _iterable_helper(q1, out=np.array([0.0, 0.0]))
    print("PASS: C2 — _iterable_helper raises NotImplementedError for non-Quantity out")


# ═══════════════════════════════════════════════════════════════════════════
# C3: einsum validates subscripts is a string
# ═══════════════════════════════════════════════════════════════════════════
# R2 / C3 / N4
# Repository test: interface description docstring requirement.
# Perspective: failure — non-string first operand raises ValueError.
# Source: function_helpers.py einsum helper
def check_C3_einsum_non_string_subscripts():
    import astropy.units as u
    q1 = np.array([1.0, 2.0]) * u.m
    with pytest.raises(ValueError):
        np.einsum(q1, q1)
    print("PASS: C3 — einsum raises ValueError for non-string subscripts")


# ═══════════════════════════════════════════════════════════════════════════
# C4: einsum computes product unit from all operands
# ═══════════════════════════════════════════════════════════════════════════
# R2 / C4 / N4→N8→N11→N13
# Repository test: test_quantity_non_ufuncs.py::TestVariousProductFunctions::test_einsum
#   lines 1415-1428.
# Perspective: dataflow — result unit equals product of all operand units.
# Source: function_helpers.py einsum helper
def check_C4_einsum_unit_product():
    import astropy.units as u
    q1 = np.arange(9.0).reshape(3, 3) * u.m
    q2 = np.eye(3) / u.s
    result = np.einsum("ij,jk", q1, q2)
    # unit should be m * (1/s) = m/s
    assert result.unit == u.m / u.s, f"unit is {result.unit}, expected m/s"
    # Also check single-operand trace
    trace = np.einsum("ii", q1)
    assert trace.unit == u.m, f"trace unit is {trace.unit}, expected m"
    print("PASS: C4 — einsum result unit is product of operand units")


# ═══════════════════════════════════════════════════════════════════════════
# C5: einsum handles out parameter (in-place + identity)
# ═══════════════════════════════════════════════════════════════════════════
# R2 / C5 / N4
# Repository test: test_quantity_non_ufuncs.py::TestVariousProductFunctions::test_einsum
#   line 1426.
# Perspective: state/side-effect — result is the same object as out.
# Source: function_helpers.py einsum helper
def check_C5_einsum_out_parameter():
    import astropy.units as u
    q1 = np.arange(9.0).reshape(3, 3) * u.m
    q2 = np.eye(3) / u.s
    o2 = np.einsum("ij,jk", q1, q2)
    o3 = np.zeros_like(o2)  # same shape+unit
    result = np.einsum("ij,jk", q1, q2, out=o3)
    assert result is o3, "einsum with out must return the out array"
    assert np.all(result == o2), "einsum with out must produce correct values"
    print("PASS: C5 — einsum out parameter returns identity and correct values")


# ═══════════════════════════════════════════════════════════════════════════
# C6: like_helper preserves unit when subok=True
# ═══════════════════════════════════════════════════════════════════════════
# R3 / C6 / N5→N14
# Repository test: test_quantity_non_ufuncs.py::InvariantUnitTestSetup::test_zeros_like
#   (line 341-344).
# Perspective: dataflow — both value and unit are preserved.
# Source: function_helpers.py like_helper
def check_C6_like_helper_preserves_unit():
    import astropy.units as u
    q = np.array([1.0, 2.0, 3.0]) * u.kg
    o1 = np.ones_like(q)
    assert isinstance(o1, u.Quantity), f"ones_like result is {type(o1)}, not Quantity"
    assert o1.unit == u.kg, f"unit is {o1.unit}, expected kg"
    assert np.all(o1.value == 1.0), "ones_like values must all be 1.0"

    o2 = np.zeros_like(q)
    assert isinstance(o2, u.Quantity), f"zeros_like result is {type(o2)}, not Quantity"
    assert o2.unit == u.kg, f"unit is {o2.unit}, expected kg"
    assert np.all(o2.value == 0.0), "zeros_like values must all be 0.0"
    print("PASS: C6 — like_helper preserves unit and correct values when subok=True")


# ═══════════════════════════════════════════════════════════════════════════
# C7: like_helper with subok=False returns plain ndarray
# ═══════════════════════════════════════════════════════════════════════════
# R3 / C7 / Finding 2 (strengthened)
# Repository test: test_quantity_non_ufuncs.py::InvariantUnitTestSetup::test_empty_like
#   (line 338-339) checks type for empty_like; test_zeros_like (line 342-344)
#   checks values for zeros_like: assert_array_equal(o2, self.q * 0.0).
# Perspective: dataflow — subok=False produces plain ndarray with correct
#   shape and values (zeros or ones depending on function).
# Source: function_helpers.py like_helper
def check_C7_like_helper_subok_false():
    import astropy.units as u
    q = np.array([[1.0, 2.0], [3.0, 4.0]]) * u.kg

    # zeros_like with subok=False → plain ndarray of zeros
    o_zeros = np.zeros_like(q, subok=False)
    assert type(o_zeros) is np.ndarray, (
        f"zeros_like subok=False returned {type(o_zeros)}, expected ndarray"
    )
    assert o_zeros.shape == q.shape, (
        f"shape {o_zeros.shape} != expected {q.shape}"
    )
    assert np.all(o_zeros == 0.0), "zeros_like subok=False must produce zeros"

    # ones_like with subok=False → plain ndarray of ones
    o_ones = np.ones_like(q, subok=False)
    assert type(o_ones) is np.ndarray, (
        f"ones_like subok=False returned {type(o_ones)}, expected ndarray"
    )
    assert o_ones.shape == q.shape, (
        f"shape {o_ones.shape} != expected {q.shape}"
    )
    assert np.all(o_ones == 1.0), "ones_like subok=False must produce ones"

    print("PASS: C7 — like_helper subok=False returns plain ndarray with correct shape and values")


# ═══════════════════════════════════════════════════════════════════════════
# C8: StructuredUnit.__rlshift__ creates Quantity
# ═══════════════════════════════════════════════════════════════════════════
# R4 / C8 / N6→N15
# Repository test: test_structured.py::TestStructuredQuantity::test_initialization_by_shifting_to_unit
#   (lines 457-461).
# Perspective: dataflow — value << structured_unit returns Quantity with
#   correct values and may_share_memory.
# Source: structured.py StructuredUnit.__rlshift__
def check_C8_rlshift_creates_quantity():
    import astropy.units as u
    from astropy.units import StructuredUnit, Quantity
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.m / u.s), dt)
    values = np.array([(10.0, 5.0), (20.0, 8.0)], dtype=dt)
    result = values << su
    assert isinstance(result, Quantity), f"result is {type(result)}, not Quantity"
    assert np.all(result['p'].value == values['p'])
    assert np.all(result['v'].value == values['v'])
    assert result.unit is su
    # copy=False means memory may be shared
    assert np.may_share_memory(result, values)
    print("PASS: C8 — __rlshift__ creates Quantity with correct values and unit")


# ═══════════════════════════════════════════════════════════════════════════
# C9: StructuredUnit.__rlshift__ returns NotImplemented on failure
# ═══════════════════════════════════════════════════════════════════════════
# R4 / C9 / N6
# Repository test: pattern from UnitBase.__rlshift__ (core.py line 346-354).
# Perspective: failure — invalid value returns NotImplemented (non-ndarray)
#   but re-raises the exception for ndarray values (Finding 3).
# Source: structured.py StructuredUnit.__rlshift__
def check_C9_rlshift_returns_notimplemented():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.m / u.s), dt)

    # Non-array value that cannot be converted → NotImplemented
    values = "not an array"
    result = values.__lshift__(su)
    assert result is NotImplemented
    print("PASS: C9 — __rlshift__ returns NotImplemented for non-convertible values")


# ═══════════════════════════════════════════════════════════════════════════
# C9a: StructuredUnit.__rlshift__ re-raises for ndarray failures (Finding 3)
# ═══════════════════════════════════════════════════════════════════════════
# R4 / C9 / Finding 3
# Repository test: UnitBase.__rlshift__ at core.py:346-354 catches Exception
#   and re-raises if m is an np.ndarray.
# Perspective: failure — ndarray with incompatible dtype/structure must
#   propagate the original exception, not swallow it into NotImplemented.
# Source: structured.py StructuredUnit.__rlshift__
def check_C9_rlshift_ndarray_re_raise():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.m / u.s), dt)

    # A 1D unstructured ndarray passed to a structured unit should fail.
    # The exception must NOT be swallowed into NotImplemented for ndarray.
    bad_values = np.array([1.0, 2.0, 3.0])  # 1D float, not structured
    try:
        result = bad_values << su
        # If it didn't raise, it must not be NotImplemented for ndarray
        assert result is not NotImplemented, (
            "ndarray re-raise: __rlshift__ should have re-raised, not returned NotImplemented"
        )
    except NotImplementedError:
        # NotImplementedError is acceptable if it's an explicit raise
        pass
    except Exception:
        # Any other exception is acceptable — this is the re-raise path
        pass
    print("PASS: C9a — __rlshift__ propagates exception for ndarray (does not swallow into NotImplemented)")


# ═══════════════════════════════════════════════════════════════════════════
# C10: StructuredUnit.__rmul__ with unit → per-field multiplication
# ═══════════════════════════════════════════════════════════════════════════
# R5 / C10 / N7→Unit
# Repository test: test_structured.py::TestStructuredUnitArithmatic::test_multiplication
#   (lines 384-399).
# Perspective: dataflow — unit * structured_unit returns StructuredUnit
#   with each field multiplied.
# Source: structured.py StructuredUnit.__rmul__
def check_C10_rmul_field_multiplication():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)

    result = u.kg * su
    assert isinstance(result, StructuredUnit), f"u.kg * su returned {type(result)}, not StructuredUnit"
    assert result['p'] == u.kg * u.m
    assert result['v'] == u.kg * u.s
    print("PASS: C10 — __rmul__ multiplies each field by the unit")


# ═══════════════════════════════════════════════════════════════════════════
# C10a: StructuredUnit.__rmul__ with string unit (Finding 7)
# ═══════════════════════════════════════════════════════════════════════════
# R5 / C10 / Finding 7
# Repository test: test_structured.py::TestStructuredUnitArithmatic::test_multiplication
#   line 394: au_times_pv2 = "AU" * self.pv_unit.
# Perspective: dataflow — string * structured_unit parses string as Unit,
#   then multiplies per-field, matching the unit-multiplication result.
# Source: structured.py StructuredUnit.__rmul__
def check_rmul_string_unit():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)

    # String * structured_unit → parse string as Unit, multiply each field
    result_str = "kg" * su
    result_unit = u.kg * su
    assert result_str == result_unit, (
        f"string 'kg' * su ({result_str}) != u.kg * su ({result_unit})"
    )
    assert result_str['p'] == u.kg * u.m
    assert result_str['v'] == u.kg * u.s
    print("PASS: C10a — __rmul__ correctly parses string units")


# ═══════════════════════════════════════════════════════════════════════════
# C10b: StructuredUnit.__rmul__ TypeError failures (Finding 5)
# ═══════════════════════════════════════════════════════════════════════════
# R5 / C10 / Finding 5
# Repository test: test_structured.py::TestStructuredUnitArithmatic::test_multiplication
#   lines 395-398:
#     with pytest.raises(TypeError): self.pv_unit * self.pv_unit
#     with pytest.raises(TypeError): "s,s" * self.pv_unit
# Perspective: failure — StructuredUnit×StructuredUnit and invalid-
#   string×StructuredUnit must raise TypeError.
# Source: structured.py StructuredUnit.__rmul__
def check_rmul_typeerror_structured():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)
    su2 = StructuredUnit((u.kg, u.m / u.s), dt)

    # StructuredUnit * StructuredUnit → TypeError
    with pytest.raises(TypeError):
        su2 * su
    print("PASS: C10b — StructuredUnit * StructuredUnit raises TypeError")


def check_rmul_typeerror_bad_string():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)

    # Invalid string (comma-separated) * StructuredUnit → TypeError
    with pytest.raises(TypeError):
        "s,s" * su
    print("PASS: C10b — invalid string * StructuredUnit raises TypeError")


# ═══════════════════════════════════════════════════════════════════════════
# C11: StructuredUnit.__rmul__ with array creates Quantity
# ═══════════════════════════════════════════════════════════════════════════
# R5 / C11 / N7→N15
# Repository test: test_structured.py::TestStructuredQuantity::test_initialization_by_multiplication_with_unit
#   (lines 447-455).
# Perspective: dataflow — array * structured_unit returns Quantity with
#   correct values and unit. copy=True (default) means no shared memory.
# Source: structured.py StructuredUnit.__rmul__
def check_C11_rmul_creates_quantity():
    import astropy.units as u
    from astropy.units import StructuredUnit, Quantity
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)
    values = np.array([(1.0, 2.0), (3.0, 4.0)], dtype=dt)
    result = values * su
    assert isinstance(result, Quantity), f"result is {type(result)}, not Quantity"
    assert result.unit is su
    assert np.all(result['p'].value == values['p'])
    # Default copy=True → memory NOT shared
    assert not np.may_share_memory(result, values)
    print("PASS: C11 — __rmul__ creates Quantity from array with correct values")


# ═══════════════════════════════════════════════════════════════════════════
# __mul__ field multiplication: structured_unit * unit (Finding 1)
# ═══════════════════════════════════════════════════════════════════════════
# R5 (extended) / C10 / Finding 1
# Repository test: test_structured.py::TestStructuredUnitArithmatic::test_multiplication
#   (lines 384-399): pv_times_au = self.pv_unit * u.au
# Perspective: dataflow — structured_unit * regular_unit returns
#   StructuredUnit with each field multiplied individually.
# Source: structured.py StructuredUnit.__mul__
def check_mul_field_multiplication():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)

    result = su * u.kg
    assert isinstance(result, StructuredUnit), f"su * u.kg returned {type(result)}, not StructuredUnit"
    assert result['p'] == u.m * u.kg
    assert result['v'] == u.s * u.kg
    # Commutativity: __mul__ result should equal __rmul__ result
    assert result == u.kg * su
    print("PASS: __mul__ — structured_unit * unit multiplies each field")


# ═══════════════════════════════════════════════════════════════════════════
# __mul__ string parsing: structured_unit * "string" (Finding 1)
# ═══════════════════════════════════════════════════════════════════════════
# R5 (extended) / C10 / Finding 1
# Repository test: test_structured.py::TestStructuredUnitArithmatic::test_multiplication
#   line 393: pv_times_au2 = self.pv_unit * "au"
# Perspective: dataflow — structured_unit * "string" parses string as Unit
#   and multiplies per-field.
# Source: structured.py StructuredUnit.__mul__
def check_mul_string_unit():
    import astropy.units as u
    from astropy.units import StructuredUnit
    import numpy as np

    dt = np.dtype([('p', 'f8'), ('v', 'f8')])
    su = StructuredUnit((u.m, u.s), dt)

    result_str = su * "kg"
    result_unit = su * u.kg
    assert result_str == result_unit, (
        f"su * 'kg' ({result_str}) != su * u.kg ({result_unit})"
    )
    assert result_str['p'] == u.m * u.kg
    assert result_str['v'] == u.s * u.kg
    print("PASS: __mul__ — structured_unit * string parses string and multiplies each field")


# ═══════════════════════════════════════════════════════════════════════════
# C12: _as_quantities returns tuple of Quantity objects
# ═══════════════════════════════════════════════════════════════════════════
# R6 / C12 / N8→N11
# Repository test: exercised by dot_like (function_helpers.py line 910),
#   solve (line 928), concatenate (line 1095), etc.
# Perspective: dataflow — return type, element conversion, 1/2/3+ arguments.
# Source: function_helpers.py _as_quantities
def check_C12_as_quantities_return():
    import astropy.units as u
    from astropy.units import Quantity
    from astropy.units.quantity_helper.function_helpers import _as_quantities

    # Single argument
    a = np.array([1.0, 2.0])
    result1 = _as_quantities(a)
    assert isinstance(result1, tuple)
    assert len(result1) == 1
    assert isinstance(result1[0], Quantity)
    assert result1[0].unit == u.dimensionless_unscaled

    # Two arguments: one with unit, one without
    b = np.array([3.0, 4.0]) * u.s
    result2 = _as_quantities(a, b)
    assert isinstance(result2, tuple)
    assert len(result2) == 2
    # First arg (no unit) becomes dimensionless Quantity
    assert isinstance(result2[0], Quantity)
    assert result2[0].unit == u.dimensionless_unscaled
    # Second arg preserves its unit
    assert isinstance(result2[1], Quantity)
    assert result2[1].unit == u.s

    # Three arguments (common pattern in production: e.g., linspace-like)
    c = np.array([5.0, 6.0]) * u.kg
    result3 = _as_quantities(a, b, c)
    assert isinstance(result3, tuple)
    assert len(result3) == 3
    for i, (q, expected_unit) in enumerate(zip(
        result3,
        [u.dimensionless_unscaled, u.s, u.kg]
    )):
        assert isinstance(q, Quantity), f"element {i} is {type(q)}, not Quantity"
        assert q.unit == expected_unit, f"element {i} unit {q.unit} != {expected_unit}"
    print("PASS: C12 — _as_quantities returns tuple of Quantity objects (1/2/3 args)")


# ═══════════════════════════════════════════════════════════════════════════
# C13: _normalize_names transforms nested names correctly
# ═══════════════════════════════════════════════════════════════════════════
# R7 / C13 / N9
# Repository test: test_structured.py::TestStructuredUnitBasics::test_extreme_recursive_initialization
#   (lines 97-127).
# Perspective: dataflow — specific input → specific nested output.
# Source: structured.py _normalize_names
def check_C13_normalize_names_transformation():
    from astropy.units.structured import _normalize_names

    raw = ("t", ("p", "v", ("h", ("d1", "d2"))), "l")
    result = _normalize_names(raw)

    expected = (
        't',
        ['pvhd1d2', ('p', 'v', ['hd1d2', ('h', ['d1d2', ('d1', 'd2')])])],
        'l',
    )
    assert result == expected, (
        f"_normalize_names mismatch:\n  got:      {result!r}\n  expected: {expected!r}"
    )
    print("PASS: C13 — _normalize_names transforms nested names correctly")


# ═══════════════════════════════════════════════════════════════════════════
# C14: _normalize_names raises ValueError on invalid entries
# ═══════════════════════════════════════════════════════════════════════════
# R7 / C14 / N9
# Repository test: test_structured.py::TestStructuredUnitBasics::test_initialization_names_invalid_list_errors
#   (lines 128-142, parametrized).
# Perspective: failure — invalid names entries raise ValueError with diagnostic.
# Source: structured.py _normalize_names
def check_C14_normalize_names_invalid_entries():
    from astropy.units.structured import _normalize_names

    invalid_cases = [
        (("t", ["p", "v"]), "['p', 'v']"),
        (("t", ["pv", "p", "v"]), "['pv', 'p', 'v']"),
        (("t", ["pv", ["p", "v"]]), "['pv', ['p', 'v']"),
        (("t", ()), "()"),
        (("t", ("p", None)), "None"),
        (("t", ["pv", ("p", "")]), "''"),
    ]
    for names, invalid_str in invalid_cases:
        with pytest.raises(ValueError, match=f"invalid entry {invalid_str}"):
            _normalize_names(names)
    print("PASS: C14 — _normalize_names raises ValueError on invalid entries")


# ═══════════════════════════════════════════════════════════════════════════
# Boundary: einsum raises NotImplementedError for non-Quantity out
# ═══════════════════════════════════════════════════════════════════════════
# R2 / C5 supplement
# Repository test: pattern from dot_like at function_helpers.py line 907.
# Perspective: failure — out that is not Quantity and not None.
# Source: function_helpers.py einsum helper
def check_einsum_non_quantity_out():
    import astropy.units as u
    q1 = np.arange(9.0).reshape(3, 3) * u.m
    with pytest.raises(NotImplementedError):
        np.einsum("ii", q1, out=np.zeros(1))
    print("PASS: einsum raises NotImplementedError for non-Quantity out")


# ═══════════════════════════════════════════════════════════════════════════
# Boundary: einsum with single operand (identity operation)
# ═══════════════════════════════════════════════════════════════════════════
# R2 / C4
# Repository test: test_quantity_non_ufuncs.py::TestVariousProductFunctions::test_einsum
#   line 1417-1418.
# Perspective: dataflow — "...i" keeps the array unchanged.
# Source: function_helpers.py einsum helper
def check_einsum_single_operand():
    import astropy.units as u
    q1 = np.arange(9.0).reshape(3, 3) * u.m
    result = np.einsum("...i", q1)
    assert np.all(result == q1)
    assert result.unit == u.m
    print("PASS: einsum single-operand identity preserves value and unit")


# ═══════════════════════════════════════════════════════════════════════════
# Static-issue closure
# ═══════════════════════════════════════════════════════════════════════════

# static_issues.md and static_analysis.md report:
# - '_as_quantities' used but not defined → covered by C12 behavior check
# - '_iterable_helper' used but not defined → covered by C1, C2 checks
# - '_normalize_names' used but not defined → covered by C13, C14 checks
# - erfa.py issues ('check_structured_unit', 'ldbody_unit') → out of scope
#   for this task (not part of this task's interfaces)
# - core.py 'get_err_str' → out of scope (not part of this task's interfaces)


def main():
    check_C1_iterable_helper_return_structure()
    check_C1_iterable_helper_with_out()
    check_C2_iterable_helper_bad_out()
    check_C3_einsum_non_string_subscripts()
    check_C4_einsum_unit_product()
    check_C5_einsum_out_parameter()
    check_C6_like_helper_preserves_unit()
    check_C7_like_helper_subok_false()
    check_C8_rlshift_creates_quantity()
    check_C9_rlshift_returns_notimplemented()
    check_C9_rlshift_ndarray_re_raise()
    check_C10_rmul_field_multiplication()
    check_rmul_string_unit()
    check_rmul_typeerror_structured()
    check_rmul_typeerror_bad_string()
    check_C11_rmul_creates_quantity()
    check_mul_field_multiplication()
    check_mul_string_unit()
    check_C12_as_quantities_return()
    check_C13_normalize_names_transformation()
    check_C14_normalize_names_invalid_entries()
    check_einsum_non_quantity_out()
    check_einsum_single_operand()
    print("ALL BEHAVIOR CHECKS PASSED")


if __name__ == "__main__":
    main()
