# Static Analysis

## Scope
- Repository: `/testbed`
- Declared interfaces: 1
- `pandas/core/reshape/concat.py`: `concat` (function)

## Findings
## static issue

- **`pandas/core/frame.py`** (1):
  - ? 'concat_compat' is used but not defined or imported in this file
- **`pandas/core/generic.py`** (1):
  - ? 'concat' is used but not defined or imported in this file
- **`pandas/core/methods/describe.py`** (1):
  - ? 'concat' is used but not defined or imported in this file
- **`pandas/core/resample.py`** (1):
  - ? 'concat' is used but not defined or imported in this file
- **`pandas/core/reshape/concat.py`** (1):
  - ? '_concat_indexes' is used but not defined or imported in this file
- **`pandas/core/reshape/melt.py`** (2):
  - ? 'concat' is used but not defined or imported in this file
  - ? 'concat_compat' is used but not defined or imported in this file
- **`pandas/core/reshape/pivot.py`** (1):
  - ? 'concat' is used but not defined or imported in this file
- **`pandas/core/window/rolling.py`** (1):
  - ? 'concat' is used but not defined or imported in this file
- **`pandas/io/json/_json.py`** (1):
  - ? 'concat' is used but not defined or imported in this file
- **`pandas/io/pytables.py`** (1):
  - ? 'concat' is used but not defined or imported in this file

## Use
- Requirement Compile: use findings to identify dependency, caller-binding, and compatibility risks.
- Test Spec: compile relevant findings into runtime checks; static evidence alone is not a behavior proof.
