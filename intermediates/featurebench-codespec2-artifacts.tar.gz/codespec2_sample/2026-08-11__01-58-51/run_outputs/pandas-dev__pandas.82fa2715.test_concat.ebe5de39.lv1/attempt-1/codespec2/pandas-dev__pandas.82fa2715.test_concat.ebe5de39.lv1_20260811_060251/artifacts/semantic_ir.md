# Semantic IR

## L1. Requirement Obligations

### R1: Public `concat` function signature and module binding
- **Type**: Interface
- **Statement**: The function `concat` shall be defined in `/testbed/pandas/core/reshape/concat.py` decorated with `@set_module('pandas')`, accepting parameters `(objs, *, axis=0, join='outer', ignore_index=False, keys=None, levels=None, names=None, verify_integrity=False, sort=False, copy=False)` and returning `DataFrame | Series`.
- **Task Evidence**: Interface Description 1 specifies the full function signature with all parameter names, defaults, and the `@set_module('pandas')` decorator.
- **Acceptance**: The function must be importable as `pd.concat`, `from pandas import concat`, and `from pandas.core.reshape.concat import concat`. All callers within the repository that use `from pandas.core.reshape.concat import concat` must resolve successfully.
- **Repository Evidence**: 
  - `/testbed/pandas/core/reshape/concat.py` lines 75-154 contain 5 `@overload` stubs for `concat` decorated with `@set_module('pandas')` but no implementation body.
  - `/testbed/pandas/__init__.py` line 286 lists `"concat"` in `__all__` but `concat` is not currently importable from `pandas` (confirmed by `AttributeError` at runtime).
  - Numerous callers use `from pandas.core.reshape.concat import concat`: `/testbed/pandas/core/frame.py`, `/testbed/pandas/core/series.py`, `/testbed/pandas/core/groupby/groupby.py`, `/testbed/pandas/core/groupby/generic.py`, `/testbed/pandas/core/reshape/reshape.py`, `/testbed/pandas/core/reshape/merge.py`, `/testbed/pandas/core/reshape/encoding.py`, `/testbed/pandas/core/apply.py`, `/testbed/pandas/core/methods/selectn.py`, `/testbed/pandas/core/arrays/categorical.py`.
- **Uncertainty**: Whether `copy` parameter default should be `False` or `lib.NoDefault` (overloads use `lib.NoDefault`, the docstring says default `False`). The overloads and docstring differ. The interface description says `copy: bool, default False`.

### R2: Input validation — iterable or mapping
- **Type**: Behavior / Failure
- **Statement**: The first argument `objs` must be an iterable (or generator) of `Series`/`DataFrame` objects, or a `Mapping` whose values are `Series`/`DataFrame`. If `objs` is a `DataFrame` directly (not iterable), raise `TypeError` with message `"first argument must be an iterable of pandas objects, you passed an object of type \"DataFrame\""`.
- **Task Evidence**: Interface Description 1 `Raises` section: `TypeError: If first argument is not an iterable of pandas objects.`; Examples in docstring show `pd.concat([s1, s2])`.
- **Acceptance**: Passing a single DataFrame (not in a list) raises TypeError. Passing a generator of DataFrames succeeds. Passing a dict/Mapping uses keys as `keys` argument if `keys` is not passed.
- **Repository Evidence**: `/testbed/pandas/tests/reshape/concat/test_invalid.py` `test_concat_invalid_first_argument` and `test_concat_generator_obj` confirm these behaviors. `/testbed/pandas/tests/reshape/concat/test_concat.py` `test_concat_mapping` confirms Mapping support.
- **Uncertainty**: None.

### R3: Input validation — object type check
- **Type**: Behavior / Failure
- **Statement**: Every element in `objs` must be a `Series` or `DataFrame`. Non-pandas objects (int, dict, list, tuple) must raise `TypeError` with message `"cannot concatenate object of type '<type>'; only Series and DataFrame objs are valid"`.
- **Task Evidence**: Interface Description 1 `Raises` section: `TypeError: If objects contain types other than Series or DataFrame.`
- **Acceptance**: `concat([df, 1])` raises TypeError. `concat([df, {}])` raises TypeError.
- **Repository Evidence**: `/testbed/pandas/tests/reshape/concat/test_invalid.py` `test_concat_invalid` parametrized with `[1, {}, [1, 2], (1, 2)]`.
- **Uncertainty**: None.

### R4: None object handling
- **Type**: Behavior / Failure
- **Statement**: `None` objects in the iterable shall be silently dropped. If all objects are `None`, raise `ValueError`.
- **Task Evidence**: Interface Description 1: `"Any None objects will be dropped silently unless they are all None in which case a ValueError will be raised."`
- **Acceptance**: `concat([df, None])` produces same result as `concat([df])`. `concat([None, None])` raises ValueError.
- **Repository Evidence**: `/testbed/pandas/tests/reshape/concat/test_concat.py` and related tests exercise None handling implicitly. The `Raises` section of the docstring specifies `ValueError: If all objects passed are None.`
- **Uncertainty**: Whether the ValueError message format is specified.

### R5: Empty objects handling
- **Type**: Behavior
- **Statement**: When no objects remain after filtering None, raise `ValueError` with message indicating no objects to concatenate.
- **Task Evidence**: Interface Description 1 `Raises`: `ValueError: If no objects to concatenate are provided.`
- **Acceptance**: `concat([])` raises ValueError.
- **Repository Evidence**: Tests in `/testbed/pandas/tests/reshape/concat/test_empty.py` exercise empty object scenarios.
- **Uncertainty**: Exact error message wording.

### R6: Mixed dimension handling
- **Type**: Behavior / Failure
- **Statement**: When concatenating mixed dimensional objects (e.g., Series with DataFrame along axis=0), Series are promoted to DataFrame using `_sanitize_mixed_ndim`. If dimensions differ by more than 1, raise `ValueError("cannot concatenate unaligned mixed dimensional NDFrame objects")`.
- **Task Evidence**: Interface Description 1: `TypeError: If trying to concatenate unaligned mixed dimensional NDFrame objects.` (Note: docstring says TypeError but helper raises ValueError).
- **Acceptance**: Concatenating Series with DataFrame along axis=0 produces DataFrame. Concatenating incompatible dimensions raises error.
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` lines 456-617 define `_sanitize_mixed_ndim` which handles this logic. The function raises `ValueError`.
- **Uncertainty**: Exception class discrepancy between docstring (TypeError) and helper implementation (ValueError). The helper raises ValueError.

### R7: Axis parameter handling
- **Type**: Behavior
- **Statement**: `axis=0` (or `'index'`) concatenates along rows; `axis=1` (or `'columns'`) concatenates along columns. When `axis=1`, the return type is always `DataFrame`. When `axis=0` and all objects are `Series`, return `Series`; if any `DataFrame` present, return `DataFrame`.
- **Task Evidence**: Interface Description 1: `"When concatenating all Series along the index (axis=0), a Series is returned. When objs contains at least one DataFrame, a DataFrame is returned. When concatenating along the columns (axis=1), a DataFrame is returned."`
- **Acceptance**: Return types match specification for each axis/object combination.
- **Repository Evidence**: The 5 overload stubs in `/testbed/pandas/core/reshape/concat.py` encode these return type constraints. Tests in `/testbed/pandas/tests/reshape/concat/test_concat.py` exercise axis combinations.
- **Uncertainty**: None.

### R8: Join parameter handling
- **Type**: Behavior / Failure
- **Statement**: `join='outer'` (default) unions all columns/indexes from all objects. `join='inner'` intersects them. Invalid values raise `ValueError`.
- **Task Evidence**: Interface Description 1: `join : {'inner', 'outer'}, default 'outer'`. Raises: `ValueError: If join parameter is not 'inner' or 'outer'.`
- **Acceptance**: `concat([df1, df3], join='inner')` returns only shared columns. Invalid join value raises ValueError.
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` `new_axes` helper (line 619) uses `intersect` parameter derived from `join`. Tests in `/testbed/pandas/tests/reshape/concat/test_concat.py` exercise join='inner'.
- **Uncertainty**: None.

### R9: Ignore_index parameter
- **Type**: Behavior / Failure
- **Statement**: When `ignore_index=True`, the result uses a default RangeIndex(0..n-1) along the concatenation axis. Cannot be combined with `keys` — raises `ValueError`.
- **Task Evidence**: Interface Description 1: `ignore_index : bool, default False`. Raises: `ValueError: If ignore_index=True and keys is not None.`
- **Acceptance**: `concat([s1, s2], ignore_index=True)` produces RangeIndex. `concat([s1, s2], ignore_index=True, keys=['a','b'])` raises ValueError.
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` `_get_concat_axis_dataframe` (line 701) checks `ignore_index` and returns `default_index`. Tests confirm behavior.
- **Uncertainty**: Whether the ValueError for `ignore_index=True` with `keys` is raised before or after other validation.

### R10: Keys, levels, names — hierarchical index construction
- **Type**: Behavior / Failure
- **Statement**: `keys` adds a hierarchical index level. `levels` provides pre-specified unique level values. `names` provides names for the index levels. If `keys` length doesn't match number of objects, raise `ValueError`. If level values are not unique, raise `ValueError`.
- **Task Evidence**: Interface Description 1: `"If multiple levels passed, should contain tuples."` Raises: `ValueError: If the length of keys doesn't match the length of objects to concatenate. If level values are not unique when using MultiIndex.`
- **Acceptance**: MultiIndex is constructed correctly from keys/levels/names. Length mismatch raises ValueError. Non-unique levels raise ValueError.
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` `_make_concat_multiindex` (line 839) and `validate_unique_levels` (line 833) handle this logic. Tests in `/testbed/pandas/tests/reshape/concat/test_concat.py` `test_concat_with_group_keys`, `test_concat_keys_specific_levels`, `test_concat_keys_and_levels`.
- **Uncertainty**: None.

### R11: Verify_integrity parameter
- **Type**: Behavior / Failure
- **Statement**: When `verify_integrity=True`, check for duplicate index values in the concatenation axis and raise `ValueError` if found.
- **Task Evidence**: Interface Description 1: `verify_integrity : bool, default False`. Raises: `ValueError: If indexes have overlapping values when verify_integrity=True.`
- **Acceptance**: `concat([df5, df6], verify_integrity=True)` where both have index `['a']` raises `ValueError("Indexes have overlapping values: ['a']")`.
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` `_get_concat_axis_dataframe` lines 726-728. Tests in `/testbed/pandas/tests/reshape/concat/test_concat.py`.
- **Uncertainty**: None.

### R12: Sort parameter
- **Type**: Behavior / Failure
- **Statement**: When `sort=False` (default), the non-concatenation axis preserves the order from the first object. When `sort=True`, it is sorted. Exception: DatetimeIndex with `join='outer'` is always sorted. Raises `ValueError` if not a boolean.
- **Task Evidence**: Interface Description 1: `sort : bool, default False`. Raises: `ValueError: If sort parameter is not a boolean value.`
- **Acceptance**: `concat([df1, df3], sort=False)` preserves column order from df1 then df3. `concat([df1, df3], sort=True)` sorts columns.
- **Repository Evidence**: `/testbed/pandas/tests/reshape/concat/test_sort.py`. `/testbed/pandas/core/reshape/concat.py` `new_axes` passes `sort` to `get_objs_combined_axis`.
- **Uncertainty**: None.

### R13: Copy parameter
- **Type**: Behavior
- **Statement**: When `copy=False` (default), avoid unnecessary data copies. When `copy=True`, ensure data is copied. Note: deprecated in 3.0.0 per docstring.
- **Task Evidence**: Interface Description 1: `copy : bool, default False`.
- **Acceptance**: `copy=False` shares memory where safe. `copy=True` ensures no shared memory.
- **Repository Evidence**: `/testbed/pandas/core/internals/concat.py` `concatenate_managers` uses `copy` parameter. Tests in `/testbed/pandas/tests/reshape/concat/test_concat.py` `test_concat_copy`.
- **Uncertainty**: The overload stubs use `lib.NoDefault` while the interface description says `bool, default False`.

### R14: Result type determination
- **Type**: Behavior
- **Statement**: After filtering None objects, determine the result type: if `axis=1`, always `DataFrame`; if `axis=0` and any object is `DataFrame`, return `DataFrame`; if `axis=0` and all are `Series`, return `Series`.
- **Task Evidence**: Interface Description 1 Returns section.
- **Acceptance**: Return types match specification.
- **Repository Evidence**: Overload stubs encode this. Helper `_sanitize_mixed_ndim` promotes Series to DataFrame when mixed.
- **Uncertainty**: None.

### R15: `_concat_indexes` helper function
- **Type**: Interface / Dependency
- **Statement**: The function `_concat_indexes` shall be defined and importable within `/testbed/pandas/core/reshape/concat.py`. It accepts a list of `Index` objects and returns a single `Index` that is the concatenation of all input indexes.
- **Task Evidence**: The function is called at lines 721 and 885 of `/testbed/pandas/core/reshape/concat.py` but is neither defined nor imported.
- **Acceptance**: `_concat_indexes` must be defined (either in `concat.py` or imported from another module) so that calls at lines 721 and 885 resolve.
- **Repository Evidence**: Static issue: `_concat_indexes` is used but not defined or imported in `concat.py`. The function likely concatenates Index objects end-to-end, similar to `Index.append` chain. No existing definition found anywhere in the repository under this name.
- **Uncertainty**: Exact implementation location. Should likely be defined in `concat.py` itself or in `pandas/core/indexes/api.py`. The function behavior: given `[idx1, idx2, idx3]`, returns `idx1.append(idx2.append(idx3))` or equivalent.

### R16: `concat_compat` helper function
- **Type**: Interface / Dependency
- **Statement**: The function `concat_compat` shall be defined in `/testbed/pandas/core/dtypes/concat.py` and accept array-like objects for concatenation with optional `axis` and `ea_compat_axis` parameters. It handles ExtensionArray, numpy arrays, and mixed types with proper dtype coercion.
- **Task Evidence**: Multiple callers use `concat_compat`: `/testbed/pandas/core/internals/concat.py` (lines 136, 139, 396, 400), `/testbed/pandas/core/frame.py` (lines 12129, 12163), `/testbed/pandas/core/reshape/melt.py` (line 350), `/testbed/pandas/core/algorithms.py` (line 1657), `/testbed/pandas/core/indexing.py` (line 2287), `/testbed/pandas/core/indexes/datetimelike.py` (lines 690, 703), `/testbed/pandas/core/indexes/base.py` (lines 3220, 5390), `/testbed/pandas/io/parsers/c_parser_wrapper.py` (line 359).
- **Acceptance**: `concat_compat` must be defined in `pandas/core/dtypes/concat.py` and callers must be able to import it. Tests in `/testbed/pandas/tests/dtypes/test_concat.py` exercise `concat_compat` behavior: concatenating Categoricals, PeriodArrays (1D and 2D), with axis parameter validation.
- **Repository Evidence**: Static issue: `concat_compat` is used but not defined or imported in `/testbed/pandas/core/internals/concat.py`, `/testbed/pandas/core/frame.py`, and `/testbed/pandas/core/reshape/melt.py`. Tests at `/testbed/pandas/tests/dtypes/test_concat.py` import `pandas.core.dtypes.concat as _concat` and call `_concat.concat_compat`. The `pandas/core/dtypes/concat.py` file currently has a large blank gap (lines 55-160 approximate) where `concat_compat` should be defined.
- **Uncertainty**: Full parameter signature of `concat_compat`. From usage: `concat_compat(vals, axis=0, ea_compat_axis=True)`, `concat_compat(vals, axis=1)`, `concat_compat(to_concat)`, `concat_compat(to_concat, axis=0, ea_compat_axis=True)`. Parameters: `arrays`, `axis=0`, `ea_compat_axis=False`.

### R17: Caller binding — `pandas.core.internals.concat` depends on `concat_compat`
- **Type**: Dependency
- **Statement**: `/testbed/pandas/core/internals/concat.py` calls `concat_compat` at lines 136, 139, 396, 400 without importing it. The module must import `concat_compat` from `pandas.core.dtypes.concat`.
- **Task Evidence**: Static analysis: `concat_compat` is used but not defined or imported in this file.
- **Acceptance**: Adding `from pandas.core.dtypes.concat import concat_compat` (or equivalent) to the imports of `/testbed/pandas/core/internals/concat.py`.
- **Repository Evidence**: The file imports from `pandas.core.dtypes.cast`, `pandas.core.dtypes.common`, `pandas.core.dtypes.dtypes`, `pandas.core.dtypes.missing` — `pandas.core.dtypes.concat` is the natural module for `concat_compat`.
- **Uncertainty**: Whether `concat_compat` should be imported at the top level or lazily within functions to avoid circular imports.

### R18: Caller binding — `pandas.core.frame` depends on `concat_compat`
- **Type**: Dependency
- **Statement**: `/testbed/pandas/core/frame.py` calls `concat_compat` at lines 12129, 12163 without importing it.
- **Task Evidence**: Static analysis: `concat_compat` is used but not defined or imported in this file.
- **Acceptance**: The function call must resolve at runtime.
- **Repository Evidence**: Line 12129: `arr = concat_compat(list(df._iter_column_arrays()))`. Line 12163: `arr = concat_compat(list(df._iter_column_arrays()))`.
- **Uncertainty**: Import path — likely a local import `from pandas.core.dtypes.concat import concat_compat` within the containing function.

### R19: Caller binding — `pandas.core.reshape.melt` depends on `concat_compat`
- **Type**: Dependency
- **Statement**: `/testbed/pandas/core/reshape/melt.py` calls `concat_compat` at line 350 without importing it.
- **Task Evidence**: Static analysis: `concat_compat` is used but not defined or imported in this file.
- **Acceptance**: The function call must resolve at runtime.
- **Repository Evidence**: Line 350: `mdata[target] = concat_compat(to_concat)` within `lreshape` function.
- **Uncertainty**: Import path.

### R20: Import path for `concat` in downstream modules
- **Type**: Interface / Dependency
- **Statement**: Multiple modules across the codebase import `concat` via `from pandas.core.reshape.concat import concat`. All these imports must resolve after implementation.
- **Task Evidence**: Static analysis identifies `concat` as used-but-not-imported in: `/testbed/pandas/core/generic.py`, `/testbed/pandas/core/methods/describe.py`, `/testbed/pandas/core/resample.py`, `/testbed/pandas/core/reshape/melt.py`, `/testbed/pandas/core/reshape/pivot.py`, `/testbed/pandas/core/window/rolling.py`, `/testbed/pandas/io/json/_json.py`, `/testbed/pandas/io/pytables.py`. In these files, `concat` is called but the import statement is missing from the static analysis perspective (though many use local imports within function bodies).
- **Acceptance**: All callers that reference `concat` resolve at runtime.
- **Repository Evidence**: Many callers use local imports (`from pandas.core.reshape.concat import concat` inside function bodies). The static analysis tool may not detect these. Actual runtime behavior must be verified.
- **Uncertainty**: Whether these are false positives (local imports not detected) or actual missing imports. Runtime testing is required.

### R21: `@set_module('pandas')` decorator
- **Type**: Interface
- **Statement**: The `concat` function must be decorated with `@set_module('pandas')` so that `help(pd.concat)` and `pd.concat.__module__` report `'pandas'`.
- **Task Evidence**: Interface Description 1 shows `@set_module('pandas')` above the function definition.
- **Acceptance**: `pd.concat.__module__ == 'pandas'` or at minimum `help(pd.concat)` shows it as part of the pandas module.
- **Repository Evidence**: The overload stubs in `concat.py` are already decorated with `@set_module('pandas')`. Other functions in the reshape module (e.g., `melt`, `pivot`) use the same pattern.
- **Uncertainty**: Whether the decorator should be on the overloads only or also on the implementation. Typically it's on the implementation.

---

## L2. Functional Design Graph

### N1: `concat` (Public Entry Point)
- **Kind**: Function
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` lines 75-154 (overload stubs). Must be the main implementation at approximately line 155+ (in the blank gap before `_sanitize_mixed_ndim` at line 456).

### N2: `_sanitize_mixed_ndim`
- **Kind**: Helper Function
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` lines 456-617. Handles promotion of Series to DataFrame when mixed dimensions detected.

### N3: `new_axes`
- **Kind**: Helper Function
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` lines 619-700. Computes the new [index, columns] for the concatenated result.

### N4: `_get_concat_axis_dataframe`
- **Kind**: Helper Function
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` lines 701-831. Computes the concatenation-axis index, handling `ignore_index`, `keys`, `verify_integrity`.

### N5: `_make_concat_multiindex`
- **Kind**: Helper Function
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` lines 839-949. Creates a MultiIndex from keys/levels/names for hierarchical index construction.

### N6: `validate_unique_levels`
- **Kind**: Helper Function
- **Repository Evidence**: `/testbed/pandas/core/reshape/concat.py` lines 833-837. Validates that level values are unique.

### N7: `_concat_indexes`
- **Kind**: Helper Function (MISSING)
- **Repository Evidence**: Called at lines 721 and 885 of `concat.py` but not defined. Must be implemented.

### N8: `concatenate_managers`
- **Kind**: Function (Internal)
- **Repository Evidence**: `/testbed/pandas/core/internals/concat.py` lines 60-156. Concatenates BlockManagers. Called by `concat` to perform actual data concatenation.

### N9: `concat_compat`
- **Kind**: Helper Function (MISSING from `pandas.core.dtypes.concat`)
- **Repository Evidence**: Called from multiple modules. Tests in `/testbed/pandas/tests/dtypes/test_concat.py`. Must be defined in `/testbed/pandas/core/dtypes/concat.py`.

### N10: `get_objs_combined_axis`
- **Kind**: Function (External)
- **Repository Evidence**: `/testbed/pandas/core/indexes/api.py` line 63. Computes the union/intersection of non-concatenation axes.

### N11: `default_index`
- **Kind**: Function (External)
- **Repository Evidence**: `/testbed/pandas/core/indexes/api.py` line 336. Creates a RangeIndex of length n.

### N12: `ensure_index`
- **Kind**: Function (External)
- **Repository Evidence**: Imported in `concat.py` from `pandas.core.indexes.api`.

### N13: `all_indexes_same`
- **Kind**: Function (External)
- **Repository Evidence**: `/testbed/pandas/core/indexes/api.py` line 318. Checks if all indexes in a list are equal.

### N14: `get_unanimous_names`
- **Kind**: Function (External)
- **Repository Evidence**: `/testbed/pandas/core/indexes/base.py` line 7810. Returns unanimous index names.

### N15: `union_categoricals`
- **Kind**: Function (Existing in `pandas.core.dtypes.concat`)
- **Repository Evidence**: `/testbed/pandas/core/dtypes/concat.py` lines 160-320 approximate. Already implemented.

### E1: `concat` -> `_sanitize_mixed_ndim` (CALL)
- **Condition**: When `objs` list contains mixed Series and DataFrame with axis=0.
- **Transfer**: `(objs, sample, ignore_index, axis)` → `list[Series | DataFrame]`
- **Evidence**: The helper exists for this purpose in concat.py.
- **Obligations**: R6, R14

### E2: `concat` -> `new_axes` (CALL)
- **Condition**: Always (to determine result axes).
- **Transfer**: `(objs, bm_axis, intersect, sort, keys, names, axis, levels, verify_integrity, ignore_index)` → `list[Index]`
- **Evidence**: The helper's docstring says "Return the new [index, column] result for concat."
- **Obligations**: R8, R9, R10, R11, R12

### E3: `new_axes` -> `_get_concat_axis_dataframe` (CALL)
- **Condition**: For the concatenation axis index (i == bm_axis).
- **Transfer**: `(objs, axis, ignore_index, keys, names, levels, verify_integrity)` → `Index`
- **Evidence**: Called in list comprehension at line 652-660 of concat.py.
- **Obligations**: R9, R10, R11

### E4: `new_axes` -> `get_objs_combined_axis` (CALL)
- **Condition**: For the non-concatenation axis (i != bm_axis).
- **Transfer**: `(objs, axis, intersect, sort)` → `Index`
- **Evidence**: Called in list comprehension at line 661-666 of concat.py.
- **Obligations**: R8, R12

### E5: `_get_concat_axis_dataframe` -> `_concat_indexes` (CALL)
- **Condition**: When `keys is None` and `ignore_index is False`.
- **Transfer**: `(list[Index])` → `Index`
- **Evidence**: Line 721 of concat.py.
- **Obligations**: R15

### E6: `_get_concat_axis_dataframe` -> `_make_concat_multiindex` (CALL)
- **Condition**: When `keys is not None`.
- **Transfer**: `(indexes, keys, levels, names)` → `MultiIndex`
- **Evidence**: Line 724 of concat.py.
- **Obligations**: R10

### E7: `_make_concat_multiindex` -> `_concat_indexes` (CALL)
- **Condition**: When indexes have different sizes and keys are provided.
- **Transfer**: `(list[Index])` → `Index`
- **Evidence**: Line 885 of concat.py.
- **Obligations**: R15

### E8: `_make_concat_multiindex` -> `validate_unique_levels` (CALL)
- **Condition**: When `levels` is provided (not None).
- **Transfer**: `(list[Index])` → `None` (raises on failure)
- **Evidence**: Lines 862, 869 of concat.py.
- **Obligations**: R10

### E9: `concat` -> `concatenate_managers` (CALL)
- **Condition**: After computing new axes, to concatenate the internal block managers.
- **Transfer**: `(mgrs_indexers, axes, concat_axis, copy)` → `BlockManager`
- **Evidence**: Standard pandas pattern for DataFrame concatenation.
- **Obligations**: R13

### E10: `concatenate_managers` -> `concat_compat` (CALL)
- **Condition**: When concatenating extension array values or non-uniform blocks.
- **Transfer**: `(list[ArrayLike], axis=..., ea_compat_axis=...)` → `ArrayLike`
- **Evidence**: Lines 136, 139, 396, 400 of `/testbed/pandas/core/internals/concat.py`.
- **Obligations**: R16, R17

### E11: `concat` -> `pandas.core.reshape.concat` (IMPORT BOUNDARY)
- **Condition**: External callers import via `from pandas.core.reshape.concat import concat` or `from pandas import concat`.
- **Transfer**: The `@set_module('pandas')` decorator exposes the function under the `pandas` namespace.
- **Evidence**: `/testbed/pandas/__init__.py` line 286 lists `"concat"` in `__all__`. `/testbed/pandas/core/reshape/reshape.py` line 53 imports it.
- **Obligations**: R1

### E12: `concat_compat` -> `pandas.core.dtypes.concat` (IMPORT BOUNDARY)
- **Condition**: Callers import `concat_compat` from `pandas.core.dtypes.concat`.
- **Transfer**: Function reference.
- **Evidence**: Tests at `/testbed/pandas/tests/dtypes/test_concat.py` line 3: `import pandas.core.dtypes.concat as _concat`.
- **Obligations**: R16

---

## L3. Verifiable Contracts

### C1: `concat` is importable from `pandas`
- **Type**: Import Boundary
- **Subject**: `pandas.concat`
- **Relation**: `IMPORT_BOUNDARY`
- **Expected**: `import pandas; pandas.concat` resolves to the function defined at `/testbed/pandas/core/reshape/concat.py` with `__module__ == 'pandas'`.
- **Evidence**: Task Interface Description 1 shows `@set_module('pandas')`. `/testbed/pandas/__init__.py` line 286 lists `"concat"` in `__all__`.
- **Observe**: `IMPORT_BOUNDARY`
- **Target**: `pandas.concat`
- **Obligations**: R1, R21
- **Graph**: N1, E11

### C2: `concat` accepts list of Series, returns Series (axis=0)
- **Type**: Behavior
- **Subject**: `concat([Series, Series])`
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns a `Series` whose values are the concatenation of input values and whose index is the concatenation of input indexes.
- **Evidence**: Task docstring example: `pd.concat([s1, s2])` returns Series.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R7, R14
- **Graph**: N1, E2

### C3: `concat` accepts list of DataFrame, returns DataFrame (axis=0)
- **Type**: Behavior
- **Subject**: `concat([DataFrame, DataFrame])`
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns a `DataFrame` with rows concatenated. Index is concatenation of input indexes. Columns use outer join by default.
- **Evidence**: Task docstring example: `pd.concat([df1, df2])` returns DataFrame.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R7, R8, R14
- **Graph**: N1, E2, E9

### C4: `concat` with `axis=1` always returns DataFrame
- **Type**: Behavior
- **Subject**: `concat([s1, s2], axis=1)`
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns a `DataFrame` even when all inputs are Series.
- **Evidence**: Task docstring: `"When concatenating along the columns (axis=1), a DataFrame is returned."`
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R7, R14
- **Graph**: N1

### C5: `concat` with `ignore_index=True` produces RangeIndex
- **Type**: Behavior
- **Subject**: `concat([s1, s2], ignore_index=True)`
- **Relation**: `RETURN_VALUE`
- **Expected**: Result index is `RangeIndex(0, n)` where n is total length.
- **Evidence**: Task docstring example: `pd.concat([s1, s2], ignore_index=True)` produces RangeIndex.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R9
- **Graph**: N1, E3, N4, N11

### C6: `concat` with `ignore_index=True` and `keys` raises ValueError
- **Type**: Exception
- **Subject**: `concat([s1, s2], ignore_index=True, keys=['a','b'])`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError`.
- **Evidence**: Task docstring Raises section.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R9
- **Graph**: N1

### C7: `concat` with `keys` builds MultiIndex
- **Type**: Behavior
- **Subject**: `concat([s1, s2], keys=['s1','s2'])`
- **Relation**: `RETURN_VALUE`
- **Expected**: Result has MultiIndex with outer level `['s1', 's2']` and inner level from original indexes.
- **Evidence**: Task docstring example.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R10
- **Graph**: N1, E3, E6, N5

### C8: `concat` with `keys`, `levels`, `names` constructs MultiIndex with specified levels
- **Type**: Behavior
- **Subject**: `concat([df, df2, df, df2], keys=[('foo','one'), ('foo','two'), ('baz','one'), ('baz','two')], levels=[['foo','baz'], ['one','two']], names=['first','second'])`
- **Relation**: `RETURN_VALUE`
- **Expected**: Result has MultiIndex with levels matching the specified levels and names.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_concat.py` `test_concat_keys_and_levels`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R10
- **Graph**: N1, E6, N5, E8, N6

### C9: `concat` with `verify_integrity=True` detects duplicates
- **Type**: Exception
- **Subject**: `concat([df5, df6], verify_integrity=True)` where both have index `['a']`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError` with message containing `"Indexes have overlapping values"`.
- **Evidence**: Task docstring example. Tests in `/testbed/pandas/tests/reshape/concat/test_concat.py`.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R11
- **Graph**: N1, E3, N4

### C10: `concat` with `join='inner'` returns only shared columns
- **Type**: Behavior
- **Subject**: `concat([df1, df3], join='inner')` where df1 has columns [letter, number] and df3 has [letter, number, animal]
- **Relation**: `RETURN_VALUE`
- **Expected**: Result has only columns `['letter', 'number']`.
- **Evidence**: Task docstring example.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R8
- **Graph**: N1, E2, E4, N10

### C11: `concat` with `join='outer'` fills missing columns with NaN
- **Type**: Behavior
- **Subject**: `concat([df1, df3], join='outer')` where df1 lacks 'animal' column
- **Relation**: `RETURN_VALUE`
- **Expected**: Result has all columns `['letter', 'number', 'animal']` with NaN in 'animal' for df1 rows.
- **Evidence**: Task docstring example: `pd.concat([df1, df3], sort=False)`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R8
- **Graph**: N1, E2, E4, N10

### C12: `concat` with non-iterable first argument raises TypeError
- **Type**: Exception
- **Subject**: `concat(DataFrame(range(2)))`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `TypeError` with message `"first argument must be an iterable of pandas objects, you passed an object of type \"DataFrame\""`.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_invalid.py` `test_concat_invalid_first_argument`.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R2
- **Graph**: N1

### C13: `concat` with non-pandas objects raises TypeError
- **Type**: Exception
- **Subject**: `concat([DataFrame, 1])`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `TypeError` with message matching `"cannot concatenate object of type 'int'; only Series and DataFrame objs are valid"`.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_invalid.py` `test_concat_invalid`.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R3
- **Graph**: N1

### C14: `concat` with all None raises ValueError
- **Type**: Exception
- **Subject**: `concat([None, None])`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError`.
- **Evidence**: Task docstring: `"Any None objects will be dropped silently unless they are all None in which case a ValueError will be raised."`
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R4
- **Graph**: N1

### C15: `concat` with empty list raises ValueError
- **Type**: Exception
- **Subject**: `concat([])`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError` indicating no objects to concatenate.
- **Evidence**: Task docstring Raises section.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R5
- **Graph**: N1

### C16: `concat` with invalid `join` raises ValueError
- **Type**: Exception
- **Subject**: `concat([df1, df2], join='invalid')`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError`.
- **Evidence**: Task docstring Raises section.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R8
- **Graph**: N1

### C17: `concat` with generator argument succeeds
- **Type**: Behavior
- **Subject**: `concat(DataFrame(...) for _ in range(3))`
- **Relation**: `RETURN_VALUE`
- **Expected**: Successfully concatenates the generated DataFrames.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_invalid.py` `test_concat_generator_obj`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R2
- **Graph**: N1

### C18: `concat` with Mapping uses keys from mapping
- **Type**: Behavior
- **Subject**: `concat({'foo': df1, 'bar': df2})`
- **Relation**: `RETURN_VALUE`
- **Expected**: Equivalent to `concat([df1, df2], keys=['foo', 'bar'])`.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_concat.py` `test_concat_mapping`. Task docstring: `"If a mapping is passed, the keys will be used as the keys argument."`
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R2, R10
- **Graph**: N1

### C19: `concat` with mixed Series/DataFrame promotes Series to DataFrame
- **Type**: Behavior
- **Subject**: `concat([Series, DataFrame])`
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns DataFrame. Series is promoted via `_sanitize_mixed_ndim`.
- **Evidence**: `/testbed/pandas/core/reshape/concat.py` `_sanitize_mixed_ndim` helper. Task docstring: `"When objs contains at least one DataFrame, a DataFrame is returned."`
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R6, R14
- **Graph**: N1, E1, N2

### C20: `concat` preserves Series name
- **Type**: Behavior
- **Subject**: `concat([s1, s2])` where s1 has `name='foo'`
- **Relation**: `RETURN_VALUE`
- **Expected**: Result Series has `name='foo'` if all Series share the same name.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_series.py` `test_concat_series`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R14
- **Graph**: N1

### C21: `concat` with `sort=True` sorts non-concatenation axis
- **Type**: Behavior
- **Subject**: `concat([df1, df2], sort=True)` with different columns
- **Relation**: `RETURN_VALUE`
- **Expected**: Columns are sorted in the result.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_sort.py`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R12
- **Graph**: N1, E4, N10

### C22: `concat` with `copy=True` ensures no shared memory
- **Type**: Behavior
- **Subject**: `concat([df, df2], axis=1, copy=True)`
- **Relation**: `RETURN_VALUE`
- **Expected**: Blocks in result do not share memory with input blocks.
- **Evidence**: `/testbed/pandas/tests/reshape/concat/test_concat.py` `test_concat_copy`.
- **Observe**: `SIDE_EFFECT` (memory isolation)
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R13
- **Graph**: N1, E9, N8

### C23: `_concat_indexes` concatenates Index objects
- **Type**: Behavior
- **Subject**: `_concat_indexes([idx1, idx2, idx3])`
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns a single Index that is the concatenation of all input indexes.
- **Evidence**: Called at lines 721, 885 of concat.py. Function must be defined.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:_concat_indexes` (or wherever defined)
- **Obligations**: R15
- **Graph**: N7, E5, E7

### C24: `concat_compat` concatenates array-like objects
- **Type**: Behavior
- **Subject**: `concat_compat([arr1, arr2], axis=0)`
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns concatenated array preserving dtype where possible. Handles ExtensionArray, numpy arrays, Categoricals.
- **Evidence**: `/testbed/pandas/tests/dtypes/test_concat.py` tests: `test_concat_mismatched_categoricals_with_empty`, `test_concat_periodarray_2d`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/dtypes/concat.py:concat_compat`
- **Obligations**: R16
- **Graph**: N9, E10, E12

### C25: `concat_compat` validates axis dimensions
- **Type**: Exception
- **Subject**: `concat_compat([arr[:, :2], arr[:, 2:]], axis=0)` for 2D arrays with mismatched dimensions
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError` with message matching `"all the input array dimensions.* for the concatenation axis must match exactly"`.
- **Evidence**: `/testbed/pandas/tests/dtypes/test_concat.py` `test_concat_periodarray_2d`.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/dtypes/concat.py:concat_compat`
- **Obligations**: R16
- **Graph**: N9

### C26: `concat_compat` handles empty Categorical arrays
- **Type**: Behavior
- **Subject**: `concat_compat([cat1_values, empty_cat_values])`
- **Relation**: `RETURN_VALUE`
- **Expected**: Result matches `pd.concat([ser1, ser2])._values` for Categorical Series.
- **Evidence**: `/testbed/pandas/tests/dtypes/test_concat.py` `test_concat_mismatched_categoricals_with_empty`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/dtypes/concat.py:concat_compat`
- **Obligations**: R16
- **Graph**: N9

### C27: `concat` with DatetimeIndex and join='outer' always sorts
- **Type**: Behavior
- **Subject**: `concat([df1, df2])` where non-concatenation axis is DatetimeIndex
- **Relation**: `RETURN_VALUE`
- **Expected**: The non-concatenation axis is sorted lexicographically regardless of `sort` parameter.
- **Evidence**: Task docstring: `"One exception to this is when the non-concatenation axis is a DatetimeIndex and join='outer' and the axis is not already aligned."`
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R12
- **Graph**: N1, E4, N10

### C28: `concat` with tz-aware Series and empty Series (axis=1)
- **Type**: Behavior
- **Subject**: `concat([ser1, ser2], axis=1)` where ser1 has tz-aware DatetimeIndex and ser2 is empty
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns DataFrame with correct tz-aware index.
- **Evidence**: `/testbed/pandas/tests/dtypes/test_concat.py` `test_concat_series_between_empty_and_tzaware_series`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R7
- **Graph**: N1

### C29: `concat` single DataFrame returns equal copy
- **Type**: Behavior
- **Subject**: `concat([df])` for a tz-aware DataFrame
- **Relation**: `RETURN_VALUE`
- **Expected**: Returns DataFrame equal to input.
- **Evidence**: `/testbed/pandas/tests/dtypes/test_concat.py` `test_concat_single_dataframe_tz_aware`.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R7
- **Graph**: N1

### C30: `concat` with `levels` but no `keys` raises ValueError
- **Type**: Exception
- **Subject**: `concat([df1, df2], levels=[...])` without keys
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError("levels supported only when keys is not None")`.
- **Evidence**: `/testbed/pandas/core/reshape/concat.py` line 719: `raise ValueError("levels supported only when keys is not None")`.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R10
- **Graph**: N1, E3, N4

### C31: `concat` with `keys` length mismatch raises ValueError
- **Type**: Exception
- **Subject**: `concat([df1, df2, df3], keys=['a', 'b'])`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError`.
- **Evidence**: Task docstring Raises section.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R10
- **Graph**: N1

### C32: `concat` with non-unique levels raises ValueError
- **Type**: Exception
- **Subject**: `concat([df1, df2], keys=['a', 'b'], levels=[['a', 'a']])`
- **Relation**: `EXCEPTION`
- **Expected**: Raises `ValueError("Level values not unique: ...")`.
- **Evidence**: `/testbed/pandas/core/reshape/concat.py` `validate_unique_levels`.
- **Observe**: `EXCEPTION`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R10
- **Graph**: N1, E8, N6

### C33: `concat` sorts non-concatenation axis when join='outer' and DatetimeIndex
- **Type**: Behavior
- **Subject**: `concat([df1, df2], sort=False)` where non-concat axis is DatetimeIndex and not aligned
- **Relation**: `RETURN_VALUE`
- **Expected**: The DatetimeIndex axis is sorted despite `sort=False`.
- **Evidence**: Task docstring special exception note.
- **Observe**: `RETURN_VALUE`
- **Target**: `/testbed/pandas/core/reshape/concat.py:concat`
- **Obligations**: R12
- **Graph**: N1, E4, N10
