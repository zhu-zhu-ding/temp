# Spec Review Report

## Evidence Reviewed

| Source | Path | Lines / Scope |
|--------|------|---------------|
| Task document | (primary oracle) | Full interface description for `concat` |
| Semantic IR | `artifacts/semantic_ir.md` | 677 lines; R1–R21, N1–N15, E1–E12, C1–C33 |
| Architecture spec | `artifacts/arch_spec.py` | 14 checks covering imports, call-graph edges, module structure |
| Behavior spec | `artifacts/behavior_spec.py` | 47 checks covering return values, failures, boundaries, state |
| Review skill | `/installed-agent/codespec2/review_skill.md` | 8 seed rubrics |
| Static issues | `artifacts/static_issues.md` | 10 files flagged for missing imports |
| Static analysis | `artifacts/static_analysis.md` | Summary of the same 10 files |
| Repository source | `/testbed/pandas/core/reshape/concat.py` | 949 lines: 5 overload stubs (L75–155), `_sanitize_mixed_ndim` (L456), `new_axes` (L619), `_get_concat_axis_dataframe` (L701), `validate_unique_levels` (L833), `_make_concat_multiindex` (L839). **No `concat` implementation body; no `_concat_indexes` definition.** |
| Repository source | `/testbed/pandas/core/dtypes/concat.py` | `_is_nonempty` defined; `union_categoricals` defined; **`concat_compat` not defined.** |
| Repository source | `/testbed/pandas/core/internals/concat.py` | `concatenate_managers` uses `concat_compat` (L136, L139, L396, L400) **without import.** |
| Repository tests | `/testbed/pandas/tests/reshape/concat/test_concat.py` | 1003 lines; 42 test functions covering core concat behavior |
| Repository tests | `/testbed/pandas/tests/reshape/concat/test_invalid.py` | `test_concat_invalid`, `test_concat_invalid_first_argument`, `test_concat_generator_obj`, `test_concat_textreader_obj` |
| Repository tests | `/testbed/pandas/tests/reshape/concat/test_empty.py` | 17 test functions covering empty-object edge cases |
| Repository tests | `/testbed/pandas/tests/reshape/concat/test_series.py` | `test_concat_series`, `test_concat_series_axis1`, `test_concat_series_axis1_preserves_series_names`, `test_concat_empty_and_non_empty_series_regression`, `test_concat_bool_and_numeric` |
| Repository tests | `/testbed/pandas/tests/reshape/concat/test_sort.py` | `test_concat_sort_none_raises` expects exact message `"The 'sort' keyword only accepts boolean values; None was passed."` |
| Repository tests | `/testbed/pandas/tests/reshape/concat/test_index.py` | `test_concat_copy_index_series`, `test_concat_copy_index_frame`, `test_concat_axis_parameter` aliases |
| Repository tests | `/testbed/pandas/tests/reshape/concat/test_dataframe.py` | `test_concat_axis_parameter` tests `'index'`, `'rows'`, `'columns'` aliases |
| Repository tests | `/testbed/pandas/tests/dtypes/test_concat.py` | Tests for `concat_compat` in `pandas.core.dtypes.concat` |

## Rubric Scores

### 1. Requirement Coverage (seed)

**Score: FAIL**

Every atomic task requirement must have a traceable R/G/C path and one or more executable observations. Three critical missing-function artifacts are present:

- **R15 / C23**: `_concat_indexes` is called at `/testbed/pandas/core/reshape/concat.py` lines 721 and 885 but never defined. The arch spec `check_R15_C23_concat_indexes_defined_and_callable` checks `hasattr(concat_module, "_concat_indexes")` — this check would fail at runtime because the symbol does not exist. The behavior spec `check_C23_concat_indexes_concatenates_index_objects` also calls it directly. These are executable observations of a function that is not yet implemented; they are design intent, not validation of a working artifact. As executable specifications they are correct in their *intent* but the artifact they observe does not yet exist.

- **R16 / C24–C26**: `concat_compat` is called at `/testbed/pandas/core/internals/concat.py` lines 136, 139, 396, 400; at `/testbed/pandas/core/frame.py` lines 12129, 12163; and at `/testbed/pandas/core/reshape/melt.py` line 350. The function is never defined in `/testbed/pandas/core/dtypes/concat.py`. The arch spec `check_R17_concat_compat_importable_in_internals_concat` checks `hasattr(dtypes_concat, "concat_compat")` — this check would fail. The behavior spec checks C24–C26 call `concat_compat` directly — these would also fail.

- **R1 / C1**: The `concat` symbol has 5 `@overload` stubs but no implementation body. Importing it resolves to `_overload_dummy`, which raises `NotImplementedError` when called. The arch spec checks `hasattr(pd, "concat")` and `callable(pd.concat)` — both pass for the dummy. But calling `pd.concat(...)` would fail.

**Affected IDs**: R1, R15, R16, R17, R18, R19, C1, C23, C24, C25, C26, E5, E7, E9, E10, E12

---

### 2. Requirement Fidelity (seed)

**Score: FAIL**

Several spec checks assert relations weaker than what the task and repository tests require:

- **Mixed ndim error class (R6)**: The task docstring says `TypeError: If trying to concatenate unaligned mixed dimensional NDFrame objects.` The existing `_sanitize_mixed_ndim` raises `ValueError`. The IR explicitly notes this discrepancy. The behavior spec `check_R6_unaligned_mixed_ndim_raises_valueerror` only checks `hasattr` for the helper — it does not test which exception class is actually raised, nor does it resolve the TypeError-vs-ValueError conflict. **This is a requirement misread.**

- **`copy` parameter default (R1)**: The interface description states `copy: bool, default False`. The overload stubs declare `copy: bool | lib.NoDefault = ...`. The IR notes this as uncertainty. No spec check verifies which default the implementation uses.

**Affected IDs**: R6, R1

---

### 3. Caller Binding and Architecture (seed)

**Score: FAIL**

Material CALL edges are not verified through the actual runtime call sites:

- **`concat` → `_concat_indexes` (E5, E7)**: The arch spec `check_E5_E7_concat_indexes_in_control_flow` exercises these paths by calling `pd.concat(...)`, which would fail because `concat` has no implementation body. The check does not verify that the call at line 721 (`_concat_indexes(indexes)`) or line 885 actually resolves.

- **`concat_compat` → `internals/concat.py` (E10)**: The arch spec `check_E9_E10_concat_to_concatenate_managers` only checks that `concatenate_managers` is importable and callable. It does not verify that `concat_compat` resolves at the actual call sites inside `concatenate_managers` (lines 136, 139, 396, 400). Static issue confirms `concat_compat` is used but never imported in `internals/concat.py`.

- **Downstream `concat` imports (R20)**: The static issues list 8 modules (`generic.py`, `describe.py`, `resample.py`, `melt.py`, `pivot.py`, `rolling.py`, `_json.py`, `pytables.py`) where `concat` is used without import. The arch spec `check_R20_concat_imports_resolve_in_downstream_modules` only imports core modules (`frame.py`, `series.py`, etc.) that already have imports, and does not verify the flagged modules. No runtime check exercises those specific call sites.

**Affected IDs**: R17, R20, E5, E7, E9, E10, static issues for 8 downstream modules

---

### 4. Dataflow and Lifecycle (seed)

**Score: FAIL**

- **Copy/memory isolation (C22, R13)**: The behavior spec `check_C22_copy_ensures_no_shared_memory` only checks result shape `(8, 3)`. It does not verify memory isolation. The repository test `test_concat_copy` (test_concat.py:48–84) performs precise block-level checks: it verifies `arr.base is df._mgr.blocks[0].values.base` for float blocks, `arr.base is df2._mgr.blocks[0].values.base` for int blocks, and uses `np.shares_memory` for consolidated cases. The spec’s shape-only check cannot distinguish a correct implementation (data copied) from a wrong one (data shared).

- **Input non-mutation**: No spec check verifies that `concat` does not mutate input objects. This is a standard pandas expectation that repository tests implicitly rely on.

**Affected IDs**: C22, R13

---

### 5. Failure and Compatibility (seed)

**Score: FAIL**

Several failure checks lack the diagnostic precision required by repository tests:

- **`sort` validation (R12)**: `check_C21_sort_parameter_non_bool_raises_valueerror` only checks `pytest.raises(ValueError)` without a message match. The repository test `test_concat_sort_none_raises` (test_sort.py:113–118) expects the exact message `"The 'sort' keyword only accepts boolean values; None was passed."` There is no `sort` type validation in the current concat.py code; the spec check is correct in intent but uses a weak oracle.

- **`join` validation (R8)**: `check_C16_invalid_join_raises_valueerror` checks `pytest.raises(ValueError)` without a message match.

- **`all_none` (R4)**: `check_C14_all_none_raises_valueerror` checks `pytest.raises(ValueError)` without matching the expected message. Repository test `test_concat_exclude_none` (test_concat.py:382–389) expects `"All objects passed were None"`.

- **Empty list (R5)**: `check_C15_empty_list_raises_valueerror` checks `pytest.raises(ValueError)` without matching `"No objects to concatenate"`, which the repository test `test_concat_no_items_raises` (test_concat.py:378–379) explicitly matches.

- **Missing axis alias tests**: The interface description says `axis: {0/'index', 1/'columns'}`. Repository test `test_concat_axis_parameter` (test_dataframe.py) tests `axis='index'`, `axis='rows'`, `axis=0`, `axis='columns'`, `axis=1`. The behavior spec only tests `axis=0` and `axis=1`.

**Affected IDs**: R12, R8, R4, R5, C16, C21

---

### 6. Static-Issue Closure (seed)

**Score: FAIL**

The static issues list 10 files with missing imports. The arch spec disposition states that flagged modules "may use local imports inside function bodies" and verifies only core import paths. However:

- `concat_compat` in `internals/concat.py`: No import exists anywhere and the function itself is not defined. The arch spec `check_R17` checks symbol existence but cannot close this issue because the symbol truly does not exist.

- `concat_compat` in `frame.py` and `melt.py`: Same — the function does not exist.

- `concat` in `generic.py`, `describe.py`, `resample.py`, `melt.py`, `pivot.py`, `rolling.py`, `_json.py`, `pytables.py`: The arch spec does not verify these specific modules. The disposition is speculative rather than evidence-backed.

- `_concat_indexes` in `concat.py`: Never defined. The arch spec `check_R15_C23` checks `hasattr` — this is a correct requirement but the symbol does not exist.

**Affected IDs**: All 10 files in static issues

---

### 7. Repository-Test Alignment (seed)

**Score: PARTIAL**

The specs cite repository tests but several generated checks diverge from repository test design:

- **Copy test**: Repository `test_concat_copy` uses block-level `arr.base` and `np.shares_memory` checks. The spec `check_C22_copy_ensures_no_shared_memory` uses only shape assertions. **Divergence.**

- **Sort validation**: Repository `test_concat_sort_none_raises` expects an exact error message. The spec `check_C21_sort_parameter_non_bool_raises_valueerror` does not. **Divergence.**

- **Series name preservation (C20)**: Repository `test_concat_series_axis1_preserves_series_names` checks both named and unnamed Series (name → column name, unnamed → integer column). The spec `check_concat_series_axis1_preserves_names` only checks the named case. **Partial coverage.**

**Affected IDs**: C22, C21 (sort), C20

---

### 8. Oracle Strength (seed)

**Score: FAIL**

Several oracles are too weak to discriminate correct from wrong implementations:

| Check | Oracle | Gap |
|-------|--------|-----|
| `check_C22_copy_ensures_no_shared_memory` | `result.shape == (8, 3)` | Does not verify copy semantics |
| `check_concat_copy_false_shares_memory_where_safe` | `result.shape == (8, 3)` | Does not verify memory sharing |
| `check_C14_all_none_raises_valueerror` | `pytest.raises(ValueError)` (no match) | Does not distinguish from other ValueErrors |
| `check_C16_invalid_join_raises_valueerror` | `pytest.raises(ValueError)` (no match) | Does not distinguish from other ValueErrors |
| `check_C21_sort_parameter_non_bool_raises_valueerror` | `pytest.raises(ValueError)` (no match) | Does not match repository-expected message |
| `check_R6_unaligned_mixed_ndim_raises_valueerror` | `hasattr` check only | Does not test actual exception behavior |

**Affected IDs**: C14, C16, C21, C22, R6, R13

---

## Findings

### Finding 1: `missing_requirement` — `_concat_indexes` function not defined

- **Affected IDs**: R15, C23, E5, E7
- **Static issue**: `/testbed/pandas/core/reshape/concat.py`: `'_concat_indexes' is used but not defined or imported in this file`
- **Repository evidence**: `/testbed/pandas/core/reshape/concat.py` line 721 (`concat_axis = _concat_indexes(indexes)` in `_get_concat_axis_dataframe`) and line 885 (`concat_index = _concat_indexes(indexes)` in `_make_concat_multiindex`). No `def _concat_indexes` exists anywhere in the repository.
- **Gap**: The function is a critical dataflow node called from two different control paths. Without it, `_get_concat_axis_dataframe` (keys=None path) and `_make_concat_multiindex` (different-sized indexes path) both fail with `NameError`. Both the arch spec (`check_R15_C23_concat_indexes_defined_and_callable`) and behavior spec (`check_C23_concat_indexes_concatenates_index_objects`) assert on a symbol that does not exist.
- **Rework instruction**: Define `_concat_indexes(indexes: list[Index]) -> Index` in `/testbed/pandas/core/reshape/concat.py` that concatenates a list of Index objects, handling RangeIndex, MultiIndex, and plain Index, returning a single Index. The arch spec's `check_R15_C23` gives a concrete expected behavior: `_concat_indexes([Index([0,1,2]), Index([3,4,5])])` should equal `Index([0,1,2,3,4,5])`.

### Finding 2: `missing_requirement` — `concat_compat` function not defined in `pandas.core.dtypes.concat`

- **Affected IDs**: R16, R17, R18, R19, C24, C25, C26, E10
- **Static issue**: `pandas/core/frame.py`: `'concat_compat' is used but not defined or imported`; `pandas/core/reshape/melt.py`: `'concat_compat' is used but not defined or imported`
- **Repository evidence**: `/testbed/pandas/core/internals/concat.py` lines 136, 139, 396, 400 call `concat_compat(...)` without importing it. `/testbed/pandas/core/frame.py` lines 12129, 12163 call `concat_compat(...)` without importing it. `/testbed/pandas/core/reshape/melt.py` line 350 calls `concat_compat(...)` without importing it. `/testbed/pandas/tests/dtypes/test_concat.py` tests `concat_compat` via `import pandas.core.dtypes.concat as _concat`. The function does not exist in `/testbed/pandas/core/dtypes/concat.py`.
- **Gap**: `concat_compat` is a critical utility called from 3 downstream modules on 6 call sites. Without it, `concatenate_managers` fails for extension arrays, `frame.py` stack/unstack operations fail, and `melt.py` fails. All behavior spec checks C24–C26 call this function.
- **Rework instruction**: Define `concat_compat(to_concat: list[ArrayLike], axis: AxisInt = 0, ea_compat_axis: bool = False) -> ArrayLike` in `/testbed/pandas/core/dtypes/concat.py`. It must: (a) concatenate numpy arrays via `np.concatenate`, (b) handle ExtensionArrays, (c) handle Categorical arrays (including mismatched/empty), (d) validate axis dimensions (raise `ValueError` with message matching `"all the input array dimensions.* for the concatenation axis must match exactly"`), and (e) be importable as `from pandas.core.dtypes.concat import concat_compat`. All call sites (`internals/concat.py`, `frame.py`, `melt.py`) must add the import `from pandas.core.dtypes.concat import concat_compat`.

### Finding 3: `missing_requirement` — `concat` implementation body not present

- **Affected IDs**: R1, R2, R3, R4, R5, R6, R7, R8, R9, R10, R11, R12, R13, R14, C1–C22, C27–C33
- **Repository evidence**: `/testbed/pandas/core/reshape/concat.py` lines 75–154 define 5 `@overload` stubs for `concat` but no implementation body. The symbol resolves to `_overload_dummy` which raises `NotImplementedError`. `/testbed/pandas/__init__.py` line 286 lists `"concat"` in `__all__` but the symbol is not callable.
- **Gap**: The entire `concat` function is a stub. All behavior spec checks that call `pd.concat(...)` would fail. The task explicitly requires this function to be callable and functional.
- **Rework instruction**: Implement the `concat` function body in `/testbed/pandas/core/reshape/concat.py` immediately after the overload stubs, decorated with `@set_module('pandas')`. The implementation must: (a) use keyword-only arguments matching the interface description (`*, axis=0, join='outer', ignore_index=False, keys=None, levels=None, names=None, verify_integrity=False, sort=False, copy=False`), (b) validate `objs` is iterable/mapping (raise `TypeError` for non-iterable), (c) filter None objects, raise `ValueError` if all None or empty, (d) validate each element is Series/DataFrame (raise `TypeError` for invalid types), (e) call `_sanitize_mixed_ndim` for mixed dimensions, (f) call `new_axes` to compute result axes, (g) call `concatenate_managers` to concatenate block managers, (h) construct and return the appropriate result type (Series for all-Series axis=0, DataFrame otherwise), (i) validate `join` in `{'inner', 'outer'}`, (j) validate `sort` is bool, (k) validate `ignore_index` and `keys` are not both set, (l) check keys length matches objects, and (m) route through `_get_concat_axis_dataframe` for index handling.

### Finding 4: `weak_constraint` — Copy oracle does not verify memory isolation

- **Affected IDs**: C22, R13
- **Repository evidence**: `/testbed/pandas/tests/reshape/concat/test_concat.py` `test_concat_copy` (lines 48–84) checks `arr.base is df._mgr.blocks[0].values.base`, `np.shares_memory`, and block-level provenance. The behavior spec `check_C22_copy_ensures_no_shared_memory` only checks `result.shape == (8, 3)`.
- **Gap**: A concat implementation that always deep-copies and one that always shares memory both pass the shape check. The spec cannot distinguish correct copy=False memory sharing from incorrect behavior.
- **Rework instruction**: Strengthen `check_C22_copy_ensures_no_shared_memory` to verify that with `copy=True`, result blocks do not share memory with input blocks (use `np.shares_memory` or `arr.base` provenance checks per the repository test pattern). Also verify that with `copy=False`, blocks *may* share memory where safe (aligning with the repository `test_concat_copy` pattern). Add a dedicated check for `copy=False` memory-sharing semantics.

### Finding 5: `weak_constraint` — Failure checks lack diagnostic message matching

- **Affected IDs**: C14 (R4), C15 (R5), C16 (R8), C21 (R12)
- **Repository evidence**:
  - `/testbed/pandas/tests/reshape/concat/test_concat.py:382`: `pytest.raises(ValueError, match="All objects passed were None")`
  - `/testbed/pandas/tests/reshape/concat/test_concat.py:378`: `pytest.raises(ValueError, match="No objects to concatenate")`
  - `/testbed/pandas/tests/reshape/concat/test_sort.py:116-118`: `pytest.raises(ValueError, match="The 'sort' keyword only accepts boolean values; None was passed.")`
- **Gap**: `check_C14_all_none_raises_valueerror`, `check_C15_empty_list_raises_valueerror`, `check_C16_invalid_join_raises_valueerror`, and `check_C21_sort_parameter_non_bool_raises_valueerror` all use bare `pytest.raises(ValueError)` without a `match` parameter. A wrong implementation that raises ValueError for a different reason would pass these checks.
- **Rework instruction**: Add `match=` with the exact error message substring to each check. For C14: `match="All objects passed were None"`. For C15: `match="No objects to concatenate"`. For C16: `match="'join' must be"` or the repository-expected message. For C21: `match="'sort' keyword only accepts boolean values"`.

### Finding 6: `missing_requirement` — Axis string aliases not tested

- **Affected IDs**: R7, R8
- **Repository evidence**: `/testbed/pandas/tests/reshape/concat/test_dataframe.py` `test_concat_axis_parameter` tests `axis='index'`, `axis='rows'`, `axis='columns'`, `axis=0`, `axis=1`. The interface description states `axis: {0/'index', 1/'columns'}`.
- **Gap**: The behavior spec only tests `axis=0` (default) and `axis=1`. The string aliases `'index'`, `'rows'`, `'columns'` and the invalid axis `'something'` are not tested.
- **Rework instruction**: Add a check that verifies `concat([s1, s2], axis='index')` returns Series, `concat([s1, s2], axis='columns')` returns DataFrame, and `concat([s1, s2], axis='something')` raises `ValueError` with `match="No axis named"`.

### Finding 7: `requirement_misread` — TypeError vs ValueError for mixed ndim

- **Affected IDs**: R6, E1
- **Repository evidence**: `/testbed/pandas/core/reshape/concat.py` `_sanitize_mixed_ndim` (L489–491) raises `ValueError("cannot concatenate unaligned mixed dimensional NDFrame objects")`. The task docstring `Raises` section says `TypeError: If trying to concatenate unaligned mixed dimensional NDFrame objects.` The IR explicitly flags this as an uncertainty.
- **Gap**: The behavior spec `check_R6_unaligned_mixed_ndim_raises_valueerror` only checks `hasattr` for the helper, not the actual exception class. The discrepancy between the task docstring (TypeError) and the existing code (ValueError) is unresolved.
- **Rework instruction**: Resolve the discrepancy: either change `_sanitize_mixed_ndim` to raise `TypeError` (matching the docstring) or update the docstring to say `ValueError`. Add a behavior spec check that tests the actual exception class with `pytest.raises` on the correct type.

### Finding 8: `missing_requirement` — `concat` import not verified in statically-flagged modules

- **Affected IDs**: R20, static issues for 8 modules
- **Static issue**: `generic.py`, `describe.py`, `resample.py`, `melt.py`, `pivot.py`, `rolling.py`, `_json.py`, `pytables.py` all flagged for using `concat` without import.
- **Gap**: The arch spec `check_R20_concat_imports_resolve_in_downstream_modules` only checks core modules that already have imports (`frame.py`, `series.py`, `groupby/groupby.py`, `reshape/reshape.py`, `reshape/merge.py`). The 8 flagged modules are not exercised. The spec's disposition ("may use local imports inside function bodies") is speculative and not evidence-backed.
- **Rework instruction**: Either (a) verify each flagged module can import and call `concat` successfully, or (b) for each flagged module, inspect the source and document whether a local import exists (if yes, add a runtime check; if no, flag it as a pre-existing issue that the concat implementation must not break). At minimum, add a check that imports each flagged module and verifies it doesn't fail at import time due to a missing `concat` symbol.

### Finding 9: `weak_constraint` — No input non-mutation verification

- **Affected IDs**: R13, R14
- **Repository evidence**: Standard pandas convention: operations should not mutate inputs. Repository tests implicitly rely on this (e.g., `test_concat_copy` verifies memory sharing but also implies inputs are unchanged).
- **Gap**: No spec check verifies that after `concat([df1, df2])`, the input DataFrames `df1` and `df2` are unchanged (same values, same columns, same index, same dtypes).
- **Rework instruction**: Add a check that concatenates two DataFrames/Series and then asserts the inputs are unchanged using `pd.testing.assert_frame_equal`/`assert_series_equal` against pre-concat copies.

---

## Decision

**Decision: REWORK**

Nine findings across all eight rubric dimensions. Three critical system artifacts (`concat` body, `_concat_indexes`, `concat_compat`) are entirely missing from the codebase, and the specs cannot execute against them. Multiple failure-path oracles lack the diagnostic precision required by repository tests. The `copy` parameter default ambiguity and the TypeError-vs-ValueError discrepancy for mixed ndim are unresolved requirement misreads. Static issues for 8 downstream modules remain unaddressed with runtime evidence.
