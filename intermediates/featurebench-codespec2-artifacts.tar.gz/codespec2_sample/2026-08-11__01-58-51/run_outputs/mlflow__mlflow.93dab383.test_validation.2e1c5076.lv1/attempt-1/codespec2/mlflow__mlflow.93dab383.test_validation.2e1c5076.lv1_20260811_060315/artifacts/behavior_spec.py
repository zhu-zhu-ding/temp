#!/usr/bin/env python3
"""
executable behavior spec

Covers states, outcomes, defaults, failures, side effects, boundaries, and
compatibility for the MLflow GenAI scorers validation system.

Each check_* function verifies a specific contract from the semantic IR.
"""

import importlib
import inspect
import logging
import sys
from io import StringIO
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd

import mlflow
from mlflow.exceptions import MlflowException


# ──────────────────────────────────────────────────────────────────────────────
# C1: CustomScorer class behavior
# Contracts: C1, R1
# Repository test guidance: tests/genai/scorers/test_scorer.py line 268
#   test_custom_scorer_allow_none_return verifies @scorer handles None return.
# Source: /testbed/mlflow/genai/scorers/base.py lines 999-1031
# Static issue: CustomScorer used but not defined
def check_c1_custom_scorer_behavior():
    """C1: CustomScorer instance has exact attribute and behavior contract.

    Verifies: _original_func stored via PrivateAttr, __call__ delegates,
    kind == ScorerKind.DECORATOR, name/description/aggregations stored,
    and __call__.__signature__ has self prepended.
    """
    from mlflow.genai.scorers.base import Scorer, ScorerKind

    def _original(inputs, outputs, expectations=None) -> bool:
        return bool(outputs)

    instance = mlflow.genai.scorers.scorer(
        _original, name="test_c1", description="test desc", aggregations=["min", "max"]
    )

    # 1. Must be Scorer instance
    assert isinstance(instance, Scorer), f"C1: not Scorer instance: {type(instance)}"

    # 2. kind must be DECORATOR
    assert instance.kind == ScorerKind.DECORATOR, (
        f"C1: kind={instance.kind}, expected DECORATOR"
    )

    # 3. name, description, aggregations
    assert instance.name == "test_c1", f"C1: name={instance.name}"
    assert instance.description == "test desc", f"C1: description={instance.description}"
    assert instance.aggregations == ["min", "max"], f"C1: aggregations={instance.aggregations}"

    # 4. _original_func set
    assert hasattr(instance, "_original_func"), "C1: no _original_func"
    assert instance._original_func is _original, "C1: _original_func wrong function"

    # 5. __call__ delegates to original
    assert instance(inputs="in", outputs="hello") is True, "C1: __call__ delegation failed"
    assert instance(inputs="in", outputs="") is False, "C1: __call__ delegation failed (2)"

    # 6. __call__.__signature__ has self prepended
    sig = inspect.signature(instance.__call__)
    params = list(sig.parameters.keys())
    assert params[0] == "self", f"C1: __call__ sig missing 'self' first: {params}"

    # 7. default name from function name
    def some_test_func(outputs):
        return outputs

    instance2 = mlflow.genai.scorers.scorer(some_test_func)
    assert instance2.name == "some_test_func", (
        f"C1: default name={instance2.name}, expected 'some_test_func'"
    )

    print("PASS: C1 - CustomScorer behavior correct")


# ──────────────────────────────────────────────────────────────────────────────
# C2: validate_scorers accepts valid Scorer instances
# Contracts: C2, R2
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 26-98.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c2_validate_scorers_accepts_valid():
    """C2: validate_scorers returns valid scorers unchanged.

    Verifies identity preservation: the returned list contains the same
    objects that were passed in.
    """
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.base import Scorer
    from mlflow.genai.scorers.builtin_scorers import Correctness

    s1 = Scorer(name="test_c2_a")
    s2 = Correctness()

    result = validate_scorers([s1, s2])

    assert len(result) == 2, f"C2: expected 2 scorers, got {len(result)}"
    assert result[0] is s1, "C2: identity lost for first scorer"
    assert result[1] is s2, "C2: identity lost for second scorer"
    assert all(isinstance(s, Scorer) for s in result), "C2: not all Scorer instances"

    print("PASS: C2 - validate_scorers accepts valid Scorer/BuiltInScorer instances")


# ──────────────────────────────────────────────────────────────────────────────
# C3: validate_scorers rejects non-list input
# Contracts: C3, R2
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 37-41.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c3_validate_scorers_rejects_non_list():
    """C3: non-list input raises MlflowException with specific message."""
    from mlflow.genai.scorers.validation import validate_scorers

    invalid_inputs = ["string", 42, None, {"key": "val"}, (1, 2, 3)]

    for inp in invalid_inputs:
        try:
            validate_scorers(inp)
            assert False, f"C3 FAIL: no exception for input type {type(inp).__name__}"
        except MlflowException as e:
            assert "must be a list of scorers" in str(e).lower(), (
                f"C3 FAIL: wrong message for {type(inp).__name__}: {e}"
            )
            assert e.error_code == "INVALID_PARAMETER_VALUE", (
                f"C3 FAIL: wrong error code: {e.error_code}"
            )

    print("PASS: C3 - validate_scorers rejects non-list input")


# ──────────────────────────────────────────────────────────────────────────────
# C4: validate_scorers returns empty list for empty input
# Contracts: C4, R2
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 43-44.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c4_validate_scorers_empty_list():
    """C4: empty list input returns empty list."""
    from mlflow.genai.scorers.validation import validate_scorers

    result = validate_scorers([])
    assert result == [], f"C4: expected [], got {result}"
    assert isinstance(result, list), f"C4: result not a list: {type(result)}"

    print("PASS: C4 - validate_scorers returns empty for empty input")


# ──────────────────────────────────────────────────────────────────────────────
# C5: validate_scorers rejects scorer class (not instance)
# Contracts: C5, R2
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 71-77.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c5_validate_scorers_rejects_class():
    """C5: passing a scorer class raises MlflowException with hint."""
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import (
        Correctness,
        RelevanceToQuery,
        Equivalence,
    )

    for cls in [Correctness, RelevanceToQuery, Equivalence]:
        try:
            validate_scorers([cls])
            assert False, f"C5 FAIL: no exception for class {cls.__name__}"
        except MlflowException as e:
            msg = str(e)
            assert cls.__name__ in msg, (
                f"C5 FAIL: class name not in error for {cls.__name__}: {msg}"
            )
            assert "instance" in msg.lower(), (
                f"C5 FAIL: 'instance' hint not in error: {msg}"
            )

    print("PASS: C5 - validate_scorers rejects class with instance hint")


# ──────────────────────────────────────────────────────────────────────────────
# C6: validate_scorers rejects nested get_all_scorers() list
# Contracts: C6, R2
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 63-69.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c6_nested_list_hint():
    """C6: [get_all_scorers()] provides hint about correct usage."""
    from mlflow.genai.scorers.validation import validate_scorers
    from mlflow.genai.scorers.builtin_scorers import get_all_scorers

    all_scorers = get_all_scorers()
    try:
        validate_scorers([all_scorers])
        assert False, "C6 FAIL: should have raised"
    except MlflowException as e:
        msg = str(e)
        assert "get_all_scorers()" in msg, (
            f"C6 FAIL: no get_all_scorers() hint: {msg}"
        )

    # Also test: nested list with additional scorers
    from mlflow.genai.scorers.base import Scorer
    extra = Scorer(name="extra_test")
    try:
        validate_scorers([all_scorers, extra])
        assert False, "C6 FAIL: should have raised for mixed list"
    except MlflowException as e:
        msg = str(e)
        assert "get_all_scorers()" in msg, (
            f"C6 FAIL: no hint for mixed nested list: {msg}"
        )

    print("PASS: C6 - nested get_all_scorers() gives usage hint")


# ──────────────────────────────────────────────────────────────────────────────
# C7: valid_data_for_builtin_scorers legacy column remapping
# Contracts: C7, R3
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 118-125.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c7_legacy_column_remap():
    """C7: request→inputs, response→outputs column remapping."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    data = pd.DataFrame({
        "request": [{"q": "hi"}],
        "response": ["hello"],
    })

    scorer = Correctness()
    with patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as mock_vc:
        valid_data_for_builtin_scorers(data, [scorer])
        cols = mock_vc.call_args[0][0]
        assert "inputs" in cols, f"C7: inputs missing: {cols}"
        assert "outputs" in cols, f"C7: outputs missing: {cols}"
        assert "request" not in cols, f"C7: request not removed: {cols}"
        assert "response" not in cols, f"C7: response not removed: {cols}"

    print("PASS: C7 - legacy columns remapped to inputs/outputs")


# ──────────────────────────────────────────────────────────────────────────────
# C8: valid_data_for_builtin_scorers predict_fn handling
# Contracts: C8, R3
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 127-129.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c8_predict_fn_adds_outputs():
    """C8: predict_fn provided → outputs added to columns."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    data = pd.DataFrame({"inputs": ["q1"]})

    scorer = Correctness()
    with patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as mock_vc:
        valid_data_for_builtin_scorers(data, [scorer], predict_fn=lambda x: x)
        cols = mock_vc.call_args[0][0]
        assert "outputs" in cols, f"C8: outputs not added when predict_fn given: {cols}"
        assert "trace" in cols, f"C8: trace not added when predict_fn given: {cols}"

    print("PASS: C8 - predict_fn adds outputs (and trace) to available columns")


# ──────────────────────────────────────────────────────────────────────────────
# C9: valid_data_for_builtin_scorers trace column handling
# Contracts: C9, R3
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 131-133.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c9_trace_adds_inputs_outputs():
    """C9: trace column → inputs and outputs inferred from trace."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    data = pd.DataFrame({"trace": [MagicMock()]})

    scorer = Correctness()
    with patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as mock_vc:
        valid_data_for_builtin_scorers(data, [scorer])
        cols = mock_vc.call_args[0][0]
        assert "inputs" in cols, f"C9: inputs not added for trace: {cols}"
        assert "outputs" in cols, f"C9: outputs not added for trace: {cols}"

    print("PASS: C9 - trace column adds inputs and outputs")


# ──────────────────────────────────────────────────────────────────────────────
# C10: valid_data_for_builtin_scorers expectations explosion
# Contracts: C10, R3
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 138-149.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c10_expectations_explosion():
    """C10: expectations dict keys become expectations/{key} columns."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    data = pd.DataFrame({
        "inputs": ["q1"],
        "outputs": ["a1"],
        "expectations": [
            {"expected_response": "Paris", "max_length": 10},
            {"expected_response": "London", "min_score": 5},
        ],
    })

    scorer = Correctness()
    with patch.object(scorer, "validate_columns", wraps=scorer.validate_columns) as mock_vc:
        valid_data_for_builtin_scorers(data, [scorer])
        cols = mock_vc.call_args[0][0]
        assert "expectations/expected_response" in cols, (
            f"C10: expected_response not exploded: {cols}"
        )
        assert "expectations/max_length" in cols, (
            f"C10: max_length not exploded: {cols}"
        )
        assert "expectations/min_score" in cols, (
            f"C10: min_score not exploded: {cols}"
        )

    # Also test with single row
    data_single = pd.DataFrame({
        "inputs": ["q1"],
        "outputs": ["a1"],
        "expectations": [{"expected_response": "Paris"}],
    })
    scorer2 = Correctness()
    with patch.object(scorer2, "validate_columns", wraps=scorer2.validate_columns) as mock_vc2:
        valid_data_for_builtin_scorers(data_single, [scorer2])
        cols2 = mock_vc2.call_args[0][0]
        assert "expectations/expected_response" in cols2, (
            f"C10: single row explosion failed: {cols2}"
        )

    print("PASS: C10 - expectations dict keys exploded to column-like names")


# ──────────────────────────────────────────────────────────────────────────────
# C11: valid_data_for_builtin_scorers raises on non-dict expectations
# Contracts: C11, R3
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 143-147.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c11_non_dict_expectations_raises():
    """C11: non-dict values in expectations column raise MlflowException."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    data = pd.DataFrame({
        "inputs": ["q1"],
        "outputs": ["a1"],
        "expectations": ["not_a_dict", "also_not"],
    })

    try:
        valid_data_for_builtin_scorers(data, [Correctness()])
        assert False, "C11 FAIL: should have raised"
    except MlflowException as e:
        assert "expectations" in str(e).lower(), (
            f"C11 FAIL: error message should mention expectations: {e}"
        )
        assert e.error_code == "INVALID_PARAMETER_VALUE", (
            f"C11 FAIL: wrong error code: {e.error_code}"
        )

    print("PASS: C11 - non-dict expectations raises MlflowException")


# ──────────────────────────────────────────────────────────────────────────────
# C12: valid_data_for_builtin_scorers logs missing columns (no raise)
# Contracts: C12, R3, E5
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 151-174.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c12_logs_missing_columns_no_raise():
    """C12: missing columns logged, function returns None, does not raise."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, Correctness

    # Use a scorer that requires columns our data doesn't have
    data = pd.DataFrame({"inputs": ["q1"]})  # no outputs

    log_capture = StringIO()
    handler = logging.StreamHandler(log_capture)
    handler.setLevel(logging.INFO)
    logger = logging.getLogger("mlflow.genai.scorers.validation")
    logger.addHandler(handler)
    old_level = logger.level
    logger.setLevel(logging.INFO)

    try:
        result = valid_data_for_builtin_scorers(data, [Correctness()])
        # Must return None
        assert result is None, f"C12: expected None return, got {result}"

        log_output = log_capture.getvalue()
        assert "missing" in log_output.lower(), (
            f"C12: log must mention 'missing', got: {log_output}"
        )
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)

    print("PASS: C12 - missing columns logged, function returns None without raise")


# ──────────────────────────────────────────────────────────────────────────────
# C13: get_all_scorers OSS cardinality and types
# Contracts: C13, R4
# Repository test guidance: tests/genai/scorers/test_builtin_scorers.py
#   line 570 test_get_all_scorers_oss.
# Source: /testbed/mlflow/genai/scorers/builtin_scorers.py
def check_c13_oss_scorers_details():
    """C13: validate exact scorer types on OSS tracking URI."""
    from mlflow.genai.scorers.builtin_scorers import (
        BuiltInScorer,
        Correctness,
        Equivalence,
        ExpectationsGuidelines,
        RelevanceToQuery,
        RetrievalGroundedness,
        RetrievalSufficiency,
        get_all_scorers,
    )

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("file:///tmp/mlflow-test-behavior")

        scorers = get_all_scorers()

        # Exact count
        assert len(scorers) == 6, f"C13: expected 6 scorers, got {len(scorers)}"

        # All must be BuiltInScorer
        assert all(isinstance(s, BuiltInScorer) for s in scorers), (
            "C13: not all are BuiltInScorer"
        )

        # Verify specific types present
        type_map = {type(s): s for s in scorers}
        expected_types = [
            ExpectationsGuidelines,
            Correctness,
            RelevanceToQuery,
            RetrievalSufficiency,
            RetrievalGroundedness,
            Equivalence,
        ]
        for et in expected_types:
            assert et in type_map, f"C13: missing {et.__name__}"

        # All have valid names
        for s in scorers:
            assert s.name, f"C13: scorer has empty name: {type(s).__name__}"

    finally:
        mlflow.set_tracking_uri(old_uri)

    print("PASS: C13 - OSS get_all_scorers returns 6 correct BuiltInScorer types")


# ──────────────────────────────────────────────────────────────────────────────
# C14: get_all_scorers Databricks behavior
# Contracts: C14, R4
# Repository test guidance: tests/genai/scorers/test_builtin_scorers.py
#   line 570 test_get_all_scorers_oss also verifies 8 for databricks.
# Source: /testbed/mlflow/genai/scorers/builtin_scorers.py
def check_c14_databricks_scorers():
    """C14: Databricks URI produces 8 scorers including Safety and RetrievalRelevance."""
    from mlflow.genai.scorers.builtin_scorers import get_all_scorers

    old_uri = mlflow.get_tracking_uri()
    try:
        mlflow.set_tracking_uri("databricks://test")

        scorers = get_all_scorers()
        assert len(scorers) == 8, f"C14: expected 8, got {len(scorers)}"

        names = {type(s).__name__ for s in scorers}
        assert "Safety" in names, f"C14: Safety missing: {names}"
        assert "RetrievalRelevance" in names, f"C14: RetrievalRelevance missing: {names}"

        # Verify the 6 OSS scorers are still present
        for expected in [
            "ExpectationsGuidelines", "Correctness", "RelevanceToQuery",
            "RetrievalSufficiency", "RetrievalGroundedness", "Equivalence",
        ]:
            assert expected in names, f"C14: OSS scorer {expected} missing from Databricks set"

    finally:
        mlflow.set_tracking_uri(old_uri)

    print("PASS: C14 - Databricks URI returns 8 scorers with Safety + RetrievalRelevance")


# ──────────────────────────────────────────────────────────────────────────────
# C17: validate_aggregations accepts valid strings
# Contracts: C17, R7
# Repository test guidance: tests/genai/scorers/test_aggregation.py exercises
#   aggregation computation; validate_aggregations tested indirectly.
# Source: /testbed/mlflow/genai/scorers/validation.py lines 177-203
def check_c17_valid_string_aggregations():
    """C17: validate_aggregations accepts all valid string names."""
    from mlflow.genai.scorers.validation import validate_aggregations

    result = validate_aggregations(["min", "max", "mean", "median", "variance", "p90"])
    assert result is None, f"C17: expected None, got {result}"

    # Subset should also work
    result2 = validate_aggregations(["min", "max"])
    assert result2 is None, f"C17: subset failed: {result2}"

    # Single value
    result3 = validate_aggregations(["mean"])
    assert result3 is None, f"C17: single failed: {result3}"

    print("PASS: C17 - validate_aggregations accepts valid string aggregations")


# ──────────────────────────────────────────────────────────────────────────────
# C18: validate_aggregations rejects invalid string
# Contracts: C18, R7
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 190-194.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c18_invalid_string_aggregation():
    """C18: invalid aggregation name raises MlflowException."""
    from mlflow.genai.scorers.validation import validate_aggregations

    try:
        validate_aggregations(["invalid_agg_name"])
        assert False, "C18 FAIL: should have raised"
    except MlflowException as e:
        assert "invalid" in str(e).lower(), (
            f"C18 FAIL: message should mention 'invalid': {e}"
        )
        assert e.error_code == "INVALID_PARAMETER_VALUE", (
            f"C18 FAIL: wrong error code: {e.error_code}"
        )

    # Also test mixed valid+invalid
    try:
        validate_aggregations(["mean", "bad_one", "min"])
        assert False, "C18 FAIL: should have raised for mixed list"
    except MlflowException as e:
        assert "bad_one" in str(e), (
            f"C18 FAIL: invalid name not in message: {e}"
        )

    print("PASS: C18 - validate_aggregations rejects invalid string names")


# ──────────────────────────────────────────────────────────────────────────────
# C19: validate_aggregations accepts callable
# Contracts: C19, R7
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 195-199.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c19_callable_aggregations():
    """C19: callable aggregations are accepted."""
    from mlflow.genai.scorers.validation import validate_aggregations

    result = validate_aggregations([lambda x: sum(x) / len(x) if x else 0])
    assert result is None, f"C19: callable should be accepted, got {result}"

    result2 = validate_aggregations([np.mean, np.median])
    assert result2 is None, f"C19: numpy callables should be accepted"

    # Mixed callable + string
    result3 = validate_aggregations(["mean", lambda x: max(x)])
    assert result3 is None, f"C19: mixed callable+string should be accepted"

    print("PASS: C19 - validate_aggregations accepts callable functions")


# ──────────────────────────────────────────────────────────────────────────────
# C20: validate_aggregations rejects non-string non-callable
# Contracts: C20, R7
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 195-199.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c20_rejects_non_string_non_callable():
    """C20: non-string, non-callable values raise MlflowException."""
    from mlflow.genai.scorers.validation import validate_aggregations

    invalid_values = [42, 3.14, True, None, [1, 2, 3], {"a": 1}]

    for val in invalid_values:
        try:
            validate_aggregations([val])
            assert False, f"C20 FAIL: no exception for {type(val).__name__}: {val}"
        except MlflowException as e:
            assert e.error_code == "INVALID_PARAMETER_VALUE", (
                f"C20 FAIL: wrong error code for {type(val).__name__}"
            )

    # Mixed invalid with valid
    try:
        validate_aggregations(["mean", 42])
        assert False, "C20 FAIL: mixed valid+invalid should raise"
    except MlflowException:
        pass

    print("PASS: C20 - validate_aggregations rejects non-string non-callable")


# ──────────────────────────────────────────────────────────────────────────────
# C21: validate_aggregations accepts None
# Contracts: C21, R7
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 183-184.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_c21_aggregations_none():
    """C21: None aggregations returns None without error."""
    from mlflow.genai.scorers.validation import validate_aggregations

    result = validate_aggregations(None)
    assert result is None, f"C21: None should return None, got {result}"

    # Empty list should also be fine (falsy)
    result2 = validate_aggregations([])
    assert result2 is None, f"C21: empty list should return None, got {result2}"

    print("PASS: C21 - validate_aggregations accepts None and empty list")


# ──────────────────────────────────────────────────────────────────────────────
# R8: BuiltInScorer.validate_columns behavior
# Contracts: R8, R9, E6, N7, N8
# Repository test guidance: tests/genai/scorers/test_builtin_scorers.py
#   multiple tests exercise BuiltInScorer subclasses.
# Source: /testbed/mlflow/genai/scorers/builtin_scorers.py lines 325-327
def check_r8_validate_columns_behavior():
    """R8: BuiltInScorer.validate_columns raises MissingColumnsException."""
    from mlflow.genai.scorers.builtin_scorers import (
        BuiltInScorer,
        Correctness,
        MissingColumnsException,
    )

    scorer = Correctness()
    # Correctness requires 'outputs' and 'inputs' (or trace)
    required = scorer.required_columns

    # With all required columns present: no exception
    try:
        scorer.validate_columns(required | {"extra_col"})
    except MissingColumnsException as e:
        assert False, f"R8 FAIL: should not raise when all columns present: {e}"

    # With missing columns: must raise MissingColumnsException
    try:
        scorer.validate_columns(set())  # no columns at all
        assert False, "R8 FAIL: should have raised MissingColumnsException"
    except MissingColumnsException as e:
        assert e.scorer == scorer.name, (
            f"R8 FAIL: scorer name mismatch: {e.scorer} vs {scorer.name}"
        )
        assert len(e.missing_columns) > 0, "R8 FAIL: missing_columns is empty"
        assert isinstance(e.missing_columns, list), (
            f"R8 FAIL: missing_columns should be list, got {type(e.missing_columns)}"
        )
        # Must be a subclass of MlflowException
        assert isinstance(e, MlflowException), (
            "R8 FAIL: MissingColumnsException not MlflowException subclass"
        )

    # Verify missing_columns content
    try:
        scorer.validate_columns({"inputs"})  # missing outputs
        assert False, "R8 FAIL: should have raised"
    except MissingColumnsException as e:
        assert "outputs" in e.missing_columns, (
            f"R8 FAIL: 'outputs' should be in missing: {e.missing_columns}"
        )

    print("PASS: R8 - BuiltInScorer.validate_columns raises MissingColumnsException correctly")


# ──────────────────────────────────────────────────────────────────────────────
# R2 boundary: validate_scorers rejects invalid types
# Contracts: R2
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 46-86.
# Source: /testbed/mlflow/genai/scorers/validation.py
def check_r2_rejects_invalid_types():
    """R2: validate_scorers rejects invalid scorer types with message."""
    from mlflow.genai.scorers.validation import validate_scorers

    class SomeRandomClass:
        pass

    invalid_items = [SomeRandomClass(), object(), 42, "string", True, None]

    for item in invalid_items:
        try:
            validate_scorers([item])
            assert False, f"R2 FAIL: no exception for {type(item).__name__}"
        except MlflowException as e:
            assert e.error_code == "INVALID_PARAMETER_VALUE", (
                f"R2 FAIL: wrong error code for {type(item).__name__}"
            )
            # Message should mention invalid type
            assert "invalid" in str(e).lower() or "must be" in str(e).lower(), (
                f"R2 FAIL: message not descriptive: {e}"
            )

    print("PASS: R2 - validate_scorers rejects invalid types with clear message")


# ──────────────────────────────────────────────────────────────────────────────
# C22: validate_scorers accepts legacy databricks.rag_eval Metric instances
# Contracts: C22, R2 (legacy Metric sub-requirement)
# Repository test guidance: no dedicated test; validated against
#   /testbed/libs/skinny/mlflow/genai/scorers/validation.py lines 47-59, 90-96.
# Source: /testbed/mlflow/genai/scorers/validation.py
# Finding 1 resolution: this check addresses the missing C contract for
#   legacy Metric acceptance in validate_scorers.
def check_c22_validate_scorers_accepts_legacy_metric():
    """C22: validate_scorers accepts legacy Metric instances when databricks.agents installed.

    When databricks.agents is installed, validate_scorers must accept
    databricks.rag_eval.evaluation.metrics.Metric instances alongside
    Scorer instances, and log a deprecation warning listing the metric names.
    """
    import sys as _sys
    from unittest.mock import MagicMock

    # ── Set up the mock databricks.agents environment ──
    # We need to simulate that databricks.agents is installed so that
    # IS_DBX_AGENTS_INSTALLED is True and the Metric import succeeds.

    from mlflow.genai.scorers import validation as val_mod

    # Create a fake Metric class
    class FakeMetric:
        def __init__(self, name="legacy_metric"):
            self.name = name

    # Register the fake module in sys.modules so the import inside
    # validate_scorers works
    fake_metrics_module = MagicMock()
    fake_metrics_module.Metric = FakeMetric
    _sys.modules["databricks.rag_eval.evaluation.metrics"] = fake_metrics_module
    _sys.modules["databricks.rag_eval.evaluation"] = MagicMock()
    _sys.modules["databricks.rag_eval"] = MagicMock()
    _sys.modules["databricks"] = MagicMock()

    # Patch the module-level flag to True
    original_flag = val_mod.IS_DBX_AGENTS_INSTALLED
    val_mod.IS_DBX_AGENTS_INSTALLED = True

    log_capture = StringIO()
    handler = logging.StreamHandler(log_capture)
    handler.setLevel(logging.WARNING)
    logger = logging.getLogger("mlflow.genai.scorers.validation")
    logger.addHandler(handler)
    old_level = logger.level
    logger.setLevel(logging.WARNING)

    try:
        from mlflow.genai.scorers.validation import validate_scorers
        from mlflow.genai.scorers.base import Scorer

        metric = FakeMetric(name="test_legacy_metric")
        valid_scorer = Scorer(name="test_regular")

        result = validate_scorers([metric, valid_scorer])

        # The metric must be included in the returned list
        assert len(result) == 2, f"C22: expected 2 scorers, got {len(result)}"
        # The FakeMetric instance must be present (check by identity or name attribute)
        metric_names = [getattr(s, "name", None) for s in result]
        assert "test_legacy_metric" in metric_names, (
            f"C22: legacy metric not in returned list. names: {metric_names}"
        )
        assert "test_regular" in metric_names, (
            f"C22: regular scorer not in returned list. names: {metric_names}"
        )

        # A deprecation warning must be logged mentioning the metric name
        log_output = log_capture.getvalue()
        assert "deprecated" in log_output.lower(), (
            f"C22: deprecation warning not logged. Log: {log_output}"
        )
        assert "test_legacy_metric" in log_output, (
            f"C22: legacy metric name not in deprecation warning. Log: {log_output}"
        )

    finally:
        # Cleanup
        val_mod.IS_DBX_AGENTS_INSTALLED = original_flag
        logger.removeHandler(handler)
        logger.setLevel(old_level)
        for mod_key in [
            "databricks.rag_eval.evaluation.metrics",
            "databricks.rag_eval.evaluation",
            "databricks.rag_eval",
            "databricks",
        ]:
            _sys.modules.pop(mod_key, None)

    print("PASS: C22 - validate_scorers accepts legacy Metric with deprecation warning")


# ──────────────────────────────────────────────────────────────────────────────
# Static issue closure: evaluation/base.py import binding
# Contracts: R5 (static: valid_data_for_builtin_scorers and validate_scorers
#   used but not imported)
# Source: /testbed/mlflow/genai/evaluation/base.py
def check_r5_static_import_closure():
    """R5 closure: verify evaluate module can import and use validation symbols.

    The static analysis reported that valid_data_for_builtin_scorers and
    validate_scorers are used but not imported. This check verifies that
    the evaluate module can be loaded and that the symbols are reachable
    at the call sites.
    """
    # Force a fresh import to catch any import-time NameError
    mod = importlib.import_module("mlflow.genai.evaluation.base")

    # Verify the symbols exist in the validation module
    from mlflow.genai.scorers.validation import (
        valid_data_for_builtin_scorers,
        validate_scorers,
    )

    assert callable(valid_data_for_builtin_scorers), "R5: valid_data_for_builtin_scorers not callable"
    assert callable(validate_scorers), "R5: validate_scorers not callable"

    # Verify evaluate function exists and the module loaded cleanly
    assert hasattr(mod, "evaluate"), "R5: evaluate function not in module"
    assert callable(mod.evaluate), "R5: evaluate is not callable"

    print("PASS: R5 - static import closure verified for evaluation/base.py")


# ──────────────────────────────────────────────────────────────────────────────
# Static issue closure: optimize/util.py import binding — CALLER-BINDING
# Contracts: R6 (static: valid_data_for_builtin_scorers used but not imported)
# Source: /testbed/mlflow/genai/optimize/util.py
# Finding 2 resolution: this check actually calls validate_train_data()
#   to exercise the valid_data_for_builtin_scorers call at line 91.
def check_r6_static_import_closure():
    """R6 closure: verify optimize.util imports valid_data_for_builtin_scorers via caller-binding.

    The static analysis reported that valid_data_for_builtin_scorers is used
    but not imported in optimize/util.py. A module-level import check is
    insufficient because the name is referenced inside validate_train_data's
    function body — a missing import would not cause ImportError at module
    load time, but would cause NameError when validate_train_data() is called.

    This check actually calls validate_train_data() with a valid DataFrame
    and BuiltInScorer instances, forcing execution of line 91:
        valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)
    """
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    assert callable(valid_data_for_builtin_scorers), "R6: valid_data_for_builtin_scorers not callable"

    mod = importlib.import_module("mlflow.genai.optimize.util")
    assert hasattr(mod, "validate_train_data"), "R6: validate_train_data not in module"
    assert callable(mod.validate_train_data), "R6: validate_train_data not callable"

    # ── CALLER-BINDING: actually invoke validate_train_data ──
    # This forces the call to valid_data_for_builtin_scorers at line 91.
    # A missing import causes NameError here, proving the import is absent.
    data = pd.DataFrame({
        "inputs": [{"question": "What is MLflow?"}],
        "outputs": ["MLflow is an open source ML platform."],
    })

    try:
        mod.validate_train_data(data, [Correctness()])
        # Success: valid_data_for_builtin_scorers was resolved and called
    except NameError as ne:
        raise AssertionError(
            f"R6 FAIL: valid_data_for_builtin_scorers not imported in "
            f"optimize/util.py (NameError at call site in validate_train_data): {ne}"
        ) from ne
    except Exception:
        # Downstream errors (e.g., model/endpoint not configured) are acceptable;
        # the critical thing is no NameError, proving the import exists.
        pass

    print("PASS: R6 - static import closure verified via validate_train_data caller-binding")


# ──────────────────────────────────────────────────────────────────────────────
# Scorer decorator: argless usage (decorator factory pattern)
# Contracts: R1
# Repository test guidance: tests/genai/scorers/test_scorer.py uses @scorer
#   decorator extensively in test definitions.
# Source: /testbed/mlflow/genai/scorers/base.py line 994
def check_scorer_decorator_factory():
    """R1: @scorer() with arguments produces correct CustomScorer."""
    from mlflow.genai.scorers.base import Scorer, ScorerKind

    @mlflow.genai.scorers.scorer(name="explicit_name", description="My desc", aggregations=["min"])
    def _decorated_with_args(outputs) -> int:
        return len(str(outputs))

    assert isinstance(_decorated_with_args, Scorer), "R1: not Scorer instance"
    assert _decorated_with_args.name == "explicit_name", (
        f"R1: name={_decorated_with_args.name}"
    )
    assert _decorated_with_args.description == "My desc", (
        f"R1: desc={_decorated_with_args.description}"
    )
    assert _decorated_with_args.aggregations == ["min"], (
        f"R1: aggregations={_decorated_with_args.aggregations}"
    )
    assert _decorated_with_args.kind == ScorerKind.DECORATOR, "R1: wrong kind"
    assert _decorated_with_args(outputs="hello") == 5, "R1: wrong return"

    print("PASS: R1 - scorer decorator factory pattern works correctly")


# ──────────────────────────────────────────────────────────────────────────────
# R3 boundary: valid_data_for_builtin_scorers with NaN expectations
# Contracts: R3
# Source: /testbed/libs/skinny/mlflow/genai/scorers/validation.py line 139
def check_r3_expectations_nan_handling():
    """R3: NaN values in expectations column should be skipped."""
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
    from mlflow.genai.scorers.builtin_scorers import Correctness

    data = pd.DataFrame({
        "inputs": ["q1"],
        "outputs": ["a1"],
        "expectations": [float("nan")],
    })

    scorer = Correctness()
    # Should not raise (NaN skipped)
    result = valid_data_for_builtin_scorers(data, [scorer])
    assert result is None, f"R3: expected None, got {result}"

    print("PASS: R3 - NaN expectations values are skipped gracefully")


# ──────────────────────────────────────────────────────────────────────────────
# Main: execute all checks
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    all_checks = [
        check_c1_custom_scorer_behavior,
        check_c2_validate_scorers_accepts_valid,
        check_c3_validate_scorers_rejects_non_list,
        check_c4_validate_scorers_empty_list,
        check_c5_validate_scorers_rejects_class,
        check_c6_nested_list_hint,
        check_c7_legacy_column_remap,
        check_c8_predict_fn_adds_outputs,
        check_c9_trace_adds_inputs_outputs,
        check_c10_expectations_explosion,
        check_c11_non_dict_expectations_raises,
        check_c12_logs_missing_columns_no_raise,
        check_c13_oss_scorers_details,
        check_c14_databricks_scorers,
        check_c17_valid_string_aggregations,
        check_c18_invalid_string_aggregation,
        check_c19_callable_aggregations,
        check_c20_rejects_non_string_non_callable,
        check_c21_aggregations_none,
        check_r8_validate_columns_behavior,
        check_r2_rejects_invalid_types,
        check_c22_validate_scorers_accepts_legacy_metric,
        check_r5_static_import_closure,
        check_r6_static_import_closure,
        check_scorer_decorator_factory,
        check_r3_expectations_nan_handling,
    ]

    failures = 0
    for check_fn in all_checks:
        try:
            check_fn()
        except Exception as e:
            failures += 1
            import traceback
            print(f"FAIL: {check_fn.__name__}: {e}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)

    if failures:
        print(f"\n{failures} check(s) FAILED", file=sys.stderr)
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} behavior checks PASSED")
        sys.exit(0)
