# Semantic IR

## L1. Requirement Obligations

### R1: `scorer` decorator producing a `CustomScorer` subclass
- **Type**: Interface / Behavior
- **Statement**: The `scorer` function at `/testbed/mlflow/genai/scorers/base.py` must, when called with a function argument, define a local `class CustomScorer(Scorer)` that wraps the function, stores `_original_func` via `PrivateAttr`, delegates `__call__` to the wrapped function, exposes `kind` as `ScorerKind.DECORATOR`, patches `__call__.__signature__` to prepend `self`, and returns a `CustomScorer` instance populated with `name`, `description`, and `aggregations`.
- **Task Evidence**: Interface Description 1 specifies the `scorer` decorator; the static issue reports `CustomScorer` used but not defined.
- **Acceptance**: `@scorer` decorated functions are accepted by `mlflow.genai.evaluate()` and are serializable/deserializable.
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 994-1030 reference `CustomScorer` but omit its class body. The complete implementation exists at `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 999-1018.
- **Uncertainty**: None — the exact class body is available in the sibling libs directory.

### R2: `validate_scorers` function
- **Type**: Interface / Behavior
- **Statement**: `validate_scorers(scorers: list[Any]) -> list[Scorer]` at `/testbed/mlflow/genai/scorers/validation.py` must validate that `scorers` is a list, return an empty list for empty input, accept `Scorer` instances directly, accept legacy `databricks.rag_eval.evaluation.metrics.Metric` instances when databricks.agents is installed (with deprecation warning), and raise `MlflowException` with helpful hints for common mistakes: passing `[get_all_scorers()]` (nested list), passing scorer classes instead of instances, or passing invalid types.
- **Task Evidence**: Interface Description 2 specifies `validate_scorers`; the static issue reports it used but not defined/imported in `evaluation/base.py`.
- **Acceptance**: Invalid scorers raise `MlflowException.invalid_parameter_value` with contextual hints; valid scorers pass through.
- **Repository Evidence**: Called at `/testbed/mlflow/genai/evaluation/base.py` line 243. Full implementation at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 26-98.
- **Uncertainty**: None.

### R3: `valid_data_for_builtin_scorers` function
- **Type**: Interface / Behavior
- **Statement**: `valid_data_for_builtin_scorers(data: pd.DataFrame, builtin_scorers: list[BuiltInScorer], predict_fn: Callable | None = None) -> None` at `/testbed/mlflow/genai/scorers/validation.py` must: remap legacy `request`→`inputs` and `response`→`outputs` columns; treat `outputs` as available when `predict_fn` is provided; treat `inputs`+`outputs` as available when `trace` column exists; explode `expectations` dictionary keys into `expectations/{key}` columns (raising `MlflowException` for non-dict values); call `scorer.validate_columns()` on each builtin scorer; and log a message (not raise) listing missing columns per scorer.
- **Task Evidence**: Interface Description 2 specifies `valid_data_for_builtin_scorers`; the static issue reports it used but not defined/imported in `evaluation/base.py` and `optimize/util.py`.
- **Acceptance**: Missing columns are logged; `expectations` non-dict values raise `MlflowException.invalid_parameter_value`.
- **Repository Evidence**: Called at `/testbed/mlflow/genai/evaluation/base.py` line 248 and `/testbed/mlflow/genai/optimize/util.py` line 91. Full implementation at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 101-174.
- **Uncertainty**: None.

### R4: `get_all_scorers` function
- **Type**: Interface / Behavior
- **Statement**: `get_all_scorers() -> list[BuiltInScorer]` at `/testbed/mlflow/genai/scorers/builtin_scorers.py` must return a list of instantiated builtin scorers: `ExpectationsGuidelines()`, `Correctness()`, `RelevanceToQuery()`, `RetrievalSufficiency()`, `RetrievalGroundedness()`, `Equivalence()`. When `is_databricks_uri(mlflow.get_tracking_uri())` is True, additionally include `Safety()` and `RetrievalRelevance()`.
- **Task Evidence**: Interface Description 3 specifies `get_all_scorers`; the function is missing from the file.
- **Acceptance**: Returns 6 scorers on OSS, 8 on Databricks; all are `BuiltInScorer` instances.
- **Repository Evidence**: Missing from `/testbed/mlflow/genai/scorers/builtin_scorers.py`; complete implementation at `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py` lines 1567-1595. Referenced in `/testbed/mlflow/genai/scorers/__init__.py` lazy-import set line 36 and `__all__` line 93. Tested at `/testbed/tests/genai/scorers/test_builtin_scorers.py` line 570 (`test_get_all_scorers_oss`).
- **Uncertainty**: None.

### R5: Import `valid_data_for_builtin_scorers` and `validate_scorers` in `evaluation/base.py`
- **Type**: Compatibility / Dependency
- **Statement**: `/testbed/mlflow/genai/evaluation/base.py` must import `valid_data_for_builtin_scorers` and `validate_scorers` from `mlflow.genai.scorers.validation` to resolve the calls at lines 243 and 248.
- **Task Evidence**: Static issue: `valid_data_for_builtin_scorers` and `validate_scorers` are used but not defined or imported.
- **Acceptance**: No `NameError` at runtime when `evaluate()` is called.
- **Repository Evidence**: The import line exists at `/testbed/libs/skinny/mlflow/genai/evaluation/base.py` line 21: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers`.
- **Uncertainty**: None.

### R6: Import `valid_data_for_builtin_scorers` in `optimize/util.py`
- **Type**: Compatibility / Dependency
- **Statement**: `/testbed/mlflow/genai/optimize/util.py` must import `valid_data_for_builtin_scorers` from `mlflow.genai.scorers.validation` to resolve the call at line 91 in `validate_train_data`.
- **Task Evidence**: Static issue: `valid_data_for_builtin_scorers` is used but not defined or imported.
- **Acceptance**: No `NameError` at runtime when `validate_train_data` is called.
- **Repository Evidence**: The import line exists at `/testbed/libs/skinny/mlflow/genai/optimize/util.py` line 11: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers`.
- **Uncertainty**: None.

### R7: `validate_aggregations` function
- **Type**: Interface / Behavior
- **Statement**: `validate_aggregations(aggregations: list[str | AggregationFunc] | None) -> None` at `/testbed/mlflow/genai/scorers/validation.py` must accept `None` silently; for each string aggregation, verify it is in the valid set from `_AGGREGATE_FUNCTIONS`; for non-string non-callable items, raise `MlflowException.invalid_parameter_value`.
- **Task Evidence**: The function signature and docstring exist in `/testbed/mlflow/genai/scorers/validation.py` but the body is empty (just a stub with trailing `return`). The implementation is needed for interface completeness.
- **Acceptance**: Invalid aggregation names raise; valid ones pass.
- **Repository Evidence**: Full body at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 177-203. Referenced in tests via scorer instantiation.
- **Uncertainty**: None.

### R8: `BuiltInScorer.validate_columns` method
- **Type**: Behavior / Failure
- **Statement**: On `BuiltInScorer` (already defined at line 259), `validate_columns(columns: set[str])` must compute `missing_columns = self.required_columns - columns` and raise `MissingColumnsException(self.name, missing_columns)` if any are missing.
- **Task Evidence**: Called by `valid_data_for_builtin_scorers`; `MissingColumnsException` is already defined.
- **Acceptance**: Raises `MissingColumnsException` with scorer name and set of missing columns.
- **Repository Evidence**: Defined at `/testbed/mlflow/genai/scorers/builtin_scorers.py` lines 325-327.
- **Uncertainty**: Already implemented in the target file.

### R9: `MissingColumnsException` class
- **Type**: Failure / Data
- **Statement**: `MissingColumnsException` must be a subclass of `MlflowException` with attributes `scorer: str` and `missing_columns: list[str]`, constructed with a message listing required columns.
- **Task Evidence**: Used by `BuiltInScorer.validate_columns` and caught in `valid_data_for_builtin_scorers`.
- **Acceptance**: Catchable, carries scorer name and column list.
- **Repository Evidence**: Defined at `/testbed/mlflow/genai/scorers/builtin_scorers.py` lines 1600-1605.
- **Uncertainty**: Already implemented in the target file.

## L2. Functional Design Graph

### N1: `mlflow.genai.evaluate` (public entry)
- **Kind**: Function (entry point)
- **Repository Evidence**: `/testbed/mlflow/genai/evaluation/base.py` line 50, decorated `@experimental(version="3.0.0")`.

### N2: `validate_scorers`
- **Kind**: Function (validation helper)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/validation.py` line 26 (libs/skinny); called at `/testbed/mlflow/genai/evaluation/base.py` line 243.

### N3: `valid_data_for_builtin_scorers`
- **Kind**: Function (validation helper)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/validation.py` line 101 (libs/skinny); called at `/testbed/mlflow/genai/evaluation/base.py` line 248 and `/testbed/mlflow/genai/optimize/util.py` line 91.

### N4: `validate_aggregations`
- **Kind**: Function (validation helper)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/validation.py` line 177 (libs/skinny).

### N5: `get_all_scorers`
- **Kind**: Function (factory)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` line 1567 (libs/skinny); lazy-imported via `/testbed/mlflow/genai/scorers/__init__.py` line 36.

### N6: `scorer` decorator → `CustomScorer`
- **Kind**: Function returning class instance
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/base.py` lines 856-1030; `CustomScorer` class at libs/skinny line 999.

### N7: `BuiltInScorer.validate_columns`
- **Kind**: Method (validation contract)
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` lines 325-327.

### N8: `MissingColumnsException`
- **Kind**: Exception class
- **Repository Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` lines 1600-1605.

### N9: `validate_train_data` (caller in optimize)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/genai/optimize/util.py` line 76.

### N10: `_convert_to_eval_set` (upstream converter)
- **Kind**: Function
- **Repository Evidence**: `/testbed/mlflow/genai/evaluation/utils.py` line 54; imported in `evaluation/base.py`.

### E1: `evaluate` -> `validate_scorers` (CALL)
- **Kind**: CALL
- **Condition**: Unconditional at entry to `evaluate()`.
- **Transfer**: `scorers: list[Scorer]` → `validate_scorers(scorers)` → returns `list[Scorer]`.
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py` line 243.
- **Obligations**: R2, R5.

### E2: `evaluate` -> `valid_data_for_builtin_scorers` (CALL)
- **Kind**: CALL
- **Condition**: After `_convert_to_eval_set` produces `df`, filters `builtin_scorers` from validated scorers.
- **Transfer**: `(df, builtin_scorers, predict_fn)` → `valid_data_for_builtin_scorers(...)` → `None`.
- **Evidence**: `/testbed/mlflow/genai/evaluation/base.py` lines 245-248.
- **Obligations**: R3, R5.

### E3: `validate_train_data` -> `valid_data_for_builtin_scorers` (CALL)
- **Kind**: CALL
- **Condition**: After validating each record has `inputs`, filters `builtin_scorers`.
- **Transfer**: `(train_data, builtin_scorers, predict_fn)` → `valid_data_for_builtin_scorers(...)` → `None`.
- **Evidence**: `/testbed/mlflow/genai/optimize/util.py` lines 89-91.
- **Obligations**: R3, R6.

### E4: `scorer` decorator -> `CustomScorer` (CONTROL + DATA)
- **Kind**: CONTROL (definition) + DATA (instantiation)
- **Condition**: When `func is not None` (decorator used without arguments).
- **Transfer**: Wraps `func` in `CustomScorer` class, stores as `_original_func`, returns instance.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 994-1031.
- **Obligations**: R1.

### E5: `valid_data_for_builtin_scorers` -> `BuiltInScorer.validate_columns` (CALL)
- **Kind**: CALL
- **Condition**: For each scorer in `builtin_scorers`.
- **Transfer**: `scorer.validate_columns(input_columns)`; catches `MissingColumnsException`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 153-158.
- **Obligations**: R8, R9.

### E6: `BuiltInScorer.validate_columns` -> `MissingColumnsException` (CONTROL + DATA)
- **Kind**: CONTROL (raise)
- **Condition**: When `self.required_columns - columns` is non-empty.
- **Transfer**: Raises `MissingColumnsException(self.name, missing_columns)`.
- **Evidence**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` lines 325-327.
- **Obligations**: R9.

### E7: `get_all_scorers` -> builtin scorer constructors (CALL)
- **Kind**: CALL
- **Condition**: Unconditional; Databricks-only scorers gated by `is_databricks_uri`.
- **Transfer**: Returns list of instantiated `BuiltInScorer` subclasses.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py` lines 1567-1595.
- **Obligations**: R4.

## L3. Verifiable Contracts

### C1: `CustomScorer` class is defined and instantiable
- **Type**: Interface
- **Subject**: `scorer` decorator function body in `/testbed/mlflow/genai/scorers/base.py`
- **Relation**: Definition → Runtime creation
- **Expected**: When `scorer(func)` is called with a function `func`, a local `class CustomScorer(Scorer)` is defined with `_original_func: PrivateAttr`, `__init__` that calls `super().__init__` and sets `_original_func`, `__call__` that delegates to `func`, and `kind` property returning `ScorerKind.DECORATOR`. The `__call__.__signature__` is patched with `self` prepended.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/base.py` lines 999-1031; static issue: `CustomScorer` used but not defined.
- **Observe**: IMPORT_BOUNDARY — `from mlflow.genai.scorers import scorer` then `@scorer def f(): pass` must succeed and `f` must be an instance of `Scorer` with `kind == ScorerKind.DECORATOR`.
- **Target**: `/testbed/mlflow/genai/scorers/base.py` lines 994-1030.
- **Obligations**: R1.
- **Graph**: N6, E4.

### C2: `validate_scorers` accepts valid Scorer instances
- **Type**: Interface
- **Subject**: `validate_scorers` function in `/testbed/mlflow/genai/scorers/validation.py`
- **Relation**: Input validation → Return value
- **Expected**: Given `[Correctness(), Scorer(name="custom")]`, returns the same list unchanged.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 26-98; called from `evaluate()`.
- **Observe**: RETURN_VALUE — call `validate_scorers([Correctness(), Scorer(name="x")])` and verify returned list has 2 elements, both `isinstance Scorer`.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_scorers`.
- **Obligations**: R2.
- **Graph**: N2, E1.

### C3: `validate_scorers` rejects non-list input
- **Type**: Failure
- **Subject**: `validate_scorers` function
- **Relation**: Input type check → Exception
- **Expected**: `validate_scorers("not_a_list")` raises `MlflowException` with message containing "must be a list of scorers".
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 37-41.
- **Observe**: EXCEPTION — `MlflowException` raised with `INVALID_PARAMETER_VALUE` error code.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_scorers`.
- **Obligations**: R2.
- **Graph**: N2, E1.

### C4: `validate_scorers` returns empty list for empty input
- **Type**: Behavior
- **Subject**: `validate_scorers` function
- **Relation**: Edge case → Return value
- **Expected**: `validate_scorers([])` returns `[]`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 43-44.
- **Observe**: RETURN_VALUE — call `validate_scorers([])` and verify `== []`.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_scorers`.
- **Obligations**: R2.
- **Graph**: N2, E1.

### C5: `validate_scorers` rejects scorer class (not instance)
- **Type**: Failure
- **Subject**: `validate_scorers` function
- **Relation**: Type check → Exception with hint
- **Expected**: `validate_scorers([Correctness])` raises `MlflowException` with hint "passed a scorer class instead of an instance".
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 71-77.
- **Observe**: EXCEPTION — message contains "Correctness()" hint.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_scorers`.
- **Obligations**: R2.
- **Graph**: N2, E1.

### C6: `validate_scorers` rejects nested `get_all_scorers()` list
- **Type**: Failure
- **Subject**: `validate_scorers` function
- **Relation**: Type check → Exception with hint
- **Expected**: `validate_scorers([get_all_scorers()])` raises `MlflowException` with hint "Use `scorers=get_all_scorers()`".
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 63-69.
- **Observe**: EXCEPTION — message contains "get_all_scorers()" hint.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_scorers`.
- **Obligations**: R2.
- **Graph**: N2, E1.

### C7: `valid_data_for_builtin_scorers` remaps legacy columns
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` function
- **Relation**: Input transform → Column set
- **Expected**: Data with columns `["request", "response"]` gets remapped so `validate_columns` sees `{"inputs", "outputs"}`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 118-125.
- **Observe**: RUNTIME_ARGUMENT_TRACE — mock `scorer.validate_columns` and verify it receives a set containing `"inputs"` and `"outputs"`.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `valid_data_for_builtin_scorers`.
- **Obligations**: R3.
- **Graph**: N3, E2, E3.

### C8: `valid_data_for_builtin_scorers` treats outputs as present when predict_fn given
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` function
- **Relation**: predict_fn flag → Column availability
- **Expected**: Data without `"outputs"` column but with `predict_fn` provided → `"outputs"` added to column set.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 127-129.
- **Observe**: RUNTIME_ARGUMENT_TRACE — mock `scorer.validate_columns` and verify `"outputs"` is in the column set.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `valid_data_for_builtin_scorers`.
- **Obligations**: R3.
- **Graph**: N3, E2, E3.

### C9: `valid_data_for_builtin_scorers` adds inputs+outputs when trace column present
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` function
- **Relation**: trace column → Column availability
- **Expected**: Data with `"trace"` column → both `"inputs"` and `"outputs"` added to column set.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 131-133.
- **Observe**: RUNTIME_ARGUMENT_TRACE — mock `scorer.validate_columns` and verify both `"inputs"` and `"outputs"` are present.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `valid_data_for_builtin_scorers`.
- **Obligations**: R3.
- **Graph**: N3, E2.

### C10: `valid_data_for_builtin_scorers` explodes expectations dict keys
- **Type**: Dataflow
- **Subject**: `valid_data_for_builtin_scorers` function
- **Relation**: expectations column → Flattened column names
- **Expected**: Data with `expectations` = `[{"expected_response": "x", "max_length": 10}]` adds `"expectations/expected_response"` and `"expectations/max_length"` to column set.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 138-149.
- **Observe**: RUNTIME_ARGUMENT_TRACE — mock `scorer.validate_columns` and verify `"expectations/expected_response"` is in the column set.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `valid_data_for_builtin_scorers`.
- **Obligations**: R3.
- **Graph**: N3, E2.

### C11: `valid_data_for_builtin_scorers` raises on non-dict expectations
- **Type**: Failure
- **Subject**: `valid_data_for_builtin_scorers` function
- **Relation**: Invalid expectations → Exception
- **Expected**: Data with `expectations` = `["not_a_dict"]` raises `MlflowException.invalid_parameter_value` with message about expectations being a dictionary.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 143-147.
- **Observe**: EXCEPTION — `MlflowException` raised.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `valid_data_for_builtin_scorers`.
- **Obligations**: R3.
- **Graph**: N3, E2.

### C12: `valid_data_for_builtin_scorers` logs missing columns (does not raise)
- **Type**: Behavior
- **Subject**: `valid_data_for_builtin_scorers` function
- **Relation**: Missing columns → Log message
- **Expected**: When `validate_columns` raises `MissingColumnsException`, the function logs an info message listing missing columns per scorer and returns `None` (no exception).
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 151-174.
- **Observe**: SIDE_EFFECT — verify `logging.Logger.info` is called with message starting "The input data is missing following columns".
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `valid_data_for_builtin_scorers`.
- **Obligations**: R3.
- **Graph**: N3, E5.

### C13: `get_all_scorers` returns correct scorers on OSS
- **Type**: Interface
- **Subject**: `get_all_scorers` function in `/testbed/mlflow/genai/scorers/builtin_scorers.py`
- **Relation**: Call → Return value
- **Expected**: On non-Databricks tracking URI, returns list of 6 `BuiltInScorer` instances: `ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, `Equivalence`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py` lines 1567-1595; test at `/testbed/tests/genai/scorers/test_builtin_scorers.py` line 570.
- **Observe**: RETURN_VALUE — call `get_all_scorers()` with file tracking URI, verify `len(result) == 6` and each element `isinstance(BuiltInScorer)`.
- **Target**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` `get_all_scorers`.
- **Obligations**: R4.
- **Graph**: N5, E7.

### C14: `get_all_scorers` returns Databricks-only scorers when applicable
- **Type**: Behavior
- **Subject**: `get_all_scorers` function
- **Relation**: tracking URI → Return composition
- **Expected**: On Databricks tracking URI, additionally includes `Safety` and `RetrievalRelevance` (8 total).
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py` lines 1593-1594.
- **Observe**: RETURN_VALUE — set tracking URI to Databricks URI, call `get_all_scorers()`, verify `len(result) == 8`.
- **Target**: `/testbed/mlflow/genai/scorers/builtin_scorers.py` `get_all_scorers`.
- **Obligations**: R4.
- **Graph**: N5, E7.

### C15: `evaluate` imports and calls `validate_scorers`
- **Type**: Compatibility
- **Subject**: Import statement in `/testbed/mlflow/genai/evaluation/base.py`
- **Relation**: Module load → Symbol availability
- **Expected**: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers` is present, making both names available for calls at lines 243 and 248.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/evaluation/base.py` line 21; static issue reports missing import.
- **Observe**: IMPORT_BOUNDARY — `from mlflow.genai.evaluation.base import evaluate` succeeds without `ImportError`, and `evaluate(...)` does not raise `NameError`.
- **Target**: `/testbed/mlflow/genai/evaluation/base.py` imports section.
- **Obligations**: R5.
- **Graph**: N1, E1, E2.

### C16: `optimize/util.py` imports `valid_data_for_builtin_scorers`
- **Type**: Compatibility
- **Subject**: Import statement in `/testbed/mlflow/genai/optimize/util.py`
- **Relation**: Module load → Symbol availability
- **Expected**: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers` is present.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/optimize/util.py` line 11; static issue reports missing import.
- **Observe**: IMPORT_BOUNDARY — `from mlflow.genai.optimize.util import validate_train_data` succeeds without `ImportError`.
- **Target**: `/testbed/mlflow/genai/optimize/util.py` imports section.
- **Obligations**: R6.
- **Graph**: N9, E3.

### C17: `validate_aggregations` accepts valid string aggregations
- **Type**: Interface
- **Subject**: `validate_aggregations` function in `/testbed/mlflow/genai/scorers/validation.py`
- **Relation**: Input → No exception
- **Expected**: `validate_aggregations(["min", "max", "mean", "median", "variance", "p90"])` returns `None`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 177-203.
- **Observe**: RETURN_VALUE — call returns `None`.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_aggregations`.
- **Obligations**: R7.
- **Graph**: N4.

### C18: `validate_aggregations` rejects invalid string aggregation
- **Type**: Failure
- **Subject**: `validate_aggregations` function
- **Relation**: Invalid aggregation name → Exception
- **Expected**: `validate_aggregations(["invalid"])` raises `MlflowException.invalid_parameter_value` with message containing "Invalid aggregation".
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 190-194.
- **Observe**: EXCEPTION — `MlflowException` raised.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_aggregations`.
- **Obligations**: R7.
- **Graph**: N4.

### C19: `validate_aggregations` accepts callable aggregations
- **Type**: Interface
- **Subject**: `validate_aggregations` function
- **Relation**: Callable aggregation → No exception
- **Expected**: `validate_aggregations([lambda x: sum(x)/len(x)])` returns `None`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 195-199.
- **Observe**: RETURN_VALUE — call returns `None`.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_aggregations`.
- **Obligations**: R7.
- **Graph**: N4.

### C20: `validate_aggregations` rejects non-string, non-callable
- **Type**: Failure
- **Subject**: `validate_aggregations` function
- **Relation**: Invalid type → Exception
- **Expected**: `validate_aggregations([42])` raises `MlflowException.invalid_parameter_value`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 195-199.
- **Observe**: EXCEPTION — `MlflowException` raised.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_aggregations`.
- **Obligations**: R7.
- **Graph**: N4.

### C21: `validate_aggregations` accepts None
- **Type**: Behavior
- **Subject**: `validate_aggregations` function
- **Relation**: None input → No exception
- **Expected**: `validate_aggregations(None)` returns `None`.
- **Evidence**: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 183-184.
- **Observe**: RETURN_VALUE — call returns `None`.
- **Target**: `/testbed/mlflow/genai/scorers/validation.py` `validate_aggregations`.
- **Obligations**: R7.
- **Graph**: N4.
