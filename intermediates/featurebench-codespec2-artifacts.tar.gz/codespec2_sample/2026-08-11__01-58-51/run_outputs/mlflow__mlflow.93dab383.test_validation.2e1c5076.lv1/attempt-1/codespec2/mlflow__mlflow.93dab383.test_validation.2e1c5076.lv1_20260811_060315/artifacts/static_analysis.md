# Static Analysis

## Scope
- Repository: `/testbed`
- Declared interfaces: 8
- `mlflow/genai/scorers/base.py`: `scorer` (function)
- `mlflow/genai/scorers/base.py`: `not_empty` (function)
- `mlflow/genai/scorers/base.py`: `exact_match` (function)
- `mlflow/genai/scorers/base.py`: `num_tool_calls` (function)
- `mlflow/genai/scorers/base.py`: `harmfulness` (function)
- `mlflow/genai/scorers/validation.py`: `valid_data_for_builtin_scorers` (function)
- `mlflow/genai/scorers/validation.py`: `validate_scorers` (function)
- `mlflow/genai/scorers/builtin_scorers.py`: `get_all_scorers` (function)

## Findings
## static issue

- **`mlflow/genai/evaluation/base.py`** (2):
  - ? 'valid_data_for_builtin_scorers' is used but not defined or imported in this file
  - ? 'validate_scorers' is used but not defined or imported in this file
- **`mlflow/genai/optimize/util.py`** (1):
  - ? 'valid_data_for_builtin_scorers' is used but not defined or imported in this file
- **`mlflow/genai/scorers/base.py`** (1):
  - ? 'CustomScorer' is used but not defined or imported in this file

## Use
- Requirement Compile: use findings to identify dependency, caller-binding, and compatibility risks.
- Test Spec: compile relevant findings into runtime checks; static evidence alone is not a behavior proof.
