# Spec Review Report

## Evidence Reviewed

1. **Task document** (`/testbed` primary oracle): Interface Descriptions 1-3 defining `scorer`, `validate_scorers`, `valid_data_for_builtin_scorers`, and `get_all_scorers`.

2. **Semantic IR** (`/agent-logs/…/semantic_ir.md`): L1 requirements R1–R9, L2 functional design graph nodes N1–N9, L3 contracts C1–C21 with R/E/C traceability.

3. **Architecture spec** (`/agent-logs/…/arch_spec.py`): 11 executable `check_*` functions covering C1, C2–C6, C7–C10, C12, C13, C14, C15, C16, plus static-issue closure and evaluate caller-binding.

4. **Behavior spec** (`/agent-logs/…/behavior_spec.py`): 25 executable `check_*` functions covering C1–C21 plus R1–R8 boundary and static-import-closure checks.

5. **Static issues** (`/agent-logs/…/static_issues.md`): 4 issues — `valid_data_for_builtin_scorers` and `validate_scorers` used but not imported in `evaluation/base.py`, same for `optimize/util.py`, and `CustomScorer` used but not defined in `scorers/base.py`.

6. **Static analysis** (`/agent-logs/…/static_analysis.md`): Confirms the same 4 findings.

7. **Repository source** (`/testbed/mlflow/genai/`):
   - `/testbed/mlflow/genai/scorers/base.py` lines 994–1030: `scorer` function present but the `CustomScorer` class body (lines ~999–1026) is blank.
   - `/testbed/mlflow/genai/scorers/validation.py` lines 1–202: imports and `validate_aggregations` exist; `validate_scorers` and `valid_data_for_builtin_scorers` bodies are blank.
   - `/testbed/mlflow/genai/scorers/builtin_scorers.py` lines 1567–1606: blank lines where `get_all_scorers` should be; `MissingColumnsException` present.
   - `/testbed/mlflow/genai/evaluation/base.py` line 21 (cf. libs/skinny): missing import `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers`.
   - `/testbed/mlflow/genai/optimize/util.py` line 11 (cf. libs/skinny): missing import `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers`.

8. **Reference implementations** (`/testbed/libs/skinny/mlflow/genai/`):
   - `scorers/base.py` lines 999–1018: full `CustomScorer` class body.
   - `scorers/validation.py` lines 26–203: complete `validate_scorers`, `valid_data_for_builtin_scorers`, `validate_aggregations`.
   - `scorers/builtin_scorers.py` lines 1567–1597: complete `get_all_scorers`.
   - `evaluation/base.py` line 21: import of both validation functions.
   - `optimize/util.py` line 11: import of `valid_data_for_builtin_scorers`.

9. **Repository tests**:
   - `/testbed/tests/genai/scorers/test_builtin_scorers.py` line 570: `test_get_all_scorers_oss` — exercises `get_all_scorers()` with file and databricks URIs, verifies counts (6/8) and types.
   - `/testbed/tests/genai/scorers/test_scorer.py` lines 61–290: exercises `@scorer` decorator through `mlflow.genai.evaluate()`, including `test_scorer_existence_in_metrics`, `test_custom_scorer_allow_none_return`, `test_scorer_on_genai_evaluate`.
   - `/testbed/tests/genai/scorers/test_registered_scorers_scheduling.py` line 347: defines a `CustomScorer(Scorer)` subclass for registration tests — analogous entity lifecycle, confirming `CustomScorer` naming convention.

## Rubric Scores

### Seed: Requirement coverage
- **Score**: PARTIAL
- **Evidence**: R1 (CustomScorer), R2 (validate_scorers), R3 (valid_data_for_builtin_scorers), R4 (get_all_scorers), R5 (evaluate import), R6 (optimize import), R7 (validate_aggregations), R8 (validate_columns), R9 (MissingColumnsException) are all traced to C contracts and spec checks. However, R2's legacy-Metric acceptance sub-requirement has no corresponding C contract and no spec check (see Finding 1).
- **Affected IDs**: R2 (partial), no C contract for legacy Metric path.

### Seed: Requirement fidelity
- **Score**: PASS
- **Evidence**: All spec assertions check the task-supported relations: CustomScorer stores `_original_func`, delegates `__call__`, has `ScorerKind.DECORATOR`; `validate_scorers` rejects non-lists, classes, nested `get_all_scorers()`, accepts valid Scorers; `valid_data_for_builtin_scorers` remaps legacy columns, explodes expectations, logs instead of raising; `get_all_scorers` returns 6/8 scorers correctly.

### Seed: Caller binding and architecture
- **Score**: PARTIAL
- **Evidence**: The evaluate caller-binding path is exercised by `check_evaluate_calls_validate_scorers` which calls `mlflow.genai.evaluate()` — a true CALL edge through the public entry point. The optimize/util.py caller path is NOT exercised through `validate_train_data()`; only module-level `importlib.import_module` checks exist (see Finding 2). The arch_spec C15/C16 checks verify symbol existence in the validation module but do not verify import statements in caller files (see Finding 3).
- **Affected IDs**: R6, C16, E3.

### Seed: Dataflow and lifecycle
- **Score**: PASS
- **Evidence**: C7–C12 checks use `wraps`-patched `validate_columns` to observe the exact set of columns reaching the scorer, verifying remap (`request→inputs`, `response→outputs`), predict_fn path (`outputs` added, `trace` added), trace path (`inputs`+`outputs` inferred), expectations explosion (`expectations/{key}` columns), and non-dict expectations exception. Return-value checks verify `None` from `valid_data_for_builtin_scorers`.

### Seed: Failure and compatibility
- **Score**: PASS
- **Evidence**: C3 (non-list → `MlflowException.invalid_parameter_value`), C5 (class → hint about instance), C6 (nested list → hint about `get_all_scorers()`), C11 (non-dict expectations → `MlflowException.invalid_parameter_value`), C18 (invalid aggregation → `MlflowException.invalid_parameter_value`), C20 (non-string/non-callable → `MlflowException.invalid_parameter_value`) all verify the correct exception class, error code, and diagnostic content. Missing-column path (C12) verifies log-and-return-None (no raise).

### Seed: Static-issue closure
- **Score**: PASS
- **Evidence**: All 4 static issues are addressed by runtime checks:
  - `CustomScorer` used but not defined → `check_custom_scorer_importable_via_module` and `check_c1_scorer_creates_custom_scorer` verify the class is created at runtime.
  - `validate_scorers` and `valid_data_for_builtin_scorers` not imported in `evaluation/base.py` → `check_r5_static_import_closure` and `check_evaluate_calls_validate_scorers` verify symbols reachable and call path functional.
  - `valid_data_for_builtin_scorers` not imported in `optimize/util.py` → `check_r6_static_import_closure` verifies module importable; but see Finding 2 for weakness.

### Seed: Oracle strength
- **Score**: PASS
- **Evidence**: Assertions use exact values (e.g., `kind == ScorerKind.DECORATOR`, `len(scorers) == 6`, specific type names in `type_map`), exact exception codes (`INVALID_PARAMETER_VALUE`), exact column names in sets (`"inputs"`, `"outputs"`, `"expectations/expected_response"`), identity checks (`result[0] is s1`), and specific log message content (`"missing"`). No success-only or broad-type checks for critical paths.

### Repository-test-derived domain rubric: Decorator identity through evaluate pipeline
- **Source**: `/testbed/tests/genai/scorers/test_scorer.py` `test_scorer_on_genai_evaluate` (line 247) and `test_custom_scorer_allow_none_return` (line 268)
- **Score**: PASS
- **Evidence**: Both `check_evaluate_calls_validate_scorers` (arch) and `check_c1_custom_scorer_behavior` (behavior) exercise the decorator→evaluate pipeline and the `.run()` method, matching the repository test pattern of using `@scorer` decorator products with `evaluate()` and `scorer.run()`.

### Repository-test-derived domain rubric: get_all_scorers URI-dependent composition
- **Source**: `/testbed/tests/genai/scorers/test_builtin_scorers.py` `test_get_all_scorers_oss` (line 570)
- **Score**: PASS
- **Evidence**: Both specs parameterize tracking URI, verify 6 vs 8 count, and check for specific scorer type names. The repository test uses parametrize with `"file://test"` and `"databricks"`; the generated specs use `"file:///tmp/mlflow-test-behavior"` and `"databricks://test"`, which is an acceptable adaptation.

### Derived rubric: validate_train_data caller path (optimize/util.py)
- **Source**: No dedicated repository test; call site at `/testbed/mlflow/genai/optimize/util.py` line 91
- **Score**: FAIL (see Finding 2)
- **Evidence**: Neither spec calls `validate_train_data()` to exercise the `valid_data_for_builtin_scorers` call at line 91. Only module-existence checks exist (`importlib.import_module`, `hasattr`).

### Derived rubric: Legacy Metric acceptance path
- **Source**: R2 in semantic IR; reference at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 46–54, 91–97
- **Score**: FAIL (see Finding 1)
- **Evidence**: No C contract or spec check exercises the `databricks.rag_eval.evaluation.metrics.Metric` acceptance path.

## Findings

### Finding 1: missing_requirement — Legacy Metric acceptance in validate_scorers is untested

- **Type**: `missing_requirement`
- **Affected IDs**: R2
- **Static issue**: None — this is a sub-requirement omission, not a static-analysis gap.
- **Repository source evidence**: The reference implementation at `/testbed/libs/skinny/mlflow/genai/scorers/validation.py` lines 46–54 accepts `databricks.rag_eval.evaluation.metrics.Metric` instances:
  ```python
  if IS_DBX_AGENTS_INSTALLED:
      from databricks.rag_eval.evaluation.metrics import Metric
      if isinstance(scorer, Metric):
          legacy_metrics.append(scorer)
          valid_scorers.append(scorer)
          continue
  ```
  Lines 91–97 log a deprecation warning for legacy metrics. The semantic IR R2 states: *"accept legacy `databricks.rag_eval.evaluation.metrics.Metric` instances when databricks.agents is installed (with deprecation warning)"*.
- **Gap**: The IR defines 21 C contracts (C1–C21) but none addresses the legacy-Metric path. Neither arch_spec nor behavior_spec includes a check that passes a `Metric` instance to `validate_scorers` and verifies it is accepted and a deprecation warning is logged. A wrong implementation that silently rejects or mishandles legacy Metric objects would pass all existing spec checks.
- **Rework instructions**:
  1. Add a C contract (e.g., C22) in the IR documenting the legacy Metric acceptance path.
  2. Add a behavior-spec check that:
     - Mocks `importlib.util.find_spec("databricks.agents")` to return a non-None value (simulating databricks.agents installed).
     - Creates a mock `Metric` instance (or patches `databricks.rag_eval.evaluation.metrics.Metric`).
     - Passes it to `validate_scorers([mock_metric])`.
     - Asserts the metric is in the returned list (identity preserved or value-equal).
     - Asserts a deprecation warning is logged containing the metric name.

### Finding 2: weak_constraint — optimize/util.py caller path never exercised through validate_train_data

- **Type**: `weak_constraint`
- **Affected IDs**: R6, C16, E3
- **Static issue**: `valid_data_for_builtin_scorers` is used but not imported in `optimize/util.py` (static issue #3).
- **Repository source evidence**:
  - `/testbed/mlflow/genai/optimize/util.py` line 91: `valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)` inside `validate_train_data`.
  - `/testbed/libs/skinny/mlflow/genai/optimize/util.py` line 11: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers`.
  - No repository test exercises `validate_train_data` through the scoring validation path.
- **Gap**: Both `check_c16_optimize_imports_valid_data` (arch_spec) and `check_r6_static_import_closure` (behavior_spec) verify only that the module imports without `ImportError`, that `validate_train_data` exists as a callable attribute, and that `valid_data_for_builtin_scorers` is callable from the validation module. Neither check actually **calls** `validate_train_data()`. The `valid_data_for_builtin_scorers` symbol is referenced inside `validate_train_data`'s function body (not at module level), so a missing import line in `optimize/util.py` would not prevent module import — it would only cause `NameError` when `validate_train_data()` is invoked. All existing spec checks would pass, but the production code path would fail.
- **Contrast with the evaluate path**: For R5/C15, `check_evaluate_calls_validate_scorers` calls `mlflow.genai.evaluate()` which internally calls `validate_scorers` — a true CALL-edge observation. No equivalent exists for the optimize path.
- **Rework instructions**:
  1. Add a behavior-spec check that calls `validate_train_data()` (or a minimal wrapper that reaches line 91) with a small valid DataFrame and a builtin scorer, verifying either successful completion or a downstream error that proves the import resolved. For example:
     ```python
     from mlflow.genai.optimize.util import validate_train_data
     data = pd.DataFrame({"inputs": ["q1"], "outputs": ["a1"]})
     # Should not raise NameError; downstream errors (e.g., missing model) are acceptable
     try:
         validate_train_data(data, [Correctness()])
     except NameError:
         raise AssertionError("R6: valid_data_for_builtin_scorers not imported in optimize/util.py")
     except Exception:
         pass  # downstream errors are fine; NameError is the concern
     ```
  2. Alternatively, verify the literal import statement text exists in `/testbed/mlflow/genai/optimize/util.py`.

### Finding 3: weak_constraint — C15/C16 arch checks are symbol-existence checks, not caller-binding checks

- **Type**: `weak_constraint`
- **Affected IDs**: R5/C15, R6/C16, E1, E2, E3
- **Static issue**: Both `validate_scorers` and `valid_data_for_builtin_scorers` reported as "used but not defined or imported" in `evaluation/base.py` (#1, #2); same for `optimize/util.py` (#3).
- **Repository source evidence**: The import line `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers` is present at `/testbed/libs/skinny/mlflow/genai/evaluation/base.py` line 21 and absent at `/testbed/mlflow/genai/evaluation/base.py` line 21.
- **Gap**: `check_c15_evaluate_imports_validate_scorers` and `check_c16_optimize_imports_valid_data` verify:
  1. The validation module exports the functions (callable check).
  2. The caller modules can be imported without `ImportError`.
  3. The key functions (`evaluate`, `validate_train_data`) exist as attributes.

  They do **not** verify the literal import statement exists in the caller source files. A plausible wrong implementation where `validate_scorers` is imported from a different module or defined as a local stub would pass. For C15, `check_evaluate_calls_validate_scorers` mitigates this by exercising the actual call path. For C16, no mitigation exists (compounded by Finding 2).
- **Rework instructions**: This is partially mitigated for C15 by the evaluate integration test. For C16, see Finding 2 rework. Additionally, the arch_spec C15/C16 checks could be strengthened by reading the source file and asserting the import line text, but the preferred approach is exercising the actual call path as done for C15.

## Decision

**Decision: REWORK**

Three findings require resolution before the specs can be considered faithfully compiled:

1. **Finding 1 (missing_requirement)**: The legacy `Metric` acceptance path in `validate_scorers` (R2) has no C contract and no spec check. Must add both.
2. **Finding 2 (weak_constraint)**: The `optimize/util.py` caller path for `valid_data_for_builtin_scorers` (R6/C16) is never exercised through `validate_train_data()`. Must add a call-path exercise.
3. **Finding 3 (weak_constraint)**: C15/C16 arch checks are module-existence rather than caller-binding checks. For C15 this is mitigated by the evaluate integration test; for C16 it is not (same gap as Finding 2).

All other requirements (R1, R3, R4, R7, R8, R9) and contracts (C1–C14, C17–C21) are well-covered by strong, oracle-rich checks with correct failure semantics.
