# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — defines arch/behavior separation, chain-call pattern, mock-only-external rule
- Native tests:
  - `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — validates that valid types are accepted, AI_JUDGE deprecated is accepted, invalid type raises MlflowException with exact message match
  - `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` — validates full chain: AssessmentSource constructor → __post_init__ → _standardize → constructor → _parse, with 6 case variants
  - `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — exact FutureWarning message match (`"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`)
  - `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` — exact MlflowException message match for blocked deserialization
  - `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_databricks_remote_access` — mocked environment path for remote Databricks blocking
  - `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` — Feedback name rewriting in `Scorer.run`
  - `tests/genai/scorers/test_scorer.py::test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list` — list-of-Feedback name preservation
  - `tests/genai/scorers/test_scorer_utils.py::test_simple_function_recreation` — basic recreate_function correctness (`recreated(3,4)==7`)
  - `tests/genai/scorers/test_scorer_utils.py::test_function_with_syntax_error` — SyntaxError on malformed source
  - `tests/genai/scorers/test_scorer_utils.py::test_function_with_mlflow_trace_type_hint` — type hint resolution in recreated functions
  - `tests/genai/scorers/test_scorer_utils.py::test_function_name_in_namespace` — __name__ preservation
  - `tests/genai/scorers/test_scorer_description.py::test_decorator_scorer_with_description` — description parameter works
  - `tests/genai/scorers/test_scorer_CRUD.py::test_mlflow_backend_scorer_operations` — full register/list/get/delete lifecycle

## Rubric
- Requirement coverage: 1 — C11 (model_validate reconstruction) is entirely absent; R9 has no executable observation. R18 (FunctionBodyExtractor) has no direct coverage. R8 serialization roundtrip (model_dump → model_validate) is only half-tested.
- Caller binding / call chain: 1 — C3 tests `_standardize` directly but never exercises the real caller `AssessmentSource.__post_init__`. C19/C20 test import identity (same object) but never prove the imported `scorer` is functional. No arch-spec check follows the full L2 chain `AssessmentSource(source_type="human")` → `__post_init__` → `_standardize` → constructor → `_parse` → validation with spied observer.
- Dataflow / state / lifecycle: 1 — C9 tests field presence in model_dump but doesn't verify the full dataflow: scorer → model_dump → SerializedScorer → model_validate → reconstructed scorer that actually runs. No lifecycle check (start/stop/update) despite task requirement "scorer registration, lifecycle management (start/stop/update), and sampling configuration."
- Failure / compatibility boundaries: 1 — C22 tests dict rejection but doesn't verify the exact error message format. C5 tests MlflowException but doesn't verify error_code == INVALID_PARAMETER_VALUE. C12/C13 test that blocking raises but C12 doesn't verify the code-snippet rendering in the error message (which native test `test_custom_scorer_error_message_renders_code_snippet_legibly` does).

## Derived Practical Test Perspectives

### P1: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — exact FutureWarning message match
Native test uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`. The generated behavior spec C4 uses `warnings.catch_warnings(record=True)` and asserts `"AI_JUDGE is deprecated" in str(w[0].message)`. This is a substring match that would pass even if the message format changes subtly. The exact `pytest.warns(match=...)` pattern is the standard MLflow test practice and should be replicated for compatibility assurance.

### P2: `tests/genai/scorers/test_scorer.py::test_custom_scorer_error_message_renders_code_snippet_legibly` — error message code snippet rendering
Native test verifies that `_reconstruct_decorator_scorer` raises an error whose message contains a properly formatted code snippet with `from mlflow.genai import scorer`, `@scorer`, and the function definition. The generated C12 only checks that `"is not supported outside of"` appears in the message. This is a weak constraint that would pass even if the code snippet rendering logic is broken.

### P3: `tests/genai/scorers/test_scorer_utils.py::test_function_with_mlflow_trace_type_hint` — type hint resolution in recreated functions
Native test verifies that `recreate_function` with signature `"(trace: mlflow.entities.Trace) -> mlflow.entities.Feedback"` can be called with a Trace object and returns a Feedback with `value is True`. The generated C16 tests this but uses a simpler assertion. The native test's full create-and-call pattern with a real Trace fixture provides stronger evidence that the `mlflow` namespace is properly injected.

### P4: `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` — Feedback name rewriting boundary
Native test verifies that `Scorer.run` rewrites `Feedback(value=42)` (default name) to the scorer name `"my_scorer"` but preserves `Feedback(name="custom_name", value=42)`. The generated specs have no test for this name-rewriting boundary behavior in `Scorer.run`. C21 only tests return values, not name rewriting.

### P5: `tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate` — end-to-end evaluate integration for Feedback return types
Native test parametrizes over Feedback, list[Feedback], and primitive returns through the full `mlflow.genai.evaluate()` pipeline. The generated specs test `Scorer.run` in isolation but never verify that the scorer integrates correctly with the evaluate pipeline for Feedback/list[Feedback] return types.

## Final Rubric Scores
- Requirement coverage: 1 — C11 (R9 deserialization) missing; R8 only half-tested (model_dump without model_validate roundtrip); R18 not tested
- Caller binding / call chain: 1 — C3 only tests helper directly, not through AssessmentSource.__post_init__; C19/C20 are import-smoke not functional chain tests
- Dataflow / state / lifecycle: 1 — No serialization roundtrip test; no lifecycle (start/stop/update) coverage; model_dump dataflow only half-verified
- Failure / compatibility boundaries: 1 — C5 doesn't check error_code; C12 doesn't verify code-snippet rendering; C22 doesn't verify exact message format
- P1 (exact warning match): 1 — C4 uses substring match instead of pytest.warns(match=...) exact pattern
- P2 (code snippet rendering): 0 — No check for code snippet format in error message
- P3 (type hint resolution): 2 — C16 adequately covers this with real Trace object call
- P4 (Feedback name rewriting): 0 — No check for name rewriting in Scorer.run
- P5 (evaluate integration): 0 — No end-to-end evaluate integration test for Feedback/list[Feedback] returns

## Findings

### F1: missing_requirement
- Requirement/IR: R9 / C11
- Evidence: IR contract C11 states "Scorer.model_validate dispatches to _reconstruct_decorator_scorer when decorator fields present" and `test_custom_scorer_loading_blocked_for_non_databricks_uri` calls `Scorer._reconstruct_decorator_scorer(serialized)` directly. But no spec verifies the full `Scorer.model_validate(SerializedScorer(...))` path.
- Gap: Neither arch_spec.py nor behavior_spec.py contains any check for C11. The full deserialization pipeline (scorer → model_dump → dict → model_validate → reconstructed scorer → run) is entirely absent.
- Repair: Add a behavior_spec check `check_C11_model_validate_reconstructs_scorer()` that: (1) creates a scorer with `@scorer`, (2) calls `model_dump()` to get a dict, (3) creates a `SerializedScorer` from that dict, (4) mocks `is_in_databricks_runtime` to return True, (5) calls `Scorer.model_validate(serialized_dict)` or `Scorer.model_validate(serialized)`, (6) asserts the reconstructed scorer has the same name, (7) asserts `reconstructed.run(outputs="test")` produces the expected result.

### F2: weak_constraint
- Requirement/IR: R4 / C3
- Evidence: arch_spec.py `check_C3_standardize_delegates_to_constructor()` directly calls `AssessmentSourceType._standardize("human")` and asserts the result. The Test Spec skill mandates: "public entry → real caller → helper → observer." The real caller is `AssessmentSource.__post_init__` (line 78 of assessment_source.py), which calls `AssessmentSourceType._standardize(self.source_type)`.
- Gap: The current check bypasses the real caller chain entirely. It proves that `_standardize` works when called directly but does not prove that `AssessmentSource(source_type="human")` triggers the correct path through `__post_init__` → `_standardize` → constructor → `_parse`.
- Repair: Convert C3 to a proper arch-spec check that: (1) imports `AssessmentSource`, (2) creates `AssessmentSource(source_type="human", source_id="test")`, (3) asserts `source.source_type == "HUMAN"`, (4) optionally spies on `AssessmentSourceType._standardize` to verify it was called by `__post_init__`. This exercises the full L2 edge E1 (N7→N6→N3→N5) from the IR graph.

### F3: weak_constraint
- Requirement/IR: R16 / C19, C20
- Evidence: arch_spec.py `check_C19_scorer_importable_from_scorers()` and `check_C20_scorer_importable_from_genai()` only verify `scorer is _base_scorer` (object identity). The Test Spec skill says "A successful `import module`, a source text match, or `hasattr(module, "helper")` proves none of Dependency, Call Chain, or Dataflow."
- Gap: These checks prove the import boundary resolves to the same object but do not prove the imported `scorer` function is functional — i.e., can actually wrap a function and produce a working Scorer.
- Repair: Extend each check to call the imported `scorer` with a trivial lambda, e.g., `s = scorer(lambda outputs: len(outputs))` and assert `s.run(outputs="test") == 4`. This proves the imported symbol is callable, produces a Scorer, and the Scorer can execute.

### F4: weak_constraint
- Requirement/IR: R12, R13 / C21, C22
- Evidence: C21 tests `Scorer.run` with lambdas returning primitives but never with lambdas returning `Feedback` or `list[Feedback]`. The task explicitly requires: "Support various return types (primitives, Feedback objects, lists)." Native test `test_custom_scorer_overwrites_default_feedback_name` verifies Feedback name rewriting in `Scorer.run`.
- Gap: C21 uses `scorer(lambda outputs: len(outputs))` — a primitive return. It does not test that `Scorer.run` correctly handles a Feedback return (with name rewriting), a list[Feedback] return, or a None return (which native test `test_custom_scorer_allow_none_return` verifies).
- Repair: Add to C21 (or create a new check `check_C21b_Scorer_run_feedback_returns`) that tests: (1) Feedback return with default name → name rewritten to scorer name, (2) Feedback return with custom name → name preserved, (3) list[Feedback] return → names preserved, (4) None return → None returned. This maps to native tests `test_custom_scorer_overwrites_default_feedback_name`, `test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list`, and `test_custom_scorer_allow_none_return`.

### F5: missing_requirement
- Requirement/IR: R8 / C9 (serialization roundtrip)
- Evidence: C9 in arch_spec tests `model_dump()` field presence but never feeds the result into `model_validate()`. The task says "Provide secure serialization that handles source code extraction and reconstruction." The native test `test_custom_scorer_error_message_renders_code_snippet_legibly` tests the code-snippet rendering in reconstruction errors, but there is no test for the happy-path roundtrip.
- Gap: C9 checks that `model_dump()` contains the right keys but doesn't verify that the dict can be round-tripped through `SerializedScorer` and `model_validate` to produce a working scorer. A bug in `model_validate` or `SerializedScorer.__post_init__` would not be caught.
- Repair: Extend `check_C9_model_dump_serialized_fields()` to also: (1) pass the dumped dict into `SerializedScorer(**dump)` to verify it validates, (2) mock `is_in_databricks_runtime` → True, (3) call `Scorer.model_validate(dump)` or `Scorer.model_validate(serialized)`, (4) assert the reconstructed scorer.run(outputs="test") returns the expected value.

### F6: missing_requirement
- Requirement/IR: Task: "Enable scorer registration, lifecycle management (start/stop/update), and sampling configuration"
- Evidence: The native test `tests/genai/scorers/test_scorer_CRUD.py::test_mlflow_backend_scorer_operations` exercises the full lifecycle: register → list → get → delete. The task explicitly requires lifecycle management (start/stop/update).
- Gap: Neither arch_spec.py nor behavior_spec.py contains any check for scorer lifecycle operations (register, start, stop, update, status transitions). The `ScorerStatus` enum and `ScorerSamplingConfig` are defined but never exercised.
- Repair: Add a behavior_spec check that: (1) creates a decorator scorer, (2) asserts initial `status == ScorerStatus.UNREGISTERED`, (3) mocks Databricks environment, (4) registers the scorer and asserts status transitions. Alternatively, test the local state transitions: `_registered_backend` set → status changes, `sample_rate` > 0 → STARTED, `sample_rate` == 0 → STOPPED.

## Rework Instructions

1. **Add C11 (model_validate reconstruction)**: Create `check_C11_model_validate_reconstructs_scorer()` in behavior_spec.py. Mock `is_in_databricks_runtime` to return True. Create a scorer via `@scorer`, call `model_dump()`, construct a `SerializedScorer` from the dump, call `Scorer.model_validate(serialized_dict)`, and verify the reconstructed scorer produces the same output via `.run()`.

2. **Strengthen C3 (caller chain)**: In arch_spec.py, replace the direct `_standardize` call with a test that creates `AssessmentSource(source_type="human", source_id="test")` and asserts `source.source_type == "HUMAN"`. Add a spy on `AssessmentSourceType._standardize` to verify it was called by `__post_init__`.

3. **Strengthen C19/C20 (functional imports)**: Extend both import checks to call the imported `scorer` with a lambda and verify `scorer(lambda outputs: len(outputs)).run(outputs="test") == 4`.

4. **Strengthen C21 (Feedback/list/None returns)**: Add sub-checks for Feedback return with default name overwriting, Feedback return with custom name preservation, list[Feedback] return, and None return. Use the `Feedback` class from `mlflow.entities`.

5. **Strengthen C9 (roundtrip)**: Extend to verify that `model_dump()` output can be round-tripped: create `SerializedScorer(**dump)`, mock Databricks, call `Scorer.model_validate(dump)`, and run the reconstructed scorer.

6. **Add lifecycle check**: Create a new behavior check that tests `ScorerStatus` transitions: UNREGISTERED → STOPPED (after setting `_registered_backend`) → STARTED (after setting `_sampling_config.sample_rate > 0`).

7. **Strengthen C4 (exact warning match)**: Use `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` pattern instead of manual `warnings.catch_warnings`+substring match, matching the native test practice.

8. **Strengthen C5 (error code verification)**: Add assertion that the raised `MlflowException` has `error_code == INVALID_PARAMETER_VALUE` (from `mlflow.protos.databricks_pb2`).

9. **Add P2 coverage (code snippet rendering)**: Add a check that `_reconstruct_decorator_scorer` error message contains properly formatted code snippet with `from mlflow.genai import scorer`, `@scorer`, the function definition, and indented body lines. Match the native test `test_custom_scorer_error_message_renders_code_snippet_legibly`.
