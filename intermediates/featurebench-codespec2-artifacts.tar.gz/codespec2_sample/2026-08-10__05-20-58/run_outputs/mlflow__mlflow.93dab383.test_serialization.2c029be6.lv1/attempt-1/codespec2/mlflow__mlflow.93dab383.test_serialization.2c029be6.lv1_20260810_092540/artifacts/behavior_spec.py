#!/usr/bin/env python3
"""
Executable behavior spec for AssessmentSourceType and scorer framework.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility contracts:
  C1, C2, C4, C5, C6, C7, C8, C11, C12, C13, C14, C15, C16, C17,
  C21, C22, C23, C24, C25 (lifecycle), C26 (code snippet rendering)

Each check_* function is a zero-argument top-level check that exercises
a public entry to its downstream observer and prints PASS: on success.
"""

import warnings
from unittest.mock import patch


# --------------------------------------------------------------------------------
# C1 – AssessmentSourceType constructor uppercases and stores (State)
# --------------------------------------------------------------------------------

def check_C1_constructor_uppercases_and_stores() -> None:
    """Contracts: C1

    AssessmentSourceType.__init__ must accept a string, uppercase it via _parse,
    validate against _SOURCE_TYPES, and store the result in self._source_type.
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    # Lowercase input → stored uppercase
    instance = AssessmentSourceType("human")
    assert instance._source_type == "HUMAN", (
        f"Expected '_source_type' == 'HUMAN', got {instance._source_type!r}"
    )

    # Already uppercase
    instance2 = AssessmentSourceType("LLM_JUDGE")
    assert instance2._source_type == "LLM_JUDGE", (
        f"Expected '_source_type' == 'LLM_JUDGE', got {instance2._source_type!r}"
    )

    # Mixed case
    instance3 = AssessmentSourceType("Code")
    assert instance3._source_type == "CODE", (
        f"Expected '_source_type' == 'CODE', got {instance3._source_type!r}"
    )

    print("PASS: C1 – AssessmentSourceType constructor uppercases and stores")


# --------------------------------------------------------------------------------
# C2 – AssessmentSourceType.__str__ returns stored value (Interface)
# --------------------------------------------------------------------------------

def check_C2_str_returns_stored_value() -> None:
    """Contracts: C2

    AssessmentSourceType.__str__ must return self._source_type, the validated
    uppercase form.
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert str(AssessmentSourceType("human")) == "HUMAN"
    assert str(AssessmentSourceType("HUMAN")) == "HUMAN"
    assert str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"
    assert str(AssessmentSourceType("CODE")) == "CODE"
    assert str(AssessmentSourceType("source_type_unspecified")) == "SOURCE_TYPE_UNSPECIFIED"

    print("PASS: C2 – AssessmentSourceType.__str__ returns stored value")


# --------------------------------------------------------------------------------
# C4 – AI_JUDGE deprecated with FutureWarning (SideEffect)
#   REPAIRED: use pytest.warns exact match pattern matching native test practice
# --------------------------------------------------------------------------------

def check_C4_AI_JUDGE_deprecated_with_FutureWarning() -> None:
    """Contracts: C4

    When 'AI_JUDGE' (case-insensitive) is passed to AssessmentSourceType,
    a FutureWarning must be emitted with the exact message
    "AI_JUDGE is deprecated. Use LLM_JUDGE instead." and the result must be 'LLM_JUDGE'.

    # Perspective: native test test_ai_judge_deprecation_warning uses
    #   pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")
    """
    from mlflow.entities.assessment_source import AssessmentSourceType

    # Test exact warning message via _parse
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._parse("AI_JUDGE")
        assert len(w) == 1, f"Expected 1 warning, got {len(w)}"
        assert issubclass(w[0].category, FutureWarning), (
            f"Expected FutureWarning, got {w[0].category.__name__}"
        )
        # Exact message match per native test
        assert str(w[0].message) == "AI_JUDGE is deprecated. Use LLM_JUDGE instead.", (
            f"Exact deprecation message mismatch: {w[0].message!r}"
        )
        assert result == "LLM_JUDGE", (
            f"Expected 'LLM_JUDGE', got {result!r}"
        )

    # Case-insensitive: "ai_judge" should also trigger with exact message
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = AssessmentSourceType._parse("ai_judge")
        assert len(w) == 1, f"Expected 1 warning for 'ai_judge', got {len(w)}"
        assert issubclass(w[0].category, FutureWarning)
        assert str(w[0].message) == "AI_JUDGE is deprecated. Use LLM_JUDGE instead."
        assert result == "LLM_JUDGE"

    # Verify via AssessmentSource (public entry) with exact message
    from mlflow.entities.assessment_source import AssessmentSource

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        source = AssessmentSource(source_type="AI_JUDGE", source_id="test")
        assert len(w) >= 1, f"Expected at least 1 warning via AssessmentSource, got {len(w)}"
        assert issubclass(w[0].category, FutureWarning)
        assert str(w[0].message) == "AI_JUDGE is deprecated. Use LLM_JUDGE instead."
        assert source.source_type == "LLM_JUDGE", (
            f"Expected source_type 'LLM_JUDGE', got {source.source_type!r}"
        )

    print("PASS: C4 – AI_JUDGE deprecated with exact FutureWarning, converts to LLM_JUDGE")


# --------------------------------------------------------------------------------
# C5 – Invalid source type raises MlflowException (Failure)
#   REPAIRED: verify error_code == INVALID_PARAMETER_VALUE
# --------------------------------------------------------------------------------

def check_C5_invalid_source_type_raises_MlflowException() -> None:
    """Contracts: C5

    Unrecognized source type strings must raise MlflowException with
    INVALID_PARAMETER_VALUE error code and message containing 'Invalid assessment source type'.

    # Perspective: native test test_assessment_source_type_validation expects
    #   pytest.raises(MlflowException, match="Invalid assessment source type")
    """
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    # Via _parse
    try:
        AssessmentSourceType._parse("ROBOT")
        assert False, "Expected MlflowException for 'ROBOT'"
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e), (
            f"Exception message mismatch: {e}"
        )
        # Verify error_code is INVALID_PARAMETER_VALUE (1000)
        assert e.error_code == INVALID_PARAMETER_VALUE, (
            f"Expected error_code {INVALID_PARAMETER_VALUE}, got {e.error_code}"
        )

    # Also verify the public AssessmentSource path
    from mlflow.entities.assessment_source import AssessmentSource

    try:
        AssessmentSource(source_type="MARTIAN", source_id="test")
        assert False, "Expected MlflowException for 'MARTIAN' via AssessmentSource"
    except MlflowException as e:
        assert "Invalid assessment source type" in str(e), (
            f"Exception message mismatch: {e}"
        )
        assert e.error_code == INVALID_PARAMETER_VALUE, (
            f"Expected error_code {INVALID_PARAMETER_VALUE}, got {e.error_code}"
        )

    print("PASS: C5 – Invalid source type raises MlflowException with INVALID_PARAMETER_VALUE")


# --------------------------------------------------------------------------------
# C6 – scorer decorator preserves function name (State)
# --------------------------------------------------------------------------------

def check_C6_scorer_decorator_name() -> None:
    """Contracts: C6

    When @scorer wraps a function, the resulting scorer's name must
    default to the original function's __name__.
    """
    from mlflow.genai.scorers.base import scorer

    @scorer
    def my_test_fn(outputs) -> bool:
        return len(outputs) > 0

    assert my_test_fn.name == "my_test_fn", (
        f"Expected name 'my_test_fn', got {my_test_fn.name!r}"
    )

    print("PASS: C6 – scorer decorator preserves function name")


# --------------------------------------------------------------------------------
# C7 – scorer parameterized usage (name, description, aggregations) (Interface)
# --------------------------------------------------------------------------------

def check_C7_scorer_parameterized_usage() -> None:
    """Contracts: C7

    @scorer(name="custom") must allow parameterized usage via functools.partial.
    """
    from mlflow.genai.scorers.base import scorer

    @scorer(name="custom_scorer")
    def _fn(outputs) -> bool:
        return len(outputs) > 0

    assert _fn.name == "custom_scorer", (
        f"Expected name 'custom_scorer', got {_fn.name!r}"
    )

    # Parameterized with description
    desc = "A description"
    @scorer(description=desc)
    def _fn2(outputs) -> bool:
        return True

    assert _fn2.description == desc, (
        f"Expected description {desc!r}, got {_fn2.description!r}"
    )

    print("PASS: C7 – scorer parameterized usage with name/description")


# --------------------------------------------------------------------------------
# C8 – scorer kind is DECORATOR (State)
# --------------------------------------------------------------------------------

def check_C8_scorer_kind_is_DECORATOR() -> None:
    """Contracts: C8

    A scorer created via @scorer must have kind == ScorerKind.DECORATOR.
    """
    from mlflow.genai.scorers.base import scorer
    from mlflow.genai.scorers.base import ScorerKind

    @scorer
    def _fn(outputs) -> bool:
        return True

    assert _fn.kind == ScorerKind.DECORATOR, (
        f"Expected kind DECORATOR, got {_fn.kind}"
    )

    print("PASS: C8 – scorer kind is DECORATOR")


# --------------------------------------------------------------------------------
# C11 – model_validate reconstructs scorer (Behavior)  [NEW]
# --------------------------------------------------------------------------------

def check_C11_model_validate_reconstructs_scorer() -> None:
    """Contracts: C11

    Scorer.model_validate must accept a serialized dict from model_dump()
    and reconstruct a working scorer when is_in_databricks_runtime is True.

    # Perspective: native test test_scorer_deserialization_with_description
    #   exercises model_validate on serialized scorer dict
    """
    from mlflow.genai.scorers.base import scorer, Scorer

    @scorer
    def _reconstruct_test(outputs) -> int:
        return len(outputs)

    # Get the serialized form
    dump = _reconstruct_test.model_dump()

    # Verify reconstruction fails without Databricks runtime (safety check)
    from mlflow.exceptions import MlflowException
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            Scorer.model_validate(dump)
            # If no exception, assert it's in Databricks runtime
            pass
        except MlflowException as e:
            # Expected when not in Databricks: security block
            assert "not supported" in str(e) or "not supported outside" in str(e), (
                f"Expected security block message, got: {e}"
            )

    # Verify reconstruction succeeds in Databricks runtime
    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        reconstructed = Scorer.model_validate(dump)
        assert reconstructed.name == "_reconstruct_test", (
            f"Expected name '_reconstruct_test', got {reconstructed.name!r}"
        )
        # Verify the reconstructed scorer can run
        result = reconstructed.run(outputs="hello")
        assert result == 5, (
            f"Expected reconstructed scorer to return 5, got {result!r}"
        )

    print("PASS: C11 – model_validate reconstructs working scorer in Databricks runtime")


# --------------------------------------------------------------------------------
# C12 – _reconstruct_decorator_scorer blocked outside Databricks (Failure)
# --------------------------------------------------------------------------------

def check_C12_reconstruct_blocked_outside_databricks() -> None:
    """Contracts: C12

    _reconstruct_decorator_scorer must raise MlflowException when called
    outside of Databricks runtime.
    """
    from mlflow.genai.scorers.base import SerializedScorer, Scorer
    from mlflow.exceptions import MlflowException

    serialized = SerializedScorer(
        name="test_scorer",
        call_source="return len(outputs) > 0",
        call_signature="(outputs)",
        original_func_name="test_scorer",
    )

    try:
        Scorer._reconstruct_decorator_scorer(serialized)
        assert False, "Expected MlflowException for blocked reconstruction"
    except MlflowException as e:
        assert "not supported outside of" in str(e).lower() or "not supported" in str(e).lower(), (
            f"Expected blocking message, got: {e}"
        )

    print("PASS: C12 – _reconstruct_decorator_scorer blocked outside Databricks")


# --------------------------------------------------------------------------------
# C13 – _reconstruct_decorator_scorer blocked for remote Databricks access (Failure)
# --------------------------------------------------------------------------------

def check_C13_reconstruct_blocked_remote_databricks() -> None:
    """Contracts: C13

    With is_in_databricks_runtime=False and is_databricks_uri=True,
    reconstruction must raise with "via remote access is not supported".
    """
    from mlflow.genai.scorers.base import SerializedScorer, Scorer
    from mlflow.exceptions import MlflowException

    serialized = SerializedScorer(
        name="test_scorer",
        call_source="return True",
        call_signature="(outputs)",
        original_func_name="test_scorer",
    )

    with (
        patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=False),
        patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True),
    ):
        try:
            Scorer._reconstruct_decorator_scorer(serialized)
            assert False, "Expected MlflowException for remote access"
        except MlflowException as e:
            assert "via remote access is not supported" in str(e), (
                f"Expected 'via remote access is not supported', got: {e}"
            )

    print("PASS: C13 – _reconstruct_decorator_scorer blocked for remote Databricks access")


# --------------------------------------------------------------------------------
# C14 – recreate_function basic reconstruction (Behavior)
# --------------------------------------------------------------------------------

def check_C14_recreate_function_basic() -> None:
    """Contracts: C14

    recreate_function("return x + y", "(x, y)", "add") must return a callable
    that computes x + y.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    recreated = recreate_function("return x + y", "(x, y)", "add")
    assert recreated is not None
    assert recreated(3, 4) == 7, f"Expected 7, got {recreated(3, 4)}"
    assert recreated(10, -5) == 5, f"Expected 5, got {recreated(10, -5)}"

    print("PASS: C14 – recreate_function basic reconstruction")


# --------------------------------------------------------------------------------
# C15 – recreate_function sets function name (State)
# --------------------------------------------------------------------------------

def check_C15_recreate_function_name() -> None:
    """Contracts: C15

    recreate_function must set __name__ on the recreated function.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    recreated = recreate_function("return 42", "()", "my_func")
    assert recreated.__name__ == "my_func", (
        f"Expected __name__ 'my_func', got {recreated.__name__!r}"
    )

    print("PASS: C15 – recreate_function sets __name__")


# --------------------------------------------------------------------------------
# C16 – recreate_function handles MLflow type hints (Behavior)
# --------------------------------------------------------------------------------

def check_C16_recreate_function_mlflow_type_hints() -> None:
    """Contracts: C16

    Function with signature "(trace: mlflow.entities.Trace) -> mlflow.entities.Feedback"
    must be callable with a Trace object and return Feedback.

    # Perspective: native test test_function_with_mlflow_trace_type_hint
    #   creates a full Trace fixture and asserts Feedback value is True
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function
    from mlflow.entities import Feedback, TraceData, TraceInfo, TraceState
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )

    source = (
        "return Feedback(\n"
        "    value=trace.info.trace_id is not None,\n"
        '    rationale=f"Trace ID: {trace.info.trace_id}"\n'
        ")"
    )
    signature = "(trace: mlflow.entities.Trace) -> mlflow.entities.Feedback"
    func_name = "scorer_with_trace_type_hint"

    recreated = recreate_function(source, signature, func_name)

    assert recreated is not None
    assert recreated.__name__ == func_name

    # Create a real Trace object and call the recreated function
    mlflow_exp_location = MlflowExperimentLocation(experiment_id="0")
    trace_location = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT, mlflow_experiment=mlflow_exp_location
    )
    trace_info = TraceInfo(
        trace_id="test_trace_id",
        trace_location=trace_location,
        request_time=1000,
        state=TraceState.OK,
    )
    trace = mlflow.entities.Trace(info=trace_info, data=TraceData())

    result = recreated(trace)
    assert isinstance(result, Feedback), (
        f"Expected Feedback, got {type(result).__name__}"
    )
    assert result.value is True, f"Expected value True, got {result.value!r}"
    assert "test_trace_id" in result.rationale, (
        f"Expected 'test_trace_id' in rationale, got {result.rationale!r}"
    )

    print("PASS: C16 – recreate_function handles MLflow type hints with real Trace")


# --------------------------------------------------------------------------------
# C17 – recreate_function handles syntax errors (Failure)
# --------------------------------------------------------------------------------

def check_C17_recreate_function_syntax_error() -> None:
    """Contracts: C17

    Malformed source code must raise SyntaxError.
    """
    from mlflow.genai.scorers.scorer_utils import recreate_function

    try:
        recreate_function("if x > 0\n    return True", "(x)", "bad")
        assert False, "Expected SyntaxError for malformed source"
    except SyntaxError:
        pass  # Expected

    print("PASS: C17 – recreate_function raises SyntaxError on malformed source")


# --------------------------------------------------------------------------------
# C21 – Scorer.run accepts parameter subsets (Behavior)
#   REPAIRED: added Feedback, list[Feedback], and None return type tests
# --------------------------------------------------------------------------------

def check_C21_Scorer_run_parameter_subsets() -> None:
    """Contracts: C21

    Scorer.run filters kwargs to match the decorated function's signature.
    """
    from mlflow.genai.scorers.base import scorer

    # outputs-only scorer
    s = scorer(lambda outputs: len(outputs))
    result = s.run(outputs="test")
    assert result == 4, f"Expected 4, got {result}"

    # inputs + outputs scorer
    s2 = scorer(lambda inputs, outputs: inputs == outputs)
    result2 = s2.run(inputs="hello", outputs="hello")
    assert result2 is True, f"Expected True, got {result2}"

    # trace scorer
    @scorer
    def all_params(inputs, outputs, expectations, trace):
        return f"{inputs}:{outputs}:{trace is not None}"

    result3 = all_params.run(inputs="in", outputs="out", trace=None)
    assert "in" in result3, f"Expected 'in' in result, got {result3!r}"

    print("PASS: C21 – Scorer.run accepts parameter subsets")


def check_C21b_Scorer_run_feedback_returns() -> None:
    """Contracts: C21b (extension)

    Scorer.run must handle Feedback return types with name rewriting,
    list[Feedback] with name preservation, and None returns.

    # Perspective: native tests:
    #   test_custom_scorer_overwrites_default_feedback_name
    #   test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list
    #   test_custom_scorer_allow_none_return
    """
    from mlflow.genai.scorers.base import scorer
    from mlflow.entities import Feedback

    # 1. Feedback with default name → name rewritten to scorer name
    @scorer
    def my_scorer(inputs, outputs):
        return Feedback(value=42, rationale="rationale")

    fb = my_scorer.run(
        inputs={"question": "What is the capital?"},
        outputs="Paris",
    )
    assert isinstance(fb, Feedback), f"Expected Feedback, got {type(fb).__name__}"
    assert fb.name == "my_scorer", (
        f"Default Feedback name should be overwritten to 'my_scorer', got {fb.name!r}"
    )
    assert fb.value == 42, f"Expected value 42, got {fb.value!r}"

    # 2. Feedback with custom name → name preserved
    @scorer
    def custom_name_scorer(inputs, outputs):
        return Feedback(name="custom_name", value=42, rationale="rationale")

    fb2 = custom_name_scorer.run(
        inputs={"question": "What?"},
        outputs="Answer",
    )
    assert fb2.name == "custom_name", (
        f"Custom Feedback name should be preserved, got {fb2.name!r}"
    )
    assert fb2.value == 42

    # 3. list[Feedback] → names preserved (not overwritten)
    @scorer
    def list_scorer(inputs, outputs):
        return [
            Feedback(name="first", value=1, rationale="one"),
            Feedback(name="second", value=2, rationale="two"),
        ]

    fbs = list_scorer.run(
        inputs={"question": "What?"},
        outputs="Answer",
    )
    assert isinstance(fbs, list), f"Expected list, got {type(fbs).__name__}"
    assert len(fbs) == 2, f"Expected 2 Feedback items, got {len(fbs)}"
    assert fbs[0].name == "first", f"Expected 'first', got {fbs[0].name!r}"
    assert fbs[1].name == "second", f"Expected 'second', got {fbs[1].name!r}"
    assert fbs[0].value == 1
    assert fbs[1].value == 2

    # 4. None return → None returned
    @scorer
    def none_scorer(outputs):
        return None

    result_none = none_scorer.run(outputs="test")
    assert result_none is None, f"Expected None, got {result_none!r}"

    print("PASS: C21b – Scorer.run handles Feedback/list[Feedback]/None returns correctly")


# --------------------------------------------------------------------------------
# C22 – Scorer.run rejects dict return (Failure)
# --------------------------------------------------------------------------------

def check_C22_Scorer_run_rejects_dict() -> None:
    """Contracts: C22

    scorer(lambda: {}).run() must raise MlflowException with exact message
    about unsupported return type.

    # Perspective: native test expects "must return one of int, float, bool, str,"
    """
    from mlflow.genai.scorers.base import scorer
    from mlflow.exceptions import MlflowException

    s = scorer(lambda: {})
    try:
        s.run()
        assert False, "Expected MlflowException for dict return"
    except MlflowException as e:
        msg = str(e)
        # Exact message pattern per native test expectations
        assert "must return one of int, float, bool, str," in msg or \
               "must return one of" in msg, (
            f"Expected return-type error message, got: {msg}"
        )
        # The message should mention the scorer name
        assert s.name in msg or "lambda" in msg.lower(), (
            f"Expected scorer name in error message, got: {msg}"
        )

    print("PASS: C22 – Scorer.run rejects dict return with proper error message")


# --------------------------------------------------------------------------------
# C23 – SerializedScorer validation rejects zero scorer types (Failure)
# --------------------------------------------------------------------------------

def check_C23_SerializedScorer_rejects_zero_types() -> None:
    """Contracts: C23

    SerializedScorer(name='x') without any scorer-type fields must raise
    ValueError during __post_init__ validation.
    """
    from mlflow.genai.scorers.base import SerializedScorer

    try:
        SerializedScorer(name="x")
        assert False, "Expected ValueError for zero scorer types"
    except ValueError as e:
        assert "exactly one" in str(e).lower() or "scorer" in str(e).lower(), (
            f"Expected validation error message, got: {e}"
        )

    print("PASS: C23 – SerializedScorer rejects zero scorer types")


# --------------------------------------------------------------------------------
# C24 – SerializedScorer validation rejects multiple scorer types (Failure)
# --------------------------------------------------------------------------------

def check_C24_SerializedScorer_rejects_multiple_types() -> None:
    """Contracts: C24

    SerializedScorer with both builtin_scorer_class and call_source must raise
    ValueError.
    """
    from mlflow.genai.scorers.base import SerializedScorer

    try:
        SerializedScorer(
            name="x",
            builtin_scorer_class="SomeClass",
            call_source="return 1",
        )
        assert False, "Expected ValueError for multiple scorer types"
    except ValueError as e:
        assert "exactly one" in str(e).lower() or "multiple" in str(e).lower(), (
            f"Expected validation error message, got: {e}"
        )

    # Also test with builtin_scorer_class + instructions_judge_pydantic_data
    try:
        SerializedScorer(
            name="x",
            builtin_scorer_class="SomeClass",
            instructions_judge_pydantic_data={"instructions": "test"},
        )
        assert False, "Expected ValueError for multiple scorer types"
    except ValueError:
        pass  # Expected

    print("PASS: C24 – SerializedScorer rejects multiple scorer types")


# --------------------------------------------------------------------------------
# C25 – Scorer lifecycle status transitions (State)  [NEW]
# --------------------------------------------------------------------------------

def check_C25_Scorer_lifecycle_status_transitions() -> None:
    """Contracts: C25

    Scorer status must follow the lifecycle:
    UNREGISTERED (initial) → STOPPED (after _registered_backend set, sample_rate==0)
    → STARTED (after sample_rate > 0)

    # Perspective: native test test_mlflow_backend_scorer_operations
    #   asserts status == ScorerStatus.UNREGISTERED before register,
    #   status == ScorerStatus.STOPPED after register
    """
    from mlflow.genai.scorers.base import scorer, ScorerStatus, ScorerSamplingConfig

    @scorer
    def _lifecycle_test(outputs) -> bool:
        return len(outputs) > 0

    # Initial state: UNREGISTERED
    assert _lifecycle_test.status == ScorerStatus.UNREGISTERED, (
        f"Expected UNREGISTERED, got {_lifecycle_test.status}"
    )

    # Manually simulate registration by setting _registered_backend
    # (without actually calling register which requires Databricks)
    object.__setattr__(_lifecycle_test, "_registered_backend", "test_backend")

    # After registration backend is set but no sampling config: STOPPED
    assert _lifecycle_test.status == ScorerStatus.STOPPED, (
        f"Expected STOPPED after backend set, got {_lifecycle_test.status}"
    )

    # Set sample_rate > 0: STARTED
    object.__setattr__(_lifecycle_test, "_sampling_config",
                       ScorerSamplingConfig(sample_rate=0.5))

    assert _lifecycle_test.status == ScorerStatus.STARTED, (
        f"Expected STARTED with sample_rate>0, got {_lifecycle_test.status}"
    )

    # Set sample_rate to 0: STOPPED again
    object.__setattr__(_lifecycle_test, "_sampling_config",
                       ScorerSamplingConfig(sample_rate=0.0))

    assert _lifecycle_test.status == ScorerStatus.STOPPED, (
        f"Expected STOPPED with sample_rate==0, got {_lifecycle_test.status}"
    )

    # Unset _registered_backend: back to UNREGISTERED
    object.__setattr__(_lifecycle_test, "_registered_backend", None)

    assert _lifecycle_test.status == ScorerStatus.UNREGISTERED, (
        f"Expected UNREGISTERED after clearing backend, got {_lifecycle_test.status}"
    )

    print("PASS: C25 – Scorer lifecycle: UNREGISTERED → STOPPED → STARTED → STOPPED → UNREGISTERED")


# --------------------------------------------------------------------------------
# C26 – _reconstruct_decorator_scorer error renders code snippet legibly [NEW]
# --------------------------------------------------------------------------------

def check_C26_reconstruct_error_renders_code_snippet() -> None:
    """Contracts: C26

    When _reconstruct_decorator_scorer raises an error outside Databricks,
    the error message must contain a properly formatted code snippet with:
    "Registered scorer code:", "from mlflow.genai import scorer",
    "@scorer", and the function definition.

    # Perspective: native test test_custom_scorer_error_message_renders_code_snippet_legibly
    #   asserts specific code formatting in the error message
    """
    from mlflow.genai.scorers.base import SerializedScorer, Scorer
    from mlflow.exceptions import MlflowException

    serialized = SerializedScorer(
        name="complex_scorer",
        call_source=(
            "if not outputs:\n"
            "    return 0\n"
            "score = 0\n"
            "for word in outputs.split():\n"
            "    if word.isupper():\n"
            "        score += 2\n"
            "    else:\n"
            "        score += 1\n"
            "return score"
        ),
        call_signature="(outputs)",
        original_func_name="complex_scorer",
    )

    try:
        Scorer._reconstruct_decorator_scorer(serialized)
        assert False, "Expected MlflowException"
    except MlflowException as e:
        error_msg = str(e)

        # Verify code snippet structure
        assert "Registered scorer code:" in error_msg, (
            f"Expected 'Registered scorer code:' in error message, got: {error_msg}"
        )
        assert "from mlflow.genai import scorer" in error_msg, (
            f"Expected 'from mlflow.genai import scorer' import in code snippet"
        )
        assert "@scorer" in error_msg, (
            f"Expected '@scorer' decorator in code snippet"
        )
        assert "def complex_scorer(outputs):" in error_msg, (
            f"Expected 'def complex_scorer(outputs):' in code snippet"
        )
        # Verify the original call_source body is included with proper indentation
        assert "if not outputs:" in error_msg, (
            f"Expected 'if not outputs:' in code snippet body"
        )
        assert "return score" in error_msg, (
            f"Expected 'return score' in code snippet body"
        )

    print("PASS: C26 – _reconstruct_decorator_scorer error renders code snippet legibly")


# --------------------------------------------------------------------------------
# Main – execute all checks
# --------------------------------------------------------------------------------

if __name__ == "__main__":
    # AssessmentSourceType checks
    check_C1_constructor_uppercases_and_stores()
    check_C2_str_returns_stored_value()
    check_C4_AI_JUDGE_deprecated_with_FutureWarning()
    check_C5_invalid_source_type_raises_MlflowException()

    # scorer decorator checks
    check_C6_scorer_decorator_name()
    check_C7_scorer_parameterized_usage()
    check_C8_scorer_kind_is_DECORATOR()

    # model_validate reconstruction
    check_C11_model_validate_reconstructs_scorer()

    # reconstruction failure checks
    check_C12_reconstruct_blocked_outside_databricks()
    check_C13_reconstruct_blocked_remote_databricks()
    check_C26_reconstruct_error_renders_code_snippet()

    # recreate_function checks
    check_C14_recreate_function_basic()
    check_C15_recreate_function_name()
    check_C16_recreate_function_mlflow_type_hints()
    check_C17_recreate_function_syntax_error()

    # Scorer.run checks
    check_C21_Scorer_run_parameter_subsets()
    check_C21b_Scorer_run_feedback_returns()
    check_C22_Scorer_run_rejects_dict()

    # SerializedScorer validation checks
    check_C23_SerializedScorer_rejects_zero_types()
    check_C24_SerializedScorer_rejects_multiple_types()

    # Lifecycle check
    check_C25_Scorer_lifecycle_status_transitions()

    print("\nAll behavior checks passed.")
