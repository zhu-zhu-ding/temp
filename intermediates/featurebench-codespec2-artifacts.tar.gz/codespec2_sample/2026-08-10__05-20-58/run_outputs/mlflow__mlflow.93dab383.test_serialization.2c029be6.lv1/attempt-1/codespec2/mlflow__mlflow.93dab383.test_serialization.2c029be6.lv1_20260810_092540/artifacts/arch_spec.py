#!/usr/bin/env python3
"""
Executable architecture spec for AssessmentSourceType and scorer framework.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts:
  C3, C9, C10, C18, C19, C20

Each check_* function is a zero-argument top-level check that exercises
a public entry to its downstream observer and prints PASS: on success.
"""

import warnings
from unittest.mock import patch


# --------------------------------------------------------------------------------
# C19 – scorer importable from mlflow.genai.scorers
# --------------------------------------------------------------------------------

def check_C19_scorer_importable_from_scorers() -> None:
    """Contracts: C19

    L2: mlflow.genai.scorers.__init__ (N21) must export `scorer` from base.py (N8).
    The import must resolve to the same object as mlflow.genai.scorers.base.scorer
    and must produce a functional Scorer when called with a lambda.

    # Perspective: native test `test_scorer.py` line 10:
    #   from mlflow.genai import Scorer, scorer
    """
    from mlflow.genai.scorers import scorer  # noqa: F401

    # Verify the imported object is the scorer function from base
    from mlflow.genai.scorers.base import scorer as _base_scorer

    assert scorer is _base_scorer, (
        "scorer from mlflow.genai.scorers must be the same object "
        "as scorer from mlflow.genai.scorers.base"
    )

    # Reference: native test test_scorer.py lines 57-62 use scorer() directly
    # Prove the imported scorer is functional:
    s = scorer(lambda outputs: len(outputs))
    result = s.run(outputs="test")
    assert result == 4, (
        f"scorer(lambda outputs: len(outputs)).run(outputs='test') expected 4, got {result!r}"
    )
    print("PASS: C19 – scorer importable from mlflow.genai.scorers and functional")


# --------------------------------------------------------------------------------
# C20 – scorer importable from mlflow.genai
# --------------------------------------------------------------------------------

def check_C20_scorer_importable_from_genai() -> None:
    """Contracts: C20

    L2: mlflow.genai.__init__ (N22) re-exports scorer from mlflow.genai.scorers (N21).
    The evidence shows `from mlflow.genai import scorer` is used in tests and
    "scorer" appears in __all__.

    # Perspective: native test test_scorer.py line 10:
    #   from mlflow.genai import Scorer, scorer
    """
    from mlflow.genai import scorer  # noqa: F401

    # Verify it's the same object as the base scorer
    from mlflow.genai.scorers.base import scorer as _base_scorer

    assert scorer is _base_scorer, (
        "scorer from mlflow.genai must be the same object "
        "as scorer from mlflow.genai.scorers.base"
    )

    # Reference: native tests use from mlflow.genai import scorer and call it
    s = scorer(lambda outputs: len(outputs))
    result = s.run(outputs="test")
    assert result == 4, (
        f"scorer(lambda outputs: len(outputs)).run(outputs='test') expected 4, got {result!r}"
    )
    print("PASS: C20 – scorer importable from mlflow.genai and functional")


# --------------------------------------------------------------------------------
# C3 – AssessmentSourceType._standardize called by AssessmentSource.__post_init__
# --------------------------------------------------------------------------------

def check_C3_full_caller_chain_AssessmentSource_to_standardize() -> None:
    """Contracts: C3

    L2: N7 AssessmentSource.__post_init__ -> N6 _standardize (E1).
    This proves the real caller chain by creating an AssessmentSource
    and observing that _standardize was invoked through __post_init__.

    # Perspective: native test test_assessment_source_case_insensitivity
    #   creates AssessmentSource(source_type="human") and asserts source_type=="HUMAN"
    #   -- this exercises the full E1 edge (__post_init__ -> _standardize).
    """
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    # Create via the public entry (AssessmentSource dataclass constructor)
    source = AssessmentSource(source_type="human", source_id="test")
    assert source.source_type == "HUMAN", (
        f"AssessmentSource(source_type='human').source_type expected 'HUMAN', "
        f"got {source.source_type!r}"
    )

    # Verify case-insensitive through the full chain
    source2 = AssessmentSource(source_type="llm_judge", source_id="test")
    assert source2.source_type == "LLM_JUDGE", (
        f"AssessmentSource(source_type='llm_judge').source_type expected 'LLM_JUDGE', "
        f"got {source2.source_type!r}"
    )

    # Spy on _standardize to prove __post_init__ calls it
    original_standardize = AssessmentSourceType._standardize
    call_args = []

    def _spy_standardize(source_type: str) -> str:
        call_args.append(source_type)
        return original_standardize(source_type)

    # Use unittest.mock.patch to spy
    with patch.object(
        AssessmentSourceType, "_standardize", wraps=AssessmentSourceType._standardize
    ) as spy:
        source3 = AssessmentSource(source_type="CODE", source_id="test")
        assert source3.source_type == "CODE"
        spy.assert_called_once_with("CODE")

    print("PASS: C3 – AssessmentSource.__post_init__ calls _standardize with correct argument")


# --------------------------------------------------------------------------------
# C9 – model_dump produces valid SerializedScorer fields and roundtrips
# --------------------------------------------------------------------------------

def check_C9_model_dump_serialized_fields_and_roundtrip() -> None:
    """Contracts: C9

    L2: N10 model_dump -> N11 SerializedScorer dict (E17).
    For a decorator scorer, model_dump() must return a dict containing
    name, call_source, call_signature, original_func_name, mlflow_version,
    and serialization_version.

    Extended: Verify the dump can roundtrip through SerializedScorer(**dump)
    and that the reconstructed scorer can execute.
    """
    from mlflow.genai.scorers.base import scorer, SerializedScorer

    def _test_func(outputs) -> bool:
        return len(outputs) > 0

    sc = scorer(_test_func)
    dump = sc.model_dump()

    # Check required fields are present
    required_keys = {
        "name", "call_source", "call_signature",
        "original_func_name", "mlflow_version", "serialization_version",
    }
    missing = required_keys - set(dump.keys())
    assert not missing, f"model_dump missing keys: {missing}"

    assert dump["name"] == "_test_func", (
        f"Expected name '_test_func', got {dump['name']!r}"
    )
    assert dump["original_func_name"] == "_test_func", (
        f"Expected original_func_name '_test_func', got {dump['original_func_name']!r}"
    )
    assert dump["call_source"] is not None, "call_source must not be None"
    assert dump["call_signature"] is not None, "call_signature must not be None"
    assert isinstance(dump["mlflow_version"], str), "mlflow_version must be a string"
    assert isinstance(dump["serialization_version"], int), "serialization_version must be int"

    # Roundtrip: pass the dumped dict into SerializedScorer to verify it validates
    serialized = SerializedScorer(**dump)
    assert serialized.name == "_test_func"
    assert serialized.call_source == dump["call_source"]
    assert serialized.call_signature == dump["call_signature"]
    assert serialized.original_func_name == "_test_func"

    print("PASS: C9 – model_dump produces valid SerializedScorer fields and roundtrips")


# --------------------------------------------------------------------------------
# C10 – _extract_source_code_info returns source code (dataflow)
# --------------------------------------------------------------------------------

def check_C10_extract_source_code_info_dataflow() -> None:
    """Contracts: C10

    L2: N11 _extract_source_code_info -> N18 extract_function_body (E10).
    Calls self._original_func through extract_function_body and returns
    call_source, call_signature, original_func_name in a dict.
    """
    from mlflow.genai.scorers.base import scorer

    def _adder(x, y):
        return x + y

    sc = scorer(_adder)
    info = sc._extract_source_code_info()

    assert isinstance(info, dict), "_extract_source_code_info must return dict"
    assert "call_source" in info, "missing call_source"
    assert "call_signature" in info, "missing call_signature"
    assert "original_func_name" in info, "missing original_func_name"
    assert info["original_func_name"] == "_adder"
    # call_source should contain the body (return x + y)
    assert "return x + y" in info["call_source"] or "return x+y" in info["call_source"].replace(" ", ""), (
        f"call_source should contain the function body, got {info['call_source']!r}"
    )
    # call_signature should include parameters
    assert "x" in info["call_signature"] and "y" in info["call_signature"], (
        f"call_signature should contain 'x' and 'y', got {info['call_signature']!r}"
    )

    print("PASS: C10 – _extract_source_code_info returns source code info")


# --------------------------------------------------------------------------------
# C18 – extract_function_body extracts function body (dataflow)
# --------------------------------------------------------------------------------

def check_C18_extract_function_body_dataflow() -> None:
    """Contracts: C18

    L2: N18 extract_function_body standalone function.
    Given a function def f(x): return x + 1 (one line), returns
    (body_string, indent_unit) tuple.
    """
    from mlflow.genai.scorers.scorer_utils import extract_function_body

    def _simple_func(x):
        return x + 1

    body, indent = extract_function_body(_simple_func)

    assert isinstance(body, str), "extract_function_body must return str as first element"
    assert isinstance(indent, int), "extract_function_body must return int as second element"
    assert "return x + 1" in body.replace(" ", ""), (
        f"Body should contain 'return x + 1', got {body!r}"
    )
    assert indent > 0, f"Indent unit must be > 0, got {indent}"

    # Test with indented function body
    def _multi_line_func(n):
        total = 0
        for i in range(n):
            total += i
        return total

    body2, indent2 = extract_function_body(_multi_line_func)
    assert "total = 0" in body2, f"Body should contain 'total = 0', got {body2!r}"
    assert "return total" in body2, f"Body should contain 'return total', got {body2!r}"
    assert indent2 > 0

    print("PASS: C18 – extract_function_body extracts function body and indent")


# --------------------------------------------------------------------------------
# Main – execute all checks
# --------------------------------------------------------------------------------

if __name__ == "__main__":
    check_C19_scorer_importable_from_scorers()
    check_C20_scorer_importable_from_genai()
    check_C3_full_caller_chain_AssessmentSource_to_standardize()
    check_C9_model_dump_serialized_fields_and_roundtrip()
    check_C10_extract_source_code_info_dataflow()
    check_C18_extract_function_body_dataflow()
    print("\nAll architecture checks passed.")
