# Semantic IR

## L1. Requirement Obligations

### R1: AssessmentSourceType string validation and standardization
- Type: Behavior
- Statement: The `AssessmentSourceType` class must accept a string in its constructor, convert it to uppercase, validate it against `_SOURCE_TYPES`, and store the standardized value so that `__str__` returns the validated uppercase form.
- Task Evidence: "Parse, validate, and standardize assessment source types with backward compatibility for deprecated values"; Interface Description 2: `__init__` docstring—"automatic validation, case normalization, and deprecation handling."
- Acceptance: `AssessmentSourceType("human")` stores `"HUMAN"`; `AssessmentSourceType("llm_judge")` stores `"LLM_JUDGE"`; `str(AssessmentSourceType("human"))` returns `"HUMAN"`.
- Repository Evidence: `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` (lines 60-71) asserts `source.source_type == "HUMAN"` after `AssessmentSource(source_type="human")`; `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`.
- Uncertainty: None

### R2: AssessmentSourceType deprecation of AI_JUDGE
- Type: Compatibility
- Statement: When the string `"AI_JUDGE"` (case-insensitive) is passed to `AssessmentSourceType`, it must emit a `FutureWarning` and be converted to `"LLM_JUDGE"`.
- Task Evidence: "Maintain backward compatibility while deprecating legacy source types"; Interface Description 2 note: "The legacy 'AI_JUDGE' type is deprecated and automatically converted to 'LLM_JUDGE' with a deprecation warning."
- Acceptance: `AssessmentSource(source_type="AI_JUDGE")` triggers `FutureWarning` and sets `source_type == "LLM_JUDGE"`.
- Repository Evidence: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` (lines 73-78) asserts `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and `source.source_type == "LLM_JUDGE"`.
- Uncertainty: None

### R3: AssessmentSourceType invalid type rejection
- Type: Failure
- Statement: When an unrecognized source type string is passed, `AssessmentSourceType` must raise `MlflowException` with error code `INVALID_PARAMETER_VALUE`.
- Task Evidence: Interface Description 2 `__init__` docstring: "Raises MlflowException: If the provided source_type is not one of the valid source types."
- Acceptance: `AssessmentSource(source_type="ROBOT")` raises `MlflowException` with message containing "Invalid assessment source type".
- Repository Evidence: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` (lines 49-55) asserts `pytest.raises(MlflowException, match="Invalid assessment source type")` for `source_type="ROBOT"`.
- Uncertainty: None

### R4: AssessmentSourceType._standardize classmethod
- Type: Interface
- Statement: `AssessmentSourceType._standardize(source_type: str) -> str` must create a temporary `AssessmentSourceType` instance and return its string representation, thereby performing full validation and deprecation handling in a single call.
- Task Evidence: Interface Description 2 `_standardize` docstring: "creates a temporary AssessmentSourceType instance and converts it to its string representation."
- Acceptance: `AssessmentSourceType._standardize("human") == "HUMAN"`; `AssessmentSourceType._standardize("ai_judge")` emits warning and returns `"LLM_JUDGE"`.
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` (line 78) calls `AssessmentSourceType._standardize(self.source_type)`; reference implementation at `libs/skinny/mlflow/entities/assessment_source.py` line 190: `return str(AssessmentSourceType(source_type))`.
- Uncertainty: None

### R5: AssessmentSourceType._parse static method
- Type: Behavior
- Statement: `AssessmentSourceType._parse(source_type: str) -> str` performs case-insensitive validation by uppercasing the input, checking for `AI_JUDGE` deprecation, validating against `_SOURCE_TYPES`, and returning the standardized string.
- Task Evidence: Interface Description 2 `_parse` docstring: "performs case-insensitive validation and standardization of assessment source type values. It handles deprecated values by converting them to their modern equivalents."
- Acceptance: `AssessmentSourceType._parse("human") == "HUMAN"`; `AssessmentSourceType._parse("AI_JUDGE")` warns and returns `"LLM_JUDGE"`; `AssessmentSourceType._parse("ROBOT")` raises `MlflowException`.
- Repository Evidence: Reference implementation at `libs/skinny/mlflow/entities/assessment_source.py` lines 163-180.
- Uncertainty: None

### R6: scorer decorator creation
- Type: Interface
- Statement: A `scorer` function must exist at `mlflow.genai.scorers.base` that, when called without arguments (as `@scorer`), wraps a function into a `Scorer` subclass with `kind == ScorerKind.DECORATOR`, preserving the original function's signature and name.
- Task Evidence: Interface Description 1: "A decorator to define a custom scorer that can be used in `mlflow.genai.evaluate()`." Returns "A CustomScorer instance."
- Acceptance: `@scorer` applied to `def my_fn(outputs) -> bool: ...` produces a `Scorer` instance `s` where `s.name == "my_fn"`, `s.kind == ScorerKind.DECORATOR`, and `s.run(outputs="value")` executes the original function.
- Repository Evidence: `tests/genai/scorers/test_scorer.py` line 10: `from mlflow.genai import Scorer, scorer`; line 57: `scorer(always_yes)`; line 62: `scorer(name="always_no")(always_yes)`. Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 847-1031.
- Uncertainty: None

### R7: scorer parameterized usage (name, description, aggregations)
- Type: Interface
- Statement: The `scorer` function must accept keyword arguments `name`, `description`, and `aggregations` so that `@scorer(name="custom", description="desc")` works via `functools.partial`.
- Task Evidence: Interface Description 1 Args: "name: The name of the scorer. If not provided, uses the function's name. description: A description of what the scorer evaluates. aggregations: A list of aggregation functions."
- Acceptance: `scorer(name="my_name")(func)` creates a scorer with `name == "my_name"`; `@scorer(name="alt")` works as a decorator.
- Repository Evidence: `tests/genai/scorers/test_scorer.py` line 62: `scorer(name="always_no")(always_yes)`. Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 994-997.
- Uncertainty: None

### R8: scorer serialization via model_dump
- Type: Dataflow
- Statement: A decorator-created `Scorer` must support `model_dump()` to serialize its configuration and extracted source code into a `SerializedScorer` dict via `_extract_source_code_info`.
- Task Evidence: Task mentions "Provide secure serialization that handles source code extraction and reconstruction."
- Acceptance: `scorer_instance.model_dump()` returns a dict containing `call_source`, `call_signature`, `original_func_name`, `name`, `description`, `aggregations`, `mlflow_version`, `serialization_version`.
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.model_dump` (lines 149-184) constructs `SerializedScorer` with source info; `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` creates `SerializedScorer(call_source=..., call_signature=..., original_func_name=...)`.
- Uncertainty: None

### R9: scorer deserialization via model_validate
- Type: Dataflow
- Statement: `Scorer.model_validate()` must accept a `SerializedScorer` or dict containing decorator scorer fields (`call_source`, `call_signature`, `original_func_name`) and call `_reconstruct_decorator_scorer` to rebuild the scorer.
- Task Evidence: Task mentions "Handle dynamic function reconstruction from serialized source code."
- Acceptance: `Scorer.model_validate(SerializedScorer(...))` returns a `Scorer` instance with the same name and behavior.
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.model_validate` (lines 202-298) checks for `call_source` fields and calls `_reconstruct_decorator_scorer`; `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` (line ~290).
- Uncertainty: None

### R10: scorer deserialization security restriction
- Type: Failure
- Statement: `_reconstruct_decorator_scorer` must raise `MlflowException` when called outside a Databricks runtime environment (`is_in_databricks_runtime() == False`), blocking arbitrary code execution via `exec()`.
- Task Evidence: "Secure code execution during scorer deserialization (restricted to controlled environments)." Interface Description 1 note: "registration is only supported in Databricks environments due to security considerations."
- Acceptance: Outside Databricks, `Scorer._reconstruct_decorator_scorer(serialized)` raises `MlflowException` with message "not supported outside of Databricks runtime".
- Repository Evidence: `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri` (lines ~284-295) asserts `pytest.raises(MlflowException, match="Loading custom scorer.*not supported")`. Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 307-338.
- Uncertainty: None

### R11: scorer deserialization with Databricks remote blocking
- Type: Failure
- Statement: When `is_in_databricks_runtime()` is False but `is_databricks_uri(get_tracking_uri())` is True, `_reconstruct_decorator_scorer` must raise `MlflowException` with "via remote access is not supported".
- Task Evidence: Task mentions "Secure code execution during scorer deserialization (restricted to controlled environments)."
- Acceptance: With patched `is_in_databricks_runtime=False` and `is_databricks_uri=True`, raises with "via remote access is not supported".
- Repository Evidence: `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_databricks_remote_access` (lines ~297-312) asserts match on "via remote access is not supported". Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 319-327.
- Uncertainty: None

### R12: scorer run method with supported return types
- Type: Behavior
- Statement: `Scorer.run()` must accept keyword arguments `inputs`, `outputs`, `expectations`, `trace`, filter to the decorated function's signature, invoke `__call__`, and accept return values of `bool`, `int`, `float`, `str`, `Feedback`, `list[Feedback]`, or `None`.
- Task Evidence: Interface Description 1: "The scorer function should return one of: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects."
- Acceptance: A scorer returning `True` produces that result from `run()`; a scorer returning `Feedback(value=42)` produces that feedback with name overwritten if default.
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.run` (lines 374-425) validates return types; `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` (lines ~230-248) tests feedback name overwriting.
- Uncertainty: None

### R13: scorer run rejects unsupported return types
- Type: Failure
- Statement: `Scorer.run()` must raise `MlflowException` when the scorer returns an unsupported type.
- Task Evidence: Interface Description 1 Raises: "MlflowException: If the scorer function returns an unsupported type."
- Acceptance: A scorer returning a `dict` raises `MlflowException` with "must return one of int, float, bool, str, Feedback, or list[Feedback]".
- Repository Evidence: `mlflow/genai/scorers/base.py:Scorer.run` lines 398-409 raise `MlflowException.invalid_parameter_value`.
- Uncertainty: None

### R14: extract_function_body utility
- Type: Behavior
- Statement: `extract_function_body(func)` must return a tuple of `(body_string, indent_unit)` by parsing the function's source with `FunctionBodyExtractor`, stripping the signature and docstring, and dedenting the body.
- Task Evidence: Task mentions "Provide secure serialization that handles source code extraction."
- Acceptance: For `def f(x):\n    return x + 1`, `extract_function_body(f)` returns `("return x + 1", 4)`.
- Repository Evidence: Reference implementation at `libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 62-81; called in `mlflow/genai/scorers/base.py:Scorer._extract_source_code_info` line 192 (in skinny version).
- Uncertainty: None

### R15: recreate_function utility
- Type: Behavior
- Statement: `recreate_function(source: str, signature: str, func_name: str) -> Callable` must reconstruct a callable function from source body, parameter signature, and name by building a function definition string and executing it with MLflow imports in the namespace.
- Task Evidence: Task mentions "Handle dynamic function reconstruction from serialized source code."
- Acceptance: `recreate_function("return x + y", "(x, y)", "add")` returns a callable `f` where `f(3, 4) == 7` and `f.__name__ == "add"`.
- Repository Evidence: `tests/genai/scorers/test_scorer_utils.py::test_simple_function_recreation` (lines 14-23) asserts `recreated(3, 4) == 7`; `test_function_with_mlflow_trace_type_hint` tests type hint handling. Reference implementation at `libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 84-138.
- Uncertainty: None

### R16: scorer import boundary
- Type: Interface
- Statement: The `scorer` function must be importable from `mlflow.genai.scorers` and `mlflow.genai`.
- Task Evidence: Interface Description 1 path `/testbed/mlflow/genai/scorers/base.py`; tests import `from mlflow.genai import Scorer, scorer`.
- Acceptance: `from mlflow.genai.scorers import scorer` succeeds; `from mlflow.genai import scorer` succeeds.
- Repository Evidence: `tests/genai/scorers/test_scorer.py` line 10: `from mlflow.genai import Scorer, scorer`; reference `libs/skinny/mlflow/genai/scorers/__init__.py` line 3: `from mlflow.genai.scorers.base import Scorer, ScorerSamplingConfig, scorer`; `mlflow/genai/__init__.py` line 49: `from mlflow.genai.scorers import Scorer` (but missing `scorer`).
- Uncertainty: The `/testbed/mlflow/genai/scorers/__init__.py` currently imports `Scorer` and `ScorerSamplingConfig` but not `scorer` from base. The `__all__` lists `"scorer"` but there is no import for it. The `mlflow/genai/__init__.py` also lists `"scorer"` in `__all__` but does not import it from scorers.

### R17: SerializedScorer validation
- Type: Behavior
- Statement: `SerializedScorer.__post_init__` must validate that exactly one type of scorer fields is present (builtin, decorator, or instructions judge), raising `ValueError` if zero or multiple field types are present.
- Task Evidence: Task mentions "Ensure type safety and validation across diverse scorer implementations."
- Acceptance: `SerializedScorer(name="x", builtin_scorer_class="C", call_source="s")` raises `ValueError`.
- Repository Evidence: Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 88-108; missing from `/testbed/mlflow/genai/scorers/base.py`.
- Uncertainty: None

### R18: FunctionBodyExtractor AST visitor
- Type: Behavior
- Statement: `FunctionBodyExtractor` must be an `ast.NodeVisitor` subclass that extracts the body of a named function from source code, skipping docstrings and dedenting the result.
- Task Evidence: Needed by `extract_function_body` for source code serialization.
- Acceptance: Given source for `def f(x):\n    """doc"""\n    return x`, extractor returns `"return x"`.
- Repository Evidence: Reference implementation at `libs/skinny/mlflow/genai/scorers/scorer_utils.py` lines 16-58.
- Uncertainty: None

## L2. Functional Design Graph

### N1: AssessmentSource (dataclass)
- Kind: Payload
- Repository Evidence: `mlflow/entities/assessment_source.py` lines 11-99

### N2: AssessmentSourceType (class)
- Kind: Class
- Repository Evidence: `mlflow/entities/assessment_source.py` lines 102-194

### N3: AssessmentSourceType.__init__
- Kind: Method
- Repository Evidence: `mlflow/entities/assessment_source.py` line 160 (in skinny/tracing libs; stub in main)

### N4: AssessmentSourceType.__str__
- Kind: Method
- Repository Evidence: `mlflow/entities/assessment_source.py` line 186 (in skinny/tracing libs; stub in main)

### N5: AssessmentSourceType._parse
- Kind: Method (staticmethod)
- Repository Evidence: `mlflow/entities/assessment_source.py` lines 163-180 (in skinny/tracing libs; stub in main)

### N6: AssessmentSourceType._standardize
- Kind: Method (staticmethod)
- Repository Evidence: `mlflow/entities/assessment_source.py` line 188-190 (in skinny/tracing libs; stub in main)

### N7: AssessmentSource.__post_init__
- Kind: Method
- Repository Evidence: `mlflow/entities/assessment_source.py` lines 76-78

### N8: scorer (function)
- Kind: PublicEntry
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 847-1031 (in skinny/tracing libs; missing in main)

### N9: CustomScorer (inner class of scorer)
- Kind: Class
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 999-1014 (in skinny/tracing libs; missing in main)

### N10: Scorer (BaseModel)
- Kind: Class
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 111-855

### N11: Scorer._extract_source_code_info
- Kind: Method
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 186-199

### N12: Scorer.model_validate
- Kind: Method (classmethod)
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 202-298

### N13: Scorer._reconstruct_decorator_scorer
- Kind: Method (classmethod)
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 301-373

### N14: Scorer.run
- Kind: Method
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 374-425

### N15: Scorer.__call__
- Kind: Method
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 427-522

### N16: Scorer.kind (property)
- Kind: Method
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 523-525

### N17: SerializedScorer
- Kind: Payload
- Repository Evidence: `mlflow/genai/scorers/base.py` lines 62-108

### N18: extract_function_body
- Kind: Function
- Repository Evidence: `mlflow/genai/scorers/scorer_utils.py` lines 62-81 (in skinny/tracing libs; stub in main)

### N19: recreate_function
- Kind: Function
- Repository Evidence: `mlflow/genai/scorers/scorer_utils.py` lines 84-138 (in skinny/tracing libs; missing from main)

### N20: FunctionBodyExtractor
- Kind: Class
- Repository Evidence: `mlflow/genai/scorers/scorer_utils.py` lines 16-58 (in skinny/tracing libs; stub in main)

### N21: scorers __init__.py (module)
- Kind: PublicEntry
- Repository Evidence: `mlflow/genai/scorers/__init__.py`

### N22: genai __init__.py (module)
- Kind: PublicEntry
- Repository Evidence: `mlflow/genai/__init__.py`

### N23: MlflowException
- Kind: Error
- Repository Evidence: `mlflow/exceptions.py`

### N24: FutureWarning (stdlib)
- Kind: Error
- Repository Evidence: Python stdlib `warnings`

### E1: N7 -> N6
- Kind: CALL
- Condition: Always (during `__post_init__`)
- Transfer: `self.source_type` (raw string) -> `AssessmentSourceType._standardize()` -> validated uppercase string stored back to `self.source_type`
- Evidence: `mlflow/entities/assessment_source.py` line 78: `self.source_type = AssessmentSourceType._standardize(self.source_type)`
- Obligations: R1, R2, R3, R5

### E2: N6 -> N3
- Kind: CALL
- Condition: Always
- Transfer: Creates temporary `AssessmentSourceType(source_type)` instance, returns `str()` of it
- Evidence: Reference implementation: `return str(AssessmentSourceType(source_type))`
- Obligations: R4

### E3: N3 -> N5
- Kind: CALL
- Condition: Always (in `__init__`)
- Transfer: `source_type` raw string -> `_parse()` -> validated string stored as `self._source_type`
- Evidence: Reference implementation: `self._source_type = AssessmentSourceType._parse(source_type)`
- Obligations: R1, R2, R3, R5

### E4: N5 -> N24
- Kind: CONTROL
- Condition: `source_type == "AI_JUDGE"` after uppercasing
- Transfer: Issues `warnings.warn("AI_JUDGE is deprecated...", FutureWarning)` then maps to `"LLM_JUDGE"`
- Evidence: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning`
- Obligations: R2, R5

### E5: N5 -> N23
- Kind: CONTROL
- Condition: `source_type not in _SOURCE_TYPES` after uppercasing
- Transfer: Raises `MlflowException` with `INVALID_PARAMETER_VALUE`
- Evidence: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation`
- Obligations: R3, R5

### E6: N4 -> N3 (state)
- Kind: DATA
- Condition: Always
- Transfer: Returns `self._source_type` string
- Evidence: Reference implementation: `return self._source_type`
- Obligations: R1

### E7: N8 -> N9
- Kind: CONTROL
- Condition: `func is not None` (decorator called with function)
- Transfer: Creates `CustomScorer` subclass, sets `_original_func`, `__call__`, `kind`, signature
- Evidence: Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 999-1031
- Obligations: R6, R7

### E8: N8 -> functools.partial
- Kind: CONTROL
- Condition: `func is None` (decorator called with keyword args only)
- Transfer: Returns `functools.partial(scorer, name=name, description=description, aggregations=aggregations)`
- Evidence: Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 994-997
- Obligations: R7

### E9: N9 -> N10
- Kind: DATA
- Condition: Always (CustomScorer inherits from Scorer)
- Transfer: All Scorer fields (`name`, `description`, `aggregations`) plus `_original_func`, `kind`, `__call__`
- Evidence: Reference implementation: `class CustomScorer(Scorer)`
- Obligations: R6, R7

### E10: N11 -> N18
- Kind: CALL
- Condition: Decorator scorer (has `_original_func`)
- Transfer: `self._original_func` -> `extract_function_body()` -> `(call_body, indent_unit)`
- Evidence: `mlflow/genai/scorers/base.py` line 192 (in skinny: `from mlflow.genai.scorers.scorer_utils import extract_function_body`)
- Obligations: R8, R14

### E11: N13 -> N19
- Kind: CALL
- Condition: `is_in_databricks_runtime()` is True
- Transfer: `(serialized.call_source, serialized.call_signature, serialized.original_func_name)` -> `recreate_function()` -> recreated callable
- Evidence: `mlflow/genai/scorers/base.py` line 303 (in skinny: `from mlflow.genai.scorers.scorer_utils import recreate_function`)
- Obligations: R9, R15

### E12: N13 -> N8
- Kind: CALL
- Condition: After `recreate_function` succeeds
- Transfer: Recreated function + serialized name/description/aggregations -> `scorer()` -> new `CustomScorer` instance
- Evidence: Reference implementation at `libs/skinny/mlflow/genai/scorers/base.py` lines 346-354
- Obligations: R9

### E13: N13 -> N23
- Kind: CONTROL
- Condition: `not is_in_databricks_runtime()`
- Transfer: Raises `MlflowException.invalid_parameter_value` with message about security
- Evidence: `tests/genai/scorers/test_scorer.py::test_custom_scorer_loading_blocked_for_non_databricks_uri`
- Obligations: R10, R11

### E14: N12 -> N13
- Kind: CALL
- Condition: Serialized data has `call_source`, `call_signature`, `original_func_name`
- Transfer: `serialized` -> `_reconstruct_decorator_scorer(serialized)` -> `Scorer` instance
- Evidence: `mlflow/genai/scorers/base.py` lines 241-243
- Obligations: R9

### E15: N14 -> N15
- Kind: CALL
- Condition: Always (after filtering parameters to signature)
- Transfer: Filtered kwargs -> `self.__call__()` -> result
- Evidence: `mlflow/genai/scorers/base.py` lines 386-394
- Obligations: R12

### E16: N14 -> N23
- Kind: CONTROL
- Condition: Result is not `(int, float, bool, str, Feedback, list[Feedback], None)`
- Transfer: Raises `MlflowException.invalid_parameter_value`
- Evidence: `mlflow/genai/scorers/base.py` lines 398-409
- Obligations: R13

### E17: N10 -> N11
- Kind: CALL
- Condition: `model_dump()` called on decorator scorer (`self._original_func` exists)
- Transfer: Extracts source code info and builds `SerializedScorer` dict
- Evidence: `mlflow/genai/scorers/base.py` lines 173-183
- Obligations: R8

### E18: N20 -> N18
- Kind: DATA
- Condition: Always (FunctionBodyExtractor is used by extract_function_body)
- Transfer: AST-parsed function body string
- Evidence: `mlflow/genai/scorers/scorer_utils.py` lines 67-81 (in skinny lib)
- Obligations: R18

### E19: N21 -> N8
- Kind: CALL (import)
- Condition: Module import
- Transfer: `scorer` from `mlflow.genai.scorers.base` made available as `mlflow.genai.scorers.scorer`
- Evidence: Reference `libs/skinny/mlflow/genai/scorers/__init__.py` line 3 imports `scorer` from base; `/testbed/mlflow/genai/scorers/__init__.py` has `"scorer"` in `__all__` but missing import.
- Obligations: R16

### E20: N22 -> N21
- Kind: CALL (import)
- Condition: Module import
- Transfer: `from mlflow.genai.scorers import scorer` makes `scorer` available at `mlflow.genai.scorer`
- Evidence: `tests/genai/scorers/test_scorer.py` line 10: `from mlflow.genai import Scorer, scorer`; `mlflow/genai/__init__.py` has `"scorer"` in `__all__` but missing explicit import.
- Obligations: R16

## L3. Verifiable Contracts

### C1: AssessmentSourceType constructor uppercases and stores
- Type: State
- Subject: `AssessmentSourceType.__init__`
- Relation: EQ
- Expected: `AssessmentSourceType("human")._source_type == "HUMAN"`
- Evidence: Task Interface Description 2 + `test_assessment_source_case_insensitivity`
- Observe: FIELD_READ
- Target: `AssessmentSourceType("human")._source_type`
- Obligations: R1
- Graph: N3, E3

### C2: AssessmentSourceType.__str__ returns stored value
- Type: Interface
- Subject: `AssessmentSourceType.__str__`
- Relation: EQ
- Expected: `str(AssessmentSourceType("human")) == "HUMAN"`
- Evidence: Task Interface Description 2 + `test_assessment_source_case_insensitivity`
- Observe: RETURN_VALUE
- Target: `str(AssessmentSourceType("human"))`
- Obligations: R1
- Graph: N4, E6

### C3: AssessmentSourceType._standardize delegates to constructor
- Type: Interface
- Subject: `AssessmentSourceType._standardize`
- Relation: EQ
- Expected: `AssessmentSourceType._standardize("LLM_JUDGE") == "LLM_JUDGE"`
- Evidence: Task Interface Description 2 + `AssessmentSource.__post_init__` calls `_standardize`
- Observe: RETURN_VALUE
- Target: `AssessmentSourceType._standardize("LLM_JUDGE")`
- Obligations: R1, R4
- Graph: N6, E2

### C4: AI_JUDGE deprecated with FutureWarning
- Type: SideEffect
- Subject: `AssessmentSourceType._parse`
- Relation: EQ
- Expected: `warnings.warn("AI_JUDGE is deprecated. Use LLM_JUDGE instead.", FutureWarning)` is emitted and result is `"LLM_JUDGE"`
- Evidence: `test_ai_judge_deprecation_warning` asserts `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated")`
- Observe: SIDE_EFFECT
- Target: `pytest.warns(FutureWarning)` context
- Obligations: R2, R5
- Graph: N5, E4

### C5: Invalid source type raises MlflowException
- Type: Failure
- Subject: `AssessmentSourceType._parse`
- Relation: RAISES
- Expected: `MlflowException` with `INVALID_PARAMETER_VALUE` and message containing "Invalid assessment source type"
- Evidence: `test_assessment_source_type_validation` asserts `pytest.raises(MlflowException, match="Invalid assessment source type")`
- Observe: EXCEPTION
- Target: `AssessmentSource(source_type="ROBOT")`
- Obligations: R3, R5
- Graph: N5, E5, N23

### C6: scorer decorator creates Scorer with correct name
- Type: Interface
- Subject: `scorer` function
- Relation: EQ
- Expected: `scorer(always_yes).name == "always_yes"`
- Evidence: `test_scorer_existence_in_metrics` uses `scorer(always_yes)` and asserts metric contains "always_yes"
- Observe: FIELD_READ
- Target: `scorer(func).name`
- Obligations: R6
- Graph: N8, N9, E7

### C7: scorer parameterized usage via partial
- Type: Interface
- Subject: `scorer` function with keyword args
- Relation: EQ
- Expected: `scorer(name="custom_name")(func).name == "custom_name"`
- Evidence: `test_scorer_name_works` uses `scorer(name="always_no")(always_yes)`
- Observe: FIELD_READ
- Target: `scorer(name="X")(func).name`
- Obligations: R7
- Graph: N8, E8

### C8: scorer creates DECORATOR kind
- Type: State
- Subject: `CustomScorer.kind`
- Relation: EQ
- Expected: `scorer(func).kind == ScorerKind.DECORATOR`
- Evidence: Reference implementation sets `return ScorerKind.DECORATOR` in `CustomScorer.kind` property
- Observe: FIELD_READ
- Target: `scorer(func).kind`
- Obligations: R6
- Graph: N9, E9, N16

### C9: model_dump produces valid SerializedScorer fields
- Type: Dataflow
- Subject: `Scorer.model_dump`
- Relation: CONTAINS
- Expected: Dict contains keys `name`, `call_source`, `call_signature`, `original_func_name`, `mlflow_version`, `serialization_version`
- Evidence: `test_custom_scorer_loading_blocked_for_non_databricks_uri` creates `SerializedScorer(call_source=..., call_signature=..., original_func_name=...)`
- Observe: RETURN_VALUE
- Target: `scorer_instance.model_dump()`
- Obligations: R8
- Graph: N10, E17, N11

### C10: _extract_source_code_info returns source code
- Type: Dataflow
- Subject: `Scorer._extract_source_code_info`
- Relation: CONTAINS
- Expected: Result dict has non-None `call_source`, `call_signature`, `original_func_name` for a decorated function
- Evidence: `extract_function_body` is called on `_original_func`
- Observe: RETURN_VALUE
- Target: `scorer_instance._extract_source_code_info()`
- Obligations: R8, R14
- Graph: N11, E10, N18

### C11: model_validate reconstructs from SerializedScorer
- Type: Behavior
- Subject: `Scorer.model_validate`
- Relation: EQ
- Expected: `Scorer.model_validate(serialized).name == serialized.name` (in Databricks runtime)
- Evidence: `Scorer.model_validate` dispatches to `_reconstruct_decorator_scorer` when decorator fields present
- Observe: RETURN_VALUE
- Target: `Scorer.model_validate(SerializedScorer(...))`
- Obligations: R9
- Graph: N12, E14, N13

### C12: _reconstruct_decorator_scorer blocked outside Databricks
- Type: Failure
- Subject: `Scorer._reconstruct_decorator_scorer`
- Relation: RAISES
- Expected: `MlflowException` with message containing "not supported outside of Databricks runtime"
- Evidence: `test_custom_scorer_loading_blocked_for_non_databricks_uri`
- Observe: EXCEPTION
- Target: `Scorer._reconstruct_decorator_scorer(SerializedScorer(name="x", call_source="return 1", call_signature="()", original_func_name="x"))`
- Obligations: R10
- Graph: N13, E13, N23

### C13: _reconstruct_decorator_scorer blocked for remote Databricks access
- Type: Failure
- Subject: `Scorer._reconstruct_decorator_scorer`
- Relation: RAISES
- Expected: With `is_in_databricks_runtime=False` and `is_databricks_uri=True`, raises with "via remote access is not supported"
- Evidence: `test_custom_scorer_loading_blocked_for_databricks_remote_access`
- Observe: EXCEPTION
- Target: `Scorer._reconstruct_decorator_scorer(serialized)` under mocked conditions
- Obligations: R11
- Graph: N13, E13, N23

### C14: recreate_function basic reconstruction
- Type: Behavior
- Subject: `recreate_function`
- Relation: EQ
- Expected: `recreate_function("return x + y", "(x, y)", "add")(3, 4) == 7`
- Evidence: `test_simple_function_recreation` asserts `recreated(3, 4) == 7`
- Observe: RETURN_VALUE
- Target: `recreate_function("return x + y", "(x, y)", "add")(3, 4)`
- Obligations: R15
- Graph: N19

### C15: recreate_function sets function name
- Type: State
- Subject: `recreate_function` output
- Relation: EQ
- Expected: `recreate_function(source, sig, "my_func").__name__ == "my_func"`
- Evidence: `test_function_name_in_namespace` asserts `recreated.__name__ == func_name`
- Observe: FIELD_READ
- Target: `recreate_function(..., func_name).__name__`
- Obligations: R15
- Graph: N19

### C16: recreate_function handles MLflow type hints
- Type: Behavior
- Subject: `recreate_function`
- Relation: EQ
- Expected: Function with signature `"(trace: mlflow.entities.Trace) -> mlflow.entities.Feedback"` can be called with a `Trace` object
- Evidence: `test_function_with_mlflow_trace_type_hint` asserts `isinstance(result, Feedback)` and `result.value is True`
- Observe: RETURN_VALUE
- Target: `recreate_function(source, sig, name)(trace_object)`
- Obligations: R15
- Graph: N19

### C17: recreate_function handles syntax errors
- Type: Failure
- Subject: `recreate_function`
- Relation: RAISES
- Expected: `SyntaxError` for malformed source code
- Evidence: `test_function_with_syntax_error` asserts `pytest.raises(SyntaxError)`
- Observe: EXCEPTION
- Target: `recreate_function("if x > 0\n    return True", "(x)", "bad")`
- Obligations: R15
- Graph: N19

### C18: extract_function_body extracts function body
- Type: Dataflow
- Subject: `extract_function_body`
- Relation: EQ
- Expected: For `def f(x):\n    return x + 1`, returns `("return x + 1", 4)`
- Evidence: Reference implementation at `libs/skinny/mlflow/genai/scorers/scorer_utils.py`
- Observe: RETURN_VALUE
- Target: `extract_function_body(some_function)`
- Obligations: R14, R18
- Graph: N18, N20, E18

### C19: scorer importable from mlflow.genai.scorers
- Type: Interface
- Subject: `mlflow.genai.scorers.__init__`
- Relation: EQ
- Expected: `from mlflow.genai.scorers import scorer` succeeds and returns the `scorer` function from base.py
- Evidence: `mlflow/genai/scorers/__init__.py` has `"scorer"` in `__all__`; reference skinny lib imports `scorer` from base
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.genai.scorers import scorer`
- Obligations: R16
- Graph: N21, E19

### C20: scorer importable from mlflow.genai
- Type: Interface
- Subject: `mlflow.genai.__init__`
- Relation: EQ
- Expected: `from mlflow.genai import scorer` succeeds (via re-export from scorers)
- Evidence: `tests/genai/scorers/test_scorer.py` line 10: `from mlflow.genai import Scorer, scorer`; `mlflow/genai/__init__.py` has `"scorer"` in `__all__`
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.genai import scorer`
- Obligations: R16
- Graph: N22, E20

### C21: Scorer.run accepts all four parameter subsets
- Type: Behavior
- Subject: `Scorer.run`
- Relation: EQ
- Expected: `scorer(lambda outputs: len(outputs)).run(outputs="test")` returns `4`
- Evidence: `Scorer.run` filters parameters to `__call__` signature
- Observe: RETURN_VALUE
- Target: `scorer_instance.run(outputs="test")`
- Obligations: R12
- Graph: N14, E15

### C22: Scorer.run rejects dict return
- Type: Failure
- Subject: `Scorer.run`
- Relation: RAISES
- Expected: `MlflowException` with "must return one of int, float, bool, str, Feedback, or list[Feedback]"
- Evidence: `mlflow/genai/scorers/base.py` lines 398-409
- Observe: EXCEPTION
- Target: `scorer(lambda: {}).run()`
- Obligations: R13
- Graph: N14, E16, N23

### C23: SerializedScorer validation rejects zero scorer types
- Type: Failure
- Subject: `SerializedScorer.__post_init__`
- Relation: RAISES
- Expected: `ValueError` when no scorer type fields are present
- Evidence: Reference implementation validates `field_count == 0` raises ValueError
- Observe: EXCEPTION
- Target: `SerializedScorer(name="x")`
- Obligations: R17
- Graph: N17

### C24: SerializedScorer validation rejects multiple scorer types
- Type: Failure
- Subject: `SerializedScorer.__post_init__`
- Relation: RAISES
- Expected: `ValueError` when multiple scorer type fields are present
- Evidence: Reference implementation validates `field_count > 1` raises ValueError
- Observe: EXCEPTION
- Target: `SerializedScorer(name="x", builtin_scorer_class="C", call_source="s")`
- Obligations: R17
- Graph: N17
