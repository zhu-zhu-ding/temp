# Semantic IR

## L1. Requirement Obligations

### R1: scorer decorator creates a CustomScorer subclass instance
- Type: Behavior
- Statement: When the `scorer` decorator is applied to a user function (with `func` not None), it must define a `CustomScorer(Scorer)` inner class that stores the original function reference, delegates `__call__` to the original function, and returns `ScorerKind.DECORATOR` from its `kind` property, then instantiate and return that class.
- Task Evidence: "A decorator to define a custom scorer that can be used in `mlflow.genai.evaluate()`." The decorator must wrap a user function into a Scorer instance.
- Acceptance: A user-decorated function like `@scorer \n def my_scorer(outputs): ...` evaluates to a `Scorer` instance whose `__call__` invokes the original function and whose `kind` is `ScorerKind.DECORATOR`.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1012` (CustomScorer class); `/testbed/mlflow/genai/scorers/base.py:1025-1031` (references CustomScorer but class definition is missing); `/testbed/tests/genai/scorers/test_scorer.py:62-74` (tests scorer decorator via `scorer(always_yes)`).
- Uncertainty: None

### R2: scorer decorator supports parameterized usage (func=None)
- Type: Behavior
- Statement: When `scorer` is called with keyword arguments but without a function (i.e., `scorer(name=..., description=..., aggregations=...)`), it must return a `functools.partial` that will apply those arguments when later used as a decorator.
- Task Evidence: The decorator accepts `name`, `description`, `aggregations` as optional keyword arguments.
- Acceptance: `@scorer(name="custom_name")` produces a Scorer instance with `name="custom_name"`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:994-997` (partial return path exists); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:994-997` (same pattern); `/testbed/tests/genai/scorers/test_scorer.py:70-74` (test_scorer_name_works uses `scorer(name="always_no")(always_yes)`).
- Uncertainty: None

### R3: CustomScorer stores original function for serialization
- Type: State
- Statement: The `CustomScorer` must store a reference to the original user function in a private attribute `_original_func` (a Pydantic `PrivateAttr`), enabling downstream serialization via `model_dump` which checks `getattr(self, "_original_func", None)`.
- Task Evidence: The decorator must support serialization of custom scorers via `model_dump`.
- Acceptance: After decoration, `scorer_instance._original_func` is the original function, and `scorer_instance.model_dump()` returns a dict with `call_source`, `call_signature`, and `original_func_name`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:147` (`model_dump` checks `_original_func`); `/testbed/mlflow/genai/scorers/base.py:177-195` (`_extract_source_code_info` uses `self._original_func`); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1001` (`_original_func: Callable[..., Any] | None = PrivateAttr(default=None)`).
- Uncertainty: None

### R4: CustomScorer.__call__ delegates to original function and returns valid types
- Type: Behavior
- Statement: `CustomScorer.__call__` must invoke the stored original function with `*args, **kwargs` and return the result. The `Scorer.run` method (inherited) wraps `__call__` and validates the return type as `int | float | bool | str | Feedback | list[Feedback]` or `None`.
- Task Evidence: "The scorer function should return one of the following: A boolean value, An integer value, A float value, A string value, A single Feedback object, A list of Feedback objects."
- Acceptance: Calling `my_scorer(outputs="hello")` returns the function's result, and if the function returns an invalid type, `run()` raises `MlflowException`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:398-442` (`Scorer.run` validates return types); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1007-1008` (`def __call__(self, *args, **kwargs): return func(*args, **kwargs)`); `/testbed/tests/genai/scorers/test_scorer.py:247-266` (test_scorer_on_genai_evaluate tests various return types).
- Uncertainty: None

### R5: scorer preserves the original function's signature on CustomScorer.__call__
- Type: Interface
- Statement: After creating the `CustomScorer` class, the decorator must update `CustomScorer.__call__.__signature__` to match the original function's signature but prepended with `self` as the first parameter. This ensures MLflow's parameter-passing machinery (which introspects the signature) correctly routes `inputs`, `outputs`, `expectations`, and `trace`.
- Task Evidence: "The scorer function should take in a subset of the following parameters: inputs, outputs, expectations, trace."
- Acceptance: `inspect.signature(my_scorer.__call__)` shows `(self, outputs)` for a scorer defined as `def my_scorer(outputs): ...`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:1018-1025` (signature manipulation exists, references `CustomScorer`); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1014-1020` (same pattern with class defined above).
- Uncertainty: None

### R6: validate_scorers accepts a list and validates each item
- Type: Behavior
- Statement: `validate_scorers(scorers)` must accept a list, validate each item is a `Scorer` instance (or legacy `databricks.rag_eval.evaluation.metrics.Metric` if databricks.agents is installed), and return the filtered list of valid scorers. It must reject non-list inputs and non-scorer items with helpful error messages.
- Task Evidence: "Validate a list of specified scorers and ensure they are valid Scorer instances." The function must handle `Scorer` instances, legacy metrics, and provide hints for common mistakes.
- Acceptance: `validate_scorers([Correctness()])` returns `[Correctness()]`; `validate_scorers("not_a_list")` raises `MlflowException`; `validate_scorers([Correctness])` raises `MlflowException` with hint about class vs instance.
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:11-152` (gap where function should be); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-91` (complete implementation); `/testbed/mlflow/genai/evaluation/base.py:243` (caller: `scorers = validate_scorers(scorers)`).
- Uncertainty: None

### R7: validate_scorers detects and hints for get_all_scorers() nesting mistakes
- Type: Failure
- Statement: If a list item inside `scorers` is itself a list equal to `get_all_scorers()`, `validate_scorers` must raise `MlflowException` with a hint: for a single-item list `[get_all_scorers()]`, hint "Use `scorers=get_all_scorers()`"; for multi-item lists, hint "Use `scorers=[*get_all_scorers(), scorer1, scorer2]`".
- Task Evidence: "The function provides context-aware error messages to help users correct common mistakes."
- Acceptance: `validate_scorers([get_all_scorers(), Correctness()])` raises with hint about using `[*get_all_scorers(), Correctness()]`.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:62-75` (complete hint logic); `/testbed/mlflow/genai/scorers/validation.py` (gap).
- Uncertainty: None

### R8: validate_scorers warns on legacy databricks.rag_eval metrics
- Type: SideEffect
- Statement: If any item is a legacy `databricks.rag_eval.evaluation.metrics.Metric` instance (when databricks.agents is installed), `validate_scorers` must include it in the returned list but log a deprecation warning.
- Task Evidence: "Legacy databricks.rag_eval metrics are supported but deprecated, and will log warnings."
- Acceptance: When databricks.agents is installed, passing a legacy `Metric` instance logs a warning and includes it in the returned list.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:50-58` (legacy metric handling); `/testbed/mlflow/genai/scorers/validation.py:19` (`IS_DBX_AGENTS_INSTALLED` check exists).
- Uncertainty: None

### R9: valid_data_for_builtin_scorers validates DataFrame columns against scorer requirements
- Type: Dataflow
- Statement: `valid_data_for_builtin_scorers(data, builtin_scorers, predict_fn=None)` must inspect the DataFrame columns, map "request"→"inputs" and "response"→"outputs" for legacy schema compatibility, add "outputs" if `predict_fn` is provided, add "inputs" and "outputs" if "trace" column exists, explode "expectations" dictionary keys into "expectations/{key}" columns, then call `validate_columns` on each builtin scorer and log missing columns.
- Task Evidence: "Validate that the required columns are present in the data for running the builtin scorers." The function handles column mapping, predict_fn, trace, and expectations.
- Acceptance: With a DataFrame having "request", "response", and "expectations" columns and `Correctness()` as a scorer, missing "expectations/expected_response" is logged.
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:100-152` (gap); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:94-148` (complete implementation); `/testbed/mlflow/genai/evaluation/base.py:248` (caller); `/testbed/mlflow/genai/optimize/util.py:91` (caller).
- Uncertainty: None

### R10: valid_data_for_builtin_scorers raises on non-dict expectations values
- Type: Failure
- Statement: When the "expectations" column is present, if any value in that column is not a dictionary (and not NaN), `valid_data_for_builtin_scorers` must raise `MlflowException` with message indicating expectations must be a dictionary.
- Task Evidence: "Raised if the 'expectations' column contains non-dictionary values when it should contain dictionaries mapping expectation names to values."
- Acceptance: DataFrame with `expectations` column containing a string value raises `MlflowException`.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:130-136` (validation and raise); `/testbed/mlflow/genai/scorers/validation.py` (gap).
- Uncertainty: None

### R11: valid_data_for_builtin_scorers logs missing columns without raising
- Type: SideEffect
- Statement: When required columns are missing, the function must log an informative message listing each missing column and which scorers require it, but must NOT raise an exception, allowing evaluation to continue with null results.
- Task Evidence: "When required columns are missing, the function logs an informative message but doesn't raise an exception, allowing the evaluation to continue with null results for affected scorers."
- Acceptance: Missing columns result in a `logger.info` message, and the function returns `None`.
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:139-148` (logging); `/testbed/mlflow/genai/scorers/validation.py` (gap).
- Uncertainty: None

### R12: get_all_scorers returns all available builtin scorer instances
- Type: Behavior
- Statement: `get_all_scorers()` must return a list containing instantiated builtin scorers: `ExpectationsGuidelines()`, `Correctness()`, `RelevanceToQuery()`, `RetrievalSufficiency()`, `RetrievalGroundedness()`, `Equivalence()`. When the tracking URI is a Databricks URI, it must additionally include `Safety()` and `RetrievalRelevance()`.
- Task Evidence: "Get all available built-in scorers for MLflow GenAI evaluation." The list includes 6 OSS scorers + 2 Databricks-only scorers.
- Acceptance: `len(get_all_scorers()) == 6` with non-Databricks URI; `len(get_all_scorers()) == 8` with Databricks URI; all items are `Scorer` instances.
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:1536-1600` (gap where function should be); `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1593` (complete implementation); `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-578` (test_get_all_scorers_oss); `/testbed/mlflow/genai/scorers/__init__.py:36,77,93` (exports `get_all_scorers` via lazy import); `/testbed/mlflow/cli/genai_eval_utils.py:121` (caller).
- Uncertainty: None

### R13: get_all_scorers is lazy-imported from scorers package
- Type: Interface
- Statement: `get_all_scorers` must be accessible as `mlflow.genai.scorers.get_all_scorers` via the `__getattr__` lazy import mechanism in `mlflow/genai/scorers/__init__.py`, which delegates to `builtin_scorers.get_all_scorers`.
- Task Evidence: The function is listed in the `_LAZY_IMPORTS` set and `__all__` in `__init__.py`.
- Acceptance: `from mlflow.genai.scorers import get_all_scorers` succeeds and returns the function from `builtin_scorers`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/__init__.py:36` (`_LAZY_IMPORTS` includes `"get_all_scorers"`); `/testbed/mlflow/genai/scorers/__init__.py:48-50` (`__getattr__` delegates to `builtin_scorers`); `/testbed/mlflow/genai/scorers/__init__.py:93` (`__all__` includes `"get_all_scorers"`).
- Uncertainty: None

### R14: validate_aggregations validates aggregation specifiers
- Type: Behavior
- Statement: `validate_aggregations(aggregations)` must check that each aggregation is either a string from the valid set `["min", "max", "mean", "median", "variance", "p90"]` or a callable function. Invalid strings or non-callable non-strings must raise `MlflowException`.
- Task Evidence: Aggregations must be validated as either valid string names or callable functions.
- Acceptance: `validate_aggregations(["mean", "invalid"])` raises `MlflowException`; `validate_aggregations([lambda x: sum(x)/len(x)])` succeeds.
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:154-175` (partial implementation exists, gap before it); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:150-175` (complete implementation).
- Uncertainty: None

### R15: CustomScorer.__call__ signature update enables parameter routing
- Type: Compatibility
- Statement: The `CustomScorer.__call__.__signature__` must be updated using `inspect.signature` to match the original function's parameter names, prefixed with `self`. This ensures the `run()` method's `inspect.signature(self.__call__)` filtering correctly passes only the parameters the scorer expects.
- Task Evidence: The decorator must enable MLflow to pass the correct set of parameters to the scorer.
- Acceptance: A scorer `def my_scorer(outputs, trace): ...` receives only `outputs` and `trace` when called via `run(inputs=..., outputs=..., expectations=..., trace=...)`.
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:410-413` (`run` filters args via `inspect.signature(self.__call__)`); `/testbed/mlflow/genai/scorers/base.py:1021-1025` (signature update code references `CustomScorer`).
- Uncertainty: None

### R16: evaluate() imports validate_scorers and valid_data_for_builtin_scorers from validation module
- Type: Interface
- Statement: The `evaluate` function in `mlflow/genai/evaluation/base.py` must import `validate_scorers` and `valid_data_for_builtin_scorers` from `mlflow.genai.scorers.validation` so they are available at call sites on lines 243 and 248.
- Task Evidence: The call sites exist but the import statement is missing in the main repository, while present in the skinny version.
- Acceptance: Running `from mlflow.genai.evaluation.base import evaluate` does not raise `NameError` when `validate_scorers` is referenced.
- Repository Evidence: `/testbed/mlflow/genai/evaluation/base.py:243` (call site); `/testbed/mlflow/genai/evaluation/base.py:248` (call site); `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21` (import exists in skinny); `/testbed/mlflow/genai/evaluation/base.py:19-20` (no validation import in main).
- Uncertainty: None

### R17: optimize/util.py imports valid_data_for_builtin_scorers from validation module
- Type: Interface
- Statement: The `validate_train_data` function in `mlflow/genai/optimize/util.py` must import `valid_data_for_builtin_scorers` from `mlflow.genai.scorers.validation` so it is available at the call site on line 91.
- Task Evidence: The call site exists but the import statement is missing in the main repository, while present in the skinny version.
- Acceptance: Running `from mlflow.genai.optimize.util import validate_train_data` does not raise `NameError` when `valid_data_for_builtin_scorers` is referenced.
- Repository Evidence: `/testbed/mlflow/genai/optimize/util.py:91` (call site); `/testbed/libs/skinny/mlflow/genai/optimize/util.py:11` (import exists in skinny); `/testbed/mlflow/genai/optimize/util.py:10` (no validation import in main).
- Uncertainty: None

## L2. Functional Design Graph

### N1: scorer (public decorator)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:847-853` (function signature)

### N2: CustomScorer (inner class)
- Kind: Class
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1012` (class definition in skinny); missing in `/testbed/mlflow/genai/scorers/base.py:999` (gap)

### N3: Scorer (base model)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:115-118` (class definition)

### N4: Scorer.run
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:398-442`

### N5: Scorer.model_dump
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:144-172`

### N6: functools.partial
- Kind: External
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:994-997`

### N7: validate_scorers
- Kind: PublicEntry
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-91` (complete implementation); missing in `/testbed/mlflow/genai/scorers/validation.py` (gap)

### N8: valid_data_for_builtin_scorers
- Kind: PublicEntry
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:94-148` (complete implementation); missing in `/testbed/mlflow/genai/scorers/validation.py` (gap)

### N9: validate_aggregations
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:154-175` (partial); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:150-175`

### N10: get_all_scorers
- Kind: PublicEntry
- Repository Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1567-1593`; missing in `/testbed/mlflow/genai/scorers/builtin_scorers.py` (gap)

### N11: BuiltInScorer
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:259-332`

### N12: BuiltInScorer.validate_columns
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:324-326`

### N13: MissingColumnsException
- Kind: Error
- Repository Evidence: `/testbed/mlflow/genai/scorers/builtin_scorers.py:1600-1605`

### N14: evaluate (genai evaluation entry point)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/evaluation/base.py:51-56`

### N15: _run_harness
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/evaluation/base.py:270-271`

### N16: validate_train_data (optimize module)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/optimize/util.py:70-73`

### N17: ScorerKind.DECORATOR
- Kind: State
- Repository Evidence: `/testbed/mlflow/genai/scorers/base.py:29-31`

### N18: scorers __init__ lazy import mechanism
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/scorers/__init__.py:42-51`

### N19: IS_DBX_AGENTS_INSTALLED
- Kind: State
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:20`

### N20: logger (validation module)
- Kind: Observer
- Repository Evidence: `/testbed/mlflow/genai/scorers/validation.py:16`

### E1: scorer (func not None) -> CustomScorer class definition
- Kind: CONTROL
- Condition: `func is not None`
- Transfer: Creates `CustomScorer(Scorer)` inner class with `_original_func`, `__init__`, `__call__`, `kind` property
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1012`
- Obligations: R1, R3, R4

### E2: CustomScorer.__init__ -> stores original func
- Kind: DATA
- Condition: Always during CustomScorer instantiation
- Transfer: `func` → `self._original_func`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1003-1005`; `/testbed/mlflow/genai/scorers/base.py:147` (model_dump checks _original_func)
- Obligations: R3

### E3: CustomScorer.__call__ -> original function
- Kind: CALL
- Condition: Always when scorer is invoked
- Transfer: `(*args, **kwargs)` → original `func` → return value
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1007-1008`
- Obligations: R4

### E4: CustomScorer.kind -> ScorerKind.DECORATOR
- Kind: DATA
- Condition: Always
- Transfer: Returns `ScorerKind.DECORATOR` constant
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1010-1012`
- Obligations: R1

### E5: scorer -> signature update on CustomScorer.__call__
- Kind: DATA
- Condition: After CustomScorer class is defined
- Transfer: Original function's signature (prepended with `self`) → `CustomScorer.__call__.__signature__`
- Evidence: `/testbed/mlflow/genai/scorers/base.py:1018-1025`
- Obligations: R5, R15

### E6: scorer (func is None) -> functools.partial
- Kind: CONTROL
- Condition: `func is None`
- Transfer: Returns `functools.partial(scorer, name=..., description=..., aggregations=...)`
- Evidence: `/testbed/mlflow/genai/scorers/base.py:994-997`
- Obligations: R2

### E7: Scorer.run -> CustomScorer.__call__
- Kind: CALL
- Condition: Always when scorer is evaluated on a row
- Transfer: Filtered kwargs (`inputs`, `outputs`, `expectations`, `trace`) → `self(...)` → return value validated for type
- Evidence: `/testbed/mlflow/genai/scorers/base.py:398-442`
- Obligations: R4, R5, R15

### E8: evaluate -> validate_scorers
- Kind: CALL
- Condition: Always at start of evaluate()
- Transfer: `scorers: list` → `validate_scorers()` → `valid_scorers: list[Scorer]`
- Evidence: `/testbed/mlflow/genai/evaluation/base.py:243`
- Obligations: R6, R7, R8

### E9: evaluate -> valid_data_for_builtin_scorers
- Kind: CALL
- Condition: Always after validate_scorers
- Transfer: `(dataframe, builtin_scorers, predict_fn)` → `valid_data_for_builtin_scorers()` → `None`
- Evidence: `/testbed/mlflow/genai/evaluation/base.py:248`
- Obligations: R9, R10, R11

### E10: valid_data_for_builtin_scorers -> BuiltInScorer.validate_columns
- Kind: CALL
- Condition: For each builtin scorer
- Transfer: `columns: set[str]` → `scorer.validate_columns()` → raises `MissingColumnsException` or passes
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:139-148`
- Obligations: R9, R11

### E11: valid_data_for_builtin_scorers -> column name mapping
- Kind: DATA
- Condition: When "request" or "response" columns exist
- Transfer: "request" → "inputs", "response" → "outputs"
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:105-110`
- Obligations: R9

### E12: valid_data_for_builtin_scorers -> expectations explosion
- Kind: DATA
- Condition: When "expectations" column exists
- Transfer: Each dict key `k` in expectations values → `"expectations/{k}"` column added to set
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:128-137`
- Obligations: R9, R10

### E13: get_all_scorers -> BuiltInScorer subclasses
- Kind: CALL
- Condition: Always
- Transfer: Instantiates and returns list of `[ExpectationsGuidelines(), Correctness(), RelevanceToQuery(), RetrievalSufficiency(), RetrievalGroundedness(), Equivalence()]`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1586-1593`
- Obligations: R12

### E14: get_all_scorers -> Databricks URI check
- Kind: CONTROL
- Condition: `is_databricks_uri(mlflow.get_tracking_uri())`
- Transfer: If True, extends list with `Safety()` and `RetrievalRelevance()`
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1594-1595`
- Obligations: R12

### E15: scorers __init__ __getattr__ -> get_all_scorers
- Kind: CALL
- Condition: When `mlflow.genai.scorers.get_all_scorers` is accessed
- Transfer: Lazily imports `builtin_scorers` module and returns `builtin_scorers.get_all_scorers`
- Evidence: `/testbed/mlflow/genai/scorers/__init__.py:48-51`
- Obligations: R13

### E16: validate_scorers -> IS_DBX_AGENTS_INSTALLED check for legacy metrics
- Kind: CONTROL
- Condition: When a list item is not a `Scorer` instance and `IS_DBX_AGENTS_INSTALLED` is True
- Transfer: Checks if item is `databricks.rag_eval.evaluation.metrics.Metric`; if so, includes with warning
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:50-58`
- Obligations: R8

### E17: validate_scorers -> get_all_scorers() nested list detection
- Kind: CONTROL
- Condition: When a list item `isinstance(scorer, list)` and `scorer == get_all_scorers()`
- Transfer: Raises `MlflowException` with context-aware hints
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:62-75`
- Obligations: R7

### E18: validate_scorers -> class-not-instance detection
- Kind: CONTROL
- Condition: When a list item `isinstance(scorer, type)` and `issubclass(scorer, BuiltInScorer)`
- Transfer: Raises `MlflowException` with hint "passed a scorer class instead of an instance"
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:77-80`
- Obligations: R6

### E19: validate_train_data -> valid_data_for_builtin_scorers
- Kind: CALL
- Condition: Always after validating inputs field
- Transfer: `(train_data, builtin_scorers, predict_fn)` → `valid_data_for_builtin_scorers()` → `None`
- Evidence: `/testbed/mlflow/genai/optimize/util.py:91`
- Obligations: R9, R17

### E20: evaluate module import -> validation module
- Kind: CALL
- Condition: Module load time
- Transfer: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers`
- Evidence: `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21` (import exists in skinny, missing in main)
- Obligations: R16

### E21: optimize/util module import -> validation module
- Kind: CALL
- Condition: Module load time
- Transfer: `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers`
- Evidence: `/testbed/libs/skinny/mlflow/genai/optimize/util.py:11` (import exists in skinny, missing in main)
- Obligations: R17

### E22: validate_aggregations -> _AGGREGATE_FUNCTIONS keys
- Kind: DATA
- Condition: For each aggregation in the list
- Transfer: Checks string aggregation against `_AGGREGATE_FUNCTIONS` keys (min, max, mean, median, variance, p90)
- Evidence: `/testbed/mlflow/genai/scorers/aggregation.py:15-21`; `/testbed/mlflow/genai/scorers/validation.py:164-170`
- Obligations: R14

### E23: valid_data_for_builtin_scorers -> predict_fn / trace column augmentation
- Kind: DATA
- Condition: When `predict_fn is not None` or `"trace"` column exists
- Transfer: Adds synthetic columns ("outputs" for predict_fn; "inputs" and "outputs" for trace)
- Evidence: `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:112-119`
- Obligations: R9

## L3. Verifiable Contracts

### C1: scorer decorator returns CustomScorer instance
- Type: Interface
- Subject: `scorer(func)` return value
- Relation: TYPE_IS
- Expected: `Scorer` instance with `kind == ScorerKind.DECORATOR`
- Evidence: Task (Interface Description 1); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:999-1012`; `/testbed/tests/genai/scorers/test_scorer.py:37-38` (AlwaysYesScorer pattern)
- Observe: RETURN_VALUE
- Target: `isinstance(scorer(always_yes), Scorer)` and `scorer(always_yes).kind == ScorerKind.DECORATOR`
- Obligations: R1
- Graph: N1, N2, N3, N17, E1, E4

### C2: CustomScorer.__call__ invokes original function
- Type: Behavior
- Subject: `CustomScorer` instance call
- Relation: EQ
- Expected: `scorer_instance(outputs="test") == original_func(outputs="test")`
- Evidence: Task (Interface Description 1); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1007-1008`; `/testbed/tests/genai/scorers/test_scorer.py:247-266`
- Observe: RETURN_VALUE
- Target: Result of calling decorated scorer equals result of calling original function with same args
- Obligations: R4
- Graph: N2, E3

### C3: CustomScorer stores _original_func for serialization
- Type: State
- Subject: `CustomScorer._original_func`
- Relation: EQ
- Expected: `scorer_instance._original_func is original_func`
- Evidence: Task; `/testbed/mlflow/genai/scorers/base.py:147` (model_dump checks _original_func); `/testbed/libs/skinny/mlflow/genai/scorers/base.py:1005`
- Observe: FIELD_READ
- Target: `scorer(my_func)._original_func is my_func`
- Obligations: R3
- Graph: N2, E2

### C4: scorer(func=None) returns partial
- Type: Interface
- Subject: `scorer(name="x", description="d")` return value
- Relation: TYPE_IS
- Expected: `functools.partial`
- Evidence: Task; `/testbed/mlflow/genai/scorers/base.py:994-997`; `/testbed/tests/genai/scorers/test_scorer.py:70` (uses `scorer(name="always_no")(always_yes)`)
- Observe: RETURN_VALUE
- Target: `isinstance(scorer(name="test"), functools.partial)`
- Obligations: R2
- Graph: N1, N6, E6

### C5: CustomScorer.__call__.__signature__ matches original function + self
- Type: Interface
- Subject: `CustomScorer.__call__.__signature__`
- Relation: CONTAINS
- Expected: Signature has "self" as first parameter followed by original function's parameters
- Evidence: Task; `/testbed/mlflow/genai/scorers/base.py:1018-1025`; `/testbed/mlflow/genai/scorers/base.py:410-413` (run filters via signature)
- Observe: FIELD_READ
- Target: `inspect.signature(my_scorer.__call__).parameters` contains "self" plus original parameter names
- Obligations: R5, R15
- Graph: N2, E5, E7

### C6: Scorer.run validates return type
- Type: Failure
- Subject: `Scorer.run()` when `__call__` returns invalid type
- Relation: RAISES
- Expected: `MlflowException` with message about valid return types
- Evidence: Task (Interface Description 1); `/testbed/mlflow/genai/scorers/base.py:430-436`; `/testbed/tests/genai/scorers/test_scorer.py:247-266`
- Observe: EXCEPTION
- Target: Calling `run()` on a scorer whose `__call__` returns a dict raises `MlflowException`
- Obligations: R4
- Graph: N4, E7

### C7: validate_scorers rejects non-list input
- Type: Failure
- Subject: `validate_scorers("not_a_list")`
- Relation: RAISES
- Expected: `MlflowException` with message "must be a list of scorers"
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:33-39`
- Observe: EXCEPTION
- Target: `validate_scorers("string")` raises `MlflowException`
- Obligations: R6
- Graph: N7, E8

### C8: validate_scorers returns valid scorers for correct input
- Type: Behavior
- Subject: `validate_scorers([Correctness(), RelevanceToQuery()])`
- Relation: EQ
- Expected: Returns the same list unchanged
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:26-91`
- Observe: RETURN_VALUE
- Target: `validate_scorers([Correctness()]) == [Correctness()]`
- Obligations: R6
- Graph: N7, E8

### C9: validate_scorers detects get_all_scorers() nesting
- Type: Failure
- Subject: `validate_scorers([get_all_scorers()])` with single item
- Relation: RAISES
- Expected: `MlflowException` with hint "Use `scorers=get_all_scorers()`"
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:62-69`
- Observe: EXCEPTION
- Target: Exception message contains "get_all_scorers()" hint
- Obligations: R7
- Graph: N7, N10, E17

### C10: validate_scorers detects class-not-instance mistake
- Type: Failure
- Subject: `validate_scorers([Correctness])` (class, not instance)
- Relation: RAISES
- Expected: `MlflowException` with hint "passed a scorer class instead of an instance"
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:77-80`
- Observe: EXCEPTION
- Target: Exception message contains "class instead of an instance"
- Obligations: R6
- Graph: N7, N11, E18

### C11: validate_scorers accepts empty list
- Type: Behavior
- Subject: `validate_scorers([])`
- Relation: EQ
- Expected: Returns `[]`
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:41-42`
- Observe: RETURN_VALUE
- Target: `validate_scorers([]) == []`
- Obligations: R6
- Graph: N7

### C12: valid_data_for_builtin_scorers maps legacy column names
- Type: Dataflow
- Subject: DataFrame with "request" and "response" columns
- Relation: PRESERVE
- Expected: "request" → "inputs", "response" → "outputs" mapping applied before validation
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:105-110`
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `BuiltInScorer.validate_columns` receives set containing "inputs" not "request"
- Obligations: R9
- Graph: N8, E11

### C13: valid_data_for_builtin_scorers explodes expectations dict keys
- Type: Dataflow
- Subject: DataFrame with `expectations` column containing `{"expected_response": "x", "guidelines": "y"}`
- Relation: CONTAINS
- Expected: Column set includes `"expectations/expected_response"` and `"expectations/guidelines"`
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:128-137`
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `BuiltInScorer.validate_columns` receives set containing exploded expectation keys
- Obligations: R9
- Graph: N8, E12

### C14: valid_data_for_builtin_scorers raises on non-dict expectations
- Type: Failure
- Subject: DataFrame with `expectations` column containing a string value
- Relation: RAISES
- Expected: `MlflowException` with "must be a dictionary" message
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:130-136`
- Observe: EXCEPTION
- Target: Exception message contains "expectations" and "dictionary"
- Obligations: R10
- Graph: N8, E12

### C15: valid_data_for_builtin_scorers logs missing columns
- Type: SideEffect
- Subject: DataFrame missing required columns for a scorer
- Relation: PRESERVE
- Expected: Logger records INFO message listing missing columns and affected scorers; no exception raised
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:139-148`
- Observe: SIDE_EFFECT
- Target: `logger.info` called with message containing missing column names and scorer names
- Obligations: R11
- Graph: N8, N20, E10

### C16: valid_data_for_builtin_scorers adds synthetic columns for predict_fn
- Type: Dataflow
- Subject: `valid_data_for_builtin_scorers(df, scorers, predict_fn=my_fn)`
- Relation: CONTAINS
- Expected: "outputs" is added to the column set before validation
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:112-114`
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: Scorers that require "outputs" do not report it as missing when predict_fn is provided
- Obligations: R9
- Graph: N8, E23

### C17: valid_data_for_builtin_scorers adds synthetic columns for trace
- Type: Dataflow
- Subject: `valid_data_for_builtin_scorers(df, scorers)` with "trace" column present
- Relation: CONTAINS
- Expected: Both "inputs" and "outputs" are added to column set
- Evidence: Task (Interface Description 2); `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:116-119`
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: Scorers requiring "inputs" or "outputs" do not report them as missing
- Obligations: R9
- Graph: N8, E23

### C18: get_all_scorers returns 6 OSS scorers
- Type: Behavior
- Subject: `get_all_scorers()` with non-Databricks tracking URI
- Relation: EQ
- Expected: List of 6 BuiltInScorer instances (`ExpectationsGuidelines`, `Correctness`, `RelevanceToQuery`, `RetrievalSufficiency`, `RetrievalGroundedness`, `Equivalence`)
- Evidence: Task (Interface Description 3); `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1586-1593`; `/testbed/tests/genai/scorers/test_builtin_scorers.py:570-578`
- Observe: RETURN_VALUE
- Target: `len(get_all_scorers()) == 6` and all items `isinstance(Scorer)`
- Obligations: R12
- Graph: N10, E13

### C19: get_all_scorers adds Databricks-only scorers
- Type: Behavior
- Subject: `get_all_scorers()` with Databricks tracking URI
- Relation: CONTAINS
- Expected: List includes `Safety()` and `RetrievalRelevance()` in addition to the 6 OSS scorers
- Evidence: Task (Interface Description 3); `/testbed/libs/skinny/mlflow/genai/scorers/builtin_scorers.py:1594-1595`; `/testbed/tests/genai/scorers/test_builtin_scorers.py:575`
- Observe: RETURN_VALUE
- Target: `len(get_all_scorers()) == 8` with Databricks URI, including Safety and RetrievalRelevance instances
- Obligations: R12
- Graph: N10, E14

### C20: get_all_scorers accessible via scorers package lazy import
- Type: Interface
- Subject: `from mlflow.genai.scorers import get_all_scorers`
- Relation: TYPE_IS
- Expected: `get_all_scorers` is a callable function
- Evidence: Task; `/testbed/mlflow/genai/scorers/__init__.py:36,48-51,93`; `/testbed/tests/genai/scorers/test_builtin_scorers.py:29` (imports get_all_scorers from scorers)
- Observe: IMPORT_BOUNDARY
- Target: `mlflow.genai.scorers.get_all_scorers` resolves to `builtin_scorers.get_all_scorers`
- Obligations: R13
- Graph: N10, N18, E15

### C21: validate_aggregations rejects invalid string
- Type: Failure
- Subject: `validate_aggregations(["invalid_agg"])`
- Relation: RAISES
- Expected: `MlflowException` with message "Invalid aggregation"
- Evidence: Task (implied by validate_aggregations docstring); `/testbed/mlflow/genai/scorers/validation.py:167-170`; `/testbed/mlflow/genai/scorers/aggregation.py:15-21`
- Observe: EXCEPTION
- Target: Exception message contains "Invalid aggregation" and valid options
- Obligations: R14
- Graph: N9, E22

### C22: validate_aggregations accepts callable
- Type: Behavior
- Subject: `validate_aggregations([lambda x: sum(x)/len(x)])`
- Relation: PRESERVE
- Expected: Returns `None` (no exception)
- Evidence: Task; `/testbed/mlflow/genai/scorers/validation.py:171-174`
- Observe: RETURN_VALUE
- Target: No exception raised
- Obligations: R14
- Graph: N9

### C23: evaluate function imports validate_scorers from validation
- Type: Interface
- Subject: `/testbed/mlflow/genai/evaluation/base.py` module imports
- Relation: CALLS
- Expected: Module contains `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers`
- Evidence: `/testbed/mlflow/genai/evaluation/base.py:243,248` (call sites); `/testbed/libs/skinny/mlflow/genai/evaluation/base.py:21` (import exists in skinny)
- Observe: IMPORT_BOUNDARY
- Target: `validate_scorers` and `valid_data_for_builtin_scorers` are bound names in the evaluate module
- Obligations: R16
- Graph: N14, N7, N8, E8, E9, E20

### C24: optimize/util imports valid_data_for_builtin_scorers from validation
- Type: Interface
- Subject: `/testbed/mlflow/genai/optimize/util.py` module imports
- Relation: CALLS
- Expected: Module contains `from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers`
- Evidence: `/testbed/mlflow/genai/optimize/util.py:91` (call site); `/testbed/libs/skinny/mlflow/genai/optimize/util.py:11` (import exists in skinny)
- Observe: IMPORT_BOUNDARY
- Target: `valid_data_for_builtin_scorers` is a bound name in the optimize.util module
- Obligations: R17
- Graph: N16, N8, E19, E21
