# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — L1-L7 lessons on spec compilation patterns
- Semantic IR: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260810_092528/artifacts/semantic_ir.md` — 17 L1 requirements (R1–R17), 24 L3 contracts (C1–C24), L2 design graph with 20 nodes and 24 edges
- Architecture spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260810_092528/artifacts/arch_spec.py` — 10 checks (C1, C4, C5, C12, C13, C16, C17, C20, C23, C24)
- Behavior spec: `/agent-logs/codespec2/mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1_20260810_092528/artifacts/behavior_spec.py` — 14 checks (C2, C3, C6, C7, C8, C9, C10, C11, C14, C15, C18, C19, C21, C22)
- Native tests: `tests/genai/scorers/test_scorer.py` (17 tests), `tests/genai/scorers/test_builtin_scorers.py` (30 tests), `tests/genai/scorers/test_aggregation.py` (5 tests), `tests/genai/scorers/test_serialization.py` (serialization format tests)
- Production code gaps confirmed:
  - `/testbed/mlflow/genai/scorers/base.py:995-1017` — `CustomScorer` class definition missing (blank lines)
  - `/testbed/mlflow/genai/scorers/validation.py:90-140` — `validate_scorers()` and `valid_data_for_builtin_scorers()` bodies missing (blank lines)
  - `/testbed/mlflow/genai/scorers/builtin_scorers.py:1565-1596` — `get_all_scorers()` body missing (blank lines)
  - `/testbed/mlflow/genai/evaluation/base.py:19-20` — missing `from mlflow.genai.scorers.validation import ...`
  - `/testbed/mlflow/genai/optimize/util.py:10` — missing `from mlflow.genai.scorers.validation import ...`
- Reference implementation: `/testbed/libs/skinny/mlflow/genai/scorers/` — complete skinny versions of all modules

## Rubric
- Requirement coverage: 1 — All 24 L3 contracts are referenced; however C16+C17 combined (predict_fn also adds "trace" per E23), `run()` None return, and `run()` Feedback name overwrite are untested.
- Caller binding / call chain: 1 — C23/C24 use `hasattr` which satisfies the IMPORT_BOUNDARY observe type per the skill's L2 guidance, but no arch-spec check exercises the actual E8/E9 call chain (`evaluate()` → `validate_scorers()` / `valid_data_for_builtin_scorers()`).
- Dataflow / state / lifecycle: 1 — C16/C17 independently test predict_fn and trace synthetic columns, but the combined case (predict_fn also adds trace) is untested. C3 checks `model_dump` key presence but not content non-emptiness. C15 checks logger called but not message structure.
- Failure / compatibility boundaries: 1 — C6 only tests one invalid type (dict); C21 tests one invalid string but not all valid strings; non-callable non-string aggregation input (e.g., int) untested; NaN expectations handling untested; empty DataFrame edge case untested.

## Derived Practical Test Perspectives
- P1: `tests/genai/scorers/test_scorer.py::test_custom_scorer_allow_none_return` — Verifies `run()` accepts None as valid return. Generated specs C6 only tests invalid dict return; must add None-return acceptance test.
- P2: `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` — Verifies `run()` mutates Feedback name from DEFAULT to scorer name. No generated spec covers this state mutation.
- P3: `tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss` — Uses `tracking_uri` fixture to parametrize OSS vs Databricks. Generated spec C18 hardcodes `set_tracking_uri("")`; should verify the fixture-driven pattern or at minimum ensure the URI is properly reset.
- P4: `tests/genai/scorers/test_aggregation.py::test_compute_aggregated_metrics` — Validates all six aggregation functions (min, max, mean, median, variance, p90) work end-to-end. The generated spec C21/C22 test one invalid and one callable, but never verify all six valid strings are accepted.
- P5: `tests/genai/scorers/test_serialization.py::test_decorator_scorer_serialization_format` — Checks that `call_source` contains actual source text (not just key presence). Generated spec C3 only checks key presence in `model_dump()`.

## Final Rubric Scores
- Requirement coverage: 1 — All 24 contracts are addressed but several material requirements are missing executable observation (see F2, F4, F6).
- Caller binding / call chain: 1 — IMPORT_BOUNDARY tests use `hasattr` (correct per skill L2), but no arch spec exercises the actual E8/E9 evaluate→validation call chain with real caller execution.
- Dataflow / state / lifecycle: 1 — C16+C17 combined case untested; C15 message structure unverified; C3 model_dump content not validated for non-emptiness.
- Failure / compatibility boundaries: 1 — C6 one invalid type only; C21 one invalid string only; NaN, empty DataFrame, and non-callable non-string aggregation inputs untested.
- P1: 0 — No test for `run()` returning None as valid.
- P2: 0 — No test for `run()` overwriting default Feedback name.
- P3: 2 — C18 and C19 already cover OSS vs Databricks count; C19 handles non-Databricks gracefully.
- P4: 1 — C21 tests one invalid aggregation string but never enumerates the six valid strings.
- P5: 1 — C3 checks `call_source` key presence but not that it contains non-empty source text.

## Findings

### F1: missing_requirement
- Requirement/IR: R9/E23 — `valid_data_for_builtin_scorers` must add "trace" as a synthetic column when `predict_fn is not None`
- Evidence: Skinny reference `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:119` (`if predict_fn is not None: input_columns |= {"trace"}`); IR L3 contracts C16 (adds "outputs") and C17 (adds "inputs"/"outputs" for trace) but neither tests the combined predict_fn+trace case
- Gap: C16 verifies predict_fn adds "outputs" but does not also assert "trace" is added. C17 verifies trace column adds "inputs"/"outputs" but without predict_fn. The combined case where predict_fn is provided AND a scorer requires "trace" is untested.
- Repair: Add a new check (e.g., `check_C16b_predict_fn_adds_trace`) in arch_spec.py that creates a DataFrame with "inputs" only, a scorer requiring "trace", provides predict_fn, and verifies no missing-columns log is emitted.

### F2: weak_constraint
- Requirement/IR: R4/C6 — `Scorer.run()` must validate return types and raise `MlflowException` for invalid types
- Evidence: Native test `tests/genai/scorers/test_scorer.py::test_custom_scorer_allow_none_return` confirms None is valid; the `run()` method (base.py:388-401) checks `isinstance(result, (int, float, bool, str, Assessment, LegacyAssessment))` plus list-of-Assessment and None
- Gap: C6 only tests a single invalid return type (dict/map). It does not verify: (a) that `None` is accepted without raising, (b) that a list of non-Assessment objects raises, (c) that valid types (int, float, bool, str, Feedback) are accepted. A plausible wrong implementation that only checks `isinstance(result, dict)` would pass C6 but fail on other invalid types.
- Repair: Strengthen C6 to parametrize multiple return types: confirm None passes, confirm `list[dict]` raises, confirm `set()` raises, and confirm at least one valid type (e.g., `True`/`42`/`"ok"`) passes without exception.

### F3: missing_requirement
- Requirement/IR: R4 — `Scorer.run()` must allow `None` as a valid return (to represent empty assessment)
- Evidence: Native test `tests/genai/scorers/test_scorer.py::test_custom_scorer_allow_none_return` (line 268) asserts `dummy_scorer.run(...) is None`; skinny reference `base.py:395` comment "Allow None to represent an empty assessment from the scorer"
- Gap: No generated spec covers the None-return path. The C6 check only covers the failure path (dict return).
- Repair: Add a check in behavior_spec.py that creates a `@scorer` function returning `None`, calls `.run()`, and asserts the return is `None` without exception.

### F4: missing_requirement
- Requirement/IR: R4 — `Scorer.run()` must overwrite the default Feedback name (`"feedback"`) with the scorer's own name
- Evidence: Native test `tests/genai/scorers/test_scorer.py::test_custom_scorer_overwrites_default_feedback_name` (line 304) verifies that a Feedback with default name gets renamed; skinny reference `base.py:404-420` shows the `if isinstance(result, Feedback) and result.name == DEFAULT_FEEDBACK_NAME: result.name = self.name` mutation
- Gap: No generated spec covers this state mutation. A scorer that returns `Feedback(value=42)` (no explicit name) must have its name overwritten to the scorer name.
- Repair: Add a check in behavior_spec.py: create `@scorer(name="my_scorer")` returning `Feedback(value=42)`, call `.run()`, assert `result.name == "my_scorer"` and `result.value == 42`.

### F5: weak_constraint
- Requirement/IR: R11/C15 — `valid_data_for_builtin_scorers` must log INFO with structured message containing missing column names and affected scorer names
- Evidence: Skinny reference `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:139-148` formats messages as `\n - \`{col}\` column is required by [{scorers}]` and `\n - \`{key}\` field in \`expectations\` column is required by [{scorers}]`
- Gap: C15 only checks that `logger.info` was called and the message contains "extra_column" or "missing". It does not verify the message contains the scorer name ("needs_extra") or follows the structured multi-line format. A wrong implementation that logs `"missing columns somewhere"` would pass.
- Repair: Strengthen C15 to assert the log message contains both the missing column name AND the scorer name in the same call, and verify the message structure includes backtick-quoted column names.

### F6: missing_requirement
- Requirement/IR: R10/C14 — `valid_data_for_builtin_scorers` must skip `NaN` values in the expectations column
- Evidence: Skinny reference `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:129` (`if pd.isna(value): continue`); IR C14 covers non-dict raising but not NaN skipping
- Gap: C14 tests that string expectations raise, but no test verifies that NaN/None expectations values are silently skipped without error.
- Repair: Add a check in behavior_spec.py that creates a DataFrame with `expectations` column containing `[float('nan'), {"key": "val"}]`, calls `valid_data_for_builtin_scorers`, and asserts no exception is raised.

### F7: weak_constraint
- Requirement/IR: R14/C21/C22 — `validate_aggregations` must reject non-callable non-string items
- Evidence: Skinny reference `/testbed/libs/skinny/mlflow/genai/scorers/validation.py:171-174` (`elif not callable(agg): raise MlflowException...`); C21 tests invalid string, C22 tests callable, but neither tests a non-callable non-string like integer `42`
- Gap: A plausible wrong implementation that only checks `isinstance(agg, str)` and treats everything else as callable would pass both C21 and C22 but fail on `validate_aggregations([42])`.
- Repair: Strengthen C21 or add a new check that passes `[42]` (an integer) to `validate_aggregations` and asserts `MlflowException` is raised with message referencing valid options.

### F8: weak_constraint
- Requirement/IR: R14/C21 — `validate_aggregations` must accept all six valid string names
- Evidence: Native test `tests/genai/scorers/test_aggregation.py::test_compute_aggregated_metrics` uses all six aggregations end-to-end; skinny reference defines valid set as `{"min", "max", "mean", "median", "variance", "p90"}`
- Gap: C21 only tests that one invalid string raises. It never verifies that all six valid strings pass without error. A wrong implementation that has a typo in the valid set (e.g., missing "p90") would not be caught.
- Repair: Strengthen C21 or add a check that passes `["min", "max", "mean", "median", "variance", "p90"]` to `validate_aggregations` and asserts no exception.

### F9: weak_constraint
- Requirement/IR: R3/C3 — `model_dump()` must include non-empty `call_source` with actual source code
- Evidence: Native test `tests/genai/scorers/test_serialization.py::test_decorator_scorer_serialization_format` checks key presence; the `_extract_source_code_info` method in `base.py:177-195` uses `inspect.getsource`
- Gap: C3 checks that `"call_source" in dumped` is True, but does not verify `call_source` is a non-empty string containing the function body. A stub implementation returning `{"call_source": ""}` would pass.
- Repair: Strengthen C3 to assert `isinstance(dumped["call_source"], str) and len(dumped["call_source"]) > 0`.

### F10: weak_constraint
- Requirement/IR: R9/C12 — `valid_data_for_builtin_scorers` must handle empty DataFrames with no columns gracefully
- Evidence: Not covered in native tests; the column mapping logic uses `set(data.columns.tolist())` which returns `set()` for empty DataFrames
- Gap: No test covers the empty-DataFrame edge case. If the column set is empty, all scorers requiring columns should trigger missing-column logging but not crash.
- Repair: Add a check that creates an empty `pd.DataFrame()`, calls `valid_data_for_builtin_scorers` with a scorer requiring "inputs", and verifies it (a) does not raise, and (b) logs missing columns.

### F11: missing_requirement
- Requirement/IR: R9/E23 — `valid_data_for_builtin_scorers` must handle the full predict_fn+trace interaction
- Evidence: Skinny reference has two sequential blocks: `if predict_fn: add "outputs"`, `if "trace": add "inputs","outputs"`, then `if predict_fn: add "trace"`. The second predict_fn block runs regardless of whether "trace" was in the original columns.
- Gap: C16 and C17 are tested independently; C16 verifies predict_fn adds "outputs" and C17 verifies "trace" column adds "inputs"/"outputs". But the combined case where (a) predict_fn is provided, (b) a scorer requires "trace", and (c) the DataFrame has neither "trace" nor "outputs" is untested. The second predict_fn block (`input_columns |= {"trace"}`) should make "trace" available.
- Repair: Add `check_C16b_predict_fn_adds_trace` in arch_spec.py: DataFrame with only "inputs", scorer requiring "trace", predict_fn provided → no missing-columns log.

## Rework Instructions
1. **Strengthen C6** (behavior_spec.py): Parametrize return type validation to cover None (valid), list[dict] (invalid), set() (invalid), and at least one valid primitive (True/42/"ok"). Verify both success and failure paths.
2. **Add new check for None return** (behavior_spec.py): `@scorer` returning `None` → `.run()` → assert result is None without exception.
3. **Add new check for Feedback name overwrite** (behavior_spec.py): `@scorer(name="my_scorer")` returning `Feedback(value=42)` → `.run()` → assert `result.name == "my_scorer"`.
4. **Strengthen C15** (behavior_spec.py): Assert log message contains both the missing column name AND the scorer name, verifying the structured format.
5. **Add NaN expectations test** (behavior_spec.py): DataFrame with NaN + valid dict in expectations → no exception raised.
6. **Strengthen C21** (behavior_spec.py): Test that (a) all six valid aggregation strings pass, and (b) non-callable non-string (e.g., `[42]`) raises.
7. **Strengthen C3** (behavior_spec.py): Assert `call_source` is a non-empty string.
8. **Add predict_fn+trace combined test** (arch_spec.py): DataFrame with only "inputs", scorer requiring "trace", predict_fn provided → verify no missing-column log.
9. **Add empty DataFrame test** (arch_spec.py or behavior_spec.py): Empty DataFrame → scorer requiring "inputs" → logs missing columns, no crash.
