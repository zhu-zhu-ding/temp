#!/usr/bin/env python3
"""Executable behavior spec for MLflow GenAI scorer validation system.

Compiles L3 State, Behavior, Failure, SideEffect, defaults, boundaries, and
compatibility contracts from the semantic IR into runtime assertions. Each check
invokes the public feature chain and asserts its outcome.
"""

import logging
import sys
from unittest.mock import patch

import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_EXIT_CODE = 0


def _pass(msg: str) -> None:
    print(f"PASS: {msg}")


def _fail(msg: str) -> None:
    global _EXIT_CODE
    _EXIT_CODE = 1
    print(f"FAIL: {msg}", file=sys.stderr)


# ---------------------------------------------------------------------------
# C2: CustomScorer.__call__ invokes original function (Behavior)
# ---------------------------------------------------------------------------


def check_C2_call_delegates_to_original() -> None:
    """Verify decorated scorer __call__ returns the original function's result."""
    # Contracts: C2
    from mlflow.genai.scorers import scorer

    def always_yes(inputs, outputs, expectations, trace):
        return "yes"

    instance = scorer(always_yes)

    result = instance(inputs="what?", outputs="answer", expectations={}, trace=None)
    if result != "yes":
        _fail(f"C2: __call__ returned {result!r}, expected 'yes'")
        return

    _pass("C2: decorated __call__ delegates to original function")


# ---------------------------------------------------------------------------
# C3: CustomScorer stores _original_func for serialization (State)
# ---------------------------------------------------------------------------


def check_C3_stores_original_func() -> None:
    """Verify CustomScorer._original_func holds the original function reference."""
    # Contracts: C3
    # Perspective: F9 from review - call_source must be non-empty string
    from mlflow.genai.scorers import scorer

    def my_scorer(outputs):
        return len(outputs)

    instance = scorer(my_scorer)

    # Check _original_func is stored
    if not hasattr(instance, "_original_func"):
        _fail("C3: instance has no _original_func attribute")
        return

    if instance._original_func is not my_scorer:
        _fail("C3: _original_func is not the original function")
        return

    # Verify model_dump includes source info
    dumped = instance.model_dump()
    if "original_func_name" not in dumped:
        _fail("C3: model_dump missing 'original_func_name'")
        return
    if dumped["original_func_name"] != "my_scorer":
        _fail(f"C3: original_func_name is {dumped['original_func_name']}, expected 'my_scorer'")
        return
    if "call_source" not in dumped:
        _fail("C3: model_dump missing 'call_source'")
        return
    if "call_signature" not in dumped:
        _fail("C3: model_dump missing 'call_signature'")
        return

    # F9 repair: assert call_source is a non-empty string with actual source code
    call_source = dumped["call_source"]
    if not isinstance(call_source, str):
        _fail(f"C3: call_source is not a string, got {type(call_source).__name__}")
        return
    if len(call_source) == 0:
        _fail("C3: call_source is an empty string, expected source code content")
        return

    _pass("C3: _original_func stored and model_dump includes non-empty source info")


# ---------------------------------------------------------------------------
# C6: Scorer.run validates return type (Failure) — strengthened per F4
# ---------------------------------------------------------------------------


def check_C6_run_validates_return_type() -> None:
    """Verify Scorer.run raises MlflowException for invalid return types.

    Tests: None (valid), bool (valid), int (valid), str (valid),
           dict (invalid), set (invalid), list[dict] (invalid).
    """
    # Contracts: C6
    # Perspective: F4 from review - parametrize with multiple types
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers import scorer

    # --- Test invalid: dict ---
    @scorer
    def dict_scorer(outputs):
        return {"bad": "type"}

    try:
        dict_scorer.run(outputs="test")
        _fail("C6: run() did not raise for dict return type")
        return
    except MlflowException as exc:
        msg = str(exc).lower()
        if "int" not in msg and "float" not in msg and "bool" not in msg:
            _fail(f"C6: exception message does not mention valid types: {exc}")
            return

    # --- Test invalid: set ---
    @scorer
    def set_scorer(outputs):
        return {1, 2, 3}

    try:
        set_scorer.run(outputs="test")
        _fail("C6: run() did not raise for set return type")
        return
    except MlflowException:
        pass  # expected

    # --- Test invalid: list of non-Feedback (list[dict]) ---
    @scorer
    def list_dict_scorer(outputs):
        return [{"a": 1}, {"b": 2}]

    try:
        list_dict_scorer.run(outputs="test")
        _fail("C6: run() did not raise for list[dict] return type")
        return
    except MlflowException:
        pass  # expected

    # --- Test valid: bool ---
    @scorer
    def bool_scorer(outputs):
        return True

    try:
        result = bool_scorer.run(outputs="test")
    except MlflowException as exc:
        _fail(f"C6: run() incorrectly raised for bool return: {exc}")
        return

    # --- Test valid: int ---
    @scorer
    def int_scorer(outputs):
        return 42

    try:
        result = int_scorer.run(outputs="test")
    except MlflowException as exc:
        _fail(f"C6: run() incorrectly raised for int return: {exc}")
        return

    # --- Test valid: str ---
    @scorer
    def str_scorer(outputs):
        return "ok"

    try:
        result = str_scorer.run(outputs="test")
    except MlflowException as exc:
        _fail(f"C6: run() incorrectly raised for str return: {exc}")
        return

    _pass("C6: Scorer.run correctly validates multiple return types")


# ---------------------------------------------------------------------------
# C6b: Scorer.run accepts None as valid return (Behavior)
# Reference: F2/P1 from review
# ---------------------------------------------------------------------------


def check_C6b_run_accepts_none_return() -> None:
    """Verify Scorer.run accepts None as a valid return value."""
    # Contracts: C6 (extended)
    # Perspective: P1 from native test test_custom_scorer_allow_none_return
    from mlflow.genai.scorers import scorer

    @scorer
    def none_scorer(outputs):
        return None

    result = none_scorer.run(outputs="test")
    if result is not None:
        _fail(f"C6b: run() with None return expected None, got {result!r}")
        return

    _pass("C6b: Scorer.run accepts None as valid return")


# ---------------------------------------------------------------------------
# C6c: Scorer.run overwrites default Feedback name with scorer name (State)
# Reference: F3/P2 from review
# ---------------------------------------------------------------------------


def check_C6c_run_overwrites_feedback_name() -> None:
    """Verify Scorer.run overwrites default Feedback name with the scorer's name."""
    # Contracts: C6 (extended)
    # Perspective: P2 from native test test_custom_scorer_overwrites_default_feedback_name
    from mlflow.entities import Feedback
    from mlflow.genai.scorers import scorer

    @scorer(name="my_scorer")
    def feedback_scorer(outputs):
        return Feedback(value=42)

    result = feedback_scorer.run(outputs="test")
    if result.name != "my_scorer":
        _fail(f"C6c: Feedback name is '{result.name}', expected 'my_scorer'")
        return

    # Also verify that an explicitly named Feedback is NOT overwritten
    @scorer(name="my_scorer2")
    def named_feedback_scorer(outputs):
        return Feedback(value=99, name="custom_name")

    result2 = named_feedback_scorer.run(outputs="test")
    if result2.name != "custom_name":
        _fail(f"C6c: Explicit Feedback name was overwritten: '{result2.name}'")
        return

    _pass("C6c: Scorer.run overwrites default Feedback name with scorer name")


# ---------------------------------------------------------------------------
# C7: validate_scorers rejects non-list input (Failure)
# ---------------------------------------------------------------------------


def check_C7_validate_scorers_rejects_non_list() -> None:
    """Verify validate_scorers raises MlflowException for non-list input."""
    # Contracts: C7
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.validation import validate_scorers

    try:
        validate_scorers("not_a_list")
        _fail("C7: validate_scorers did not raise for string input")
        return
    except MlflowException as exc:
        msg = str(exc).lower()
        if "list" not in msg:
            _fail(f"C7: exception message does not mention 'list': {exc}")
            return

    _pass("C7: validate_scorers rejects non-list input with helpful message")


# ---------------------------------------------------------------------------
# C8: validate_scorers returns valid scorers for correct input (Behavior)
# ---------------------------------------------------------------------------


def check_C8_validate_scorers_valid_input() -> None:
    """Verify validate_scorers returns the same list for valid scorer instances."""
    # Contracts: C8
    from mlflow.genai.scorers import scorer
    from mlflow.genai.scorers.validation import validate_scorers

    @scorer
    def scorer_one(outputs):
        return True

    @scorer
    def scorer_two(outputs):
        return False

    result = validate_scorers([scorer_one, scorer_two])
    if not isinstance(result, list):
        _fail(f"C8: returned {type(result).__name__}, expected list")
        return
    if len(result) != 2:
        _fail(f"C8: list length is {len(result)}, expected 2")
        return

    _pass("C8: validate_scorers returns valid scorer instances unchanged")


# ---------------------------------------------------------------------------
# C9: validate_scorers detects get_all_scorers() nesting (Failure)
# ---------------------------------------------------------------------------


def check_C9_validate_scorers_detects_nesting() -> None:
    """Verify validate_scorers raises when get_all_scorers() is nested in a list."""
    # Contracts: C9
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers import get_all_scorers
    from mlflow.genai.scorers.validation import validate_scorers

    try:
        validate_scorers([get_all_scorers()])
        _fail("C9: validate_scorers did not raise for nested get_all_scorers()")
        return
    except MlflowException as exc:
        msg = str(exc).lower()
        if "get_all_scorers" not in msg:
            _fail(f"C9: exception message does not mention get_all_scorers: {exc}")
            return

    _pass("C9: validate_scorers detects get_all_scorers() nesting with hint")


# ---------------------------------------------------------------------------
# C10: validate_scorers detects class-not-instance mistake (Failure)
# ---------------------------------------------------------------------------


def check_C10_validate_scorers_detects_class_not_instance() -> None:
    """Verify validate_scorers raises when a scorer class is passed instead of instance."""
    # Contracts: C10
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import validate_scorers

    try:
        validate_scorers([BuiltInScorer])
        _fail("C10: validate_scorers did not raise for class-not-instance")
        return
    except MlflowException as exc:
        msg = str(exc).lower()
        if "class" not in msg or "instance" not in msg:
            _fail(f"C10: exception message missing class/instance hint: {exc}")
            return

    _pass("C10: validate_scorers detects class instead of instance with hint")


# ---------------------------------------------------------------------------
# C11: validate_scorers accepts empty list (Behavior)
# ---------------------------------------------------------------------------


def check_C11_validate_scorers_empty_list() -> None:
    """Verify validate_scorers returns empty list for empty input."""
    # Contracts: C11
    from mlflow.genai.scorers.validation import validate_scorers

    result = validate_scorers([])
    if result != []:
        _fail(f"C11: validate_scorers([]) returned {result!r}, expected []")
        return

    _pass("C11: validate_scorers accepts and returns empty list")


# ---------------------------------------------------------------------------
# C14: valid_data_for_builtin_scorers raises on non-dict expectations (Failure)
# ---------------------------------------------------------------------------


def check_C14_non_dict_expectations_raises() -> None:
    """Verify valid_data raises MlflowException when expectations is not a dict."""
    # Contracts: C14
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class AnyScorer(BuiltInScorer):
        name: str = "any_scorer"
        required_columns: set[str] = {"inputs"}

        @property
        def instructions(self) -> str:
            return "test"

    df = pd.DataFrame({
        "inputs": ["test"],
        "expectations": ["not_a_dict"],  # string, not dict
    })

    try:
        valid_data_for_builtin_scorers(df, [AnyScorer()])
        _fail("C14: did not raise for non-dict expectations value")
        return
    except MlflowException as exc:
        msg = str(exc).lower()
        if "expectations" not in msg or "dictionary" not in msg:
            _fail(f"C14: exception message missing expectations/dictionary: {exc}")
            return

    _pass("C14: valid_data raises MlflowException for non-dict expectations")


# ---------------------------------------------------------------------------
# C14b: valid_data_for_builtin_scorers skips NaN expectations (Boundary)
# Reference: F6 from review
# ---------------------------------------------------------------------------


def check_C14b_nan_expectations_skipped() -> None:
    """Verify NaN values in expectations column are silently skipped."""
    # Contracts: C14 (extended)
    # Perspective: F6 from review - NaN expectations should not raise
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class AnyScorer(BuiltInScorer):
        name: str = "any_scorer"
        required_columns: set[str] = {"inputs"}

        @property
        def instructions(self) -> str:
            return "test"

    # DataFrame with NaN + valid dict in expectations
    df = pd.DataFrame({
        "inputs": ["test", "test2"],
        "expectations": [float('nan'), {"key": "val"}],
    })

    # Must not raise
    valid_data_for_builtin_scorers(df, [AnyScorer()])

    _pass("C14b: NaN expectations values are silently skipped")


# ---------------------------------------------------------------------------
# C15: valid_data_for_builtin_scorers logs missing columns (SideEffect) — strengthened per F5
# ---------------------------------------------------------------------------


def check_C15_logs_missing_columns() -> None:
    """Verify valid_data logs INFO about missing columns without raising.

    Strengthened per F5: assert log message contains both the missing column
    name AND the scorer name in the structured format.
    """
    # Contracts: C15
    # Perspective: F5 from review - verify message structure
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class NeedsExtraScorer(BuiltInScorer):
        name: str = "needs_extra"
        required_columns: set[str] = {"inputs", "extra_column"}

        @property
        def instructions(self) -> str:
            return "test"

    df = pd.DataFrame({"inputs": ["test"]})  # missing 'extra_column'

    with patch("logging.Logger.info") as mock_info:
        valid_data_for_builtin_scorers(df, [NeedsExtraScorer()])
        if not mock_info.called:
            _fail("C15: logger.info was not called for missing columns")
            return
        # Check message content — must contain both column name and scorer name
        call_args = mock_info.call_args
        if call_args:
            msg = str(call_args[0][0])
            msg_lower = msg.lower()
            # Verify the message mentions the missing column
            if "extra_column" not in msg:
                _fail(f"C15: log message does not contain missing column name: {msg}")
                return
            # Verify the message mentions the scorer name
            if "needs_extra" not in msg:
                _fail(f"C15: log message does not contain scorer name: {msg}")
                return
            # Verify structured format — should have backtick-quoted column names
            if "`extra_column`" not in msg:
                _fail(f"C15: log message missing backtick-quoted column: {msg}")
                return

    _pass("C15: valid_data logs missing columns with scorer name in structured format")


# ---------------------------------------------------------------------------
# C18: get_all_scorers returns 6 OSS scorers (Behavior)
# ---------------------------------------------------------------------------


def check_C18_get_all_scorers_oss() -> None:
    """Verify get_all_scorers returns exactly 6 scorers in OSS mode."""
    # Contracts: C18
    import mlflow
    from mlflow.genai.scorers import Scorer, get_all_scorers

    # Ensure we are NOT on Databricks URI
    mlflow.set_tracking_uri("")

    scorers = get_all_scorers()

    if not isinstance(scorers, list):
        _fail(f"C18: get_all_scorers() returned {type(scorers).__name__}, expected list")
        return

    # Should have exactly 6 OSS scorers
    if len(scorers) != 6:
        _fail(f"C18: expected 6 OSS scorers, got {len(scorers)}")
        return

    # All should be Scorer instances
    for s in scorers:
        if not isinstance(s, Scorer):
            _fail(f"C18: item {s} is not a Scorer instance")
            return

    # Verify expected scorer names are present
    names = {s.name for s in scorers}
    expected = {
        "expectations_guidelines",
        "correctness",
        "relevance_to_query",
        "retrieval_sufficiency",
        "retrieval_groundedness",
        "equivalence",
    }
    missing = expected - names
    if missing:
        _fail(f"C18: missing expected scorers: {missing}")
        return

    _pass("C18: get_all_scorers returns 6 OSS BuiltInScorer instances")


# ---------------------------------------------------------------------------
# C19: get_all_scorers adds Databricks-only scorers (Behavior)
# ---------------------------------------------------------------------------


def check_C19_get_all_scorers_databricks() -> None:
    """Verify get_all_scorers includes Safety and RetrievalRelevance on Databricks."""
    # Contracts: C19
    import mlflow
    from mlflow.genai.scorers import Scorer, get_all_scorers
    from mlflow.utils.uri import is_databricks_uri

    original_uri = mlflow.get_tracking_uri()

    try:
        mlflow.set_tracking_uri("databricks")
        if is_databricks_uri(mlflow.get_tracking_uri()):
            scorers = get_all_scorers()
            if len(scorers) != 8:
                _fail(f"C19: expected 8 scorers on Databricks, got {len(scorers)}")
                return

            names = {s.name for s in scorers}
            if "safety" not in names:
                _fail("C19: Safety scorer missing from Databricks result")
                return
            if "retrieval_relevance" not in names:
                _fail("C19: RetrievalRelevance scorer missing from Databricks result")
                return

            _pass("C19: get_all_scorers adds Safety and RetrievalRelevance on Databricks")
        else:
            _pass("C19: SKIPPED - not on Databricks URI")
    finally:
        mlflow.set_tracking_uri(original_uri)


# ---------------------------------------------------------------------------
# C21: validate_aggregations rejects invalid string AND non-callable non-string (Failure)
# Strengthened per F7 and F8
# ---------------------------------------------------------------------------


def check_C21_validate_aggregations_invalid_string() -> None:
    """Verify validate_aggregations raises for invalid aggregation name."""
    # Contracts: C21
    # Perspective: F7 from review - also test non-callable non-string like int
    from mlflow.exceptions import MlflowException
    from mlflow.genai.scorers.validation import validate_aggregations

    # --- Test invalid string ---
    try:
        validate_aggregations(["not_a_valid_aggregation"])
        _fail("C21: validate_aggregations did not raise for invalid string")
        return
    except MlflowException as exc:
        msg = str(exc).lower()
        if "invalid aggregation" not in msg:
            _fail(f"C21: exception message missing 'invalid aggregation': {exc}")
            return
        # Should also mention valid options
        if "min" not in msg and "max" not in msg:
            _fail(f"C21: exception message does not list valid options: {exc}")
            return

    # --- Test non-callable non-string: integer 42 (F7 repair) ---
    try:
        validate_aggregations([42])
        _fail("C21: validate_aggregations did not raise for non-callable non-string (int)")
        return
    except MlflowException as exc:
        msg = str(exc).lower()
        if "aggregation" not in msg:
            _fail(f"C21: exception message missing 'aggregation' for int input: {exc}")
            return

    _pass("C21: validate_aggregations rejects invalid string and non-callable non-string")


# ---------------------------------------------------------------------------
# C21b: validate_aggregations accepts all six valid aggregation strings (Behavior)
# Reference: F8 from review
# ---------------------------------------------------------------------------


def check_C21b_all_valid_aggregation_strings() -> None:
    """Verify all six valid aggregation strings are accepted without error."""
    # Contracts: C21 (extended)
    # Perspective: F8 from review - enumerate all valid strings
    from mlflow.genai.scorers.validation import validate_aggregations

    valid_aggregations = ["min", "max", "mean", "median", "variance", "p90"]

    try:
        validate_aggregations(valid_aggregations)
    except Exception as exc:
        _fail(f"C21b: validate_aggregations raised for valid aggregation strings: {exc}")
        return

    _pass("C21b: all six valid aggregation strings accepted")


# ---------------------------------------------------------------------------
# C22: validate_aggregations accepts callable (Behavior)
# ---------------------------------------------------------------------------


def check_C22_validate_aggregations_callable() -> None:
    """Verify validate_aggregations accepts callable aggregations without error."""
    # Contracts: C22
    from mlflow.genai.scorers.validation import validate_aggregations

    try:
        validate_aggregations([lambda x: sum(x) / len(x)])
    except Exception as exc:
        _fail(f"C22: validate_aggregations raised for callable: {exc}")
        return

    _pass("C22: validate_aggregations accepts callable aggregation functions")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    checks = [
        check_C2_call_delegates_to_original,
        check_C3_stores_original_func,
        check_C6_run_validates_return_type,
        check_C6b_run_accepts_none_return,
        check_C6c_run_overwrites_feedback_name,
        check_C7_validate_scorers_rejects_non_list,
        check_C8_validate_scorers_valid_input,
        check_C9_validate_scorers_detects_nesting,
        check_C10_validate_scorers_detects_class_not_instance,
        check_C11_validate_scorers_empty_list,
        check_C14_non_dict_expectations_raises,
        check_C14b_nan_expectations_skipped,
        check_C15_logs_missing_columns,
        check_C18_get_all_scorers_oss,
        check_C19_get_all_scorers_databricks,
        check_C21_validate_aggregations_invalid_string,
        check_C21b_all_valid_aggregation_strings,
        check_C22_validate_aggregations_callable,
    ]

    for check in checks:
        try:
            check()
        except Exception as exc:
            _fail(f"{check.__name__}: {type(exc).__name__}: {exc}")

    sys.exit(_EXIT_CODE)
