#!/usr/bin/env python3
"""Executable architecture spec for MLflow GenAI scorer validation system.

Compiles L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts from the
semantic IR into runtime checks. Each check traces a public entry point through
real callers and helpers to an observer, confirming connectivity, data routing,
and import boundaries.
"""

import functools
import inspect
import logging
import sys
from unittest.mock import patch

import pandas as pd

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_EXIT_CODE = 0


def _pass(msg: str) -> None:
    print(f"PASS: {msg}")


def _fail(msg: str) -> None:
    global _EXIT_CODE
    _EXIT_CODE = 1
    print(f"FAIL: {msg}", file=sys.stderr)


def _make_eval_df(
    columns: list[str] | None = None,
    expect_col: str | None = None,
    expect_val: dict | None = None,
) -> pd.DataFrame:
    """Create a minimal DataFrame for validation tests."""
    data: dict[str, list] = {}
    if columns:
        for c in columns:
            data[c] = ["placeholder"]
    if expect_col:
        data[expect_col] = [expect_val if expect_val is not None else {"key": "val"}]
    if not data:
        data["inputs"] = ["test"]
    return pd.DataFrame(data)


# ---------------------------------------------------------------------------
# C1: scorer decorator returns CustomScorer instance (Interface)
# ---------------------------------------------------------------------------


def check_C1_scorer_returns_custom_scorer() -> None:
    """Verify @scorer produces a Scorer instance with ScorerKind.DECORATOR."""
    # Contracts: C1
    from mlflow.genai.scorers import Scorer, scorer
    from mlflow.genai.scorers.base import ScorerKind

    def my_test_scorer(outputs):
        return outputs == "correct"

    instance = scorer(my_test_scorer)

    # Verify it is a Scorer instance
    if not isinstance(instance, Scorer):
        _fail("C1: scorer(func) did not return a Scorer instance")
        return

    # Verify kind is DECORATOR
    if instance.kind != ScorerKind.DECORATOR:
        _fail(
            f"C1: scorer(func).kind is {instance.kind}, expected {ScorerKind.DECORATOR}"
        )
        return

    _pass("C1: scorer(func) returns Scorer instance with kind=DECORATOR")


# ---------------------------------------------------------------------------
# C4: scorer(func=None) returns functools.partial (Interface)
# ---------------------------------------------------------------------------


def check_C4_scorer_param_partial() -> None:
    """Verify parameterized scorer (func=None) returns a functools.partial."""
    # Contracts: C4
    from mlflow.genai.scorers import scorer

    result = scorer(name="my_custom_name", description="A custom description")

    if not isinstance(result, functools.partial):
        _fail(
            f"C4: scorer(name=...) returned {type(result).__name__}, "
            f"expected functools.partial"
        )
        return

    # Verify the partial wraps scorer with correct kwargs
    if result.keywords.get("name") != "my_custom_name":
        _fail("C4: partial does not carry name keyword")
        return
    if result.keywords.get("description") != "A custom description":
        _fail("C4: partial does not carry description keyword")
        return

    _pass("C4: scorer(name=...) returns functools.partial with correct kwargs")


# ---------------------------------------------------------------------------
# C5: CustomScorer.__call__.__signature__ preserves original + self (Interface)
# ---------------------------------------------------------------------------


def check_C5_signature_preservation() -> None:
    """Verify decorated scorer __call__ signature has 'self' + original params."""
    # Contracts: C5
    import inspect

    from mlflow.genai.scorers import scorer

    def my_scorer(inputs, outputs, expectations, trace):
        return 0.0

    instance = scorer(my_scorer)

    sig = inspect.signature(instance.__call__)
    param_names = list(sig.parameters.keys())

    # First parameter must be 'self'
    if param_names[0] != "self":
        _fail(
            f"C5: first param is '{param_names[0]}', expected 'self'"
        )
        return

    # Remaining params must match original function
    orig_params = list(inspect.signature(my_scorer).parameters.keys())
    if param_names[1:] != orig_params:
        _fail(
            f"C5: params after self are {param_names[1:]}, expected {orig_params}"
        )
        return

    _pass("C5: __call__.__signature__ preserves self + original params")


# ---------------------------------------------------------------------------
# C12: valid_data_for_builtin_scorers maps legacy column names (Dataflow)
# ---------------------------------------------------------------------------


def check_C12_legacy_column_mapping() -> None:
    """Verify 'request'->'inputs' and 'response'->'outputs' column mapping."""
    # Contracts: C12
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    # Create a scorer that requires 'inputs' column
    class InputsOnlyScorer(BuiltInScorer):
        name: str = "inputs_only"
        required_columns: set[str] = {"inputs"}

        @property
        def instructions(self) -> str:
            return "test"

    scorer_instance = InputsOnlyScorer()

    # DataFrame with legacy 'request' column instead of 'inputs'
    df = pd.DataFrame({"request": ["test"], "outputs": ["test"]})

    # Should not raise or log missing columns because 'request' maps to 'inputs'
    with patch("logging.Logger.info") as mock_info:
        valid_data_for_builtin_scorers(df, [scorer_instance])
        # If mapping works, no missing columns logged
        if mock_info.called:
            _fail("C12: legacy column mapping failed - missing columns logged")
            return

    _pass("C12: legacy column names 'request'/'response' mapped correctly")


# ---------------------------------------------------------------------------
# C13: valid_data_for_builtin_scorers explodes expectations dict keys (Dataflow)
# ---------------------------------------------------------------------------


def check_C13_expectations_explosion() -> None:
    """Verify expectations dict keys become 'expectations/{key}' columns."""
    # Contracts: C13
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    # Create a scorer that requires 'expectations/expected_response'
    class ExpectScorer(BuiltInScorer):
        name: str = "expect_scorer"
        required_columns: set[str] = {"inputs", "expectations/expected_response"}

        @property
        def instructions(self) -> str:
            return "test"

    scorer_instance = ExpectScorer()

    df = pd.DataFrame({
        "inputs": ["test"],
        "expectations": [{"expected_response": "answer", "guidelines": "be polite"}],
    })

    with patch("logging.Logger.info") as mock_info:
        valid_data_for_builtin_scorers(df, [scorer_instance])
        if mock_info.called:
            _fail("C13: expectations explosion failed - missing columns logged")
            return

    _pass("C13: expectations dict keys exploded into column set")


# ---------------------------------------------------------------------------
# C16: valid_data_for_builtin_scorers adds 'outputs' for predict_fn (Dataflow)
# ---------------------------------------------------------------------------


def check_C16_predict_fn_adds_outputs() -> None:
    """Verify predict_fn adds synthetic 'outputs' column before validation."""
    # Contracts: C16
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class OutputsScorer(BuiltInScorer):
        name: str = "needs_outputs"
        required_columns: set[str] = {"inputs", "outputs"}

        @property
        def instructions(self) -> str:
            return "test"

    scorer_instance = OutputsScorer()

    # DataFrame with inputs but NO outputs
    df = pd.DataFrame({"inputs": ["test"]})

    def dummy_predict_fn(x):
        return "prediction"

    with patch("logging.Logger.info") as mock_info:
        valid_data_for_builtin_scorers(df, [scorer_instance], predict_fn=dummy_predict_fn)
        if mock_info.called:
            _fail("C16: predict_fn did not add synthetic 'outputs' column")
            return

    _pass("C16: predict_fn adds synthetic 'outputs' column")


# ---------------------------------------------------------------------------
# C16b: predict_fn also adds synthetic 'trace' column (Dataflow - combined case)
# Reference: F1/F11 from Spec Review Report - predict_fn + trace interaction
# ---------------------------------------------------------------------------


def check_C16b_predict_fn_adds_trace() -> None:
    """Verify predict_fn adds synthetic 'trace' column so trace-requiring scorers work."""
    # Contracts: C16 (extended), C17 (combined)
    # Perspective: P1 from review - predict_fn also adds "trace" per skinny ref
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class TraceScorer(BuiltInScorer):
        name: str = "needs_trace"
        required_columns: set[str] = {"inputs", "trace"}

        @property
        def instructions(self) -> str:
            return "test"

    scorer_instance = TraceScorer()

    # DataFrame with ONLY inputs (no trace, no outputs)
    df = pd.DataFrame({"inputs": ["test"]})

    def dummy_predict_fn(x):
        return "prediction"

    with patch("logging.Logger.info") as mock_info:
        valid_data_for_builtin_scorers(df, [scorer_instance], predict_fn=dummy_predict_fn)
        if mock_info.called:
            _fail("C16b: predict_fn did not add synthetic 'trace' column")
            return

    _pass("C16b: predict_fn adds synthetic 'trace' column for trace-requiring scorers")


# ---------------------------------------------------------------------------
# C17: valid_data_for_builtin_scorers adds inputs+outputs for trace (Dataflow)
# ---------------------------------------------------------------------------


def check_C17_trace_adds_inputs_outputs() -> None:
    """Verify 'trace' column adds both 'inputs' and 'outputs' to column set."""
    # Contracts: C17
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class NeedsBothScorer(BuiltInScorer):
        name: str = "needs_both"
        required_columns: set[str] = {"inputs", "outputs"}

        @property
        def instructions(self) -> str:
            return "test"

    scorer_instance = NeedsBothScorer()

    # DataFrame with trace column but no inputs/outputs
    df = pd.DataFrame({"trace": ["trace_obj"]})

    with patch("logging.Logger.info") as mock_info:
        valid_data_for_builtin_scorers(df, [scorer_instance])
        if mock_info.called:
            _fail("C17: trace column did not add synthetic inputs/outputs")
            return

    _pass("C17: trace column adds synthetic 'inputs' and 'outputs'")


# ---------------------------------------------------------------------------
# C10_empty: valid_data_for_builtin_scorers handles empty DataFrame (Compatibility)
# Reference: F10 from Spec Review Report
# ---------------------------------------------------------------------------


def check_C10_empty_dataframe_handling() -> None:
    """Verify valid_data_for_builtin_scorers does not crash on empty DataFrame."""
    # Contracts: C12 (extended boundary)
    # Perspective: F10 from review - empty DataFrame edge case
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers

    class InputsScorer(BuiltInScorer):
        name: str = "needs_inputs"
        required_columns: set[str] = {"inputs"}

        @property
        def instructions(self) -> str:
            return "test"

    scorer_instance = InputsScorer()

    # Empty DataFrame with no columns
    df = pd.DataFrame()

    with patch("logging.Logger.info") as mock_info:
        # Must not raise
        valid_data_for_builtin_scorers(df, [scorer_instance])

    # Empty DataFrame should trigger missing column logging, not a crash
    if not mock_info.called:
        _fail("C10_empty: logger.info was not called for empty DataFrame")
        return

    _pass("C10_empty: empty DataFrame does not crash, logs missing columns")


# ---------------------------------------------------------------------------
# C20: get_all_scorers accessible via scorers package lazy import (Interface)
# ---------------------------------------------------------------------------


def check_C20_lazy_import_get_all_scorers() -> None:
    """Verify get_all_scorers is accessible via mlflow.genai.scorers package."""
    # Contracts: C20
    from mlflow.genai.scorers import get_all_scorers

    if not callable(get_all_scorers):
        _fail("C20: mlflow.genai.scorers.get_all_scorers is not callable")
        return

    # Verify it actually returns results when called
    scorers = get_all_scorers()
    if not isinstance(scorers, list):
        _fail(f"C20: get_all_scorers() returned {type(scorers).__name__}, expected list")
        return

    _pass("C20: get_all_scorers accessible via mlflow.genai.scorers lazy import")


# ---------------------------------------------------------------------------
# C23: evaluate module imports validation functions (Interface)
# ---------------------------------------------------------------------------


def check_C23_evaluate_imports_validation() -> None:
    """Verify evaluate module imports validate_scorers and valid_data_for_builtin_scorers."""
    # Contracts: C23
    import mlflow.genai.evaluation.base as eval_base

    # The module must have these names bound (imported)
    has_validate_scorers = hasattr(eval_base, "validate_scorers") or (
        "validate_scorers" in dir(eval_base)
    )
    has_valid_data = hasattr(eval_base, "valid_data_for_builtin_scorers") or (
        "valid_data_for_builtin_scorers" in dir(eval_base)
    )

    if not has_validate_scorers:
        _fail("C23: evaluate.base does not import validate_scorers")
        return
    if not has_valid_data:
        _fail("C23: evaluate.base does not import valid_data_for_builtin_scorers")
        return

    _pass("C23: evaluate module imports both validation functions")


# ---------------------------------------------------------------------------
# C24: optimize/util imports valid_data_for_builtin_scorers (Interface)
# ---------------------------------------------------------------------------


def check_C24_optimize_imports_validation() -> None:
    """Verify optimize/util module imports valid_data_for_builtin_scorers."""
    # Contracts: C24
    import mlflow.genai.optimize.util as opt_util

    has_valid_data = hasattr(opt_util, "valid_data_for_builtin_scorers") or (
        "valid_data_for_builtin_scorers" in dir(opt_util)
    )

    if not has_valid_data:
        _fail("C24: optimize.util does not import valid_data_for_builtin_scorers")
        return

    _pass("C24: optimize/util imports valid_data_for_builtin_scorers")


# ---------------------------------------------------------------------------
# C23_call_chain: evaluate() → validate_scorers / valid_data_for_builtin_scorers (Call Chain)
# Reference: Review report - cross-module caller-binding gap for E8/E9
# ---------------------------------------------------------------------------


def check_C23_call_chain_evaluate_to_validation() -> None:
    """Verify the real evaluate() call chain reaches validation functions.

    Spies on the caller-resolved bindings and observes their downstream result
    when evaluate() is invoked with data and scorers.
    """
    # Contracts: C23 (extended to Call Chain)
    # Perspective: F1 arch gap - must exercise actual E8/E9 call chain
    import mlflow
    from mlflow.genai.scorers import scorer
    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, get_all_scorers

    # Use a real scorer that requires 'inputs' column
    @scorer
    def dummy_scorer(inputs):
        return True

    # Spy on the validation functions from the caller's perspective
    from mlflow.genai.scorers.validation import validate_scorers as real_validate
    from mlflow.genai.scorers.validation import (
        valid_data_for_builtin_scorers as real_valid_data,
    )

    with patch(
        "mlflow.genai.scorers.validation.validate_scorers",
        wraps=real_validate,
    ) as spy_validate, patch(
        "mlflow.genai.scorers.validation.valid_data_for_builtin_scorers",
        wraps=real_valid_data,
    ) as spy_valid_data:
        # Call evaluate() — this should internally invoke both validation functions
        try:
            mlflow.genai.evaluate(
                data=pd.DataFrame({"inputs": ["hello"]}),
                scorers=[dummy_scorer],
            )
        except Exception:
            # evaluate() may fail for other reasons (models, etc.), but the
            # validation functions should still have been called
            pass

        # The caller (evaluate) must have resolved and invoked validate_scorers
        if not spy_validate.called:
            _fail("C23_call_chain: evaluate() did not call validate_scorers")
            return

    _pass("C23_call_chain: evaluate() invokes validate_scorers and valid_data_for_builtin_scorers")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    checks = [
        check_C1_scorer_returns_custom_scorer,
        check_C4_scorer_param_partial,
        check_C5_signature_preservation,
        check_C12_legacy_column_mapping,
        check_C13_expectations_explosion,
        check_C16_predict_fn_adds_outputs,
        check_C16b_predict_fn_adds_trace,
        check_C17_trace_adds_inputs_outputs,
        check_C10_empty_dataframe_handling,
        check_C20_lazy_import_get_all_scorers,
        check_C23_evaluate_imports_validation,
        check_C24_optimize_imports_validation,
        check_C23_call_chain_evaluate_to_validation,
    ]

    for check in checks:
        try:
            check()
        except Exception as exc:
            _fail(f"{check.__name__}: {type(exc).__name__}: {exc}")

    sys.exit(_EXIT_CODE)
