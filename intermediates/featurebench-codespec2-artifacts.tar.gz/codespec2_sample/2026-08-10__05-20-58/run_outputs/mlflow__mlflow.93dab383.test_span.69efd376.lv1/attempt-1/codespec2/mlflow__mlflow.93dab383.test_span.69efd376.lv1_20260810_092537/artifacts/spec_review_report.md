# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — defines arch_spec (L2 connectivity/call chain) and behavior_spec (L3 outcome/state/failure) responsibilities; mandates six architecture views and caller-binding checks.
- Native tests:
  - `tests/tracing/test_trace_manager.py::test_add_spans` — verifies `pop_trace` returns immutable `Span` instances, cardinality, and trace removal from manager.
  - `tests/tracing/opentelemetry/test_integration.py::test_mlflow_and_opentelemetry_unified_tracing_with_mlflow_root_span` — verifies `request_preview`/`response_preview` contain real content strings after traced execution.
  - `tests/entities/test_span_event.py::test_span_event_to_otel_proto_conversion` — verifies `SpanEvent.to_otel_proto` roundtrip via `_decode_otel_proto_anyvalue`.
  - `tests/tracing/otel/test_span_translation.py::test_translate_span_type_from_otel` — verifies OTel span kind → MLflow span type mapping.
  - `tests/entities/test_trace.py::test_trace_to_and_from_proto` — verifies Trace ↔ protobuf roundtrip including spans.
  - `tests/entities/test_trace.py::test_search_spans` — verifies `Trace.search_spans` filtering and ordered results.
- Repository source: `/testbed/mlflow/entities/span.py` (missing: `LiveSpan.from_dict`, `LiveSpan.set_span_type`, `LiveSpan.to_immutable_span`, `Span.attributes`, `Span.events`, `Span.from_otel_proto`, `Span.request_id`, `Span.span_type`, `Span.to_dict`, `Span.to_otel_proto`, `_CachedSpanAttributesRegistry.set` override, `_SpanAttributesRegistry.get_all`, `create_mlflow_span`, and 14 `NoOpSpan` property/method overrides), `/testbed/mlflow/tracing/trace_manager.py` (missing `_Trace.to_mlflow_trace`), `/testbed/mlflow/tracing/utils/otlp.py` (missing `_decode_otel_proto_anyvalue`, `_otel_proto_bytes_to_id`), `/testbed/mlflow/tracing/utils/truncation.py` (missing `set_request_response_preview`).
- Reference implementation: `/testbed/libs/skinny/mlflow/entities/span.py` (complete), `/testbed/libs/skinny/mlflow/tracing/trace_manager.py` (complete `to_mlflow_trace`), `/testbed/libs/skinny/mlflow/tracing/utils/otlp.py` (complete `_decode_otel_proto_anyvalue`).

## Rubric
- **Requirement coverage**: 1 — The arch_spec and behavior_spec together cover nearly all L3 contracts (C1–C32). However, several checks define only shapeless observations (e.g., C2 only asserts `hasattr` not actual content; C21 only checks event name, not full attribute conversion; C5 to_immutable_span only checks name preservation, not all attribute/event/status roundtrip).
- **Caller binding / call chain**: 1 — C1 exercises the real `pop_trace → _Trace.to_mlflow_trace → LiveSpan.to_immutable_span` path through the trace manager, which is correct. But C28/C29/C30 test `create_mlflow_span` in isolation, not through its real callers (`mlflow/semantic_kernel/autolog.py`, `mlflow/haystack/autolog.py`, `mlflow/strands/autolog.py`). The spec does not verify that these importers can resolve `from mlflow.entities.span import create_mlflow_span` at import time.
- **Dataflow / state / lifecycle**: 1 — C25 tests to_dict byte encoding but does not test from_dict→to_dict roundtrip. C20 tests attributes deserialization but weakly (only checks `isinstance(result, dict)`). C5 to_immutable_span only checks name preservation, ignoring attribute, event, status, and timing data flow.
- **Failure / compatibility boundaries**: 1 — C3 correctly tests `LiveSpan.from_dict` raises `NotImplementedError`. C27 correctly tests `_CachedSpanAttributesRegistry.set` raises `MlflowException`. C31 correctly tests invalid-type raises. But C22 (from_otel_proto) does not test malformed protobuf input, missing status code, or missing required fields. C2 tests set_request_response_preview but uses `patch(wraps=None)` which doesn't actually spy — it silently passes even if the function is never called. No test covers `NoOpSpan` integration in an actual `start_span` failure path.

## Derived Practical Test Perspectives

- **P1**: `tests/tracing/test_trace_manager.py::test_add_spans` — observed risk: after `pop_trace`, spans must be immutable `Span` (not `LiveSpan`) and trace must be cleared from the manager. The generated spec C1 already captures this, but the `_setup_trace_and_spans` helper creates LiveSpan objects with minimal attributes; it does not set inputs/outputs/events, so the to_immutable_span path cannot prove attribute/event preservation.
- **P2**: `tests/tracing/opentelemetry/test_integration.py::test_mlflow_and_opentelemetry_unified_tracing_with_mlflow_root_span` — observed risk: `trace.info.request_preview` and `trace.info.response_preview` must contain actual non-empty content after a traced function with inputs/outputs. The generated spec C2 only checks `hasattr(trace.info, 'request_preview')`, not that the preview contains meaningful content from the spans' inputs/outputs.
- **P3**: `tests/entities/test_span_event.py::test_span_event_to_otel_proto_conversion` — observed risk: `SpanEvent.to_otel_proto` → `_decode_otel_proto_anyvalue` roundtrip must preserve all attribute types (dict, list, primitives). The generated spec C32 tests `_decode_otel_proto_anyvalue` in isolation with hand-crafted protobuf messages but does not verify it works on actual `SpanEvent.to_otel_proto()` output, missing the compatibility dataflow.
- **P4**: `tests/entities/test_trace.py::test_trace_to_and_from_proto` — observed risk: `Trace.to_proto()` calls `span.to_otel_proto()` for each span, and `Trace.from_proto()` calls `Span.from_otel_proto()`. The generated specs test these methods in isolation but never verify the full roundtrip through the Trace container, which is the actual caller binding.
- **P5**: `tests/entities/test_trace.py::test_search_spans` — observed risk: `span.span_type` must work for filtering. The generated spec C24 tests `span.span_type` in isolation on a mock span but does not verify it integrates with `Trace.search_spans`.

## Final Rubric Scores
- Requirement coverage: 1 — All L1 obligations are mapped to at least one check, but several checks are shallow (C2: hasattr only; C5: name-only data preservation; C20: type-only dict check; C21: name-only event check).
- Caller binding / call chain: 1 — C1 exercises the real trace-manager path (good), but `create_mlflow_span` is tested in isolation without verifying that real callers (`semantic_kernel/autolog.py`, `haystack/autolog.py`, `strands/autolog.py`) can resolve the import. No arch check verifies the `from mlflow.entities.span import create_mlflow_span` dependency is satisfied.
- Dataflow / state / lifecycle: 1 — No roundtrip test for `to_dict`→`from_dict`. No roundtrip test for `to_otel_proto`→`from_otel_proto` through the Trace container. `to_immutable_span` data preservation is only name-level. C2's `patch(wraps=None)` does not observe the actual call.
- Failure / compatibility boundaries: 1 — C2 spy is broken (wraps=None prevents observation). No malformed-input test for `from_otel_proto`. No `NoOpSpan` integration test in real failure path.
- P1: 1 — C1 covers the type-check but not attribute/event preservation through the conversion.
- P2: 1 — C2 checks field existence but not content fidelity.
- P3: 1 — C32 tests the decoder in isolation but not coupled with `SpanEvent.to_otel_proto`.
- P4: 0 — No roundtrip check exists via `Trace.to_proto()`/`Trace.from_proto()`.
- P5: 1 — C24 tests `span_type` in isolation but not via `search_spans` integration.

## Findings

### F1: weak_constraint — C2 set_request_response_preview call is never observed
- Requirement/IR: C2, R1
- Evidence: `behavior_spec.py::check_C2_to_mlflow_trace_calls_set_request_response_preview` uses `patch("mlflow.tracing.trace_manager.set_request_response_preview", wraps=None)` — `wraps=None` means the mock does not wrap the real function and returns a `MagicMock` that accepts any call silently. The test only asserts `hasattr(trace.info, 'request_preview')` and does not assert `mock_srrp.assert_called()`.
- Gap: The test cannot detect whether `_Trace.to_mlflow_trace()` actually calls `set_request_response_preview` or whether the preview fields were populated by some other path.
- Repair: Change to `wraps=set_request_response_preview` (after importing it) and assert `mock_srrp.assert_called_once_with(trace.info, ANY)`. Also assert that after the call, `request_preview` and `response_preview` are strings (possibly empty) — matching the native test pattern in `test_mlflow_and_opentelemetry_unified_tracing_with_mlflow_root_span` which asserts actual content like `'{"text": "hello"}'`.

### F2: missing_requirement — No caller-binding check for `create_mlflow_span` import by real consumers
- Requirement/IR: C28–C31, R27
- Evidence: `mlflow/semantic_kernel/autolog.py:15`, `mlflow/haystack/autolog.py:20`, `mlflow/strands/autolog.py:24` all contain `from mlflow.entities.span import create_mlflow_span`. The arch_spec tests `create_mlflow_span` directly but never verifies that these importers can resolve the symbol.
- Gap: If `create_mlflow_span` is defined in a different module than expected, or not exported from `mlflow.entities.span`, the real callers will fail at import time. The arch_spec does not exercise any of these caller paths.
- Repair: Add an arch_spec check that (a) verifies `from mlflow.entities.span import create_mlflow_span` succeeds, and (b) exercises at least one real caller path (e.g., load `mlflow.haystack.autolog` module and verify its `create_mlflow_span` reference resolves to the same function). Per the Test Spec skill L2 pattern, this should be: "import the real caller module, spy on the imported helper at the caller's binding, invoke the caller's entry point."

### F3: weak_constraint — `to_immutable_span` preserves only name, not full data
- Requirement/IR: C5, R4
- Evidence: `behavior_spec.py::check_C5_live_span_to_immutable_preserves_data` sets span type, attributes, and events on the LiveSpan, then calls `to_immutable_span()`, but only asserts `result.name == live.name`.
- Gap: The test does not verify that attributes, span_type, events, inputs, outputs, status, and timing are preserved after the conversion. A plausible wrong implementation that only copies the name would pass.
- Repair: After `result = live.to_immutable_span()`, assert `result.span_type == live.span_type`, `result.attributes == live.attributes`, `len(result.events) == len(live.events)`, `result.status.status_code == live.status.status_code`, and `result.start_time_ns == live.start_time_ns`.

### F4: weak_constraint — `Span.attributes` and `Span.events` checks are underspecified
- Requirement/IR: C20, C21, R19, R20
- Evidence: `arch_spec.py::check_C20_span_attributes_returns_deserialized_dict` only checks `isinstance(result, dict)` and that a known key exists. `check_C21_span_events_returns_span_event_list` only checks `isinstance(result, list)`, that one event is a `SpanEvent`, and its name. Neither checks full value fidelity.
- Gap: A mock OTel span with attributes `{"x": json.dumps(42)}` should return `{"x": 42}` (deserialized). The test doesn't verify deserialization correctness. A plausible wrong implementation returning raw JSON strings would pass. For events, the attributes dict inside the SpanEvent should be converted from BoundedAttributes to plain dict — the test doesn't verify this conversion.
- Repair: For C20: set multiple attributes of different types (int, string, dict, list) on the mock OTel span, build a Span, and assert `span.attributes == {"int_key": 42, "str_key": "hello", "dict_key": {"nested": True}}`. For C21: set an event with attributes, then assert `span.events[0].attributes == {"ev_key": "ev_val"}` and verify the type is `dict` not `BoundedAttributes`.

### F5: missing_requirement — No roundtrip test for `to_dict` ↔ `from_dict`
- Requirement/IR: C25, R24
- Evidence: `arch_spec.py::check_C25_span_to_dict_base64_encoding` tests only the encoding direction (Span→dict) and asserts specific byte patterns (`result["trace_id"] == b64encode(trace_id_int.to_bytes(16, "big")).decode("utf-8")`). There is no test that `Span.from_dict(span.to_dict())` reproduces an equivalent Span.
- Gap: The task specification notes that "this encoding scheme must match exactly to ensure the from_dict() method can correctly deserialize." Without a roundtrip test, an implementation could pass the unidirectional encoding check but fail deserialization due to a mismatch in status code format, attribute serialization, or event structure.
- Repair: Add a roundtrip check: create a Span from a mock OTel span with attributes, events, and status; serialize via `span.to_dict()`; deserialize via `Span.from_dict(result)`; then assert `restored.name == original.name`, `restored.span_type == original.span_type`, `restored.attributes == original.attributes`, and `len(restored.events) == len(original.events)`.

### F6: missing_requirement — No roundtrip test for `to_otel_proto` → `from_otel_proto` through Trace
- Requirement/IR: C22, C26, R21, R25
- Evidence: `arch_spec.py` tests `Span.from_otel_proto` (C22) and `Span.to_otel_proto` (C26) in isolation. Native test `tests/entities/test_trace.py::test_trace_to_and_from_proto` demonstrates the real dataflow: `Trace.to_proto()` → protobuf → `Trace.from_proto()` calls `Span.to_otel_proto()` and `Span.from_otel_proto()` internally. The generated specs never exercise this container-level path.
- Gap: Without testing through `Trace.to_proto()`/`Trace.from_proto()`, the specs cannot detect a mismatch where `span.to_otel_proto()` produces a format that `Span.from_otel_proto()` cannot parse, or where `Trace.from_proto()` fails to wire the helper correctly.
- Repair: Add an arch_spec check that creates a real Trace with spans, calls `trace.to_proto()`, then `Trace.from_proto(proto_trace)`, and asserts `restored.to_dict() == original.to_dict()`. This matches the native test pattern exactly.

### F7: weak_constraint — No malformed-input test for `Span.from_otel_proto`
- Requirement/IR: C22, R21
- Evidence: The arch_spec `check_C22_span_from_otel_proto_returns_span` tests only the happy path with a well-formed protobuf span. Native test `tests/tracing/test_otel_logging.py::test_invalid_otel_span_format_returns_400` and `test_missing_required_span_fields_returns_422` demonstrate that malformed OTel inputs should be handled gracefully.
- Gap: A plausible wrong implementation could crash with `AttributeError` on missing fields (e.g., no status, no name, no trace_id). The spec does not test boundary behavior.
- Repair: Add a behavior_spec check that passes a minimally populated protobuf span (e.g., only trace_id and span_id, no attributes, no events, no status) and verifies `Span.from_otel_proto()` returns a valid Span without raising. Also test a protobuf span with `STATUS_CODE_UNSET` and verify it maps correctly.

### F8: weak_constraint — NoOpSpan is never tested in the real `start_span` failure path
- Requirement/IR: C6–C19, R5–R18
- Evidence: All NoOpSpan tests (behavior_spec C6–C18) test `NoOpSpan()` in complete isolation — construct the object, call a method, assert no raise or check None. No test verifies that an actual tracing failure (e.g., `start_span` with a bad argument or disabled tracing) returns a `NoOpSpan` that survives the full context-manager lifecycle.
- Gap: The task specification says `NoOpSpan` "should be returned from the mlflow.start_span context manager when span creation fails." Testing only the class methods in isolation doesn't prove the integration: that the context manager's `__enter__` returns NoOpSpan, `__exit__` calls `end()` without error, and user setter calls between enter and exit don't crash.
- Repair: Add a behavior_spec integration test that simulates a span creation failure (e.g., by mocking `start_detached_span` to raise), enters the `start_span` context manager, calls `span.set_inputs(...)`, `span.set_attribute(...)`, `span.add_event(...)`, then exits — and verifies no exception propagates and the exit code runs cleanly.

## Rework Instructions
1. **Fix C2 spy (F1)**: In `behavior_spec.py::check_C2_to_mlflow_trace_calls_set_request_response_preview`, import `set_request_response_preview` from `mlflow.tracing.utils.truncation` (after it is implemented) and use `wraps=set_request_response_preview`. Assert `mock_srrp.assert_called_once()`. Also assert that `trace.info.request_preview` and `trace.info.response_preview` are `str` instances with actual content matching span inputs/outputs (following the native test pattern in `test_mlflow_and_opentelemetry_unified_tracing_with_mlflow_root_span`).

2. **Add caller-binding check for `create_mlflow_span` (F2)**: In `arch_spec.py`, add a check that verifies `from mlflow.entities.span import create_mlflow_span` succeeds and that at least one real consumer module (e.g., `mlflow.haystack.autolog`) can resolve its `create_mlflow_span` reference.

3. **Strengthen `to_immutable_span` data preservation (F3)**: In `behavior_spec.py::check_C5_live_span_to_immutable_preserves_data`, add assertions for `span_type`, `attributes`, `events` count, `status`, and `start_time_ns` equality.

4. **Strengthen `attributes` and `events` checks (F4)**: In `arch_spec.py::check_C20_span_attributes_returns_deserialized_dict`, set mock OTel attributes of diverse types (int, str, dict, list) and assert the deserialized dict matches. In `check_C21_span_events_returns_span_event_list`, assert event attribute dict equality and type.

5. **Add `to_dict` ↔ `from_dict` roundtrip (F5)**: In `behavior_spec.py`, add a new check that creates a Span with attributes/events/status, serializes via `to_dict()`, deserializes via `Span.from_dict()`, and asserts field-level equality (name, span_type, attributes, events count, status code).

6. **Add `to_otel_proto` → `from_otel_proto` roundtrip via Trace (F6)**: In `arch_spec.py`, add a check that creates a real Trace, calls `trace.to_proto()`, then `Trace.from_proto(proto)`, and asserts `restored.to_dict() == original.to_dict()`.

7. **Add malformed-input test for `from_otel_proto` (F7)**: In `behavior_spec.py`, add a check that constructs a minimal protobuf span (trace_id+span_id only, no attributes/events/status) and verifies `Span.from_otel_proto()` returns a valid Span without raising.

8. **Add NoOpSpan integration test (F8)**: In `behavior_spec.py`, add a check that simulates span creation failure within `mlflow.start_span`, exercises the full context-manager lifecycle (set_inputs, set_attribute, add_event, end via __exit__), and verifies no exception propagates.
