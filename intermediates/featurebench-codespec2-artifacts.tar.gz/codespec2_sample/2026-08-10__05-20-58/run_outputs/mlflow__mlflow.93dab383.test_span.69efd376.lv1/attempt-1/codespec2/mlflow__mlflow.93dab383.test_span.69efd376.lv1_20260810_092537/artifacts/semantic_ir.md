# Semantic IR

## L1. Requirement Obligations

### R1: Trace-to-MLflow conversion
- Type: Dataflow
- Statement: The internal `_Trace` must convert its mutable `LiveSpan` dictionary into an immutable MLflow `Trace` object containing `Span` objects, `TraceData`, and request/response previews.
- Task Evidence: "Convert the internal _Trace representation to an MLflow Trace object. ... converts all LiveSpan objects in the span dictionary to immutable Span objects, creates a TraceData container, and sets request/response previews."
- Acceptance: Calling `_Trace.to_mlflow_trace()` returns a `Trace` whose `data.spans` list contains only `Span` (not `LiveSpan`) instances, and whose `info.request_preview`/`info.response_preview` are populated.
- Repository Evidence: `mlflow/tracing/trace_manager.py:186` calls `internal_trace.to_mlflow_trace()` in `pop_trace`; `tests/tracing/test_trace_manager.py:60-63` asserts `isinstance(trace.data.spans[0], Span)` and `not isinstance(trace.data.spans[0], LiveSpan)`; `libs/skinny/mlflow/tracing/trace_manager.py:28-33` has a reference implementation.
- Uncertainty: None

### R2: LiveSpan from_dict raises NotImplementedError
- Type: Failure
- Statement: `LiveSpan.from_dict()` must raise `NotImplementedError` because live spans cannot be reconstructed from serialized data.
- Task Evidence: "This method is not supported for the LiveSpan class as LiveSpan objects represent active, mutable spans ... LiveSpan objects cannot be reconstructed from serialized dictionary data."
- Acceptance: `LiveSpan.from_dict({})` raises `NotImplementedError`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R3: LiveSpan set_span_type
- Type: Behavior
- Statement: `LiveSpan.set_span_type(span_type)` must store the span type string as an attribute on the underlying OTel span.
- Task Evidence: "Set the type of the span to categorize its purpose or functionality. ... The span type is stored as a span attribute."
- Acceptance: After `live_span.set_span_type("LLM")`, the span's `span_type` property returns `"LLM"`.
- Repository Evidence: `mlflow/tracing/fluent.py:492,594` calls `mlflow_span.set_span_type(span_type)`; `mlflow/bedrock/_autolog.py:103` calls `span.set_span_type(span_type)`; `mlflow/haystack/autolog.py:126,161` calls `mlflow_span.set_span_type(...)`; `mlflow/strands/autolog.py:92,94,96` calls `mlflow_span.set_span_type(...)`.
- Uncertainty: None

### R4: LiveSpan to_immutable_span
- Type: State
- Statement: `LiveSpan.to_immutable_span()` must return an immutable `Span` wrapping the same underlying OTel span data.
- Task Evidence: "Convert this LiveSpan instance to an immutable Span object. ... All state of the live span is already persisted in the OpenTelemetry span object, so no data copying is required."
- Acceptance: The returned object is `isinstance(result, Span)` and `not isinstance(result, LiveSpan)`.
- Repository Evidence: `libs/skinny/mlflow/tracing/trace_manager.py:30` calls `span.to_immutable_span()` inside `_Trace.to_mlflow_trace()`.
- Uncertainty: None

### R5: NoOpSpan _trace_id returns None
- Type: Behavior
- Statement: `NoOpSpan._trace_id` must return `None` to indicate absence of a valid OpenTelemetry trace ID.
- Task Evidence: "This property returns None to indicate the absence of a valid trace ID."
- Acceptance: `noop_span._trace_id is None`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R6: NoOpSpan add_event no-op
- Type: SideEffect
- Statement: `NoOpSpan.add_event(event)` must accept a `SpanEvent` argument and perform no operation.
- Task Evidence: "This is a no-operation implementation that does nothing when called."
- Acceptance: Calling `noop_span.add_event(some_event)` does not raise and does not modify state.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R7: NoOpSpan end no-op
- Type: SideEffect
- Statement: `NoOpSpan.end(...)` must accept optional `outputs`, `attributes`, `status`, and `end_time_ns` arguments and perform no operation.
- Task Evidence: "This is a no-operation implementation that does nothing when called."
- Acceptance: Calling `noop_span.end(outputs={"x": 1})` does not raise.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R8: NoOpSpan end_time_ns returns None
- Type: Behavior
- Statement: `NoOpSpan.end_time_ns` must return `None`.
- Task Evidence: "Always returns None for no-op spans since they don't track actual timing information."
- Acceptance: `noop_span.end_time_ns is None`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R9: NoOpSpan name returns None
- Type: Behavior
- Statement: `NoOpSpan.name` must return `None`.
- Task Evidence: "Always returns None since no-op spans don't have actual names."
- Acceptance: `noop_span.name is None`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R10: NoOpSpan set_attribute no-op
- Type: SideEffect
- Statement: `NoOpSpan.set_attribute(key, value)` must accept string key and any value and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called."
- Acceptance: Calling `noop_span.set_attribute("key", "value")` does not raise.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R11: NoOpSpan set_attributes no-op
- Type: SideEffect
- Statement: `NoOpSpan.set_attributes(attributes)` must accept a dictionary and perform no operation.
- Task Evidence: "This is a no-operation implementation that accepts attribute assignments but performs no actual work."
- Acceptance: Calling `noop_span.set_attributes({"k": "v"})` does not raise.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R12: NoOpSpan set_inputs no-op
- Type: SideEffect
- Statement: `NoOpSpan.set_inputs(inputs)` must accept any input value and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called."
- Acceptance: Calling `noop_span.set_inputs({"x": 1})` does not raise.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R13: NoOpSpan set_outputs no-op
- Type: SideEffect
- Statement: `NoOpSpan.set_outputs(outputs)` must accept any output value and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called."
- Acceptance: Calling `noop_span.set_outputs({"y": 2})` does not raise.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R14: NoOpSpan set_status no-op
- Type: SideEffect
- Statement: `NoOpSpan.set_status(status)` must accept a `SpanStatus` argument and perform no operation.
- Task Evidence: "This is a no-op implementation that does nothing when called."
- Acceptance: Calling `noop_span.set_status(SpanStatus(SpanStatusCode.OK))` does not raise.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R15: NoOpSpan span_id returns None
- Type: Behavior
- Statement: `NoOpSpan.span_id` must return `None`.
- Task Evidence: "Always returns None for no-op spans since they don't have actual span IDs."
- Acceptance: `noop_span.span_id is None`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R16: NoOpSpan start_time_ns returns None
- Type: Behavior
- Statement: `NoOpSpan.start_time_ns` must return `None`.
- Task Evidence: "Always returns None as no-op spans do not have actual start times."
- Acceptance: `noop_span.start_time_ns is None`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R17: NoOpSpan status returns None
- Type: Behavior
- Statement: `NoOpSpan.status` must return `None`.
- Task Evidence: "Always returns None since this is a no-operation span that doesn't track actual status information."
- Acceptance: `noop_span.status is None`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R18: NoOpSpan trace_id returns sentinel constant
- Type: Behavior
- Statement: `NoOpSpan.trace_id` must return the constant string `"MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Task Evidence: "A special constant trace ID 'MLFLOW_NO_OP_SPAN_TRACE_ID' that distinguishes no-op spans from real spans."
- Acceptance: `noop_span.trace_id == "MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Repository Evidence: `mlflow/entities/span.py:758` defines `NO_OP_SPAN_TRACE_ID = "MLFLOW_NO_OP_SPAN_TRACE_ID"`.
- Uncertainty: None

### R19: Span attributes deserialization
- Type: Behavior
- Statement: `Span.attributes` must return a dictionary of all span attribute key-value pairs with JSON-deserialized values, cached for performance.
- Task Evidence: "Get all attributes of the span. ... The attributes are automatically deserialized from their internal JSON string representation to their original Python objects when accessed through this property."
- Acceptance: `span.attributes` returns `dict[str, Any]` with values deserialized from JSON.
- Repository Evidence: `mlflow/tracing/processor/base_mlflow.py:172,175` accesses `root_span.attributes.get(...)`; `mlflow/tracing/config.py:107` iterates `span.attributes.keys()`; `tests/tracing/test_fluent.py` accesses span attributes.
- Uncertainty: None

### R20: Span events conversion
- Type: Dataflow
- Statement: `Span.events` must return a list of `SpanEvent` objects converted from OpenTelemetry's internal event representation.
- Task Evidence: "Get all events of the span. ... The returned events are converted from OpenTelemetry's internal BoundedAttributes format to simple dictionaries."
- Acceptance: `span.events` returns `list[SpanEvent]`; each event has `name`, `timestamp`, and `attributes` fields.
- Repository Evidence: `tests/tracing/opentelemetry/test_integration.py:58-70` asserts `spans[0].events[0].name`, `.attributes`; `tests/tracing/test_fluent.py:301-303` asserts `root_span.events[0].name`, `.attributes`.
- Uncertainty: None

### R21: Span from_otel_proto conversion
- Type: Compatibility
- Statement: `Span.from_otel_proto(otel_proto_span, location_id=None)` must convert an OpenTelemetry protobuf span into an MLflow `Span` object, extracting trace/span IDs, timing, attributes, events, and status.
- Task Evidence: "Create a Span from an OpenTelemetry protobuf span. ... converts an OpenTelemetry protobuf span message into an MLflow Span object."
- Acceptance: Returns a `Span` instance with correct trace_id, span_id, name, status, attributes, and events mapped from the protobuf.
- Repository Evidence: `mlflow/server/otel_api.py:106` calls `Span.from_otel_proto(otel_proto_span)`; `mlflow/utils/databricks_tracing_utils.py:140` calls `Span.from_otel_proto(span, location_id)`; `mlflow/entities/trace.py:331` calls `Span.from_otel_proto(span)`.
- Uncertainty: None

### R22: Span request_id alias
- Type: Compatibility
- Statement: `Span.request_id` must return the same value as `Span.trace_id` for backward compatibility.
- Task Evidence: "The request ID of the span, which is an alias for the trace ID. ... This property provides backward compatibility for code that uses the deprecated `request_id` attribute."
- Acceptance: `span.request_id == span.trace_id`.
- Repository Evidence: `mlflow/entities/span.py:116-118` shows `trace_id` returns `self.get_attribute(SpanAttributeKey.REQUEST_ID)`.
- Uncertainty: None

### R23: Span span_type retrieval
- Type: Behavior
- Statement: `Span.span_type` must return the span type string stored in the `SpanAttributeKey.SPAN_TYPE` attribute.
- Task Evidence: "The type of the span. ... The span type is stored as an attribute with the key defined in SpanAttributeKey.SPAN_TYPE."
- Acceptance: `span.span_type` returns a string like `"LLM"`, `"TOOL"`, etc.
- Repository Evidence: `mlflow/entities/trace.py` `search_spans` method calls `span.span_type`; `tests/tracing/otel/test_span_translation.py` tests span type translation.
- Uncertainty: None

### R24: Span to_dict serialization
- Type: Dataflow
- Statement: `Span.to_dict()` must serialize the span to a dictionary with base64-encoded IDs (trace_id, span_id, parent_span_id), nanosecond timestamps, events list, status dict, and attributes dict.
- Task Evidence: "Convert the span to a dictionary representation. ... The trace_id, span_id, and parent_span_id are encoded as base64 strings for safe serialization."
- Acceptance: Dictionary contains keys `trace_id`, `span_id`, `parent_span_id`, `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`; IDs are base64-encoded.
- Repository Evidence: `mlflow/entities/trace_data.py:32` calls `span.to_dict()`; `mlflow/entities/trace.py:131` calls `span.to_dict()`; `mlflow/genai/judges/tools/get_span.py:113` calls `target_span.to_dict()`; `mlflow/tracing/utils/__init__.py:496` calls `span.to_dict()`; `mlflow/tracing/otel/translation/__init__.py:50` calls `span.to_dict()`.
- Uncertainty: None

### R25: Span to_otel_proto conversion
- Type: Compatibility
- Statement: `Span.to_otel_proto()` must convert the MLflow span to an OpenTelemetry protobuf `Span` message for OTLP export.
- Task Evidence: "Convert to OpenTelemetry protobuf span format for OTLP export. ... transforms the MLflow Span object into an OpenTelemetry protobuf Span message."
- Acceptance: Returns `OTelProtoSpan` with trace_id, span_id bytes, timing, status, attributes as AnyValue, and events.
- Repository Evidence: `mlflow/entities/trace.py:324` calls `span.to_otel_proto()`; `mlflow/utils/databricks_tracing_utils.py:133` calls `span.to_otel_proto()`; `mlflow/store/tracking/databricks_rest_store.py:483` and `rest_store.py:1739` call `span.to_otel_proto()`.
- Uncertainty: None

### R26: CachedSpanAttributesRegistry set raises
- Type: Failure
- Statement: `_CachedSpanAttributesRegistry.set(key, value)` must raise `MlflowException` because cached attributes are immutable.
- Task Evidence: "Always raised since this method is not supported for immutable spans. ... The cached registry is designed for read-only access to persisted span attributes and does not allow modifications."
- Acceptance: Calling `_CachedSpanAttributesRegistry(...).set("key", "value")` raises `MlflowException`.
- Repository Evidence: None (task-only)
- Uncertainty: None

### R27: create_mlflow_span factory
- Type: Interface
- Statement: `create_mlflow_span(otel_span, trace_id, span_type=None)` must return the correct MLflow span type (`LiveSpan`, `Span`, or `NoOpSpan`) based on the OTel span type.
- Task Evidence: "Create an MLflow span object from an OpenTelemetry span. ... returns the appropriate MLflow span object based on the type of the input OpenTelemetry span."
- Acceptance: For `OTelSpan` returns `LiveSpan`; for `OTelReadableSpan` returns `Span`; for `NonRecordingSpan` or `None` returns `NoOpSpan`; raises `MlflowException` for invalid types.
- Repository Evidence: `mlflow/tracing/processor/otel.py:4,53` imports and calls `create_mlflow_span`; `mlflow/tracing/processor/inference_table.py:9,114` imports and calls; `mlflow/tracing/processor/base_mlflow.py:87` calls; `mlflow/semantic_kernel/autolog.py:15,91` imports and calls; `mlflow/haystack/autolog.py:20,105` imports and calls; `mlflow/strands/autolog.py:24,48` imports and calls.
- Uncertainty: None

### R28: _decode_otel_proto_anyvalue decoder
- Type: Dataflow
- Statement: `_decode_otel_proto_anyvalue(pb_any_value)` must recursively decode an OpenTelemetry `AnyValue` protobuf message into the corresponding Python object.
- Task Evidence: "Decode an OpenTelemetry protobuf AnyValue message into a Python object. ... This function recursively converts an OpenTelemetry AnyValue protobuf message into its corresponding Python representation."
- Acceptance: Returns `None` for unset; `bool` for bool_value; `str` for string_value; `int` for int_value; `float` for double_value; `bytes` for bytes_value; `list` for array_value (recursively decoded); `dict` for kvlist_value (recursively decoded).
- Repository Evidence: `libs/skinny/mlflow/tracing/utils/otlp.py:157-180` has reference implementation; called by `_set_otel_proto_anyvalue` sibling function.
- Uncertainty: None

## L2. Functional Design Graph

### N1: _Trace
- Kind: State
- Repository Evidence: `mlflow/tracing/trace_manager.py:23-27`

### N2: _Trace.to_mlflow_trace
- Kind: Method
- Repository Evidence: `mlflow/tracing/trace_manager.py:186` calls this method; `libs/skinny/mlflow/tracing/trace_manager.py:28-33` has reference.

### N3: Trace
- Kind: Payload
- Repository Evidence: `mlflow/entities/trace/__init__.py:23-25`

### N4: TraceData
- Kind: Payload
- Repository Evidence: `mlflow/entities/trace_data.py:10-21`

### N5: TraceInfo
- Kind: Payload
- Repository Evidence: `mlflow/entities/trace_info.py:22-43`

### N6: LiveSpan
- Kind: Class
- Repository Evidence: `mlflow/entities/span.py:484-756`

### N7: Span (immutable)
- Kind: Class
- Repository Evidence: `mlflow/entities/span.py:91-483`

### N8: NoOpSpan
- Kind: Class
- Repository Evidence: `mlflow/entities/span.py:761-852`

### N9: create_mlflow_span
- Kind: Function
- Repository Evidence: Called by processors in `mlflow/tracing/processor/` and autolog modules; `libs/skinny/mlflow/entities/span.py:66-88` has reference.

### N10: _SpanAttributesRegistry
- Kind: Class
- Repository Evidence: `mlflow/entities/span.py:854-889`

### N11: _CachedSpanAttributesRegistry
- Kind: Class
- Repository Evidence: `mlflow/entities/span.py:892-903`

### N12: SpanEvent
- Kind: Payload
- Repository Evidence: `mlflow/entities/span_event.py:11-64`

### N13: SpanStatus
- Kind: Payload
- Repository Evidence: `mlflow/entities/span_status.py:34-149`

### N14: OTelProtoSpan
- Kind: External
- Repository Evidence: `mlflow/entities/span.py:7` imports `from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan`

### N15: OTelReadableSpan
- Kind: External
- Repository Evidence: `mlflow/entities/span.py:11` imports `from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan`

### N16: OTelSpan
- Kind: External
- Repository Evidence: `mlflow/entities/span.py:13` imports `from opentelemetry.trace import Span as OTelSpan`

### N17: NonRecordingSpan
- Kind: External
- Repository Evidence: `mlflow/entities/span.py:12` imports `from opentelemetry.trace import NonRecordingSpan`

### N18: AnyValue (protobuf)
- Kind: External
- Repository Evidence: `mlflow/tracing/utils/otlp.py:4` imports `from opentelemetry.proto.common.v1.common_pb2 import AnyValue`

### N19: _decode_otel_proto_anyvalue
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/tracing/utils/otlp.py:157-180` has reference implementation.

### N20: set_request_response_preview
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/tracing/utils/truncation.py:15-23` defines it; called by `_Trace.to_mlflow_trace`.

### N21: SpanStatusCode
- Kind: Payload
- Repository Evidence: `mlflow/entities/span_status.py:12-18`

### N22: InMemoryTraceManager.pop_trace
- Kind: Method
- Repository Evidence: `mlflow/tracing/trace_manager.py:176-187`

### N23: LiveSpan.to_immutable_span
- Kind: Method
- Repository Evidence: Called by `_Trace.to_mlflow_trace` in libs reference.

### N24: LiveSpan.set_span_type
- Kind: Method
- Repository Evidence: Called by `mlflow/tracing/fluent.py:492,594`, `mlflow/bedrock/_autolog.py:103`, etc.

### N25: LiveSpan.from_dict
- Kind: Method
- Repository Evidence: None (task-only, must raise NotImplementedError)

### E1: _Trace.to_mlflow_trace -> LiveSpan.to_immutable_span
- Kind: CALL
- Condition: Always (for each span in span_dict)
- Transfer: `LiveSpan -> Span` via `to_immutable_span()`
- Evidence: `libs/skinny/mlflow/tracing/trace_manager.py:30` calls `span.to_immutable_span()`
- Obligations: R1, R4

### E2: _Trace.to_mlflow_trace -> set_request_response_preview
- Kind: CALL
- Condition: Always
- Transfer: `(TraceInfo, TraceData) -> None` with side-effect on TraceInfo previews
- Evidence: `libs/skinny/mlflow/tracing/trace_manager.py:32` calls `set_request_response_preview(self.info, trace_data)`
- Obligations: R1

### E3: _Trace.to_mlflow_trace -> Trace
- Kind: DATA
- Condition: Always
- Transfer: Returns `Trace(info, trace_data)` where trace_data.spans are immutable Span objects
- Evidence: `libs/skinny/mlflow/tracing/trace_manager.py:33`
- Obligations: R1

### E4: InMemoryTraceManager.pop_trace -> _Trace.to_mlflow_trace
- Kind: CALL
- Condition: When internal trace is found
- Transfer: Converts internal _Trace to MLflow Trace for external consumption
- Evidence: `mlflow/tracing/trace_manager.py:186` calls `internal_trace.to_mlflow_trace()`
- Obligations: R1

### E5: create_mlflow_span -> LiveSpan
- Kind: CONTROL
- Condition: `isinstance(otel_span, OTelSpan)` and span is recording
- Transfer: Returns `LiveSpan(otel_span, trace_id, span_type)`
- Evidence: `libs/skinny/mlflow/entities/span.py:66-88`; callers like `mlflow/tracing/processor/base_mlflow.py:87`
- Obligations: R27

### E6: create_mlflow_span -> Span
- Kind: CONTROL
- Condition: `isinstance(otel_span, OTelReadableSpan)` (finished span)
- Transfer: Returns `Span(otel_span)`
- Evidence: `libs/skinny/mlflow/entities/span.py:66-88` reference
- Obligations: R27

### E7: create_mlflow_span -> NoOpSpan
- Kind: CONTROL
- Condition: `isinstance(otel_span, NonRecordingSpan)` or `otel_span is None`
- Transfer: Returns `NoOpSpan()`
- Evidence: `libs/skinny/mlflow/entities/span.py:66-88` reference
- Obligations: R27

### E8: create_mlflow_span -> MlflowException
- Kind: CONTROL
- Condition: otel_span is not a recognized OTel span type
- Transfer: Raises `MlflowException(INVALID_PARAMETER_VALUE)`
- Evidence: Task document
- Obligations: R27

### E9: Span.__init__ -> _CachedSpanAttributesRegistry
- Kind: DATA
- Condition: Always
- Transfer: Sets `self._attributes = _CachedSpanAttributesRegistry(otel_span)`
- Evidence: `mlflow/entities/span.py:112`
- Obligations: R19, R26

### E10: Span.attributes -> _CachedSpanAttributesRegistry.get_all
- Kind: CALL
- Condition: Always
- Transfer: Returns all deserialized attributes from registry
- Evidence: `libs/skinny/mlflow/entities/span.py:181-188` has reference; `mlflow/tracing/processor/base_mlflow.py:172` accesses `.attributes`
- Obligations: R19

### E11: Span.events -> OTelReadableSpan.events
- Kind: DATA
- Condition: Always
- Transfer: Converts OTel BoundedAttributes events to list[SpanEvent]
- Evidence: `libs/skinny/mlflow/entities/span.py:190-207` reference; `tests/tracing/test_fluent.py:301-303`
- Obligations: R20

### E12: Span.from_otel_proto -> OTelProtoSpan
- Kind: DATA
- Condition: Always
- Transfer: Extracts trace_id, span_id, name, timestamps, attributes, events, status from protobuf
- Evidence: `libs/skinny/mlflow/entities/span.py:366-420` reference; `mlflow/server/otel_api.py:106`
- Obligations: R21

### E13: Span.to_dict -> base64 encoding helpers
- Kind: CALL
- Condition: Always
- Transfer: Encodes trace_id (16 bytes) and span_id (8 bytes) via int.to_bytes + base64
- Evidence: `libs/skinny/mlflow/entities/span.py:227-256` reference; `mlflow/entities/trace_data.py:32`
- Obligations: R24

### E14: Span.to_otel_proto -> OTelProtoSpan
- Kind: DATA
- Condition: Always
- Transfer: Populates OTelProtoSpan fields from MLflow Span data; uses _set_otel_proto_anyvalue for attributes
- Evidence: `libs/skinny/mlflow/entities/span.py:422-454` reference; `mlflow/entities/trace.py:324`
- Obligations: R25

### E15: Span.request_id -> Span.trace_id
- Kind: DATA
- Condition: Always
- Transfer: Returns same value as trace_id
- Evidence: Task document; `libs/skinny/mlflow/entities/span.py:121-123` reference
- Obligations: R22

### E16: Span.span_type -> _CachedSpanAttributesRegistry.get
- Kind: CALL
- Condition: Always
- Transfer: Returns value of `SpanAttributeKey.SPAN_TYPE` attribute
- Evidence: `libs/skinny/mlflow/entities/span.py:168-170` reference; `mlflow/entities/trace.py` search_spans
- Obligations: R23

### E17: _CachedSpanAttributesRegistry.set -> MlflowException
- Kind: CONTROL
- Condition: Always
- Transfer: Raises MlflowException to prevent mutation of immutable spans
- Evidence: Task document; `libs/skinny/mlflow/entities/span.py:905-908` reference
- Obligations: R26

### E18: LiveSpan.set_span_type -> _SpanAttributesRegistry.set
- Kind: CALL
- Condition: Always
- Transfer: Sets `SpanAttributeKey.SPAN_TYPE` attribute to span_type value
- Evidence: `libs/skinny/mlflow/entities/span.py:525-527` reference; `mlflow/tracing/fluent.py:492`
- Obligations: R3

### E19: LiveSpan.to_immutable_span -> Span
- Kind: DATA
- Condition: Always
- Transfer: Returns `Span(self._span)` wrapping same OTel span
- Evidence: `libs/skinny/mlflow/entities/span.py:668-675` reference
- Obligations: R4

### E20: LiveSpan.from_dict -> NotImplementedError
- Kind: CONTROL
- Condition: Always
- Transfer: Raises NotImplementedError
- Evidence: Task document
- Obligations: R2

### E21: NoOpSpan.* -> NoOpSpan (identity no-ops)
- Kind: CONTROL
- Condition: Always
- Transfer: All setter methods accept arguments and return None; all property getters return None (except trace_id which returns sentinel)
- Evidence: `libs/skinny/mlflow/entities/span.py:761-852` reference
- Obligations: R5, R6, R7, R8, R9, R10, R11, R12, R13, R14, R15, R16, R17, R18

### E22: _decode_otel_proto_anyvalue -> AnyValue
- Kind: DATA
- Condition: Always
- Transfer: Reads `WhichOneof("value")` and returns corresponding Python type, recursing for array/kvlist
- Evidence: `libs/skinny/mlflow/tracing/utils/otlp.py:157-180` reference
- Obligations: R28

## L3. Verifiable Contracts

### C1: to_mlflow_trace returns immutable Trace
- Type: Behavior
- Subject: `_Trace.to_mlflow_trace()`
- Relation: TYPE_IS
- Expected: Returns `Trace`; `all(not isinstance(s, LiveSpan) for s in result.data.spans)`; `all(isinstance(s, Span) for s in result.data.spans)`
- Evidence: `tests/tracing/test_trace_manager.py:60-63` asserts `isinstance(trace.data.spans[0], Span)` and `not isinstance(trace.data.spans[0], LiveSpan)`
- Observe: RETURN_VALUE
- Target: `InMemoryTraceManager.pop_trace()` → `_Trace.to_mlflow_trace()`
- Obligations: R1, R4
- Graph: N2, E1, E3, E4

### C2: to_mlflow_trace calls set_request_response_preview
- Type: SideEffect
- Subject: `_Trace.to_mlflow_trace()`
- Relation: CALLS
- Expected: `set_request_response_preview(trace_info, trace_data)` is invoked, populating `trace_info.request_preview` and `trace_info.response_preview`
- Evidence: `libs/skinny/mlflow/tracing/trace_manager.py:32`; `libs/skinny/mlflow/tracing/utils/truncation.py:15-23`
- Observe: SIDE_EFFECT
- Target: `TraceInfo.request_preview` / `TraceInfo.response_preview` field read after `to_mlflow_trace()`
- Obligations: R1
- Graph: N2, E2, N20

### C3: LiveSpan.from_dict raises NotImplementedError
- Type: Failure
- Subject: `LiveSpan.from_dict`
- Relation: RAISES
- Expected: `NotImplementedError`
- Evidence: Task document
- Observe: EXCEPTION
- Target: `LiveSpan.from_dict({})`
- Obligations: R2
- Graph: N6, N25, E20

### C4: LiveSpan.set_span_type stores attribute
- Type: Behavior
- Subject: `LiveSpan.set_span_type("LLM")`
- Relation: PRESERVE
- Expected: After call, `span.span_type == "LLM"` (attribute stored at `SpanAttributeKey.SPAN_TYPE`)
- Evidence: `mlflow/tracing/fluent.py:492,594`; `mlflow/bedrock/_autolog.py:103`
- Observe: FIELD_READ
- Target: `span.span_type` property after `set_span_type`
- Obligations: R3
- Graph: N6, N24, E18

### C5: LiveSpan.to_immutable_span returns Span not LiveSpan
- Type: State
- Subject: `live_span.to_immutable_span()`
- Relation: TYPE_IS
- Expected: Returns `Span` instance; `isinstance(result, Span) is True`; `isinstance(result, LiveSpan) is False`
- Evidence: `libs/skinny/mlflow/tracing/trace_manager.py:30`; `tests/tracing/test_trace_manager.py:60-63`
- Observe: RETURN_VALUE
- Target: `live_span.to_immutable_span()` return type check
- Obligations: R4
- Graph: N6, N23, E19, E1

### C6: NoOpSpan._trace_id is None
- Type: Behavior
- Subject: `NoOpSpan()._trace_id`
- Relation: EQ
- Expected: `None`
- Evidence: Task document
- Observe: FIELD_READ
- Target: `noop_span._trace_id`
- Obligations: R5
- Graph: N8, E21

### C7: NoOpSpan.add_event does not raise
- Type: SideEffect
- Subject: `NoOpSpan().add_event(SpanEvent(...))`
- Relation: UNCHANGED
- Expected: No exception raised; no state change
- Evidence: Task document
- Observe: SIDE_EFFECT
- Target: Call `add_event` on NoOpSpan and verify no exception
- Obligations: R6
- Graph: N8, E21

### C8: NoOpSpan.end does not raise
- Type: SideEffect
- Subject: `NoOpSpan().end(outputs={"x": 1})`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task document
- Observe: SIDE_EFFECT
- Target: Call `end` on NoOpSpan with kwargs and verify no exception
- Obligations: R7
- Graph: N8, E21

### C9: NoOpSpan.end_time_ns is None
- Type: Behavior
- Subject: `NoOpSpan().end_time_ns`
- Relation: EQ
- Expected: `None`
- Evidence: Task document
- Observe: FIELD_READ
- Target: `noop_span.end_time_ns`
- Obligations: R8
- Graph: N8, E21

### C10: NoOpSpan.name is None
- Type: Behavior
- Subject: `NoOpSpan().name`
- Relation: EQ
- Expected: `None`
- Evidence: Task document
- Observe: FIELD_READ
- Target: `noop_span.name`
- Obligations: R9
- Graph: N8, E21

### C11: NoOpSpan.set_attribute no-op
- Type: SideEffect
- Subject: `NoOpSpan().set_attribute("key", "value")`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task document
- Observe: SIDE_EFFECT
- Target: Call `set_attribute` and verify no exception
- Obligations: R10
- Graph: N8, E21

### C12: NoOpSpan.set_attributes no-op
- Type: SideEffect
- Subject: `NoOpSpan().set_attributes({"k": "v"})`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task document
- Observe: SIDE_EFFECT
- Target: Call `set_attributes` and verify no exception
- Obligations: R11
- Graph: N8, E21

### C13: NoOpSpan.set_inputs no-op
- Type: SideEffect
- Subject: `NoOpSpan().set_inputs({"x": 1})`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task document
- Observe: SIDE_EFFECT
- Target: Call `set_inputs` and verify no exception
- Obligations: R12
- Graph: N8, E21

### C14: NoOpSpan.set_outputs no-op
- Type: SideEffect
- Subject: `NoOpSpan().set_outputs({"y": 2})`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task document
- Observe: SIDE_EFFECT
- Target: Call `set_outputs` and verify no exception
- Obligations: R13
- Graph: N8, E21

### C15: NoOpSpan.set_status no-op
- Type: SideEffect
- Subject: `NoOpSpan().set_status(SpanStatus(SpanStatusCode.OK))`
- Relation: UNCHANGED
- Expected: No exception raised
- Evidence: Task document
- Observe: SIDE_EFFECT
- Target: Call `set_status` and verify no exception
- Obligations: R14
- Graph: N8, E21

### C16: NoOpSpan.span_id is None
- Type: Behavior
- Subject: `NoOpSpan().span_id`
- Relation: EQ
- Expected: `None`
- Evidence: Task document
- Observe: FIELD_READ
- Target: `noop_span.span_id`
- Obligations: R15
- Graph: N8, E21

### C17: NoOpSpan.start_time_ns is None
- Type: Behavior
- Subject: `NoOpSpan().start_time_ns`
- Relation: EQ
- Expected: `None`
- Evidence: Task document
- Observe: FIELD_READ
- Target: `noop_span.start_time_ns`
- Obligations: R16
- Graph: N8, E21

### C18: NoOpSpan.status is None
- Type: Behavior
- Subject: `NoOpSpan().status`
- Relation: EQ
- Expected: `None`
- Evidence: Task document
- Observe: FIELD_READ
- Target: `noop_span.status`
- Obligations: R17
- Graph: N8, E21

### C19: NoOpSpan.trace_id is sentinel
- Type: Behavior
- Subject: `NoOpSpan().trace_id`
- Relation: EQ
- Expected: `"MLFLOW_NO_OP_SPAN_TRACE_ID"`
- Evidence: `mlflow/entities/span.py:758` defines `NO_OP_SPAN_TRACE_ID`
- Observe: FIELD_READ
- Target: `noop_span.trace_id`
- Obligations: R18
- Graph: N8, E21

### C20: Span.attributes returns deserialized dict
- Type: Dataflow
- Subject: `span.attributes`
- Relation: TYPE_IS
- Expected: Returns `dict[str, Any]` with all attribute values JSON-deserialized
- Evidence: `libs/skinny/mlflow/entities/span.py:181-188` reference; `mlflow/tracing/processor/base_mlflow.py:172`
- Observe: FIELD_READ
- Target: `span.attributes` return value type and content
- Obligations: R19
- Graph: N7, E9, E10

### C21: Span.events returns list[SpanEvent]
- Type: Dataflow
- Subject: `span.events`
- Relation: TYPE_IS
- Expected: Returns `list[SpanEvent]`; each event has `name: str`, `timestamp: int`, `attributes: dict`
- Evidence: `tests/tracing/opentelemetry/test_integration.py:58-60` asserts `spans[0].events[0].name`, `.attributes`; `tests/tracing/test_fluent.py:301-303`
- Observe: FIELD_READ
- Target: `span.events` return value
- Obligations: R20
- Graph: N7, E11

### C22: Span.from_otel_proto returns Span with mapped data
- Type: Compatibility
- Subject: `Span.from_otel_proto(proto_span)`
- Relation: TYPE_IS
- Expected: Returns `Span` with trace_id, span_id, name, start_time_ns, end_time_ns, status, attributes, events all populated from protobuf
- Evidence: `mlflow/server/otel_api.py:106`; `mlflow/entities/trace.py:331`
- Observe: RETURN_VALUE
- Target: `Span.from_otel_proto(otel_proto_span)` → inspect fields
- Obligations: R21
- Graph: N7, E12, N14

### C23: Span.request_id equals trace_id
- Type: Compatibility
- Subject: `span.request_id`
- Relation: EQ
- Expected: `span.request_id == span.trace_id`
- Evidence: Task document; `mlflow/entities/span.py:116-118`
- Observe: FIELD_READ
- Target: Compare `span.request_id` and `span.trace_id`
- Obligations: R22
- Graph: N7, E15

### C24: Span.span_type returns attribute value
- Type: Behavior
- Subject: `span.span_type`
- Relation: EQ
- Expected: Returns value of attribute at `SpanAttributeKey.SPAN_TYPE` (e.g., `"LLM"`)
- Evidence: `mlflow/entities/trace.py` search_spans uses `span.span_type`
- Observe: FIELD_READ
- Target: `span.span_type`
- Obligations: R23
- Graph: N7, E16

### C25: Span.to_dict base64 encoding
- Type: Dataflow
- Subject: `span.to_dict()`
- Relation: CONTAINS
- Expected: Returns dict with keys: `trace_id` (base64 str, 16-byte), `span_id` (base64 str, 8-byte), `parent_span_id` (base64 str or None), `name`, `start_time_unix_nano`, `end_time_unix_nano`, `events`, `status`, `attributes`
- Evidence: `mlflow/entities/trace_data.py:32`; `mlflow/genai/judges/tools/get_span.py:113`; `tests/tracing/test_fluent.py` uses span data
- Observe: RETURN_VALUE
- Target: `span.to_dict()` return dict structure
- Obligations: R24
- Graph: N7, E13

### C26: Span.to_otel_proto returns OTelProtoSpan
- Type: Compatibility
- Subject: `span.to_otel_proto()`
- Relation: TYPE_IS
- Expected: Returns `OTelProtoSpan` with trace_id bytes, span_id bytes, name, timestamps, status, attributes as AnyValue, events
- Evidence: `mlflow/entities/trace.py:324`; `mlflow/store/tracking/rest_store.py:1739`
- Observe: RETURN_VALUE
- Target: `span.to_otel_proto()` → check fields on returned protobuf
- Obligations: R25
- Graph: N7, E14, N14

### C27: _CachedSpanAttributesRegistry.set raises MlflowException
- Type: Failure
- Subject: `_CachedSpanAttributesRegistry(otel_span).set("key", "value")`
- Relation: RAISES
- Expected: `MlflowException`
- Evidence: Task document; `libs/skinny/mlflow/entities/span.py:905-908`
- Observe: EXCEPTION
- Target: `_CachedSpanAttributesRegistry(...).set("k", "v")`
- Obligations: R26
- Graph: N11, E17

### C28: create_mlflow_span returns LiveSpan for active OTelSpan
- Type: Interface
- Subject: `create_mlflow_span(otel_span, trace_id, span_type)`
- Relation: TYPE_IS
- Expected: When `isinstance(otel_span, OTelSpan)` and span is recording, returns `LiveSpan`
- Evidence: `mlflow/tracing/processor/base_mlflow.py:87`; `mlflow/semantic_kernel/autolog.py:91`
- Observe: RETURN_VALUE
- Target: `create_mlflow_span(mock_otel_span, "trace-id")` return type
- Obligations: R27
- Graph: N9, E5

### C29: create_mlflow_span returns Span for ReadableSpan
- Type: Interface
- Subject: `create_mlflow_span(otel_readable_span, trace_id)`
- Relation: TYPE_IS
- Expected: When `isinstance(otel_span, OTelReadableSpan)` and not active, returns `Span`
- Evidence: `mlflow/tracing/processor/` modules
- Observe: RETURN_VALUE
- Target: `create_mlflow_span(readable_span, "trace-id")` return type
- Obligations: R27
- Graph: N9, E6

### C30: create_mlflow_span returns NoOpSpan for NonRecordingSpan
- Type: Interface
- Subject: `create_mlflow_span(non_recording_span, trace_id)`
- Relation: TYPE_IS
- Expected: When `isinstance(otel_span, NonRecordingSpan)` or `otel_span is None`, returns `NoOpSpan`
- Evidence: Task document
- Observe: RETURN_VALUE
- Target: `create_mlflow_span(NonRecordingSpan(...), "trace-id")` return type
- Obligations: R27
- Graph: N9, E7

### C31: create_mlflow_span raises for invalid type
- Type: Failure
- Subject: `create_mlflow_span("invalid", trace_id)`
- Relation: RAISES
- Expected: `MlflowException` with `INVALID_PARAMETER_VALUE`
- Evidence: Task document
- Observe: EXCEPTION
- Target: `create_mlflow_span(invalid_obj, "trace-id")`
- Obligations: R27
- Graph: N9, E8

### C32: _decode_otel_proto_anyvalue decodes all types
- Type: Dataflow
- Subject: `_decode_otel_proto_anyvalue(any_value)`
- Relation: EQ
- Expected: Returns None for unset; bool for bool_value; str for string_value; int for int_value; float for double_value; bytes for bytes_value; list for array_value (recursive); dict for kvlist_value (recursive)
- Evidence: `libs/skinny/mlflow/tracing/utils/otlp.py:157-180` reference
- Observe: RETURN_VALUE
- Target: `_decode_otel_proto_anyvalue(pb)` for each type
- Obligations: R28
- Graph: N19, E22, N18

