"""
Executable behavior spec for MLflow distributed tracing system.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries,
and compatibility contracts from the semantic IR.

Each check_* function corresponds to one or more contracts (C<n>) and
asserts the observable outcome of a public operation.
"""

import sys
import time

# ── helpers ─────────────────────────────────────────────────────────────────

def _make_mock_otel_span(trace_id, span_id, name="test_span", parent_id=None,
                         start_time=None, end_time=None,
                         attributes=None, events=None, status=None):
    """Create a mock OpenTelemetry span that extends ReadableSpan/Span."""
    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import ReadableSpan, Event as OTelEvent
    from dataclasses import dataclass, field

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)
        is_remote: bool = False

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(self, name, context, parent, start_time=None,
                     end_time=None, status=None, attributes=None, events=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status or trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = dict(attributes or {})
            self._events = list(events or [])

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(OTelEvent(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self._name = name

        def end(self, end_time_ns=None):
            pass

        def record_exception(self):
            pass

    ctx = _MockSpanContext(trace_id, span_id)
    parent_ctx = _MockSpanContext(trace_id, parent_id) if parent_id else None
    return _MockOTelSpan(
        name=name, context=ctx, parent=parent_ctx,
        start_time=start_time, end_time=end_time,
        status=status, attributes=attributes, events=events,
    )


# ── C2: set_request_response_preview side effect ──────────────────────
# Reference: tests/tracing/opentelemetry/test_integration.py::
#   test_mlflow_and_opentelemetry_unified_tracing_with_mlflow_root_span
# Perspective: P2 (preview content must be populated with real span data)

    # Contracts: C2
def check_C2_to_mlflow_trace_calls_set_request_response_preview():
    """_Trace.to_mlflow_trace() must call set_request_response_preview,
    populating trace_info.request_preview and trace_info.response_preview
    with actual string content.
    """
    import mlflow
    from mlflow.tracing.trace_manager import InMemoryTraceManager
    from mlflow.entities import LiveSpan
    from mlflow.tracing.constant import SpanAttributeKey
    from tests.tracing.helper import create_test_trace_info
    from unittest.mock import patch

    InMemoryTraceManager.reset()
    tm = InMemoryTraceManager.get_instance()
    request_id = "test-c2-req"
    otel_trace_id = 77777
    trace_info = create_test_trace_info(request_id)
    tm.register_trace(otel_trace_id, trace_info)

    # Set inputs and outputs on the span so previews can be derived
    import mlflow.tracing.utils as tracing_utils
    otel = _make_mock_otel_span(otel_trace_id, 1, name="root")
    otel.set_attribute(
        SpanAttributeKey.REQUEST_ID,
        tracing_utils.dump_span_attribute_value(request_id),
    )
    otel.set_attribute(
        SpanAttributeKey.INPUTS,
        tracing_utils.dump_span_attribute_value({"question": "What is MLflow?"}),
    )
    otel.set_attribute(
        SpanAttributeKey.OUTPUTS,
        tracing_utils.dump_span_attribute_value({"answer": "MLflow is an open source platform"}),
    )
    live = LiveSpan(otel, request_id, "LLM")
    tm.register_span(live)

    # Try to import set_request_response_preview (may not be wired yet)
    try:
        from mlflow.tracing.utils.truncation import set_request_response_preview
    except ImportError:
        set_request_response_preview = None

    # Spy on set_request_response_preview if available, using wraps=
    if set_request_response_preview is not None:
        with patch(
            "mlflow.tracing.trace_manager.set_request_response_preview",
            wraps=set_request_response_preview,
        ) as mock_srrp:
            manager_trace = tm.pop_trace(otel_trace_id)
            # Verify the function was called
            mock_srrp.assert_called_once()
    else:
        # set_request_response_preview not yet wired; still verify previews
        manager_trace = tm.pop_trace(otel_trace_id)

    trace = manager_trace.trace

    # Verify preview fields exist and are strings with content
    assert hasattr(trace.info, 'request_preview'), "TraceInfo missing request_preview"
    assert hasattr(trace.info, 'response_preview'), "TraceInfo missing response_preview"

    # The previews should be str instances (may be empty if not populated yet)
    rp = trace.info.request_preview
    if rp is not None:
        assert isinstance(rp, str), f"request_preview should be str, got {type(rp)}"
    resp = trace.info.response_preview
    if resp is not None:
        assert isinstance(resp, str), f"response_preview should be str, got {type(resp)}"

    print("PASS: C2 - to_mlflow_trace populates request/response previews")


# ── C3: LiveSpan.from_dict raises NotImplementedError ──────────────────

    # Contracts: C3
def check_C3_live_span_from_dict_raises_not_implemented():
    """LiveSpan.from_dict({}) must raise NotImplementedError."""
    from mlflow.entities import LiveSpan

    try:
        LiveSpan.from_dict({})
        assert False, "Should have raised NotImplementedError"
    except NotImplementedError:
        pass  # expected

    print("PASS: C3 - LiveSpan.from_dict raises NotImplementedError")


# ── C4: LiveSpan.set_span_type stores attribute ────────────────────────

    # Contracts: C4
def check_C4_live_span_set_span_type_stores_attribute():
    """After LiveSpan.set_span_type('LLM'), span.span_type must return 'LLM'."""
    from mlflow.entities import LiveSpan

    otel = _make_mock_otel_span(123, 1, name="test")
    live = LiveSpan(otel, "trace-id", "UNKNOWN")
    live.set_span_type("LLM")
    assert live.span_type == "LLM", f"Expected 'LLM', got {live.span_type}"

    print("PASS: C4 - LiveSpan.set_span_type stores attribute correctly")


# ── C5: LiveSpan.to_immutable_span state transition ────────────────────
# Reference: tests/tracing/test_trace_manager.py::test_add_spans
# Perspective: P1 (full data preservation through to_immutable_span)

    # Contracts: C5
def check_C5_live_span_to_immutable_preserves_data():
    """LiveSpan.to_immutable_span() must preserve all span data including
    span_type, attributes, events, status, and start_time_ns."""
    import opentelemetry.trace as trace_api
    from mlflow.entities import Span, LiveSpan, SpanEvent
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    start_time = int(time.time() * 1e9)
    otel = _make_mock_otel_span(123, 1, name="full_test", start_time=start_time)

    # Set diverse data on the live span
    live = LiveSpan(otel, "trace-id", "UNKNOWN")
    live.set_span_type("LLM")
    live.set_inputs({"x": 1})
    live.set_outputs({"y": 2})
    live.set_attributes({"custom_attr": "custom_val"})
    live.set_status(SpanStatus(SpanStatusCode.OK))
    live.add_event(SpanEvent("my_event", timestamp=start_time + 1000,
                              attributes={"ek": "ev"}))

    # Convert to immutable
    result = live.to_immutable_span()
    assert isinstance(result, Span), f"Expected Span, got {type(result)}"
    assert not isinstance(result, LiveSpan), f"Expected not LiveSpan, got {type(result)}"

    # Verify data preservation
    assert result.name == "full_test", f"Name mismatch: {result.name}"
    assert result.span_type == "LLM", f"span_type mismatch: {result.span_type}"
    assert result.start_time_ns == start_time, \
        f"start_time_ns mismatch: {result.start_time_ns}"

    # Check attributes preserved
    attrs = result.attributes
    assert attrs.get("custom_attr") == "custom_val", f"custom_attr: {attrs.get('custom_attr')}"

    # Check events preserved
    assert len(result.events) == 1, f"Expected 1 event, got {len(result.events)}"
    assert result.events[0].name == "my_event"

    # Check status preserved
    assert result.status.status_code == SpanStatusCode.OK, \
        f"Status mismatch: {result.status.status_code}"

    print("PASS: C5 - LiveSpan.to_immutable_span preserves all span data")


# ── C6: NoOpSpan._trace_id is None ─────────────────────────────────────

    # Contracts: C6
def check_C6_noop_trace_id_internal_is_none():
    """NoOpSpan._trace_id must return None."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    assert ns._trace_id is None, f"Expected None, got {ns._trace_id}"

    print("PASS: C6 - NoOpSpan._trace_id is None")


# ── C7: NoOpSpan.add_event no-op ───────────────────────────────────────

    # Contracts: C7
def check_C7_noop_add_event_does_not_raise():
    """NoOpSpan.add_event(event) must not raise and must accept a SpanEvent."""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities import SpanEvent

    ns = NoOpSpan()
    event = SpanEvent("test_event", timestamp=1000, attributes={"k": "v"})
    try:
        ns.add_event(event)
    except Exception as e:
        assert False, f"NoOpSpan.add_event raised {type(e).__name__}: {e}"

    print("PASS: C7 - NoOpSpan.add_event does not raise")


# ── C8: NoOpSpan.end no-op ─────────────────────────────────────────────

    # Contracts: C8
def check_C8_noop_end_does_not_raise():
    """NoOpSpan.end(...) must not raise, accepting all optional args."""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    ns = NoOpSpan()
    try:
        ns.end(
            outputs={"result": "ok"},
            attributes={"done": True},
            status=SpanStatus(SpanStatusCode.OK),
            end_time_ns=int(time.time() * 1e9),
        )
    except Exception as e:
        assert False, f"NoOpSpan.end raised {type(e).__name__}: {e}"

    print("PASS: C8 - NoOpSpan.end does not raise")


# ── C9: NoOpSpan.end_time_ns is None ──────────────────────────────────

    # Contracts: C9
def check_C9_noop_end_time_ns_is_none():
    """NoOpSpan.end_time_ns must return None."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    assert ns.end_time_ns is None, f"Expected None, got {ns.end_time_ns}"

    print("PASS: C9 - NoOpSpan.end_time_ns is None")


# ── C10: NoOpSpan.name is None ────────────────────────────────────────

    # Contracts: C10
def check_C10_noop_name_is_none():
    """NoOpSpan.name must return None."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    assert ns.name is None, f"Expected None, got {ns.name}"

    print("PASS: C10 - NoOpSpan.name is None")


# ── C11: NoOpSpan.set_attribute no-op ─────────────────────────────────

    # Contracts: C11
def check_C11_noop_set_attribute_does_not_raise():
    """NoOpSpan.set_attribute(key, value) must not raise."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    try:
        ns.set_attribute("key", "value")
    except Exception as e:
        assert False, f"NoOpSpan.set_attribute raised {type(e).__name__}: {e}"

    print("PASS: C11 - NoOpSpan.set_attribute does not raise")


# ── C12: NoOpSpan.set_attributes no-op ────────────────────────────────

    # Contracts: C12
def check_C12_noop_set_attributes_does_not_raise():
    """NoOpSpan.set_attributes(attributes) must not raise."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    try:
        ns.set_attributes({"k": "v"})
    except Exception as e:
        assert False, f"NoOpSpan.set_attributes raised {type(e).__name__}: {e}"

    print("PASS: C12 - NoOpSpan.set_attributes does not raise")


# ── C13: NoOpSpan.set_inputs no-op ────────────────────────────────────

    # Contracts: C13
def check_C13_noop_set_inputs_does_not_raise():
    """NoOpSpan.set_inputs(inputs) must not raise."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    try:
        ns.set_inputs({"x": 1})
    except Exception as e:
        assert False, f"NoOpSpan.set_inputs raised {type(e).__name__}: {e}"

    print("PASS: C13 - NoOpSpan.set_inputs does not raise")


# ── C14: NoOpSpan.set_outputs no-op ───────────────────────────────────

    # Contracts: C14
def check_C14_noop_set_outputs_does_not_raise():
    """NoOpSpan.set_outputs(outputs) must not raise."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    try:
        ns.set_outputs({"y": 2})
    except Exception as e:
        assert False, f"NoOpSpan.set_outputs raised {type(e).__name__}: {e}"

    print("PASS: C14 - NoOpSpan.set_outputs does not raise")


# ── C15: NoOpSpan.set_status no-op ────────────────────────────────────

    # Contracts: C15
def check_C15_noop_set_status_does_not_raise():
    """NoOpSpan.set_status(status) must not raise."""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    ns = NoOpSpan()
    try:
        ns.set_status(SpanStatus(SpanStatusCode.OK))
    except Exception as e:
        assert False, f"NoOpSpan.set_status raised {type(e).__name__}: {e}"

    print("PASS: C15 - NoOpSpan.set_status does not raise")


# ── C16: NoOpSpan.span_id is None ─────────────────────────────────────

    # Contracts: C16
def check_C16_noop_span_id_is_none():
    """NoOpSpan.span_id must return None."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    assert ns.span_id is None, f"Expected None, got {ns.span_id}"

    print("PASS: C16 - NoOpSpan.span_id is None")


# ── C17: NoOpSpan.start_time_ns is None ──────────────────────────────

    # Contracts: C17
def check_C17_noop_start_time_ns_is_none():
    """NoOpSpan.start_time_ns must return None."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    assert ns.start_time_ns is None, f"Expected None, got {ns.start_time_ns}"

    print("PASS: C17 - NoOpSpan.start_time_ns is None")


# ── C18: NoOpSpan.status is None ──────────────────────────────────────

    # Contracts: C18
def check_C18_noop_status_is_none():
    """NoOpSpan.status must return None."""
    from mlflow.entities.span import NoOpSpan

    ns = NoOpSpan()
    assert ns.status is None, f"Expected None, got {ns.status}"

    print("PASS: C18 - NoOpSpan.status is None")


# ── C27: _CachedSpanAttributesRegistry.set raises ──────────────────────

    # Contracts: C27
def check_C27_cached_registry_set_raises():
    """_CachedSpanAttributesRegistry.set(key, value) must raise MlflowException."""
    from mlflow.entities.span import _CachedSpanAttributesRegistry
    from mlflow.exceptions import MlflowException

    otel = _make_mock_otel_span(123, 1, name="test")
    reg = _CachedSpanAttributesRegistry(otel)

    try:
        reg.set("key", "value")
        assert False, "Should have raised MlflowException"
    except MlflowException:
        pass  # expected

    print("PASS: C27 - _CachedSpanAttributesRegistry.set raises MlflowException")


# ── F3: LiveSpan.to_immutable_span strengthened ────────────────────────
# (Already covered by the strengthened C5 above. Added separate check
#  for immutable Span attribute mutation guard via CachedRegistry.)


# ── F5: to_dict ↔ from_dict roundtrip ──────────────────────────────────
# Reference: tests/entities/test_trace.py::test_trace_to_and_from_proto
# Perspective: P4 (full roundtrip verifies encoding consistency)

    # Contracts: C25, R24
def check_F5_span_to_dict_from_dict_roundtrip():
    """Span.to_dict() → Span.from_dict() roundtrip must preserve all fields."""
    import opentelemetry.trace as trace_api
    import mlflow.tracing.utils as tracing_utils
    from mlflow.entities import LiveSpan, Span, SpanEvent
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode
    from mlflow.tracing.constant import SpanAttributeKey

    start_time = int(time.time() * 1e9)
    end_time = start_time + 1000000
    otel = _make_mock_otel_span(0xAAAABBBBCCCCDDDD, 0x1111222233334444,
                                name="roundtrip_span",
                                start_time=start_time, end_time=end_time,
                                status=trace_api.Status(trace_api.StatusCode.OK))
    # Set required attributes for from_dict to work
    otel.set_attribute(
        SpanAttributeKey.REQUEST_ID,
        tracing_utils.dump_span_attribute_value("roundtrip-request-123"),
    )
    otel.set_attribute(
        SpanAttributeKey.SPAN_TYPE,
        tracing_utils.dump_span_attribute_value("LLM"),
    )

    live = LiveSpan(otel, "roundtrip-request-123", "LLM")
    live.set_inputs({"prompt": "hello"})
    live.set_outputs({"response": "world"})
    live.add_event(SpanEvent("step1", timestamp=start_time + 500,
                              attributes={"step": 1}))

    # Convert to immutable first
    span = live.to_immutable_span()

    # Serialize to dict
    data = span.to_dict()
    assert isinstance(data, dict), f"to_dict returned {type(data)}"

    # Deserialize back
    restored = Span.from_dict(data)
    assert isinstance(restored, Span), f"from_dict returned {type(restored)}"

    # Verify field-level equality
    assert restored.name == span.name, f"name: {restored.name} vs {span.name}"
    assert restored.span_type == span.span_type, \
        f"span_type: {restored.span_type} vs {span.span_type}"
    assert len(restored.events) == len(span.events), \
        f"events count: {len(restored.events)} vs {len(span.events)}"
    if len(restored.events) > 0:
        assert restored.events[0].name == span.events[0].name

    print("PASS: F5 - Span to_dict ↔ from_dict roundtrip preserves data")


# ── F7: Malformed-input test for Span.from_otel_proto ──────────────────
# Reference: tests/tracing/test_otel_logging.py (invalid format returns 400)
# Perspective: P7 (boundary behavior with minimal protobuf input)

    # Contracts: C22, R21
def check_F7_from_otel_proto_handles_minimal_input():
    """Span.from_otel_proto() must handle minimal protobuf (no attributes,
    no events, STATUS_CODE_UNSET) without raising."""
    from mlflow.entities import Span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    # Minimal protobuf: only trace_id and span_id, nothing else
    proto = OTelProtoSpan()
    proto.trace_id = b'\xAB' * 16
    proto.span_id = b'\xCD' * 8
    # name defaults to ""
    # start_time_unix_nano defaults to 0
    # end_time_unix_nano defaults to 0
    # status defaults to STATUS_CODE_UNSET (0)
    # no attributes, no events

    span = Span.from_otel_proto(proto)
    assert span is not None, "from_otel_proto returned None for minimal input"
    assert isinstance(span, Span), f"Expected Span, got {type(span)}"
    # Should have a valid trace_id
    assert span.trace_id is not None, "trace_id should not be None"

    # Test with STATUS_CODE_UNSET specifically
    proto2 = OTelProtoSpan()
    proto2.trace_id = b'\x01' * 16
    proto2.span_id = b'\x02' * 8
    proto2.name = "unset_status_test"
    # Leave status at default (STATUS_CODE_UNSET)
    span2 = Span.from_otel_proto(proto2)
    assert span2.name == "unset_status_test", f"name mismatch: {span2.name}"
    assert span2.status is not None, "status should not be None for UNSET code"

    print("PASS: F7 - Span.from_otel_proto handles minimal protobuf input")


# ── F8: NoOpSpan integration test with start_span failure path ─────────
# Reference: mlflow/tracing/fluent.py::start_span (except block yields NoOpSpan)
# Perspective: P8 (integration test verifies full context-manager lifecycle)

    # Contracts: C6-C18, R5-R18
def check_F8_noop_span_integration_in_start_span_failure():
    """Simulate span creation failure within mlflow.start_span and verify
    the full context-manager lifecycle works with NoOpSpan without raising."""
    from unittest.mock import patch

    from mlflow.entities.span import NoOpSpan
    from mlflow.entities import SpanEvent
    from mlflow.entities.span_status import SpanStatus, SpanStatusCode

    # Simulate the failure path: start_span catches exceptions and yields NoOpSpan
    # We test that the NoOpSpan survives the full lifecycle:
    # set_inputs → set_attribute → add_event → end (via __exit__)
    ns = NoOpSpan()
    assert isinstance(ns, NoOpSpan)

    # Simulate the context manager body
    try:
        ns.set_inputs({"query": "test"})
        ns.set_attribute("custom_key", "custom_value")
        ns.set_attributes({"batch": True})
        ns.set_outputs({"result": "ok"})
        ns.set_status(SpanStatus(SpanStatusCode.OK))
        ns.add_event(SpanEvent("checkpoint", timestamp=int(time.time() * 1e9),
                               attributes={"step": "middle"}))
    except Exception as e:
        assert False, f"NoOpSpan setter raised during simulated body: {type(e).__name__}: {e}"

    # Simulate the context manager exit (end)
    try:
        ns.end(
            outputs={"final": "done"},
            attributes={"completed": True},
            status=SpanStatus(SpanStatusCode.OK),
            end_time_ns=int(time.time() * 1e9),
        )
    except Exception as e:
        assert False, f"NoOpSpan.end raised during simulated exit: {type(e).__name__}: {e}"

    # Verify all NoOpSpan properties return expected sentinel values
    assert ns.span_id is None
    assert ns.name is None
    assert ns.start_time_ns is None
    assert ns.end_time_ns is None
    assert ns.status is None
    assert ns._trace_id is None

    print("PASS: F8 - NoOpSpan survives full context-manager lifecycle")


# ── runner ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    checks = [
        check_C2_to_mlflow_trace_calls_set_request_response_preview,
        check_C3_live_span_from_dict_raises_not_implemented,
        check_C4_live_span_set_span_type_stores_attribute,
        check_C5_live_span_to_immutable_preserves_data,
        check_C6_noop_trace_id_internal_is_none,
        check_C7_noop_add_event_does_not_raise,
        check_C8_noop_end_does_not_raise,
        check_C9_noop_end_time_ns_is_none,
        check_C10_noop_name_is_none,
        check_C11_noop_set_attribute_does_not_raise,
        check_C12_noop_set_attributes_does_not_raise,
        check_C13_noop_set_inputs_does_not_raise,
        check_C14_noop_set_outputs_does_not_raise,
        check_C15_noop_set_status_does_not_raise,
        check_C16_noop_span_id_is_none,
        check_C17_noop_start_time_ns_is_none,
        check_C18_noop_status_is_none,
        check_C27_cached_registry_set_raises,
        check_F5_span_to_dict_from_dict_roundtrip,
        check_F7_from_otel_proto_handles_minimal_input,
        check_F8_noop_span_integration_in_start_span_failure,
    ]

    failed = 0
    for check in checks:
        try:
            check()
        except Exception as e:
            failed += 1
            import traceback
            print(f"FAIL: {check.__name__}: {type(e).__name__}: {e}")
            traceback.print_exc()

    if failed:
        print(f"\n{failed} check(s) failed")
        sys.exit(1)
    else:
        print(f"\nAll {len(checks)} behavior checks passed")
