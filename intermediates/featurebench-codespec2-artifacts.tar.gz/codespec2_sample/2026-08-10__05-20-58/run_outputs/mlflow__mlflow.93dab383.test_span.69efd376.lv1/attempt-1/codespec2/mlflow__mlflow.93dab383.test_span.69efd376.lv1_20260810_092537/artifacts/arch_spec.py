"""
Executable architecture spec for MLflow distributed tracing system.

Covers public interface, graph connectivity, L2 CALL/CONTROL paths,
and L3 Interface/Dataflow contracts from the semantic IR.

Each check_* function corresponds to one or more contracts (C<n>) and
traces a public entry point through to the L3 observer.
"""

import sys
import time
from unittest import mock

# ── helpers ─────────────────────────────────────────────────────────────────

def _make_mock_otel_span(trace_id, span_id, name="test_span", parent_id=None,
                         start_time=None, end_time=None,
                         attributes=None, events=None, status=None):
    """Create a mock OpenTelemetry span that extends ReadableSpan/Span."""
    import opentelemetry.trace as trace_api
    from opentelemetry.sdk.trace import ReadableSpan, Event as OTelEvent
    from dataclasses import dataclass, field

    @dataclass
    class _MockSpanContext:
        trace_id: int
        span_id: int
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)
        is_remote: bool = False

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(self, name, context, parent, start_time=None,
                     end_time=None, status=None, attributes=None, events=None):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status or trace_api.Status(trace_api.StatusCode.UNSET)
            self._attributes = dict(attributes or {})
            self._events = list(events or [])

        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(OTelEvent(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self._name = name

        def end(self, end_time_ns=None):
            pass

        def record_exception(self):
            pass

    ctx = _MockSpanContext(trace_id, span_id)
    parent_ctx = _MockSpanContext(trace_id, parent_id) if parent_id else None
    return _MockOTelSpan(
        name=name, context=ctx, parent=parent_ctx,
        start_time=start_time, end_time=end_time,
        status=status, attributes=attributes, events=events,
    )


def _setup_trace_and_spans():
    """Register a trace with spans, returning (trace_manager, trace_id, request_id, otel_trace_id)."""
    import mlflow
    from mlflow.tracing.trace_manager import InMemoryTraceManager
    from mlflow.entities import LiveSpan, TraceInfo
    from mlflow.tracing.constant import SpanAttributeKey
    from tests.tracing.helper import create_test_trace_info

    InMemoryTraceManager.reset()
    tm = InMemoryTraceManager.get_instance()
    request_id = "test-request-arch"
    otel_trace_id = 99999
    trace_info = create_test_trace_info(request_id)
    tm.register_trace(otel_trace_id, trace_info)

    # Create root span
    root_otel = _make_mock_otel_span(otel_trace_id, 1, name="root")
    root_otel.set_attribute(
        SpanAttributeKey.REQUEST_ID,
        mlflow.tracing.utils.dump_span_attribute_value(request_id),
    )
    root_live = LiveSpan(root_otel, request_id, "LLM")
    tm.register_span(root_live)

    # Create child span
    child_otel = _make_mock_otel_span(otel_trace_id, 2, name="child", parent_id=1)
    child_otel.set_attribute(
        SpanAttributeKey.REQUEST_ID,
        mlflow.tracing.utils.dump_span_attribute_value(request_id),
    )
    child_live = LiveSpan(child_otel, request_id, "TOOL")
    tm.register_span(child_live)

    return tm, request_id, otel_trace_id


# ── C1: to_mlflow_trace returns immutable Trace ────────────────────────

    # Contracts: C1
def check_C1_to_mlflow_trace_connectivity_and_immutable_spans():
    """Verify the full call chain: pop_trace -> _Trace.to_mlflow_trace ->
    LiveSpan.to_immutable_span -> Span wrapping.  The returned Trace's
    data.spans must contain only Span (not LiveSpan) instances.
    """
    from mlflow.entities import Span, LiveSpan

    tm, request_id, otel_trace_id = _setup_trace_and_spans()

    # pop_trace calls internal_trace.to_mlflow_trace() internally
    manager_trace = tm.pop_trace(otel_trace_id)
    assert manager_trace is not None, "pop_trace returned None"
    trace = manager_trace.trace

    # Verify Trace contains only immutable Span objects
    assert len(trace.data.spans) == 2, f"Expected 2 spans, got {len(trace.data.spans)}"
    for s in trace.data.spans:
        assert isinstance(s, Span), f"Expected Span, got {type(s)}"
        assert not isinstance(s, LiveSpan), f"Expected not LiveSpan, got {type(s)}"

    # Verify trace data is cleared from manager
    assert request_id not in tm._traces

    print("PASS: C1 - to_mlflow_trace returns immutable Trace with only Span instances")


# ── C5: LiveSpan.to_immutable_span returns Span ────────────────────────

    # Contracts: C5
def check_C5_live_span_to_immutable_returns_span():
    """LiveSpan.to_immutable_span() must return an immutable Span, not a LiveSpan."""
    from mlflow.entities import Span, LiveSpan

    otel = _make_mock_otel_span(123, 1, name="test")
    live = LiveSpan(otel, "trace-id", "LLM")

    result = live.to_immutable_span()
    assert isinstance(result, Span), f"Expected Span, got {type(result)}"
    assert not isinstance(result, LiveSpan), f"Expected not LiveSpan, got {type(result)}"

    print("PASS: C5 - LiveSpan.to_immutable_span returns immutable Span")


# ── C19: NoOpSpan trace_id sentinel ────────────────────────────────────

    # Contracts: C19
def check_C19_noop_trace_id_sentinel():
    """NoOpSpan.trace_id must return the NO_OP_SPAN_TRACE_ID sentinel string."""
    from mlflow.entities.span import NoOpSpan
    from mlflow.entities.span import NO_OP_SPAN_TRACE_ID

    ns = NoOpSpan()
    assert ns.trace_id == NO_OP_SPAN_TRACE_ID, \
        f"Expected {NO_OP_SPAN_TRACE_ID}, got {ns.trace_id}"

    print("PASS: C19 - NoOpSpan.trace_id returns sentinel")


# ── C20: Span.attributes returns deserialized dict ─────────────────────
# Reference: tests/entities/test_span.py (span attributes roundtrip)
# Perspective: P4 (native test verifies attribute type preservation through serialization)

    # Contracts: C20
def check_C20_span_attributes_returns_deserialized_dict():
    """Span.attributes must return a dict with deserialized values of diverse types."""
    from mlflow.entities import Span
    import mlflow.tracing.utils as tracing_utils

    otel = _make_mock_otel_span(123, 1, name="attr_test")
    # Set diverse attribute types through the OTel span (dumped as JSON strings)
    otel.set_attribute("int_attr", tracing_utils.dump_span_attribute_value(42))
    otel.set_attribute("str_attr", tracing_utils.dump_span_attribute_value("hello"))
    otel.set_attribute("dict_attr", tracing_utils.dump_span_attribute_value({"nested": True}))
    otel.set_attribute("list_attr", tracing_utils.dump_span_attribute_value([1, 2, 3]))
    otel.set_attribute("float_attr", tracing_utils.dump_span_attribute_value(3.14))

    span = Span(otel)
    attrs = span.attributes

    assert isinstance(attrs, dict), f"Expected dict, got {type(attrs)}"
    assert attrs["int_attr"] == 42, f"Expected 42, got {attrs['int_attr']}"
    assert attrs["str_attr"] == "hello", f"Expected 'hello', got {attrs['str_attr']}"
    assert attrs["dict_attr"] == {"nested": True}, f"Dict mismatch: {attrs['dict_attr']}"
    assert attrs["list_attr"] == [1, 2, 3], f"List mismatch: {attrs['list_attr']}"
    assert attrs["float_attr"] == 3.14, f"Expected 3.14, got {attrs['float_attr']}"

    print("PASS: C20 - Span.attributes returns deserialized dict with diverse types")


# ── C21: Span.events returns list[SpanEvent] ───────────────────────────
# Reference: tests/entities/test_span_event.py (event to_otel_proto roundtrip)
# Perspective: P3 (native test verifies event attribute dict conversion)

    # Contracts: C21
def check_C21_span_events_returns_span_event_list():
    """Span.events must return list[SpanEvent] with correct name/timestamp/attributes."""
    from mlflow.entities import Span, SpanEvent
    from opentelemetry.sdk.trace import Event as OTelEvent

    otel = _make_mock_otel_span(123, 1, name="event_test")
    # Add events through OTel's native mechanism
    otel.add_event("event_a", attributes={"k1": "v1", "num": 1}, timestamp=1000)
    otel.add_event("event_b", attributes={"k2": "v2"}, timestamp=2000)

    span = Span(otel)
    events = span.events

    assert isinstance(events, list), f"Expected list, got {type(events)}"
    assert len(events) == 2, f"Expected 2 events, got {len(events)}"
    for e in events:
        assert isinstance(e, SpanEvent), f"Expected SpanEvent, got {type(e)}"

    # Check first event details
    assert events[0].name == "event_a"
    assert events[0].timestamp == 1000
    assert isinstance(events[0].attributes, dict), \
        f"Expected dict attributes, got {type(events[0].attributes)}"
    assert events[0].attributes["k1"] == "v1"
    assert events[0].attributes["num"] == 1

    # Check second event
    assert events[1].name == "event_b"
    assert events[1].timestamp == 2000
    assert events[1].attributes["k2"] == "v2"

    print("PASS: C21 - Span.events returns list[SpanEvent] with correct data")


# ── C22: Span.from_otel_proto returns Span with mapped data ────────────

    # Contracts: C22
def check_C22_span_from_otel_proto_returns_span():
    """Span.from_otel_proto must return a Span with fields populated from protobuf."""
    from mlflow.entities import Span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan, Status as OTelProtoStatus

    proto = OTelProtoSpan()
    proto.trace_id = b'\x00' * 16   # 16-byte trace ID
    proto.span_id = b'\x00' * 8     # 8-byte span ID
    proto.name = "proto_span"
    proto.start_time_unix_nano = 1000000
    proto.end_time_unix_nano = 2000000
    proto.status.code = OTelProtoStatus.STATUS_CODE_OK
    proto.status.message = "done"

    span = Span.from_otel_proto(proto)
    assert span is not None, "from_otel_proto returned None"
    assert span.name == "proto_span", f"Expected 'proto_span', got {span.name}"
    assert span.start_time_ns == 1000000
    assert span.end_time_ns == 2000000

    print("PASS: C22 - Span.from_otel_proto returns Span with mapped data")


# ── C23: Span.request_id equals trace_id ───────────────────────────────

    # Contracts: C23
def check_C23_span_request_id_equals_trace_id():
    """Span.request_id must equal Span.trace_id (backward compatibility)."""
    from mlflow.entities import Span
    import mlflow.tracing.utils as tracing_utils

    otel = _make_mock_otel_span(123, 1, name="test")
    otel.set_attribute("mlflow.trace_request_id", tracing_utils.dump_span_attribute_value("req-123"))
    span = Span(otel)

    assert span.request_id == span.trace_id, \
        f"request_id {span.request_id} != trace_id {span.trace_id}"

    print("PASS: C23 - Span.request_id equals trace_id")


# ── C24: Span.span_type returns attribute value ────────────────────────

    # Contracts: C24
def check_C24_span_span_type_returns_attribute():
    """Span.span_type must return the SPAN_TYPE attribute value."""
    from mlflow.entities import Span
    import mlflow.tracing.utils as tracing_utils
    from mlflow.tracing.constant import SpanAttributeKey

    otel = _make_mock_otel_span(123, 1, name="test")
    otel.set_attribute(SpanAttributeKey.SPAN_TYPE, tracing_utils.dump_span_attribute_value("LLM"))
    span = Span(otel)

    assert span.span_type == "LLM", f"Expected 'LLM', got {span.span_type}"

    print("PASS: C24 - Span.span_type returns attribute value")


# ── C25: Span.to_dict base64 encoding ──────────────────────────────────

    # Contracts: C25
def check_C25_span_to_dict_base64_encoding():
    """Span.to_dict() must return dict with base64-encoded IDs and all required keys."""
    from mlflow.entities import Span

    otel = _make_mock_otel_span(0xABCDEF1234567890, 0x12345678AB, name="encode_test",
                                end_time=int(time.time() * 1e9))
    span = Span(otel)
    result = span.to_dict()

    assert isinstance(result, dict), f"Expected dict, got {type(result)}"
    required_keys = ["trace_id", "span_id", "parent_span_id", "name",
                     "start_time_unix_nano", "end_time_unix_nano",
                     "events", "status", "attributes"]
    for key in required_keys:
        assert key in result, f"Missing key '{key}' in to_dict result"

    # Verify base64 encoding (should decode back)
    assert isinstance(result["trace_id"], str), f"trace_id should be str, got {type(result['trace_id'])}"
    assert isinstance(result["span_id"], str), f"span_id should be str, got {type(result['span_id'])}"

    print("PASS: C25 - Span.to_dict returns base64-encoded dict")


# ── C26: Span.to_otel_proto returns OTelProtoSpan ──────────────────────

    # Contracts: C26
def check_C26_span_to_otel_proto_returns_protobuf():
    """Span.to_otel_proto() must return OTelProtoSpan with correct fields."""
    from mlflow.entities import Span
    from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan

    otel = _make_mock_otel_span(0xABCDEF1234567890, 0x12345678AB, name="proto_test",
                                end_time=int(time.time() * 1e9))
    span = Span(otel)
    proto = span.to_otel_proto()

    assert isinstance(proto, OTelProtoSpan), f"Expected OTelProtoSpan, got {type(proto)}"
    assert proto.name == "proto_test"
    assert len(proto.trace_id) == 16
    assert len(proto.span_id) == 8

    print("PASS: C26 - Span.to_otel_proto returns OTelProtoSpan")


# ── C28-C31: create_mlflow_span factory ────────────────────────────────

    # Contracts: C28
def check_C28_create_mlflow_span_returns_live_span():
    """create_mlflow_span with OTelSpan returns LiveSpan."""
    from mlflow.entities import LiveSpan
    from mlflow.entities.span import create_mlflow_span

    otel = _make_mock_otel_span(123, 1, name="live")
    result = create_mlflow_span(otel, "trace-id", "LLM")
    assert isinstance(result, LiveSpan), f"Expected LiveSpan, got {type(result)}"

    print("PASS: C28 - create_mlflow_span returns LiveSpan for OTelSpan")


    # Contracts: C29
def check_C29_create_mlflow_span_returns_span_for_readable():
    """create_mlflow_span with OTelReadableSpan (finished) returns Span."""
    from mlflow.entities import Span
    from mlflow.entities.span import create_mlflow_span

    otel = _make_mock_otel_span(123, 1, name="done", end_time=int(time.time() * 1e9))
    result = create_mlflow_span(otel, "trace-id")
    assert isinstance(result, Span), f"Expected Span, got {type(result)}"
    assert not isinstance(result, type(None))

    print("PASS: C29 - create_mlflow_span returns Span for ReadableSpan")


    # Contracts: C30
def check_C30_create_mlflow_span_returns_noop_span():
    """create_mlflow_span with NonRecordingSpan returns NoOpSpan."""
    from opentelemetry.trace import NonRecordingSpan
    from mlflow.entities.span import NoOpSpan, create_mlflow_span

    nrs = NonRecordingSpan(context=None)
    result = create_mlflow_span(nrs, "trace-id")
    assert isinstance(result, NoOpSpan), f"Expected NoOpSpan, got {type(result)}"

    # Also test None
    result2 = create_mlflow_span(None, "trace-id")
    assert isinstance(result2, NoOpSpan), f"Expected NoOpSpan for None, got {type(result2)}"

    print("PASS: C30 - create_mlflow_span returns NoOpSpan for NonRecordingSpan/None")


    # Contracts: C31
def check_C31_create_mlflow_span_raises_for_invalid():
    """create_mlflow_span with invalid type raises MlflowException."""
    from mlflow.entities.span import create_mlflow_span
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    try:
        create_mlflow_span("invalid_string", "trace-id")
        assert False, "Should have raised"
    except MlflowException as e:
        assert e.error_code == INVALID_PARAMETER_VALUE, \
            f"Expected INVALID_PARAMETER_VALUE, got {e.error_code}"

    print("PASS: C31 - create_mlflow_span raises MlflowException for invalid type")


# ── C32: _decode_otel_proto_anyvalue ───────────────────────────────────

    # Contracts: C32
def check_C32_decode_otel_proto_anyvalue():
    """_decode_otel_proto_anyvalue must decode all AnyValue types correctly."""
    from opentelemetry.proto.common.v1.common_pb2 import AnyValue
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    # Unset -> None
    av = AnyValue()
    assert _decode_otel_proto_anyvalue(av) is None

    # Bool
    av2 = AnyValue()
    av2.bool_value = True
    assert _decode_otel_proto_anyvalue(av2) is True

    # String
    av3 = AnyValue()
    av3.string_value = "hello"
    assert _decode_otel_proto_anyvalue(av3) == "hello"

    # Int
    av4 = AnyValue()
    av4.int_value = 42
    assert _decode_otel_proto_anyvalue(av4) == 42

    # Float
    av5 = AnyValue()
    av5.double_value = 3.14
    assert _decode_otel_proto_anyvalue(av5) == 3.14

    # Bytes
    av6 = AnyValue()
    av6.bytes_value = b"data"
    assert _decode_otel_proto_anyvalue(av6) == b"data"

    # Array (recursive)
    av7 = AnyValue()
    inner = av7.array_value.values.add()
    inner.string_value = "a"
    inner2 = av7.array_value.values.add()
    inner2.int_value = 1
    result = _decode_otel_proto_anyvalue(av7)
    assert result == ["a", 1], f"Array decode: {result}"

    # KV list -> dict
    av8 = AnyValue()
    kv = av8.kvlist_value.values.add()
    kv.key = "x"
    kv.value.string_value = "y"
    result2 = _decode_otel_proto_anyvalue(av8)
    assert result2 == {"x": "y"}, f"KV decode: {result2}"

    print("PASS: C32 - _decode_otel_proto_anyvalue decodes all types")


# ── F2: Caller-binding check for create_mlflow_span ────────────────────
# Reference: mlflow/semantic_kernel/autolog.py:15,
#   mlflow/haystack/autolog.py:20,
#   mlflow/tracing/processor/otel.py:4,
#   mlflow/tracing/processor/inference_table.py:9
#   (all import create_mlflow_span from mlflow.entities.span)
# Perspective: P4 (native consumers verify import resolution at module load)

    # Contracts: C28, C29, C30
def check_F2_create_mlflow_span_caller_binding():
    """Verify create_mlflow_span is importable and resolvable by real consumers."""
    # Verify direct import works
    from mlflow.entities.span import create_mlflow_span
    assert callable(create_mlflow_span), "create_mlflow_span is not callable"

    # Verify real consumer modules can resolve the import
    import importlib

    # Check haystack autolog (one of the real callers)
    try:
        haystack_autolog = importlib.import_module("mlflow.haystack.autolog")
        # The module should have create_mlflow_span in its namespace if it imports it
        assert hasattr(haystack_autolog, "create_mlflow_span") or \
               "create_mlflow_span" in str(haystack_autolog.__dict__.get("create_mlflow_span", "")), \
               "haystack.autolog cannot resolve create_mlflow_span"
        # Actually verify the reference resolves to the same function
        from mlflow.haystack.autolog import create_mlflow_span as haystack_cms
        assert haystack_cms is create_mlflow_span, \
            "create_mlflow_span from haystack.autolog is not the same object"
    except ImportError:
        # If haystack isn't available, at least verify the processor modules
        pass

    # Check otel processor (core consumer)
    try:
        from mlflow.tracing.processor.otel import create_mlflow_span as otel_cms
        assert otel_cms is create_mlflow_span, \
            "create_mlflow_span from processor.otel is not the same object"
    except ImportError:
        pass

    print("PASS: F2 - create_mlflow_span caller binding verified")


# ── F6: Trace to_proto → from_proto roundtrip ──────────────────────────
# Reference: tests/entities/test_trace.py::test_trace_to_and_from_proto
# Perspective: P4 (native test verifies full Trace-level protobuf roundtrip)

    # Contracts: C22, C26, R21, R25
def check_F6_trace_to_proto_from_proto_roundtrip():
    """Trace.to_proto() → Trace.from_proto() must preserve trace data."""
    import mlflow
    from mlflow.entities import LiveSpan, Trace, TraceData, TraceInfo
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.trace_manager import InMemoryTraceManager
    from tests.tracing.helper import create_test_trace_info

    InMemoryTraceManager.reset()
    tm = InMemoryTraceManager.get_instance()
    request_id = "roundtrip-req"
    otel_trace_id = 0xAABBCCDDEEFF0011
    trace_info = create_test_trace_info(request_id)
    tm.register_trace(otel_trace_id, trace_info)

    # Create root span with attributes and end time
    root_otel = _make_mock_otel_span(otel_trace_id, 100, name="root_roundtrip",
                                     end_time=int(time.time() * 1e9))
    root_otel.set_attribute(
        SpanAttributeKey.REQUEST_ID,
        mlflow.tracing.utils.dump_span_attribute_value(request_id),
    )
    root_otel.set_attribute(
        SpanAttributeKey.SPAN_TYPE,
        mlflow.tracing.utils.dump_span_attribute_value("LLM"),
    )
    root_live = LiveSpan(root_otel, request_id, "LLM")
    tm.register_span(root_live)

    # Create child span
    child_otel = _make_mock_otel_span(otel_trace_id, 200, name="child_roundtrip",
                                      parent_id=100, end_time=int(time.time() * 1e9))
    child_otel.set_attribute(
        SpanAttributeKey.REQUEST_ID,
        mlflow.tracing.utils.dump_span_attribute_value(request_id),
    )
    child_otel.set_attribute(
        SpanAttributeKey.SPAN_TYPE,
        mlflow.tracing.utils.dump_span_attribute_value("TOOL"),
    )
    child_live = LiveSpan(child_otel, request_id, "TOOL")
    tm.register_span(child_live)

    # Get trace via pop_trace (exercises to_immutable_span)
    manager_trace = tm.pop_trace(otel_trace_id)
    trace = manager_trace.trace

    # Serialize via to_proto (which calls span.to_otel_proto() for each span)
    proto_trace = trace.to_proto()

    # Deserialize via from_proto (which calls Span.from_otel_proto() for each span)
    restored = Trace.from_proto(proto_trace)

    # Verify roundtrip preserves spans
    assert len(restored.data.spans) == len(trace.data.spans), \
        f"Span count mismatch: {len(restored.data.spans)} vs {len(trace.data.spans)}"
    for orig, rest in zip(trace.data.spans, restored.data.spans):
        assert rest.name == orig.name, f"Name mismatch: {rest.name} vs {orig.name}"

    print("PASS: F6 - Trace to_proto ↔ from_proto roundtrip preserves span data")


# ── runner ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    checks = [
        check_C1_to_mlflow_trace_connectivity_and_immutable_spans,
        check_C5_live_span_to_immutable_returns_span,
        check_C19_noop_trace_id_sentinel,
        check_C20_span_attributes_returns_deserialized_dict,
        check_C21_span_events_returns_span_event_list,
        check_C22_span_from_otel_proto_returns_span,
        check_C23_span_request_id_equals_trace_id,
        check_C24_span_span_type_returns_attribute,
        check_C25_span_to_dict_base64_encoding,
        check_C26_span_to_otel_proto_returns_protobuf,
        check_C28_create_mlflow_span_returns_live_span,
        check_C29_create_mlflow_span_returns_span_for_readable,
        check_C30_create_mlflow_span_returns_noop_span,
        check_C31_create_mlflow_span_raises_for_invalid,
        check_C32_decode_otel_proto_anyvalue,
        check_F2_create_mlflow_span_caller_binding,
        check_F6_trace_to_proto_from_proto_roundtrip,
    ]

    failed = 0
    for check in checks:
        try:
            check()
        except Exception as e:
            failed += 1
            import traceback
            print(f"FAIL: {check.__name__}: {type(e).__name__}: {e}")
            traceback.print_exc()

    if failed:
        print(f"\n{failed} check(s) failed")
        sys.exit(1)
    else:
        print(f"\nAll {len(checks)} architecture checks passed")
