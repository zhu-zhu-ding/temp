#!/usr/bin/env python3
"""
Executable architecture spec for MLflow tracing and assessment data management.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check_* function is a no-argument executable assertion that begins at a
public entry point and reaches the L3 observer.
"""

import sys
import warnings

# ──────────────────────────────────────────────────────────────────────────────
# C1: assessment_to_proto field mapping (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C1


def check_assessment_to_proto_connectivity() -> None:
    """Verify assessment_to_proto exists with correct signature and call chain."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto

    assert callable(assessment_to_proto), "assessment_to_proto must be callable"

    from mlflow.entities import Assessment
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
    from mlflow.protos import databricks_tracing_pb2 as pb

    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="tester")
    assessment = Assessment(
        name="test_assessment",
        trace_id="trace:/catalog.schema/trace123",
        source=source,
        create_time_ms=1000,
        last_update_time_ms=2000,
    )

    result = assessment_to_proto(assessment)
    assert isinstance(result, pb.Assessment), f"Expected pb.Assessment, got {type(result)}"
    # Core field mapping
    assert result.assessment_name == "test_assessment", "assessment_name mismatch"
    # Timestamps should be in protobuf Timestamp format (FromMilliseconds)
    assert result.create_time.ToMilliseconds() == 1000, "create_time mismatch"
    assert result.last_update_time.ToMilliseconds() == 2000, "last_update_time mismatch"

    print("PASS: check_assessment_to_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C2: get_trace_id_from_assessment_proto v4 construction (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C2


def check_get_trace_id_from_assessment_proto_connectivity() -> None:
    """Verify get_trace_id_from_assessment_proto uses construct_trace_id_v4 (E3)."""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import databricks_tracing_pb2 as pb

    assert callable(get_trace_id_from_assessment_proto), (
        "get_trace_id_from_assessment_proto must be callable"
    )

    # Proto with UC schema trace_location → v4 trace_id construction
    proto = pb.Assessment()
    proto.trace_id = "raw_trace_123"
    proto.trace_location.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto.trace_location.uc_schema.catalog_name = "my_catalog"
    proto.trace_location.uc_schema.schema_name = "my_schema"

    result = get_trace_id_from_assessment_proto(proto)
    assert isinstance(result, str), f"Expected str, got {type(result)}"
    assert "my_catalog.my_schema" in result, "v4 trace_id should contain catalog.schema"
    assert "raw_trace_123" in result, "v4 trace_id should contain raw trace_id"

    # Proto without UC schema → raw trace_id
    proto2 = pb.Assessment()
    proto2.trace_id = "simple_trace_id"
    result2 = get_trace_id_from_assessment_proto(proto2)
    assert result2 == "simple_trace_id", (
        f"Expected simple_trace_id, got {result2}"
    )

    print("PASS: check_get_trace_id_from_assessment_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C3: inference_table_location_to_proto mapping (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C3


def check_inference_table_location_to_proto_connectivity() -> None:
    """Verify inference_table_location_to_proto maps full_table_name (E4)."""
    from mlflow.utils.databricks_tracing_utils import inference_table_location_to_proto
    from mlflow.entities.trace_location import InferenceTableLocation
    from mlflow.protos import databricks_tracing_pb2 as pb

    loc = InferenceTableLocation(full_table_name="catalog.schema.table")
    result = inference_table_location_to_proto(loc)

    assert isinstance(result, pb.InferenceTableLocation), (
        f"Expected pb.InferenceTableLocation, got {type(result)}"
    )
    assert result.full_table_name == "catalog.schema.table", "full_table_name mismatch"

    print("PASS: check_inference_table_location_to_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C4: mlflow_experiment_location_to_proto mapping (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C4


def check_mlflow_experiment_location_to_proto_connectivity() -> None:
    """Verify mlflow_experiment_location_to_proto maps experiment_id (E5)."""
    from mlflow.utils.databricks_tracing_utils import mlflow_experiment_location_to_proto
    from mlflow.entities.trace_location import MlflowExperimentLocation
    from mlflow.protos import databricks_tracing_pb2 as pb

    loc = MlflowExperimentLocation(experiment_id="exp_42")
    result = mlflow_experiment_location_to_proto(loc)

    assert isinstance(result, pb.MlflowExperimentLocation), (
        f"Expected pb.MlflowExperimentLocation, got {type(result)}"
    )
    assert result.experiment_id == "exp_42", "experiment_id mismatch"

    print("PASS: check_mlflow_experiment_location_to_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C5: trace_from_proto composition (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C5


def check_trace_from_proto_connectivity() -> None:
    """Verify trace_from_proto constructs Trace with info and spans (E6)."""
    from mlflow.utils.databricks_tracing_utils import trace_from_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities import Trace

    assert callable(trace_from_proto), "trace_from_proto must be callable"

    proto = pb.Trace()
    proto.trace_info.trace_id = "test_trace"
    proto.trace_info.request_time.FromMilliseconds(1000)
    proto.trace_info.state = pb.TraceInfo.State.OK

    result = trace_from_proto(proto, location_id="test_location")
    assert isinstance(result, Trace), f"Expected Trace, got {type(result)}"
    assert result.info is not None, "Trace must have info"
    assert result.data is not None, "Trace must have data"

    print("PASS: check_trace_from_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C6: trace_info_to_v4_proto composition (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C6


def check_trace_info_to_v4_proto_connectivity() -> None:
    """Verify trace_info_to_v4_proto constructs proto with trace_id parsing (E7)."""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState

    assert callable(trace_info_to_v4_proto), "trace_info_to_v4_proto must be callable"

    # UC_SCHEMA location → v4 trace_id parsing
    trace_info = TraceInfo(
        trace_id="trace:/cat.sch/trace_v4",
        trace_location=TraceLocation(
            type=TraceLocationType.UC_SCHEMA,
            uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
        ),
        request_time=3000,
        state=TraceState.OK,
        client_request_id="req_1",
        request_preview='{"q":"hi"}',
        response_preview='{"a":"hello"}',
    )

    result = trace_info_to_v4_proto(trace_info)
    assert isinstance(result, pb.TraceInfo), f"Expected pb.TraceInfo, got {type(result)}"
    # v4 trace_id should be parsed (only the actual trace_id part)
    assert result.trace_id == "trace_v4", f"trace_id mismatch: {result.trace_id}"
    assert result.client_request_id == "req_1", "client_request_id mismatch"

    print("PASS: check_trace_info_to_v4_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C7: trace_location_from_proto dispatch (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C7


def check_trace_location_from_proto_dispatch() -> None:
    """Verify trace_location_from_proto dispatches on WhichOneof (E8)."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities.trace_location import TraceLocationType

    assert callable(trace_location_from_proto), "trace_location_from_proto must be callable"

    # UC_SCHEMA dispatch
    proto_uc = pb.TraceLocation()
    proto_uc.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto_uc.uc_schema.catalog_name = "test_cat"
    proto_uc.uc_schema.schema_name = "test_sch"

    result_uc = trace_location_from_proto(proto_uc)
    assert result_uc.type == TraceLocationType.UC_SCHEMA, (
        f"Expected UC_SCHEMA, got {result_uc.type}"
    )
    assert result_uc.uc_schema is not None, "uc_schema must be populated"
    assert result_uc.uc_schema.catalog_name == "test_cat", "catalog_name mismatch"
    assert result_uc.uc_schema.schema_name == "test_sch", "schema_name mismatch"

    # MLFLOW_EXPERIMENT dispatch
    proto_exp = pb.TraceLocation()
    proto_exp.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto_exp.mlflow_experiment.experiment_id = "exp_99"

    result_exp = trace_location_from_proto(proto_exp)
    assert result_exp.type == TraceLocationType.MLFLOW_EXPERIMENT, (
        f"Expected MLFLOW_EXPERIMENT, got {result_exp.type}"
    )
    assert result_exp.mlflow_experiment is not None, "mlflow_experiment must be populated"
    assert result_exp.mlflow_experiment.experiment_id == "exp_99", "experiment_id mismatch"

    # INFERENCE_TABLE dispatch
    proto_inf = pb.TraceLocation()
    proto_inf.type = pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    proto_inf.inference_table.full_table_name = "cat.sch.tbl"

    result_inf = trace_location_from_proto(proto_inf)
    assert result_inf.type == TraceLocationType.INFERENCE_TABLE, (
        f"Expected INFERENCE_TABLE, got {result_inf.type}"
    )
    assert result_inf.inference_table is not None, "inference_table must be populated"
    assert result_inf.inference_table.full_table_name == "cat.sch.tbl", "full_table_name mismatch"

    # Unspecified fallback
    proto_unspec = pb.TraceLocation()
    proto_unspec.type = pb.TraceLocation.TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED
    result_unspec = trace_location_from_proto(proto_unspec)
    assert result_unspec.type == TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED, (
        f"Expected TRACE_LOCATION_TYPE_UNSPECIFIED, got {result_unspec.type}"
    )

    print("PASS: check_trace_location_from_proto_dispatch")


# ──────────────────────────────────────────────────────────────────────────────
# C8: trace_location_to_proto dispatch (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C8


def check_trace_location_to_proto_dispatch() -> None:
    """Verify trace_location_to_proto dispatches on location type (E9)."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.protos import databricks_tracing_pb2 as pb

    assert callable(trace_location_to_proto), "trace_location_to_proto must be callable"

    # UC_SCHEMA
    loc_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="c", schema_name="s"),
    )
    result_uc = trace_location_to_proto(loc_uc)
    assert isinstance(result_uc, pb.TraceLocation), f"Expected pb.TraceLocation, got {type(result_uc)}"
    assert result_uc.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA, "type mismatch"
    assert result_uc.uc_schema.catalog_name == "c", "catalog_name mismatch"
    assert result_uc.uc_schema.schema_name == "s", "schema_name mismatch"

    # MLFLOW_EXPERIMENT
    loc_exp = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="e99"),
    )
    result_exp = trace_location_to_proto(loc_exp)
    assert result_exp.type == pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT, "type mismatch"
    assert result_exp.mlflow_experiment.experiment_id == "e99", "experiment_id mismatch"

    # INFERENCE_TABLE
    loc_inf = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="a.b.c"),
    )
    result_inf = trace_location_to_proto(loc_inf)
    assert result_inf.type == pb.TraceLocation.TraceLocationType.INFERENCE_TABLE, "type mismatch"
    assert result_inf.inference_table.full_table_name == "a.b.c", "full_table_name mismatch"

    print("PASS: check_trace_location_to_proto_dispatch")


# ──────────────────────────────────────────────────────────────────────────────
# C9: trace_to_proto composition (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C9


def check_trace_to_proto_connectivity() -> None:
    """Verify trace_to_proto converts Trace info and spans to proto (E10)."""
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities import Trace, TraceData, TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        MlflowExperimentLocation,
    )
    from mlflow.entities.trace_state import TraceState

    assert callable(trace_to_proto), "trace_to_proto must be callable"

    trace_info = TraceInfo(
        trace_id="trace_id_xyz",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp_1"),
        ),
        request_time=5000,
        state=TraceState.OK,
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[]))

    result = trace_to_proto(trace)
    assert isinstance(result, pb.Trace), f"Expected pb.Trace, got {type(result)}"
    assert result.trace_info.trace_id == "trace_id_xyz", "trace_id mismatch"
    # Even with empty spans, the spans field should exist
    assert result.spans is not None, "spans must not be None"

    print("PASS: check_trace_to_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C10: uc_schema_location_from_proto (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C10


def check_uc_schema_location_from_proto_connectivity() -> None:
    """Verify uc_schema_location_from_proto constructs UCSchemaLocation (E11)."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities.trace_location import UCSchemaLocation

    assert callable(uc_schema_location_from_proto), (
        "uc_schema_location_from_proto must be callable"
    )

    proto = pb.UCSchemaLocation()
    proto.catalog_name = "my_catalog"
    proto.schema_name = "my_schema"

    result = uc_schema_location_from_proto(proto)
    assert isinstance(result, UCSchemaLocation), (
        f"Expected UCSchemaLocation, got {type(result)}"
    )
    assert result.catalog_name == "my_catalog", "catalog_name mismatch"
    assert result.schema_name == "my_schema", "schema_name mismatch"

    print("PASS: check_uc_schema_location_from_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C11: uc_schema_location_to_proto (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C11


def check_uc_schema_location_to_proto_connectivity() -> None:
    """Verify uc_schema_location_to_proto maps all fields to proto (E12)."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto
    from mlflow.entities.trace_location import UCSchemaLocation
    from mlflow.protos import databricks_tracing_pb2 as pb

    assert callable(uc_schema_location_to_proto), (
        "uc_schema_location_to_proto must be callable"
    )

    loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    loc._otel_spans_table_name = "spans_tbl"
    loc._otel_logs_table_name = "logs_tbl"

    result = uc_schema_location_to_proto(loc)
    assert isinstance(result, pb.UCSchemaLocation), (
        f"Expected pb.UCSchemaLocation, got {type(result)}"
    )
    assert result.catalog_name == "cat", "catalog_name mismatch"
    assert result.schema_name == "sch", "schema_name mismatch"
    assert result.otel_spans_table_name == "spans_tbl", "otel_spans_table_name mismatch"
    assert result.otel_logs_table_name == "logs_tbl", "otel_logs_table_name mismatch"

    print("PASS: check_uc_schema_location_to_proto_connectivity")


# ──────────────────────────────────────────────────────────────────────────────
# C12: AssessmentSourceType._standardize interface (Interface)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C12


def check_assessment_source_type_standardize_interface() -> None:
    """Verify AssessmentSourceType._standardize normalizes source_type strings."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    # _standardize must exist as a static method
    assert hasattr(AssessmentSourceType, "_standardize"), (
        "AssessmentSourceType must have _standardize static method"
    )

    # Case normalization
    assert AssessmentSourceType._standardize("human") == "HUMAN", (
        "Should normalize to uppercase"
    )
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN", (
        "Should preserve uppercase"
    )
    assert AssessmentSourceType._standardize("code") == "CODE", (
        "Should normalize to uppercase"
    )

    print("PASS: check_assessment_source_type_standardize_interface")


# ──────────────────────────────────────────────────────────────────────────────
# C18: Span.inputs reads from attributes (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: tests/entities/test_span.py::test_create_live_span
# Contracts: C18


def check_span_inputs_dataflow() -> None:
    """Verify Span.inputs property returns deserialized attribute value, or None.

    Perspective P1: Create a real Span/LiveSpan with inputs stored as serialized
    attribute, verify the property deserializes to the original Python value.
    """
    from mlflow.entities.span import Span, LiveSpan, create_mlflow_span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.provider import _get_tracer

    # Verify the attribute key constant
    assert SpanAttributeKey.INPUTS == "mlflow.spanInputs", (
        f"Expected 'mlflow.spanInputs', got {SpanAttributeKey.INPUTS!r}"
    )

    # Create a real LiveSpan and set inputs, then verify property deserialization.
    # This exercises the full serialization→deserialization pipeline.
    tracer = _get_tracer("test_arch_inputs")
    with tracer.start_as_current_span("arch_inputs_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_arch_inputs")
        assert isinstance(span, LiveSpan), f"Expected LiveSpan, got {type(span)}"

        # Set complex nested inputs
        test_inputs = {"query": "What is ML?", "params": {"temp": 0.7, "max_tokens": 100}}
        span.set_inputs(test_inputs)

        # Verify the property deserializes back to the original Python object
        assert hasattr(span, "inputs"), "Span must have 'inputs' property"
        result = span.inputs
        assert result == test_inputs, (
            f"inputs property should return deserialized value. Expected {test_inputs!r}, got {result!r}"
        )

        # Verify None when inputs not set (on a different span)
        with tracer.start_as_current_span("no_inputs_span") as otel_span2:
            span2 = create_mlflow_span(otel_span2, trace_id="trace_no_inputs")
            if hasattr(span2, "inputs"):
                # A newly created span without set_inputs may have None
                assert span2.inputs is None, (
                    "inputs property should return None when not set"
                )

    print("PASS: check_span_inputs_dataflow")


# ──────────────────────────────────────────────────────────────────────────────
# C19: Span.outputs reads from attributes (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: tests/entities/test_span.py::test_create_live_span
# Contracts: C19


def check_span_outputs_dataflow() -> None:
    """Verify Span.outputs property returns deserialized attribute value, or None.

    Perspective P1: Create a real Span/LiveSpan with outputs stored as serialized
    attribute, verify the property deserializes to the original Python value.
    """
    from mlflow.entities.span import LiveSpan, create_mlflow_span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.provider import _get_tracer

    # Verify the attribute key constant
    assert SpanAttributeKey.OUTPUTS == "mlflow.spanOutputs", (
        f"Expected 'mlflow.spanOutputs', got {SpanAttributeKey.OUTPUTS!r}"
    )

    # Create a real LiveSpan and set outputs, then verify property deserialization.
    tracer = _get_tracer("test_arch_outputs")
    with tracer.start_as_current_span("arch_outputs_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_arch_outputs")
        assert isinstance(span, LiveSpan), f"Expected LiveSpan, got {type(span)}"

        # Set integer output (not just dict)
        span.set_outputs(42)

        # Verify the property deserializes back correctly
        assert hasattr(span, "outputs"), "Span must have 'outputs' property"
        result = span.outputs
        assert result == 42, (
            f"outputs property should return deserialized value. Expected 42, got {result!r}"
        )

        # Verify None when outputs not set
        with tracer.start_as_current_span("no_outputs_span") as otel_span2:
            span2 = create_mlflow_span(otel_span2, trace_id="trace_no_outputs")
            if hasattr(span2, "outputs"):
                assert span2.outputs is None, (
                    "outputs property should return None when not set"
                )

    print("PASS: check_span_outputs_dataflow")


# ──────────────────────────────────────────────────────────────────────────────
# C20: trace_info_to_v4_proto import boundary (Interface)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C20


def check_trace_info_to_v4_proto_import_boundary() -> None:
    """Verify TraceInfo.to_proto calls trace_info_to_v4_proto when _is_v4() is True.

    Execution-based: creates a TraceInfo with UC_SCHEMA location (triggering
    _is_v4() → True), calls to_proto(), and verifies the result contains parsed
    trace_id from the v4 path.
    """
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState

    # Verify the function is importable from the declared module
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    assert callable(trace_info_to_v4_proto), "trace_info_to_v4_proto must be callable"

    # Create TraceInfo with UC_SCHEMA location → _is_v4() returns True
    trace_info = TraceInfo(
        trace_id="trace:/my_catalog.my_schema/real_trace_42",
        trace_location=TraceLocation(
            type=TraceLocationType.UC_SCHEMA,
            uc_schema=UCSchemaLocation(catalog_name="my_catalog", schema_name="my_schema"),
        ),
        request_time=1000000,
        state=TraceState.OK,
        client_request_id="client_req_1",
        request_preview='{"input":"test"}',
        response_preview='{"output":"result"}',
        trace_metadata={"run_id": "run_1"},
        tags={"env": "prod"},
    )

    # Execute the real caller method
    result = trace_info.to_proto()

    # Verify it reached the v4 path: trace_id should be parsed (only the real part)
    assert isinstance(result, pb.TraceInfo), f"Expected pb.TraceInfo, got {type(result)}"
    assert result.trace_id == "real_trace_42", (
        f"v4 path should parse trace_id; expected 'real_trace_42', got {result.trace_id!r}"
    )
    assert result.client_request_id == "client_req_1", "client_request_id mismatch"
    assert result.request_preview == '{"input":"test"}', "request_preview mismatch"
    assert result.response_preview == '{"output":"result"}', "response_preview mismatch"
    assert result.request_time.ToMilliseconds() == 1000000, "request_time mismatch"

    print("PASS: check_trace_info_to_v4_proto_import_boundary")


# ──────────────────────────────────────────────────────────────────────────────
# C21: trace_location_from_proto import boundary (Interface)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C21


def check_trace_location_from_proto_import_boundary() -> None:
    """Verify TraceLocation.from_proto delegates to trace_location_from_proto.

    Execution-based: creates a pb.TraceLocation proto, calls
    TraceLocation.from_proto(proto), and verifies the result is a TraceLocation
    with correct type and populated sub-location.
    """
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
    )

    # Verify the function is importable from the declared module
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    assert callable(trace_location_from_proto), "trace_location_from_proto must be callable"

    # Test UC_SCHEMA path through the caller
    proto_uc = pb.TraceLocation()
    proto_uc.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto_uc.uc_schema.catalog_name = "boundary_cat"
    proto_uc.uc_schema.schema_name = "boundary_sch"

    result_uc = TraceLocation.from_proto(proto_uc)
    assert result_uc.type == TraceLocationType.UC_SCHEMA, (
        f"Expected UC_SCHEMA, got {result_uc.type}"
    )
    assert result_uc.uc_schema is not None, "uc_schema must be set"
    assert result_uc.uc_schema.catalog_name == "boundary_cat", "catalog_name mismatch"
    assert result_uc.uc_schema.schema_name == "boundary_sch", "schema_name mismatch"

    # Test MLFLOW_EXPERIMENT path through the caller
    proto_exp = pb.TraceLocation()
    proto_exp.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    proto_exp.mlflow_experiment.experiment_id = "boundary_exp"

    result_exp = TraceLocation.from_proto(proto_exp)
    assert result_exp.type == TraceLocationType.MLFLOW_EXPERIMENT, (
        f"Expected MLFLOW_EXPERIMENT, got {result_exp.type}"
    )
    assert result_exp.mlflow_experiment is not None, "mlflow_experiment must be set"
    assert result_exp.mlflow_experiment.experiment_id == "boundary_exp", "experiment_id mismatch"

    # Test INFERENCE_TABLE path through the caller
    proto_inf = pb.TraceLocation()
    proto_inf.type = pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    proto_inf.inference_table.full_table_name = "boundary.cat.sch.tbl"

    result_inf = TraceLocation.from_proto(proto_inf)
    assert result_inf.type == TraceLocationType.INFERENCE_TABLE, (
        f"Expected INFERENCE_TABLE, got {result_inf.type}"
    )
    assert result_inf.inference_table is not None, "inference_table must be set"
    assert result_inf.inference_table.full_table_name == "boundary.cat.sch.tbl", (
        "full_table_name mismatch"
    )

    print("PASS: check_trace_location_from_proto_import_boundary")


# ──────────────────────────────────────────────────────────────────────────────
# C22: get_trace_id_from_assessment_proto import boundary (Interface)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C22


def check_get_trace_id_from_assessment_proto_import_boundary() -> None:
    """Verify Expectation.from_proto calls get_trace_id_from_assessment_proto.

    Execution-based: creates a pb.Assessment proto with UC schema trace_location,
    calls Expectation.from_proto(proto), and verifies the returned trace_id is in
    v4 format.
    """
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities.assessment import Expectation
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    # Verify the function is importable from the declared module
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    assert callable(get_trace_id_from_assessment_proto), (
        "get_trace_id_from_assessment_proto must be callable"
    )

    # Build a proto Assessment with UC schema trace_location
    proto = pb.Assessment()
    proto.assessment_name = "boundary_expectation"
    proto.trace_id = "boundary_trace_id"
    proto.trace_location.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto.trace_location.uc_schema.catalog_name = "bcat"
    proto.trace_location.uc_schema.schema_name = "bsch"
    proto.create_time.FromMilliseconds(1000)
    proto.last_update_time.FromMilliseconds(2000)
    proto.source.source_type = pb.AssessmentSource.SourceType.HUMAN
    proto.source.source_id = "tester"
    # Set expectation field
    proto.expectation.value.string_value = "expected result"

    # Call the real caller method
    result = Expectation.from_proto(proto)

    # Verify that trace_id is in v4 format (constructed from catalog.schema + trace_id)
    assert "bcat.bsch" in result.trace_id, (
        f"trace_id should contain catalog.schema; got {result.trace_id!r}"
    )
    assert "boundary_trace_id" in result.trace_id, (
        f"trace_id should contain raw trace_id; got {result.trace_id!r}"
    )
    assert result.name == "boundary_expectation", "name mismatch"
    assert result.source.source_type == "HUMAN", "source_type mismatch"

    print("PASS: check_get_trace_id_from_assessment_proto_import_boundary")


# ──────────────────────────────────────────────────────────────────────────────
# C23: DatabricksTracingRestStore import boundary (Interface)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C23


def check_databricks_rest_store_import_boundary() -> None:
    """Verify databricks_rest_store imports from databricks_tracing_utils (E23).

    Execution-based: verifies the four required functions are importable from
    mlflow.utils.databricks_tracing_utils, proving they exist for the caller.
    """
    from mlflow.utils.databricks_tracing_utils import (
        assessment_to_proto,
        trace_from_proto,
        uc_schema_location_from_proto,
        uc_schema_location_to_proto,
    )

    required = {
        "assessment_to_proto": assessment_to_proto,
        "trace_from_proto": trace_from_proto,
        "uc_schema_location_from_proto": uc_schema_location_from_proto,
        "uc_schema_location_to_proto": uc_schema_location_to_proto,
    }

    for name, fn in required.items():
        assert callable(fn), f"{name} must be callable"

    print("PASS: check_databricks_rest_store_import_boundary")


# ──────────────────────────────────────────────────────────────────────────────
# C24: AssessmentSourceType class constants are strings (Interface)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C24


def check_assessment_source_type_constants_are_strings() -> None:
    """Verify AssessmentSourceType constants are simple str values."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    for attr_name in ("SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "AI_JUDGE", "HUMAN", "CODE"):
        value = getattr(AssessmentSourceType, attr_name)
        assert isinstance(value, str), (
            f"AssessmentSourceType.{attr_name} must be str, got {type(value).__name__}: {value!r}"
        )
        assert not isinstance(value, dict), (
            f"AssessmentSourceType.{attr_name} must not be dict"
        )

    print("PASS: check_assessment_source_type_constants_are_strings")


# ──────────────────────────────────────────────────────────────────────────────
# C25: AssessmentSourceType._SOURCE_TYPES excludes AI_JUDGE (State)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C25


def check_source_types_excludes_ai_judge() -> None:
    """Verify _SOURCE_TYPES list excludes deprecated AI_JUDGE."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    source_types = AssessmentSourceType._SOURCE_TYPES

    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED in source_types, (
        "SOURCE_TYPE_UNSPECIFIED missing from _SOURCE_TYPES"
    )
    assert AssessmentSourceType.LLM_JUDGE in source_types, (
        "LLM_JUDGE missing from _SOURCE_TYPES"
    )
    assert AssessmentSourceType.HUMAN in source_types, (
        "HUMAN missing from _SOURCE_TYPES"
    )
    assert AssessmentSourceType.CODE in source_types, (
        "CODE missing from _SOURCE_TYPES"
    )
    # C25: AI_JUDGE must NOT be in _SOURCE_TYPES
    assert AssessmentSourceType.AI_JUDGE not in source_types, (
        "AI_JUDGE must not be in _SOURCE_TYPES (deprecated)"
    )

    print("PASS: check_source_types_excludes_ai_judge")


# ──────────────────────────────────────────────────────────────────────────────
# Runner
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    all_checks = [
        check_assessment_to_proto_connectivity,
        check_get_trace_id_from_assessment_proto_connectivity,
        check_inference_table_location_to_proto_connectivity,
        check_mlflow_experiment_location_to_proto_connectivity,
        check_trace_from_proto_connectivity,
        check_trace_info_to_v4_proto_connectivity,
        check_trace_location_from_proto_dispatch,
        check_trace_location_to_proto_dispatch,
        check_trace_to_proto_connectivity,
        check_uc_schema_location_from_proto_connectivity,
        check_uc_schema_location_to_proto_connectivity,
        check_assessment_source_type_standardize_interface,
        check_span_inputs_dataflow,
        check_span_outputs_dataflow,
        check_trace_info_to_v4_proto_import_boundary,
        check_trace_location_from_proto_import_boundary,
        check_get_trace_id_from_assessment_proto_import_boundary,
        check_databricks_rest_store_import_boundary,
        check_assessment_source_type_constants_are_strings,
        check_source_types_excludes_ai_judge,
    ]

    failed = 0
    for check in all_checks:
        try:
            check()
        except Exception as exc:
            print(f"FAIL: {check.__name__}: {exc}")
            import traceback
            traceback.print_exc()
            failed += 1

    if failed:
        print(f"\n{failed} check(s) failed")
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} architecture checks passed")
        sys.exit(0)
