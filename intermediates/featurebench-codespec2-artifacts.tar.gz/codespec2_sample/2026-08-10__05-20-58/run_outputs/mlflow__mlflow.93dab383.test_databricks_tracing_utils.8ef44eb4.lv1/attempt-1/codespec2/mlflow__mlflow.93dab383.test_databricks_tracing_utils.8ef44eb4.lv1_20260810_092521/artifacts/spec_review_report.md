# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — mandates execution-based verification, forbids source-text checks as functional evidence, requires real caller→helper→observer chains for L2 contracts.
- Task document: Interface Descriptions 1–3 defining 14 functions/properties with exact signatures and behaviors.
- Semantic IR: Full L1→L3 IR at `/agent-logs/codespec2/.../semantic_ir.md` with 25 contracts (C1–C25).
- Architecture spec: `/agent-logs/codespec2/.../arch_spec.py` (773 lines, 20 checks).
- Behavior spec: `/agent-logs/codespec2/.../behavior_spec.py` (883 lines, 23 checks).
- Repository source: `/testbed/mlflow/utils/databricks_tracing_utils.py` (imports only, no function bodies), `/testbed/mlflow/entities/assessment_source.py` (class constants exist, missing `__init__`, `__str__`, `_parse`, `_standardize`), `/testbed/mlflow/entities/span.py` (missing `inputs`/`outputs` properties).
- Reference implementation: `/testbed/libs/skinny/mlflow/utils/databricks_tracing_utils.py` (197 lines, full implementation).
- Native tests:
  - `tests/entities/test_span.py::test_create_live_span` — verifies exact `span.inputs`/`span.outputs` deserialized values
  - `tests/entities/test_span.py::test_dict_conversion` — verifies inputs/outputs survive to_dict/from_dict roundtrip
  - `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — verifies invalid type raises MlflowException with INVALID_PARAMETER_VALUE
  - `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — verifies pytest.warns(FutureWarning) with exact message match
  - `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` — verifies case normalization through AssessmentSource constructor

## Rubric
- Requirement coverage: How many L1 obligations (R1–R14) have at least one discriminating executable observation?
- Caller binding / call chain: For L2 cross-module CALL contracts (C20–C23), does the spec execute the real caller and observe helper/caller binding?
- Dataflow / state / lifecycle: Are data values, conversions, state transitions, and lifecycles observed, not just type/shape checks?
- Failure / compatibility boundaries: Are error conditions, deprecation paths, backward compatibility, and edge cases verified with discriminating assertions?

## Derived Practical Test Perspectives
- P1: `tests/entities/test_span.py::test_create_live_span` — observed risk: inputs/outputs property returns exact deserialized Python values (dicts, ints, nested structures), not just non-None. Generated spec must create a real Span with serialized attribute data and verify the property deserializes to the original value.
- P2: `tests/entities/test_span.py::test_dict_conversion` — observed risk: inputs/outputs values survive serialization roundtrip (to_dict → from_dict). Generated spec should verify that creating a Span with inputs/outputs and reading them back preserves type and value fidelity.
- P3: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — observed risk: exact warning message match (`pytest.warns(FutureWarning, match="AI_JUDGE is deprecated...")`). Generated spec for C15 uses substring checks; should tighten to match the exact expected message pattern.
- P4: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — observed risk: the native test exercises AssessmentSource (the caller), not just AssessmentSourceType directly. The generated specs test both levels well (C14–C17 + boundary checks), but the AssessmentSource.__post_init__ boundary check (E17) could verify that calling AssessmentSource with "ai_judge" both emits the warning AND resolves to "LLM_JUDGE"—currently the post_init check only tests case normalization, not deprecation through the caller.

## Final Rubric Scores
- Requirement coverage: 1 — Most R1–R14 obligations have at least one check, but C18/C19 (Span.inputs/outputs) are tested only for property existence and key constant values, not actual deserialization behavior. C11 (trace_to_proto) only checks trace_id with empty spans. These are material requirements from Interface Descriptions 1 and 3.
- Caller binding / call chain: 1 — C20–C22 import boundary checks use `inspect.getsource` (runtime source-text inspection) which is an improvement over AST but still not execution-based caller→helper binding. C23 uses pure AST parsing. The Test Spec Skill explicitly prohibits source-text checks as functional evidence. None of these checks actually invoke the caller (e.g., `TraceInfo.to_proto()`, `TraceLocation.from_proto()`, `Expectation.from_proto()`) and observe the downstream helper being called with correct data.
- Dataflow / state / lifecycle: 1 — C1 (assessment_to_proto) checks field mapping and UC_SCHEMA type but doesn't verify the actual catalog_name/schema_name values extracted from the v4 trace_id. C6 (trace_info_to_v4_proto) only verifies trace_id parsing and assessments existence; it omits timestamp conversion verification, metadata truncation, tags, state, request/response previews. C11 (trace_to_proto) only checks trace_id, not span serialization. C18/C19 ignore actual data values.
- Failure / compatibility boundaries: 1 — C9 (ValueError for unsupported trace location type) and C15/C16 (AI_JUDGE deprecation, invalid type raises) are well-covered. However, C12 optional-field behavior only tests "with" and "without" proto fields but doesn't verify the default values when HasField returns False. The C22 dual-proto-type acceptance (pb.Assessment vs assessments_pb2.Assessment) is not tested at all—no check verifies that `get_trace_id_from_assessment_proto` works with the `assessments_pb2.Assessment` type.
- P1: 0 — No check creates a real Span with inputs/outputs stored as serialized attributes and verifies the property returns the correctly deserialized value. The current C18/C19 checks only verify property existence (`hasattr`) and constant values (`SpanAttributeKey.INPUTS == "mlflow.spanInputs"`).
- P2: 0 — No roundtrip test for inputs/outputs data preservation exists in either spec.
- P3: 1 — C15 behavior check tests AI_JUDGE deprecation with substring-based warning assertions; it does not match the exact `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` message pattern used in native tests.
- P4: 1 — The `check_assessment_source_post_init_standardizes` test (behavior spec) verifies case normalization through AssessmentSource but doesn't verify that `AssessmentSource(source_type="AI_JUDGE")` both emits the warning AND resolves to "LLM_JUDGE" through the caller path.

## Findings
- ### F1: weak_constraint
  - Requirement/IR: R13 (Span.inputs), R14 (Span.outputs), C18, C19
  - Evidence: Task Interface Description 3: "The inputs are automatically serialized to JSON when stored and deserialized when retrieved." Native test `test_create_live_span` asserts `span.inputs == {"input": 1}` and `span.outputs == 2`.
  - Gap: Both `arch_spec.py` C18/C19 and `behavior_spec.py` C18/C19 only verify `hasattr(Span, "inputs")` and `SpanAttributeKey.INPUTS == "mlflow.spanInputs"`. They never create a real Span with inputs/outputs data stored in attributes and never verify that the property returns correctly deserialized Python values. A plausible wrong implementation that returns `None` always or returns the raw JSON string would pass all current checks.
  - Repair: In `behavior_spec.py`, create a real `Span` from an `OTelReadableSpan` with `mlflow.spanInputs` and `mlflow.spanOutputs` attributes set to JSON-serialized values (e.g., `'{"input": 1, "nested": {"foo": "bar"}}'` and `"2"`), then assert `span.inputs == {"input": 1, "nested": {"foo": "bar"}}` and `span.outputs == 2`. Also assert `span.inputs is None` / `span.outputs is None` when the attributes are not set.

- ### F2: weak_constraint
  - Requirement/IR: R8 (trace_to_proto), C11
  - Evidence: Task Interface Description 1: "trace_to_proto returns pb.Trace containing trace_info and spans list converted to OpenTelemetry protobuf format." Native test `test_dict_conversion` verifies span data roundtrips.
  - Gap: `behavior_spec.py` `check_trace_to_proto_preserves_structure` creates a Trace with `TraceData(spans=[])` and only asserts `result.trace_info.trace_id == "test_id"`. It does not verify that spans are serialized. `arch_spec.py` `check_trace_to_proto_connectivity` also uses empty spans and only checks `hasattr(result, "spans")`. A wrong implementation that ignores spans would pass.
  - Repair: In `behavior_spec.py`, create a Trace with at least one real span (via `create_mlflow_span` from an OTelReadableSpan), call `trace_to_proto`, and assert `len(result.spans) >= 1` with span-level field verification (e.g., `result.spans[0].name` matches the original span name).

- ### F3: weak_constraint
  - Requirement/IR: C20 (trace_info_to_v4_proto import boundary), C21 (trace_location_from_proto import boundary), C22 (get_trace_id_from_assessment_proto import boundary), C23 (DatabricksTracingRestStore import boundary)
  - Evidence: Test Spec Skill lesson L2: "Import boundary contracts require both ends... Checking only one side produces a false positive." Skill also forbids "source-text checks, symbol existence, or mocked-only critical paths as evidence of functional behavior."
  - Gap: C20–C22 use `inspect.getsource` (runtime source-text inspection) and C23 uses AST parsing. None of these checks actually invoke the real caller method and observe the downstream helper being called with correct data. For example, C20 does not call `trace_info.to_proto()` when `_is_v4()` is True and verify that `trace_info_to_v4_proto` is the function reached.
  - Repair: For C20, create a TraceInfo with a UC_SCHEMA location (triggering `_is_v4()` path), call `trace_info.to_proto()`, and verify the result has the expected parsed trace_id. For C22, call `Expectation.from_proto(proto)` with a proto that has a UC schema trace_location, and verify the returned trace_id is a v4 format. For C23, verify that `assessment_to_proto`, `trace_from_proto`, `uc_schema_location_from_proto`, and `uc_schema_location_to_proto` are both importable from `mlflow.utils.databricks_tracing_utils` AND used by actually invoking the caller methods that depend on them.

- ### F4: weak_constraint
  - Requirement/IR: R1 (assessment_to_proto), C1
  - Evidence: Task Interface Description 1: "The function automatically parses the trace_id to extract location information and constructs the appropriate trace_location proto field for UC Schema locations." The skinny reference implementation shows `location, trace_id = parse_trace_id_v4(assessment.trace_id)` then `catalog, schema = location.split(".")`.
  - Gap: `behavior_spec.py` `check_assessment_to_proto_full_fields` checks that `result.trace_location.type == UC_SCHEMA` but does NOT verify `result.trace_location.uc_schema.catalog_name` or `result.trace_location.uc_schema.schema_name`. A wrong implementation that hardcodes dummy catalog/schema would pass.
  - Repair: In the behavior spec C1 check, add assertions for `result.trace_location.uc_schema.catalog_name == "catalog"` and `result.trace_location.uc_schema.schema_name == "schema"` (extracted from the input `"trace:/catalog.schema/trace_001"`).

- ### F5: weak_constraint
  - Requirement/IR: R6 (trace_info_to_v4_proto), C6, C7
  - Evidence: Task Interface Description 1: "trace_info_to_v4_proto returns pb.TraceInfo containing parsed trace_id, client_request_id, trace_location, request/response previews, converted timestamps and durations, trace state, metadata, and tags (truncated if necessary), and associated assessments."
  - Gap: `behavior_spec.py` `check_trace_info_to_v4_proto_trace_id_parsing_both_paths` only verifies trace_id. `check_trace_info_to_v4_proto_assessments_included` only verifies assessment count and name. Neither verifies: client_request_id, trace_location, request_preview, response_preview, timestamps (create_time in protobuf Timestamp format), execution_duration, state, metadata, or tags.
  - Repair: Add assertions for `result.trace_location`, `result.request_preview`, `result.response_preview`, `result.request_time.ToMilliseconds()`, `result.state`, `result.trace_metadata`, and `result.tags` in the behavior spec. This ensures the full field mapping is correct.

- ### F6: missing_requirement
  - Requirement/IR: C22 — dual proto type acceptance for `get_trace_id_from_assessment_proto`
  - Evidence: Task Interface Description 1: "proto (pb.Assessment | assessments_pb2.Assessment): Can be either a databricks_tracing_pb2.Assessment or assessments_pb2.Assessment object." Semantic IR C22 notes the `"trace_location" in proto.DESCRIPTOR.fields_by_name` guard for version differences.
  - Gap: Neither spec tests `get_trace_id_from_assessment_proto` with an `assessments_pb2.Assessment` proto. The behavior spec C2 only tests with `pb.Assessment` (databricks_tracing_pb2). If the function is not implemented to handle both proto types, the `assessments_pb2` path may crash.
  - Repair: In `behavior_spec.py`, add a check that creates an `assessments_pb2.Assessment` proto (which may lack the `trace_location` field), calls `get_trace_id_from_assessment_proto`, and verifies the raw trace_id path works correctly (returns `proto.trace_id` as-is).

## Rework Instructions
1. **Strengthen C18/C19 (Span.inputs/outputs)** — Replace the property-existence-only checks in both arch and behavior specs with real data-deserialization checks: create a `Span` from `OTelReadableSpan` with `mlflow.spanInputs`/`mlflow.spanOutputs` attributes set to JSON strings, verify `span.inputs` and `span.outputs` return the correctly deserialized Python objects, and verify `None` returns when attributes are absent.

2. **Strengthen C11 (trace_to_proto)** — Add a span with real data to the trace fixture and assert that `result.spans` contains the serialized span with at minimum the correct name. Use `create_mlflow_span` or construct a minimal `OTelReadableSpan`.

3. **Strengthen C1 (assessment_to_proto trace_location)** — Add assertions verifying the exact `catalog_name` and `schema_name` extracted from the v4 trace_id in the behavior spec.

4. **Strengthen C6/C7 (trace_info_to_v4_proto)** — Add comprehensive field assertions for timestamps, request/response previews, state, metadata, and tags in the behavior spec.

5. **Strengthen C20–C23 (import boundaries)** — Replace source-text/AST checks with execution-based verification: invoke the real caller (`TraceInfo.to_proto()`, `TraceLocation.from_proto()`, `Expectation.from_proto()`) and observe the downstream helper being reached with correct data.

6. **Add C22 dual-proto test** — Test `get_trace_id_from_assessment_proto` with an `assessments_pb2.Assessment` proto to verify the backward-compatible path.

7. **Tighten C15 deprecation warning match** — Use exact message pattern `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."` in FutureWarning assertions, matching native test practice.

8. **Strengthen P4 AssessmentSource boundary** — In `check_assessment_source_post_init_standardizes`, add a test that constructs `AssessmentSource(source_type="AI_JUDGE")` and verifies both the FutureWarning emission AND resolution to `"LLM_JUDGE"`.
