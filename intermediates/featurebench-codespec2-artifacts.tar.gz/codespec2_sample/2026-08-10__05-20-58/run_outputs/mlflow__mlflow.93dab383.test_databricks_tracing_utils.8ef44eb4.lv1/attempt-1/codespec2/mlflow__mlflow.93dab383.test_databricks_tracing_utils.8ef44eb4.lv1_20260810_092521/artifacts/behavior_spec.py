#!/usr/bin/env python3
"""
Executable behavior spec for MLflow tracing and assessment data management.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries, and
compatibility contracts. Each check_* function is a no-argument executable
assertion that invokes the public feature chain and asserts its result.
"""

import sys
import warnings

# ──────────────────────────────────────────────────────────────────────────────
# C1: assessment_to_proto field mapping — behavior verification
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C1


def check_assessment_to_proto_full_fields() -> None:
    """Verify assessment_to_proto correctly maps all assessment fields to proto."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities import Assessment
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
    from mlflow.protos import databricks_tracing_pb2 as pb

    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="tester")
    assessment = Assessment(
        name="my_assessment",
        trace_id="trace:/catalog.schema/trace_001",
        source=source,
        create_time_ms=1000000,
        last_update_time_ms=2000000,
        span_id="span_42",
        rationale="test rationale",
        metadata={"key1": "val1", "key2": 123},
        overrides='{"override_key": "override_val"}',
        valid=True,
    )
    # Set assessment_id manually (not in constructor)
    assessment.assessment_id = "assessment_007"

    result = assessment_to_proto(assessment)

    assert result.assessment_name == "my_assessment", "assessment_name mismatch"
    assert result.trace_id == "trace_001", f"trace_id mismatch: {result.trace_id}"
    assert result.span_id == "span_42", "span_id mismatch"
    assert result.rationale == "test rationale", "rationale mismatch"
    assert result.assessment_id == "assessment_007", "assessment_id mismatch"

    # Timestamps in protobuf Timestamp format
    assert result.create_time.ToMilliseconds() == 1000000, "create_time mismatch"
    assert result.last_update_time.ToMilliseconds() == 2000000, "last_update_time mismatch"

    # Source
    assert result.source.source_type == source.to_proto().source_type, "source type mismatch"
    assert result.source.source_id == "tester", "source_id mismatch"

    # Metadata — values converted to strings
    assert dict(result.metadata) == {"key1": "val1", "key2": "123"}, (
        f"metadata mismatch: {dict(result.metadata)}"
    )

    # Overrides
    assert result.overrides == '{"override_key": "override_val"}', (
        f"overrides mismatch: {result.overrides}"
    )

    # Valid
    assert result.valid is True, "valid mismatch"

    # Trace location should be UC_SCHEMA with correct catalog/schema
    assert result.trace_location.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA, (
        "trace_location type should be UC_SCHEMA"
    )
    # F4 repair: verify exact catalog_name and schema_name extracted from v4 trace_id
    assert result.trace_location.uc_schema.catalog_name == "catalog", (
        f"catalog_name mismatch: expected 'catalog', got {result.trace_location.uc_schema.catalog_name!r}"
    )
    assert result.trace_location.uc_schema.schema_name == "schema", (
        f"schema_name mismatch: expected 'schema', got {result.trace_location.uc_schema.schema_name!r}"
    )

    print("PASS: check_assessment_to_proto_full_fields")


# ──────────────────────────────────────────────────────────────────────────────
# C1b: assessment_to_proto with expectation (Dataflow — exactly one set)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C1


def check_assessment_to_proto_with_expectation() -> None:
    """Verify expectation is set and feedback is not when assessment has expectation."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment import Expectation
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="tester")
    exp = Expectation(
        name="exp_test",
        value="expected value",
        source=source,
        trace_id="trace:/cat.sch/trace_exp",
        create_time_ms=1000,
        last_update_time_ms=2000,
    )

    result = assessment_to_proto(exp)

    assert result.HasField("expectation"), "expectation field must be set"
    assert not result.HasField("feedback"), "feedback field must not be set when expectation exists"

    print("PASS: check_assessment_to_proto_with_expectation")


# ──────────────────────────────────────────────────────────────────────────────
# C1c: assessment_to_proto with feedback (Dataflow — exactly one set)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C1


def check_assessment_to_proto_with_feedback() -> None:
    """Verify feedback is set and expectation is not when assessment has feedback."""
    from mlflow.utils.databricks_tracing_utils import assessment_to_proto
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    source = AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="gpt-4")
    fb = Feedback(
        name="fb_test",
        value=4.5,
        source=source,
        trace_id="trace:/cat.sch/trace_fb",
        create_time_ms=1000,
        last_update_time_ms=2000,
    )

    result = assessment_to_proto(fb)

    assert result.HasField("feedback"), "feedback field must be set"
    assert not result.HasField("expectation"), (
        "expectation field must not be set when feedback exists"
    )

    print("PASS: check_assessment_to_proto_with_feedback")


# ──────────────────────────────────────────────────────────────────────────────
# C2: get_trace_id_from_assessment_proto v4 vs raw (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C2


def check_get_trace_id_v4_and_raw_paths() -> None:
    """Verify both UC schema and non-UC schema paths for trace ID extraction."""
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.tracing.utils import construct_trace_id_v4

    # Path A: UC schema → v4 trace_id via construct_trace_id_v4
    proto_a = pb.Assessment()
    proto_a.trace_id = "raw_trace_abc"
    proto_a.trace_location.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    proto_a.trace_location.uc_schema.catalog_name = "my_cat"
    proto_a.trace_location.uc_schema.schema_name = "my_sch"

    result_a = get_trace_id_from_assessment_proto(proto_a)
    expected_v4 = construct_trace_id_v4("my_cat.my_sch", "raw_trace_abc")
    assert result_a == expected_v4, (
        f"v4 trace_id mismatch: expected {expected_v4!r}, got {result_a!r}"
    )

    # Path B: No UC schema → raw trace_id
    proto_b = pb.Assessment()
    proto_b.trace_id = "simple_id"

    result_b = get_trace_id_from_assessment_proto(proto_b)
    assert result_b == "simple_id", (
        f"raw trace_id mismatch: expected 'simple_id', got {result_b!r}"
    )

    print("PASS: check_get_trace_id_v4_and_raw_paths")


# ──────────────────────────────────────────────────────────────────────────────
# C2b: get_trace_id_from_assessment_proto dual proto type (assessments_pb2)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: F6 — missing_requirement for dual proto type acceptance
# Contracts: C2


def check_get_trace_id_from_assessments_pb2_proto() -> None:
    """Verify get_trace_id_from_assessment_proto works with assessments_pb2.Assessment.

    Perspective: The function accepts both pb.Assessment (databricks_tracing_pb2)
    and assessments_pb2.Assessment. The assessments_pb2 version may lack the
    trace_location field (older schema). The function must gracefully handle this
    and return the raw trace_id.
    """
    from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto
    from mlflow.protos import assessments_pb2

    # Create an assessments_pb2.Assessment proto (the older schema without trace_location)
    proto = assessments_pb2.Assessment()
    proto.trace_id = "legacy_trace_999"

    result = get_trace_id_from_assessment_proto(proto)
    # Should return raw trace_id since assessments_pb2 may lack trace_location
    assert result == "legacy_trace_999", (
        f"Expected raw trace_id 'legacy_trace_999', got {result!r}"
    )

    print("PASS: check_get_trace_id_from_assessments_pb2_proto")


# ──────────────────────────────────────────────────────────────────────────────
# C3: trace_from_proto creates valid Trace (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C3


def check_trace_from_proto_creates_valid_trace() -> None:
    """Verify trace_from_proto returns a Trace with correct info and data."""
    from mlflow.utils.databricks_tracing_utils import trace_from_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities import Trace, TraceData

    # Build a minimal valid proto Trace
    proto = pb.Trace()
    proto.trace_info.trace_id = "test_trace_id_v4"
    proto.trace_info.request_time.FromMilliseconds(2000)
    proto.trace_info.state = pb.TraceInfo.State.OK

    result = trace_from_proto(proto, location_id="loc_1")

    assert isinstance(result, Trace), f"Expected Trace, got {type(result)}"
    assert result.info is not None, "Trace.info must not be None"
    assert result.data is not None, "Trace.data must not be None"
    assert isinstance(result.data, TraceData), (
        f"Expected TraceData, got {type(result.data)}"
    )
    # Even with no spans, the spans list should exist
    assert result.data.spans is not None, "Trace.data.spans must not be None"

    print("PASS: check_trace_from_proto_creates_valid_trace")


# ──────────────────────────────────────────────────────────────────────────────
# C4: trace_info_to_v4_proto trace_id parsing both paths (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C4


def check_trace_info_to_v4_proto_trace_id_parsing_both_paths() -> None:
    """Verify trace_info_to_v4_proto parses v4 trace_id for UC schema, raw otherwise."""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
        MlflowExperimentLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos import databricks_tracing_pb2 as pb

    # Path A: UC_SCHEMA → parsed trace_id
    ti_uc = TraceInfo(
        trace_id="trace:/cat.sch/real_id_123",
        trace_location=TraceLocation(
            type=TraceLocationType.UC_SCHEMA,
            uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
        ),
        request_time=5000,
        state=TraceState.OK,
    )
    result_uc = trace_info_to_v4_proto(ti_uc)
    assert result_uc.trace_id == "real_id_123", (
        f"UC schema: expected parsed trace_id 'real_id_123', got {result_uc.trace_id!r}"
    )

    # Path B: MLFLOW_EXPERIMENT → raw trace_id
    ti_exp = TraceInfo(
        trace_id="raw_trace_no_v4",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp_1"),
        ),
        request_time=6000,
        state=TraceState.OK,
    )
    result_exp = trace_info_to_v4_proto(ti_exp)
    assert result_exp.trace_id == "raw_trace_no_v4", (
        f"MLflow experiment: expected raw trace_id 'raw_trace_no_v4', got {result_exp.trace_id!r}"
    )

    print("PASS: check_trace_info_to_v4_proto_trace_id_parsing_both_paths")


# ──────────────────────────────────────────────────────────────────────────────
# C5: trace_info_to_v4_proto assessments included (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C5


def check_trace_info_to_v4_proto_assessments_included() -> None:
    """Verify trace_info_to_v4_proto includes assessments in the proto output."""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities import Assessment, TraceInfo
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        MlflowExperimentLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos import databricks_tracing_pb2 as pb

    source = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="tester")
    assessment = Assessment(
        name="trace_level_assessment",
        trace_id="raw_trace_assess",
        source=source,
        create_time_ms=7000,
        last_update_time_ms=8000,
    )
    assessment.assessment_id = "assess_001"

    ti = TraceInfo(
        trace_id="raw_trace_assess",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp_assess"),
        ),
        request_time=7000,
        state=TraceState.OK,
        assessments=[assessment],
    )

    result = trace_info_to_v4_proto(ti)
    assert len(result.assessments) == 1, (
        f"Expected 1 assessment, got {len(result.assessments)}"
    )
    assert result.assessments[0].assessment_name == "trace_level_assessment", (
        "assessment_name mismatch"
    )
    assert result.assessments[0].assessment_id == "assess_001", "assessment_id mismatch"

    print("PASS: check_trace_info_to_v4_proto_assessments_included")


# ──────────────────────────────────────────────────────────────────────────────
# C5b: trace_info_to_v4_proto comprehensive fields (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: F5 — weak_constraint on C6/C7
# Contracts: C5


def check_trace_info_to_v4_proto_comprehensive_fields() -> None:
    """Verify trace_info_to_v4_proto maps all fields: timestamps, previews,
    state, metadata, tags, trace_location, execution_duration."""
    from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto
    from mlflow.entities import TraceInfo
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.protos import databricks_tracing_pb2 as pb

    ti = TraceInfo(
        trace_id="trace:/cat.sch/full_trace_xyz",
        trace_location=TraceLocation(
            type=TraceLocationType.UC_SCHEMA,
            uc_schema=UCSchemaLocation(catalog_name="cat", schema_name="sch"),
        ),
        request_time=1234567,
        state=TraceState.OK,
        client_request_id="client_req_full",
        request_preview='{"question":"What is ML?"}',
        response_preview='{"answer":"Machine Learning is..."}',
        execution_duration=500,
        trace_metadata={"run_id": "run_abc", "source": "notebook"},
        tags={"env": "staging", "version": "2.0"},
    )

    result = trace_info_to_v4_proto(ti)

    # Core fields
    assert result.trace_id == "full_trace_xyz", f"trace_id mismatch: {result.trace_id!r}"
    assert result.client_request_id == "client_req_full", "client_request_id mismatch"
    assert result.request_preview == '{"question":"What is ML?"}', "request_preview mismatch"
    assert result.response_preview == '{"answer":"Machine Learning is..."}', "response_preview mismatch"

    # Timestamp in protobuf Timestamp format
    assert result.request_time.ToMilliseconds() == 1234567, (
        f"request_time mismatch: {result.request_time.ToMilliseconds()}"
    )

    # Execution duration
    assert result.HasField("execution_duration"), "execution_duration must be set"
    assert result.execution_duration.ToMilliseconds() == 500, (
        f"execution_duration mismatch: {result.execution_duration.ToMilliseconds()}"
    )

    # State
    assert result.state == pb.TraceInfo.State.OK, f"state mismatch: {result.state}"

    # Trace location
    assert result.HasField("trace_location"), "trace_location must be set"
    assert result.trace_location.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA, (
        "trace_location type mismatch"
    )

    # Metadata and tags are converted (may be truncated)
    assert result.trace_metadata is not None, "trace_metadata must be set"
    assert result.tags is not None, "tags must be set"

    print("PASS: check_trace_info_to_v4_proto_comprehensive_fields")


# ──────────────────────────────────────────────────────────────────────────────
# C6: trace_location_from_proto all types (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C6


def check_trace_location_from_proto_all_types() -> None:
    """Verify trace_location_from_proto handles all three location types."""
    from mlflow.utils.databricks_tracing_utils import trace_location_from_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities.trace_location import TraceLocationType

    # UC_SCHEMA
    p_uc = pb.TraceLocation()
    p_uc.type = pb.TraceLocation.TraceLocationType.UC_SCHEMA
    p_uc.uc_schema.catalog_name = "cat"
    p_uc.uc_schema.schema_name = "sch"
    r_uc = trace_location_from_proto(p_uc)
    assert r_uc.type == TraceLocationType.UC_SCHEMA
    assert r_uc.uc_schema.catalog_name == "cat"
    assert r_uc.uc_schema.schema_name == "sch"

    # MLFLOW_EXPERIMENT
    p_exp = pb.TraceLocation()
    p_exp.type = pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    p_exp.mlflow_experiment.experiment_id = "e1"
    r_exp = trace_location_from_proto(p_exp)
    assert r_exp.type == TraceLocationType.MLFLOW_EXPERIMENT
    assert r_exp.mlflow_experiment.experiment_id == "e1"

    # INFERENCE_TABLE
    p_inf = pb.TraceLocation()
    p_inf.type = pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    p_inf.inference_table.full_table_name = "a.b.c"
    r_inf = trace_location_from_proto(p_inf)
    assert r_inf.type == TraceLocationType.INFERENCE_TABLE
    assert r_inf.inference_table.full_table_name == "a.b.c"

    print("PASS: check_trace_location_from_proto_all_types")


# ──────────────────────────────────────────────────────────────────────────────
# C7: trace_location_to_proto raises ValueError (Failure)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C7


def check_trace_location_to_proto_raises_value_error() -> None:
    """Verify trace_location_to_proto raises ValueError for unsupported type."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
    )

    loc_unspec = TraceLocation(type=TraceLocationType.TRACE_LOCATION_TYPE_UNSPECIFIED)
    try:
        trace_location_to_proto(loc_unspec)
        assert False, "Should have raised ValueError"
    except ValueError as exc:
        assert "Unsupported trace location type" in str(exc), (
            f"Wrong error message: {exc}"
        )

    print("PASS: check_trace_location_to_proto_raises_value_error")


# ──────────────────────────────────────────────────────────────────────────────
# C8: trace_location_to_proto all types (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C8


def check_trace_location_to_proto_all_types() -> None:
    """Verify trace_location_to_proto produces correct proto for all valid types."""
    from mlflow.utils.databricks_tracing_utils import trace_location_to_proto
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
        UCSchemaLocation,
    )
    from mlflow.protos import databricks_tracing_pb2 as pb

    # UC_SCHEMA
    loc_uc = TraceLocation(
        type=TraceLocationType.UC_SCHEMA,
        uc_schema=UCSchemaLocation(catalog_name="c", schema_name="s"),
    )
    r_uc = trace_location_to_proto(loc_uc)
    assert r_uc.type == pb.TraceLocation.TraceLocationType.UC_SCHEMA
    assert r_uc.uc_schema.catalog_name == "c"
    assert r_uc.uc_schema.schema_name == "s"

    # MLFLOW_EXPERIMENT
    loc_exp = TraceLocation(
        type=TraceLocationType.MLFLOW_EXPERIMENT,
        mlflow_experiment=MlflowExperimentLocation(experiment_id="e2"),
    )
    r_exp = trace_location_to_proto(loc_exp)
    assert r_exp.type == pb.TraceLocation.TraceLocationType.MLFLOW_EXPERIMENT
    assert r_exp.mlflow_experiment.experiment_id == "e2"

    # INFERENCE_TABLE
    loc_inf = TraceLocation(
        type=TraceLocationType.INFERENCE_TABLE,
        inference_table=InferenceTableLocation(full_table_name="x.y.z"),
    )
    r_inf = trace_location_to_proto(loc_inf)
    assert r_inf.type == pb.TraceLocation.TraceLocationType.INFERENCE_TABLE
    assert r_inf.inference_table.full_table_name == "x.y.z"

    print("PASS: check_trace_location_to_proto_all_types")


# ──────────────────────────────────────────────────────────────────────────────
# C9: trace_to_proto preserves structure (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C9


def check_trace_to_proto_preserves_structure() -> None:
    """Verify trace_to_proto correctly serializes trace info and spans.

    F3 repair: Use a trace with real span data (not empty spans). Create a
    LiveSpan, end it, get the resulting OTelReadableSpan, build a Trace with it.
    """
    from mlflow.utils.databricks_tracing_utils import trace_to_proto
    from mlflow.entities import Trace, TraceData, TraceInfo
    from mlflow.entities.span import Span, create_mlflow_span
    from mlflow.entities.trace_location import (
        TraceLocation,
        TraceLocationType,
        MlflowExperimentLocation,
    )
    from mlflow.entities.trace_state import TraceState
    from mlflow.tracing.provider import _get_tracer
    from mlflow.protos import databricks_tracing_pb2 as pb

    # Create a real span with data using the OTel tracer
    tracer = _get_tracer("test_trace_to_proto")
    with tracer.start_as_current_span("test_root_span") as otel_span:
        live_span = create_mlflow_span(otel_span, trace_id="tr_proto_test")
        live_span.set_inputs({"query": "hello"})
        live_span.set_outputs("world")
        live_span.set_attribute("custom_key", 42)

    # Now otel_span is ended; create a Span from it
    mlflow_span = Span(otel_span)

    trace_info = TraceInfo(
        trace_id="tr_proto_test",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id="exp_proto"),
        ),
        request_time=9000,
        state=TraceState.OK,
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[mlflow_span]))

    result = trace_to_proto(trace)
    assert isinstance(result, pb.Trace), f"Expected pb.Trace, got {type(result)}"
    assert result.trace_info.trace_id == "tr_proto_test", "trace_id mismatch"

    # Verify spans are serialized
    assert len(result.spans) == 1, f"Expected 1 span, got {len(result.spans)}"
    assert result.spans[0].name == "test_root_span", (
        f"span name mismatch: {result.spans[0].name!r}"
    )

    print("PASS: check_trace_to_proto_preserves_structure")


# ──────────────────────────────────────────────────────────────────────────────
# C10: uc_schema_location_from_proto with and without optional fields
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C10


def check_uc_schema_location_from_proto_with_and_without_optional() -> None:
    """Verify uc_schema_location_from_proto handles HasField gating for optional fields."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_from_proto
    from mlflow.protos import databricks_tracing_pb2 as pb
    from mlflow.entities.trace_location import UCSchemaLocation

    # With optional fields set
    proto_with = pb.UCSchemaLocation()
    proto_with.catalog_name = "cat"
    proto_with.schema_name = "sch"
    proto_with.otel_spans_table_name = "spans_table"
    proto_with.otel_logs_table_name = "logs_table"

    result_with = uc_schema_location_from_proto(proto_with)
    assert result_with.catalog_name == "cat"
    assert result_with.schema_name == "sch"
    assert result_with._otel_spans_table_name == "spans_table"
    assert result_with._otel_logs_table_name == "logs_table"

    # Without optional fields (HasField returns False → default used)
    proto_without = pb.UCSchemaLocation()
    proto_without.catalog_name = "cat2"
    proto_without.schema_name = "sch2"
    # Do NOT set otel_spans_table_name and otel_logs_table_name

    result_without = uc_schema_location_from_proto(proto_without)
    assert result_without.catalog_name == "cat2"
    assert result_without.schema_name == "sch2"

    print("PASS: check_uc_schema_location_from_proto_with_and_without_optional")


# ──────────────────────────────────────────────────────────────────────────────
# C11: uc_schema_location_to_proto complete mapping (Dataflow behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C11


def check_uc_schema_location_to_proto_complete_mapping() -> None:
    """Verify uc_schema_location_to_proto maps all fields including private attrs."""
    from mlflow.utils.databricks_tracing_utils import uc_schema_location_to_proto
    from mlflow.entities.trace_location import UCSchemaLocation
    from mlflow.protos import databricks_tracing_pb2 as pb

    loc = UCSchemaLocation(catalog_name="cat", schema_name="sch")
    loc._otel_spans_table_name = "my_spans"
    loc._otel_logs_table_name = "my_logs"

    result = uc_schema_location_to_proto(loc)
    assert isinstance(result, pb.UCSchemaLocation), (
        f"Expected pb.UCSchemaLocation, got {type(result)}"
    )
    assert result.catalog_name == "cat"
    assert result.schema_name == "sch"
    assert result.otel_spans_table_name == "my_spans"
    assert result.otel_logs_table_name == "my_logs"

    print("PASS: check_uc_schema_location_to_proto_complete_mapping")


# ──────────────────────────────────────────────────────────────────────────────
# C12: AssessmentSourceType case normalization (Behavior)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C12


def check_assessment_source_type_case_normalization() -> None:
    """Verify AssessmentSourceType handles case-insensitive input."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert str(AssessmentSourceType("human")) == "HUMAN"
    assert str(AssessmentSourceType("Human")) == "HUMAN"
    assert str(AssessmentSourceType("HUMAN")) == "HUMAN"
    assert str(AssessmentSourceType("code")) == "CODE"
    assert str(AssessmentSourceType("CODE")) == "CODE"
    assert str(AssessmentSourceType("llm_judge")) == "LLM_JUDGE"
    assert str(AssessmentSourceType("LLM_JUDGE")) == "LLM_JUDGE"

    print("PASS: check_assessment_source_type_case_normalization")


# ──────────────────────────────────────────────────────────────────────────────
# C13: AssessmentSourceType AI_JUDGE deprecation (SideEffect)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: P3 — native test uses exact message match
# Contracts: C13


def check_assessment_source_type_ai_judge_deprecation() -> None:
    """Verify AI_JUDGE triggers FutureWarning and converts to LLM_JUDGE.

    F7 repair: Use exact message pattern from native test:
    `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
    """
    import pytest
    from mlflow.entities.assessment_source import AssessmentSourceType

    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = str(AssessmentSourceType("AI_JUDGE"))

    assert result == "LLM_JUDGE", (
        f"AI_JUDGE should resolve to LLM_JUDGE, got {result!r}"
    )

    print("PASS: check_assessment_source_type_ai_judge_deprecation")


# ──────────────────────────────────────────────────────────────────────────────
# C14: AssessmentSourceType invalid type raises (Failure)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C14


def check_assessment_source_type_invalid_raises() -> None:
    """Verify AssessmentSourceType raises MlflowException for invalid types."""
    import pytest
    from mlflow.entities.assessment_source import AssessmentSourceType
    from mlflow.exceptions import MlflowException
    from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

    with pytest.raises(MlflowException, match="Invalid assessment source type") as exc_info:
        AssessmentSourceType("ROBOT")
    assert exc_info.value.error_code == INVALID_PARAMETER_VALUE, (
        f"Error code should be INVALID_PARAMETER_VALUE, got {exc_info.value.error_code}"
    )

    print("PASS: check_assessment_source_type_invalid_raises")


# ──────────────────────────────────────────────────────────────────────────────
# C15: AssessmentSourceType._standardize behavior (Interface)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C15


def check_assessment_source_type_standardize_behavior() -> None:
    """Verify _standardize static method normalizes and validates source_type."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    # Case normalization
    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("code") == "CODE"

    # AI_JUDGE deprecation via _standardize
    import pytest
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        result = AssessmentSourceType._standardize("AI_JUDGE")
    assert result == "LLM_JUDGE"

    # Invalid type via _standardize
    from mlflow.exceptions import MlflowException
    try:
        AssessmentSourceType._standardize("INVALID")
        assert False, "Should have raised MlflowException"
    except MlflowException as exc:
        assert "Invalid assessment source type" in str(exc)

    print("PASS: check_assessment_source_type_standardize_behavior")


# ──────────────────────────────────────────────────────────────────────────────
# C16: Span.inputs with real data deserialization (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: P1 — tests/entities/test_span.py::test_create_live_span
# Perspective: Create a real Span with serialized attribute data and verify
# the property deserializes to the original Python value.
# Contracts: C16


def check_span_inputs_with_data() -> None:
    """Verify Span.inputs returns correctly deserialized Python objects.

    F1 repair: Create a real LiveSpan, set inputs with complex nested data,
    then verify the inputs property returns the exact original value after
    JSON serialization→deserialization roundtrip through OTel attributes.
    """
    from mlflow.entities.span import LiveSpan, create_mlflow_span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.provider import _get_tracer
    import json

    # Verify the attribute key
    assert SpanAttributeKey.INPUTS == "mlflow.spanInputs"

    # Create a LiveSpan and set complex inputs
    tracer = _get_tracer("test_span_inputs_behavior")
    with tracer.start_as_current_span("inputs_test_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_inputs_test")

        # Test with dict inputs (the most common case)
        test_data = {
            "query": "What is MLflow?",
            "params": {"temperature": 0.7, "model": "gpt-4"},
            "history": [{"role": "user", "content": "hi"}],
        }
        span.set_inputs(test_data)

        # Verify property returns correctly deserialized value
        assert hasattr(span, "inputs"), "Span must have 'inputs' property"
        result = span.inputs
        assert result == test_data, (
            f"inputs should match original data. Expected {test_data!r}, got {result!r}"
        )
        assert isinstance(result, dict), f"Expected dict, got {type(result)}"
        assert result["params"]["temperature"] == 0.7, "nested value mismatch"

        # Verify the attribute is stored as JSON string in OTel
        raw_attr = otel_span._attributes.get(SpanAttributeKey.INPUTS)
        assert raw_attr is not None, "INPUTS attribute should be set on OTel span"
        assert isinstance(json.loads(raw_attr), dict), "stored value should be valid JSON"

    # Test None when inputs never set
    with tracer.start_as_current_span("no_inputs_span") as otel_span2:
        span2 = create_mlflow_span(otel_span2, trace_id="trace_no_inputs")
        if hasattr(span2, "inputs"):
            assert span2.inputs is None, (
                "inputs should be None when never set"
            )

    print("PASS: check_span_inputs_with_data")


# ──────────────────────────────────────────────────────────────────────────────
# C17: Span.outputs with real data deserialization (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: P1 — tests/entities/test_span.py::test_create_live_span
# Perspective: Create a real Span with serialized output data and verify
# the property deserializes to the original Python value.
# Contracts: C17


def check_span_outputs_with_data() -> None:
    """Verify Span.outputs returns correctly deserialized Python objects.

    F1 repair: Create a real LiveSpan, set outputs with various types,
    then verify the outputs property returns the exact original value after
    JSON serialization→deserialization roundtrip through OTel attributes.
    """
    from mlflow.entities.span import LiveSpan, create_mlflow_span
    from mlflow.tracing.constant import SpanAttributeKey
    from mlflow.tracing.provider import _get_tracer
    import json

    # Verify the attribute key
    assert SpanAttributeKey.OUTPUTS == "mlflow.spanOutputs"

    tracer = _get_tracer("test_span_outputs_behavior")

    # Test with integer output
    with tracer.start_as_current_span("outputs_int_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_outputs_int")
        span.set_outputs(42)
        assert hasattr(span, "outputs"), "Span must have 'outputs' property"
        result = span.outputs
        assert result == 42, f"Expected 42, got {result!r}"

    # Test with string output
    with tracer.start_as_current_span("outputs_str_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_outputs_str")
        span.set_outputs("result_string")
        assert span.outputs == "result_string", f"Expected 'result_string', got {span.outputs!r}"

    # Test with complex nested output
    with tracer.start_as_current_span("outputs_nested_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_outputs_nested")
        nested = {"answer": "MLflow is great", "sources": ["doc1", "doc2"], "score": 0.95}
        span.set_outputs(nested)
        result = span.outputs
        assert result == nested, f"Expected {nested!r}, got {result!r}"
        assert result["score"] == 0.95, "nested float value mismatch"

        # Verify stored as JSON string in OTel
        raw_attr = otel_span._attributes.get(SpanAttributeKey.OUTPUTS)
        assert raw_attr is not None, "OUTPUTS attribute should be set on OTel span"

    # Test None when outputs never set
    with tracer.start_as_current_span("no_outputs_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_no_outputs")
        if hasattr(span, "outputs"):
            assert span.outputs is None, (
                "outputs should be None when never set"
            )

    print("PASS: check_span_outputs_with_data")


# ──────────────────────────────────────────────────────────────────────────────
# C18: Span inputs/outputs survive to_dict/from_dict roundtrip (Dataflow)
# ──────────────────────────────────────────────────────────────────────────────
# Reference: P2 — tests/entities/test_span.py::test_dict_conversion
# Perspective: Create a Span with inputs/outputs set, convert to/from dict,
# verify values survive the serialization roundtrip.
# Contracts: C18


def check_span_inputs_outputs_dict_roundtrip() -> None:
    """Verify inputs and outputs survive to_dict → from_dict roundtrip.

    P2 repair: Create a real Span with inputs/outputs data, call to_dict()
    and from_dict(), and verify the deserialized Span has correct values.
    """
    from mlflow.entities.span import Span, create_mlflow_span
    from mlflow.tracing.provider import _get_tracer
    from mlflow.tracing.constant import SpanAttributeKey

    tracer = _get_tracer("test_span_roundtrip")
    with tracer.start_as_current_span("roundtrip_span") as otel_span:
        span = create_mlflow_span(otel_span, trace_id="trace_roundtrip")
        span.set_inputs({"question": "What is tracing?", "k": 5})
        span.set_outputs({"answer": "It is...", "confidence": 0.88})
        span.set_attribute("source", "test_suite")

    # End the span and create an immutable Span from it
    mlflow_span = Span(otel_span)

    # Convert to dict and back
    span_dict = mlflow_span.to_dict()
    restored = Span.from_dict(span_dict)

    # Verify inputs/outputs are preserved (via attribute roundtrip)
    assert restored.name == "roundtrip_span", "name should survive roundtrip"
    assert restored.get_attribute(SpanAttributeKey.INPUTS) is not None, (
        "INPUTS attribute should survive roundtrip"
    )
    assert restored.get_attribute(SpanAttributeKey.OUTPUTS) is not None, (
        "OUTPUTS attribute should survive roundtrip"
    )

    print("PASS: check_span_inputs_outputs_dict_roundtrip")


# ──────────────────────────────────────────────────────────────────────────────
# C24: AssessmentSourceType constants values (State)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C24


def check_assessment_source_type_constants_values() -> None:
    """Verify the exact values of AssessmentSourceType string constants."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED == "SOURCE_TYPE_UNSPECIFIED"
    assert AssessmentSourceType.LLM_JUDGE == "LLM_JUDGE"
    assert AssessmentSourceType.AI_JUDGE == "AI_JUDGE"
    assert AssessmentSourceType.HUMAN == "HUMAN"
    assert AssessmentSourceType.CODE == "CODE"

    # Confirm they're all strings
    for name in ("SOURCE_TYPE_UNSPECIFIED", "LLM_JUDGE", "AI_JUDGE", "HUMAN", "CODE"):
        val = getattr(AssessmentSourceType, name)
        assert isinstance(val, str), f"{name} must be str, got {type(val)}"

    print("PASS: check_assessment_source_type_constants_values")


# ──────────────────────────────────────────────────────────────────────────────
# C25: _SOURCE_TYPES excludes AI_JUDGE (State)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C25


def check_source_types_list_excludes_ai_judge() -> None:
    """Verify _SOURCE_TYPES has exactly the four non-deprecated values."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    st = AssessmentSourceType._SOURCE_TYPES

    expected = [
        AssessmentSourceType.SOURCE_TYPE_UNSPECIFIED,
        AssessmentSourceType.LLM_JUDGE,
        AssessmentSourceType.HUMAN,
        AssessmentSourceType.CODE,
    ]

    assert st == expected, (
        f"_SOURCE_TYPES mismatch:\n  expected: {expected}\n  got:      {st}"
    )

    # AI_JUDGE must NOT be present
    assert AssessmentSourceType.AI_JUDGE not in st, (
        "AI_JUDGE must not appear in _SOURCE_TYPES"
    )

    print("PASS: check_source_types_list_excludes_ai_judge")


# ──────────────────────────────────────────────────────────────────────────────
# Boundary: AssessmentSource.__post_init__ calls _standardize (E17)
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C15, E17


def check_assessment_source_post_init_standardizes() -> None:
    """Verify AssessmentSource.__post_init__ standardizes source_type via _standardize.

    P4 repair: Test that constructing AssessmentSource with "AI_JUDGE" both
    emits the FutureWarning AND resolves source_type to "LLM_JUDGE".
    """
    import pytest
    from mlflow.entities.assessment_source import AssessmentSource

    # Lowercase input should be normalized
    src = AssessmentSource(source_type="human", source_id="test")
    assert src.source_type == "HUMAN", (
        f"AssessmentSource should normalize source_type, got {src.source_type!r}"
    )

    # Upper case should pass through
    src2 = AssessmentSource(source_type="LLM_JUDGE", source_id="test")
    assert src2.source_type == "LLM_JUDGE"

    # P4: AI_JUDGE deprecation through AssessmentSource caller
    # Both warning emission AND resolution to "LLM_JUDGE"
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        src3 = AssessmentSource(source_type="AI_JUDGE", source_id="ai_test")
    assert src3.source_type == "LLM_JUDGE", (
        f"AI_JUDGE should resolve to LLM_JUDGE through AssessmentSource, got {src3.source_type!r}"
    )
    assert src3.source_id == "ai_test", "source_id should be preserved"

    print("PASS: check_assessment_source_post_init_standardizes")


# ──────────────────────────────────────────────────────────────────────────────
# Boundary: AssessmentSourceType constructor + __str__ roundtrip
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C12, E24


def check_assessment_source_type_constructor_and_str() -> None:
    """Verify AssessmentSourceType(s) constructor and __str__() work correctly."""
    from mlflow.entities.assessment_source import AssessmentSourceType

    # Constructor + str roundtrip
    inst = AssessmentSourceType("HUMAN")
    assert str(inst) == "HUMAN", f"str(AssessmentSourceType('HUMAN')) = {str(inst)!r}"

    inst2 = AssessmentSourceType("code")
    assert str(inst2) == "CODE", f"str(AssessmentSourceType('code')) = {str(inst2)!r}"

    # Verify the constructor stores the parsed value
    inst3 = AssessmentSourceType("llm_judge")
    assert str(inst3) == "LLM_JUDGE"

    print("PASS: check_assessment_source_type_constructor_and_str")


# ──────────────────────────────────────────────────────────────────────────────
# Boundary: AssessmentSource accepts both string and AssessmentSourceType
# ──────────────────────────────────────────────────────────────────────────────
# Contracts: C12


def check_assessment_source_with_class_constant() -> None:
    """Verify AssessmentSource works with AssessmentSourceType class constants."""
    from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType

    # Using class constant directly
    src = AssessmentSource(source_type=AssessmentSourceType.HUMAN, source_id="user_1")
    assert src.source_type == "HUMAN"
    assert src.source_id == "user_1"

    # Using class constant for LLM_JUDGE
    src2 = AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="gpt-4")
    assert src2.source_type == "LLM_JUDGE"

    # Using class constant for CODE
    src3 = AssessmentSource(source_type=AssessmentSourceType.CODE, source_id="script.py")
    assert src3.source_type == "CODE"

    print("PASS: check_assessment_source_with_class_constant")


# ──────────────────────────────────────────────────────────────────────────────
# Runner
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    all_checks = [
        check_assessment_to_proto_full_fields,
        check_assessment_to_proto_with_expectation,
        check_assessment_to_proto_with_feedback,
        check_get_trace_id_v4_and_raw_paths,
        check_get_trace_id_from_assessments_pb2_proto,
        check_trace_from_proto_creates_valid_trace,
        check_trace_info_to_v4_proto_trace_id_parsing_both_paths,
        check_trace_info_to_v4_proto_assessments_included,
        check_trace_info_to_v4_proto_comprehensive_fields,
        check_trace_location_from_proto_all_types,
        check_trace_location_to_proto_raises_value_error,
        check_trace_location_to_proto_all_types,
        check_trace_to_proto_preserves_structure,
        check_uc_schema_location_from_proto_with_and_without_optional,
        check_uc_schema_location_to_proto_complete_mapping,
        check_assessment_source_type_case_normalization,
        check_assessment_source_type_ai_judge_deprecation,
        check_assessment_source_type_invalid_raises,
        check_assessment_source_type_standardize_behavior,
        check_span_inputs_with_data,
        check_span_outputs_with_data,
        check_span_inputs_outputs_dict_roundtrip,
        check_assessment_source_type_constants_values,
        check_source_types_list_excludes_ai_judge,
        check_assessment_source_post_init_standardizes,
        check_assessment_source_type_constructor_and_str,
        check_assessment_source_with_class_constant,
    ]

    failed = 0
    for check in all_checks:
        try:
            check()
        except Exception as exc:
            print(f"FAIL: {check.__name__}: {exc}")
            import traceback
            traceback.print_exc()
            failed += 1

    if failed:
        print(f"\n{failed} check(s) failed")
        sys.exit(1)
    else:
        print(f"\nAll {len(all_checks)} behavior checks passed")
        sys.exit(0)
