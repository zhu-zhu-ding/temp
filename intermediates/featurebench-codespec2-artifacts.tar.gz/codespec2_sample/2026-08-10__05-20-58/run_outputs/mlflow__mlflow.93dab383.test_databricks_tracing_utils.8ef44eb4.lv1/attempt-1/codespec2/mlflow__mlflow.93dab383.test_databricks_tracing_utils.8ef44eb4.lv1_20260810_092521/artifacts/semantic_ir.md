# Semantic IR

## L1. Requirement Obligations

### R1: serialize assessment to protobuf
- Type: Dataflow
- Statement: An MLflow `Assessment` entity must be convertible to a `pb.Assessment` protobuf message with all fields (name, trace_id, source, timestamps, optional span_id, rationale, assessment_id, expectation/feedback, metadata, overrides, valid) and UC-schema trace location extracted from a v4 trace_id.
- Task Evidence: "Convert an Assessment entity to its corresponding protobuf representation" / "assessment_to_proto"
- Acceptance: Calling `assessment_to_proto(assessment)` returns a `pb.Assessment` proto with correctly populated fields and timestamps in protobuf Timestamp format.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`; `mlflow/entities/assessment.py:Assessment.to_proto`; `mlflow/store/tracking/databricks_rest_store.py:511` calls `assessment_to_proto(assessment)`.
- Uncertainty: None

### R2: extract trace ID from assessment proto
- Type: Dataflow
- Statement: Given a protobuf Assessment (from either `pb.Assessment` or `assessments_pb2.Assessment`), extract the trace ID, constructing a v4 trace ID (`trace:/<catalog>.<schema>/<trace_id>`) when the proto contains a UC-schema trace_location, or returning the raw trace_id otherwise.
- Task Evidence: "Extract the trace ID from an assessment protocol buffer object" / "get_trace_id_from_assessment_proto"
- Acceptance: `get_trace_id_from_assessment_proto(proto)` returns a string trace ID; v4 format when UC schema location present, raw otherwise.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`; called from `mlflow/entities/assessment.py:288,426` for `Expectation.from_proto` and `Feedback.from_proto`.
- Uncertainty: None

### R3: serialize inference table location to protobuf
- Type: Dataflow
- Statement: An `InferenceTableLocation` entity must map its `full_table_name` field to a `pb.InferenceTableLocation` protobuf message.
- Task Evidence: "Convert an InferenceTableLocation object to its corresponding protobuf representation"
- Acceptance: `inference_table_location_to_proto(loc)` returns `pb.InferenceTableLocation(full_table_name=loc.full_table_name)`.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:inference_table_location_to_proto`; `mlflow/entities/trace_location.py:InferenceTableLocation`.
- Uncertainty: None

### R4: serialize MLflow experiment location to protobuf
- Type: Dataflow
- Statement: An `MlflowExperimentLocation` entity must map its `experiment_id` field to a `pb.MlflowExperimentLocation` protobuf message.
- Task Evidence: "Convert an MlflowExperimentLocation object to its corresponding protobuf representation"
- Acceptance: `mlflow_experiment_location_to_proto(loc)` returns `pb.MlflowExperimentLocation(experiment_id=loc.experiment_id)`.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:mlflow_experiment_location_to_proto`; `mlflow/entities/trace_location.py:MlflowExperimentLocation`.
- Uncertainty: None

### R5: deserialize trace from protobuf
- Type: Dataflow
- Statement: A `pb.Trace` protobuf message must be convertible to an MLflow `Trace` entity by deserializing `trace_info` via `TraceInfo.from_proto` and converting each OTel proto span into an MLflow `Span` via `Span.from_otel_proto` with the given location_id.
- Task Evidence: "Convert a protobuf Trace message to an MLflow Trace entity" / "trace_from_proto"
- Acceptance: `trace_from_proto(proto, location_id)` returns a `Trace` with `info` and `data.spans` populated.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`; `mlflow/store/tracking/databricks_rest_store.py:189` calls `trace_from_proto(proto, location)`.
- Uncertainty: None

### R6: serialize trace info to v4 protobuf
- Type: Dataflow
- Statement: A `TraceInfo` entity must be convertible to a `pb.TraceInfo` v4 protobuf message, parsing v4 trace IDs for UC schema locations, converting timestamps, including truncated metadata/tags, and converting all assessments to proto format.
- Task Evidence: "Convert a TraceInfo object to its v4 protocol buffer representation" / "trace_info_to_v4_proto"
- Acceptance: `trace_info_to_v4_proto(trace_info)` returns a `pb.TraceInfo` with parsed trace_id, client_request_id, trace_location, request/response previews, timestamps, state, metadata, tags, and assessments.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`; called from `mlflow/entities/trace_info.py:103`.
- Uncertainty: None

### R7: deserialize trace location from protobuf
- Type: Dataflow
- Statement: A `pb.TraceLocation` protobuf must be convertible to a `TraceLocation` entity, dispatching on the `WhichOneof("identifier")` result to the appropriate sub-location type (UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE), or returning `TRACE_LOCATION_TYPE_UNSPECIFIED` when no identifier is set.
- Task Evidence: "Convert a protobuf TraceLocation message to a TraceLocation entity object" / "trace_location_from_proto"
- Acceptance: `trace_location_from_proto(proto)` returns a `TraceLocation` with correct type and sub-location populated, or `TRACE_LOCATION_TYPE_UNSPECIFIED` for unrecognized identifiers.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`; called from `mlflow/entities/trace_location.py:246`.
- Uncertainty: None

### R8: serialize trace location to protobuf
- Type: Dataflow
- Statement: A `TraceLocation` entity must be convertible to a `pb.TraceLocation` protobuf, dispatching on the location type (UC_SCHEMA, MLFLOW_EXPERIMENT, INFERENCE_TABLE) to populate the corresponding sub-message, or raising `ValueError` for unsupported types.
- Task Evidence: "Convert a TraceLocation object to its corresponding protobuf representation" / "trace_location_to_proto"
- Acceptance: `trace_location_to_proto(trace_location)` returns a `pb.TraceLocation` with correct type and sub-location; raises `ValueError` for unsupported types.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`; used in `trace_info_to_v4_proto`.
- Uncertainty: None

### R9: serialize trace to protobuf
- Type: Dataflow
- Statement: A `Trace` entity must be convertible to a `pb.Trace` protobuf by converting `trace.info` via `to_proto()` and each span via `to_otel_proto()`.
- Task Evidence: "Convert a Trace object to its corresponding protobuf representation" / "trace_to_proto"
- Acceptance: `trace_to_proto(trace)` returns `pb.Trace(trace_info=..., spans=[...])`.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_to_proto`; `tests/store/tracking/test_databricks_rest_store.py:46,212` imports and calls `trace_to_proto`.
- Uncertainty: None

### R10: deserialize UC schema location from protobuf
- Type: Dataflow
- Statement: A `pb.UCSchemaLocation` protobuf must be convertible to a `UCSchemaLocation` entity, extracting `catalog_name`, `schema_name`, and optionally `otel_spans_table_name` and `otel_logs_table_name` (set as private attributes when present).
- Task Evidence: "Convert a protobuf UCSchemaLocation message to a UCSchemaLocation entity object" / "uc_schema_location_from_proto"
- Acceptance: `uc_schema_location_from_proto(proto)` returns a `UCSchemaLocation` with catalog_name, schema_name, and optional _otel_spans_table_name/_otel_logs_table_name.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`; `mlflow/store/tracking/databricks_rest_store.py:422` calls it.
- Uncertainty: None

### R11: serialize UC schema location to protobuf
- Type: Dataflow
- Statement: A `UCSchemaLocation` entity must be convertible to a `pb.UCSchemaLocation` protobuf, mapping `catalog_name`, `schema_name`, and the private `_otel_spans_table_name` and `_otel_logs_table_name` fields.
- Task Evidence: "Convert a UCSchemaLocation entity to its corresponding protobuf representation" / "uc_schema_location_to_proto"
- Acceptance: `uc_schema_location_to_proto(loc)` returns `pb.UCSchemaLocation` with all four fields.
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_to_proto`; `mlflow/store/tracking/databricks_rest_store.py:412,434,451` calls it.
- Uncertainty: None

### R12: validate and standardize assessment source type
- Type: Behavior
- Statement: An `AssessmentSourceType` class must accept a string in `__init__`, normalize it to uppercase, convert deprecated `AI_JUDGE` to `LLM_JUDGE` with a `FutureWarning`, validate against `_SOURCE_TYPES` list (excluding `AI_JUDGE`), and expose the result via `__str__()`. A static `_standardize` method must provide a convenience interface that creates an instance and returns the string.
- Task Evidence: "Validate and normalize assessment source types with deprecation handling" / "AssessmentSourceType._standardize"
- Acceptance: `AssessmentSourceType("human").__str__()` returns `"HUMAN"`; `AssessmentSourceType("AI_JUDGE")` emits `FutureWarning` and yields `"LLM_JUDGE"`; invalid types raise `MlflowException`.
- Repository Evidence: `mlflow/entities/assessment_source.py:AssessmentSourceType` (constants exist, methods missing); `mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`; `tests/entities/test_assessment_source.py` tests validation, deprecation, case insensitivity.
- Uncertainty: None

### R13: provide span inputs property
- Type: Interface
- Statement: The immutable `Span` class must expose an `inputs` property that reads the `SpanAttributeKey.INPUTS` (`"mlflow.spanInputs"`) attribute, deserializing it from JSON to return the original Python value, or `None` if not set.
- Task Evidence: "The input values of the span" / "Span.inputs property"
- Acceptance: `span.inputs` returns the deserialized input data (e.g., `{"query": "What is ML?"}`) or `None`.
- Repository Evidence: `mlflow/entities/span.py:Span` class; `mlflow/tracing/constant.py:SpanAttributeKey.INPUTS = "mlflow.spanInputs"`; `tests/entities/test_span.py:44-46` asserts `span.inputs == {"input": 1}` on a LiveSpan.
- Uncertainty: None

### R14: provide span outputs property
- Type: Interface
- Statement: The immutable `Span` class must expose an `outputs` property that reads the `SpanAttributeKey.OUTPUTS` (`"mlflow.spanOutputs"`) attribute, deserializing it from JSON to return the original Python value, or `None` if not set.
- Task Evidence: "The output values of the span" / "Span.outputs property"
- Acceptance: `span.outputs` returns the deserialized output data or `None`.
- Repository Evidence: `mlflow/entities/span.py:Span` class; `mlflow/tracing/constant.py:SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"`; `tests/entities/test_span.py:44-46` asserts `span.outputs == 2` on a LiveSpan.
- Uncertainty: None

## L2. Functional Design Graph

### N1: databricks_tracing_utils module
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/utils/databricks_tracing_utils.py` (empty, needs implementation)

### N2: assessment_to_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:assessment_to_proto`

### N3: get_trace_id_from_assessment_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:get_trace_id_from_assessment_proto`

### N4: inference_table_location_to_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:inference_table_location_to_proto`

### N5: mlflow_experiment_location_to_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:mlflow_experiment_location_to_proto`

### N6: trace_from_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_from_proto`

### N7: trace_info_to_v4_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_info_to_v4_proto`

### N8: trace_location_from_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_location_from_proto`

### N9: trace_location_to_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_location_to_proto`

### N10: trace_to_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:trace_to_proto`

### N11: uc_schema_location_from_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_from_proto`

### N12: uc_schema_location_to_proto
- Kind: Function
- Repository Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:uc_schema_location_to_proto`

### N13: AssessmentSourceType class
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType`

### N14: AssessmentSourceType._standardize
- Kind: Method (static)
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py` (missing, must be added); called by `AssessmentSource.__post_init__` at line 78.

### N15: AssessmentSourceType.__init__
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py` (missing, must be added)

### N16: AssessmentSourceType.__str__
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py` (missing, must be added)

### N17: AssessmentSourceType._parse
- Kind: Method (static)
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py` (missing, must be added)

### N18: Span inputs property
- Kind: Method (property)
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span` class (missing, must be added)

### N19: Span outputs property
- Kind: Method (property)
- Repository Evidence: `/testbed/mlflow/entities/span.py:Span` class (missing, must be added)

### N20: Span.get_attribute
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/span.py:215`

### N21: AssessmentSource dataclass
- Kind: Class
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSource`

### N22: TraceInfo.to_proto
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/trace_info.py:TraceInfo.to_proto`

### N23: TraceLocation.from_proto
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py:TraceLocation.from_proto`

### N24: Assessment.from_proto (Expectation/Feedback)
- Kind: Method (classmethod)
- Repository Evidence: `/testbed/mlflow/entities/assessment.py:Expectation.from_proto`, `Feedback.from_proto`

### N25: DatabricksTracingRestStore
- Kind: Class
- Repository Evidence: `/testbed/mlflow/store/tracking/databricks_rest_store.py:DatabricksTracingRestStore`

### N26: parse_trace_id_v4
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py:parse_trace_id_v4`

### N27: construct_trace_id_v4
- Kind: Function
- Repository Evidence: `/testbed/mlflow/tracing/utils/__init__.py:construct_trace_id_v4`

### N28: MlflowException
- Kind: Error
- Repository Evidence: `/testbed/mlflow/exceptions.py:MlflowException`

### E1: N2 -> N26
- Kind: CALL
- Condition: Always (assessment has a trace_id)
- Transfer: `assessment.trace_id` -> `parse_trace_id_v4` -> `(location, trace_id)` tuple
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:147` calls `parse_trace_id_v4(assessment.trace_id)`
- Obligations: R1

### E2: N2 -> Assessment fields
- Kind: DATA
- Condition: Always
- Transfer: Maps assessment fields (name, source, create_time_ms, last_update_time_ms, span_id, rationale, assessment_id, expectation/feedback, metadata, overrides, valid) to proto fields
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:144-181`
- Obligations: R1

### E3: N3 -> N27
- Kind: CALL
- Condition: proto has `trace_location` field with `uc_schema` set
- Transfer: `(catalog_name, schema_name, trace_id)` -> `construct_trace_id_v4` -> v4 trace_id string
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:187-197`
- Obligations: R2

### E4: N4 -> InferenceTableLocation.full_table_name
- Kind: DATA
- Condition: Always
- Transfer: `inference_table_location.full_table_name` -> `pb.InferenceTableLocation.full_table_name`
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:44-48`
- Obligations: R3

### E5: N5 -> MlflowExperimentLocation.experiment_id
- Kind: DATA
- Condition: Always
- Transfer: `mlflow_experiment_location.experiment_id` -> `pb.MlflowExperimentLocation.experiment_id`
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:50-55`
- Obligations: R4

### E6: N6 -> TraceInfo.from_proto, Span.from_otel_proto
- Kind: CALL
- Condition: Always
- Transfer: `proto.trace_info` -> `TraceInfo.from_proto`; each `proto.spans` -> `Span.from_otel_proto(span, location_id)`
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:137-141`
- Obligations: R5

### E7: N7 -> N9, N26, N2, trace_info fields
- Kind: CALL
- Condition: Always
- Transfer: `trace_info.trace_id` -> `parse_trace_id_v4` (if UC_SCHEMA); `trace_info.trace_location` -> `trace_location_to_proto`; each assessment -> `assessment_to_proto`
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:102-127`
- Obligations: R6

### E8: N8 -> N11, MlflowExperimentLocation.from_proto, InferenceTableLocation.from_proto
- Kind: CALL
- Condition: Dispatches on `proto.WhichOneof("identifier")`
- Transfer: proto sub-message -> corresponding entity factory
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:80-99`
- Obligations: R7

### E9: N9 -> N12, N5, N4
- Kind: CALL
- Condition: Dispatches on `trace_location.type`
- Transfer: Entity -> appropriate proto conversion function
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:58-75`
- Obligations: R8

### E10: N10 -> TraceInfo.to_proto, Span.to_otel_proto
- Kind: CALL
- Condition: Always
- Transfer: `trace.info.to_proto()` -> proto trace_info; each `trace.data.spans[].to_otel_proto()` -> proto spans
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:130-134`
- Obligations: R9

### E11: N11 -> UCSchemaLocation constructor
- Kind: CALL
- Condition: Always
- Transfer: proto fields -> `UCSchemaLocation(catalog_name, schema_name)` with optional `_otel_spans_table_name`, `_otel_logs_table_name`
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:34-41`
- Obligations: R10

### E12: N12 -> UCSchemaLocation private fields
- Kind: DATA
- Condition: Always
- Transfer: `uc_schema_location.catalog_name`, `.schema_name`, `._otel_spans_table_name`, `._otel_logs_table_name` -> proto fields
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:25-31`
- Obligations: R11

### E13: N14 -> N15, N16
- Kind: CALL
- Condition: Always
- Transfer: `source_type` string -> `AssessmentSourceType(source_type)` instance -> `str(instance)` -> standardized string
- Evidence: Task Interface Description 2: "_standardize must instantiate an AssessmentSourceType object by calling the constructor AssessmentSourceType(source_type), then convert the instance to a string representation"
- Obligations: R12

### E14: N15 -> N17
- Kind: CALL
- Condition: Always
- Transfer: `source_type` string -> `_parse(source_type)` -> stored parsed value
- Evidence: Task Interface Description 2: "The constructor must delegate validation and transformation logic to a _parse(source_type: str) static method"
- Obligations: R12

### E15: N17 -> N28
- Kind: CONTROL
- Condition: source_type (after uppercasing and deprecation mapping) not in `_SOURCE_TYPES`
- Transfer: Raises `MlflowException` with `INVALID_PARAMETER_VALUE` error code
- Evidence: Task Interface Description 2: "raising MlflowException with INVALID_PARAMETER_VALUE error code for invalid types"
- Obligations: R12

### E16: N17 -> FutureWarning
- Kind: SIDE_EFFECT
- Condition: source_type uppercased equals "AI_JUDGE"
- Transfer: Emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` and maps to "LLM_JUDGE"
- Evidence: Task Interface Description 2; `tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning`
- Obligations: R12

### E17: N21 -> N14
- Kind: CALL
- Condition: Always (during `__post_init__`)
- Transfer: `self.source_type` -> `AssessmentSourceType._standardize(self.source_type)` -> normalized value stored back to `self.source_type`
- Evidence: `/testbed/mlflow/entities/assessment_source.py:78`
- Obligations: R12

### E18: N18 -> N20
- Kind: CALL
- Condition: Always
- Transfer: `SpanAttributeKey.INPUTS` -> `self.get_attribute(...)` -> deserialized value
- Evidence: Task Interface Description 3; `SpanAttributeKey.INPUTS = "mlflow.spanInputs"` in constant.py
- Obligations: R13

### E19: N19 -> N20
- Kind: CALL
- Condition: Always
- Transfer: `SpanAttributeKey.OUTPUTS` -> `self.get_attribute(...)` -> deserialized value
- Evidence: Task Interface Description 3; `SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"` in constant.py
- Obligations: R14

### E20: N22 -> N7
- Kind: CALL
- Condition: `trace_info._is_v4()` returns True (UC_SCHEMA location)
- Transfer: `self` (TraceInfo) -> `trace_info_to_v4_proto(self)` -> proto
- Evidence: `/testbed/mlflow/entities/trace_info.py:101-103`
- Obligations: R6

### E21: N23 -> N8
- Kind: CALL
- Condition: Always
- Transfer: `proto` -> `trace_location_from_proto(proto)` -> TraceLocation entity
- Evidence: `/testbed/mlflow/entities/trace_location.py:244-246`
- Obligations: R7

### E22: N24 -> N3
- Kind: CALL
- Condition: Always
- Transfer: `proto` -> `get_trace_id_from_assessment_proto(proto)` -> trace_id string
- Evidence: `/testbed/mlflow/entities/assessment.py:288,426`
- Obligations: R2

### E23: N25 -> N2, N6, N10, N11, N12
- Kind: CALL
- Condition: Various REST operations
- Transfer: Assessment/Trace entities -> proto converters for API requests; proto responses -> entity converters
- Evidence: `libs/skinny/mlflow/store/tracking/databricks_rest_store.py:48-52` imports; `/testbed/mlflow/store/tracking/databricks_rest_store.py:189,412,422,434,451,511` calls (missing import, needs fix)
- Obligations: R1, R5, R9, R10, R11

### E24: N16 -> stored value
- Kind: DATA
- Condition: Always
- Transfer: Returns the `_value` stored by `__init__`
- Evidence: Task Interface Description 2: "__str__() method that returns the stored source type string"
- Obligations: R12

## L3. Verifiable Contracts

### C1: assessment_to_proto field mapping
- Type: Dataflow
- Subject: N2 return value fields
- Relation: EQ
- Expected: `assessment_proto.assessment_name == assessment.name`, `assessment_proto.trace_id` equals parsed trace_id from v4, timestamps in protobuf Timestamp format via `FromMilliseconds()`, optional fields (span_id, rationale, assessment_id) set only when not None, exactly one of expectation or feedback set, metadata values as strings, overrides/valid set when present
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:144-181`
- Observe: RETURN_VALUE
- Target: `assessment_to_proto(assessment)` returning `pb.Assessment`
- Obligations: R1
- Graph: N2, E1, E2

### C2: get_trace_id_from_assessment_proto v4 construction
- Type: Dataflow
- Subject: N3 return value
- Relation: EQ
- Expected: When proto has `trace_location.uc_schema`, returns `construct_trace_id_v4(f"{catalog}.{schema}", proto.trace_id)`; otherwise returns `proto.trace_id`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:187-197`
- Observe: RETURN_VALUE
- Target: `get_trace_id_from_assessment_proto(proto)` return
- Obligations: R2
- Graph: N3, E3, N27

### C3: inference_table_location_to_proto mapping
- Type: Dataflow
- Subject: N4 return value
- Relation: EQ
- Expected: `pb.InferenceTableLocation(full_table_name=inference_table_location.full_table_name)`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:44-48`
- Observe: RETURN_VALUE
- Target: `inference_table_location_to_proto(loc)` return
- Obligations: R3
- Graph: N4, E4

### C4: mlflow_experiment_location_to_proto mapping
- Type: Dataflow
- Subject: N5 return value
- Relation: EQ
- Expected: `pb.MlflowExperimentLocation(experiment_id=mlflow_experiment_location.experiment_id)`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:50-55`
- Observe: RETURN_VALUE
- Target: `mlflow_experiment_location_to_proto(loc)` return
- Obligations: R4
- Graph: N5, E5

### C5: trace_from_proto composition
- Type: Dataflow
- Subject: N6 return value
- Relation: TYPE_IS
- Expected: Returns `Trace` with `info` from `TraceInfo.from_proto(proto.trace_info)` and `data` as `TraceData` with spans from `Span.from_otel_proto(span, location_id)` for each proto span
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:137-141`
- Observe: RETURN_VALUE
- Target: `trace_from_proto(proto, location_id)` return
- Obligations: R5
- Graph: N6, E6

### C6: trace_info_to_v4_proto trace_id parsing
- Type: Dataflow
- Subject: N7 proto trace_id field
- Relation: EQ
- Expected: When `trace_info.trace_location.uc_schema` is set, trace_id is parsed via `parse_trace_id_v4` and only the second component used; otherwise raw `trace_info.trace_id`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:114-117`
- Observe: RETURN_VALUE
- Target: `trace_info_to_v4_proto(trace_info).trace_id`
- Obligations: R6
- Graph: N7, E7, N26

### C7: trace_info_to_v4_proto includes all assessments
- Type: Dataflow
- Subject: N7 proto assessments field
- Relation: PRESERVE
- Expected: Each assessment in `trace_info.assessments` is converted via `assessment_to_proto` and included in proto
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:126`
- Observe: RETURN_VALUE
- Target: `trace_info_to_v4_proto(trace_info).assessments` list
- Obligations: R1, R6
- Graph: N7, E7, N2

### C8: trace_location_from_proto dispatch
- Type: Behavior
- Subject: N8 return value
- Relation: EQ
- Expected: For `uc_schema` identifier -> `TraceLocation(type=UC_SCHEMA, uc_schema=uc_schema_location_from_proto(...))`; for `mlflow_experiment` -> `TraceLocation(type=MLFLOW_EXPERIMENT, mlflow_experiment=MlflowExperimentLocation.from_proto(...))`; for `inference_table` -> `TraceLocation(type=INFERENCE_TABLE, inference_table=InferenceTableLocation.from_proto(...))`; else -> `TraceLocation(TRACE_LOCATION_TYPE_UNSPECIFIED)`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:80-99`
- Observe: RETURN_VALUE
- Target: `trace_location_from_proto(proto)` return
- Obligations: R7
- Graph: N8, E8, N11

### C9: trace_location_to_proto ValueError
- Type: Failure
- Subject: N9
- Relation: RAISES
- Expected: Raises `ValueError` when `trace_location.type` is not UC_SCHEMA, MLFLOW_EXPERIMENT, or INFERENCE_TABLE
- Evidence: Task Interface Description 1: "Raises: ValueError: If the trace_location.type is not one of the supported types"
- Observe: EXCEPTION
- Target: `trace_location_to_proto(TraceLocation(type=unsupported))` raises ValueError
- Obligations: R8
- Graph: N9, E9

### C10: trace_location_to_proto type dispatch
- Type: Behavior
- Subject: N9 return value
- Relation: EQ
- Expected: UC_SCHEMA -> `pb.TraceLocation(type=UC_SCHEMA, uc_schema=...)`; MLFLOW_EXPERIMENT -> `pb.TraceLocation(type=MLFLOW_EXPERIMENT, mlflow_experiment=...)`; INFERENCE_TABLE -> `pb.TraceLocation(type=INFERENCE_TABLE, inference_table=...)`
- Evidence: `libs/skinny/mlflow/utils/databricks_tracing_utils.py:58-75`
- Observe: RETURN_VALUE
- Target: `trace_location_to_proto(trace_location)` return
- Obligations: R8
- Graph: N9, E9, N12, N5, N4

### C11: trace_to_proto composition
- Type: Dataflow
- Subject: N10 return value
- Relation: EQ
- Expected: `pb.Trace(trace_info=trace.info.to_proto(), spans=[span.to_otel_proto() for span in trace.data.spans])`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:130-134`
- Observe: RETURN_VALUE
- Target: `trace_to_proto(trace)` return
- Obligations: R9
- Graph: N10, E10

### C12: uc_schema_location_from_proto optional fields
- Type: Dataflow
- Subject: N11 return value private attributes
- Relation: EQ
- Expected: `_otel_spans_table_name` set from proto when `HasField("otel_spans_table_name")`; `_otel_logs_table_name` set from proto when `HasField("otel_logs_table_name")`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:34-41`
- Observe: FIELD_READ
- Target: `uc_schema_location_from_proto(proto)._otel_spans_table_name`
- Obligations: R10
- Graph: N11, E11

### C13: uc_schema_location_to_proto field mapping
- Type: Dataflow
- Subject: N12 return value
- Relation: EQ
- Expected: `pb.UCSchemaLocation(catalog_name=..., schema_name=..., otel_spans_table_name=..., otel_logs_table_name=...)`
- Evidence: Task Interface Description 1; `libs/skinny/mlflow/utils/databricks_tracing_utils.py:25-31`
- Observe: RETURN_VALUE
- Target: `uc_schema_location_to_proto(loc)` return
- Obligations: R11
- Graph: N12, E12

### C14: AssessmentSourceType case normalization
- Type: Behavior
- Subject: N15 + N16
- Relation: EQ
- Expected: `str(AssessmentSourceType("human")) == "HUMAN"`, `str(AssessmentSourceType("Human")) == "HUMAN"`, `str(AssessmentSourceType("HUMAN")) == "HUMAN"`
- Evidence: Task Interface Description 2; `tests/entities/test_assessment_source.py:test_assessment_source_case_insensitivity`
- Observe: RETURN_VALUE
- Target: `str(AssessmentSourceType("human"))` return
- Obligations: R12
- Graph: N13, N14, N15, N16, N17, E13, E14, E24

### C15: AssessmentSourceType AI_JUDGE deprecation
- Type: SideEffect
- Subject: N17
- Relation: EQ
- Expected: `str(AssessmentSourceType("AI_JUDGE")) == "LLM_JUDGE"` and emits `FutureWarning("AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
- Evidence: Task Interface Description 2; `tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning`
- Observe: RETURN_VALUE + SIDE_EFFECT (warnings.warn)
- Target: `str(AssessmentSourceType("AI_JUDGE"))` with `pytest.warns(FutureWarning)`
- Obligations: R12
- Graph: N13, N17, E16

### C16: AssessmentSourceType invalid type raises
- Type: Failure
- Subject: N17 -> N28
- Relation: RAISES
- Expected: `AssessmentSourceType("ROBOT")` raises `MlflowException` with `INVALID_PARAMETER_VALUE` error code and message containing "Invalid assessment source type"
- Evidence: Task Interface Description 2; `tests/entities/test_assessment_source.py:test_assessment_source_type_validation`
- Observe: EXCEPTION
- Target: `AssessmentSourceType("ROBOT")` constructor
- Obligations: R12
- Graph: N13, N15, N17, N28, E14, E15

### C17: AssessmentSourceType._standardize static method
- Type: Interface
- Subject: N14
- Relation: EQ
- Expected: `AssessmentSourceType._standardize("human")` returns `"HUMAN"`; `AssessmentSourceType._standardize("AI_JUDGE")` returns `"LLM_JUDGE"` with warning
- Evidence: Task Interface Description 2; called from `AssessmentSource.__post_init__` at `assessment_source.py:78`
- Observe: RETURN_VALUE
- Target: `AssessmentSourceType._standardize(source_type)` return
- Obligations: R12
- Graph: N14, E13, N15, N16, N17

### C18: Span.inputs reads from attributes
- Type: Dataflow
- Subject: N18
- Relation: EQ
- Expected: `span.inputs` returns `span.get_attribute(SpanAttributeKey.INPUTS)` which deserializes the JSON-stored attribute value to the original Python object, or `None` if not set
- Evidence: Task Interface Description 3; `SpanAttributeKey.INPUTS = "mlflow.spanInputs"` in constant.py; `tests/entities/test_span.py:44-46`
- Observe: RETURN_VALUE
- Target: `span.inputs` property access
- Obligations: R13
- Graph: N18, E18, N20

### C19: Span.outputs reads from attributes
- Type: Dataflow
- Subject: N19
- Relation: EQ
- Expected: `span.outputs` returns `span.get_attribute(SpanAttributeKey.OUTPUTS)` which deserializes the JSON-stored attribute value to the original Python object, or `None` if not set
- Evidence: Task Interface Description 3; `SpanAttributeKey.OUTPUTS = "mlflow.spanOutputs"` in constant.py; `tests/entities/test_span.py:44-46`
- Observe: RETURN_VALUE
- Target: `span.outputs` property access
- Obligations: R14
- Graph: N19, E19, N20

### C20: trace_info_to_v4_proto import boundary
- Type: Interface
- Subject: N7
- Relation: CALLS
- Expected: `mlflow/entities/trace_info.py:TraceInfo.to_proto` imports `trace_info_to_v4_proto` from `mlflow.utils.databricks_tracing_utils` and calls it when `_is_v4()` is True
- Evidence: `/testbed/mlflow/entities/trace_info.py:101-103`
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto`
- Obligations: R6
- Graph: N7, N22, E20

### C21: trace_location_from_proto import boundary
- Type: Interface
- Subject: N8
- Relation: CALLS
- Expected: `mlflow/entities/trace_location.py:TraceLocation.from_proto` imports `trace_location_from_proto` from `mlflow.utils.databricks_tracing_utils` and delegates to it
- Evidence: `/testbed/mlflow/entities/trace_location.py:244-246`
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.utils.databricks_tracing_utils import trace_location_from_proto`
- Obligations: R7
- Graph: N8, N23, E21

### C22: get_trace_id_from_assessment_proto import boundary
- Type: Interface
- Subject: N3
- Relation: CALLS
- Expected: `mlflow/entities/assessment.py:Expectation.from_proto` and `Feedback.from_proto` import `get_trace_id_from_assessment_proto` from `mlflow.utils.databricks_tracing_utils` and call it
- Evidence: `/testbed/mlflow/entities/assessment.py:288,426`
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.utils.databricks_tracing_utils import get_trace_id_from_assessment_proto`
- Obligations: R2
- Graph: N3, N24, E22

### C23: DatabricksTracingRestStore import boundary
- Type: Interface
- Subject: N25
- Relation: CALLS
- Expected: `mlflow/store/tracking/databricks_rest_store.py` imports `assessment_to_proto`, `trace_from_proto`, `uc_schema_location_from_proto`, `uc_schema_location_to_proto` from `mlflow.utils.databricks_tracing_utils`
- Evidence: `libs/skinny/mlflow/store/tracking/databricks_rest_store.py:48-52` (import exists in skinny, missing in main); `/testbed/mlflow/store/tracking/databricks_rest_store.py:189,412,422,434,451,511` uses functions without import
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.utils.databricks_tracing_utils import assessment_to_proto, trace_from_proto, uc_schema_location_from_proto, uc_schema_location_to_proto`
- Obligations: R1, R5, R10, R11
- Graph: N25, N2, N6, N11, N12, E23
- Uncertainty: The main `databricks_rest_store.py` is missing the import of these functions; it must be added for the module to work.

### C24: AssessmentSourceType class constants are strings
- Type: Interface
- Subject: N13 constants
- Relation: TYPE_IS
- Expected: `SOURCE_TYPE_UNSPECIFIED`, `LLM_JUDGE`, `AI_JUDGE`, `HUMAN`, `CODE` are all simple `str` values, not dict structures
- Evidence: Task Interface Description 2: "The class constants should be defined as simple string values, not dictionary structures"; already true in `/testbed/mlflow/entities/assessment_source.py`
- Observe: FIELD_READ
- Target: `AssessmentSourceType.HUMAN` is `str`
- Obligations: R12
- Graph: N13

### C25: AssessmentSourceType._SOURCE_TYPES excludes AI_JUDGE
- Type: State
- Subject: N13._SOURCE_TYPES
- Relation: EQ
- Expected: `_SOURCE_TYPES == [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]` (AI_JUDGE excluded)
- Evidence: Task Interface Description 2: "The _SOURCE_TYPES list should contain [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE] (excluding the deprecated AI_JUDGE)"; already true in existing code
- Observe: FIELD_READ
- Target: `AssessmentSourceType._SOURCE_TYPES`
- Obligations: R12
- Graph: N13
