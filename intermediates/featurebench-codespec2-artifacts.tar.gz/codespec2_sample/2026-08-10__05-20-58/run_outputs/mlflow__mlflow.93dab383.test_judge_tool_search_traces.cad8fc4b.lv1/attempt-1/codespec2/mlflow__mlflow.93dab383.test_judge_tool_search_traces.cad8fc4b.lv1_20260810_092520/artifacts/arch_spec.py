"""
Executable architecture spec for SearchTracesTool and AssessmentSourceType.

Covers L2 CALL/CONTROL paths and L3 Interface/Dataflow contracts.
Each check_* function exercises the public API and validates structural
connectivity, data identity, and routing.
"""

import sys
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_trace_with_location(experiment_id="exp-001"):
    """Create a minimal Trace with a valid MLflow experiment location."""
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-001",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id=experiment_id),
        ),
        request_time=1700000000000,
        state=TraceState.OK,
    )
    data = TraceData()
    return Trace(info=info, data=data)


def _make_trace_without_location():
    """Create a Trace with trace_location=None."""
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-002",
        trace_location=None,
        request_time=1700000000000,
        state=TraceState.OK,
    )
    data = TraceData()
    return Trace(info=info, data=data)


def _make_trace_with_inference_table_location():
    """Create a Trace with non-MLFLOW_EXPERIMENT location."""
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-003",
        trace_location=TraceLocation(
            type=TraceLocationType.INFERENCE_TABLE,
            inference_table=InferenceTableLocation(full_table_name="catalog.schema.table"),
        ),
        request_time=1700000000000,
        state=TraceState.OK,
    )
    data = TraceData()
    return Trace(info=info, data=data)


def _make_expectation():
    """Create a minimal Expectation assessment."""
    from mlflow.entities.assessment import Expectation
    from mlflow.entities.assessment_source import AssessmentSource

    return Expectation(
        name="correctness",
        value="expected_value",
        source=AssessmentSource(source_type="HUMAN", source_id="user1"),
        span_id="span-001",
    )


def _make_feedback(with_error=False):
    """Create a minimal Feedback assessment, optionally with an error."""
    from mlflow.entities.assessment import Feedback
    from mlflow.entities.assessment_error import AssessmentError
    from mlflow.entities.assessment_source import AssessmentSource

    if with_error:
        error = AssessmentError(
            error_code="ERR_001",
            error_message="Something went wrong",
            stack_trace="Traceback...",
        )
        return Feedback(
            name="quality",
            value=0.95,
            error=error,
            source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
            span_id="span-002",
            overrides="orig-001",
            valid=False,
        )
    else:
        return Feedback(
            name="quality",
            value=0.95,
            source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
            span_id="span-002",
        )


# ---------------------------------------------------------------------------
# C25: SearchTracesTool is importable from genai.judges.tools
# ---------------------------------------------------------------------------

def check_import_search_traces_tool() -> None:
    """Contracts: C25"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    assert SearchTracesTool is not None
    # Verify it's a class that inherits from JudgeTool
    from mlflow.genai.judges.tools.base import JudgeTool

    assert issubclass(SearchTracesTool, JudgeTool)
    print("PASS: check_import_search_traces_tool")


# ---------------------------------------------------------------------------
# C1: name property returns ToolNames._SEARCH_TRACES
# ---------------------------------------------------------------------------

def check_name_property_returns_search_traces_constant() -> None:
    """Contracts: C1"""
    from mlflow.genai.judges.tools.constants import ToolNames
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tool = SearchTracesTool()
    assert tool.name == "_search_traces"
    assert tool.name == ToolNames._SEARCH_TRACES
    print("PASS: check_name_property_returns_search_traces_constant")


# ---------------------------------------------------------------------------
# C2: get_definition().function.name == "_search_traces"
# ---------------------------------------------------------------------------

def check_get_definition_function_name() -> None:
    """Contracts: C2"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.types.llm import ToolDefinition

    tool = SearchTracesTool()
    definition = tool.get_definition()
    assert isinstance(definition, ToolDefinition)
    assert definition.function.name == "_search_traces"
    print("PASS: check_get_definition_function_name")


# ---------------------------------------------------------------------------
# C3: get_definition().type == "function"
# ---------------------------------------------------------------------------

def check_get_definition_type_is_function() -> None:
    """Contracts: C3"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tool = SearchTracesTool()
    definition = tool.get_definition()
    assert definition.type == "function"
    print("PASS: check_get_definition_type_is_function")


# ---------------------------------------------------------------------------
# C4: filter_string optional string parameter
# ---------------------------------------------------------------------------

def check_get_definition_filter_string_param() -> None:
    """Contracts: C4"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.types.llm import ParamProperty

    tool = SearchTracesTool()
    definition = tool.get_definition()
    props = definition.function.parameters.properties
    assert "filter_string" in props
    filter_param = props["filter_string"]
    assert isinstance(filter_param, ParamProperty)
    assert filter_param.type == "string"
    assert filter_param.description is not None
    assert len(filter_param.description) > 0
    # filter_string should NOT be in required
    required = definition.function.parameters.required or []
    assert "filter_string" not in required
    print("PASS: check_get_definition_filter_string_param")


# ---------------------------------------------------------------------------
# C5: order_by optional array-of-strings parameter
# ---------------------------------------------------------------------------

def check_get_definition_order_by_param() -> None:
    """Contracts: C5"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.types.llm import ParamProperty

    tool = SearchTracesTool()
    definition = tool.get_definition()
    props = definition.function.parameters.properties
    assert "order_by" in props
    order_param = props["order_by"]
    assert isinstance(order_param, ParamProperty)
    assert order_param.type == "array"
    assert order_param.items is not None
    assert order_param.items.type == "string"
    assert order_param.description is not None
    # order_by should NOT be in required
    required = definition.function.parameters.required or []
    assert "order_by" not in required
    print("PASS: check_get_definition_order_by_param")


# ---------------------------------------------------------------------------
# C6: max_results optional integer parameter with default mention
# ---------------------------------------------------------------------------

def check_get_definition_max_results_param() -> None:
    """Contracts: C6"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.types.llm import ParamProperty

    tool = SearchTracesTool()
    definition = tool.get_definition()
    props = definition.function.parameters.properties
    assert "max_results" in props
    max_param = props["max_results"]
    assert isinstance(max_param, ParamProperty)
    assert max_param.type == "integer"
    assert max_param.description is not None
    # max_results should NOT be in required
    required = definition.function.parameters.required or []
    assert "max_results" not in required
    print("PASS: check_get_definition_max_results_param")


# ---------------------------------------------------------------------------
# C7: get_definition has empty required list
# ---------------------------------------------------------------------------

def check_get_definition_empty_required() -> None:
    """Contracts: C7"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    tool = SearchTracesTool()
    definition = tool.get_definition()
    required = definition.function.parameters.required
    assert required == [] or required is None or len(required) == 0
    print("PASS: check_get_definition_empty_required")


# ---------------------------------------------------------------------------
# C14: _get_experiment_id returns experiment_id string for valid trace
# ---------------------------------------------------------------------------

def check_get_experiment_id_returns_experiment_id() -> None:
    """Contracts: C14"""
    from mlflow.genai.judges.tools.search_traces import _get_experiment_id

    trace = _make_trace_with_location(experiment_id="exp-valid-42")
    result = _get_experiment_id(trace)
    assert result == "exp-valid-42"
    assert isinstance(result, str)
    print("PASS: check_get_experiment_id_returns_experiment_id")


# ---------------------------------------------------------------------------
# C11: invoke returns list of JudgeToolTraceInfo on success
# ---------------------------------------------------------------------------

def check_invoke_returns_list_of_judge_tool_trace_info() -> None:
    """Contracts: C11"""
    from unittest.mock import patch

    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo

    trace = _make_trace_with_location(experiment_id="exp-001")

    # Create a mock search result Trace
    result_trace = _make_trace_with_location(experiment_id="exp-001")
    result_trace.info.trace_id = "found-tr-001"

    with patch(
        "mlflow.genai.judges.tools.search_traces.TracingClient"
    ) as mock_client_cls:
        mock_client = mock_client_cls.return_value
        mock_client.search_traces.return_value = [result_trace]

        tool = SearchTracesTool()
        results = tool.invoke(trace, max_results=1)

    assert isinstance(results, list)
    assert len(results) >= 1
    assert isinstance(results[0], JudgeToolTraceInfo)
    print("PASS: check_invoke_returns_list_of_judge_tool_trace_info")


# ---------------------------------------------------------------------------
# C24: invoke passes include_spans=True to search_traces
# F1 repair: also verify experiment_ids forwarding (C11/E4 dataflow)
# ---------------------------------------------------------------------------

def check_invoke_passes_include_spans_and_experiment_ids_to_search_traces() -> None:
    """Contracts: C24, F1 (experiment_ids forwarding)
    
    Reference: Task requires search within the same experiment context.
    IR edge E4: experiment_ids=[experiment_id] -> PagedList[Trace].
    """
    from unittest.mock import patch

    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace = _make_trace_with_location(experiment_id="exp-001")

    result_trace = _make_trace_with_location(experiment_id="exp-001")

    with patch(
        "mlflow.genai.judges.tools.search_traces.TracingClient"
    ) as mock_client_cls:
        mock_client = mock_client_cls.return_value
        mock_client.search_traces.return_value = [result_trace]

        tool = SearchTracesTool()
        tool.invoke(trace, max_results=5)

    # Verify search_traces was called with include_spans=True
    call_kwargs = mock_client.search_traces.call_args.kwargs
    assert call_kwargs.get("include_spans") is True, (
        f"Expected include_spans=True, got {call_kwargs.get('include_spans')}"
    )
    # F1: Verify experiment_ids is forwarded from the trace's experiment context
    assert call_kwargs.get("experiment_ids") == ["exp-001"], (
        f"Expected experiment_ids=['exp-001'], got {call_kwargs.get('experiment_ids')}"
    )
    print("PASS: check_invoke_passes_include_spans_and_experiment_ids_to_search_traces")


# ---------------------------------------------------------------------------
# C12: invoke defaults order_by to ['timestamp ASC'] when None
# ---------------------------------------------------------------------------

def check_invoke_defaults_order_by_to_timestamp_asc() -> None:
    """Contracts: C12"""
    from unittest.mock import patch

    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace = _make_trace_with_location(experiment_id="exp-001")

    result_trace = _make_trace_with_location(experiment_id="exp-001")

    with patch(
        "mlflow.genai.judges.tools.search_traces.TracingClient"
    ) as mock_client_cls:
        mock_client = mock_client_cls.return_value
        mock_client.search_traces.return_value = [result_trace]

        tool = SearchTracesTool()
        tool.invoke(trace, order_by=None)

    call_kwargs = mock_client.search_traces.call_args.kwargs
    assert call_kwargs.get("order_by") == ["timestamp ASC"], (
        f"Expected order_by=['timestamp ASC'], got {call_kwargs.get('order_by')}"
    )
    print("PASS: check_invoke_defaults_order_by_to_timestamp_asc")


# ---------------------------------------------------------------------------
# C13: invoke defaults max_results to 20
# ---------------------------------------------------------------------------

def check_invoke_defaults_max_results_to_20() -> None:
    """Contracts: C13"""
    from unittest.mock import patch

    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace = _make_trace_with_location(experiment_id="exp-001")

    result_trace = _make_trace_with_location(experiment_id="exp-001")

    with patch(
        "mlflow.genai.judges.tools.search_traces.TracingClient"
    ) as mock_client_cls:
        mock_client = mock_client_cls.return_value
        mock_client.search_traces.return_value = [result_trace]

        tool = SearchTracesTool()
        tool.invoke(trace)  # No max_results specified

    call_kwargs = mock_client.search_traces.call_args.kwargs
    assert call_kwargs.get("max_results") == 20, (
        f"Expected max_results=20, got {call_kwargs.get('max_results')}"
    )
    print("PASS: check_invoke_defaults_max_results_to_20")


# ---------------------------------------------------------------------------
# C15: _convert_assessments_to_tool_types converts Expectation
# ---------------------------------------------------------------------------

def check_convert_expectation_to_judge_tool_expectation() -> None:
    """Contracts: C15"""
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolExpectation

    expectation = _make_expectation()
    result = _convert_assessments_to_tool_types([expectation])

    assert len(result) == 1
    converted = result[0]
    assert isinstance(converted, JudgeToolExpectation)
    assert converted.name == expectation.name
    assert converted.source == expectation.source.source_type
    assert converted.rationale == expectation.rationale
    assert converted.span_id == expectation.span_id
    assert converted.assessment_id == expectation.assessment_id
    assert converted.value == expectation.value
    print("PASS: check_convert_expectation_to_judge_tool_expectation")


# ---------------------------------------------------------------------------
# C16: _convert_assessments_to_tool_types converts Feedback with error fields
# ---------------------------------------------------------------------------

def check_convert_feedback_to_judge_tool_feedback_with_error() -> None:
    """Contracts: C16"""
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolFeedback

    feedback = _make_feedback(with_error=True)
    result = _convert_assessments_to_tool_types([feedback])

    assert len(result) == 1
    converted = result[0]
    assert isinstance(converted, JudgeToolFeedback)
    assert converted.name == feedback.name
    assert converted.source == feedback.source.source_type
    assert converted.rationale == feedback.rationale
    assert converted.span_id == feedback.span_id
    assert converted.assessment_id == feedback.assessment_id
    assert converted.value == feedback.value
    assert converted.error_code == "ERR_001"
    assert converted.error_message == "Something went wrong"
    assert converted.stack_trace == "Traceback..."
    assert converted.overrides == "orig-001"
    assert converted.valid is False
    print("PASS: check_convert_feedback_to_judge_tool_feedback_with_error")


def check_convert_feedback_without_error_sets_none_fields() -> None:
    """Contracts: C16 - error fields are None when no error"""
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolFeedback

    feedback = _make_feedback(with_error=False)
    result = _convert_assessments_to_tool_types([feedback])

    assert len(result) == 1
    converted = result[0]
    assert isinstance(converted, JudgeToolFeedback)
    assert converted.error_code is None
    assert converted.error_message is None
    assert converted.stack_trace is None
    print("PASS: check_convert_feedback_without_error_sets_none_fields")


# ---------------------------------------------------------------------------
# F6 repair: L2 caller binding – GetTracesInSession -> SearchTracesTool (E1)
#
# Perspective: Native test test_get_traces_in_session_tool_invoke_success
#   verifies mock_search_tool.invoke.assert_called_once_with(trace=...,
#   filter_string=..., order_by=..., max_results=...). The arch_spec must
#   execute the real caller and observe the binding plus downstream args.
# ---------------------------------------------------------------------------

def check_get_traces_in_session_calls_search_traces_tool() -> None:
    """Contracts: E1, P5 — cross-module caller binding
    
    Executes GetTracesInSession.invoke (the real caller) with a trace that has
    a session ID, spies on SearchTracesTool.invoke, and asserts the call
    signature matches what GetTracesInSession constructs. This proves the
    import binding (E11) and the caller-to-helper call chain (E1).
    """
    from unittest.mock import patch

    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import TraceLocation
    from mlflow.entities.trace_state import TraceState
    from mlflow.genai.judges.tools.get_traces_in_session import GetTracesInSession
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.tracing.constant import TraceMetadataKey

    # Build a trace with a session ID in metadata
    trace_info = TraceInfo(
        trace_id="current-trace",
        trace_location=TraceLocation.from_experiment_id("exp-123"),
        request_time=1234567890,
        state=TraceState.OK,
        execution_duration=250,
        trace_metadata={TraceMetadataKey.TRACE_SESSION: "session-789"},
    )
    trace = Trace(info=trace_info, data=TraceData(spans=[]))

    with patch.object(SearchTracesTool, "invoke", return_value=[]) as mock_invoke:
        tool = GetTracesInSession()
        tool.invoke(trace, max_results=10, order_by=["timestamp DESC"])

    # Verify SearchTracesTool.invoke was called with the correct arguments
    # that GetTracesInSession constructs (filter_string includes session ID,
    # trace.timestamp < trace.request_time)
    mock_invoke.assert_called_once()
    call_kwargs = mock_invoke.call_args.kwargs
    assert call_kwargs["trace"] == trace
    assert TraceMetadataKey.TRACE_SESSION in call_kwargs["filter_string"]
    assert "session-789" in call_kwargs["filter_string"]
    assert "trace.timestamp < 1234567890" in call_kwargs["filter_string"]
    assert call_kwargs["order_by"] == ["timestamp DESC"]
    assert call_kwargs["max_results"] == 10
    print("PASS: check_get_traces_in_session_calls_search_traces_tool")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    check_import_search_traces_tool()
    check_name_property_returns_search_traces_constant()
    check_get_definition_function_name()
    check_get_definition_type_is_function()
    check_get_definition_filter_string_param()
    check_get_definition_order_by_param()
    check_get_definition_max_results_param()
    check_get_definition_empty_required()
    check_get_experiment_id_returns_experiment_id()
    check_invoke_returns_list_of_judge_tool_trace_info()
    check_invoke_passes_include_spans_and_experiment_ids_to_search_traces()
    check_invoke_defaults_order_by_to_timestamp_asc()
    check_invoke_defaults_max_results_to_20()
    check_convert_expectation_to_judge_tool_expectation()
    check_convert_feedback_to_judge_tool_feedback_with_error()
    check_convert_feedback_without_error_sets_none_fields()
    check_get_traces_in_session_calls_search_traces_tool()
    print("\nAll architecture spec checks PASSED.")
    sys.exit(0)
