# Spec Review Report

Decision: REWORK

## Evidence Reviewed
- Test Spec skill: `/installed-agent/codespec2/test_spec_skill.md` — mandatory arch/behavior spec design procedure, caller-binding requirement, cross-spec contract sharing rules, and per-trace error handling fixture guidance (L5).
- Semantic IR: 25 L3 contracts (C1–C25), 13 edges (E1–E13), 8 L1 obligations (R1–R10).
- Native tests:
  - `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — verifies `MlflowException` with exact message `"Invalid assessment source type"` and `pytest.raises(match=...)` pattern
  - `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — verifies `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")`
  - `tests/entities/test_assessment_source.py::test_assessment_source_case_insensitivity` — verifies source types are normalized to uppercase through `AssessmentSource` creation
  - `tests/entities/test_assessment.py::test_assessment_creation` — verifies `feedback.error.error_code`, `feedback.error.error_message` access path
  - `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_no_session_id` — verifies `exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)` on raised `MlflowException`
  - `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_success` — verifies that `SearchTracesTool().invoke()` is called with specific keyword arguments from `GetTracesInSession.invoke`
- Arch spec: `/agent-logs/.../arch_spec.py` — 16 check functions covering C1–C7, C11–C16, C24, C25
- Behavior spec: `/agent-logs/.../behavior_spec.py` — 12 check functions covering C8–C11, C17–C23, plus integration check for E12

## Rubric
- Requirement coverage: 1 — All 25 contracts have at least one check, but several checks are weak (see Findings F2–F5) and two critical dataflow paths are unobserved (F1, F6).
- Caller binding / call chain: 0 — No arch_spec check executes `GetTracesInSession.invoke` (the real caller of `SearchTracesTool`) and observes the binding plus downstream `TracingClient.search_traces` arguments. The Skill doc requires this for every material L2 cross-module CALL (E1).
- Dataflow / state / lifecycle: 1 — Field-level mapping in C11 is weak (non-None checks for request/response, `isinstance(list)` for assessments). No check verifies `experiment_ids` is forwarded to `search_traces`. Conversion order (C17) and field mapping (C15/C16) are solid.
- Failure / compatibility boundaries: 1 — Exception message assertions for C8/C9/C10 are too broad (matching any string containing "location" or "experiment"). No error_code checks on MlflowException (native pattern from P3). C23 depends on a single ad-hoc fixture (`assessments=None`).

## Derived Practical Test Perspectives
- **P1**: `tests/entities/test_assessment_source.py::test_assessment_source_type_validation` — native test uses `pytest.raises(MlflowException, match="Invalid assessment source type")` for exact message matching. Generated specs should use the same exact-match pattern for exception messages instead of broad substring checks.
- **P2**: `tests/entities/test_assessment_source.py::test_ai_judge_deprecation_warning` — native test uses `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` for exact warning matching. Generated specs should use `pytest.warns` with exact match rather than `warnings.catch_warnings` with loose substring checks.
- **P3**: `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_no_session_id` — native test verifies `exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)`. Generated failure checks (C8, C9, C10) should also assert `error_code` on the raised `MlflowException`.
- **P4**: `tests/entities/test_assessment.py::test_assessment_creation` — native test verifies `feedback.error.error_code == "E001"` path from real Assessment objects. The arch_spec C16 checks already cover this well through real `Feedback` fixtures.
- **P5**: `tests/genai/judges/test_judge_tool_get_traces_in_session.py::test_get_traces_in_session_tool_invoke_success` — native test verifies the caller binding: `mock_search_tool.invoke.assert_called_once_with(trace=..., filter_string=..., order_by=..., max_results=...)`. The arch_spec must include a similar caller-binding check for `SearchTracesTool` being invoked through `GetTracesInSession`.

## Final Rubric Scores
- Requirement coverage: 1 — All contracts present but some checks are too weak to discriminate correct from incorrect implementations.
- Caller binding / call chain: 0 — No cross-module caller binding test for E1 (`GetTracesInSession.invoke` → `SearchTracesTool.invoke`).
- Dataflow / state / lifecycle: 1 — Missing `experiment_ids` forwarding check; weak C11 field assertions.
- Failure / compatibility boundaries: 1 — Missing error_code assertions; too-broad exception message patterns; C23 conversion fixture is ad-hoc.
- P1: 1 — C20 uses exact match `"Invalid assessment source type"` but C8/C9/C10 use broad substring patterns inconsistent with native practice.
- P2: 1 — C19 checks warning message content but uses `catch_warnings` + substring rather than the native `pytest.warns(match=...)` pattern.
- P3: 0 — No error_code assertion on any MlflowException in C8, C9, C10, or C22.
- P4: 2 — C15/C16 tests construct real `Expectation`/`Feedback` and verify all field paths including `feedback.error.error_code`, matching native practice.
- P5: 0 — No caller-binding test for E1 cross-module CALL.

## Findings

### F1: missing_requirement
- Requirement/IR: R3, E4, C11 — `experiment_ids` forwarding
- Evidence: Task interface doc: "Search for traces within the same experiment as the current trace"; IR edge E4: `(experiment_ids=[experiment_id], ...) → PagedList[Trace]`
- Gap: No check in either arch_spec or behavior_spec verifies that `experiment_ids=[experiment_id]` is passed to `TracingClient.search_traces`. The arch_spec checks `include_spans`, `order_by`, and `max_results` but omits the primary purpose of `_get_experiment_id`: scoping the search to the correct experiment.
- Repair: Add to arch_spec: a check that patches `TracingClient`, calls `SearchTracesTool().invoke()`, and asserts `mock_client.search_traces.call_args.kwargs["experiment_ids"] == ["exp-001"]` (matching the experiment_id from the fixture trace).

### F2: weak_constraint
- Requirement/IR: R4, C8, C9, C10 — exception message assertions
- Evidence: Native test `test_assessment_source_type_validation` uses `pytest.raises(MlflowException, match="Invalid assessment source type")` (exact substring match). Behavior spec C8 uses `"trace location" in str(e).lower() or "location" in str(e).lower()` which matches any string containing "location".
- Gap: The C8 assertion matches `"location"` in any message, which would pass for an unrelated error. C9 matches `"experiment" in msg or "mlflow" in msg` — overly broad. C10 matches `"experiment" in msg or "experiment_id" in msg` — also broad. These cannot distinguish a correct error message from a misrouted or generic one.
- Repair: Tighten each to an exact required phrase: C8 must match `"trace location"` (or the actual message produced by `_get_experiment_id`), C9 must match `"MLflow experiment"`, C10 must match `"experiment_id"`. Use `pytest.raises(MlflowException, match=...)` consistently.

### F3: weak_constraint
- Requirement/IR: R5, C23 — per-trace conversion error handling
- Evidence: Task: "Traces that fail to process during retrieval are logged as warnings and skipped." Behavior spec C23 uses `bad_trace.info.assessments = None` as the trigger.
- Gap: The fixture is brittle — it depends on the implementation iterating over `trace.info.assessments` which will `TypeError` on `None`. But the implementation might iterate over `getattr(trace.info, 'assessments', [])` and silently produce zero assessments, never triggering the warning path. The test also does not verify the warning message content.
- Repair: Use a fixture trace where `info.assessments` is a list containing a deliberately malformed assessment object. Verify the warning message contains the trace ID that failed. Also verify that both the count of returned traces and their identities are correct (the good trace is present, the bad one is absent).

### F4: missing_requirement
- Requirement/IR: P3 perspective — error_code on MlflowException
- Evidence: Native test `test_get_traces_in_session_tool_invoke_no_session_id`: `assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)`. The existing `GetTracesInSession` raises `MlflowException(..., error_code=INVALID_PARAMETER_VALUE)`. By the task description, SearchTracesTool errors should be consistent.
- Gap: None of C8, C9, C10, or C22 verify the `error_code` field on the raised `MlflowException`. The `_get_experiment_id` and `invoke` implementations should set `error_code=INVALID_PARAMETER_VALUE` for validation errors, matching the pattern in `GetTracesInSession`.
- Repair: Add `assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)` to C8, C9, C10 checks. For C22, assert the error propagates with a meaningful error_code.

### F5: weak_constraint
- Requirement/IR: R10, C11 — JudgeToolTraceInfo field mapping
- Evidence: Behavior spec `check_invoke_result_fields_match_trace_info` asserts `info.request is not None`, `info.response is not None`, `isinstance(info.assessments, list)`. Task: "request: Input data/parameters for the trace", "response: Output data/results from the trace".
- Gap: `is not None` does not verify that request/response hold the actual trace data. A plausible wrong implementation that returns `"dummy"` for every field would pass. Similarly, `isinstance(list)` for assessments does not verify that assessments were actually converted.
- Repair: Set `result_trace.info.request_preview = '{"q":"hello"}'` and `result_trace.info.response_preview = '{"a":"world"}'` (as the spec already does), then assert `info.request == '{"q":"hello"}'` and `info.response == '{"a":"world"}'`. For assessments, verify at least one assessment is present and is the correct `JudgeToolExpectation`/`JudgeToolFeedback` type.

### F6: missing_requirement
- Requirement/IR: E1, P5 perspective — L2 caller binding (`GetTracesInSession.invoke` → `SearchTracesTool.invoke`)
- Evidence: Skill doc: "For every material L2 cross-module CALL, check that arch_spec.py executes the real caller and observes its helper/caller binding plus downstream result." IR edge E1 defines the call from `GetTracesInSession.invoke` to `SearchTracesTool().invoke()`. Native test `test_get_traces_in_session_tool_invoke_success` verifies `mock_search_tool.invoke.assert_called_once_with(trace=..., filter_string=..., order_by=..., max_results=...)`.
- Gap: Neither arch_spec nor behavior_spec exercises the caller binding. The arch_spec directly instantiates `SearchTracesTool` and never imports or calls `GetTracesInSession`. A broken import in `get_traces_in_session.py` (e.g., missing `from mlflow.genai.judges.tools.search_traces import SearchTracesTool`) would go undetected.
- Repair: Add an arch_spec check that imports `GetTracesInSession`, creates a real trace with a session ID in metadata, patches `SearchTracesTool.invoke` to return a list of `JudgeToolTraceInfo`, calls `GetTracesInSession().invoke(trace)`, and asserts that `SearchTracesTool.invoke` was called with the correct filter_string including the session ID. This proves the import binding (E11) and the caller-to-helper call chain (E1).

### F7: weak_constraint
- Requirement/IR: C22 — search failure error propagation
- Evidence: Behavior spec `check_invoke_raises_on_search_failure` patches `search_traces.side_effect = RuntimeError("Search backend error")` and catches `MlflowException`. But `TracingClient.search_traces` in reality raises `MlflowException` (not `RuntimeError`).
- Gap: Mocking a `RuntimeError` is unrealistic — the actual `TracingClient.search_traces` raises `MlflowException` subclasses for invalid syntax or backend errors. The test should mock the actual exception type that `search_traces` would raise (e.g., `MlflowException`) and verify that the invoke method either re-raises it or wraps it appropriately.
- Repair: Change the side_effect to `MlflowException("Invalid filter syntax", error_code=INVALID_PARAMETER_VALUE)` and verify the exception propagates with the original error_code and message preserved (or wrapped with context).

## Rework Instructions
1. **Add `experiment_ids` forwarding check (F1)**: In arch_spec, add a check that `call_kwargs.get("experiment_ids") == ["exp-001"]` in either `check_invoke_passes_include_spans_true_to_search_traces` or a new dedicated check.

2. **Tighten exception message assertions (F2)**: Replace broad substring checks in C8/C9/C10 with exact required phrases using `pytest.raises(match=...)`. Use the actual messages that `_get_experiment_id` or `invoke` should produce: e.g., `"No trace location"`, `"not an MLflow experiment"`, `"No experiment_id"`.

3. **Add error_code assertions (F4)**: In C8, C9, C10, C22, assert `e.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)` on the caught `MlflowException`, matching the native `GetTracesInSession` pattern.

4. **Strengthen C11 field mapping (F5)**: Change `assert info.request is not None` to `assert info.request == '{"q":"hello"}'` and similarly for response. Add at least one real assessment to the result trace and verify it appears in `info.assessments` as the correct type.

5. **Add caller-binding test for E1 (F6)**: In arch_spec, add `check_get_traces_in_session_calls_search_traces_tool()` that exercises `GetTracesInSession.invoke` with a trace containing a session ID, patches `SearchTracesTool.invoke`, and asserts the call signature matches what `GetTracesInSession` constructs.

6. **Use realistic search failure mock (F7)**: Change C22 side_effect to `MlflowException(...)` instead of `RuntimeError`.

7. **Strengthen C23 fixture (F3)**: Replace `bad_trace.info.assessments = None` with a trace whose `info.assessments` list contains a deliberately malformed assessment object. Verify the warning message mentions the failing trace ID.

8. **Adopt `pytest.warns` for C19 (P2)**: Replace `warnings.catch_warnings` pattern with `pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")` to match native test practice.
