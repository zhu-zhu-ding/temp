# Semantic IR

## L1. Requirement Obligations

### R1: SearchTracesTool class exposes name property returning ToolNames._SEARCH_TRACES
- Type: Interface
- Statement: The `SearchTracesTool.name` property must return the constant `ToolNames._SEARCH_TRACES` (value `"_search_traces"`).
- Task Evidence: "Get the name identifier for the SearchTracesTool... This property returns the standardized tool name used to identify this tool within the MLflow GenAI judges framework."
- Acceptance: `SearchTracesTool().name` evaluates to `"_search_traces"`.
- Repository Evidence: `mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; `mlflow/genai/judges/tools/base.py:JudgeTool.name` abstract property; `mlflow/genai/judges/tools/get_trace_info.py:GetTraceInfoTool.name` returns `ToolNames.GET_TRACE_INFO` (pattern).
- Uncertainty: None.

### R2: SearchTracesTool provides get_definition returning ToolDefinition with name, description, and three optional parameters
- Type: Interface
- Statement: `get_definition()` must return a `ToolDefinition` whose `function` contains: `name=ToolNames._SEARCH_TRACES`, a non-empty description, and a `ToolParamsSchema` with three optional properties (`filter_string` as string, `order_by` as array of strings, `max_results` as integer with default 20).
- Task Evidence: "Get the tool definition for the SearchTracesTool... Returns: ToolDefinition... The function definition includes: name: The tool name from ToolNames._SEARCH_TRACES, description: Detailed explanation... parameters: ToolParamsSchema defining three optional parameters..."
- Acceptance: `SearchTracesTool().get_definition()` returns `ToolDefinition` with `function.name == "_search_traces"`, `function.parameters.properties` containing keys `filter_string`, `order_by`, `max_results`, and `function.parameters.required == []`.
- Repository Evidence: `mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`; `mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.get_definition()` (pattern for optional parameters with defaults).
- Uncertainty: None.

### R3: SearchTracesTool.invoke validates experiment context and searches traces
- Type: Behavior
- Statement: `invoke(trace, filter_string, order_by, max_results)` must extract the experiment ID from the trace, invoke MLflow's trace search with that experiment scope, and return a list of `JudgeToolTraceInfo` objects.
- Task Evidence: "Search for traces within the same experiment as the current trace... This method enables searching and retrieving traces from the same MLflow experiment context as the provided trace."
- Acceptance: When called with a valid trace having an MLflow experiment location, returns `list[JudgeToolTraceInfo]` with results matching the filter/order/limit constraints.
- Repository Evidence: `mlflow/tracing/client.py:TracingClient.search_traces()` accepts `experiment_ids`, `filter_string`, `max_results`, `order_by`; `mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke()` delegates to `SearchTracesTool().invoke()` (caller evidence).
- Uncertainty: None.

### R4: SearchTracesTool.invoke raises MlflowException when trace lacks valid experiment context
- Type: Failure
- Statement: If the trace has no `trace_location`, is not of type `MLFLOW_EXPERIMENT`, or has no `experiment_id`, `invoke()` must raise `MlflowException`.
- Task Evidence: "Raises: MlflowException... The provided trace has no trace location information... The trace is not from an MLflow experiment context... The trace has no associated experiment_id."
- Acceptance: Calling `invoke()` with a trace missing location/experiment raises `MlflowException`.
- Repository Evidence: `mlflow/entities/trace_location.py:TraceLocation`, `TraceLocationType.MLFLOW_EXPERIMENT`; `mlflow/exceptions.py:MlflowException`.
- Uncertainty: None.

### R5: SearchTracesTool.invoke gracefully handles per-trace conversion errors with warnings
- Type: Failure
- Statement: When processing search results, individual traces that fail to convert to `JudgeToolTraceInfo` must be logged as warnings and skipped rather than causing the entire invocation to fail.
- Task Evidence: "Traces that fail to process during retrieval are logged as warnings and skipped."
- Acceptance: When one trace in results cannot be processed, a warning is logged and remaining traces are still returned.
- Repository Evidence: `mlflow/genai/judges/tools/search_traces.py:_logger = logging.getLogger(__name__)` (logger is available); task is sole source for this specific behavior.
- Uncertainty: Exact exception types caught during per-trace conversion are not specified.

### R6: _get_experiment_id extracts and validates experiment ID from trace location
- Type: Behavior
- Statement: `_get_experiment_id(trace)` must return the experiment ID string from `trace.info.trace_location.mlflow_experiment.experiment_id` after validating that the location exists, is `MLFLOW_EXPERIMENT` type, and has a non-None experiment_id.
- Task Evidence: "Extract and validate the experiment ID from a trace object... validates that the trace originates from an MLflow experiment context."
- Acceptance: Returns experiment ID string for valid traces; raises `MlflowException` otherwise.
- Repository Evidence: `mlflow/entities/trace_info.py:TraceInfo.trace_location`; `mlflow/entities/trace_location.py:MlflowExperimentLocation.experiment_id`, `TraceLocationType.MLFLOW_EXPERIMENT`; `mlflow/entities/trace.py:Trace.info`.
- Uncertainty: None.

### R7: _convert_assessments_to_tool_types converts Assessment objects to JudgeToolExpectation/JudgeToolFeedback
- Type: Dataflow
- Statement: Given a list of `Assessment` objects (mixed `Expectation` and `Feedback`), the function must return a list of corresponding `JudgeToolExpectation` and `JudgeToolFeedback` objects preserving order.
- Task Evidence: "Convert MLflow Assessment objects to their corresponding judge tool type representations... Expectation objects are converted to JudgeToolExpectation instances... Feedback objects are converted to JudgeToolFeedback instances with additional error handling fields..."
- Acceptance: For each `Expectation`, returns `JudgeToolExpectation(name, source, rationale, span_id, assessment_id, value)`. For each `Feedback`, returns `JudgeToolFeedback(name, source, rationale, span_id, assessment_id, value, error_code, error_message, stack_trace, overrides, valid)`.
- Repository Evidence: `mlflow/entities/assessment.py:Expectation`, `Feedback`, `Assessment`; `mlflow/genai/judges/tools/types.py:JudgeToolExpectation`, `JudgeToolFeedback`; `mlflow/entities/assessment_source.py:AssessmentSource.source_type`; `mlflow/entities/assessment_error.py:AssessmentError`.
- Uncertainty: None.

### R8: AssessmentSourceType._standardize normalizes case and handles AI_JUDGE deprecation
- Type: Behavior
- Statement: `AssessmentSourceType._standardize(source_type: str) -> str` must uppercase the input, issue a `FutureWarning` when input is `"AI_JUDGE"` (converting to `"LLM_JUDGE"`), and raise `MlflowException` for invalid values.
- Task Evidence: "Standardize and validate an assessment source type string... handles case normalization, deprecation warnings, and validation."
- Acceptance: `"human"` → `"HUMAN"`; `"AI_JUDGE"` → `"LLM_JUDGE"` with `FutureWarning`; `"INVALID"` → `MlflowException`.
- Repository Evidence: `tests/entities/test_assessment_source.py:test_assessment_source_case_insensitivity`, `test_ai_judge_deprecation_warning`, `test_assessment_source_type_validation`; `mlflow/entities/assessment_source.py:AssessmentSourceType._SOURCE_TYPES`.
- Uncertainty: None.

### R9: SearchTracesTool.invoke uses default order_by ['timestamp ASC'] and default max_results 20
- Type: State
- Statement: When `order_by` is None, the search must default to `['timestamp ASC']`. When `max_results` is not specified, it defaults to 20.
- Task Evidence: "order_by: Optional list of order by expressions... Defaults to ['timestamp ASC']... max_results: Maximum number of traces to return... Defaults to 20."
- Acceptance: Calling `invoke(trace)` without order_by or max_results uses `['timestamp ASC']` and 20 respectively.
- Repository Evidence: Interface Description; `mlflow/tracing/client.py:TracingClient.search_traces` accepts `order_by` and `max_results`.
- Uncertainty: None.

### R10: SearchTracesTool.invoke converts Trace search results to JudgeToolTraceInfo
- Type: Dataflow
- Statement: Each `Trace` returned from MLflow search must be mapped to a `JudgeToolTraceInfo` with: `trace_id` from `trace.info.trace_id`, `request_time` from `trace.info.request_time`, `state` from `trace.info.state`, `request` from `trace.info.request_preview`, `response` from `trace.info.response_preview`, `execution_duration` from `trace.info.execution_duration`, and `assessments` from `_convert_assessments_to_tool_types(trace.info.assessments)`.
- Task Evidence: "Returns: List of JudgeToolTraceInfo objects, each containing: trace_id, request_time, state, request, response, execution_duration, assessments."
- Acceptance: Output `JudgeToolTraceInfo` fields match corresponding `TraceInfo` fields.
- Repository Evidence: `mlflow/entities/trace_info.py:TraceInfo` fields; `mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`.
- Uncertainty: None.

## L2. Functional Design Graph

### N1: SearchTracesTool
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool`

### N2: SearchTracesTool.name
- Kind: Method (property)
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/search_traces.py` (declared in interface)

### N3: SearchTracesTool.get_definition
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/search_traces.py` (declared in interface)

### N4: SearchTracesTool.invoke
- Kind: Method
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/search_traces.py` (declared in interface)

### N5: JudgeTool (base class)
- Kind: Class
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool`

### N6: ToolNames._SEARCH_TRACES
- Kind: State
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`

### N7: ToolDefinition / FunctionToolDefinition / ToolParamsSchema
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`

### N8: JudgeToolTraceInfo
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`

### N9: JudgeToolExpectation
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation`

### N10: JudgeToolFeedback
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolFeedback`

### N11: _get_experiment_id
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/search_traces.py` (declared in interface)

### N12: _convert_assessments_to_tool_types
- Kind: Function
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/search_traces.py` (declared in interface)

### N13: Trace
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace.py:Trace`

### N14: TraceInfo
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_info.py:TraceInfo`

### N15: TraceLocation / TraceLocationType / MlflowExperimentLocation
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/trace_location.py`

### N16: Assessment (Expectation / Feedback)
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/assessment.py:Assessment`, `Expectation`, `Feedback`

### N17: AssessmentSource / AssessmentSourceType
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSource`, `AssessmentSourceType`

### N18: AssessmentError
- Kind: Payload
- Repository Evidence: `/testbed/mlflow/entities/assessment_error.py:AssessmentError`

### N19: TracingClient.search_traces
- Kind: External
- Repository Evidence: `/testbed/mlflow/tracing/client.py:TracingClient.search_traces`

### N20: MlflowException
- Kind: Error
- Repository Evidence: `/testbed/mlflow/exceptions.py:MlflowException`

### N21: GetTracesInSession (caller)
- Kind: PublicEntry
- Repository Evidence: `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:GetTracesInSession.invoke` calls `SearchTracesTool().invoke()`

### N22: AssessmentSourceType._standardize
- Kind: Method (static)
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._standardize` (declared in interface, called by `AssessmentSource.__post_init__`)

### N23: AssessmentSource.__post_init__
- Kind: Method
- Repository Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__`

---

### E1: N21 -> N4 (GetTracesInSession calls SearchTracesTool.invoke)
- Kind: CALL
- Condition: Always (when GetTracesInSession.invoke is called)
- Transfer: `(trace, filter_string, order_by, max_results) -> list[JudgeToolTraceInfo]`
- Evidence: `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py:SearchTracesTool().invoke(trace=trace, filter_string=filter_string, order_by=order_by, max_results=max_results)`
- Obligations: R3, R4, R9, R10

### E2: N4 -> N11 (invoke calls _get_experiment_id)
- Kind: CALL
- Condition: Always (at start of invoke)
- Transfer: `(trace: Trace) -> experiment_id: str`
- Evidence: Task interface description: "Must have a valid trace location with experiment information."
- Obligations: R4, R6

### E3: N11 -> N15 (reads TraceLocation from trace)
- Kind: DATA
- Condition: Always
- Transfer: `trace.info.trace_location -> type, mlflow_experiment.experiment_id`
- Evidence: `/testbed/mlflow/entities/trace_info.py:TraceInfo.trace_location`; `/testbed/mlflow/entities/trace_location.py:MlflowExperimentLocation.experiment_id`
- Obligations: R6

### E4: N4 -> N19 (invoke calls TracingClient.search_traces)
- Kind: CALL
- Condition: After experiment_id validated
- Transfer: `(experiment_ids=[experiment_id], filter_string, max_results, order_by, include_spans=True) -> PagedList[Trace]`
- Evidence: `/testbed/mlflow/tracing/client.py:TracingClient.search_traces` signature; `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` delegates to `SearchTracesTool` which must use search_traces.
- Obligations: R3, R5, R9

### E5: N4 -> N12 (invoke calls _convert_assessments_to_tool_types)
- Kind: CALL
- Condition: For each Trace in search results
- Transfer: `(trace.info.assessments: list[Assessment]) -> list[JudgeToolExpectation | JudgeToolFeedback]`
- Evidence: Task interface description: "assessments: List of expectations and feedback associated with the trace"
- Obligations: R7, R10

### E6: N12 -> N16 (reads Assessment subtype)
- Kind: DATA
- Condition: For each Assessment in list
- Transfer: `Assessment fields (name, source, rationale, span_id, assessment_id, value, error, overrides, valid) -> JudgeToolExpectation/JudgeToolFeedback fields`
- Evidence: `/testbed/mlflow/entities/assessment.py:Expectation`, `Feedback` fields; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation`, `JudgeToolFeedback`
- Obligations: R7

### E7: N4 -> N14 (reads TraceInfo from Trace)
- Kind: DATA
- Condition: For each Trace in search results
- Transfer: `trace.info.(trace_id, request_time, state, request_preview, response_preview, execution_duration, assessments) -> JudgeToolTraceInfo fields`
- Evidence: `/testbed/mlflow/entities/trace_info.py:TraceInfo` fields; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolTraceInfo`
- Obligations: R10

### E8: N2 -> N6 (name property reads constant)
- Kind: DATA
- Condition: Always
- Transfer: `ToolNames._SEARCH_TRACES -> return value`
- Evidence: `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; pattern from `GetTraceInfoTool.name` returning `ToolNames.GET_TRACE_INFO`
- Obligations: R1

### E9: N3 -> N7 (get_definition constructs ToolDefinition)
- Kind: DATA
- Condition: Always
- Transfer: Creates `ToolDefinition(function=FunctionToolDefinition(name=ToolNames._SEARCH_TRACES, description=..., parameters=ToolParamsSchema(...)))`
- Evidence: `/testbed/mlflow/types/llm.py:ToolDefinition`, `FunctionToolDefinition`, `ToolParamsSchema`; pattern from `GetTraceInfoTool.get_definition()`
- Obligations: R2

### E10: N4 -> N20 (invoke raises MlflowException on error)
- Kind: CONTROL
- Condition: Invalid trace location, search failure
- Transfer: Error message + error code
- Evidence: Task interface description; `/testbed/mlflow/exceptions.py:MlflowException`; `/testbed/mlflow/protos/databricks_pb2.py:INVALID_PARAMETER_VALUE`
- Obligations: R4, R6

### E11: N4 -> N5 (SearchTracesTool inherits JudgeTool)
- Kind: CONTROL
- Condition: Always (class definition)
- Transfer: Inherits `name`, `get_definition`, `invoke` abstract contract
- Evidence: `/testbed/mlflow/genai/judges/tools/base.py:JudgeTool`; `/testbed/mlflow/genai/judges/tools/search_traces.py:SearchTracesTool(JudgeTool)`
- Obligations: R1, R2, R3

### E12: N23 -> N22 (AssessmentSource.__post_init__ calls _standardize)
- Kind: CALL
- Condition: Always during AssessmentSource initialization
- Transfer: `(raw source_type: str) -> standardized source_type: str`
- Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSource.__post_init__` calls `AssessmentSourceType._standardize(self.source_type)`
- Obligations: R8

### E13: N22 -> N17 (reads _SOURCE_TYPES for validation)
- Kind: DATA
- Condition: After uppercasing and AI_JUDGE check
- Transfer: Validates against `_SOURCE_TYPES` list
- Evidence: `/testbed/mlflow/entities/assessment_source.py:AssessmentSourceType._SOURCE_TYPES = [SOURCE_TYPE_UNSPECIFIED, LLM_JUDGE, HUMAN, CODE]`
- Obligations: R8

## L3. Verifiable Contracts

### C1: name property returns ToolNames._SEARCH_TRACES
- Type: Interface
- Subject: `SearchTracesTool.name`
- Relation: EQ
- Expected: `"_search_traces"`
- Evidence: `/testbed/mlflow/genai/judges/tools/constants.py:ToolNames._SEARCH_TRACES = "_search_traces"`; pattern from `GetTraceInfoTool.name` returning `ToolNames.GET_TRACE_INFO`.
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().name` field read
- Obligations: R1
- Graph: N2, N6, E8, E11

### C2: get_definition returns ToolDefinition with name="_search_traces"
- Type: Interface
- Subject: `SearchTracesTool.get_definition().function.name`
- Relation: EQ
- Expected: `"_search_traces"`
- Evidence: Task interface description: "name: The tool name from ToolNames._SEARCH_TRACES"; pattern from `GetTraceInfoTool.get_definition()`.
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().get_definition().function.name`
- Obligations: R2
- Graph: N3, N6, N7, E9

### C3: get_definition returns ToolDefinition with type="function"
- Type: Interface
- Subject: `SearchTracesTool.get_definition().type`
- Relation: EQ
- Expected: `"function"`
- Evidence: Task interface description: "type: Set to 'function'"; pattern from all other JudgeTool implementations.
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().get_definition().type`
- Obligations: R2
- Graph: N3, N7, E9

### C4: get_definition declares filter_string as optional string parameter
- Type: Interface
- Subject: `SearchTracesTool.get_definition().function.parameters.properties["filter_string"]`
- Relation: TYPE_IS
- Expected: `ParamProperty` with `type="string"` and `description` containing filter syntax documentation
- Evidence: Task interface description: "filter_string (str): SQL-like filter syntax for trace selection"; parameter not in `required` list.
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().get_definition().function.parameters.properties`
- Obligations: R2
- Graph: N3, N7, E9

### C5: get_definition declares order_by as optional array-of-strings parameter
- Type: Interface
- Subject: `SearchTracesTool.get_definition().function.parameters.properties["order_by"]`
- Relation: TYPE_IS
- Expected: `ParamProperty` with `type="array"`, `items.type="string"`, and default description mentioning `['timestamp ASC']`
- Evidence: Task interface description: "order_by (list[str]): List of ordering expressions, defaults to ['timestamp ASC']"
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().get_definition().function.parameters.properties`
- Obligations: R2
- Graph: N3, N7, E9

### C6: get_definition declares max_results as optional integer parameter with default 20
- Type: Interface
- Subject: `SearchTracesTool.get_definition().function.parameters.properties["max_results"]`
- Relation: TYPE_IS
- Expected: `ParamProperty` with `type="integer"`, default description mentioning 20
- Evidence: Task interface description: "max_results (int): Maximum number of traces to return, defaults to 20"
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().get_definition().function.parameters.properties`
- Obligations: R2
- Graph: N3, N7, E9

### C7: get_definition has empty required list
- Type: Interface
- Subject: `SearchTracesTool.get_definition().function.parameters.required`
- Relation: EQ
- Expected: `[]` (empty list)
- Evidence: Task interface description: all three parameters described as optional; pattern from `GetTracesInSession.get_definition()` with `required=[]`.
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().get_definition().function.parameters.required`
- Obligations: R2
- Graph: N3, N7, E9

### C8: invoke raises MlflowException when trace has no trace_location
- Type: Failure
- Subject: `SearchTracesTool.invoke(trace, ...)` where `trace.info.trace_location is None`
- Relation: RAISES
- Expected: `MlflowException` with message about missing trace location
- Evidence: Task interface description: "The provided trace has no trace location information"
- Observe: EXCEPTION
- Target: `SearchTracesTool().invoke(trace_without_location)`
- Obligations: R4, R6
- Graph: N4, N11, N15, N20, E2, E3, E10

### C9: invoke raises MlflowException when trace location is not MLFLOW_EXPERIMENT
- Type: Failure
- Subject: `SearchTracesTool.invoke(trace, ...)` where `trace.info.trace_location.type != TraceLocationType.MLFLOW_EXPERIMENT`
- Relation: RAISES
- Expected: `MlflowException` with message about trace not from MLflow experiment context
- Evidence: Task interface description: "The trace is not from an MLflow experiment context"
- Observe: EXCEPTION
- Target: `SearchTracesTool().invoke(trace_with_wrong_location_type)`
- Obligations: R4, R6
- Graph: N4, N11, N15, N20, E2, E3, E10

### C10: invoke raises MlflowException when experiment_id is None
- Type: Failure
- Subject: `SearchTracesTool.invoke(trace, ...)` where `trace.info.trace_location.mlflow_experiment.experiment_id is None`
- Relation: RAISES
- Expected: `MlflowException` with message about no associated experiment_id
- Evidence: Task interface description: "The trace has no associated experiment_id"
- Observe: EXCEPTION
- Target: `SearchTracesTool().invoke(trace_with_null_experiment_id)`
- Obligations: R4, R6
- Graph: N4, N11, N15, N20, E2, E3, E10

### C11: invoke returns list of JudgeToolTraceInfo on success
- Type: Interface
- Subject: `SearchTracesTool.invoke(trace, ...)` return type
- Relation: TYPE_IS
- Expected: `list[JudgeToolTraceInfo]`
- Evidence: Task interface description: "Returns: List of JudgeToolTraceInfo objects"
- Observe: RETURN_VALUE
- Target: `SearchTracesTool().invoke(valid_trace)`
- Obligations: R3, R10
- Graph: N4, N8, E4, E7

### C12: invoke defaults order_by to ['timestamp ASC'] when None
- Type: Behavior
- Subject: `SearchTracesTool.invoke` with `order_by=None`
- Relation: DEFAULTS_TO
- Expected: `['timestamp ASC']` passed to underlying search
- Evidence: Task interface description: "Defaults to ['timestamp ASC'] for chronological ordering if None."
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: TracingClient.search_traces `order_by` parameter when SearchTracesTool.invoke called with `order_by=None`
- Obligations: R9
- Graph: N4, N19, E4

### C13: invoke defaults max_results to 20
- Type: Behavior
- Subject: `SearchTracesTool.invoke` with default `max_results`
- Relation: DEFAULTS_TO
- Expected: `20` passed to underlying search
- Evidence: Task interface description: "Defaults to 20 to prevent excessive memory usage."
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: TracingClient.search_traces `max_results` parameter
- Obligations: R9
- Graph: N4, N19, E4

### C14: _get_experiment_id returns experiment_id string for valid trace
- Type: Dataflow
- Subject: `_get_experiment_id(trace)` with trace having MLFLOW_EXPERIMENT location with experiment_id
- Relation: EQ
- Expected: The experiment_id string from `trace.info.trace_location.mlflow_experiment.experiment_id`
- Evidence: Task interface description: "Returns: str: The experiment ID string extracted from the trace's location information."
- Observe: RETURN_VALUE
- Target: `_get_experiment_id(valid_trace)`
- Obligations: R6
- Graph: N11, N15, E3

### C15: _convert_assessments_to_tool_types converts Expectation to JudgeToolExpectation
- Type: Dataflow
- Subject: `_convert_assessments_to_tool_types([Expectation(...)])`
- Relation: TYPE_IS
- Expected: Returns list containing `JudgeToolExpectation` with matching fields: `name`, `source` (AssessmentSource.source_type string), `rationale`, `span_id`, `assessment_id`, `value`
- Evidence: Task interface description: "Expectation objects are converted to JudgeToolExpectation instances"; `/testbed/mlflow/genai/judges/tools/types.py:JudgeToolExpectation` fields; `/testbed/mlflow/entities/assessment.py:Expectation` fields.
- Observe: RETURN_VALUE
- Target: `_convert_assessments_to_tool_types([expectation_obj])`
- Obligations: R7
- Graph: N12, N16, N9, E6

### C16: _convert_assessments_to_tool_types converts Feedback to JudgeToolFeedback with error fields
- Type: Dataflow
- Subject: `_convert_assessments_to_tool_types([Feedback(...)])`
- Relation: TYPE_IS
- Expected: Returns list containing `JudgeToolFeedback` with: `name`, `source` (AssessmentSource.source_type), `rationale`, `span_id`, `assessment_id`, `value`, `error_code` (from feedback.error.error_code or None), `error_message` (from feedback.error.error_message or None), `stack_trace` (from feedback.error.stack_trace or None), `overrides`, `valid`
- Evidence: Task interface description: "Feedback objects are converted to JudgeToolFeedback instances with additional error handling fields (error_code, error_message, stack_trace) and validation properties (overrides, valid)"; "Error fields in JudgeToolFeedback are set to None if the original Feedback object has no associated error"
- Observe: RETURN_VALUE
- Target: `_convert_assessments_to_tool_types([feedback_obj])`
- Obligations: R7
- Graph: N12, N16, N10, N18, E6

### C17: _convert_assessments_to_tool_types preserves order
- Type: Behavior
- Subject: `_convert_assessments_to_tool_types` with multiple assessments
- Relation: PRESERVE
- Expected: Output list order matches input list order
- Evidence: Task interface description: "The returned list maintains the same order as the input list."
- Observe: RETURN_VALUE
- Target: `_convert_assessments_to_tool_types([expectation1, feedback1, expectation2])` returns matching order
- Obligations: R7
- Graph: N12, E6

### C18: _standardize uppercases valid input
- Type: Dataflow
- Subject: `AssessmentSourceType._standardize("human")`
- Relation: EQ
- Expected: `"HUMAN"`
- Evidence: Task interface description: "case-insensitive string inputs (converts to uppercase)"; `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_case_insensitivity`
- Observe: RETURN_VALUE
- Target: `AssessmentSourceType._standardize("human")`
- Obligations: R8
- Graph: N22, E13

### C19: _standardize maps AI_JUDGE to LLM_JUDGE with FutureWarning
- Type: SideEffect
- Subject: `AssessmentSourceType._standardize("AI_JUDGE")`
- Relation: EQ
- Expected: Returns `"LLM_JUDGE"` AND emits `FutureWarning` matching `"AI_JUDGE is deprecated. Use LLM_JUDGE instead."`
- Evidence: Task interface description: "automatically converted to 'LLM_JUDGE' with a deprecation warning"; `/testbed/tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning`
- Observe: RETURN_VALUE + SIDE_EFFECT (warnings.warn)
- Target: `AssessmentSourceType._standardize("AI_JUDGE")`
- Obligations: R8
- Graph: N22, E13

### C20: _standardize raises MlflowException for invalid type
- Type: Failure
- Subject: `AssessmentSourceType._standardize("ROBOT")`
- Relation: RAISES
- Expected: `MlflowException` with message matching `"Invalid assessment source type"`
- Evidence: Task interface description: "Raises: MlflowException: If the provided source_type is not a valid assessment source type"; `/testbed/tests/entities/test_assessment_source.py:test_assessment_source_type_validation`
- Observe: EXCEPTION
- Target: `AssessmentSourceType._standardize("ROBOT")`
- Obligations: R8
- Graph: N22, N20, E13

### C21: _standardize is case-insensitive for "AI_JUDGE"
- Type: Behavior
- Subject: `AssessmentSourceType._standardize("ai_judge")`
- Relation: EQ
- Expected: `"LLM_JUDGE"` with FutureWarning
- Evidence: Task interface description: "Case-insensitive string inputs"; `/testbed/tests/entities/test_assessment_source.py:test_ai_judge_deprecation_warning` tests `"AI_JUDGE"` only but case-insensitivity is a general property.
- Observe: RETURN_VALUE + SIDE_EFFECT
- Target: `AssessmentSourceType._standardize("ai_judge")`
- Obligations: R8
- Graph: N22, E13

### C22: invoke handles search failure with MlflowException
- Type: Failure
- Subject: `SearchTracesTool.invoke` when underlying search raises
- Relation: RAISES
- Expected: `MlflowException` (wrapping or re-raising search error)
- Evidence: Task interface description: "The search operation fails due to invalid filter syntax or other errors"
- Observe: EXCEPTION
- Target: `SearchTracesTool().invoke(trace, filter_string="invalid syntax")`
- Obligations: R4, R3
- Graph: N4, N19, N20, E4, E10

### C23: invoke skips failed per-trace conversions with warning log
- Type: SideEffect
- Subject: `SearchTracesTool.invoke` when one trace in results fails to process
- Relation: CONTAINS
- Expected: Warning is logged; other traces are returned; no exception propagates
- Evidence: Task interface description: "Traces that fail to process during retrieval are logged as warnings and skipped"
- Observe: SIDE_EFFECT (logger.warning)
- Target: `SearchTracesTool().invoke(trace)` when a trace in search results causes conversion error
- Obligations: R5
- Graph: N4, E7

### C24: invoke passes include_spans=True to search_traces
- Type: Dataflow
- Subject: `SearchTracesTool.invoke` underlying search call
- Relation: EQ
- Expected: `include_spans=True` so full Trace objects are returned
- Evidence: Task requires access to `request`, `response`, `execution_duration` which come from `TraceInfo`; `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` delegates to `SearchTracesTool` and expects full trace access.
- Observe: RUNTIME_ARGUMENT_TRACE
- Target: `TracingClient.search_traces` `include_spans` argument
- Obligations: R3, R10
- Graph: N4, N19, E4

### C25: SearchTracesTool is importable from genai.judges.tools
- Type: Interface
- Subject: `from mlflow.genai.judges.tools import SearchTracesTool`
- Relation: TYPE_IS
- Expected: `SearchTracesTool` class is accessible
- Evidence: `/testbed/mlflow/genai/judges/tools/__init__.py` exports `SearchTracesTool`; `/testbed/mlflow/genai/judges/tools/get_traces_in_session.py` imports `SearchTracesTool`.
- Observe: IMPORT_BOUNDARY
- Target: `from mlflow.genai.judges.tools.search_traces import SearchTracesTool`
- Obligations: R1, R2, R3
- Graph: N1, E11
