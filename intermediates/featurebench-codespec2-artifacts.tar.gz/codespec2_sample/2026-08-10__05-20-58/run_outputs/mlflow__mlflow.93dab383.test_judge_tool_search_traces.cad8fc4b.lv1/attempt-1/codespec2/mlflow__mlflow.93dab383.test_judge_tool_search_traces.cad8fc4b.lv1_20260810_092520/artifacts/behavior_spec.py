"""
Executable behavior spec for SearchTracesTool and AssessmentSourceType.

Covers L3 State, Behavior, Failure, SideEffect, defaults, boundaries, and
compatibility contracts. Each check_* function exercises a documented outcome.
"""

import sys
import warnings
from unittest.mock import MagicMock, patch

import pytest

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, ErrorCode

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_trace_with_location(experiment_id="exp-001"):
    """Create a minimal Trace with a valid MLflow experiment location."""
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-001",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id=experiment_id),
        ),
        request_time=1700000000000,
        state=TraceState.OK,
    )
    data = TraceData()
    return Trace(info=info, data=data)


def _make_trace_without_location():
    """Create a Trace with trace_location=None."""
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-002",
        trace_location=None,
        request_time=1700000000000,
        state=TraceState.OK,
    )
    data = TraceData()
    return Trace(info=info, data=data)


def _make_trace_with_inference_table_location():
    """Create a Trace with non-MLFLOW_EXPERIMENT location."""
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        InferenceTableLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-003",
        trace_location=TraceLocation(
            type=TraceLocationType.INFERENCE_TABLE,
            inference_table=InferenceTableLocation(full_table_name="catalog.schema.table"),
        ),
        request_time=1700000000000,
        state=TraceState.OK,
    )
    data = TraceData()
    return Trace(info=info, data=data)


def _make_trace_with_null_experiment_id():
    """Create a Trace with MLFLOW_EXPERIMENT location but None experiment_id."""
    from mlflow.entities.trace import Trace
    from mlflow.entities.trace_data import TraceData
    from mlflow.entities.trace_info import TraceInfo
    from mlflow.entities.trace_location import (
        MlflowExperimentLocation,
        TraceLocation,
        TraceLocationType,
    )
    from mlflow.entities.trace_state import TraceState

    info = TraceInfo(
        trace_id="tr-004",
        trace_location=TraceLocation(
            type=TraceLocationType.MLFLOW_EXPERIMENT,
            mlflow_experiment=MlflowExperimentLocation(experiment_id=None),
        ),
        request_time=1700000000000,
        state=TraceState.OK,
    )
    data = TraceData()
    return Trace(info=info, data=data)


# ---------------------------------------------------------------------------
# C8: invoke raises MlflowException when trace has no trace_location
# F2 repair: exact message match with pytest.raises
# F4 repair: assert error_code == INVALID_PARAMETER_VALUE
#
# Perspective: Native test test_get_traces_in_session_tool_invoke_no_session_id
#   uses pytest.raises(match=...) and verifies error_code.
# ---------------------------------------------------------------------------

def check_invoke_raises_when_no_trace_location() -> None:
    """Contracts: C8"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace = _make_trace_without_location()
    tool = SearchTracesTool()

    with pytest.raises(MlflowException, match="No trace location") as exc_info:
        tool.invoke(trace)
    assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)
    print("PASS: check_invoke_raises_when_no_trace_location")


# ---------------------------------------------------------------------------
# C9: invoke raises MlflowException when trace location is not MLFLOW_EXPERIMENT
# F2 repair: exact message match
# F4 repair: assert error_code
# ---------------------------------------------------------------------------

def check_invoke_raises_when_not_mlflow_experiment() -> None:
    """Contracts: C9"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace = _make_trace_with_inference_table_location()
    tool = SearchTracesTool()

    with pytest.raises(MlflowException, match="not an MLflow experiment") as exc_info:
        tool.invoke(trace)
    assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)
    print("PASS: check_invoke_raises_when_not_mlflow_experiment")


# ---------------------------------------------------------------------------
# C10: invoke raises MlflowException when experiment_id is None
# F2 repair: exact message match
# F4 repair: assert error_code
# ---------------------------------------------------------------------------

def check_invoke_raises_when_experiment_id_is_none() -> None:
    """Contracts: C10"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace = _make_trace_with_null_experiment_id()
    tool = SearchTracesTool()

    with pytest.raises(MlflowException, match="No experiment_id") as exc_info:
        tool.invoke(trace)
    assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)
    print("PASS: check_invoke_raises_when_experiment_id_is_none")


# ---------------------------------------------------------------------------
# C22: invoke handles search failure with MlflowException
# F7 repair: use realistic MlflowException side_effect instead of RuntimeError
# F4 repair: assert error_code propagates
#
# Perspective: TracingClient.search_traces raises MlflowException for
#   invalid syntax or backend errors; invoke should propagate this.
# ---------------------------------------------------------------------------

def check_invoke_raises_on_search_failure() -> None:
    """Contracts: C22"""
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool

    trace = _make_trace_with_location(experiment_id="exp-001")

    with patch(
        "mlflow.genai.judges.tools.search_traces.TracingClient"
    ) as mock_client_cls:
        mock_client = mock_client_cls.return_value
        mock_client.search_traces.side_effect = MlflowException(
            "Invalid filter syntax",
            error_code=INVALID_PARAMETER_VALUE,
        )

        tool = SearchTracesTool()
        with pytest.raises(MlflowException, match="Invalid filter syntax") as exc_info:
            tool.invoke(trace, filter_string="invalid syntax")
        assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)

    print("PASS: check_invoke_raises_on_search_failure")


# ---------------------------------------------------------------------------
# C23: invoke skips failed per-trace conversions with warning log
# F3 repair: use a truly malformed assessment in the trace's assessments list
#   instead of setting assessments=None. Verify warning mentions the failing
#   trace ID.
# ---------------------------------------------------------------------------

def check_invoke_skips_failed_trace_conversion_with_warning() -> None:
    """Contracts: C23"""
    import logging

    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.entities.assessment import Expectation

    trace = _make_trace_with_location(experiment_id="exp-001")

    # Create a good result trace
    good_trace = _make_trace_with_location(experiment_id="exp-001")
    good_trace.info.trace_id = "good-tr-001"

    # Create a trace that will cause a conversion error: add a malformed
    # assessment that is missing required fields (no source, no name, etc.)
    bad_trace = _make_trace_with_location(experiment_id="exp-001")
    bad_trace.info.trace_id = "bad-tr-002"
    # Populate assessments with an object that will cause AttributeError during
    # conversion (e.g., an object without the expected Assessment interface)
    class MalformedAssessment:
        pass
    bad_trace.info.assessments = [MalformedAssessment()]

    with patch(
        "mlflow.genai.judges.tools.search_traces.TracingClient"
    ) as mock_client_cls:
        mock_client = mock_client_cls.return_value
        mock_client.search_traces.return_value = [good_trace, bad_trace]

        tool = SearchTracesTool()
        with patch.object(
            logging.getLogger("mlflow.genai.judges.tools.search_traces"), "warning"
        ) as mock_warning:
            results = tool.invoke(trace)

        # Should have at least the good trace returned
        assert len(results) >= 1
        assert results[0].trace_id == "good-tr-001"
        # A warning should have been emitted for the bad trace
        assert mock_warning.call_count >= 1, (
            "Expected at least one warning for the failed trace conversion"
        )
        # Verify the warning mentions the failing trace ID
        warning_calls = [str(call) for call in mock_warning.call_args_list]
        assert any("bad-tr-002" in c for c in warning_calls), (
            f"Expected warning to mention failing trace ID 'bad-tr-002', "
            f"got: {warning_calls}"
        )

    print("PASS: check_invoke_skips_failed_trace_conversion_with_warning")


# ---------------------------------------------------------------------------
# C17: _convert_assessments_to_tool_types preserves order
# ---------------------------------------------------------------------------

def check_convert_assessments_preserves_order() -> None:
    """Contracts: C17"""
    from mlflow.entities.assessment import Expectation, Feedback
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import _convert_assessments_to_tool_types
    from mlflow.genai.judges.tools.types import JudgeToolExpectation, JudgeToolFeedback

    exp1 = Expectation(
        name="first",
        value="v1",
        source=AssessmentSource(source_type="HUMAN"),
        span_id="s1",
    )
    fb1 = Feedback(
        name="second",
        value=0.5,
        source=AssessmentSource(source_type="LLM_JUDGE"),
        span_id="s2",
    )
    exp2 = Expectation(
        name="third",
        value="v3",
        source=AssessmentSource(source_type="CODE"),
        span_id="s3",
    )

    assessments = [exp1, fb1, exp2]
    result = _convert_assessments_to_tool_types(assessments)

    assert len(result) == 3
    assert isinstance(result[0], JudgeToolExpectation)
    assert result[0].name == "first"
    assert isinstance(result[1], JudgeToolFeedback)
    assert result[1].name == "second"
    assert isinstance(result[2], JudgeToolExpectation)
    assert result[2].name == "third"
    print("PASS: check_convert_assessments_preserves_order")


# ---------------------------------------------------------------------------
# C18: _standardize uppercases valid input
# ---------------------------------------------------------------------------

def check_standardize_uppercases_valid_input() -> None:
    """Contracts: C18"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    assert AssessmentSourceType._standardize("human") == "HUMAN"
    assert AssessmentSourceType._standardize("Human") == "HUMAN"
    assert AssessmentSourceType._standardize("HUMAN") == "HUMAN"
    assert AssessmentSourceType._standardize("llm_judge") == "LLM_JUDGE"
    assert AssessmentSourceType._standardize("code") == "CODE"
    assert AssessmentSourceType._standardize("source_type_unspecified") == "SOURCE_TYPE_UNSPECIFIED"
    print("PASS: check_standardize_uppercases_valid_input")


# ---------------------------------------------------------------------------
# C19: _standardize maps AI_JUDGE to LLM_JUDGE with FutureWarning
# P2 repair: use pytest.warns with exact match, matching native test practice
#
# Perspective: Native test test_ai_judge_deprecation_warning uses
#   pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead.")
# ---------------------------------------------------------------------------

def check_standardize_ai_judge_deprecation_warning() -> None:
    """Contracts: C19"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    with pytest.warns(
        FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."
    ):
        result = AssessmentSourceType._standardize("AI_JUDGE")

    assert result == "LLM_JUDGE"
    print("PASS: check_standardize_ai_judge_deprecation_warning")


# ---------------------------------------------------------------------------
# C20: _standardize raises MlflowException for invalid type
# ---------------------------------------------------------------------------

def check_standardize_raises_for_invalid_type() -> None:
    """Contracts: C20"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    with pytest.raises(MlflowException, match="Invalid assessment source type"):
        AssessmentSourceType._standardize("ROBOT")
    print("PASS: check_standardize_raises_for_invalid_type")


# ---------------------------------------------------------------------------
# C21: _standardize is case-insensitive for "AI_JUDGE"
# P2 repair: use pytest.warns for consistency
# ---------------------------------------------------------------------------

def check_standardize_case_insensitive_ai_judge() -> None:
    """Contracts: C21"""
    from mlflow.entities.assessment_source import AssessmentSourceType

    # Lowercase ai_judge
    with pytest.warns(FutureWarning):
        result = AssessmentSourceType._standardize("ai_judge")
    assert result == "LLM_JUDGE"

    # Mixed case Ai_Judge
    with pytest.warns(FutureWarning):
        result2 = AssessmentSourceType._standardize("Ai_Judge")
    assert result2 == "LLM_JUDGE"
    print("PASS: check_standardize_case_insensitive_ai_judge")


# ---------------------------------------------------------------------------
# Integration: _standardize called through AssessmentSource.__post_init__
# ---------------------------------------------------------------------------

def check_assessment_source_creation_uses_standardize() -> None:
    """Contracts: C18, C19, C20, C21 - verifies _standardize is wired through
    AssessmentSource.__post_init__"""
    from mlflow.entities.assessment_source import AssessmentSource

    # Case normalization through AssessmentSource creation
    source = AssessmentSource(source_type="human", source_id="u1")
    assert source.source_type == "HUMAN"

    # AI_JUDGE deprecation through AssessmentSource creation
    with pytest.warns(FutureWarning, match="AI_JUDGE is deprecated. Use LLM_JUDGE instead."):
        source2 = AssessmentSource(source_type="AI_JUDGE", source_id="u2")
    assert source2.source_type == "LLM_JUDGE"

    # Invalid type through AssessmentSource creation
    with pytest.raises(MlflowException, match="Invalid assessment source type"):
        AssessmentSource(source_type="ROBOT", source_id="u3")

    print("PASS: check_assessment_source_creation_uses_standardize")


# ---------------------------------------------------------------------------
# C11 + R10: invoke returns JudgeToolTraceInfo with correct field mapping
# F5 repair: assert exact values for request/response instead of is-not-None;
#   add real assessments to the result trace and verify conversion.
# ---------------------------------------------------------------------------

def check_invoke_result_fields_match_trace_info() -> None:
    """Contracts: C11 (extended) - verify field mapping from TraceInfo to
    JudgeToolTraceInfo with exact field values and assessment conversion."""
    from mlflow.entities.assessment import Expectation, Feedback
    from mlflow.entities.assessment_source import AssessmentSource
    from mlflow.genai.judges.tools.search_traces import SearchTracesTool
    from mlflow.genai.judges.tools.types import JudgeToolTraceInfo, JudgeToolExpectation, JudgeToolFeedback

    trace = _make_trace_with_location(experiment_id="exp-001")

    result_trace = _make_trace_with_location(experiment_id="exp-001")
    result_trace.info.trace_id = "map-tr-001"
    result_trace.info.request_time = 1700000000123
    result_trace.info.execution_duration = 5000
    result_trace.info.request_preview = '{"q": "hello"}'
    result_trace.info.response_preview = '{"a": "world"}'
    # Add real assessments to verify they are converted
    result_trace.info.assessments = [
        Expectation(
            name="expected_answer",
            value="Paris",
            source=AssessmentSource(source_type="HUMAN", source_id="user1"),
            span_id="span-001",
        ),
        Feedback(
            name="relevance",
            value=0.95,
            source=AssessmentSource(source_type="LLM_JUDGE", source_id="gpt-4"),
            span_id="span-002",
        ),
    ]

    with patch(
        "mlflow.genai.judges.tools.search_traces.TracingClient"
    ) as mock_client_cls:
        mock_client = mock_client_cls.return_value
        mock_client.search_traces.return_value = [result_trace]

        tool = SearchTracesTool()
        results = tool.invoke(trace, max_results=1)

    assert len(results) == 1
    info = results[0]
    assert isinstance(info, JudgeToolTraceInfo)
    assert info.trace_id == "map-tr-001"
    assert info.request_time == 1700000000123
    assert info.execution_duration == 5000
    # F5: exact value assertions instead of is-not-None
    assert info.request == '{"q": "hello"}', (
        f"Expected request='{{\"q\": \"hello\"}}', got {info.request!r}"
    )
    assert info.response == '{"a": "world"}', (
        f"Expected response='{{\"a\": \"world\"}}', got {info.response!r}"
    )
    # F5: verify assessments were actually converted
    assert isinstance(info.assessments, list)
    assert len(info.assessments) == 2
    assert isinstance(info.assessments[0], JudgeToolExpectation)
    assert info.assessments[0].name == "expected_answer"
    assert info.assessments[0].value == "Paris"
    assert isinstance(info.assessments[1], JudgeToolFeedback)
    assert info.assessments[1].name == "relevance"
    assert info.assessments[1].value == 0.95
    print("PASS: check_invoke_result_fields_match_trace_info")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    check_invoke_raises_when_no_trace_location()
    check_invoke_raises_when_not_mlflow_experiment()
    check_invoke_raises_when_experiment_id_is_none()
    check_invoke_raises_on_search_failure()
    check_invoke_skips_failed_trace_conversion_with_warning()
    check_convert_assessments_preserves_order()
    check_standardize_uppercases_valid_input()
    check_standardize_ai_judge_deprecation_warning()
    check_standardize_raises_for_invalid_type()
    check_standardize_case_insensitive_ai_judge()
    check_assessment_source_creation_uses_standardize()
    check_invoke_result_fields_match_trace_info()
    print("\nAll behavior spec checks PASSED.")
    sys.exit(0)
